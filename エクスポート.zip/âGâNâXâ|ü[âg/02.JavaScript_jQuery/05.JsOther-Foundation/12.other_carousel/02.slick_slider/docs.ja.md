---
title: Slick_Slider
taxonomy:
    category:
        - docs
---

## 複数の画像を表示（base）

[新規タブ](../../../../sample/jquery/slick-slider/multi_base/index.html?target=_blank)

<iframe width="100%" height="650" src="../../../sample/jquery/slick-slider/multi_base/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

## 複数画像のセンター画像を拡大する
[新規タブ](../../../../sample/jquery/slick-slider/multi_center_large_key/index.html?target=_blank)

<iframe width="100%" height="650" src="../../../sample/jquery/slick-slider/multi_center_large_key/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>