## <span>Demo1</span>tablesorter basic demo (includes widgets) 

<a href="upload/sample1(tablesorter)/" target="_blank">新規タブ</a>

テーブルクラス名～ **tablesorter**    
 theme～ **blackice**
 
<script async src="//jsfiddle.net/Mottie/bbxxomhx/embed/result,html,css,js,resources"></script>


## <span>Demo2</span>tablesorter basic demo with pager plugin

テーブルクラス名～ **tablesorter**  
 theme～ **blackice**

<a href="upload/sample2(tablesorter)/" target="_blank">新規タブ</a>
<script async src="//jsfiddle.net/Mottie/wty134u7/embed/result,html,css,js,resources"></script>


## <span>Demo3</span>tablesorter LESS theme

<a href="upload/sample3(tablesorter)/" target="_blank">新規タブ</a>

<iframe width="100%" height="350" src="upload/sample3(tablesorter)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

テーブルクラス名～ **tablesorter-custom**  

<p class="tmp list"><span>リスト</span>script</p>
```
var $table = $('table'),
	process = false;

$('.error').click(function () {
	$.tablesorter.showError($table, 'This is the error row');
});

$('.process').click(function () {
	process = !process;
	$.tablesorter.isProcessing($table, process);
});

$('.sortable').click(function () {
	$table
		.find('.tablesorter-header:last').toggleClass('sorter-false')
		.trigger('update');
});

$table.tablesorter({
	sortList: [
		[0, 0],
		[1, 0],
		[2, 0]
	],
	widgets: ['zebra', 'columns', "filter"]
});
```

## <span>Demo4</span>Tablesorter Bootstrap LESS theme

<a href="upload/sample4(tablesorter)/" target="_blank">新規タブ</a>

<iframe width="100%" height="800" src="upload/sample4(tablesorter)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

テーブルクラス名～ **tablesorter-bootstrap**  

<p class="tmp list"><span>リスト</span>script</p>
```
var $table = $('table'),
	process = false;

$('.error').click(function () {
	$.tablesorter.showError($table, 'This is the error row');
});

$('.process').click(function () {
	process = !process;
	$.tablesorter.isProcessing($table, process);
});

$('.sortable').click(function () {
	$table
		.find('.tablesorter-header:last').toggleClass('sorter-false')
		.trigger('update');
});

$table.tablesorter({
	theme: 'bootstrap',
	headerTemplate: '{content} {icon}',
	sortList: [
		[0, 0],
		[1, 0],
		[2, 0]
	],
	widgets: ['zebra', 'columns', 'filter', 'uitheme']
});
```



## <span>Demo5</span>Tablesorter Metro LESS theme

<a href="upload/sample5(tablesorter)/" target="_blank">新規タブ</a>

<iframe width="100%" height="550" src="upload/sample5(tablesorter)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

テーブルクラス名～ **tablesorter-metro**  

<p class="tmp list"><span>リスト</span>script</p>
```
var $table = $('table'),
	process = false;

$('.error').click(function () {
	$.tablesorter.showError($table, 'This is the error row');
});

$('.process').click(function () {
	process = !process;
	$.tablesorter.isProcessing($table, process);
});

$('.sortable').click(function () {
	$table
		.find('.tablesorter-header:last').toggleClass('sorter-false')
		.trigger('update');
});

$table.tablesorter({
	sortList: [
		[0, 0],
		[1, 0],
		[2, 0]
	],
	widgets: ['zebra', 'columns', "filter"]
})
.tablesorterPager({
	// target the pager markup - see the HTML block below
	container: $(".pager")
});
```

## </span>Demo6</span>Tablesorter SCSS theme

<a href="upload/sample6(tablesorter)/" target="_blank">新規タブ</a>

<iframe width="100%" height="550" src="upload/sample6(tablesorter)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

テーブルクラス名～** tablesorter-custom** 

<p class="tmp list"><span>リスト</span>script</p>
```
var $table = $('table'),
	process = false;

$('.error').click(function () {
	$.tablesorter.showError($table, 'This is the error row');
});

$('.process').click(function () {
	process = !process;
	$.tablesorter.isProcessing($table, process);
});

$('.sortable').click(function () {
	$table
		.find('.tablesorter-header:last').toggleClass('sorter-false')
		.trigger('update');
});

$table.tablesorter({
	sortList: [
		[0, 0],
		[1, 0],
		[2, 0]
	],
	widgets: ['zebra', 'columns', "filter"]
});
```

## 参考サイト

* [widgets参考サイト](https://mottie.github.io/tablesorter/docs/index.html#Widget-options)
* [日本語訳](https://mottie-github-io.translate.goog/tablesorter/docs/index.html?_x_tr_sl=auto&_x_tr_tl=ja&_x_tr_hl=ja&_x_tr_pto=wapp#Widget-options)
* [デモページ（Examples）](https://mottie.github.io/tablesorter/docs/index.html#Examples) 様々なサンプルがあります。
