*[page-title]:コンポーネントの利用


## コンポーネントとサービスプロバイダー

サービスプロバイダーが重要となるものの例として、もう1つ「コンポーネント」についても説明しましょう。  
コンポーネントは、「フロントエンドとバックエンドを一体化して扱える部品」です。3章で、サブビューを使ってヘッダーやフッターなどの部品を組み込むことを説明しました。しかし、こうしたものは「表示を部品化するだけ」です。そこに組み込む値や事前に実行する処理などは、それを利用するコントローラーですべて用意しないといけません。

コンポーネントは、フロントエンドの表示部分だけでなく、その背後で動くPHPのコードまで含めて部品化します。ただ組み込むだけで、コンポーネントに用意された処理が実行され、その結果としてコンポーネントが表示されるのです。  

しかし、フロント(テンプレート)とバック(PHPコード)をまとめて扱えるようにするためには、どこかでコンポーネントをひとまとめにした部品として処理する仕組みを用意しないといけません。
そこで「サービスプロバイダー」の出番となるわけです。サービスプロバイダーでコンポーネントを登録することで、完全に独立した部品として扱えるコンポーネントを作成することができるようになっているのです。


>（まとめ）  
> コンポーネントは、フロントエンドの表示とバックエンドの処理を一体化した部品で、組み込むだけで必要な処理が実行され表示されます。   
> そのためには、サービスプロバイダーでコンポーネントを登録し、独立した部品として利用できる仕組みを用意する必要があります。

### コンポーネントを作る

コンポーネントはフロントエンドとバックエンドで構成されるため、正しい場所と名前で作成する必要があり、間違いを防ぐために artisan コマンドで作成します。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:component コンポーネント名
```

このように実行することで、指定した名前のコンポーネント関連ファイルが作成されます。  
では、以下のようにコマンドを実行してみましょう。

```
php artisan make:component Message
```
![](upload/make_component_Messageコマンド実行.png)

artisan実行で、テンプレート（resources/views/components/message.blade.php）とPHPコード（app/View/Components/Message.php）の2ファイルが作成されます。  
テンプレートはresourcesに、プログラムはappに配置され、それぞれ役割が異なります。

<div markdown="1" class="d-flex">
![](upload/message_bladeディレクトリ.png)
![](upload/Message_phpディレクトリ.png)
</div>

## コンポーネントの内容

では、作成されたコードを見ていきましょう。まずはPHPのコードからです。  
app/View/Components内のMessage.phpを開くと以下のように書かれていることがわかります。

<p class="tmp list"><span>リスト5-8</span>app/View/Components/Message.php（デフォルト）</p>
```
<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class Message extends Component
{
  
  public function __construct()
  {
    //
  }

  public function render(): View|Closure|string
  {
    return view('components.message');
  }
}
```

コンポーネントクラスは Illuminate\View\Component を継承し、コンストラクタと render メソッドを持ちます。  
render で view 関数を使いテンプレートを指定し、デフォルトでは views/components/message.blade.php が表示として返されます。


### テンプレートについて

では、「components」内に作成されたmessage.blade.phpの内容はどうなっているのでしょうか。見てみましょう。

<p class="tmp list"><span>リスト5-9</span>message.blade.php（デフォルト）</p>
```
<div>
    <!-- Always remember that you are absolutely unique. Just like everyone else. - Margaret Mead -->
</div>
```

div内の英語文翻訳
: あなたは他の皆と同じように、唯一無二の存在であることを常に忘れないで。 - マーガレット・ミード


## 外部からデータを取得し表示するコンポーネント

コンポーネントは内部で処理を完結させ、組み込むだけで動作する点が特徴です。  
サンプルとして、以下のJSON Placeholderからデータを取得して表示するコンポーネントを作成します。

https://jsonplaceholder.typicode.com/


### コンポーネントクラスの作成

では、コンポーネントを作りましょう。まずはクラスからです。  
app/View/Components/Message.phpファイルの内容を以下に書き換えてください（リターンマークは実際には改行せず、次の行と続けて記述してください）。

<p class="tmp list"><span>リスト5-10</span>app/View/Components/Message.php</p>
```
<?php
namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;
use Illuminate\Support\Facades\Http;

class Message extends Component
{
  private $data;

  public function __construct()
  {
    $num = rand(1, 100);
    $response = Http::get('https://jsonplaceholder.typicode.com/posts/' . $num);
    $this->data = $response->json();
  }

  public function render(): View|Closure|string
  {
    $data = [
      'msg'=>'ランダムなPOSTデータを表示します。',
      'data'=> $this->data
    ];
    return view('components.message',$data);
  }
}
```

コンストラクタで Http::get を使い、/posts/番号 にアクセスしてランダムな投稿データ(JSON)を取得し $this->data に格納します。  
render メソッドで data とメッセージを渡し、components.message をレンダリングして返しています。


例）<https://jsonplaceholder.typicode.com/posts/20>の場合

```
{
  "userId": 2,
  "id": 20,
  "title": "doloribus ad provident suscipit at",
  "body": "qui consequuntur ducimus possimus quisquam amet similique\nsuscipit porro ipsam amet\neos veritatis officiis exercitationem vel fugit aut necessitatibus totam\nomnis rerum consequatur expedita quidem cumque explicabo"
}
```



### テンプレートを作成する

続いて、テンプレートを作りましょう。resources/views/components/message.blade.phpを開き、以下のように記述をしてください。

<p class="tmp list"><span>リスト5-11</span>resources/views/components/message.blade.php</p>
```
<div style="border:solid 1px gray; padding:0px 10px; margin:10px 0px;">
  <p style="color:red;">Message component</p>
  <p style="font-size:12pt;">{{$msg}}</p>
  <ul>
    <li>[id] {{$data['id']}}</li>
    <li>[title] {{$data['title']}}</li>
    <li>[content] {{$data['body']}}</li>
  </ul>
</div>
```
ここでは、コンポーネントクラスから渡された$dataからid, title,bodyといった値を取り出して表示しています。


## コンポーネントをサービスプロバイダーで読み込む

では、作成したコンポーネントを使えるようにしましょう。これを行うのが、サービスプロバイダーです。  
サービスプロバイダー内で、コンポーネントの設定を行うことでコンポーネントが利用できるようになります。  

では、HelloServiceProvider.phpを開き、コードを以下のように書き換えましょう。

<p class="tmp list"><span>リスト5-12</span>HelloServiceProvider.php</p>
```
<?php
namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;
use App\View\Components\Message;

class HelloServiceProvider extends ServiceProvider
{
  public function boot()
  {
    Blade::component('package-message', Message::class);
  }

}
```

bootメソッドで Blade::component('package-message', Message::class) を実行し、Messageクラスを 'package-message' という名前で登録します。  
これにより、テンプレートでそのコンポーネントを利用できるようになります。


### コンポーネントを利用する

では、作成したコンポーネントをテンプレートに埋め込んで使ってみましょう。  
「hello」フォルダー内のindex.blade.phpを開いて、@section('content')部分を以下のように書き換えてください。

<p class="tmp list"><span>リスト5-13</span>hello/index.blade.php</p>
```
@section('content')
  <h2>コンポーネント</h2>
  <x-package-message />
  <p>※上がコンポーネントの表示です。</p>
@endsection
```

/helloにアクセスすると、ページ内にmessage コンポーネントが表示されます。
![](upload/Message_component表示.png){.photo-border}

`<x-package-message />` は package-message という名前のコンポーネントで、 `<x-コンポーネント名 />` 形式で記述して利用します。 /hello にアクセスすると JSON Placeholder からランダムに取得したデータが表示され、リロードごとに内容が変わります。


## 値をコンポーネントに渡す

コンポーネントは `<x-〇〇/>` と書くだけで自動的に外部サイトからJSONを取得して表示できますが、外部から情報を渡せるとさらに便利です。  
例えばIDを指定して表示するデータを変えることも可能で、その実装は簡単にできます。  
まずはコンポーネントのクラス（Message.php）を修正します。

<p class="tmp list"><span>リスト5-14</span>Message.php</p>
```
class Message extends Component
{
  private $id;
  private $data;
  private $msg;
  
  public function __construct($id = 1)
  {
    $this->msg = 'ランダムなPOSTデータを表示します。';
    $this->id = $id;
    $response = Http::get('https://jsonplaceholder.typicode.com/posts/' . $this->id);
    $this->data = $response->json();
  }

  public function render(): View|Closure|string
  {
    return view('components.message',[
      'id' => $this->id,
      'data' => $this->data,
      'msg' => $this->msg
    ]);
  }

}
```

コンストラクタに $id 引数を追加し、その値で指定IDのデータを取得するようにしました。表示処理は同じため、テンプレート側の修正は不要です。

### パラメーターの値を渡す

では、コンポーネントを利用しているHelloController側を修正しましょう。クラスのindexメソッドを以下のように修正してください。

<p class="tmp list"><span>リスト5-15</span>HelloController.php</p>
```
public function index(Request $request)
{
  $id = $request->id;
  return view('hello.index', ['id'=> $id]);
}
```

request->id を取得してテンプレートに渡し、その値をコンポーネントへ渡すようにします。  
そのために hello/index.blade.php の @section('content') を修正します。

<p class="tmp list"><span>リスト5-16</span>hello/index.blade.php</p>
```
@section('content')
  <h2>コンポーネント</h2>
  <x-package-message id={{$id}} />
  <p>※上がコンポーネントの表示です。</p>
@endsection
```

`<x-package-message/>` に id={{$id}} 属性を追加し、その値がコンポーネントのコンストラクタに渡されます。属性は必要に応じて複数設定できます。

修正したら、/hello?id=番号というようにクエリーパラメーターを指定してアクセスしてみましょう。idに指定したデータがコンポーネントに表示されるのがわかるでしょう。
![](upload/id20でアクセス.png){.photo-border}


## コンポーネント内コンテンツとスロット

今回のコンポーネントは、`<x-package-message/>`というようにして1つのタグだけで表 示を組み込んでいました。しかしHTMLの要素には、例えば`<p>`や`<div>`のように、開始 タグと終了タグの間にコンテンツを用意するものもあります。

こうした「内部にコンテンツを 持った部品」というのは、コンポーネントでは作れないのでしょうか。   
これには「スロット」という概念を理解する必要があります。コンポーネントでも、内部に コンテンツをもたせることは可能です。

例えば、こんな具合ですね。 
```
<x-コンポーネント> ·コンテンツ …… </x-コンポーネント>
```
このような形でコンポーネントを使ったとき、開始タグと終了タグの間にあるコンテンツは 「スロット」と呼ばれるものとして扱われます。  
スロットは、コンポーネント内でコンテンツ を扱うためのものです。  
これは、{{$slot }}というようにしてコンポーネント内に値を追加す ることができます。   

<div markdown="1" class="line-box">
（まとめ）  
コンポーネントは `<x-〇〇>` と `</x-〇〇>` の間にコンテンツを持たせることができ、その部分は「スロット」と呼ばれます。  
スロットの内容はコンポーネント内で {{$slot}} として利用できます。
</div>

### テンプレートを修正する

例として、作成したMessageコンポーネント内にコンテンツを持てるように、message.blade.phpテンプレートを修正しましょう。

<p class="tmp list"><span>リスト5-17</span>message.blade.php</p>
```
<div style="border:solid 1px gray; padding:0px 10px; margin:10px 0px;">
  <p style="color:red;">Message component</p>
  <p style="font-size:12pt;">{{$msg}}</p>
  <hr/>
  <div style="margin:0px 100px; font-size:12pt; color:blue;">
    {{ $slot }}
  </div>
  <hr />
  <ul>
    <li>[id] {{$data['id']}}</li>
    <li>[title] {{$data['title']}}</li>
    <li>[content] {{$data['body']}}</li>
  </ul>
</div>
```

{{$slot}} はコンポーネント内部に渡されたコンテンツを表示するもので、そのまま出力できます。  

では次に index.blade.php を修正します。

<p class="tmp list"><span>リスト5-18</span>hello/index.blade.php</p>
```
@section('content')
  <h2>コンポーネント</h2>
  <x-package-message id={{$id}}>
    <p>※これはコンポーネント内に追加したコンテンツです。</p>
  </x-package-message>
  <p>※上がコンポーネントの表示です。</p>
@endsection
```

/hello?id=～ にアクセスすると、コンポーネント内の2本の横線の間に `<p>` の内容が {{$slot}} に表示されます。  
スロットには単純なテキストだけでなく、外部から渡した値も組み込めます。

![](upload/id12にアクセス.png){.photo-border}