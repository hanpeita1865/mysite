## Barra Lateral Exclusiva

Uma Barra Lateral exclusiva com tudo que você precisa para aumentar sua produtividade.

| Pasta Simples | Workspace com Múltiplas Pastas |
|---------------|------------|
| ![Barra Lateral](../images/printscreen-activity-bar.png) | ![Barra Lateral](../images/printscreen-activity-bar-multi-root.png) |
