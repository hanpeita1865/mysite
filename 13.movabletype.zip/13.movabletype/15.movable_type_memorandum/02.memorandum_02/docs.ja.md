---
title: MTタグ部分が空行になって出力される現象を解消する方法
taxonomy:
    category:
        - docs
---

Movable Type で出力するテンプレートから空行を削除したい

Movable Type でMTタグ部分が空行になって出力される現象を解消する方法。

以下のようなタグで、空行を削除したい場所を挟んであげればOK。

### サンプルコード
```
<mt:Unless name="compress" regex_replace="/^\s*\n/gm","">


</mt:Unless>
```


ここでは compress という変数名にしているが、これは存在しない変数名であれば何でもOK

