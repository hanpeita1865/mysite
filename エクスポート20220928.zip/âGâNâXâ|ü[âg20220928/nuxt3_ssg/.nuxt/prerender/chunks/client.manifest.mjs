const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.dcb7201e.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "virtual:nuxt:C:/Users/hirao/Desktop/test/nuxt3-ssg/.nuxt/error-component.mjs",
      "layouts/custom.vue",
      "layouts/default.vue",
      "layouts/sample.vue",
      "node_modules/nuxt/dist/app/entry.mjs-css"
    ],
    "css": []
  },
  "virtual:nuxt:C:/Users/hirao/Desktop/test/nuxt3-ssg/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.25d891c1.js",
    "src": "virtual:nuxt:C:/Users/hirao/Desktop/test/nuxt3-ssg/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "pages/fishdata/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.bad3f6d2.js",
    "src": "pages/fishdata/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_data.12335034.js"
    ]
  },
  "_data.12335034.js": {
    "resourceType": "script",
    "module": true,
    "file": "data.12335034.js"
  },
  "pages/fishdata/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b4623ccd.js",
    "src": "pages/fishdata/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_data.12335034.js"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.1078c68e.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/secondpage.vue": {
    "resourceType": "script",
    "module": true,
    "file": "secondpage.0d68a06e.js",
    "src": "pages/secondpage.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/custom.vue": {
    "resourceType": "script",
    "module": true,
    "file": "custom.92ad6bbd.js",
    "src": "layouts/custom.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Navbar.895672aa.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_Navbar.895672aa.js": {
    "resourceType": "script",
    "module": true,
    "file": "Navbar.895672aa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.94bdd675.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Navbar.895672aa.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/sample.vue": {
    "resourceType": "script",
    "module": true,
    "file": "sample.07cc422d.js",
    "src": "layouts/sample.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.777ff0b8.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-404.18ced855.css": {
    "file": "error-404.18ced855.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.281d0c5e.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-500.e60962de.css": {
    "file": "error-500.e60962de.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.18ced855.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.e60962de.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/nuxt/dist/app/entry.mjs-css": {
    "file": ""
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
