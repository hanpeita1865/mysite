*[page-title]:配列と配列を結合する（スプレッド構文、concatメソッド）

## スプレッド構文で結合する
スプレッド構文を使うと、配列の内容を展開することが可能です。  
この挙動を結合するために、使うことができます。

<iframe src="https://paiza.io/projects/e/BeTnFuZuidgu0dEYKrmYAA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## concatメソッドで結合する

Array オブジェクトの concat メソッドを使うと配列に対して別の配列を結合した新しい配列を取得することができます。書式は次の通りです。
<p class="tmp"><span>書式</span></p>
```
配列名.concat(配列)
配列名.concat(配列, 配列, ...)
配列名.concat(値, 値, ...)
```
配列の最後に引数に指定した配列を結合した新しい配列を返します。引数は省略可能で結合する配列または値を指定し、複数の配列を結合する場合はカンマ(,)のあとに続けて記載してください。


<iframe src="https://paiza.io/projects/e/qozMnSqKIbRMedJuwzJrlQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## concatメソッドを使った配列のコピー

concat メソッドの引数を省略した場合は元の配列を複製したものを戻り値として返します。  
次のサンプルをみてください。

複製された配列は元の配列は別の配列オブジェクトとなります。その為、複製した配列に変更を加えても元の配列には影響しません(逆も同じです)。

<iframe src="https://paiza.io/projects/e/qURQzEnGADXNm1uSgMf_iA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

ただし concata メソッドが複製するのは 1 次元の要素までです。元の配列の要素の値として配列が格納されていた場合、その要素が参照する配列は複製された配列の要素も同じ配列を参照します。



## 配列内の重複した要素を統合する

配列内に重複した要素がある場合、同じものをマージして1つにするやり方です。

### 値、文字列の重複をまとめる
new Set()を使うと、配列内に重複している値、数値などを簡単に重複を1つにまとめることがきます。

<iframe src="https://paiza.io/projects/e/05_TQFzS0d3VhpKugkkn_w?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

new Set()で生成したもの（ここでいうnumbersFiltered）を出力しようとすると Set オブジェクトになってしまっているので、配列として扱いたい場合はスプレッド演算子（…）で抜き出せます。


### オブジェクトの重複をまとめる
オブジェクトの重複は Set ではまとめられません。filter と findIndex を組み合わせて使うと良いみたいです。

例：data を重複フィルタリングする
```
const data = [ ...何かしらのオブジェクト ];
const dataFiltered = data.filter((element, index, self) => self.findIndex(
  (dataElement) => dataElement.id === element.id ) === index
);
```
解説は下記のサイトを見てください。　複雑でよくわからん。こっちはあまり使うことがないと思う。

<https://white-space.work/merge-the-duplicated-array-object-using-javascript/>

## 参考サイト

* [配列と配列を結合する](https://www.javadrive.jp/javascript/array/index11.html)
* [JavaScriptで配列を結合する方法3選！](https://codelikes.com/javascript-array-merge/)
* [Javascript で配列内の重複した要素を1つにまとめる](https://white-space.work/merge-the-duplicated-array-object-using-javascript/)
