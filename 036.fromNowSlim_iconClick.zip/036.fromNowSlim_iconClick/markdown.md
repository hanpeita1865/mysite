*[page-title]:メニューの▼アイコンをクリックでエラーの改修


下記のようなメニューで▼をクリックした場合、コンソールにエラーが出てしまう。

![](upload/メニュー開閉用サンプル.png){.photo-border}

![](upload/▼クリックでエラー.png "図　コンソール画面エラー"){.photo-border}


原因としては、▼をクリックした時に開閉イベントが実行された後、メニュー名変更のイベントも発生していました。
![](upload/▼クリックでエラーコード開閉.png  "図　メニュー開閉イベントコード"){.photo-border}
![](upload/▼クリックでエラーコードメニュー名変更.png "図　メニュー名変更イベントコード"){.photo-border}

![](upload/メニューHTMLコード.png "図　メニューHTMLコード"){.photo-border}

このメニュー名変更イベントへの伝播とリンクへの遷移をを停止させたら、エラーはなくなりました。
<p class="tmp list"><span>リスト</span>admin.js（修正前）</p>
```
//「▼」アイコンクリックでサブメニューを開閉
document.querySelectorAll('.icon-slide').forEach(elm => {
	elm.addEventListener('click', function (e) {
		e.target.closest('.box-item').classList.toggle('s-close');
	});
});
```

<p class="tmp list"><span>リスト</span>admin.js（修正後）</p>
```
//「▼」アイコンクリックでサブメニューを開閉
document.querySelectorAll('.icon-slide').forEach(elm => {
	elm.addEventListener('click', function (e) {
		e.target.closest('.box-item').classList.toggle('s-close');
		e.stopPropagation(); 
		e.preventDefault();
	});
});
```

<pre><code class="hljs javascript"><span class="hljs-comment">//「▼」アイコンクリックでサブメニューを開閉</span>
<span class="hljs-built_in">document</span>.querySelectorAll(<span class="hljs-string">'.icon-slide'</span>).forEach(<span class="hljs-function"><span class="hljs-params">elm</span> =&gt;</span> {
    elm.addEventListener(<span class="hljs-string">'click'</span>, <span class="hljs-function"><span class="hljs-keyword">function</span> (<span class="hljs-params">e</span>) </span>{
        e.target.closest(<span class="hljs-string">'.box-item'</span>).classList.toggle(<span class="hljs-string">'s-close'</span>);
        <span class="marker-yellow">e.stopPropagation(); </span>
        <span class="marker-yellow">e.preventDefault();</span>
    });
});</code></pre>