// import SpecialCharacters from 'modules/ckeditor5-special-characters/src/specialcharacters';
// import SpecialCharactersEssentials from 'modules/ckeditor5-special-characters/src/specialcharactersessentials';

// function SpecialCharactersEmoji( editor ) {
//     editor.plugins.get( 'SpecialCharacters' ).addItems( 'Emoji', [
//         { title: 'smiley face', character: '😊' },
//         { title: 'rocket', character: '🚀' },
//         { title: 'wind blowing face', character: '🌬️' },
//         { title: 'floppy disk', character: '💾' },
//         { title: 'heart', character: '❤️' }
//     ], { label: 'Emoticons' } );
// }

//CKeditor用
CKEDITOR.ClassicEditor.create(document.getElementById("body"), {
    // plugins: [
    //     SpecialCharacters, SpecialCharactersEssentials, SpecialCharactersEmoji,
    //     // More plugins.
    //     // ...
    // ],
    fontColor: {
        colors: [
            {
                color: 'hsl(0, 10%, 0%)',
                label: 'Black'
            },
            {
                color: 'hsl(0, 0%, 30%)',
                label: 'Dim grey'
            },
            {
                color: 'hsl(0, 0%, 60%)',
                label: 'Grey'
            },
            {
                color: 'hsl(0, 0%, 90%)',
                label: 'Light grey'
            },
            {
                color: 'hsl(0, 0%, 100%)',
                label: 'White',
                hasBorder: true
            },
            {
                color: 'hsl(0, 85%, 70%)',
                label: 'Red'
            },
            {
                color: 'hsl(30, 75%, 70%)',
                label: 'Orange'
            },
            {
                color: 'hsl(45, 100%, 51%)',
                label: 'Yellow'
            },
            {
                color: 'hsl(131, 64%, 41%)',
                label: 'Green'
            },
            {
                color: 'hsl(150, 75%, 70%)',
                label: 'Aquamarine'
            },
            {
                color: 'hsl(180, 75%, 70%)',
                label: 'Turquoise'
            },
            {
                color: 'hsl(210, 75%, 70%)',
                label: 'Light blue'
            },
            {
                color: 'hsl(211, 100%, 50%)',
                label: 'Blue'
            },
            {
                color: 'hsl(264, 39%, 51%)',
                label: 'Purple'
            }
            // More colors.
            // ...
        ]
    },
    fontBackgroundColor: {
        //... // Font background color feature configuration.
        //const fontBackgroundColorConfig = {
            colors: [
                // {
                //     color: 'hsl(0, 0%, 0%)',
                //     label: 'Black'
                // },
                {
                    color: 'hsl(0, 10%, 30%)',
                    label: 'Dim grey'
                },
                {
                    color: 'hsl(0, 0%, 60%)',
                    label: 'Grey'
                },
                {
                    color: 'hsl(0, 0%, 90%)',
                    label: 'Light grey'
                },
                {
                    color: 'hsl(0, 0%, 100%)',
                    label: 'White',
                    hasBorder: true
                },
                {
                    color: 'hsl(0, 75%, 70%)',
                    label: 'Red'
                },
                {
                    color: 'hsl(30, 75%, 70%)',
                    label: 'Orange'
                },
                {
                    color: 'hsl(60, 92%, 59%)',
                    label: 'Yellow'
                },
                {
                    color: 'hsl(90, 100%, 68%)',
                    label: 'Light green'
                },
                {
                    color: 'hsl(120, 75%, 70%)',
                    label: 'Green'
                },
                {
                    color: 'hsl(150, 75%, 70%)',
                    label: 'Aquamarine'
                },
                {
                    color: 'hsl(180, 75%, 70%)',
                    label: 'Turquoise'
                },
                {
                    color: 'hsl(210, 75%, 70%)',
                    label: 'Light blue'
                },
                {
                    color: 'hsl(240, 100%, 82%)',
                    label: 'Blue'
                },
                {
                    color: 'hsl(270, 100%, 82%)',
                    label: 'Purple'
                }
            ]
        //}
        
    },
    highlight: {
        options: [
            {
                model: 'yellowMarker',
                class: 'marker-yellow',
                title: 'Yellow marker',
                color: 'var(--ck-highlight-marker-yellow)',
                type: 'marker'
            },
            {
                model: 'greenMarker',
                class: 'marker-green',
                title: 'Green marker',
                color: 'var(--ck-highlight-marker-green)',
                type: 'marker'
            },
            {
                model: 'pinkMarker',
                class: 'marker-pink',
                title: 'Pink marker',
                color: 'var(--ck-highlight-marker-pink)',
                type: 'marker'
            },
            {
                model: 'blueMarker',
                class: 'marker-blue',
                title: 'Blue marker',
                color: 'var(--ck-highlight-marker-blue)',
                type: 'marker'
            },
            {
                model: 'PurpleMarker',
                class: 'marker-purple',
                title: 'Purple marker',
                color: 'var(--ck-highlight-marker-purple)',
                type: 'marker'
            },
            {
                model: 'GrayMarker',
                class: 'marker-gray',
                title: 'Gray marker',
                color: 'var(--ck-highlight-marker-gray)',
                type: 'marker'
            },
        ]
    },
    image: {
        resizeUnit: "%",
        resizeOptions: [ 
            {
                name: 'resizeImage:original',
                value: null
            },
            {
                name: 'resizeImage:30',
                value: '30'
            },
            {
                name: 'resizeImage:35',
                value: '35'
            },
            {
                name: 'resizeImage:40',
                value: '40'
            },
            {
                name: 'resizeImage:45',
                value: '45'
            },
            {
                name: 'resizeImage:50',
                value: '50'
            },
            {
                name: 'resizeImage:55',
                value: '55'
            },
            {
                name: 'resizeImage:60',
                value: '60'
            },
            {
                name: 'resizeImage:65',
                value: '65'
            },
            {
                name: 'resizeImage:70',
                value: '70'
            },
            {
                name: 'resizeImage:75',
                value: '75'
            },
            {
                name: 'resizeImage:80',
                value: '80'
            }, 
            {
                name: 'resizeImage:85',
                value: '85'
            },
            {
                name: 'resizeImage:90',
                value: '90'
            },  
            {
                name: 'resizeImage:95',
                value: '95'
            },  
        ]
    },
    toolbar: {
        items: [
            'undo', 'redo', '|',
            'heading', '|',
            'bold', 'strikethrough', 'underline', 'subscript', 'superscript', 'removeFormat','|',
            'fontSize', 'fontColor', 'fontBackgroundColor', 'highlight', '|',
            'alignment', '|',
            'bulletedList', 'numberedList', '|',
            'outdent', 'indent', '|',
            'findAndReplace', 'selectAll', '|',
            'link', /*'insertImage',*/ 'blockQuote', 'insertTable', 'mediaEmbed', '|',
            'specialCharacters', 'horizontalLine', '|',
            'sourceEditing', '|',
        ],
        shouldNotGroupWhenFull: true
    },
    // Changing the language of the interface requires loading the language file using the <script> tag.
    // language: 'es',
    list: {
        properties: {
            styles: true,
            startIndex: true,
            reversed: true
        }
    },
    // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
    heading: {
        options: [
            { model: 'paragraph', title: 'paragraph', class: 'ck-heading_paragraph' },

            // { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
            // { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
            // { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
            // { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' },
            // { model: 'heading5', view: 'h5', title: 'Heading 5', class: 'ck-heading_heading5' },
            // { model: 'heading6', view: 'h6', title: 'Heading 6', class: 'ck-heading_heading6' },
            // {
            //     model: 'paragraph',
            //     view: { 
            //         name: 'p',
            //         classes: ''
            //     },
            //     title: 'pタグ',
            //     class: 'ck-heading_paragraph'
            // },
            {
                model: 'heading2',
                view: {
                    name: 'h2',
                    classes: 'heading2'
                },
                title: '見出しH2',
                class: 'ck-heading_heading2'
            },
            {
                model: 'heading3-1',
                view: {
                    name: 'h3',
                    classes: 'heading3'
                },
                title: '見出しH3',
                class: 'ck-heading_heading3'
            },
            {
                model: 'heading4-1',
                view: {
                    name: 'h4',
                    classes: 'heading4'
                },
                title: '見出しH4',
                class: 'ck-heading_heading4'
            },
            {
                model: 'heading5-1',
                view: {
                    name: 'h5',
                    classes: 'heading5'
                },
                title: '見出しH5',
                class: 'ck-heading_heading5'
            },
            {
                model: 'heading6-1',
                view: {
                    name: 'h6',
                    classes: 'heading6'
                },
                title: '見出しH6',
                class: 'ck-heading_heading6'
            },
            // {
            //     model: 'picture-grid',
            //     view: {
            //         name: 'paragraph',
            //         classes: 'picture-grid'
            //     },
            //     title: '画像横並び(picture-grid)',
            //     class: 'picture-grid'
            // }
        ]
    },
    // https://ckeditor.com/docs/ckeditor5/latest/features/editor-placeholder.html#using-the-editor-configuration
    //placeholder: 'Welcome to CKEditor 5!',
    placeholder: '入力してください。',

    // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-size-feature
    fontSize: {
        options: [12, 14, 'default', 18, 20, 22, 24],
        supportAllValues: true
    },
    // Be careful with the setting below. It instructs CKEditor to accept ALL HTML markup.
    // https://ckeditor.com/docs/ckeditor5/latest/features/general-html-support.html#enabling-all-html-features
    htmlSupport: {
        allow: [
            {
                name: /.*/,
                attributes: true,
                classes: true,
                styles: true
            }
        ]
    },
    // Be careful with enabling previews
    // https://ckeditor.com/docs/ckeditor5/latest/features/html-embed.html#content-previews
    // htmlEmbed: {
    //     showPreviews: true
    // },
    // https://ckeditor.com/docs/ckeditor5/latest/features/link.html#custom-link-attributes-decorators
    // link: {
    //     decorators: {
    //         addTargetToExternalLinks: true,
    //         defaultProtocol: 'https://',
    //         toggleDownloadable: {
    //             mode: 'manual',
    //             label: 'Downloadable',
    //             attributes: {
    //                 download: 'file'
    //             }
    //         }
    //     }
    // },
    link: {
        addTargetToExternalLinks: true,

        // decorators: {
        //     detectDownloadable: {
        //         mode: 'automatic',
        //         callback: url => url.endsWith('.txt'),
        //         attributes: {
        //             download: 'file.txt'
        //         }
        //     }
        // }
    },
    // https://ckeditor.com/docs/ckeditor5/latest/features/mentions.html#configuration
    mention: {
        feeds: [
            {
                marker: '@',
                feed: [
                    '@apple', '@bears', '@brownie', '@cake', '@cake', '@candy', '@canes', '@chocolate', '@cookie', '@cotton', '@cream',
                    '@cupcake', '@danish', '@donut', '@dragée', '@fruitcake', '@gingerbread', '@gummi', '@ice', '@jelly-o',
                    '@liquorice', '@macaroon', '@marzipan', '@oat', '@pie', '@plum', '@pudding', '@sesame', '@snaps', '@soufflé',
                    '@sugar', '@sweet', '@topping', '@wafer'
                ],
                minimumCharacters: 1
            }
        ]
    },
    // The "super-build" contains more premium features that require additional configuration, disable them below.
    // Do not turn them on unless you read the documentation and know how to configure them and setup the editor.
    removePlugins: [
        // These two are commercial, but you can try them out without registering to a trial.
        // 'ExportPdf',
        // 'ExportWord',
        'CKBox',
        'CKFinder',
        'EasyImage',
        // This sample uses the Base64UploadAdapter to handle image uploads as it requires no configuration.
        // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/base64-upload-adapter.html
        // Storing images as Base64 is usually a very bad idea.
        // Replace it on production website with other solutions:
        // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/image-upload.html
        // 'Base64UploadAdapter',
        'RealTimeCollaborativeComments',
        'RealTimeCollaborativeTrackChanges',
        'RealTimeCollaborativeRevisionHistory',
        'PresenceList',
        'Comments',
        'TrackChanges',
        'TrackChangesData',
        'RevisionHistory',
        'Pagination',
        'WProofreader',
        // Careful, with the Mathtype plugin CKEditor will not load when loading this sample
        // from a local file system (file://) - load this site via HTTP server if you enable MathType
        'MathType'
    ]
})
    .then(newEditor => {
        editor = newEditor;
        let editorData = editor.getData();
        editorData = editorData.replace('<p>{{{</p>', '').replace('<p>}}}</p>', '').replace('<p>{{{}}}</p>', '');
        editorData = editorData.trim();
        editor.setData(editorData);

        // //ボタンをクリックでリンクを挿入
        // document.getElementById('insert-test').addEventListener('click', function () {
        //     editor.execute( 'link', 'http://example.com' );
        // }, false);

        //ボタンをクリックでリンクを挿入（テキスト名も記入）
        // document.getElementById('insert-test').addEventListener('click', function () {
        //     editor.model.change( writer => {
        //         const insertPosition = editor.model.document.selection.getFirstPosition();
            
        //         writer.insertText( 'CKEditor 5 rocks!', { linkHref: 'https://ckeditor.com/' }, insertPosition );
        //     } );
        // }, false);
        

        // クリックやエンターを押したり、入力すると実行される。
        // editor.model.document.on( 'change', (e) => {
        //     console.log('実行', e.target)
        // } );

        // データの変更のみ
        // editor.model.document.on( 'change:data', () => {
        // } );

        // クリックした位置に「foo」が挿入される
        // editor.model.document.on( 'change', () => {
        // 	editor.model.change( writer => {
        // 		writer.insertText( 'foo', editor.model.document.selection.getFirstPosition() );
        // 	} );
        // } );

        // クリックした位置に「foo」が挿入される
        // editor.model.document.on( 'change', () => {
        // 	editor.model.change( writer => {
        // 		writer.insertText( 'foo', editor.model.document.selection.getFirstPosition() );
        // 	} );
        // } );

        //ボタンをクリックでテキストを挿入
        // document.getElementById('insert').addEventListener('click', function () {
        // 	let imgCode = 'テキスト';
        // 	editor.model.change(writer => {
        // 		writer.insertText(imgCode, editor.model.document.selection.getFirstPosition());
        // 	});
        // }, false);

        //ボタンをクリックでリンクを挿入
        // document.getElementById('insert').addEventListener('click', function () {
        // 	let imgCode = 'http://localhost:9840/sugu_cms/sugu_webdir/1/sample.txt';
        // 	editor.model.change(writer => {
        // 		writer.insertText(imgCode, editor.model.document.selection.getFirstPosition());
        // 		//writer.setAttribute( imgCode, href, linkRange );
        // 	});
        // }, false);

        //ボタンをクリックで画像を挿入
        // document.getElementById('insert').addEventListener('click', function () {
        // 	editor.execute( 'insertImage', { source: 'http://localhost:9840/sugu_cms/sugu_webdir/1/s_0-09.png' } );
        // }, false);

        //ボタンをクリックで複数の画像を挿入
        // document.getElementById('insert-test').addEventListener('click', function () {

        //     editor.execute( 'insertImage', {
        //         source:  [
        //             'https://fastly.picsum.photos/id/279/300/300.jpg?hmac=eTOokFmneKtouFY2d6WU7cCg11xbDhUL7OjzrnToz9Q',
        //             'https://fastly.picsum.photos/id/279/300/300.jpg?hmac=eTOokFmneKtouFY2d6WU7cCg11xbDhUL7OjzrnToz9Q',
        //             'https://fastly.picsum.photos/id/279/300/300.jpg?hmac=eTOokFmneKtouFY2d6WU7cCg11xbDhUL7OjzrnToz9Q'
        //         ]
        //     } );

        //     //const htmlDP = new HtmlDataProcessor( viewDocument );

        //     //テスト
        //     editor.model.change( writer => {
        //         const p1 = writer.createElement( 'paragraph' );
        //         const docFrag = writer.createDocumentFragment();
        //         writer.append( p1, docFrag );//docFragにpタグを挿入
        //         writer.insertText( 'abc', p1);//<p>abc</p>
        //         editor.model.insertContent( docFrag );
        //     } );
        //     //テストここまで
        //  }, false);



        //ボタンをクリックで挿入（insertContent）
        // const docFrag = editor.model.change( writer => {
        //     const p1 = writer.createElement( 'paragraph' );
        //     const p2 = writer.createElement( 'paragraph' );
        //     const blockQuote = writer.createElement( 'blockQuote' );
        //     const div = writer.createElement( 'div' );

        //     console.log(blockQuote, div)

        //     const docFrag = writer.createDocumentFragment();//新しい空の DocumentFragment を作成

        //     // let p = document.createElement("p")
        //     //div.append("Some text", p)

        //     writer.append( p1, docFrag );//docFragにpタグを挿入
        //     writer.append( blockQuote, docFrag );//docFragにblockquoteを挿入
        //     //writer.append( div, docFrag );//docFragにdivを挿入 → divの名前ではだめ
        //     // writer.append( newDiv, docFrag );
        //     //writer.append( p2, blockQuote );//<blockquote><p></p></blockquote>
        //     // writer.append( p2, newDiv );//
        //     // writer.insertText( 'foo', p1 );
        //     writer.insertText( 'bar', blockQuote );
        //     writer.insertText( 'abc', p1);//<p>abc</p>


        //     return docFrag;
        // } );
        

        // document.getElementById('insert-test').addEventListener('click', function () {
        //     editor.model.insertContent( docFrag );
        // });

        
        //ボタンをクリックでHTML?を挿入???
        // const htmlDP = new HtmlDataProcessor( viewDocument );
        // const viewFragment = htmlDP.toView( htmlString );
        // const modelFragment = editor.data.toModel( viewFragment );
        
        // document.getElementById('insert-test').addEventListener('click', function () {
        //     editor.model.insertContent( modelFragment );
        // });



        //記事に画像を挿入
        document.querySelectorAll('.insert-image').forEach(function (elm) {
            elm.addEventListener('click', function (e) {
                let href = e.target.closest('.sugu-control-group').querySelector('.current_image').getAttribute('href');
                editor.execute('insertImage', { source: href });
                alert('画像を本文内に挿入しました。')
            });
        });

        const regexp = new RegExp(/.jpg$|.jpeg$|.jpe$|.jfif$|.png$|.gif$|.svgx$|webp$/i);

        //記事に画像を挿入（添付用コントロール）
        document.querySelectorAll('.insert-tenpu').forEach(function (elm) {

            let id = elm.getAttribute('data-id');//current_file_数値
            let href = document.getElementById(id).getAttribute('href');
            let fileTextId = id.replace('current_file_', 'current_file_text,');//ファイル名欄
            let fileLinkId = id.replace('current_file_', 'current_file_link,');//ファイルリンク欄
            let fileCurrent = id.replace('current_file_', 'file_current_');//親ボックス

            //画像以外か判定
            if (regexp.test(href)) {
                //画像の場合、「挿入ボタン」を表示、ファイルリンクを非表示
                let filename = document.getElementById(fileTextId).value;
                elm.classList.add('d-block');
                document.getElementById(fileTextId).classList.add('d-none');
                document.getElementById(fileTextId).previousElementSibling.classList.add('d-none');
                document.getElementById(fileLinkId).classList.add('d-none');
                document.getElementById(fileLinkId).previousElementSibling.classList.add('d-none');

                document.getElementById(fileCurrent).querySelector('.tenpu-delete').insertAdjacentHTML('beforebegin','<span>（'+filename+'）</span>');

            } else {
                //ファイルリンクの場合、リンクを絶対パスで表示
                // let arr = absolutePath(href).split("/").slice(-1)[0] //スラッシュで分割して配列をつくる
                // let repHref = absolutePath(href).replace(arr, document.getElementById(fileTextId).value)//ファイルリンク値
                // document.getElementById(fileLinkId).value = repHref;
                document.getElementById(fileLinkId).value = href;//相対パス
            }

            //相対パスを絶対パスに変換
            function absolutePath(path) {
                let baseUrl = location.href;
                let url = new URL(path, baseUrl);
                return url.href;
            }

            //画像やリンクを記事に挿入
            elm.addEventListener('click', function (e) {
                id = e.target.getAttribute('data-id');

                if (regexp.test(href)) {
                    href = document.getElementById(id).getAttribute('href');
                    editor.execute('insertImage', { source: href });
                    alert('画像を本文内に挿入しました。')
                }else{
                    fileLinkId = id.replace('current_file_', 'current_file_link,');//ファイルリンク欄
                    fileTextId = id.replace('current_file_', 'current_file_text,');//ファイルテキスト欄　current_file_text,3
                    let fileLinkVal = document.getElementById(fileLinkId).value;
                    let fileTextVal = document.getElementById(fileTextId).value;

                    // console.log(fileTextVal)
                    // console.log(fileLinkVal)
                    // editor.execute( 'link', fileLinkVal );

                    editor.model.change( writer => {
                        const insertPosition = editor.model.document.selection.getFirstPosition();
                        writer.insertText( fileTextVal, { linkHref: fileLinkVal }, insertPosition );
                        alert('ファイルリンクを本文内に挿入しました。')
                    } );
                }
            });
        });

        //ツールバーに拡大アイコン設置→保留　別のイベントが発生してしまう。
        // document.querySelector('.ck-toolbar__items').insertAdjacentHTML('beforeend', '<button class="arrow-alt" title="全画面表示"></button>');

        // document.querySelector('.arrow-alt').addEventListener('click',function(e){
        //     console.log('拡大')
        //     stopImmediatePropagation;
        // });
    })
    // .catch(error => {
    //     consolelog('エラーです')
    // });




//確認ボタンクリックで送信前の処理
function set_submit(LIST) {

    let editorData = editor.getData();
    editorData = editorData.replace('<script>','').replace('</script>','');//追加
    document.getElementById('body1').value = '{{{' + editorData + '}}}';

    var ListTable = document.getElementById(LIST);
    var ListOfChildId = "";
    if (set_order == null) { return true; }
    if (!$('#' + LIST).children(".file-unit") || $('#' + LIST).children(".file-unit").length == 0) { return true; }

    $('#' + LIST).children(".file-unit").each(function () {
        ListOfChildId += $(this).attr("id") + "\n\n";
    });
    var MyForm = document.getElementById("mainform");
    MyForm.file_order.value = ListOfChildId;
    return true;
}

//送信キャンセルテスト
// document.getElementById('mainform').onsubmit = function () { return false }