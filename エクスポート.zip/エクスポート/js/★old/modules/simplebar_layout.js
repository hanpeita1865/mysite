export function barLayout() {

	//Simplebar設定
	const leftColumn = document.getElementById('menu-wrap');
	const simpleBar = new SimpleBar(leftColumn);


	function setLayout() {
		const headerHeight = $('#header-wrapper').outerHeight();
		const menuHeight = (window.innerHeight - headerHeight) + 'px';
		$('#menu-wrap').css('height', menuHeight);
	}

	setLayout();

	window.addEventListener('resize', setLayout);
}