*[page-title]:gulp_watch 監視してGulpタスクを自動実行する

参考サイト
: [ファイルの変更を監視してGulpタスクを自動実行する方法 (gulp.watch / gulp-watch)](https://weblabo.oscasierra.net/gulp-watch/)

完成品サンプルファイル格納場所
: <span class="green bold">～\pages\p__gulp_watch\sample\sample1(watch)</span>

## gulp_watch（監視）設定方法

Gulpの設定されているディレクトリに移動し、gulp-watch モジュールのインストールを実行します。

<p class="tmp cmd"><span>コマンド</span></p>
```
npm install --save-dev gulp-watch
```

gulpfile.jsを修正します。

<p class="tmp list"><span>リスト</span>gulpfile.js</p>
sassフォルダにあるscssファイルを変更すると、自動でタスクが実行され、cssフォルダに変換されたcssファイルが出力されます。
```
// Gulpを初期化する
const { src, dest, watch, series } = require('gulp');

// Gulpプラグインの読み込み
//const sass = require('gulp-sass');
const sass = require('gulp-sass')(require('sass'));

// Sassのコンパイル処理
const sass_compile = function () {
    return src('sass/style.scss')
        .pipe(sass({ outputStyle: 'expanded' }))
        .pipe(dest('css'))
}

// タスクを実行する
//exports.default = series(sass_compile);

//監視して自動実行
exports.default = () => {
	watch('sass/*.scss', sass_compile);
}
```

gulpコマンドを実行すると、監視状態になります。
![](upload/gulp_watch監視.png)

sassフォルダのscssファイルを修正して保存すると、タスクが自動実行され、コンパイルされます。
![](upload/gulp_watchコンパイル実行.png)

