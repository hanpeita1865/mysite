---
title: オブジェクトの検索方法
taxonomy:
    category:
        - docs
---

## リストの項目から検索

##### 配列データ
```
var lists = [
  {id:1, name:"ポチ", address:"広島県××××", tel:"082-941-××××"},
  {id:2, name:"タマ", address:"岡山県××××", tel:"086-803-××××"},
  {id:3, name:"モモ", address:"島根県××××", tel:"0852-55-××××"},
  {id:4, name:"ミケ", address:"鳥取県××××", tel:"0857-22-××××"},
  {id:5, name:"クロ", address:"山口県××××", tel:"083-922-××××"}
];
```

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
最初に上記のようなデータを準備します。検索ボックスに名前（ポチ、タマ…）を入力してボタンを押すと、指定した名前のデータが表示されます。（ひらがなは不可）
[sample(search)1](../../../../sample/jquery/sample(search)1/index.html?target=_blank)
</div>
<iframe width="100%" height="570" src="//jsfiddle.net/h3s0ez57/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

##### リスト（ul）
```
<ul id="list">
    <li><span>3</span><span>モモ</span><span>島根県××××</span><span>0852-55-××××</span></li>
    <li><span>4</span><span>ミケ</span><span>鳥取県××××</span><span>0857-22-××××</span></li>
    <li><span>1</span><span>ポチ</span><span>広島県××××</span><span>082-941-××××</span></li>
    <li><span>2</span><span>タマ</span><span>岡山県××××</span><span>086-803-××××</span></li>
    <li><span>5</span><span>クロ</span><span>山口県××××</span><span>083-922-××××</span></li>
</ul>
```

<div class="box-example" markdown="1">
### 例2 ### {.h-example}
まず上記のようなリストからデータを作成します。検索ボックスに名前（ポチ、タマ…）を入力してボタンを押すと、指定した名前のデータが表示されます。（ひらがなは不可）
[sample(search)2](../../../../sample/jquery/sample(search)2/index.html?target=_blank)
</div>
<iframe width="100%" height="570" src="//jsfiddle.net/bjqmgy2n/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

### あいまい検索

```
// 名前であいまい検索

searchWord = $('#search-box').val();//検索ボックスの値を取得
regexp = new RegExp(searchWord);//RegExpにセット
var result = regexp.test(lists[i].name);//名前に含まれるかの判定値(true、false)
```
<div class="box-example" markdown="1">
### 例3 ### {.h-example}
例2にあいまい検索を設定しています。
[sample(search)3](../../../../sample/jquery/sample(search)3/index.html?target=_blank)
</div>
<iframe width="100%" height="570" src="//jsfiddle.net/x7L6pf93/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<p class="tmp"><span>書式</span>文字列内の空白を全て削除</p>
```
変数.replace(/\s+/g, '')
```

<p class="tmp"><span>書式</span>文字列前後の空白を削除</p>
```
変数.trim()
```

<div class="box-example" markdown="1">
### 例4 ### {.h-example}
データを別のに変更して、同じようにあいまい検索しています。データの空白は無視して検索するようにしています。
[sample(search)4](../../../../sample/jquery/sample(search)4/index.html?target=_blank)
</div>
<iframe width="100%" height="570" src="//jsfiddle.net/gxpwyud5/1/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

### 検索と並べ替えの両方を使用
<div class="box-example" markdown="1">
### 例5 ### {.h-example}
データ数を増やしました。名前（ふりがな）と年月日で並べ替えと名前であいまい検索しています。
[sample(search)5](../../../../sample/jquery/sample(search)5/index.html?target=_blank)
</div>
<iframe width="100%" height="620" src="//jsfiddle.net/wfvpqgmL/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

### セレクトボックスで抽出

<div class="box-example" markdown="1">
### 例6 ### {.h-example}
例5の名前検索をセレクトボックスで抽出するように変更しました。セレクトボックスの名前は、リストの名前から作成しています。
[sample(search)6](../../../../sample/jquery/sample(search)6/index.html?target=_blank)
</div>
<iframe width="100%" height="620" src="//jsfiddle.net/p6njdLva/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>




