*[page-title]:ツールバー説明

![](upload/ツールバーまとめ.png "図　ツールバー一覧")


<div markdown="1" class="tb-toolbar">
| アイコン | 名称 | 機能 | 表示|
| -------- | -------- | -------- |---|
| ![](upload/undo.png)     | Undo      | 操作の取り消し     | |
| ![](upload/redo.png)    | Redo      | 操作のやり直し（Undoした内容を元に戻す）     | |
| ![](upload/heading.png)    | Headindg      | 見出しを選択する     | |
| ![](upload/bold.png)     | Bold      | 太字にする     | 　<strong>近畿能開大</strong>|
|![](upload/strikethrouth.png)     | Strikethrouth      | 打ち消し線をつける  |　<s>近畿能開大</s> |
| ![](upload/subscript.png)    | Subscript      | 下付き文字をつける    |水は、H<sub>2</sub>Oです。<br>酸素は、CO<sub>2</sub>です。 |
| ![](upload/superscript.png)    | Superscript      | 上付き文字をつける    | 10の8乗は10<sup>8</sup>です。|
| ![](upload/fontsize.png)     | Font Size     | 文字サイズを変更します ![](upload/文字サイズパネル5.png)    | <span style="font-size:12px;">近畿(12) </span><br><span style="font-size:14px;">近畿(14)</span><br>近畿(default) <br><span style="font-size:18px;">近畿(18)</span><br><span style="font-size:20px;">近畿(20)</span><br><span style="font-size:22px;">近畿(22) </span><br><span style="font-size:24px;">近畿(24)</span>|
| ![](upload/fontcolor.png)  | Font Color      | 文字の色を設定します<br> ![](upload/文字色パレット.png)       |<p><span style="color: hsl(0deg 97% 42%);">近畿</span>　<span style="color:hsl(45, 100%, 51%);">近畿</span>　<span style="color:hsl(131, 64%, 41%);">近畿</span><br><span style="color:hsl(211, 100%, 50%);">近畿</span>　<span style="color:hsl(264, 39%, 51%);">近畿</span></p> |
| ![](upload/fontbackcolor.png)    | Font Background Color     | 文字の背景色を設定します ![](upload/文字背景色パネル.png)    | <span style="background-color:hsl(90, 100%, 68%);">近畿能開大</span>　<span style="background-color:hsl(30, 75%, 70%);">近畿能開大</span>　<span style="background-color:hsl(60, 92%, 59%);">近畿能開大</span><br><span style="background-color:hsl(210, 75%, 70%);">近畿能開大</span>　<span style="background-color:hsl(0, 0%, 90%);">近畿能開大</span>　<span style="background-color:hsl(0, 10%, 30%);color:hsl(0, 0%, 100%);">近畿能開大</span>|
| ![](upload/highlight.png)    | Highlight      | 文字にマーカーを設定します ![](upload/文字マーカー.png) | <mark class="marker-yellow">近畿能開大</mark>　<mark class="marker-green">近畿能開大</mark>　<mark class="marker-pink">近畿能開大</mark><br><mark class="marker-blue">近畿能開大</mark>　<mark class="marker-purple">近畿能開大</mark>　<mark class="marker-gray">近畿能開大</mark>|
| ![](upload/text_align.png)    | Text alignment     | 文字の横位置を設定します![](upload/文字横位置.png)     | <span class="red">（左配置）</span><p>近畿能開大</p><span class="red">（右配置）</span><p style="text-align:right;">近畿能開大</p><span class="red">（中央配置）</span><p style="text-align:center;">近畿能開大</p><span class="red">（両端揃え）</span><p style="text-align:justify;"><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);font-size:16px;"><span style="-webkit-text-stroke-width:0px;display:inline !important;float:none;font-family:-apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, &quot;Liberation Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;font-style:normal;font-variant-caps:normal;font-variant-ligatures:normal;font-weight:400;letter-spacing:normal;orphans:2;text-align:left;text-decoration-color:initial;text-decoration-style:initial;text-decoration-thickness:initial;text-indent:0px;text-transform:none;white-space:normal;widows:2;word-spacing:0px;">Some placeholder text to demonstrate justified text alignment. Will you do the same for me? It's time to face the music I'm no longer your muse.&nbsp;</span></span></p>|
| ![](upload/list.png)     | Bulleted List    | 箇条書きリスト<kbd>&lt;ul&gt;</kbd>を追加します。<br>（インデントをつけると子要素になります） ![](upload/リスト.png)   |<ul style="list-style-type:disc;margin-bottom:2rem;"><li>就職支援について</li><li>就職先一覧</li><li>就職フェア開催のご案内</li></ul> <ul style="list-style-type:square;"><li>学校案内<ul><li>校長挨拶</li><li>大学校の目的と沿革</li><li>大学校の特色・特徴</li></ul></li><li>就職情報<ul><li>就職支援について</li><li>就職先一覧</li></ul></li></ul>|
| ![](upload/number_list.png)     | Numbered List    | 番号付きリスト<kbd>&lt;ol&gt;</kbd>を追加します。<br>（インデントをつけると子要素になります）![](upload/番号リスト.png)   | <ol style="list-style-type:decimal;"><li style="list-style-type:decimal;">就職支援について</li><li style="list-style-type:decimal;">就職先一覧</li><li style="list-style-type:decimal;">就職フェア開催のご案内</li></ol><ol style="list-style-type:upper-latin;"><li>学校案内<ol style="list-style-type:decimal-leading-zero;"><li>校長挨拶</li><li>大学校の目的と沿革</li><li>大学校の特色・特徴</li></ol></li><li>就職情報<ol style="list-style-type:decimal-leading-zero;"><li>就職支援について</li><li>就職先一覧</li></ol></li></ol>|
| ![](upload/indent取消.png)    | Decrease Indent     | インデントを削除します。     | |
| ![](upload/indent.png)    | Increase Indent      | インデントを設定します。<br>（40pxずつ左マージンが設定されます）   | <p style="margin-left:40px; margin-bottom:0;">就職支援について<br>就職先一覧<br>就職フェア開催のご案内</p>|
| ![](upload/findreplace.png)    | Find and replace      | 検索と置換を実行する    | |
|   ![](upload/allselect.png)  | Select all      | 全て選択する    | |
| ![](upload/link.png)     | Link      | リンクを挿入する     | |
| ![](upload/block_quart.png)     | Block quate     | Block quateを設置します    | |
| ![](upload/table.png)    | Insert table      | テーブルを挿入します ![](upload/テーブルパネル.png)    ||
| ![](upload/movie.png)   | insert madia      | 動画を挿入します ![](upload/動画パネル.png)    | |
| ![](upload/horizen_line.png)    | Horizonral line    | 水平線を追加します     | ダミーテキストです。ダミーテキストです。<hr>ダミーテキストです。ダミーテキストです。|
| ![](upload/source.png)    | Source      | HTMLコードを表示します    | ![](upload/HTML表示.png) |
</div>

