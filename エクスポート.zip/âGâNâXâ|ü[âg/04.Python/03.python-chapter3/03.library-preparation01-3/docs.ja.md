---
title: 03.プログラムの実行時間を計測する
taxonomy:
    category:
        - docs
visible: true
---

同じ用途のプログラムであっても、速いプログラム（実行時間が短い）と遅いプログラム（実行時間が長い）があります。<br>
プログラムの速さは、書き方によって変わります。いくつかの手法が選べるときには、それぞれの手法でプログラムを書いてみて、
実行時間を計測し、速い方を選ぶのが有効です。

<p class="tmp"><span>書式1</span>現在の時間を秒単位で返す</p>

	time.time()

<p class="inpre"><span>インタプリタ</span>timeモジュールをインポートしてから、time.time()を使って、現在の時間を調べる</p>
<pre>
>>> import time
>>> time.time()
1558671639.2633626<span class="comment">  # UNIX時間(コンピュータ上で時刻を表現する方式の一つ)</span>
</pre>


<p class="inpre"><span>インタプリタ</span>経過時間を求める</p>
<pre>
>>> old = time.time()
>>> time.time() - old
11.407870292663574<span class="comment">  # 約11.4秒</span>
</pre>


2種類のプログラムの実行時間を計測します。

<div class="box-example">
    <h3 class="h-example">例1</h3>
	time1.pyの実行時間を計測し、表示する。
</div>
<p class="editpre"><span>テキストエディタ</span>time1.py</p>

    import time
    old = time.time()
    s = ''
    for i in range(1000000):
        s += '根菜町１丁目２番地　人参\n'
    print(time.time()-old, '秒')


<p class="result">実行結果</p>
<pre>
61.84627079963684 秒<span class="comment">  # 実行時間</span>
</pre>

<div class="box-example">
    <h3 class="h-example">例2</h3>
	time2.pyの実行時間を計測し、表示する
</div>
<p class="editpre"><span>テキストエディタ</span>time2.py</p>

    import time
    old = time.time()
    s = '根菜町１丁目２番地　人参\n' * 1000000
    print(time.time()-old, '秒')

<p class="result">実行結果</p>
<pre>
0.031249046325683594 秒<span class="comment">  # 実行時間</span>
</pre>


<p class="att">※例1の文字列を連結する処理は、何度も繰り返すと意外に時間がかかります。<br>
文字列はメモリ上に格納しますが、文字列が長くなると、より大きなメモリ領域が必要になります。<br>
その場合は、元のメモリ領域を拡大するか、元のメモリ領域よりも大きな別のメモリ領域を確保したうえで元のメモリ領域から引っ越しするか、いずれの処理が必要になります。<br>
文字列の連結を何度も繰り返すと、この処理が何度も行われることになり、実行時間が長くなる原因になります。<br>
<br>
一方、演算子を使った例2のプログラムでは、最終的な文字列に必要なメモリ領域をあらかじめ確保してから処理を行うために、メモリ領域の拡大や文字列のコピーといった処理が行われず、高速に処理できていめためと思われます。</p>



