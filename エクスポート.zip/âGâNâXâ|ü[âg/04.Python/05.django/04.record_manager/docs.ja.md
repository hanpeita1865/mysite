---
title: レコードの取得の基本とManager
media_order: 'model_query.png,hello_data.png,hello_value.png,hello_values2.png,hello_list.png,first_last.png,query_set.png,crud1.png,create1.png,create2.png,create_data.png,create3.png,create4.png,modelForm1.png,modelForm2.png,edit1.png,edit2.png,delete2.png,delete3.png'
taxonomy:
    category:
        - docs
visible: true
---

## レコードを表示しよう

Djangoのアプリからデータベースを利用していきます。  
まず、「Fiendsの全レコードを表示する」ということをやってみます。

「hello」フォルダ内のviews.pyを下記のように修正します。


<p class="mb-05"><span class="tmp list">リスト3-9</span><span class="bold">views.pyの修正</span></p>

    from django.shortcuts import render
    from django.http import HttpResponse
    from .models import Friend

    def index(request):
        data = Friend.objects.all()
        params = {
                'title': 'Hello',
                'message': 'all friends.',
                'data': data,
            }
        return render(request, 'hello/index.html', params)


ここでは、Friendクラスの機能を使っています。Friendは、先に作成したモデルクラスです。  
モデルクラスには「objects」という属性が用意されています。このobjectsには「Manager」というクラスのインスタンスが設定されています。  
すべてのレコードを取り出すには、このobjectsにある「all」というメソッドを利用します。



## モデルの内容を表示する

allで取り出したFriendモデルのセットをテンプレートでテーブルにまとめて表示します。  
「templates」フォルダ内の「hello」フォルダ内にあるindex.htmlを開き、下記のように編集します。

<p class="mb-05"><span class="tmp list">リスト3-10</span><span class="bold">index.htmlの編集</span></p>

    {% load static %}
    <!doctype html>
    <html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>{{title}}</title>
        <link rel="stylesheet" type="text/css" 
            href="{% static 'hello/css/style.css' %}" />
    </head>
    <body>
        <h1>{{title}}</h1>
        <p>{{message|safe}}</p>
        <table>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>GENDER</th>
                <th>MAIL</th>
                <th>AGE</th>
                <th>BIRTHDAY</th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item.id}}</td>
                <td>{{item.name}}</td>
                <td>{% if item.gender == False %}male{% endif %}
                    {% if item.gender == True %}female{% endif %}</td>
                <td>{{item.mail}}</td>
                <td>{{item.age}}</td>
                <td>{{item.birthday}}</td>
            <tr>
        {% endfor %}
        </table>
    </body>
    </html>


ここでは、ビュー関数側から渡された変数dataから頭にオブジェクトを取り出してテーブルの表示を作っています。  
これには、「forタグ」というテンプレートタグを利用しています。  
このforタグを使った基本的な処理の流れを整理すると、こんな感じになります。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">forタグ</span></p>

    {% for item in data %}
      ・・・繰り返す表示・・・
    {% endfor %}

これで、変数dataから順にオブジェクトを取り出し、itemに代入する、ということを繰り返していきます。

<div class="gray-box" markdown="1">
「id」とは
: Djangoが自動的に追加する値です。データベースでは、テーブルのレコードにはすべて「プライマリキー」と呼ばれるものを用意します。
これは、すべてのレコードで異なる値を割り振られている特別な項目で、データベースでは、このプライマリキーという値を使って、一つ一つのレコードを識別します。
</div>



### ifタグで条件分岐

    {% if item.gender == False %}male{% endif %}
    {% if item.gender == True %}female{% endif %}

ifの後に用意した条件の式がTrueならば、そのあとにある部分を画面に表示します。Falseならば表示しません。  
ここでは、item.genderの値がFalseのときは「male」、Trueのときは「female」とテキスト表示するようにしています。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">ifタグ</span></p>

	{% if 条件 %}・・・表示内容・・・{% endif %}



### モデルの表示を完成させよう

これでビュー関数とテンプレートはできました。  
次は、urlpatternsです。  
「hello」フォルダ内のurls.pyを開き、urlpatterns変数の部分を修正します。


<p class="mb-05"><span class="tmp list">リスト3-11</span><span class="bold">urls.pyの編集</span></p>

    from django.urls import path
    from . import views

    urlpatterns = [
        path('', views.index, name='index'),
    ]


これで、/hello/にアクセスしたら、views.pyのindex関数が呼び出されるようになりました。

これでプログラムは完成ですが、テーブルの表示をするので、テーブル用のスタイルを用意します。  
「hello」フォルダ内の「statics」フォルダ内にある「hello」フォルダ内の「css」フォルダ内の中からstyle.cssを開いて、下記のクラスを追記します。


<p class="mb-05"><span class="tmp list">リスト3-12</span><span class="bold">style.cssにクラスを追記</span></p>

    table {
        margin:10px;
        font-size:14pt;
    }
    table tr th {
        background-color:#009;
        color:white;
        padding:2px 10px;
        border-width:2px;
    }
    table tr td {
        background-color:#eee;
        color:#666;
        padding:2px 10px;
        border-width:2px;
    }

追記したら、http://localhost:8000/hello/（または、http://localhost:8080/hello/）にアクセスします。  
Friendsテーブルにサンプルとして追加しておいたレコードの内容がテーブルにまとめて表示されます。


## 指定のIDのレコードだけ取り出す

もっとも基本的なものとして、「ID番号を指定してレコードを取り出す」ということを考えてみます。

これには、フォームを用意する必要があります。  
では、「hello」フォルダ内のforms.pyを開いて、中身を以下のように編集します。

<p class="mb-05"><span class="tmp list">リスト3-13</span><span class="bold">forms.pyを編集</span></p>

    from django import forms

    class HelloForm(forms.Form):
        id = forms.IntegerField(label='ID')


今回は、idというIntegerFieldを一つだけ用意しておきました。  
これにID番号を入力して送信すると、そのレコードが表示される、というようにしてみます。


### index.htmlを修正する

このHelloFormを組み込んでテンプレートを作ります。  
templateフォルダ内の「hello」フォルダ内にあるindex.htmlを修正します。

<p class="mb-05"><span class="tmp list">リスト3-14</span><span class="bold">index.htmlを修正</span></p>

    <body>
        <h1>{{title}}</h1>
        <p>{{message|safe}}</p>
        <table>
        <form action="{% url 'index' %}" method="post">
            {% csrf_token %}
            {{ form.as_table }}//フォームを表示
            <tr><td></td><td><input type="submit" value="click"></td></tr>
        </form>
        </table>
        <hr>
        <table>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>GENDER</th>
                <th>MAIL</th>
                <th>AGE</th>
                <th>BIRTHDAY</th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item.id}}</td>
                <td>{{item.name}}</td>
                <td>{% if item.gender == False %}male{% endif %}
                    {% if item.gender == True %}female{% endif %}</td>
                <td>{{item.mail}}</td>
                <td>{{item.age}}</td>
                <td>{{item.birthday}}</td>
            <tr>
        {% endfor %}
        </table>
    </body>

{ form.as_table }}で、フォームを表示させていますので、ビュー関数でformという変数にHeloFormを用意しておくようにします。


### ビュー関数を修正しよう

「hello」フォルダ内のviews.pyを開き、下記のように書き換えます。


<p class="mb-05"><span class="tmp list">リスト3-15</span><span class="bold">views.pyを修正</span></p>

    from django.shortcuts import render
    from django.http import HttpResponse
    from .models import Friend
    from .forms import HelloForm

    def index(request):
        params = {
                'title': 'Hello',
                'message': 'all friends.',
                'form':HelloForm(),
                'data': [],
            }
        if (request.method == 'POST'):
            num=request.POST['id']
            item = Friend.objects.get(id=num)
            params['data'] = [item]
            params['form'] = HelloForm(request.POST)
        else:
            params['data'] = Friend.objects.all()
        return render(request, 'hello/index.html', params)



では「hello」サイトにアクセスし、フィールドにID番号を入力して送信すると、そのレコードだけを表示するようになっています。

今回は、if (request.method == 'POST'):でPOST送信されたかどうかをチェックし、異なる処理を行うようにしてあります。  
POST送信された場合は、フォームから送られた値を元に、指定のIDのレコードをモデルインスタンスとして取り出しています。

    num=request.POST['id']
    item = Friend.objects.get(id=num)

request.POST['id']でフォームの値を取り出したら、Friend.objectsの「get」というメソッドをつけて実行しています。  
get(id=num)は、IDの値がnumのレコードを一つだけ取り出すということをやっています。

注意点として、このgetで取り出されるのは、モデルのインスタンス一つだけになっています。  
allのようにセットにはなっていません。  
ここでは、テンプレート側で「セットからインスタンスを取り出して表示する」というように処理をしているので、getで取り出したインスタンスは、

	params['data'] = [item]

このようにして、セットに入れてparams['data']に代入しています。  
こうすれば、項目が一つだけのセットしてちゃんとテンプレート側で処理してくれます。


## Managerクラスってなに?

ここまで、Friend.objectsのallやgetといったメソッドを使って、レコードをFriendsインスタンスとして取り出してきました。
このFriend.objectsというのは「Managerというクラスのインスタンスが入っている」と前にいいました。

このManagerというのは、いったい何なんでしょうか?


### Managerは「データベースクエリ」のクラス

このManagerクラスは、「データベースクエリ」を操作するための機能を提供するためのものです。

データベースクエリというのは、「データベースに対してさまざまな要求をするためのもの」です。

Managerクラスは、メソッドなどの内部から、このSQLのクエリを作成してデータベースに問い合わせをし、その結果（レコードなど）を受け取ります。  
つまりManagerクラスは、「Pythonのメソッドを、データベースクエリに翻訳して実行するもの」と考えるとよいでしょう。


![](model_query.png?classes=caption "図　モデルのobjectsには、Managerが設定されている。Managerは、メソッドをデータベースクエリに変換してデータベースに問い合わせる。")

## モデルのリストを調べてみる

「hello」フォルダ内のview.pyを開き、以下のように書き換えます。

<p class="mb-05"><span class="tmp list">リスト3-16</span><span class="bold">view.pyを修正</span></p>

    from django.shortcuts import render
    from django.http import HttpResponse
    from .models import Friend

    def index(request):
        data = Friend.objects.all()
        params = {
                'title': 'Hello',
                'data': data,
            }
        return render(request, 'hello/index.html', params)

単純にFriend.objects.allを呼び出してテンプレートに渡すだけにしてあります。  
テンプレート側では、これをそのまま表示させてみます。

「template」フォルダ内の「hello」フォルダ内にあるindex.htmlを開いて、<body>タグの部分を以下のように修正します。


<p class="mb-05"><span class="tmp list">リスト3-17</span><span class="bold">index.htmlを修正</span></p>
    
    <body>
        <h1>{{title}}</h1>
        <p>{{data}}</p>
        <table>
            <tr>
                <th>data</th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item}}</td>
            <tr>
        {% endfor %}
        </table>
    </body>

 まず、最初に{{data}}で変数dataをそのまま表示させています。  
その後の&lt;table&gt;では、dataから順にオブジェクトを取り出して{{item}}を表示しています。  
どちらも、具体的なレコードの値ではなく、取り出したオブジェクトをそのままテキストで表示させています。

allで得られるのは「QuerySet」

「hello」サイトにアクセスすると、下記のように&lt;QuerSet[……]&gt;といった表示がされるのがわかります。  
つまり、allで取り出されていたのは、QuerySetというクラスのインスタンスだったのです。  
    
 ![](hello_data.png)

<p class="mb-05"><span class="bold">生成されたbodyのコードの内容</span></p>
    
    <body>
        <h1>Hello</h1>
        <p>&lt;QuerySet [&lt;Friend: &lt;Friend:id=1, hirao(48)&gt;&gt;, &lt;Friend: &lt;Friend:id=2, tanaka(35)&gt;&gt;]&gt;</p>
         <table>
            <tr>
                <th>data</th>
            </tr>
            <tr>
                <td>&lt;Friend:id=1, hirao(48)&gt;</td>
            <tr>
            <tr>
                <td>&lt;Friend:id=2, tanaka(35)&gt;</td>
            <tr>
        </table>
    </body>

このQuerySetは、Setの派生クラスで、クエリ取得用にいろいろに機能拡張したセットです。
これを使って、データベースからレコード（実際にはモデルのインスタンスですが）を取り出していたんです。


## valuesメソッド

このallで得られるQuerySetには、いろいろなメソッドが用意されています。  
allで得られるのは、モデルのインスタンスのセットでした。

「レコードの値だけほしい」という場合は、「values」というメソッドを利用することができます。

「hello」フォルダを開いて、view.pyのindex関数を以下のように書き換えます。

<p class="mb-05"><span class="tmp list">リスト3-18</span><span class="bold">view.pyのindex関数を修正</span></p>

    def index(request):
        data = Friend.objects.all().values()
        params = {
                'title': 'Hello',
                'data': data,
            }
        return render(request, 'hello/index.html', params)

data = Friend.objects.all() を　data = Friend.objects.all().values()　に変更しています。
    
    

それから、「template」フォルダ内の「hello」フォルダ内にあるindex.htmlを開いて、<body>部分にある

	<p>{{data}}</p>

この行を探して、削除しておきます。もう、allで得られるのがQuerSetであることはわかったので、これはいらないです。  
「hello」サイトにアクセスすると、今度は、テーブルに表示される内容が少し変わっています。  
これは、「**辞書**」になります。  
Pythonオブジェクトで、一つ一つの値に名前（キー）をつけてまとめたものです。  
こんな具合に、valuesメソッドを使うと、モデルに保管されている値を辞書の形にして取り出すことができます。

<!--
<div class="dl-photo" markdown="1">
![](hello_value.png)
: 図　Friendの内容が辞書の形で表示される
</div>
-->
    
![](hello_value.png?classes=caption "図　Friendの内容が辞書の形で表示される")


## 特定の項目だけ取り出す

valueメソッドは、引数に項目名を書いておくと、その項目の値だけをとりだせます。
「hello」フォルダ内のviews.pyを開いて、index関数を以下のように書き換えます。


<p class="mb-05"><span class="tmp list">リスト3-19</span><span class="bold">view.pyのindex関数を修正</span></p>
    
    def index(request):
        data = Friend.objects.all().values('id', 'name')
        params = {
                'title': 'Hello',
                'data': data,
            }
        return render(request, 'hello/index.html', params)

    
![](hello_values2.png?classes=caption "idとnameの値のみ表示")
    
「hello」サイトにアクセスすると、idとnameの値だけが表示されます。  
取り出したレコードは辞書の形になってますが、idとname以外の値しかありません。

リスト3-19でvaluesの引数に、'id'と'name'が指定されてるように、valuesは引数に項目名を指定すると、その項目名だけを取り出します。


## リストとして取り出す

QuerySetには、取り出したモデルをリストとして取り出すメソッドもあります。  
これは「values list」というもので、使い方はvaluesと同じです。

「hello」フォルダ内のview.pyにあるindex関数を以下のように書き換えます。


<p class="mb-05"><span class="tmp list">リスト3-20</span><span class="bold">view.pyのindex関数を修正</span></p>
    
    def index(request):
        data = Friend.objects.all().values_list('id','name','age')
        params = {
                'title': 'Hello',
                'data': data,
            }
        return render(request, 'hello/index.html', params)
<!--
<div class="dl-photo" markdown="1">
![](hello_list.png)
: 図　リストを使って、id、name、ageの値を表示
</div>
-->
    
![](hello_list.png?classes=caption "図　リストを使って、id、name、ageの値を表示")
    
今回は、**values_list('id','name','age')** というようにしてレコードを取り出しています。  
表示される値を見ると、「リストとして返す」といいながら、実際に返ってくるのはタプルです。  
「辞書ではなくて、レコードの値だけをまとめたものを取り出す」という意味では、リストもタプルもそう大きな違いはないのでいでしょう。


## 最初と最後、レコード数

レコードの取得には、allとgetの他にも便利なものが用意されています。  
それは以下のようなものです。


| | | 
| -------- | -------- | 
|first	|allなどで得られたレコードの内、最初のものだけを返すメソッドです。|
|last	|やはり多数のレコードの中から、最後のものだけを返すメソッドです。|
|count	|これは、取得したレコード数を返すメソッドです。|

レコードの最初と最後を取得できると、例えば取り出したレコードについて「〇〇から××」という表示に使えます。
また、取り出したレコード数も必要となるシーンは結構多いいでしょう。
では、実際の利用例をあげてみましょう

「hello」フォルダ内のviews.pyを開き、index関数を以下のように修正します。


<p class="mb-05"><span class="tmp list">リスト3-21</span><span class="bold">view.pyのindex関数を修正</span></p>
    
    def index(request):
        num = Friend.objects.all().count()
        first = Friend.objects.all().first()
        last = Friend.objects.all().last()
        data = [num, first, last]
        params = {
                'title': 'Hello',
                'data': data,
            }
        return render(request, 'hello/index.html', params)


 ![](first_last.png?classes=caption "図　レコード数、最初と最後のレコードを表示")   


アクセスすると、レコード数、最初のレコード（モデル）、最後のレコード（モデル）をテーブルにまとめて表示しています。


## QuerySetの表示をカスタマイズ

allでは、QuerySetというクラスのインスタンスとしてレコードの値が取り出されます。  
このQuerySetクラスをいろいろと操作すれば、取り出したレコードデータの使いこなしもしやすくなります。  
QuerySetのように、Djangoに用意されているクラスも、私たちが後から機能を追加したり変更できるのです。

「hello」フォルダ内のviews.pyを開き、以下のように修正してください。

<p class="mb-05"><span class="tmp list">リスト3-22</span><span class="bold">view.pyのindex関数を修正</span></p>
    
    from django.shortcuts import render
    from django.http import HttpResponse
    from .models import Friend
    from django.db.models import QuerySet

    def __new_str__(self):
        result = ''
        for item in self:
            result += '<tr>'
            for k in item:
                result += '<td>' + str(k) + '=' + str(item[k]) + '</td>'
            result += '</tr>'
        return result

    QuerySet.__str__ = __new_str__

    def index(request):
        data = Friend.objects.all().values('id', 'name', 'age')
        params = {
                'title': 'Hello',
                'data': data,
            }
        return render(request, 'hello/index.html', params)

これは、QuerySetをテキストにキャストした時の表示を変更する例です。  
<p>クラスには、テキストの値として取り出されるときによびだされる__str__というメソッドが用意されていましたが、このメソッドを変更すれば、QuerySetをテキストにキャストした時の内容を変更することができます。</p>

<p>ここでは、＿new_str＿という関数を定義しておき、これをQuerySetの＿str＿に設定しています。</p>

	QuerySet.__str__ = __new_str__

<p>こんな具合に、関数名を__str__に代入すれば、もうこれでテキストにキャストするとき新たに設定したメソッドが実行されるようになります。</p>


### QuerySetを表示しよう

では、実際にQuerySetを表示してみましょう。  
「template」フォルダ内の「hello」フォルダ内にあるindex.htmlを開き、&lt;body&gt;タグの部分を下記のように修正してください。

<p class="mb-05"><span class="tmp list">リスト3-23</span><span class="bold">index.htmlを修正</span></p>
    
    <body>
        <h1>{{title}}</h1>
        <table>
            {{data|safe}}
        </table>
    </body>


これでアクセスをすると、取り出したレコードがテーブルにまとめて表示されます。
    
![](query_set.png?classes=caption "図　アクセスすると、レコードのid, name, ageがそれぞれ区切られて表示される")

実際の表示は、 **{{data|safe}}**としているだけです。  
これだけで、レコードの値をテーブルにまとめて表示できるようになります。  
このように、メソッドの書き換えができるとなかなか便利にです。


    
## CRUDを作ろう

### CRUDとは

データベースを利用するための基本機能は、一般に「CRUD」という四文字で表されます。

|||
|--|--|
|Create（レコードの新規作成）|	新たにレコードを作成しテーブルに保存します。|
|Read（レコードの取得）|	テーブルからレコードを取得します。|
|Update（レコードの更新）|	既にテーブルにあるレコードの内容を変更し保存します。|
|Delete（レコードの削除）|	既にテーブルにあるレコードを削除します。|


この4つの機能が実装できれば、Djangoのスクリプトからデータベースに保存されているレコードを操作できるようになります。
これらは、「必要最低限の機能」であって、実際にはそれ以外のもの（例えば、複雑な検索処理など）が必要になります。

![](crud1.png?classes=caption "図　データベースアクセスの基本は、CRUDの4つの機能です。")

## Createを作ろう

「Create（レコードの新規作成）」から説明します。

レコードの作成は、「モデルのインスタンスを用意し、保存のメソッドを実行する」というやり方をします。保存のメソッドは、「save」になります。  
例えば、今回のFriendモデルならば、以下のようになります。

    friend = Friend()
    ……friendに値を設定……
    friend.save()


### HelloFormの作成

まずは、保存用のフォームからです。  
「hello」フォルダ内のforms.pyに、HelloFormというクラスを作成しましたが、あれを修正して使います。  
forms.pyの内容を以下のように書き換えて下さい。

<p class="mb-05"><span class="tmp list">リスト3-24</span><span class="bold">forms.pyを修正</span></p>
    
    from django import forms

    class HelloForm(forms.Form):
        name = forms.CharField(label='Name')
        mail = forms.EmailField(label='Email')
        gender = forms.BooleanField(label='Gender',required=False)
        age = forms.IntegerField(label='Age')
        birthday = forms.DateField(label='Birth')



見てわかるように、forms.Formを継承したHelloFormを再利用しています。  
フォームの項目として、**name、mail、gender、age、birthday** の5つを用意してあります。    
  
### create.htmlの作成

続いて、テンプレートです。  
CRUDは、今までのようにindex.htmlを書き換えるのでなく、それぞれファイルを用意してすべて動くようにした方が動作の確認もしやすいので、新たにテンプレートファイルを用意することにします。

「template」フォルダ内の「hello」フォルダの中に、「create.html」という名前でファイルを用意します。  
そして、以下のように記述をしてください。

<p class="mb-05"><span class="tmp list">リスト3-25</span><span class="bold">create.htmlを用意する</span></p>
    
    {% load static %}
    <!doctype html>
    <html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>{{title}}</title>
        <link rel="stylesheet" type="text/css" 
            href="{% static 'hello/css/style.css' %}" />
    </head>
    <body>
        <h1>{{title}}</h1>
        <table>
            <form action="{% url 'create' %}" method="post">
            {% csrf_token %}
            {{ form.as_table }}
            <tr><td></td><td><input type="submit" value="click"></td></tr>
            </form>
        </table>
    </body>
    </html>

![](create1.png?classes=caption "図「templates」内の「hello」フォルダ内に、create.htmlを作成する。")

    
    
### index.htmlも修正しよう

ついでに、index.htmlも修正して、保存されているレコードを表示し確認できるようにしておきましょう。
「template」フォルダ内の「hello」フォルダ内にあるindex.htmlを開き、&lt;body&gt;の部分を以下のように修正して下さい。

<p class="mb-05"><span class="tmp list">リスト3-26</span><span class="bold">index.htmlを修正する</span></p>
    
    <body>
        <h1>{{title}}</h1>
        <table>
            <tr>
                <th>data</th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item}}</td>
            <tr>
        {% endfor %}
        </table>
    </body>


![](create2.png?classes=caption "図　index.htmlを修正し、レコードを一覧表示するようにしておく")

    

### vuew.pyを修正しよう

「hello」フォルダ内のviews.pyを開き、以下のように書き換えて下さい。

<p class="mb-05"><span class="tmp list">リスト3-27</span><span class="bold">views.pyを修正する</span></p>
    
    from django.shortcuts import render
    from django.http import HttpResponse
    from django.shortcuts import redirect
    from .models import Friend
    from .forms import HelloForm

    def index(request):
        data = Friend.objects.all()
        params = {
                'title': 'Hello',
                'data': data,
            }
        return render(request, 'hello/index.html', params)

    # create model
    def create(request):
        params = {
            'title': 'Hello',
            'form': HelloForm(),
        }
        if (request.method == 'POST'):
            name = request.POST['name']
            mail = request.POST['mail']
            gender = 'gender' in request.POST
            age = int(request.POST['age'])
            birth = request.POST['birthday']
            friend = Friend(name=name,mail=mail,gender=gender,\
                    age=age,birthday=birth)
            friend.save()
            return redirect(to='/hello')
        return render(request, 'hello/create.html', params)


### レコード保存の流れをチェック

今回のスクリプトには、index関数とcreate関数が用意されています。  
indexx関数はわかると思うので、createx関数の方を見ていきます。  
ここでは、params変数を用意した後、if (request.method == 'POST'):でPOST送信されたかチェックしています。  
そしてPOST送信の場合は、レコード保存の処理を行っています。  
まず、送信された値を一通り変数に取り出していきます。


    name = request.POST['name']
    mail = request.POST['mail']
    gender = 'gender' in request.POST
    age = int(request.POST['age'])
    birth = request.POST['birthday']



これらの値をもとに、Friendインスタンスを作成します。


    friend = Friend(name=name,mail=mail,gender=gender,\
            age=age,birthday=birth)


インスタンスを作成後、一つ一つの値を設定してくのは面倒なので、インスタンス作成時に必要な値を引数で渡すようにしました。  
モデルクラスはインスタンスを作成する際、このように用意されている項目に代入する値を引数で指定することができます。  
後は、インスタンスを保存するだけです。


	friend.save()

これで、送信されたフォームの情報を元にインスタンスが作成され、テーブルにレコードとして保存されました。


### リダイレクトについて

POST送信された際には、モデルを作成し保存した後、/helloにリダイレクトしています。  
リダイレクトは、「redirect」という関数で行えます。


	return redirect(to='/hello')


普通は、returnでrender関数の戻り値を返していますが、その代わりにredirect関数の戻り値を返しています。  
これで、引数のtoに指定したアドレスにリダイレクトされます。  
このredirect関数を使うには、from django.shortcuts import redirectというようにimport文を用意することを忘れないでください。



### urls.pyを修正する

後は、urlpatternsを修正するだけです。  
「hello」フォルダ内のurls.pyを開き、urlpatterns変数の値を以下のように修正しましょう。


<p class="mb-05"><span class="tmp list">リスト3-28</span><span class="bold">urls.pyのurlpatterns変数の値を修正する</span></p>
    
    urlpatterns = [
        path('', views.index, name='index'),
        path('create', views.create, name='create'),
    ]



「/hello/create」にアクセスすると、Friendの項目がフォームとして表示されます。  
それらを入力し、送信するとレコードが追加されます。

![](create3.png?classes=caption "図　フォームが表示され、記入し送信すると")
    <p class="text-center">↓</p>
   
![](create4.png?classes=caption "図　レコードに保存される")    
    
    

## ModelFormを使う

Djangoにはモデルのためのフォームを作成する「**ModelForm**」というクラスが用意されています。  
これを利用することで、もっともスムーズにレコードの保存を行うことができます。


### forms.pyにクラスを追加

では、ModelFormというフォームクラスを利用してみましょう。  
「hello」フォルダ内のforms.pyを開き、以下のように修正します。



<p class="mb-05"><span class="tmp list">リスト3-29</span><span class="bold">forms.pyを修正する</span></p>
    from django import forms
    from.models import Friend

    class FriendForm(forms.ModelForm):
        class Meta:
            model = Friend
            fields = ['name','mail','gender','age','birthday']

    
今回のFriendFormクラスは、ModelFormクラスを継承して作っています。  
これは以下のような形をしています。


    class FriendForm(forms.ModelForm):
        class Meta:
            model = モデルクラス
            fields = [……フィールド……]

このModelFormでは、内部に「**Meta**」というクラスを持ってます。  
これは「メタクラス」と呼ばれるもので、モデル用のフォームに関する情報が用意されています。  
ここでは、modelで使用するモデルクラスを、またFieldsで用意するフィールドをそれぞれ設定しています。  
用意するのはこれだけで、これまでのフォームのように、個々のフィールドなどは用意する必要ありません。


### create関数を修正する

ビュー関数側を修正しましょう。先ほど作成したviews.pyのcreate関数を以下のように書き換えてください。


<p class="mb-05"><span class="tmp list">リスト3-30</span><span class="bold">views.pyのcreate関数を修正する</span></p>
    
    # from .forms import HelloForm　#この文を削除する
    from .forms import FriendForm　#この文を新たに追記

    def create(request):
        if (request.method == 'POST'):
            obj = Friend()
            friend = FriendForm(request.POST, instance=obj)
            friend.save()
            return redirect(to='/hello')
        params = {
            'title': 'Hello',
            'form': FriendForm(),
        }
        return render(request, 'hello/create.html', params)

![](modelForm1.png?classes=caption "図　ModelFormによるフォーム")
    
これで完成です。アクセスしても、見た目にはほとんど違いはありません。  
BirthがBirthdayに変わったくらいです。


### ModelFormによる保存の流れ

実行している処理を見てみます。  
POST送信されたなら、まずFriendクラスのインスタンスを作成します。

	obj = Friend()

これは、引数などには何も指定していません。いわば、「初期状態のインスタンス」です。  
続いて、FriendFormインスタンスを作成します。

	friend = FriendForm(request.POST, instance=obj)

これがModelForm利用のポイントです。  
FriendFormインスタンスを作成する際、引数にはrequest.POSTを指定しています。  
これは、POST送信されたフォームの情報がすべてまとめてるところです。

もう一つは「instance」という引数を指定しています。  
これで、先ほど作成したFriendインスタンスを指定するのです。

	friend.save()

このまま、ModelFormの「save」メソッドを呼び出すと、ModelFormに設定されたrequest.POSTの値をinstanceに設定したFriendインスタンスに設定し、レコードが保存されます。

このやり方ならば、先のHelloFormを使った方法よりもだいぶすっきりします。  
保存処理も簡単ですし、フォームの定義も非常にシンプルで済みます。

![](modelForm2.png?classes=caption "図　Modelとrequest.POSTをModelFormで1つにまとめ、保存する。")
   

## Updateを作ろう

既にあるレコードの更新も、保存そのものは「save」を使って行います。  
編集するFriendインスタンスを使ってFriendFormを作成すれば、そのFriendインスタンスを更新することができます。

### edit.htmlを作る

URLの登録から行います。  
「hello」フォルダ内のurls.pyを開き、urlpatterns変数を以下のように書き換えます。

<p class="mb-05"><span class="tmp list">リスト3-31</span><span class="bold">urls.pyのurlpatterns変数を修正する</span></p>
    
    urlpatterns = [
        path('', views.index, name='index'),
        path('create', views.create, name='create'),
        path('edit/<int:num>', views.edit, name='edit'),
    ]


今回は、editというページを追加します。  
これは、/edit/1というように、ID番号をURLに含むようにしておきます。  
こうすることで、どのレコードを編集するか指定できるようにするわけです。  
例えば、/edit/3とすれば、ID番号が「3」のレコードを編集するページが現れる、というようにするのです。


### index.hmlを修正する

ついでに、「template」フォルダ内の「hello」フォルダ内にあるindex.htmlも修正をしておきましょう。  
&lt;body&gt;タグの部分を以下のように修正します。


<p class="mb-05"><span class="tmp list">リスト3-32</span><span class="bold">index.htmlを修正する</span></p>
    
    <body>
        <h1>{{title}}</h1>
        <table>
            <tr>
                <th>data</th>
                <th></th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item}}</td>
                <td><a href="{% url 'edit' item.id %}">Edit</a></td>
            <tr>
        {% endfor %}
        </table>
    </body>


図　/helloにアクセスすると、各レコードに「Edit」というリンクが追加されています。（ただし今の段階では完成していないので動きません。）

トップページのレコード一覧表示に、更新用のリンクを追記してあります。  
テーブルの一番右側に「Edit」というリンクが追加されていますが、これをクリックするとそのレコードの編集ページに移動する、というように設定します。  
編集ページへのリンクには、こんな<a>タグを用意しています。

	<a href="{% url 'edit' item.id %}">

 url 'edit'の後に、item.idをつけています。これにより、/edit/1というようにeditの後にID番号をつけてアクセスできるようにします。


### edit.htmlを作る

編集用のテンプレートを用意します。  
「templates」フォルダ内の「hello」フォルダの中に、「edit.html」といった名前でファイルを作成し、以下のように記述します。

<p class="mb-05"><span class="tmp list">リスト3-33</span><span class="bold">edit.htmlを作成</span></p>
        
    {% load static %}
    <!doctype html>
    <html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>{{title}}</title>
        <link rel="stylesheet" type="text/css" 
            href="{% static 'hello/css/style.css' %}" />
    </head>
    <body>
        <h1>{{title}}</h1>
        <table>
            <form action="{% url 'edit' id %}" method="post">
            {% csrf_token %}
            {{ form.as_table }}
            <tr><td></td><td><input type="submit" value="click"></td></tr>
            </form>
        </table>
    </body>
    </html>

見ればわかるように、create.htmlと内容はほぼ同じです。  
用意されているフォームの発信先が、action="{% url 'edit' id %}"というように設定されていますね。  
これで、例えばID=1の編集をする場合は、/hello/edit/1というようにアドレスが設定されるようになります。


### edit関数を作る

続いて、編集用のビュー関数を作ります。  
「hello」フォルダ内のviews.pyを開き、その中に「edit」というビュー関数を追記します。  
既に書いてあるスクリプトはそのままにしておきます。

<p class="mb-05"><span class="tmp list">リスト3-34</span><span class="bold">views.pyに「edit」というビュー関数を追記</span></p>
        
    def edit(request, num):
        obj = Friend.objects.get(id=num)
        if (request.method == 'POST'):
            friend = FriendForm(request.POST, instance=obj)
            friend.save()
            return redirect(to='/hello')
        params = {
            'title': 'Hello',
            'id':num,
            'form': FriendForm(instance=obj),
        }
        return render(request, 'hello/edit.html', params)

これで必要なファイルやコードは一通りできました。  
/helloにアクセスすると、テーブル表示されるレコードの右端に「Edit」が表示されます。

このEditリンクをクリックすると、/editの指定のIDを編集するページに移動します。  
移動すると、フォームにレコードの値が設定された形で表示されます。  
そのまま値を書き換えて送信すれば、レコードの内容が更新されます。
        
![](edit1.png?classes=caption "図　Editリンクをクリックすると、そのレコードを編集する画面に移動します。")
<p class="text-center">↓</p>     
![](edit2.png?classes=caption "図　クリックしたそのレコードの編集画面。値を変更してclickを押すと変更されます。")

### 更新の仕組み

ここでは、以下のように関数が定義されています。

	def edit(request, num):

urlpatternsに用意したURLでは、'edit/<int:num>'というように設定をしていましたから、アドレスのnumの値がそのまま引数numに渡されます。  
このnumの値を使って、Friendインスタンスを取得します。

	obj = Friend.objects.get(id=num)

インスタンスの取得は、getで取得したインスタンスを指定しています。  
フォームから送信された値（request.POST）は、create関数の時と同じように用意してあります。  
そしてインスタンスを作成し、saveを呼び出せば、取得したFriendインスタンスの内容が更新されレコードが保存されます。  
更新の場合、あらかじめ「どのレコードを編集するのか」を指定し、そのレコードの値をフォームに表示するなどの下準備をしておかないといけませんが、保存そのものは新規作成の場合とほとんど変わりありません。


## Deleteを作ろう

まず、ID番号などを使って、削除するレコードのモデルインスタンスを取得しておきます。  
そして、そのインスタンスの「delete」メソッドを実行すれば、そのモデルに対応するレコードが削除されます。  
削除するレコードを指定して内容を確認して……という「削除の手前」の部分を作るのに少し手間がかかりますが、削除そのものはとっても簡単なのです。

### urlpatternsの追記

「hello」フォルダ内のurls.pyを開き、urlpatterns変数を以下のように書き換えておきます。

<p class="mb-05"><span class="tmp list">リスト3-35</span><span class="bold">urls.pyのurlpatterns変数を書き換える</span></p>
        
    urlpatterns = [
        path('', views.index, name='index'),
        path('create', views.create, name='create'),
        path('edit/<int:num>', views.edit, name='edit'),
        path('delete/<int:num>', views.delete, name='delete'),
    ]

editと同様に、<int:num>をアドレスの中に埋め込んでおきます。  
これで削除するIDをビュー関数に伝えることができます。


### index.htmlの修正

更新の場合と同様、DeleteもID番号を指定してページにアクセスしないといけません。  
「template」フォルダ内の「hello」フォルダ内にあるindex.htmlを開き、<body>の部分を以下のように修正します。

<p class="mb-05"><span class="tmp list">リスト3-36</span><span class="bold">index.htmlの&lt;body&gt;の部分を修正</span></p>
        
    <body>
        <h1>{{title}}</h1>
        <table>
            <tr>
                <th>data</th>
                <th></th>
                <th></th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item}}</td>
                <td><a href="{% url 'edit' item.id %}">Edit</a></td>
                <td><a href="{% url 'delete' item.id %}">Delete</a></td>
            <tr>
        {% endfor %}
        </table>
    </body>


![](delete2.png?classes=caption "index.htmlを修正し、各レコードにDeleteリンクを追加した。")       


ここでは、&lt;a&gt;タグのリンク先に、&lt;a href="{% url 'delete' item.id %}"&gt;と値を指定してあります。
その上にあるEditリンクと同様に、これで、/delete/番号という形でアドレスが作成されます。

### delete.htmlを作成する

「template」フォルダ内の「hello」フォルダの中に、新たに「delete.html」という名前でファイルを作成します。


<p class="mb-05"><span class="tmp list">リスト3-37</span><span class="bold">delete.htmlを新規作成する</span></p>
        
    {% load static %}
    <!doctype html>
    <html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>{{title}}</title>
        <link rel="stylesheet" type="text/css" 
            href="{% static 'hello/css/style.css' %}" />
    </head>
    <body>
        <h1>{{title}}</h1>
        <p>※以下のレコードを削除します。</p>
        <table>
            <tr><th>ID</th><td>{{obj.id}}</td></tr>
            <tr><th>Name</th><td>{{obj.name}}</td></tr>
            <tr><th>Gender</th><td>
            {% if obj.gender == False %}male{% endif %}
            {% if obj.gender == True %}female{% endif %}</td></tr>
            <tr><th>Email</th><td>{{obj.mail}}</td></tr>
            <tr><th>Age</th><td>{{obj.age}}</td></tr>
            <tr><th>Birth</th><td>{{obj.birthday}}</td></tr>
            <form action="{% url 'delete' id %}" method="post">
            {% csrf_token %}
            <tr><th></th><td><input type="submit" value="click"></td></tr>
            </form>
        </table>
    </body>
    </html>

今回は、ビュー関数側から渡された変数objの値を表示し、その下に送信ボタンだけのフォームを用意しておきました。  
フォーム関係のタグだけを見ると、こうなっているのがわかるでしょう。

    <form action="{% url 'delete' id %}" method="post">
        {% csrf_token %}
        <tr><th></th><td><input type="submit" value="click"></td></tr>
     </form>

見ればわかるように、{% csrf_token %}と&lt;input type="submit"&gt;だけしかありません。  
何も送信していないフォームなのです。  
送信先のアドレスには、{% url 'delete' id %}が指定されていますから、idの値は送られています。  
IDさえわかれば、どのレコードを削除すれば良いかわかりますから、それ以外の情報は送る必要がないのです。

### delete関数を作る

「hello」フォルダ内にあるviews.pyを開き、以下のdelete関数を追記します。

/hello/にアクセスして、削除したいレコードの「Delete」ボタンをクリックしてみます。  
そのレコードの内容が表示されます。  
これで内容を確認し、送信ボタンを押すと、そのレコードが削除されます

<p class="mb-05"><span class="tmp list">リスト3-38</span><span class="bold">views.pyにdelete関数を追記します</span></p>
        
    def delete(request, num):
        friend = Friend.objects.get(id=num)
        if (request.method == 'POST'):
            friend.delete()
            return redirect(to='/hello')
        params = {
            'title': 'Hello',
            'id':num,
            'obj': friend,
        }
        return render(request, 'hello/delete.html', params)

![](delete3.png?classes=caption "図　レコード削除のページ。削除するレコードの内容が表示されます。このまま送信すれば、このレコードが削除されます。")



        
        
        

