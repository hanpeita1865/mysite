*[page-title]:ループする fetch()

## フェッチモードとは何か？
参考サイト
: [フェッチモードとは？PDOのfetchパターンを理解する](https://blog.senseshare.jp/fetch-mode.html)

フェッチモードとは、PDOでデータベースからデータを取り出した際の「配列の形式を指定するモード」のことです。  
fetch（フェッチ）は、日本語で「取得する」という意味です。

フェッチモードを指定しなくてもデータは取得出来ますが（デフォルトのモードが適用）、指定することでデータ配列の形式をカスタマイズすることが出来ます。


## fetch()の活用方法

サンプルDB（fetch_db.sqlite3）格納フォルダ
: C:\Users\hirao\Desktop\test\fetch\db

参考サイト
: [わかっているようでわからない、PHPのFETCHを解説！](https://takablog06.com/php_fetch_for_beginner/)
: [【PHP】PDOのfetchで取得できる配列パターン一覧](https://kinocolog.com/pdo_fetch_pattern/)

データの取り方は主に４種類。でもよく使うのは２つ。
データを取ってくる方法は主に次の４つです。

※()にあるのは、公式のリンクとなっています。

* <span class="red bold">fetch</span>・・・該当するデータを1行返す。(fetch)
* <span class="red bold">fetchAll</span>・・・該当するすべてのデータを配列で返す。(fetchAll)
* fetchColumn・・・該当するデータから単一のカラムを返す。(fetchColumn)
* fetchObject・・・該当するデータを1行取得して、それをオブジェクトとして返す。(fetchObject)


このうち、よく使用されるのは「<span class="red bold">fetch</span>」と「<span class="red bold">fetchAll</span>」です。


<定義済み定数の種類>
: <span class="green bold">PDO::FETCH_ASSOC</span>・・・結果セットに 返された際のカラム名で添字を付けた配列を返します。
: <span class="green bold">PDO::FETCH_BOTH (デフォルト)</span>・・・結果セットに返された際のカラム名と 0 で始まるカラム番号で添字を付けた配列を返します。
: <span class="green bold">PDO::FETCH_NUM</span>・・・結果セットに返された際の 0 から始まるカラム番号を添字とする配列を返します。
 
※上記で紹介した定数は「fetch」と「fetchAll」で使用できる定数となります。  
※またこれ以外にもまだまだ種類はたくさんあります。

今回は、次のようなデータベースをSQLiteに作成しました。

データベース名
: fetch_db.sqlite3

テーブル名
: users

![](upload/usersテーブル.png)
 
 
 ### fetch(PDO::FETCH_ASSOC)
 
<p class="tmp list"><span>リスト</span>fetch(PDO::FETCH_ASSOC)</p>
```
<?php
try {

  $pdo = new PDO('sqlite:db/fetch_db.sqlite3');

  $stmt = $pdo->prepare('SELECT * FROM users WHERE age >= 40');
  $stmt->execute();
  $result = $stmt->fetch(PDO::FETCH_ASSOC); 

  print_r('<pre>');
  print_r($result);
  print_r('</pre>');
  
} catch (Exception $e) {
    error_log('障害が発生しており、ご迷惑をおかけしています。');
}
?>
 ```
 
`$stmt = $pdo->prepare('SELECT * FROM users WHERE age >= 40');`  
SQL文で40歳以上を指定しています。

`$result = $stmt->fetch(PDO::FETCH_ASSOC); `  
featch(～)でデータの最初の40歳以上を、１件取得しています。

 下記に接続してください。  
http://localhost:7000/test/fetch/sample1(asscot).php


<p class="tmp">結果</p>
```
Array
(
    [id] => 2
    [name] => 鈴木　太郎
    [age] => 69
    [locate] => 愛知
)
```

次のように、query()を使っても同じような結果が得られます。
<p class="tmp list"><span>リスト</span></p>
```
$sql = 'SELECT * FROM users WHERE age >= 40';
$sth = $pdo -> query($sql);
$result = $sth -> fetch(PDO::FETCH_ASSOC);
```

 ### fetch(PDO::FETCH_BOTH)、fetch()
 $result = $stmt->fetch(<span class="red bold">PDO::FETCH_BOTH</span>); かfetch() に変更すると、「カラム名」と「０から始まるカラム番号で添字をつけた」配列の形式でデータを取得します。
 
 「PDO::FETCH_BOTH」はデフォルトになるので、省略しても同じ結果が得られます。
 
 <http://localhost:7000/test/fetch/sample2(both).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [id] => 2
    [0] => 2
    [name] => 鈴木　太郎
    [1] => 鈴木　太郎
    [age] => 69
    [2] => 69
    [locate] => 愛知
    [3] => 愛知
)
```

連想配列の形式と通常の配列の形式の２つの配列をデータに格納するということ。だから「BOTH(両方)」という名前になっています。


### fetch(PDO::FETCH_NUM)
 $result = $stmt->fetch(<span class="red bold">PDO::FETCH_NUM</span>);にすると、添え字が付いたデータが取得されます。
 
  <http://localhost:7000/test/fetch/sample3(num).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [0] => 2
    [1] => 鈴木　太郎
    [2] => 69
    [3] => 愛知
)
```
 
 
 ## fetchAllで取得されるデータ

<span class="blue bold">fetchAll</span>は、該当するすべてのデータを配列の形式で返します。

### fetchAll(PDO::FETCH_ASSOC)

$result = $stmt-><span class="blue bold">fetchAll</span>(<span class="red">PDO::FETCH_ASSOC</span><span class="red"></span>); にすると

<http://localhost:7000/test/fetch/sample4(allasscot).php>に接続してください。

次のように、該当するすべてのデータを二次元配列の形式で返します。
<p class="tmp">結果</p>
 ```
 Array
(
    [0] => Array
        (
            [id] => 2
            [name] => 鈴木　太郎
            [age] => 69
            [locate] => 愛知
        )

    [1] => Array
        (
            [id] => 4
            [name] => 松下　譲
            [age] => 42
            [locate] => 大阪
        )

    [2] => Array
        (
            [id] => 8
            [name] => 高橋　綾
            [age] => 44
            [locate] => 福島
        )

)
```

### fetchAll(PDO::FETCH_NUM)
 
 $result = $stmt-><span class="blue">fetchAll</span>(<span class="red">PDO::FETCH_NUM</span>); にすると、次のように二次元目のデータも添え字になったデータを返します。

<http://localhost:7000/test/fetch/sample5(allnum).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [0] => Array
        (
            [0] => 2
            [1] => 鈴木　太郎
            [2] => 69
            [3] => 愛知
        )

    [1] => Array
        (
            [0] => 4
            [1] => 松下　譲
            [2] => 42
            [3] => 大阪
        )

    [2] => Array
        (
            [0] => 8
            [1] => 高橋　綾
            [2] => 44
            [3] => 福島
        )

)
```

### fetchAll(PDO::FETCH_BOTH)
$result = $stmt-><span class="blue">fetchAll</span>(<span class="red">PDO::FETCH_BOTH</span>)か$result = $stmt-><span class="blue">fetchAll()</span>　にすると、二次元目にはカラム名と添え字が付いたデータが返ります。

<http://localhost:7000/test/fetch/sample6(allboth).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [0] => Array
        (
            [id] => 2
            [0] => 2
            [name] => 鈴木　太郎
            [1] => 鈴木　太郎
            [age] => 69
            [2] => 69
            [locate] => 愛知
            [3] => 愛知
        )

    [1] => Array
        (
            [id] => 4
            [0] => 4
            [name] => 松下　譲
            [1] => 松下　譲
            [age] => 42
            [2] => 42
            [locate] => 大阪
            [3] => 大阪
        )

    [2] => Array
        (
            [id] => 8
            [0] => 8
            [name] => 高橋　綾
            [1] => 高橋　綾
            [age] => 44
            [2] => 44
            [locate] => 福島
            [3] => 福島
        )

)
```

### fetchAll(PDO::FETCH_COLUMN)

$result = $stmt-><span class="blue">fetchAll</span>(<span class="red">PDO::FETCH_COLUMN</span>); にすると、キーを連番に、値をある1つのカラムを指定した一次元配列として取得します。

<p class="tmp list"><span>リスト</span></p>
```
$stmt = $pdo->prepare('SELECT name FROM users');
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_COLUMN);
```

または、query()を使っても同じ結果が得られます。
<p class="tmp list"><span>リスト</span></p>
```
$sql = 'SELECT name FROM users';
$sth = $pdo -> query($sql);
$result = $sth -> fetchAll(PDO::FETCH_COLUMN);
```

<http://localhost:7000/test/fetch/sample7(allcolumn).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [0] => 山田　花子
    [1] => 鈴木　太郎
    [2] => 松本　太郎
    [3] => 松下　譲
    [4] => 塚本　仁
    [5] => 小林　由佳
    [6] => 山田太郎
    [7] => 高橋　綾
)
```

### fetchAll(PDO::FETCH_KEY_PAIR)

fetchAll(<span class="red">PDO::FETCH_KEY_PAIR</span>)　に変更すると、配列のキーを連番ではなく指定したカラムに変更することが出来ます

<p class="tmp list"><span>リスト</span></p>
```
$sql = 'SELECT id, name FROM users';
$sth = $pdo -> query($sql);
$result = $sth -> fetchAll(PDO::FETCH_KEY_PAIR);
```
<http://localhost:7000/test/fetch/sample8(allkeypair).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [1] => 山田　花子
    [2] => 鈴木　太郎
    [3] => 松本　太郎
    [4] => 松下　譲
    [5] => 塚本　仁
    [6] => 小林　由佳
    [7] => 山田太郎
    [8] => 高橋　綾
)
```

$sql = 'SELECT name, locate FROM users';　のように、SQL文のSELECTを「<span class="green">name, locate</span>」すると、<span class="green">name</span>が添え字になります。

<http://localhost:7000/test/fetch/sample9(allkeypair_name_locate).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [山田　花子] => 東京
    [鈴木　太郎] => 愛知
    [松本　太郎] => 熊本
    [松下　譲] => 大阪
    [塚本　仁] => 富山
    [小林　由佳] => 群馬
    [山田太郎] => 鳥取
    [高橋　綾] => 福島
)
```

$result = $stmt->fetch(PDO::FETCH_COLUMN);でも、キーを添え字にできます。 
１件目のデータが表示されます。

<p class="tmp">結果</p>
```
Array
(
    [山田　花子] => 東京
)
```

### カラム（列）とレコード（行）を指定して、配列ではなく変数として取得する

欲しいデータを取得する際、特定のカラム（列）とレコード（行）を指定する場合は、取得するデータが配列である必要はありません。  
その場合は単一の変数としても取得できます。

<p class="tmp list"><span>リスト</span></p>
```
$stmt = $pdo->prepare('SELECT name FROM users WHERE id = 4');
$stmt->execute();
$name = $stmt -> fetch(PDO::FETCH_COLUMN);
echo $name;
```

<http://localhost:7000/test/fetch/sample10(variable).php>に接続してください。

<p class="tmp">結果</p>
```
松下　譲
```

### キーを指定したカラムに、値をカラム毎の配列で取得する

先頭のカラム（ここではid）をキーに、以降を各カラム毎の配列で取得したい場合の処理です。

<p class="tmp list"><span>リスト</span></p>
```
$sql = 'SELECT id, users.* FROM users';
$sth = $pdo -> query($sql);
$result = $sth -> fetchAll(PDO::FETCH_ASSOC|PDO::FETCH_UNIQUE);
```

<http://localhost:7000/test/fetch/sample12(allassocunique).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [1] => Array
        (
            [id] => 1
            [name] => 山田　花子
            [age] => 32
            [locate] => 東京
        )

    [2] => Array
        (
            [id] => 2
            [name] => 鈴木　太郎
            [age] => 69
            [locate] => 愛知
        )

    [3] => Array
        (
            [id] => 3
            [name] => 松本　太郎
            [age] => 36
            [locate] => 熊本
        )

    [4] => Array
        (
            [id] => 4
            [name] => 松下　譲
            [age] => 42
            [locate] => 大阪
        )

    [5] => Array
        (
            [id] => 5
            [name] => 塚本　仁
            [age] => 20
            [locate] => 富山
        )

    [6] => Array
        (
            [id] => 6
            [name] => 小林　由佳
            [age] => 24
            [locate] => 群馬
        )

    [7] => Array
        (
            [id] => 7
            [name] => 山田太郎
            [age] => 28
            [locate] => 鳥取
        )

    [8] => Array
        (
            [id] => 8
            [name] => 高橋　綾
            [age] => 44
            [locate] => 福島
        )

)
```

## キーを指定したカラムでグループ化した配列を取得する

先頭のカラムをキーをグループ化した配列で取得できます。
値となるカラムを1つに指定するか、複数取得できる三次元配列で取得するかで、SELECTの指定とfetchの引数が異なります。


### グループ化したキーと単一のカラムで取得する場合

先頭カラムをグループ化したキー（ここではlocate）に、2つ目に指定したカラム（name）はそれぞれのグループ毎に振り分けます。

<p class="tmp list"><span>リスト</span>fetchAll(<span class="red">PDO::FETCH_COLUMN|PDO::FETCH_GROUP</span>)</p>
```
$sql = "SELECT locate, name FROM users";
$sth = $pdo -> query($sql);
$result = $sth -> fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_GROUP);
```

<http://localhost:7000/test/fetch/sample13(allcolumngroup).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [東京] => Array
        (
            [0] => 山田　花子
        )

    [愛知] => Array
        (
            [0] => 鈴木　太郎
        )

    [熊本] => Array
        (
            [0] => 松本　太郎
        )

    [大阪] => Array
        (
            [0] => 松下　譲
        )

    [富山] => Array
        (
            [0] => 塚本　仁
        )

    [群馬] => Array
        (
            [0] => 小林　由佳
        )

    [鳥取] => Array
        (
            [0] => 山田太郎
        )

    [福島] => Array
        (
            [0] => 高橋　綾
        )

)
```

fetchAll(<span class="red">PDO::FETCH_GROUP | PDO::FETCH_ASSOC</span>); にした場合、次のような結果が返ります。

<http://localhost:7000/test/fetch/sample14(allassocgroup).php>に接続してください。

<p class="tmp">結果</p>
```
Array
(
    [東京] => Array
        (
            [0] => Array
                (
                    [name] => 山田　花子
                )

        )

    [愛知] => Array
        (
            [0] => Array
                (
                    [name] => 鈴木　太郎
                )

        )

    [熊本] => Array
        (
            [0] => Array
                (
                    [name] => 松本　太郎
                )

        )

    [大阪] => Array
        (
            [0] => Array
                (
                    [name] => 松下　譲
                )

        )

    [富山] => Array
        (
            [0] => Array
                (
                    [name] => 塚本　仁
                )

        )

    [群馬] => Array
        (
            [0] => Array
                (
                    [name] => 小林　由佳
                )

        )

    [鳥取] => Array
        (
            [0] => Array
                (
                    [name] => 山田太郎
                )

        )

    [福島] => Array
        (
            [0] => Array
                (
                    [name] => 高橋　綾
                )

        )

)
```




## データの件数を取得

<p class="tmp list"><span>リスト</span></p>
```
$sql = 'SELECT COUNT(*) FROM users';
$sth = $pdo -> query($sql);
$count = $sth -> fetch(PDO::FETCH_COLUMN);
echo '件数は'.$count.'件です';
```

<http://localhost:7000/test/fetch/sample11(count).php>に接続してください。

<p class="tmp">結果</p>
```
件数は8件です
```
※また、件数の取得はPDOオブジェクトのrowCount()でも取得できます。→やってみたが、0件になる。


 
 <!--
 ## データベースから取得
 

 ### fetch(PDO::FETCH_BOTH)
 ```
 $result = $stmt->fetch(PDO::FETCH_BOTH); 
 ```
 
 <p class="tmp">取得データ</p>
 ![fetchfetch_both](upload/fetchfetch_both.png "fetchfetch_both")
 
 ### fetch(PDO::FETCH_ASSOC)
 
 ```
 $result = $stmt->fetch(PDO::FETCH_ASSOC); 
 ```
  <p class="tmp">取得データ</p>
 ![fetch_ascot](fetch_ascot.png "fetch_ascot")
 ```
 
 ### fetch(PDO::FETCH_NUM);
 
 $result = $stmt->fetch(PDO::FETCH_NUM); 
 ```
  <p class="tmp">取得データ</p>
 ![fetch_num](fetch_num.png "fetch_num")
 
 
 ## fetchAll
 
 ### fetchAll(PDO::FETCH_ASSOC)
 
 ```
 $result = $stmt->fetchAll(PDO::FETCH_ASSOC); 
 ```
 ![fetchAll_ascot](fetchAll_ascot.png "fetchAll_ascot")
 
 ### fetchAll(PDO::FETCH_NUM)
 
 ```
 $result = $stmt->fetchAll(PDO::FETCH_NUM); 
 ```
 ![fetchAll_num](fetchAll_num.png "fetchAll_num")
 
 -->