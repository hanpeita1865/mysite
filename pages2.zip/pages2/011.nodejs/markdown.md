*[page-title]:Node.js

参考サイト
: [nodistを使ってwindowsでnodejsのバージョン管理](https://www.aska-ltd.jp/jp/blog/155)
: [Windowsでnode.jsやnpmのバージョンをアップデート・変更する方法｜バージョンが切り替わらないときの対処法（nodistの使い方）](https://prograshi.com/framework/nodejs/upgrade-or-change-node-version-in-windows/)

## nodistを使って、 バージョン管理

※npx コマンドは npm バージョン 5.2.0 より同梱されているコマンドで、ローカルインストールしたコマンドを実行するために使われます。今主に使われている npm ではほとんど使える状態にあります。

ただ、Gulp実行で使うnpxというツールは、nodistではバンドルされないため別途インストールする必要があります。

<p class="tmp cmd"><span>コマンド</span>npxインストールコマンド</p>
```
npm i npx -g
```

※↑ 正しいコマンドかわかりませんが、一応できました。参考にしたサイト[nodistのnpmにはnpxがバンドルされないので、別途入れてみた。](https://qiita.com/horihiro/items/93c3fb247d39911ccdf0)


<div class="d-flex" markdown="1">
<div markdown="1">
基盤の方が案件で使用したバージョン

|名前	|バージョン|	備考|
|--|--|--|
|Node.js|	14.16.1	|JavaScript実行環境|
|npm|	6.14.12	|パッケージ管理|
|npx|	6.14.8	|パッケージの実行|
|create-nuxt-app|	3.6.0	|Nuxtプロジェクト生成|
|Nuxt	|2.15.4	|フレームワーク本体|
|Vue.js|	2.6.12	|Nuxtの内部で使用|
</div>

<div markdown="1">
現在自分が使用している各種バージョン　6/29（火）13:49 時点

|名前	|バージョン|新バージョン（切り替え済み）|2021/11/16（切り替え）制作Gで統一のため |
|--|--|--|--|
|Node.js|v12.13.0|<span class="text-red">v14.16.1</span>| <span class="green bold">v16.4.2</span> |
|npm|6.12.0|<span class="text-red">6.14.12</span>|  <span class="green bold">7.18.1</span>|
|npx|10.2.2|  同じ|
|nodist(Node.js管理ツール)|0.9.1| |  |
</div>
</div>

<div markdown="1" class="memo-box">
node16.4.2で、`npx nuxi init nuxt3-app`などの<span class="green bold">npxコマンド</span>を使うと、下記のエラーがでる。
```
WARN  Current version of Node.js (16.4.2) is unsupported and might cause issues.                             17:21:26
       Please upgrade to a compatible version (^14.16.0 || ^16.11.0 || ^17.0.0 || ^18.0.0).
```
そのため、Nodeのバージョンを上記のどれかに切り替える必要があります。
</div>


<p class="tmp cmd"><span>コマンド</span>Node.jsのバージョン確認</p>
```
node -v
```

<p class="tmp cmd"><span>コマンド</span>npmのバージョン確認</p>
```
npm -v
```
<p class="tmp cmd"><span>コマンド</span>npxのバージョン確認</p>
```
npx -v
```
<p class="tmp cmd"><span>コマンド</span>nodistのバージョン確認</p>
```
nodist -v
```

<p class="tmp">実行結果</p>
```
PS C:\Users\hirao\Desktop> node -v
v16.4.2
PS C:\Users\hirao\Desktop> npm -v
7.18.1
PS C:\Users\hirao\Desktop> npx -v
10.2.2
PS C:\Users\hirao\Desktop> nodist -v
0.9.1
```

### nodistの使い方

[_proxy.bat](upload/_proxy.bat)のバッチファイルをデスクトップに置いて起動し、下図のようにU～とpasswordを入力します。

「nodist  list 」コマンドを実行して、	現在インストールされているNode.jsのバージョン一覧を確認します。

![](upload/nodist_list.jpg)

新しく使用したいNode.jsのバージョンを指定しインストールします。

![](upload/nodist_list2.jpg)


再度「nodist  list 」コマンドを実行し、Node.jsのバージョン一覧でバージョンが 「14.16.1」 に切り替わっていることを確認します。

![](upload/nodist_list3.jpg)

現在インストールされているnpmのバージョン一覧を確認します。  
nodist npm

![](upload/nodist_list4.jpg)

npmのバージョンを現在使用中のNode.jsに合わせます。  
<p class="tmp cmd"><span>コマンド</span></p>
```
nodist npm match
```

![](upload/nodist_list5.jpg)

上図のような表示になったが、ちゃんとできてるか疑問????

再度npmのバージョン一覧を確認し、バージョンが切り替わっていることを確認します。  
nodist npm

![](upload/nodist_list6.jpg)

ちゃんと、  6.12.0から6.14.12に切り替わってました。

### Node.jsのバージョン切り替え

バージョンの切り替えは次のコマンドで実施できます。

<p class="tmp"><span>書式</span></p>
```
nodist {バージョン}
```

Node.jsのバージョンを12.13.0に戻したい場合は、下記のように入力します。
<p class="tmp cmd"><span>コマンド</span></p>
```
nodist 12.13.0
```

Node.jsのバージョンを切り替えると、npmのバージョンも自動で切り替わりました。

![](upload/node_change.jpg)

## ローカルのnode_modulesの再インストール

プロジェクト内のnode_modulesフォルダを削除した後、下記のコマンドをそのディレクトリで実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
npm i
```

## nvm-windowsを使って、nodeバージョン管理を行う

参考サイト
: [いよいよ Nodist では Node.js v18 が動かなかったので nvm-windows に移行する](https://neos21.net/blog/2022/09/16-01.html)
: [【Node.js入門】バージョン管理と確認方法のまとめ！](https://www.sejuku.net/blog/73695)
: [2020 年ではもう使えない Nodist はアンインストールする (Windows)](https://zenn.dev/ymasaoka/articles/note-uninstall-nodish-windows)

※nodistを設定していれば、アンインストールをします。

下記からnwn-windowsをダウンロードします。  
下記からの最新バージョンのページを開き、下部の方のnvm-setup.zipをダウンロードして解凍。nvm-setup.exeをダブルクリックして実行。（nvm-setup.exeをダウンロードでもいいと思います）  
![](upload/nvm_assets.png)

<https://github.com/coreybutler/nvm-windows/releases>

nvmをインストールして、nodeもバージョンごとにインストールしていきます。
![](upload/nvmインストール.png)
* node v18.10.0
* npm v8.19.2
* npx v8.19.2


### nvmのコマンド利用方法
参考サイト
: [Node.js のバージョン管理ツール nvm の使い方](https://laboradian.com/how-to-use-nvm/)


<p class="tmp cmd"><span>コマンド</span>インストール済のバージョンを表示する</p>
```
nvm ls
```

<p class="tmp cmd"><span>コマンド</span>利用するバージョンに切り替え。</p>
```
nvm use {バージョン}
```

<p class="tmp cmd"><span>コマンド</span>現在利用しているバージョンを表示する。</p>
```
nvm current
```


