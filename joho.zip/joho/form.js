let photoDelList = [];//削除画像のパスリスト
let pathDelList = [];//削除画像のname属性リスト


$(function () {

    let imgLng;//その他の画像の数

    //imgのボタンを初めは非表示
    $('.btn-img').hide();
    $('.btn-markimg').hide();
    //キャプションも初めは非表示
    //$('#caption-top').hide();
    //$('.caption').hide();
    //$('.caption-title').hide();


    //テキストエリアにリンクのタグを挿入(バリアフリーマップ用)
	$(".def-form .btn-text").click(function () {
		let valText = $(this).data('text');
		let v= $('#report').val();//テキストエリアの文字取得
		let selin = $('#report').prop('selectionStart');//カーソル位置取得（開始）
		let selout = $('#report').prop('selectionEnd');//カーソル位置取得（選択状態では最後の位置）
		let v1=v.substr(0,selin);//カーソル位置から前の文字
		let v2=v.substr(selin,selout-selin);
		let v3=v.substr(selout);//カーソル位置から後ろの文字
		$('#report')
		  .val(v1+valText+v3)

		  .prop({
			"selectionStart":selin+valText.length,
			"selectionEnd":selin+valText.length+v2.length
			})
		  .trigger("focus");
	})

    //投稿画面 トップの画像を選択してキャプチャ
    $('#file-top').change(function (e) {

        let imgTopSize = this.files[0].size; //ここでファイルサイズを取得
        if (imgTopSize >= 2000000) {
            resetTopImg();
            $('#list-top').html('');//表示されてる画像を最初にクリア
            alert('ファイルサイズが大きすぎます。（' + imgTopSize + 'Byte）')
        } else {

            $('#list-top').html('');//表示されてる画像を最初にクリア

            let file = e.target.files[0];//Fileオブジェクトを取得
            let reader = new FileReader(); //オブジェクトを生成

            //ファイル情報をキャプチャする
            reader.onload = (function (file) {
                return function (e) {
                    // サムネイル用のimgタグ
                    let $html = '<figure><img id="photo-top" class="thumb" src="' + e.target.result + '"><figcaption>トップ（位置固定）</figcaption></figure>';

                    // サムネイルタグを生成
                    $('#list-top').append($html);
                };
            })(file);

            reader.readAsDataURL(file);
            //トップのキャプションとキャプション見出しを表示
            $('#caption-top').show();
            $('.caption-title').addClass('capShow');

        }
    });

    //投稿画面 その他の画像を選択してキャプチャ
    $('#files').change(function (e) {
        imgLng = e.target.files.length;//選択したファイル数

        let imgTotalSize = 0;
        let imgSingleSize = 0;

        for (let i = 0; i < imgLng; i++) {//ファイルサイズの合計を取得
            imgTotalSize = imgTotalSize + this.files[i].size;//合計サイズ
            imgSingleSize = this.files[i].size;//単独サイズ
            if (imgSingleSize >= 2000000) {
                break;
            }
        }

        if (imgSingleSize >= 2000000) {
            resetOtherImg();
            $('#list').html('');//表示されてる画像を最初にクリア
            alert('容量が2MBを超えているファイルがあります。')
        } else if (imgTotalSize >= 8300000) {//ファイル合計が8.3M以上の場合は警告する
            resetOtherImg();
            $('#list').html('');//表示されてる画像を最初にクリア
            alert('ファイルの合計容量が大きすぎます。（' + imgTotalSize + 'Byte）')
        } else if (imgLng > 10) {
            //$('#files').val('');
            resetOtherImg();
            alert('画像の選択は10枚までです。選択し直してください。');
        } else {

            let files = e.target.files;//inputタグからFileオブジェクトを取得
            $('#list').html('');//表示されてる画像を最初にクリア

            let cnt = 0;
            for (let i = 0, f; f = files[i]; i++) {

                let reader = new FileReader(); //オブジェクトを生成

                reader.onload = (function (i) {//ファイル情報をキャプチャする
                    return function (e) {
                        cnt++;
                        // サムネイル用のimgタグ
                        let $html = '<figure><img id="photo' + cnt + '" class="thumb" src="' + e.target.result + '"><figcaption class="def-photo">（img' + cnt + '）</figcaption><figcaption class="mark-photo">img' + cnt + '</figcaption></figure>';
                        // サムネイルタグを生成
                        $('#list').append($html);
                        //ボタン表示
                        let btnImg = '#img' + cnt;
                        let btnMarkImg = '#mark-img' + cnt;
                        $(btnImg).show();
                        $(btnMarkImg).show();
                        //その他のキャプションを表示
                        let captionID = '#caption' + cnt;
                        //$(captionID).show();
                        //$('.def-form').find(captionID).show();
                        $(captionID).addClass('capShow');
                    };
                })(f);

                reader.readAsDataURL(f);
            }

            //キャプション見出しを表示
            //$('.caption-title').show();
            $('.caption-title').addClass('capShow');
        }
    });


    //テキストエリアの文字をクリアし、画像のボタンを復活させる
    $("#btn-clear").click(function () {
        $('#report').val('')

        for (let i = 1; i <= imgLng; i++) {
            let btnImg = '#img' + i;
            $(btnImg).show();
        }
    })

    //トップのファイル選択をクリア
    $("#reset-top").click(function () {
        resetTopImg();
    })

    //その他のファイル選択をクリア
    $("#reset").click(function () {
        resetOtherImg();
    })



    //編集画面のトップ画像を変更してキャプチャ
    $('.btn-change').change(function (e) {

        let delPath = $(e.target).parent('label').next('input').attr('data-path');

        //削除パスリストと変更ボタン内ののパスが一致したものを削除
        for (let i = 0; i < pathDelList.length; i++) {
            if (pathDelList[i] == delPath) {
                photoDelList.splice(i, 1);
                pathDelList.splice(i, 1);
            }
        }

        let idValue = $(this).data('change');

        let imgSize = this.files[0].size; //ここでファイルサイズを取得
        if (imgSize >= 2000000) {
            alert('ファイルサイズが大きすぎます。（' + imgSize + 'Byte）')
        } else {

            let file = e.target.files[0];//Fileオブジェクトを取得
            let reader = new FileReader(); //オブジェクトを生成

            //ファイル情報をキャプチャする
            reader.onload = (function (file) {
                return function (e) {
                    $(idValue).attr('src', e.target.result);//表示されてる画像を変更
                };
            })(file);

            reader.readAsDataURL(file);
        }
    })

    //削除ボタンをクリック
    $(".btn-updateDel").click(function () {
        let idValue = $(this).data('change');
        let pathValue = $(this).data('path');
        let imgValue = $(this).data('img');
        let imgSrc = $(idValue).attr('src');//今の画像のパスを取得

        $(idValue).attr('src', '');
        $(this).parent().next('textarea').val('');
        photoDelList.push(imgSrc);//削除画像のパスを変数に追加
        pathDelList.push(pathValue);//削除画像のデータベースの見出しを変数に追加

        //記事内の（img数字）を削除
        let repo = $('#report').val();//テキストエリアの文字取得
        let repoReplace = repo.replace(imgValue, "");
        $('#report').val(repoReplace);
    })

    //プレビューボタンをクリック
    $("#btn-preview").click(function () {

        let category = $('input[name="category"]').val();//カテゴリー名

        $('#category-p').val(category);

        let poster = $('#ip').val();//投稿者名
        $('#ip-p').val(poster);

        let titleVal = $('#title').val();//タイトル
        $('#title-p').val(titleVal);

        let reportVal = $('#report').val();//記事
        $('#report-p').val(reportVal);

        let topImg = $('#photo-top').attr('src');//トップ画像パス
        $('#top-img').val(topImg);

        let otherImg = [];
        for (let $i = 1; $i <= 10; $i++) {
            otherImg[$i] = $('#photo' + $i).attr('src');//その他画像パス
            $('#other' + $i).val(otherImg[$i]);
        }

        let topCaption = $('#cap-top').val();//トップ画像キャプション
        $('#caption-top-p').val(topCaption);


        for (let $i = 1; $i <= 10; $i++) {
            let caption = $('#cap' + $i).val();//その他画像パスのキャプション
            $('#caption' + $i + '-p').val(caption);
        }

        $('#form-preview').attr('action', 'preview.php')

        $('#form-preview').submit();
    })

    //プレビューボタンをクリック(バリアフリーマップ用)
    $("#local-btn-preview").click(function () {
        let poster = $('#ip').val();//投稿者名
        $('#ip-p').val(poster);

        let titleVal = $('#title').val();//タイトル
        $('#title-p').val(titleVal);

        let siteUrlVal = $('#site-url').val();//サイトURL
        $('#site-url-p').val(siteUrlVal);

        let reportVal = $('#report').val();//記事
        $('#report-p').val(reportVal);

        let topImg = $('#photo-top').attr('src');//トップ画像パス
        $('#top-img').val(topImg);

        let topCaption = $('#cap-top').val();//トップ画像キャプション
        $('#caption-top-p').val(topCaption);

        $('#form-preview').submit();
    })

    //マークダウンプレビューボタンをクリック
    $("#btn-markpreview").click(function () {

        let category = $('input[name="category"]').val();//カテゴリー名
        $('#category-p').val(category);

        let poster = $('#ip').val();//投稿者名
        $('#ip-p').val(poster);

        let titleVal = $('#title').val();//タイトル
        $('#title-p').val(titleVal);

        let reportVal = $('#report').val();//記事
        $('#report-p').val(reportVal);
        //console.log(reportVal);//テスト

        let markVal = $('#report-markdown').val();//マークダウン記事
        $('#markdown-p').val(markVal);

        let topImg = $('#photo-top').attr('src');//トップ画像パス
        $('#top-img').val(topImg);

        let topCaption = $('#cap-top').val();//トップ画像キャプション
        $('#caption-top-p').val(topCaption);

        let otherImg = [];
        for (let $i = 1; $i <= 10; $i++) {
            otherImg[$i] = $('#photo' + $i).attr('src');//その他画像パス
            $('#other' + $i).val(otherImg[$i]);
        }

        $('#form-preview').attr('action', 'markpreview.php');

        console.log(markVal);//テスト

        $('#form-preview').submit();
    })

});


function resetTopImg() {//トップ画像の選択をクリア
    $('#file-top').val('');
    $('#list-top').html('');
    $('#caption-top').hide();//トップのキャプションを非表示
    $('textarea[name="caption-top"]').val('');//キャプションの内容もクリア

    //キャプションの見出し非表示するか確認
    let filesVal = $("#files").val();//その他画像もないか確認
    if (filesVal == "") {
        $('.caption-title').removeClass('capShow');
    }
}

function resetOtherImg() {//その他画像の選択をクリア
    $('#files').val('');
    $('#list').html('');
    $('.caption').removeClass('capShow');//その他のキャプションを非表示
    $('.btn-img').hide();//imgのボタンを初めは非表示
    $('.caption').val('');//キャプションの内容もクリア
    $('.cap-txt').val('');//キャプションの内容もクリア
    imgLng = 0;//その他の画像の数を0にする

    //キャプションの見出し非表示するか確認
    let fileTopVal = $("#file-top").val();//トップ画像もないか確認
    if (fileTopVal == "") {
        $('.caption-title').removeClass('capShow');
    }
}


//フォームの入力チェック
function checkForm() { //アップロードボタン
    let titleVal = $('#title').val();
    let reportVal = $('#report').val();
    let reportMarkVal = $('#report-markdown').val();//記事（マークダウン）
    let radioVal = $('input[name="type"]').prop('checked')
    let fileTopVal = $('#file-top').val();//投稿画面 トップ一時的フォルダ
    let filesVal = $('#files').val();//投稿画面 その他一時的フォルダ
    let imgResult = '';//重複した（img数字）を連結した文字
    let category = $('input[name="category"]').val();
    let mark = $('#btn-mark').hasClass('active');//マークダウンで投稿の場合、「true」、標準は「false

    //記事内の（img数字）の重複チェック
    let imgCnt = [];//（img数字）が2つ以上は配列に格納

    for (let $i = 1; $i <= 10; $i++) {
        let searchStr = '（img' + $i + '）';
        let checkImg = strCount(searchStr, reportVal);
        if (checkImg >= 2) {
            imgCnt.push(searchStr);
        }
    }
    imgResult = imgCnt.join(',');//（img数字）の重複まとめ

    upData = $('#upload').attr('data-upload');

    if (upData === '編集更新' || upData === '一時的保存からアップ') {

        //削除画像のパスが入ったinputを挿入
        if (photoDelList.length > 0) {
            for (let $i = 0; $i < photoDelList.length; $i++) {
                $('.address').before('<input type="hidden" name="deleteList[]" value="' + photoDelList[$i] + '">');
                $('.address').before('<input type="hidden" name="pathDelList[]" value="' + pathDelList[$i] + '">');
            }
        }
    }

    if (category == 'map') {
        let siteUrl = $('#site-url').val();
        console.log('サイトURL' + siteUrl);
        console.log('トップ画像' + fileTopVal);

        if (titleVal == "") {
            alert("タイトルを入力して下さい。");
            return false;
        } else if (reportVal == "") {
            alert("情報や感想を入力して下さい。");
            return false;
        } else if (fileTopVal == "" && siteUrl == "") {
            alert("サイトのURLかまたは画像を登録してください。");
            return false;
        } else {

            if ($('#upload').val() === '編集更新') {//編集確認用
                if (window.confirm('更新していいですか？')) {
                    return true;
                } else {
                    return false;
                }

            } else {//投稿確認用
                if (window.confirm('投稿していいですか？')) {
                    return true;
                } else {
                    return false;
                }
            }
        }

    } else {  //便利ツール・余暇活動・私の工夫

        if (titleVal == "") {
            alert("タイトルを入力して下さい。");
            return false;

        } else if (reportVal == "" && mark == false) {  //標準の投稿で空白の場合
            alert("記事を入力して下さい。");
            return false;

        } else if (reportMarkVal == "" && mark == true) {  //マークダウン投稿で空白の場合
            alert("マーク記事を入力して下さい。");
            return false;

        } else if (!imgResult == '' && mark == false) {//（img数字）の重複チェック 修正
            alert(imgResult + 'の文字が、それぞれ記事の中に2つ以上あります。');
            return false;

            /*} else if(category == 'ingenuity'){
                if($("#intro").val()==""){
                    alert("紹介文を入力して下さい。")
                    return false;
                }*/


        } else {

            if ($('#upload').val() === '編集更新') {//編集確認用
                if (window.confirm('更新していいですか～？')) {
                    if (mark == true) {//マークダウンの場合、標準の記事は削除する
                        $('#report').val('')
                    }
                    //画像以外のファイルを先にAjaxで送信し、成功すればFormのデータを送信する。
                    ajaxPath = 'file_upload-update.php';//update-input時の送信先のパス
                    file_submit();//送信
                }

            } else {//投稿確認用

                let matterCheck = $('#chat').prop('checked');//マッターモストへの通知有無(2021.09.13追加)

                if (matterCheck) {
                    topMsg = '（マッターモストに通知します）'
                } else {
                    topMsg = '（マッターモストに通知なし）';
                }

                if (window.confirm('投稿していいですか？' + topMsg)) {
                    if (mark == true) {//マークダウンの場合、標準の記事は削除する
                        $('#report').val('')
                    }
                    //画像以外のファイルを先にAjaxで送信し、成功すればFormのデータを送信する。
                    ajaxPath = 'file_upload.php';//insert-input時とtemporaryからアップ時の送信先のパス

                    mattermost_image(matterCheck);//追加202021.09.13

                }
            }
        }
    }
}

//画像以外のファイルを送信する処理
function file_submit() {
    let fd = new FormData();
    let pathName = location.href;//URL取得
    let total = 0;

    for (let i = 0; i < waitList.length; i++) {
        fd.append('file[' + i + ']', waitList[i]);
        total = total + Number(waitList[i].size);//ファイルサイズを一個ずつ合計していく
    }

    if (total > 8000000) {//ファイル合計が8Mを超えていれば、アップロード停止
        alert('画像以外の追加ファイル合計が8Mを超えています。(total ' + total + 'Byte)\n\n要らないファイルを削除するか、後ほど削除したファイルを編集画面からアップロードしてください。');
        return false;
    }

    let result = pathName.indexOf('insert-input.php');//あいまい検索 含まれていれば「-1」以外の数字


    //FormDataを格納した変数fdを投稿画面はfile_upload.phpに送信、編集画面は、file_upload-update.phpに送信
    $.ajax({
        url: ajaxPath,
        type: "POST",
        contentType: false,
        processData: false,
        cache: false,
        data: fd,
    }).done(function (data) {
        //通信成功時の処理
        $('.waitFileList').remove();
        waitList = [];

        //フォームのデータ送信
        if (result == -1) {
            $('#form-update').submit();//編集画面Form送信
        } else {
            $('#form-insert').submit();//投稿画面Form送信
        }
    }).fail(function () {
        //通信失敗時の処理
        alert('画像以外のファイルアップロードに失敗しました');
        return false;
    });
}

//投稿一時的保存ボタン
function temporarySave() {

    if (window.confirm('保存しますか？')) {
        $('form').attr('action', 'temporary-output.php');

        //画像以外のファイルをtmp_filesに格納
        ajaxPath = 'file_upload_temporary.php';//一時的保存時の送信先のパス
        file_submit();

        //name="url"のvalue値を変更
        let url = $('input[name="url"]').val();
        let urlSprit = url.split('#');
        $('input[name="url"]').val(urlSprit[0]);

        return true;
        //return false;
    } else {
        return false;
    }
}

//編集一時的保存ボタン
function temporaryEditSave() {
    let mark = $('#btn-mark').hasClass('active');//マークダウン形式か判定

    if (window.confirm('保存しますか～？')) {
        $('form').attr('action', 'temporary-edit-save.php');
        //削除画像のパスが入ったinputを挿入
        if (photoDelList.length > 0) {
            for (let $i = 0; $i < photoDelList.length; $i++) {
                //console.log(photoDelList[0]);
                $('.address').before('<input type="hidden" name="deleteList[]" value="' + photoDelList[$i] + '">');
                $('.address').before('<input type="hidden" name="pathDelList[]" value="' + pathDelList[$i] + '">');
            }
        }

        if (mark == true) {//マークダウンの場合、標準の記事は削除する
            $('#report').val('')
        }
        //画像以外のファイルを先にAjaxで送信し、成功すればFormのデータを送信する。
        ajaxPath = 'file_update_temporary.php';//ファイル更新の送信先のパス
        file_submit();//送信

        return true;
    } else {
        return false;
    }
}

//バリアフリーマップ 投稿一時的保存ボタン
function temporaryLocalSave() {

    if (window.confirm('保存しますか？')) {
        $('form').attr('action', 'temporary-local-save.php');

        return true;
    } else {
        return false;
    }
}

//バリアフリーマップ 編集一時的保存ボタン
function temporaryLocalEditSave() {
    if (window.confirm('保存しますか？')) {
        $('form').attr('action', 'temporary-edit-save.php');

        return true;
    } else {
        return false;
    }
}


//記事内の（img数字）が重複チェック関数
let strCount = function (searchStr, str) {
    if (!searchStr || !str) return 0;

    let count = 0, pos = str.indexOf(searchStr);

    while (pos !== -1) {
        count++;
        pos = str.indexOf(searchStr, pos + count);
    }

    return count;
}

function deleteForm() {
    if (window.confirm('削除していいですか？')) {
        return true;
    } else {
        return false;
    }
}

//マークダウンと標準の記事の切り替え
$(function () {

    $('#btn-def').on('click', function () {  //標準ボタン
        $('.report-select button').removeClass('active');
        $(this).addClass('active');
        $(this).attr('tabIndex', '-1');
        $('#btn-mark').removeAttr('tabIndex');
        $('#btn-mark').focus();
        $('#contents').addClass('def-form');
        $('#contents').removeClass('mark-form')
        $('.mark-box').removeClass('d-block');
        $('.def-box').addClass('d-block');
        $('#report-markdown').removeAttr('name');
        $('#report').attr('name', 'report');
        $('#form-preview').show();
        $('form .caution').removeClass('d-block');
        $('.markdown-guide').removeClass('d-inline');
        $('#file-area').removeClass('d-block');
    });

    $('#btn-mark').on('click', function () {  //マークダウンボタン
        $('.report-select button').removeClass('active');
        $(this).addClass('active');
        $(this).attr('tabIndex', '-1');
        $('#btn-def').removeAttr('tabIndex');
        $('#btn-def').focus();
        $('#contents').addClass('mark-form');
        $('#contents').removeClass('def-form');
        $('.def-box').removeClass('d-block');
        $('.mark-box').addClass('d-block');
        $('#report').removeAttr('name');
        $('#report-markdown').attr('name', 'markdown');
        $('#form-preview').hide();
        $('form .caution').addClass('d-block');
        $('.markdown-guide').addClass('d-inline');
        $('#file-area').addClass('d-block');
    });

    if ($('.mark-box').hasClass('d-block')) {//マークダウンで記入している場合
        $('#btn-mark').addClass('active');
        $('#btn-def').removeClass('active');
        $('#form-preview').hide();
        $('form .caution').addClass('d-block');
        $('#report').removeAttr('name');
        $('#contents').addClass('mark-form');
        $('#contents').removeClass('def-form');
        $('.markdown-guide').addClass('d-inline');
        $('#file-area').addClass('d-block');
    }
});


function mattermost_image(matterCheck) {//マッターモストに画像設定用

    //マッターモストへの通知有り
    if (matterCheck) {
        //通知用の画像をローカルに送信
        let now = new Date();

        //現日時から年月日取得
        let year = now.getFullYear();
        let month = now.getMonth() + 1;
        // 0～11で月を取得するので、1を足します。
        let day = now.getDate();

        //現日時から時刻取得
        let hour = now.getHours();
        let min = now.getMinutes();
        let sec = now.getSeconds();
        let msec = now.getTime();
        let chatImgName = year + '.' + month + '.' + day + '_' + hour + '-' + min + '-' + sec + '-' + msec;

        $('#chatImg').val(chatImgName);//シンクラ用

        let topImg = $('#photo-top').attr('src');//トップ画像データ(base64)

        //トップ画像の登録があるか判定➡あればローカルに画像保存
        if (topImg != '' && upData == '一時的保存からアップ') {
            $('#chatImg2').val(chatImgName);//アップロード用
            $('#file-matter').val(topImg);
            $('#form-matter-photo').submit();//マッターモスト用の画像をシンクラに保存

        } else if (topImg != undefined && upData == '最初のアップ') {
            $('#chatImg2').val(chatImgName);//アップロード用
            $('#file-matter').val(topImg);
            $('#form-matter-photo').submit();//マッターモスト用の画像をシンクラに保存
        }

        file_submit();//送信

    } else {
        //マッターモスト用の画像保存無し
        file_submit();//送信
    }
}
