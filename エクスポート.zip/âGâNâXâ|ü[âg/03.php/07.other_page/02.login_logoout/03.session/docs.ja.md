---
title: $_SESSION(セッション変数)
taxonomy:
    category:
        - docs
---

参考サイト
: [PHP $_SESSION(セッション変数)のすべて！【初心者向け基本】](https://wepicks.net/phpref-session/)


## ログイン後のサイト表示

ログインしてるか確認してページを開くようにするには、
session変数customer（仮）に登録されてるかを確認する。

<p class="tmp"><span>書式</span>セッション時</p>
```
<?php session_start();
if (isset($_SESSION['customer'])) {
	//セッションされてるときの記述
}else{
	echo 'ログインしてください。';
}
```
