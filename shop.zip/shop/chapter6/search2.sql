select * from product where name like '%ナッツ%';
