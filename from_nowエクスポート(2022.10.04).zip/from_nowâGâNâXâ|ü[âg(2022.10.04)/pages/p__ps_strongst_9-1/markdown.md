*[page-title]:9-1. パスやシェイプのしくみ

## パスとシェイプってどう違うの? ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-01-1.jpg)](upload/9-01-1.jpg){.image}
</div>


## パスやシェイプはこうなっている ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-01-2.jpg)](upload/9-01-2.jpg){.image}
</div>


## パスやシェイプを描いたり、選択するためのツール ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-01-3.jpg)](upload/9-01-3.jpg){.image}
</div>
