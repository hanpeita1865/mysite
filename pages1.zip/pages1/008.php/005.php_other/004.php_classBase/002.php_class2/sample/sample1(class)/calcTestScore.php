<?php
$taroName = "たろう";
$taroMath = 87;
$taroEnglish = 92;
$taroJapanese = 74;
$taroSum = $taroMath + $taroEnglish + $taroJapanese;
$taroAve = $taroSum / 3;
print($taroName."さんの合計: ".$taroSum." 平均: ".$taroAve."<br>");

$hanakoName = "はなこ";
$hanakoMath = 95;
$hanakoEnglish = 79;
$hanakoJapanese = 83;
$hanakoSum = $hanakoMath + $hanakoEnglish + $hanakoJapanese;
$hanakoAve = $hanakoSum / 3;
print($hanakoName."さんの合計: ".$hanakoSum." 平均: ".$hanakoAve."<br>");
