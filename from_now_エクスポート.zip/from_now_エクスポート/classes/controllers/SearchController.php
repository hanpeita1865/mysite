<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Container\ContainerInterface;

require '../admin/basepath.php';

class SearchController
{
    // コンテナインスタンス
    private $container;

    // コンストラクタ
    public function __construct(ContainerInterface $container)
    {
        // 引数のコンテナインスタンスをプロパティに格納。
        $this->container = $container;
    }

    public function searchResult(Request $request, Response $response, array $args): Response
    {
        global $basePath;
        global $db;
        global $flag;
        global $countIp;
        global $lockData;
        global $lockArray;
        global $onlyArray;
        global $mdArray;
        global $searchFolder;


        if($_REQUEST['cate']==''){
            $searchFolder = '../pages';
        }else{
            $searchFolder = '../pages/'.$_REQUEST['cate'];
        }

        
        $flag = $request->getAttribute('flag');
        $motourl = $request->getAttribute('moto');
        $countIp = $request->getAttribute('countIp');


        $db = $this->container->get("db");

        //フォルダ構成をオブジェクトで取得
        $folderObj = $this->container->get("folderComp");

        $lockArray = []; 
        $array = [];

        $stmt = $db->prepare('select page, under_dir from locklist');
        $stmt->execute();
        $lockData = $stmt -> fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_GROUP);

        foreach($lockData as $key => $value){
            //ロックリストにメニューが存在する
            if(array_key_exists($key, $folderObj)){

                if($lockData[$key][0]=='all'){//一般ユーザーのメニューからは除外
                    $folder_dir = preg_quote($folderObj[$key], '/');//正規表現をクオートする
                    $dir_group = preg_grep('/'.$folder_dir.'/', $folderObj);
                    $lockArray = array_merge($lockArray, $dir_group);     

                }else{
                    //onlyの場合（緑のロック）
                    $onlyArray = [$key => $folderObj[$key]];
                }
            }
        }


        global $folderArray;

        $folderObj2  = $this->container->get("select_list");
        $folderArray = array_values($folderObj2);

    
        $folderObj = [];//ディレクトリ格納用オブジェクト
        $mdArray = [];
        $word = htmlspecialchars($_REQUEST['word']);
       
        foreach ($folderArray as $dir){

            $md = file_get_contents($_SERVER["DOCUMENT_ROOT"] . $basePath . '/pages/' . $dir . '/markdown.md');
            
            if(preg_match('/'.$word.'/',$md)){
                $mdArray[] = ['dir'=>$dir, 'md'=> $md];
            }
        }

        //マークダウン変換インスタンスをコンテナから取得
        $markData = $this->container->get("markHtml");
        $htmlData = $markData['html']; //HTMLデータ


        //管理者かどうかの判定値
        $assign["countIp"] = $countIp;
          //ディレクトリ名を格納
        $assign["pathBase"] = $basePath;

        $assign["htmlData"] = $htmlData;

        $assign["title"] = '検索結果';

        $menuData = $this->container->get("menuComp");
        $assign["menuData"] = $menuData; //メニューリスト
        $twig = $this->container->get("view");

        $response = $twig->render($response, "base.twig", $assign); 

        return $response;
    }

}    