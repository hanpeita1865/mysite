*[page-title]:3-2. フォーム関連のディレクティブ

フロントエンド開発において、フォームはエンドユーザーからの入力を受け取る代表的な手段です。 Vue.js はユーザーからの入力を受けて処理を開始し、その結果をテンプレートに反映します。そうした意味では、フォーム開発とは、Vue.js アプリ実行の基点、肝とも言えるでしょう。本節では、フォーム開発の基本となるしくみから、入力要素に応じた具体的な例を紹介していきます。

### 3-2-1 双方向データバインディング

Vue.js のフォーム開発について解説する前に、その前提知識となる<span class="green bold">双方向データバインディング</span>について解説しておきます。  
2-1-1 項などで説明したデータバインディングは、データオブジェクト⇒テンプレートの、いわゆる<span class="green bold">片方向データバインディング</span>です。しかし、双方向データバインディングでは、データオブジェクト⇒ テンプレートのデータ反映はもちろん、テンプレート(一般的にはテキストボックスなどの入力) ⇒デー タオブジェクトのデータ反映を可能にします。双方向データバインディングとは、データオブジェクトとテンプレートの状態を同期するしくみと言い換えてもよいでしょう。

![](upload/双方向データバインディング.png)

具体的な例も見てみましょう。たとえば以下は、テキストボックスに入力された名前に応じて、「こんにちは、○○さん!」というあいさつメッセージを生成するサンプルです。

<p class="tmp list"><span>リス3-17 / 3-18</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-17、3-18" src="https://codepen.io/hanpeita/embed/ZERzYvP?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/ZERzYvP">
  Vue3 リスト3-17、3-18</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/form.html

入力した名前によって、テキストが変わります。
![](upload/form_平尾さん!.png)

双方向データバインディングを実現しているのは、<span class="red">v-modelディレクティブ</span>です。「v-model="<span class="green bold">myName</span>"」 で、テキストボックスとデータオブジェクトの <span class="green bold">myName</span> プロパティを紐付けているわけです。初期状態で、 データオブジェクト側の値がテキストボックスに反映されること、テキストボックスへの入力がデータオブジェクトに反映され、文字列「こんにちは、●○さん!」が更新されることを確認しておきましょう。

<div markdown="1" class="note-box">
#####  value 属性は無視される

v-model を利用した場合、テキストボックスの初期値は紐付いたプロパティの値となります。 value 属性を指定しても「Template compilation error: Unnecessary value binding used alongside v-model. It will interfere with v-model's behavior」（value 属性が v-model の 挙動を邪魔しています）のような警告が発生し、設定値も無視されるので、注意してください。 ラジオボタンまたはチェックボックスの checked 属性、選択ボックスまたはリストボックスの selected 属性も同様で、v-model を利用した場合は無視されます。
</div>

以上、双方向データバインディングの基本を理解したところで、ここからはよく利用されるフォーム 要素をデータオブジェクトと連結する例を見ていきます。  
なお、&lt;input&gt;要素では type 属性を変更することで、数値スピナー、日付入力ボックスなどを表現できます。が、これらはすべて標準的なテキストボックスと同じように処理できるので、本書では解説を割愛します。

![](upload/フォーム要素（type属性）.png)

http://localhost:7001/from_now/trunk/pages/p__veu_3_chap3-2/sample/type/

### 3-2-2 ラジオボタン 

ラジオボタンでは、すべての選択オプションに対して、同一の v-model を渡すのがポイントです。これによって、v-model の値と value 属性が等しいオプションが選択状態になります。

<p class="tmp list"><span>リスト3-19 / 3-20</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-19、3-20" src="https://codepen.io/hanpeita/embed/NWzKPzz?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/NWzKPzz">
  Vue3 リスト3-19、3-20</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

http://localhost:7008/chap03/model_radio.html

ラジオボタンの選択値のテキストが表示される 
![](upload/model_radio選択結果.png)


チェックボックスは、単一でオン/オフを表す場合と、リストで複数選択オプションを表す場合とがあります。 まずは、オン/オフを表す場合です。

<p class="tmp list"><span>リスト3-21 / 3-22</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-21、3-22" src="https://codepen.io/hanpeita/embed/abKozaz?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/abKozaz">
  Vue3 リスト3-21、3-22</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

http://localhost:7008/chap03/model_check.html

![](upload/model_check_true.png "図 チェックを入れた場合")
![](upload/model_check_false.png "図 チェックをはずした場合")

### 3-2-4 チェックボックス (複数)

複数のチェックボックスを並べる場合には、ラジオボタンの場合と同じく、これらすべてに対して同一の v-model を渡します。

<p class="tmp list"><span>リスト3-23 / 3-24</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-23、3-24" src="https://codepen.io/hanpeita/embed/abKozRO?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/abKozRO">
  Vue3 リスト3-23、3-24</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

http://localhost:7008/chap03/model_check_multi.html
![](upload/model_check_multi.png)

チェックボックスが複数選択された場合には、プロパティにも複数の値が配列として格納されます。
![](upload/model_check_multi_複数.png)


### 3-2-5 選択ボックス

選択ボックスは、ほぼ特筆すべき点はありません。&lt;select&gt;要素に v-model を指定するだけです。

<p class="tmp list"><span>リスト3-25 / 3-26</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-25、3-26" src="https://codepen.io/hanpeita/embed/BaVByvr?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/BaVByvr">
  Vue3 リスト3-25、3-26</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/model_select.html


複数選択を可能にした場合に、プロパティには配列が格納される点はチェックボックスと同じです。

<p class="tmp list"><span>リスト3-27 / 3-28</span></p>
CTRLキーで複数選択できます。
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-27、3-28" src="https://codepen.io/hanpeita/embed/zYaOxex?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/zYaOxex">
  Vue3 リスト3-27、3-28</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/model_select_multi.html

![](upload/model_select_multi.png)


### 補足:オブジェクトをバインドする

ラジオボタンやチェックボックス、選択ボックスなどには、文字列だけでなくオブジェクトを引き渡すこともできます。

<p class="tmp list"><span>リスト3-29 / 3-30</span></p>
選択すると、コンソールログに値が表示されます。
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-29、3-30" src="https://codepen.io/hanpeita/embed/PoaYPaP?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/PoaYPaP">
  Vue3 リスト3-29、3-30</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/model_obj.html

value 属性にバインドしたオブジェクトがログにも反映されていることが確認できます。選択ボックスであれば、オブジェクトは &lt;option&gt;要素の value 属性にバインドします
![](upload/model_obj.png)

## 3-2-6 ファイル入力ボックス

他のフォーム要素と異なり、ファイル入力ボックスはアプリから値が設定されることはありません （ユーザーが指定した値をアプリが受け取るだけで、アプリが特定のファイルを指定することはできません）。よって、双方向データバインディングという概念もなく、change などのイベントを受けて処理を実行します。

<p class="tmp list"><span>リスト3-31</span></p>
```
<div id="app">
  <form>
    <input ref="upfile" type="file" v-on:change="onchange" /><!-- (1) -->
  </form>
  <div>{{ message }}</div>
</div>
```

<p class="tmp list"><span>リスト3-32</span></p>
```
Vue.createApp({
  data() {
    return {
      message: ''
    };
  },
  methods: {
    onchange() {
      //アップロードファイルを準備
      const fl = this.$refs.upfile.files[0];
      const data = new FormData();
      data.append('upfile', fl, fl.name);
      //サーバーにデータを送信
      fetch('upload.php', { 
        method: 'POST',
        body: data,
      })
      //成功時に結果を表示
      .then(response => response.text())
      .then(text => {
        this.message = text;
      })
      //失敗時にはエラーメッセージをダイアログで表示
      .catch(error => {
        window.alert(`Error: ${error.message}`);
      });
    }
  }
}).mount('#app');
```
http://localhost:7008/chap03/model_file.html


&lt;input type="file"&gt;要素には、後でイベントハンドラーからアクセスできるように、ref 属性で名前を付けておきます(1)。ref 属性は Vue.js で予約された特殊な属性で、ここで命名された要素は、イベントハンドラーなどから「this.$refs. 名前」の形式でアクセスできるようになります。
![](upload/model_file.png "図 指定したファイルをアップロード後")

<div markdown="1" class="note-box">
##### ref 属性の意味
要素にアクセスするのであれば、id、name、class 属性をキーに document.getElementById などのメソッドを利用すればよい、と思われるかもしれません。 それは可能ですが、望ましくありません。というのも、id、name、class 属性を利用するということは、コードの側がテンプレートの構造を把握していなければならない、ということだからです。それは、ソフトウェア工学における「関心の分離」という観点からも望ましくありませんし、単体テストを難しくする要因ともなります。 しかし、ref 属性を利用することで、コード側は this.$refs を介して、要素オブジェクトが渡ってくることだけを意識すればよいので、コードがよりシンプルになります。テンプレートとコードとは、まずはデータオブジェクトでもってデータ交換すべきですが、やむを得ず、要素にアクセスしたい場合にも ref 属性を利用するようにしてください。※1

※1 ただし、その場合も $refs 経由でデータを更新してはいけません(参照に限定すべきです)。
</div>

$refs 経由で取得した &lt;input type="file"&gt; 要素からは、files プロパティを参照することで指定されたファイルを取得できます。  
files プロパティは、戻り値としてアップロードされたファイル群を、FileList オブジェクトとして返します（アップロードされたファイルがひとつであったとしても FileList です）。ここでは、ファイルがひとつであることを前提としているので、決め打ちでリスト先頭のファイル (File オブジェクト) を取得します。
![](upload/アップロード処理の流れ.png)

ただし、File オブジェクトのままではアップロードできないので、送信のための形式(FormData オブジェクト)に変換しておきます。 FormData は、multipart/form-data 形式のフォームデータを、 キーと値の形式で表現します。 FormData にファイル(データ)を追加するのは、append メソッドの役割です。

※複数のファイルを選択できるようにするには、&lt;input type="file"&gt;要素で、multi属性を指定します。

<p class="tmp"><span>書式</span>appendメソッド</p>
```
form.append(name, value [,file])

form: FormDataオブジェクト
name: キー名
value: 値
file: ファイル名
```

以上でファイルを送信するための準備は完了です。後は、fetch メソッドで、サーバー(upload. php)にデータを送信するだけです。fetch メソッドについては 11-3-4 項で詳しく解説するので、ここではアップロードデータは body オプションに渡す、とだけ覚えておきましょう。送信先の upload. php については、本書の守備範囲を外れるので、解説は割愛します。完全なコードは、ダウンロードサンプルを参照してください。


## 3-2-7 バインドの動作オプションを設定する

v-model ディレクティブではさまざまな修飾子が用意されており、バインド時の挙動を細かく制御できるようになっています。修飾子とは、ディレクティブ(属性名)の後方に、ピリオド(.)区切りで 付与する追加情報です。  
たとえば「v-model.number="..."」のように表します。「v-model.number. lazy」のように、複数連結しても構いません。

### 入力値を数値としてバインドする - <span class="green">.number 修飾子</span>
.number 修飾子を利用することで、テキストボックスへの入力値を(文字列ではなく)数値としてプロパティにバインドできます。ユーザーからの入力値は、既定で文字列と見なされますが、.number 修飾子を利用することで、コード側での数値変換が不要になります。

※コンソールに表示されます。
<p class="tmp list"><span>リスト3-33 / 3-34</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-31、3-32" src="https://codepen.io/hanpeita/embed/PoaYPyZ?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/PoaYPyZ">
  Vue3 リスト3-31、3-32</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/model_number.html

温度を入力して、欄外をクリックすると、コンソールに入力温度が表示されます。
![](upload/model_number.png)

### 入力値の前後の空白を除去する -<span class="green"> .trim 修飾子</span>
 .trim 修飾子を利用することで、入力値をプロパティにバインドする前に、前後の空白を除去できます。 以下は、入力された文字列から空白を除去したうえで、ログに出力する例です。

<p class="tmp list"><span>リスト3-35 / 3-36</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-35、3-36" src="https://codepen.io/hanpeita/embed/poKzgxq?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/poKzgxq">
  Vue3 リスト3-35、3-36</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/model_trim.html

![](upload/model_trim_前.png)
↓前後の空白が削除される
![](upload/model_trim_後.png)

## 3-2-8 バインドのタイミングを遅延させる - .lazy 修飾子

v-model によるバインドの既定タイミングは inputイベントの発生時です。つまり、キー入力のタイミングで即座にバインドします。これを changeイベント――変更後、<span class="red">フォーム要素からフォーカスが 移動したタイミング</span>でバインドさせるのが、<span class="green bold">.lazy 修飾子</span>の役割です。

<p class="tmp list"><span>リスト3-37 / 3-38</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-37、3-38" src="https://codepen.io/hanpeita/embed/OJELMqv?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/OJELMqv">
  Vue3 リスト3-37、3-38</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/model_lazy.html

![](upload/model_lazy_前.png)
↓入力して欄外をクリックすると反映される
![](upload/model_lazy_後.png)

### 3-2-9 双方向データバインドのカスタマイズ

双方向データバインドの理解を深めるために、最後に v-model を利用せずに双方向データバインドを 実装してみましょう。
v-model ディレクティブは、内部的には、v-bind や v-on: input の別記法です。よって、以下の2行のコー ドは意味的に等価です。
```
<input v-model="str" />
<input v-bind:value="str" v-on:input="str=Sevent.target.value" />
```
input イベントで、入力値($event.target.value) を str プロパティにバインドし、value 属性に strプロパティをバインドしているわけです。もちろん、一般的には v-model を使ったほうがシンプル ですが、v-model では事足りない場合があります。  
それは、入力された値をプロパティにバインドする際になんらかの処理を挟みたい場合です。そのような場合には、v-bind:value や v-on: input の組み合わせを利用します。  
たとえば以下は、入力されたメールアドレス(セミコロン区切り)を分割し、配列として mails プロ パティに反映させる例です(本来であれば、算出プロパティなどを利用すべきです。

<p class="tmp list"><span>リスト3-39 / 3-40</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-39、3-40" src="https://codepen.io/hanpeita/embed/PoaYNYR?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/PoaYNYR">
  Vue3 リスト3-39、3-40</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/model_custom.html

※末尾にセミコロンをつけると、リストになって●がつきます。
![](upload/model_custom.png)


<p class="tmp list"><span>リスト3-39</span></p>
```
<div id="app">
  <form>
    <label for="mail">メールアドレス：</label>
    <textarea id="mail"
      v-bind:value="mails.join(';')" //-----(2)
      v-on:input="mails=$event.target.value.split(';')"></textarea> //-----(1)
  </form>
  <ul>
    <li v-for="mail in mails"> //----------(3)ここから
      {{ mail }}
    </li> //------------------//-----------(3)ここまで
  </ul>
</div>
```

まず、(1)が「テンプレート→データオブジェクト」方向のデータの流れです。入力されたセミコロン 区切りの文字列を split メソッドで分割し、mails プロパティに反映させます。  
配列化された mails プロパティの内容は、(2)で再び join メソッドで連結したうえで、&lt;textarea&gt;要素にバインドしています。「データオブジェクト→テンプレート」方向の流れです。  
(1)、(2)の組み合わせによって、v-model 相当の双方向データバインディングを実装していることを確認してください。  
なお、v-for による配列の展開③については、この後に解説します。ここでは、配列をもとに &lt;ul&gt; / &lt;li&gt; リストを作成している、とだけ理解しておきましょう。
