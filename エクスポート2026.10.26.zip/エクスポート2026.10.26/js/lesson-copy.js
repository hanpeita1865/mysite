// ==================================================
// コード問題：JavaScript実行
// ==================================================

document.querySelectorAll('.code-run').forEach(button => {

    button.addEventListener('click', () => {

        const questionId = button.dataset.questionId;

        const textarea = document.querySelector(
            `.code-input[data-question-id="${questionId}"]`
        );

        const output = document.querySelector(
            `.code-output[data-question-id="${questionId}"]`
        );

        const hidden = document.querySelector(
            `.code-output-hidden[data-question-id="${questionId}"]`
        );

        if (!textarea || !output || !hidden) {
            return;
        }

        const code = textarea.value;

        // 実行結果をいったんクリア
        output.textContent = '実行中...';
        hidden.value = '';

        // JavaScriptを実行するiframe
        const iframe = document.createElement('iframe');

        // JavaScriptだけ実行できるsandbox
        iframe.sandbox = 'allow-scripts';
        iframe.style.display = 'none';

        /*
         * iframe内で実行するHTML
         *
         * console.log()の内容をresult配列に保存し、
         * 実行終了後にpostMessage()で親ページへ送る
         */
        const iframeHtml = `
            <!DOCTYPE html>
            <html>
            <body>
            <script>
                (() => {

                    const result = [];

                    // console.log()を上書き
                    console.log = (...args) => {
                        result.push(args.map(String).join(' '));
                    };

                    try {

                        // ユーザーが入力したJavaScript
                        ${code}

                        // 実行結果を親ページへ送る
                        window.parent.postMessage({
                            type: 'code-result',
                            questionId: '${questionId}',
                            result: result
                        }, '*');

                    } catch (error) {

                        // JavaScriptエラーを親ページへ送る
                        window.parent.postMessage({
                            type: 'code-error',
                            questionId: '${questionId}',
                            message: error.message
                        }, '*');

                    }

                })();
            <\/script>
            </body>
            </html>
        `;

        // iframeにHTMLを設定
        iframe.srcdoc = iframeHtml;

        document.body.appendChild(iframe);

        /*
         * iframeを3秒後に削除
         */
        setTimeout(() => {

            if (iframe.parentNode) {
                iframe.remove();
            }

        }, 3000);
    });
});


// ==================================================
// コード問題：iframeから実行結果を受け取る
// ==================================================

window.addEventListener('message', event => {

    if (!event.data) {
        return;
    }

    const data = event.data;

    // コード問題以外のmessageは無視
    if (data.type !== 'code-result' &&
        data.type !== 'code-error') {

        return;
    }

    const questionId = data.questionId;

    const output = document.querySelector(
        `.code-output[data-question-id="${questionId}"]`
    );

    const hidden = document.querySelector(
        `.code-output-hidden[data-question-id="${questionId}"]`
    );

    if (!output || !hidden) {
        return;
    }


    // ----------------------------------------------
    // 正常終了
    // ----------------------------------------------

    if (data.type === 'code-result') {

        const result = data.result || [];

        // 実行結果を画面に表示
        output.textContent = result.join('\n');

        // 回答送信用にJSONとして保存
        hidden.value = JSON.stringify(result);
    }


    // ----------------------------------------------
    // JavaScriptエラー
    // ----------------------------------------------

    if (data.type === 'code-error') {

        const errorMessage = `エラー: ${data.message}`;

        // エラーを画面に表示
        output.textContent = errorMessage;

        // 回答送信用にも保存
        hidden.value = JSON.stringify([
            `ERROR: ${data.message}`
        ]);
    }

});


// ==================================================
// クイズフォーム
// ==================================================

// const quizForm = document.getElementById('quiz-form');

// if (quizForm) {

//     quizForm.addEventListener('submit', event => {

//         /*
//          * コード問題がある場合、
//          * 「実行」してから回答する
//          */
//         const codeInputs = document.querySelectorAll('.code-input');

//         let notExecuted = false;

//         codeInputs.forEach(textarea => {

//             const questionId = textarea.dataset.questionId;

//             const hidden = document.querySelector(
//                 `.code-output-hidden[data-question-id="${questionId}"]`
//             );

//             if (!hidden || hidden.value === '') {
//                 notExecuted = true;
//             }
//         });

//         if (notExecuted) {

//             event.preventDefault();

//             alert('コード問題は「実行」してから回答してください。');

//             return;
//         }
//     });
// }



// ==================================================
// コード実行部分　追加
// ==================================================

const CODE_EXECUTION_LIMIT = 3000;

const runningCode = new Map();

document.addEventListener('DOMContentLoaded', function () {
    
    initCodeFrames();//追加

    const runButtons = document.querySelectorAll('.code-run');

    runButtons.forEach(function (button) {

        button.addEventListener('click', function () {

            const questionId = button.dataset.questionId;
            
            const input = document.querySelector(
                '.code-input[data-question-id="' + questionId + '"]'
            );

            if (!input) {
                return;
            }

            const code = input.value;

            const iframe = document.querySelector(
                '.code-frame[data-question-id="' + questionId + '"]'
            );

            if (iframe) {
                runCodeInIframe(questionId, code, iframe);
            } else {
                runCodeInWorker(questionId, code);
            }
        });
    });


    const form = document.getElementById('quiz-form');

    if (form) {

        form.addEventListener('submit', function (event) {

            const hiddenOutputs =
                document.querySelectorAll('.code-output-hidden');

            let hasUnexecutedCode = false;

            hiddenOutputs.forEach(function (hidden) {

                if (hidden.value === '') {
                    hasUnexecutedCode = true;
                }

            });

            if (hasUnexecutedCode) {
                event.preventDefault();

                alert('コードを実行してから回答してください。');
            }

        });

    }

});



//Web Worker 実行用
function runCodeInWorker(questionId, code) {

    stopRunningCode(questionId);

    const output = document.querySelector(
        '.code-output[data-question-id="' + questionId + '"]'
    );

    const hidden = document.querySelector(
        '.code-output-hidden[data-question-id="' + questionId + '"]'
    );

    const codeHidden = document.querySelector(
        '.code-hidden[data-question-id="' + questionId + '"]'
    );

    if (!output || !hidden || !codeHidden) {
        return;
    }

    output.textContent = '実行中...';

    codeHidden.value = code;

    const workerSource = `
        self.onmessage = function (event) {

            const code = event.data.code;
            const result = [];

            console.log = function () {

                const values = Array.prototype.slice.call(arguments);

                result.push(
                    values.map(function (value) {
                        return String(value);
                    }).join(' ')
                );

            };

            try {

                new Function(code)();

                self.postMessage({
                    type: 'result',
                    result: result
                });

            } catch (error) {

                self.postMessage({
                    type: 'error',
                    message: error.message
                });

            }

        };
    `;

    const blob = new Blob(
        [workerSource],
        { type: 'application/javascript' }
    );

    const workerUrl = URL.createObjectURL(blob);
    const worker = new Worker(workerUrl);

    const timeoutId = setTimeout(function () {

        worker.terminate();
        URL.revokeObjectURL(workerUrl);

        runningCode.delete(questionId);

        output.textContent =
            '実行時間が3秒を超えたため、処理を停止しました。';

        hidden.value = JSON.stringify([
            'ERROR: 実行時間超過'
        ]);

    }, CODE_EXECUTION_LIMIT);


    runningCode.set(questionId, {
        worker: worker,
        timeoutId: timeoutId,
        workerUrl: workerUrl
    });


    worker.onmessage = function (event) {

        clearTimeout(timeoutId);

        worker.terminate();
        URL.revokeObjectURL(workerUrl);

        runningCode.delete(questionId);

        if (event.data.type === 'result') {

            const result = event.data.result;

            output.textContent = result.join('\n');

            hidden.value = JSON.stringify(result);

        } else {

            output.textContent =
                'エラー：' + event.data.message;

            hidden.value = JSON.stringify([
                'ERROR: ' + event.data.message
            ]);

        }

    };


    worker.onerror = function (event) {

        clearTimeout(timeoutId);

        worker.terminate();
        URL.revokeObjectURL(workerUrl);

        runningCode.delete(questionId);

        output.textContent =
            'エラーが発生しました。';

        hidden.value = JSON.stringify([
            'ERROR: ' + event.message
        ]);

    };


    worker.postMessage({
        code: code
    });

}



//iframe実行用
function runCodeInIframe(questionId, code, iframe) {

    stopRunningCode(questionId);

    const output = document.querySelector(
        '.code-output[data-question-id="' + questionId + '"]'
    );

    const hidden = document.querySelector(
        '.code-output-hidden[data-question-id="' + questionId + '"]'
    );

    const codeHidden = document.querySelector(
        '.code-hidden[data-question-id="' + questionId + '"]'
    );

    if (!output || !hidden || !codeHidden) {
        return;
    }

    codeHidden.value = code;

    hidden.value = '';
    output.textContent = '実行中...';


    /*
     * iframeからのメッセージを受け取る
     */
    const receiveMessage = function (event) {

        if (event.source !== iframe.contentWindow) {
            return;
        }

        if (!event.data) {
            return;
        }


        /*
         * DOM変更・console.log()の結果
         */
        if (event.data.type === 'code-result') {

            const result = event.data.result || [];

            hidden.value = JSON.stringify(result);

            output.textContent =
                result.length > 0
                    ? result.join('\n')
                    : '出力なし';

            return;
        }


        /*
         * JavaScript実行完了
         */
        if (event.data.type === 'code-executed') {
            return;
        }


        /*
         * JavaScriptエラー
         */
        if (event.data.type === 'code-error') {

            clearTimeout(timeoutId);

            window.removeEventListener(
                'message',
                receiveMessage
            );

            runningCode.delete(questionId);

            const message =
                'ERROR: ' + event.data.message;

            hidden.value = JSON.stringify([message]);

            output.textContent =
                'エラー：' + event.data.message;
        }

    };


    window.addEventListener(
        'message',
        receiveMessage
    );


    /*
     * 3秒経過したらiframeを終了
     */
    const timeoutId = setTimeout(function () {

        window.removeEventListener(
            'message',
            receiveMessage
        );

        runningCode.delete(questionId);

        iframe.srcdoc = '';

        hidden.value = JSON.stringify([
            'ERROR: 実行時間超過'
        ]);

        output.textContent =
            '実行時間が3秒を超えたため、処理を停止しました。';

    }, CODE_EXECUTION_LIMIT);


    runningCode.set(questionId, {
        iframe: iframe,
        timeoutId: timeoutId
    });


    /*
     * iframeへコードを送る
     */
    iframe.contentWindow.postMessage({
        type: 'run-code',
        code: code
    }, '*');

}



//共通の停止処理コード
function stopRunningCode(questionId) {

    const running = runningCode.get(questionId);

    if (!running) {
        return;
    }

    clearTimeout(running.timeoutId);

    if (running.worker) {
        running.worker.terminate();
        URL.revokeObjectURL(running.workerUrl);
    }

    if (running.iframe) {
        running.iframe.srcdoc = '';
    }

    runningCode.delete(questionId);
}


//iframeを初期化
function initCodeFrames() {

    const frames = document.querySelectorAll('.code-frame');

    frames.forEach(function (iframe) {

        const html = iframe.dataset.html || '';

        const iframeHtml = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body {
                        font-family: sans-serif;
                        padding: 10px;
                    }

                    button {
                        margin-top: 10px;
                    }
                </style>
            </head>

            <body>

                ${html}

                <script>

                    (function () {

                        let domChanges = [];

                        /*
                         * console.log()の結果
                         */
                        console.log = function () {

                            const values =
                                Array.prototype.slice.call(arguments);

                            domChanges.push(
                                values.map(function (value) {
                                    return String(value);
                                }).join(' ')
                            );

                            sendResult();

                        };


                        /*
                         * DOMの変更を監視
                         */
                        const observer =
                            new MutationObserver(function (mutations) {

                                mutations.forEach(function (mutation) {

                                    if (mutation.type === 'characterData') {

                                        const value =
                                            mutation.target.textContent.trim();

                                        if (value !== '') {
                                            domChanges.push(value);
                                        }

                                    }

                                    if (mutation.type === 'childList') {

                                        mutation.addedNodes.forEach(
                                            function (node) {

                                                if (
                                                    node.nodeType === 3 &&
                                                    node.textContent.trim() !== ''
                                                ) {

                                                    domChanges.push(
                                                        node.textContent.trim()
                                                    );

                                                }

                                            }
                                        );

                                    }

                                });

                                sendResult();

                            });


                        observer.observe(document.body, {
                            childList: true,
                            characterData: true,
                            subtree: true
                        });


                        /*
                         * 親ページへ結果を送る
                         */
                        function sendResult() {

                            window.parent.postMessage({
                                type: 'code-result',
                                result: domChanges
                            }, '*');

                        }


                        /*
                         * 親ページからコードを受け取る
                         */
                        window.addEventListener(
                            'message',
                            function (event) {

                                if (!event.data) {
                                    return;
                                }

                                if (event.data.type !== 'run-code') {
                                    return;
                                }

                                const code = event.data.code;

                                try {

                                    new Function(code)();

                                    window.parent.postMessage({
                                        type: 'code-executed'
                                    }, '*');

                                } catch (error) {

                                    window.parent.postMessage({
                                        type: 'code-error',
                                        message: error.message
                                    }, '*');

                                }

                            }
                        );

                    })();

                <\/script>

            </body>
            </html>
        `;

        iframe.srcdoc = iframeHtml;

    });

}