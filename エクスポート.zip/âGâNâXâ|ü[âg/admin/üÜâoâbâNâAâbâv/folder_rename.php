<?php
$post_dir = $_POST['post_dir'];
$post_redir = $_POST['post_redir'];

//半角英数字記号かを判定
if(preg_match("/^[!-~]+$/", $post_redir) ){
    //フォルダ名変更
    rename('../pages/' . $post_dir, '../pages/' . $post_redir);
    //メニューのフォルダ名変更
    $menu = file_get_contents('../templates/layouts/menu_list.twig');

    $menu_re = preg_replace('/'.$_POST['post_folderName'].'\/"(.*)>/i', $_POST['post_folderReName'].'/"$1>', $menu);
    file_put_contents('../templates/layouts/menu_list.twig', $menu_re);

    echo 'フォルダ名を変更しました。';
}else{
    echo '半角英数字記号で入力してください。';
}

?>
