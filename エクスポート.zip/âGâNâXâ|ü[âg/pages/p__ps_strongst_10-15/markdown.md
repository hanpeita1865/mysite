*[page-title]:10-15. 画像をぼかしてみよう

## ぼかし（ガウス）フィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-15-1.jpg)](upload/10-15-1.jpg){.image}
</div>

## ぼかし（レンズ）フィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-15-2.jpg)](upload/10-15-2.jpg){.image}
</div>

## その他のぼかしフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-15-3.jpg)](upload/10-15-3.jpg){.image}
</div>

## ぼかしギャラリー ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-15-4.jpg)](upload/10-15-4.jpg){.image}
</div>