Vue.createApp({
}).mount('#app');