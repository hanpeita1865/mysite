<h3>フォルダ内にある直下のフォルダ名だけを表示</h3>
<ul>
<?php
	//$dir = '../pages/';

	$folder = glob('../pages/*', GLOB_ONLYDIR);

    $num = 1;

	foreach ($folder as $dir) {
		//echo '<li><span class="filename">'.$dir.'/</span></li>';

        $md = file_get_contents($dir.'/markdown.md'); //マークダウンの内容を変数に格納
        preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);

        echo '<li id="'.$num.'" draggable="true">';
        echo '<a href="'.$dir.'/">'.$ArrayTitle[1].'</a>';
        echo '</li>';

        $num++;
	}
?>
</ul>
