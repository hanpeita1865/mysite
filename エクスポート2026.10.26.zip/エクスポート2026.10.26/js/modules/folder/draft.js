import { Api } from '../api.js';
import { show, hide } from '../modalManager.js';

export function initDraft({ soating, completeMsg }) {

    let currentFolderName = null;
    let listDir = null;   
    let currentDraftBtn = '';
    let pageName = null;

    document.addEventListener('click', async (e) => {

        if (soating()) {
            show('soatWarn');
            return;
        }
        
        //下書き設定モーダル表示      
        const btn = e.target.closest('.btn-draft');
        if (!btn) return;

        // ★ in-use が付いていたら無効化
        if (btn.classList.contains('in-use')) {
            return; // 何もせず終了
        }
        
        currentDraftBtn = e.target;

        const modal = document.getElementById('draftModal');
        
        listDir = e.target.closest('.box-item').children[0].getAttribute('href');
        currentFolderName = listDir.split('/').slice(-2)[0];          
        pageName = e.target.closest('.box-item').children[0].textContent;
            
        show('draftModal'); 
    });

    // モーダル内 設定ボタン
    const draftSet = document.getElementById('draft-set');

    if(draftSet){
        draftSet.addEventListener('click', async () => {

            const fd = new FormData();
            fd.append('listDir', listDir);
            fd.append('folderName', currentFolderName);
            fd.append('title', pageName);
            //追加
            const csrfToken = document.getElementById('csrf_token').value;
            fd.append('csrf_token', csrfToken);
            
            try {
                const data = await Api.postJSON('../public/admin/draft_set', fd);

                // ボタン表示変更
                if(data.success){
                    if (currentDraftBtn) {
                        currentDraftBtn.classList.add('is-use');
                        currentDraftBtn.textContent = '下書き中';
                    }                    
                }
                    
                completeMsg(data.message);

            } catch {
                alert('失敗しました');
            }        
            
            hide('draftModal');
        });
    }
}