*[page-title]:要素の幅と高さを取得

参考サイト
: [JavaScriptで特定の要素の幅と高さを取得する方法(clientWidth,clientHeight)](https://www.imamura.biz/blog/26906)