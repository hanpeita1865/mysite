<?php require '../header.php'; ?>
<?php
echo rand();
?>
<?php require '../footer.php'; ?>
