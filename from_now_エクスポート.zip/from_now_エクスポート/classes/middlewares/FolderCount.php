<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;

class FolderCount implements MiddlewareInterface {
    private $container;

    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {

        $pagesObj = $this->container->get("folderComp"); //pagesオブジェクト
        $folderCnt = count($pagesObj);
        // print_r($folderCnt);

        $request = $request->withAttribute('count', $folderCnt);

        $response = $handler->handle($request);

        return $response;
    }
}