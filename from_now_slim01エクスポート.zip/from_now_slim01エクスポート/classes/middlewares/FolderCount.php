<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\Services\{
    FolderService,
};

class FolderCount implements MiddlewareInterface {
    
    private $container;
    private FolderService $folderService;

    public function __construct(FolderService $folderService, ContainerInterface $container) {
        $this->container = $container;
        $this->folderService = $folderService;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {

        $pagesObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）
        $folderCnt = count($pagesObj);

        $request = $request->withAttribute('count', $folderCnt);
        $response = $handler->handle($request);

        return $response;
    }
}