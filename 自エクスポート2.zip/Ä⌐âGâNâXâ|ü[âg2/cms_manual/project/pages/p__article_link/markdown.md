*[page-title]:リンク配置

## ファイルリンクを設置

### ファイルの登録

まず、PDF、WORD、EXCELなどのファイルのアップロードを行います。  
添付ファイル用の欄にある<kbd class="border border-secondary">ファイルを選択</kbd>ボタンから、アップロードするファイルを選択します。

<div markdown="1" class="d-flex justify-content-start align-items-center">
![](upload/選択前のボックス.png "図　添付ファイル欄の「ファイルを選択」ボタンをクリック")
<p class="d-flex flex-column align-items-center mx-3"><span class="fz-16">➡</span></p>
![](upload/ファイルを選択.png "図　ファイルが選択されました")
</div>

他にもアップロードしたいファイルがあれば選択しておいてから、右端にある<kbd class="border border-secondary">先にアップロード</kbd>ボタンを押します。  
ページが更新され、下のようにアップロードしたファイル名とリンクが表示されます。  
これで仮のアップロードは完了しました。  
（※確認画面でページ編集を確定せず、ここで編集を中止すると仮アップロードしたファイルは自動的に削除されます。）

![](upload/仮のアップロード完了.png "図　仮アップロード完了")


### 本文内にファイルリンクの設置

本文内に挿入する前にリンク名を変更しておきます。  
ファイル名のままでよければ、そのままでいいです。また、挿入した後からでも変更はできます。
![](upload/ファイルリンク名の変更.png)

本文内のリンクを挿入したい箇所（「お申し込みは」の後ろ）にカーソルを持っていき、<kbd class="border border-secondary">本文内に挿入</kbd>ボタンを押します、
![](upload/企業説明会リンク挿入前.png "図　ファイルリンク挿入箇所を指定")
<p class="d-flex flex-column align-items-center"><span class="fz-16 rotate90">➡</span></p>
これで、ファイルリンクの挿入ができました。
![](upload/企業説明会リンク挿入後.png "図　ファイルリンクの挿入完了")


### リンク名を変更

挿入した後にリンク名を変更します。  
コピー&ペーストで書き替える時は、対象のリンクに先頭の一文字だけを残して、その後ろを選択してから貼り付けます。  
直接テキストを書き替える時は、先頭と最後尾の文字だけを残したまま記入した後に先頭と最後尾の文字を削除します。  
手間ですが、この方法でないと追加した文字がリンクになりません。

では、実際に書き替えてみます。  
例えば、 

<span class="bold">企業説明会参加申込書兼連絡票</span>　→　<span class="bold">合同研修会説明資料</span>

のように書き替えるとして、 

#### 貼り付けの方法の場合 ####{.green}
「合同研修会説明資料」の文字をいつも通りの方法でコピーしたあと、

* 先頭の「企」だけ残して他の文字を選択します。
<div markdown="1" class="figure-my-0">
![](upload/ペースト一文字残して選択.png)
</div>
<p class="d-flex align-items-center"><span class="fz-16 rotate90 ml-5">➡</span></p>
* 先頭の１文字残して貼り付けます。
<div markdown="1" class="figure-my-0">
![](upload/ペースト一文字残して貼り付け.png)
</div>
<p class="d-flex align-items-center"><span class="fz-16 rotate90 ml-5">➡</span></p>
* 最後に前のリンク名の先頭の文字を削除します。
<div markdown="1" class="figure-mt-0">
![](upload/ペースト貼り付け完了.png)
</div>

通常のペースト方法だとスタイルも付いてきてリンクにならないこともあるので、そのときは「<kbd class="border border-secondary">Shift</kbd>+<kbd class="border border-secondary">Ctrl</kbd>+<kbd class="border border-secondary">V</kbd>」を同時に押してペーストしてください。

#### 直接リンク名を書き替える方法の場合 ####{.purple}

* 先頭と最後の１文字ずつ残して選択します。
<div markdown="1" class="figure-my-0">
![](upload/書き替え間の文字を選択.png)
</div>
<p class="d-flex align-items-center"><span class="fz-16 rotate90 ml-5">➡</span></p>
* 選択した文字を削除します。
<div markdown="1" class="figure-my-0">
![](upload/書き替え間の文字を削除.png)
</div>
<p class="d-flex align-items-center"><span class="fz-16 rotate90 ml-5">➡</span></p>
* 間に新しいリンク名を記入します。
<div markdown="1" class="figure-my-0">
![](upload/書き替え間に文字を記入.png)
</div>
<p class="d-flex align-items-center"><span class="fz-16 rotate90 ml-5">➡</span></p>
* 残った以前のリンク名の前後の１文字ずつを削除して完了です。
<div markdown="1" class="figure-mt-0">
![](upload/書き替え間に文字を記入完了.png)
</div>


## リンクの挿入

### 外部サイトのリンクを貼り付ける
別のサイトのリンクなどを貼り付けたい時は、挿入したい箇所にカーソルを持って行った後、ツールバーのリンクアイコン![](upload/リンクアイコン単独.png){.figure-none}をクリックします。

そうすると、カーソルのそばにURLを記入するポップアップがでます。
![](upload/外部リンク空ポップアップ.png)

そこのURL入力欄にリンクを記入して、右横のチェックマークボタン![](upload/リンクチェックマークボタン.png){.figure-none}をクリックするか、<kbd class="border border-secondary">Enter</kbd>キーを押します。
![](upload/外部リンクURL記入.png)

これでリンクが挿入されます。
![](upload/外部リンクリンク挿入.png)

リンク名を変更する場合は、先述のファイルリンクの時と同じやり方で、行ってください。  
ただし、同一ドメインになるので、別ウインドウで開くのではなく、ページ遷移になります。

### ページ内リンク設定

移動先のページの見出しなどにid属性が設置してあれば、開いたときその位置までスクロールしてくれます。  

貼り付けたリンクをクリックし、表示されたボックス内のペンアイコン![](upload/リンク編集ペンマークアイコン.png){.figure-none}をクリックします。
![](upload/ページ内リンクを設置.png)

リンクの末尾に「#」と「id値」を付け加えます。
![](upload/ページ内リンクを設置ID名記入.png)

例として、「就職フェア」ページの「3 参加申し込み方法」の見出しにid属性値「participant」が設定されてると仮定して、
![](upload/ページ内リンクを設置id_participant.png)


URLの末尾に「<span class="red bold">#participant</span>」を追記します。
![](upload/ページ内リンクを設置participant入力.png)

これで、Saveボタン![](upload/リンクチェックマークボタン.png){.figure-none}をクリックすればリンクのパスが変わります。
最後、リンク名に「参加申し込み方法」を追加したら完了です。
![](upload/ページ内リンク参加申し込み方法追加.png)



