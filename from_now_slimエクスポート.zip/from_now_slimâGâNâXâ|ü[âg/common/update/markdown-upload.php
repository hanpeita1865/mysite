<?php
	//print_r($_POST['folderDir']);//例) ../../pages/002.windows
	file_put_contents($_POST['folderDir'].'/markdown.md', $_POST['report']);

	print_r($_POST['report']);
?>