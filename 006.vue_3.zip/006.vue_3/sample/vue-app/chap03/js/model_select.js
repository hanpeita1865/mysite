Vue.createApp({
  data() {
    return {
      os: ''
    };
  }
}).mount('#app');