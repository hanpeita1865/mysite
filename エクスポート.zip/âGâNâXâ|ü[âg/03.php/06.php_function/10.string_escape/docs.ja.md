---
title: 文字をエスケープ(htmlspecialchars)
visible: true
taxonomy:
    category:
        - docs
---

*htmlspecialchars関数*は、HTMLにおいて特別な働きを持つ文字について、特別な働きを失わせる 関数です。例えば「<」を「`&lt;`」に、「>」を「`&gt;`」に変換し、ブラウザがこれらの文字をそのまま画面に表示できるようにします。  
データベースに登録されているデータに、HTMLにおいて特別な働きを持つ文字(く、>、&、"、) が含まれていないことが確実ならば、Step5のようにhtmlspecialchars関数を省略することもでき ます。これらの文字が含まれている可能性があるならば、Step6のようにhtmlspecialchars関数 を使うとよいでしょう。

<p class="tmp"><span>書式1</span></p>
```
htmlspecialchars(変数)
```

関数を定義すると、短い記述で書くことが出来ます。
<p class="tmp"><span>書式2</span>関数の定義</p>
```
function 関数名(引数, ...) {
    処理;
    ・・・
    return 返り値;
}
```
以下は簡単な関数定義の例です。
```
function h($string) {
	return htmlspecialchars($string);
}
```
この関数は、htmlspecialchars関数を使って引数$stringを加工し、結果を返り値として返します。この関数を使うと、htmlspecialchars($row['name'])のような長い記述を、h($row['name']) のように短く書くことができます。
