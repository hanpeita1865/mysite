*[page-title]:Laravel9メモ

## 学習記録



## データベースをMariaDBに変更

参考サイト
: [【Laravel】SailでMariaDBを使う](https://chigusa-web.com/blog/laravel-sail-mariadb/)

## 1対多のhasmany()、belongsTo()について

参考サイト
: [【PHP/Laravel】1対多のHasmanyの基本的な使い方をマスターしよう!](https://www.sejuku.net/blog/63335)
: [laravelで１対多（belongsTo）を実装する](https://programing-school.work/laravel-belongsto/)

## Sail コマンド

参考サイト
: [https://laravel.com/docs/10.x/sail](https://laravel.com/docs/10.x/sail)


## Xampp7.4のMySQLとポートが競合する

Xampp7.4のMySQLのポートを13306に設定しているので、競合してしまう。  
とりあえず、Xampp7.4は「GRAV」でしか使用していないので、MySQLは起動しなくていい。