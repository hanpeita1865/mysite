---
title: '20. 検索とスコープ'
media_order: 'search_scope1.png,search_scope2.png,search_scope3.png,search_scope4.png,scope1.png,scope2.png,nameEqual1.png,customer_age.png,global_scop1.png,global_scope2.png'
taxonomy:
    category:
        - docs
---

* [whereによる検索](#p1)
* [スコープの利用](#p2)
* [ローカルスコープについて](#p3)
* [nameをスコープにする](#p4)
* [スコープを組み合わせる](#p5)
* [グローバルスコープについて](#p6)
* [グローバルスコープを作成する](#p7)
* [Scopeクラスを作成する](#p8)
* [ScopeCustomerクラスを作る](#p9)

データベース操作の基本は、検索です。Eloquentによる検索と、レコードを絞り込むための強力な機能「***スコープ***」の使い方を覚え、検索を使いこなせるようになりましょう。

## whereによる検索 ##{#p1}
IDを指定してレコードを取り出すことはできるようになりました。では、ID以外の検索はどのようにすればいいのでしょうか。  
これは、「where」メソッドを使います。前章でDBクラスを使った時に登場した、あのwhereとほぼ同じものが、モデルクラスにも用意されているのです。

<p class="tmp"><span>書式1</span>複数のレコードを得る</p>
```
$変数 = モデルクラス :: where(フィールド名 , 値 )->get();
```

<p class="tmp"><span>書式2</span>最初のレコードだけを得る</p>
```
$変数 = モデルクラス :: where(フィールド名 , 値 )->first();
```
whereで検索の条件を設定し、getまたはfirstを使ってレコードを取得する。DBクラスのときの使い方とまったく同じです。  
このwhereは、ビルダクラスのインスタンスを返します。これはDBクラスのビルダとは少し違います。DBクラスのwhereでは、Illuminate\Database\Query名前空間にある Builderクラスのインスタンスが返されました。  
モデルクラスのwhereでは、illuminate\ Database\Eloquent名前空間にあるBuilderクラスのインスタンスが返されます。
両者は違うクラスですが、用意されている機能は非常に似ています。クエリを生成するために利用されるメソッド類(whereもその一つです)は、ほとんど同じと考えてよいでしょう。

### name を検索する
では、whereの利用例を挙げておきましょう。先に作成した、/findのPOST送信用アクション「***search***」メソッドを書き換えて、nameフィールドで検索をさせてみましょう。

<p class="tmp list"><span>リスト1</span></p>
```
public function search(Request $request)
{
   $item = Customer::where('name', $request->input)->first();
   $param = ['input' => $request->input, 'item' => $item];
   return view('person.find', $param);
}
```

**/customer/find**にアクセスし、フィールドに名前を記入して送信してみましょう。(フルネームを記入)   
その名前のレコードを検索して表示します。もし同じ名前が複数あった場合は、最初のレコードを表示します。
※完全に一致した名前のレコードが表示されます。(あいまい検索ではありません)

![](scope2.png?classes=caption "図1　入力フィールドから名前を送信すると、その名前のレコードを表示する")


ここでは、以下のようにしてレコードの検索を行っています。
```
$item = Customer:: where('name', $request->input)->first();
```
whereを使い、nameの値が**$request->input**と同じ条件を設定します。そしてfirstを呼び出して、最初のレコードを取得します。

## スコープの利用 ##{#p2}
このように、whereによる検索は、DBクラスとほとんど同じ感覚で行うことができます。これは、モデルでもDBクラスでも違和感なく使えるという点でメリットと見ることもできますが、「せっかくモデルを作っても、DBクラスとたいして変わらない」という見方もできるでしょう。  
whereそのものの使い方はDBクラスとモデルクラスで違いはほとんどありません。が、それをいかに使いこなすかという点では、モデルのほうがはるかに便利にできています。  
モデルの利点の一つとして、「***スコープ***」があります。これは、特定の条件でレコードを絞り込む処理をモデルに用意することで、特定条件の検索を用意にするものです。

### モデルの「スコープ」とは?
スコープという言葉は、例えば変数の利用範囲などで耳にしたことがあるでしょう。
スコープとは、「全体の中で、どこからどこまでの範囲か」を特定するものです。  
モデルのスコープというのは、モデルの範囲を特定するためのものです。検索などを行う際、細かな条件をいくつも用意することがよくあります。例えば、「年齢が20以上 の人で、○○の条件に合う人」「今月作成されたレコードの中で○○なもの」というように、データをあらかじめ絞り込むための条件を設定して、その中から検索を行うことは よくあります。

検索はwhereで行えますが、こうした複雑な検索をすべてwhereをつなぎ合わせて行うとなると、非常にわかりにくくなります。そこで、モデルに「こういう条件のもの」と いったスコープを設定するメソッドを用意しておき、それを利用して細かな条件を設定した検索をわかりやすく行えるようにしよう、というわけです。  
例えば、「**今月登録**された**20歳以上**の**女性**の会員の**山田さん**」を検索しようとすると、 とてつもなく複雑な条件を想像してしまうでしょう。が、モデルの中に「今月登録した人」 「20以上の人」「女性のみ」といったスコープが用意されていれば、それらを組み合わせることで、whereには「名前が山田さん」という条件だけ用意すれば済みます。これが、スコープの考え方です。

![](search_scope2.png?classes=caption "図2　スコープを使い、モデルに特定の条件で絞り込むための機能を用意しておくと、複雑な検索でも whereで実行する処理部分は簡単なものになる。")
このスコープには、大きく分けて2つのものがあります。「**グローバルスコープ**」と「**ロー カルスコープ**」です。   
まずは、利用が簡単なローカルスコープから説明しましょう。

## ローカルスコープについて ##{#p3}
これは、モデル内にメソッドを用意しておき、必要に応じてそれらのメソッドを明示的に呼び出して条件を絞り込むものです。メソッドを呼び出さなければ、スコープは機能しません。メソッドを呼び出すと、そのときだけスコープが機能します。これが***ローカルスコープ***です。 ローカルスコープでは、以下のようなメソッドをモデルクラスの中に定義します。
<p class="tmp"><span>書式1</span></p>
```
public function scope 名前 ($query, 引数 )
{
	......必要な処理...... 
    return 絞り込んだビルダ;
}
```
スコープを定義するためのメソッドは、必ずメソッド名のはじめに「***scope***」がつきます。その後に、大文字で始まる名前をつなげてメソッド名にします。例えば、「**scopeAgeMax**」というような形です。  
第1引数には、$queryが渡されています。これは、whereで取得されるのと同じ Builderインスタンスが渡されます。その他に引数を用意する場合は、この$queryの後 に用意します。  
このメソッドでは、レコードを絞り込む処理をして得られたビルダをreturnで返します。こうすることで、更に戻り値を使ってメソッドチェーンを構築できるようにします。

## nameをスコープにする ##{#p4}
では、先ほどのnameで検索する処理を、スコープにしてみましょう。まず、Customerモデルクラスに以下のようにメソッドを追加します。
<p class="tmp list"><span>リスト2-1</span>/app/Customer.php</p>
```
public function scopeNameEqual($query, $str)
{
   return $query->where('name', $str);
}
```
ここでは、第2引数に$strという項目を用意しておきました。これを利用して、 $query->where('name', $str);を実行した結果をreturnしています。これで、nameの値 が$strであるBuilderインスタンスが返されることになります。

### nameEqual を利用する
では、このスコープを利用してみましょう。CustomerControllerクラスのsearchメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト2-2</span></p>
```
public function search(Request $request)
{
   $item = Customer::nameEqual($request->input)->first();
   $param = ['input' => $request->input, 'item' => $item];
   return view('customer.find', $param);
}
```
これで修正は完了です。/customer/findにアクセスして、フィールドに名前を書いて送信しましょう。先程と同様に、記入した名前のレコードが表示されるでしょう。
![](nameEqual1.png)


ここでは、以下のようにしてレコード検索を行っています。
```
$item = Customer::nameEqual($request->input)->first();
```
先ほどのスコープを、**nameEqual($request->input)**というようにして呼び出しています。レコード用メソッドを呼び出す場合は、メソッド名の最初のscopeは不要です。また、 第1引数の$queryも用意する必要はありません。**nameEqual(名前)**というように呼び出せば、nameが指定した名前に絞り込んだビルダが得られます。そのfirstで最初のレコードを取得すればいいわけです。

## スコープを組み合わせる ##{#p5}
もう少し複雑なスコープを作成してみましょう。数字の値を保管するフィールドでは、 よく「○○以上○○以下」というように、指定した範囲内にあるレコードを検索したりし ます。これを行うスコープを作ってみましょう。 まずは、Customerモデルクラスにスコープ用メソッドを追加しましょう。
<p class="tmp list"><span>リスト3-1</span>/app/Customer.php</p>
```
public function scopeAgeGreaterThan($query, $n)
{
   return $query->where('age','>=', $n);
}

public function scopeAgeLessThan($query, $n)
{
   return $query->where('age', '<=', $n);
}
```

「**scopeAgeGreaterThan**」は、ageの値が引数の値と等しいかもっと大きいものに絞り込むものです。  
「**scopeAgeLessThan**」は、ageの値が引数と等しいかもっと小さいものに絞り込みます。

この2つを組み合わせることで、「○○以上○○以下」といった条件が簡単に設定できます。では、CustomerControllerクラスのsearchメソッドを以下のように書き換えましょう。

<p class="tmp list"><span>リスト3-2</span></p>
```
public function search(Request $request)
{
   $min = $request->input * 1;
   $max = $min + 10;
   $item = Customer::ageGreaterThan($min)->ageLessThan($max)->first();
   $param = ['input' => $request->input, 'item' => $item];
   return view('customer.find', $param);
}
```
わかりやすいように、歳も表示させたいので、Customer.phpのpublic function getData() を下記のように少し修正しておきます。
<p class="tmp list"><span>リスト3-3</span></p>
```
public function getData()
{
   return $this->id . ': ' . $this->name .' '. $this->age . '才 (' . $this->address . ')';
}
```


これで、/customer/findにアクセスし、フィールドに数字を記入して送信すると、**ageの値がその値以上 値+10以下**の範囲で絞り込みます。例えば、「30」と送信すると、30以上40以下の範囲から最初のレコードを表示します。 

![](customer_age.png?classes=caption "図3　整数を入力して送信すると、その数字から数字+10の範囲の最初のレコードが検索されます。")

ここでの検索処理は、以下のようになっています。
```
$item = Customer::ageGreaterThan($min)->ageLessThan($max)->first();
```
Customerから、ageGreater ThanとageLessThanを連続して呼び出すことで、「○○以上」 と「○○以下」の絞り込みを行っています。後はfirstで最初のレコードを取り出すだけです。見ればわかるように、コントローラ側ではwhereもクエリー文字列もまったくありません。ただメソッドを呼び出せば、必要なレコードが絞り込まれるのです。

## グローバルスコープについて ##{#p6}
ローカルスコープは、単純に「検索条件を設定してBuilderを返すメソッド」を用意して、それを呼び出す、というものでした。要するに、「メソッドを呼び出して利用すれば、その機能が利用される」というものであり、あまりスコープ設定の魅力を感じなかったかもしれません。別にスコープなど使わなくとも、普通にwhereを実行してBuilderを返すメソッドを用意すれば同じことですから。

が、グローバルスコープになると話は違ってきます。グローバルスコープは、処理を用意しておくだけで、そのモデルでのすべてのレコード取得にそのスコープが適用されるようになります。  
グローバルスコープは、ローカルスコープのようにメソッドを追加すればOKとはいきません。専用のメソッドが用意されており、それを利用して処理を組み込みます。

### boot メソッドについて
処理の組み込みは、モデルが作成される際の初期化処理として実行します。これは、 _constructなどは利用しません。「boot」という、モデルの初期化専用のメソッドを用います。これは以下のように記述します。
#### boot初期化メソッドの基本
<p class="tmp"><span>書式2</span></p>
```
protected static function boot()
{
    parent::boot(); 
    ...初期化処理......
}
```
見ればわかるように、これは静的メソッドです。したがって、モデルインスタンス自身($this)を利用する処理は書けません。では、どうやってグローバルスコープの処理を 用意するのかというと、「**addGlobalScope**」という静的メソッドを使うのです。 これは、以下のように記述します。
<p class="tmp"><span>書式3</span></p>
```
static::addGlobalScope(スコープ名 , function (Builder $builder)
{
......絞り込み処理......
}
```
**addGlobalScope**は、その名の通りグローバルスコープを追加するメソッドです。これ をオーバーライドすることで、グローバルスコープを追加することができます。
このメソッドでは、第1引数にスコープの名前を、第2引数にクロージャを用意してい ます。このクロージャは、Builderインスタンスが引数として渡されます。Builderを使って、スコープの絞り込み処理を作成します。

## グローバルスコープを作成する ##{#p7}
では、実際にグローバルスコープを利用してみましょう。ここでは、**ageの値が40以上のレコード**だけが表示されるようにしておきます。  
これは、モデルクラスにbootメソッドをオーバーライドして利用します。Customer.php に以下のメソッドを追加して下さい。
<p class="tmp list"><span>リスト4</span></p>
```
// use Illuminate\Database\Eloquent\Builder;  を追加

protected static function boot()
{
   parent::boot();

   static::addGlobalScope('age', function (Builder $builder) {
       $builder->where('age', '>', 40);
   });
}
```

修正したら、例として/customerにアクセスしてみましょう。40歳以上のレコードのみが表示されます。  
![](global_scop1.png?classes=caption "図4　/customerにアクセスすると、40歳以上のレコードだけが表示される。")

ここでは、addGlobalScopeのクロージャに以下のような処理を追加しています。
```
function (Builder $builder) {
	$builder->where('age', '>', 40);
}
```
引数で渡されたBuilderでwhereを呼び出し、ageが40以上のものに絞り込んでいます。 このように、引数のBuilderを使って絞り込みの処理を行えば、それがすべての検索処理に適用されるようになるのです。

## Scopeクラスを作成する ##{#p8}
クロージャを使ったグローバルスコープは、特定のモデルに簡単にグローバルスコー プを追加できて便利です。が、複数のモデルや、その他のプロジェクトなどでも利用されるような汎用性の高い処理は、「***Scopeクラス***」として作成しておくと便利です。  
Scopeクラスというのは、Illuminate\Database\Eroquent名前空間にあるScopeを実装して定義されるクラスです。これは以下のような形になります。

<p class="tmp"><span>書式4</span></p>
```
class クラス名 implements Scope
{
    public function apply(Builder $builder, Model $model)
    {
    ......絞り込み処理を用意.....
    }
}
```
Scopeクラスでは、「***apply***」というメソッドを1つ用意します。このメソッドでは、 BuilderとModelがインスタンスとして渡されます。これらの引数を用いて、絞り込みの 処理を行います。  
モデルから切り離され、引数にModelを渡して処理をするようになっているため、特定のモデルに囚われず、汎用的な処理を行うスコープが作成できます。

## ScopeCustomerクラスを作る ##{#p9}
では、実際にScopeクラスを作成してみましょう。まずは、Scopeクラスを配置する場所を用意します。Scopeクラスは、特に「ここに入れておかないといけない」ということは決まっていませんが、やはり専用のフォルダを用意してそこにまとめたほうがわかりやすいでしょう。  
「app」フォルダの中に「**Scopes**」という名前のフォルダを作成しましょう。このフォルダの中にScopeクラスのスクリプトを配置することにします。フォルダ内に、 「**ScopeCustomer.php**」という名前でファイルを作成して下さい。そして以下のようにソースコードを記述しておきます。

<p class="tmp list"><span>リスト5-1</span>app/Scopes/ScopeCustomer.php</p>
```
<?php
namespace App\Scopes;

use Illuminate\Database\Eloquent\Scope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class ScopeCustomer implements Scope
{
   public function apply(Builder $builder, Model $model)
   {
       $builder->where('age', '>', 40);
   }
}
```
やっていることは、実は先ほどのクロージャに用意した処理と変わりありません。 applyメソッドの中で、$builder->where('age', '>', 40);を実行しているだけです。

### Customerモデルクラスの修正
では、このScopeCustomerクラスを利用するようにCustomerクラスのbootメソッドを修正しましょう。
<p class="tmp list"><span>リスト5-2</span></p>
```
// use App\Scopes\ScopeCustomer;　を追加

protected static function boot()
{
   parent::boot();
   static::addGlobalScope(new ScopeCustomer);
}
```
ここでは、**static::addGlobalScope**メソッドの引数に、**new ScopeCustomer**を指定しています。こうすることで、ScopeCustomerがグローバルスコープとして追加されます。
後は、/customerにアクセスして、先程と同様に40歳以上のレコードだけが表示されるようになっているか確認しましょう。

![](global_scope2.png?classes=caption "図5　40歳以上のレコードだけが表示されるScopeCustomerクラス")



