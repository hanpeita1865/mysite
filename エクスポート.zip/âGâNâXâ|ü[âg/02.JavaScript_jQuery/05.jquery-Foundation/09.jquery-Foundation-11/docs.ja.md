---
title: '09. 非同期通信（ajaxを使った外部ファイルの読み込みやAPI利用など）'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: #0000bc;}
    .large {font-size:3.5rem;}
    button:focus {outline:none;}
    .w-300 {width: 300px;}
    hr {border-color: #aaa;}
    .smp-box {
        margin: 2rem 0 3rem;
    }
    .smp {
        display: inline-block;
        margin-top: 2rem;
        margin-bottom: 0;
        background: #bc495b;
        color: #fff;
        font-size: .75rem;
        font-weight: bold;
        letter-spacing: .3rem;
        padding: .2rem .5rem;
    }
    .tmp {
        background: #026ca2;
        color: #fff;
        font-size: .87rem;
        letter-spacing: .3rem;
        padding: .2rem 1rem;
        white-space: nowrap;
    }
    .dcn {
     	font-weight: bold;   
    }
    .exp {
     	border-bottom: 3px solid #14ff00;
        font-weight: bold;
        font-size: 2rem;
    }
    h3 {
    	margin-top: 2rem;
    }
    h3 span {
      border-bottom: 3px solid green;   
    }
</style>
非同期通信とは，画面遷移を行わずにサーバから情報を取得する仕組みだと考えてください．  

通常，情報を取得する際は，<a\>リンクに指定された画面へ遷移しますが  
画面を遷移させずに『一部分だけ』を更新したいという要望があった場合，非同期通信を使うと簡単に実現できます．  
同期通信と非同期通信の違いについては，下記の説明を見てください．  
<a href="https://www.atmarkit.co.jp/ait/articles/0708/23/news134_2.html" target="_blank">いまさら聞けない、“Ajax”とは何なのか？ (2-3)：いまさら聞けないリッチクライアント技術（3） - ＠IT</a>  
■同期？ 非同期？  

## 都道府県に紐づく市区町村を表示

選択された都道府県に紐づく市区町村の一覧を表示するという要望があったとします．

単純に都道府県ごとの市区町村一覧の表示枠を47個作って，選択された都道府県に応じて表示を切り替えるという作り方もできます．  
ただ，凄く大変な上にコードの量が多くなるのでメンテナンス性も悪いです．

サンプルでは非同期通信を使って，選択された都道府県に紐づく市区町村の一覧を取得して表示しています．

<!--<iframe width="100%" height="300" src="//jsfiddle.net/ookiki/m4wzj0gt/30/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>-->
<http://localhost:7000/test/ajax_local/>

<iframe width="100%" height="600" src="//jsfiddle.net/hirao/o3qf6pey/1/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずはResultを見て，結果を見てください．  
都道府県プルダウンリストが表示されていますので，試しにご自分の住んでいる都道府県を選んでみてください．  
市区町村に選んだ都道府県に紐づく市区町村の一覧が表示されます．

ではHTMLを見てください．  
都道府県のプルダウンリストと市区町村一覧用のDiv要素が表示されるようになっています．

次はJavaScriptを見てください．  
都道府県が選択されたときに，非同期通信が実行される処理を記述しています．  
詳しく見てみましょう．

まず，変数areaに選択された都道府県の<option\>のvalue値を格納します．  
次に，市区町村一覧用のDiv要素をクリアします．  

非同期通信処理を実行します．非同期通信処理は，$.ajaxを記述します．  

<span class="tmp">書式</span>
<pre>
  jQuery.ajax(options)<br>
    .done(非同期通信が<span class="red">成功</span>した時の処理)<br>
    .fail(非同期通信が<span class="blue">失敗</span>した時の処理);
</pre>

<span class="tmp">記述例</span>
<pre>
  $.ajax({//options
    type:     'GET',
    dataType: 'json',
    cache:    false,
    url:      'http://～～～～'
  })
  .done(function(data) {
    //通信成功時の処理　
  })
  .fail(function(){
    //通信失敗時の処理
  });
</pre>

$.ajaxの引数に様々なオプション（options）を設定して実行します．  
設定できるオプションについては，
<a href="http://semooh.jp/jquery/api/ajax/jQuery.ajax/options/" target="_blank">jQuery日本語リファレンス</a>
を見てください．  
今回設定しているオプションは下記になります．

|オプション|説明|
|::|::|
|type|HTTP通信の種類を設定します．今回は「GET」|
|dataType|サーバから返されるデータの型を指定します．今回は「json」|
|cache|通信結果をキャッシュするかを指定します．今回は「false」|
|url|リクエストを送信する先のURLを指定します．|

urlには，
<a href="http://www.land.mlit.go.jp/webland/api.html" target="_blank">国土交通省　土地総合情報システムの都道府県内市区町村一覧取得API</a> 
を指定しています．  
都道府県内市区町村一覧取得APIは，末尾に「area=都道府県コード」を指定することで，都道府県内の市区町村の一覧を取得しています．

都道府県の<option\>のvalue値に都道府県コードを設定しています．  
<option\>のvalue値を格納した変数areaをurlに含めることで，動的に市区町村の一覧を取得しています．

ここまでが，非同期通信を実行する前の処理説明になります．  
ここからが，実行した後の処理説明になります．

非同期通信が成功した場合は，done()に記述した処理が実行されます．  
取得した市区町村の一覧は，data.dataというオブジェクトに格納されて戻ってきます．  
forEachループを使って1件1件連結して，最後に市区町村一覧用のDiv要素に出力します．

---

## おまけ - 外部ファイルを利用する -

上記のサンプルでは，APIを利用していましたが、Webサーバに配置された外部ファイルを利用することも可能です．  
静的な外部ファイルを利用する際は，オプション設定で「cache: false」を設定して  
常に最新のファイルを利用することをお勧めします．  

<div class="box-example" markdown="1">
### 例 ### {.h-example}
[外部ファイル読み込みサンプル](sample1/index.html?target=_blank)(別ウィンドウで開きます)

ボタンを押すと、commonフォルダにあるsample.htmlを「id="hoge"」内に読み込んで表示します。

<iframe width="100%" height="300" src="jquery-foundation-11/sample1/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

</div>

<iframe width="100%" height="300" src="//jsfiddle.net/hirao/1skxn6fm/2/embedded/html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>














