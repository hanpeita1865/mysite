---
title: '11. 動画'
taxonomy:
    category:
        - docs
---

[新規タブ](../../../sample/video/sample.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/video/sample.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>