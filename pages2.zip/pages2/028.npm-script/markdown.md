*[page-title]:npm-scripts

## npm-scriptsでDart Sassのコンパイル環境構築
参考サイト
: [npm-scriptsでDart Sassのコンパイル環境構築](https://noob-front-end-engineer-blog.com/node-sass-compiler/)
: [【SASS】@useと@forwardとは何か？違いやメリット、使い方を実例で解説。](https://prograshi.com/design/css/use-forward/)

### 概要

#### 1. npm-scripts での環境構築

Sassの環境構築というと<span class="red bold">Gulp</span>を使用されている例が多いかと思います。  
しかし 2020 年頃から、かの有名な[フロントエンドロードマップ](https://roadmap.sh/frontend)でもそこまで注目されなくなり、<span class="green bold">npm-scripts</span>で殆どの事が解決できるのではないかという雰囲気に。

という事で今回はnpm-scriptsでの環境構築を行っていきます。

#### 2. DartSass を使用したコンパイル

意外と知られていない事なのですが、厳密にはSassは3種類あります。

基本的な記述方法は同じですが、@import等細かな箇所で違いがあり、  
独自の機能・記述方法を使用している場合には、乗り換えは少し手間になる事があります。

##### 1. RUBY SASS
その名の通り、Ruby製のSassです。

このタイプの場合コンパイルにはcompassが使用されており、config.rbという設定ファイルがあると思います。

3 種類のSassの内で最も古く、2019 年にサポートが終わっています。  
昔から保守が続いているサイト・Web アプリ等ではよく見かけられます。

##### 2. LIBSASS
こちらはC++製のSassで、このタイプはnode-sassでコンパイルが行われており、現在最も多く使用されています。

Gulpを使用している場合はgulp-sassになりますが、内部的にはnode-sassを使用しているみたいです

2021 年 2 月中旬の現在だと、記事等の情報も最も豊富で、node-sassの週間インストール数も 400 万回行われています 😮

但し、こちらも 2020 年 10 月にSassの公式から非推奨とされています。

実際の記事
: [翻訳した記事](https://sass--lang-com.translate.goog/blog/libsass-is-deprecated?_x_tr_sl=auto&_x_tr_tl=ja&_x_tr_hl=ja&_x_tr_pto=wapp)
: [原文](https://sass-lang.com/blog/libsass-is-deprecated)


##### 3. DART SASS（推奨） #####{.green .mark-yellow}

こちらも名前の通りDart製のSassになります。  
Sass公式ではこちらが推奨されており、新機能の対応は、殆どこちらでしかされていない状態です。

という事で今回は、現段階では最新っぽい、  
npm-scriptsとDart Sassでの環境構築を行っていきます！

## 環境構築

では、ここから実際にSassの環境構築手順を紹介していきます！

### ディレクトリ作成

まずはテスト用のディレクトリを作成してpackage.jsonファイルの作成をしましょう！

<p class="tmp cmd"><span>コマンド</span></p>
```
# テストディレクトリの作成（名前は任意）
mkdir node-sass-compiler

# 移動
cd node-sass-compiler

# package.jsonの作成
npm init
```

<p class="tmp list"><span>リスト</span>package.json</p>
```
{
  "name": "sass-compiler",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "sass": "sass src/scss/:dist/css/ --no-source-map --watch"
  },
  "author": "",
  "license": "ISC",
  "dependencies": {
    "sass": "^1.50.0"
  }
}
```

### モジュールのインストール

次に使用するモジュールのインストールを行います。

<table>
	<tbody>
		<tr>
			<th>module</th>
			<td>description</td>
		</tr>
		<tr>
			<th>sass</th>
			<td>Dart 製の Sass コンパイラ</td>
		</tr>
	</tbody>
</table>

```
# モジュールインストール
npm install sass
```

まず、Sassのコンパイルを行ってくれる<span class="red bold">sassモジュール</span>を使ってみましょう。

### sass モジュールの使用方法

先ほど作成した**package.json**の**scripts**の箇所を下記の様に編集してみてください。

<p class="tmp list"><span>リスト</span>package.json</p>
```
# --- 略 ---
"scripts": {
    "sass": "sass src/scss/:dist/css/ --no-source-map --watch"
  },
# --- 略 ---
```

上記のスクリプトの解説はこんな感じです。

<p class="tmp"><span>書式</span>package.json</p>
```
sass [コンパイル前ファイル（ディレクトリ）]:[出力先ファイル（ディレクトリ）]
```

使用しているオプションの<span class="green">--no-source-map</span>は<span class="red">ソースマップ</span>を表示しない、  
<span class="green">--watch</span>はコンパイル前ファイル（ディレクトリ）の変更を検知して、コンパイルを実行してくれるものです。

オプション周りの詳細は下記公式を参考にしてください。  
Dart Sassのコマンドラインドキュメント：<https://sass-lang.com/documentation/cli/dart-sass>

それでは実際にスクリプトを実行してみましょう！

<p class="tmp cmd"><span>コマンド</span>コンパイル実行</p>
```
npm run sass
```

これで/src/sass/ディレクトリ配下にsass or scssファイルを作成・編集すると、コンパイルが行われ、/dist/css/ディレクトリにcssファイルが生成されます。 😍


完成したnpm-scriptsを使ったコンパイル用ファイルが下記のフォルダになります。
```
C:\xampp\htdocs\sass_folder\npm-scripts\sample1\node-sass-compiler
```
srcフォルダのscssファイルをコンパイルして、distフォルダに出力する仕組みです。  

ここで注意すべきは、ファイルを読み込む場合、@importではなく、<span class="green bold">@use</span> を使う点です。  
また、使用する際に名前空間を設定し、変数やmixinを読み込むには、その名前空間の変数名を頭に記述する必要があります。

参考サイト
: [Dart Sass（@use）の基本的な書き方と@importから乗り換える方法](https://haniwaman.com/dart-sass/)

<p class="tmp"><span>書式</span></p>
```
@use "ファイル名" as 名前空間;

//アスタリスクを使うことで、変数を呼び出すときに名前空間をつける必要がなくなります。
//@use "ファイル名" as *;

//変数を読み込み
名前空間.変数名

//mixinを読み込み
@include 名前空間.mixin名
```

以下のファイルでは、variablesファイルを読み込んで、変数$bp-wideとミックスインmedia(～)を使用しています。

<p class="tmp list"><span>リスト</span>node-sass-compiler/src/test.scss</p>
```
@use "variables" as var;

//上側のコンテンツ
.main-contents {
	display: flex;
	flex-direction: row;
	justify-content: space-around;

	@include var.media(sm) {
		flex-direction: column;
	}
    
    div {
        color: #000;
        width: var.$bp-wide;
    }
}
```

<p class="tmp list"><span>リスト</span>node-sass-compiler/src/_variables.scss</p>
```
@charset "utf-8";

$bp-wide: 1199px;
$bp-desktop: 991px;
$bp-tablet: 767px;
$bp-mobile: 575px;
$bp-mobile-small: 414px;

@mixin media($media-width) {
	@if $media-width==wd {
		@media only screen and (max-width: $bp-wide) {
			@content;
		}
	}
	@else if $media-width==pc {
		@media only screen and (max-width: $bp-desktop) {
			@content;
		}
	}
	@else if $media-width==tb {
		@media only screen and (max-width: $bp-tablet) {
			@content;
		}
	}
	@else if $media-width==sm {
		@media only screen and (max-width: $bp-mobile) {
			@content;
		}
	}
	@else if $media-width==xs {
		@media only screen and (max-width: $bp-mobile-small) {
			@content;
		}
	}
}
```
C:\xampp\htdocs\sass_folder\sample1\node-sass-compilerのディレクトリに移動して、  
<span class="red bold">npm run sass</span>を実行すると、watch状態になり、コードを変更して保存するとコンパイルされ、test.cssが生成されるか、test.cssのコードが書き換わります。

<p class="tmp">実行結果</p>
```
C:\xampp\htdocs\sass_folder\sample1\node-sass-compiler>npm run sass

> sass-compiler@1.0.0 sass
> sass src/scss/:dist/css/ --no-source-map --watch

Sass is watching for changes. Press Ctrl-C to stop.

Compiled src\scss\test.scss to dist\css\test.css.
```

<p class="tmp list"><span>リスト</span>node-sass-compiler/dist/css/test.css</p>
```
.main-contents {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
}
@media only screen and (max-width: 575px) {
  .main-contents {
    flex-direction: column;
  }
}
.main-contents div {
  color: #000;
  width: 1199px;
}
```

同友会の案件で使ったSCSSをCSSにコンパイルするサンプルも、準備してみました。
```
C:\xampp\htdocs\sass_folder\npm-scripts\sample2
```

package.jsonのscriptの値を、次のように変更しただけです。
```
//～省略～//
  "scripts": {
    "sass": "sass scss/:css/ --no-source-map --watch"
  },
//～省略～//
```