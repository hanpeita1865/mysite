*[page-title]:forever

参考サイト
* [【Node.js入門】foreverの使い方とデーモン化による永続化・自動起動まとめ！](https://www.sejuku.net/blog/81363)
*  [node.js foreverによるデーモン化](https://kaworu.jpn.org/javascript/node.js_forever%E3%81%AB%E3%82%88%E3%82%8B%E3%83%87%E3%83%BC%E3%83%A2%E3%83%B3%E5%8C%96)

## foreverのインストールと使い方

<p class="tmp cmd"><span>コマンド</span>foreverインストール</p>
```
npm install forever
```
![](upload/foreverインストール.png)

グローバルにインストールする場合は、次のコマンドを実行します。  （こちらのグローバル用のコマンドを実行します）
<span class="red">※foreverモジュールはアプリごとに使うものではないので、「-g」を付与してグローバル環境にインストールするという点を覚えておきましょう！</span>
<p class="tmp cmd"><span>コマンド</span>forever グローバルにインストール</p>
```
npm install -g forever
```
![](upload/foreverグローバルにインストール.png)

常に起動させておきたいNode.jsのファイルを次のように実行します。  
※下記は、index.jsファイルを実行させています。
```
forever start index.js
```
![](upload/index.jsを実行.png)

※この時点で、Node.jsに何らかのエラーが起きても自動的に起動してプログラムを実行してくれます。

サイトにアクセスして、確認してみましょう。  
起動できてました。
![](upload/サイトアクセスして起動確認.png){.photo-border}

これでコマンドプロンプトを閉じても、起動したままになります。

停止するときは、次のコマンドを実行してください。

<p class="tmp cmd"><span>コマンド</span>アプリケーションを停止する場合</p>
```
forever stop index.js
```

何らかの理由によりforeverで実行しているNode.jsのアプリが停止してしまっているようなケースでは、次のコマンドを実行して再起動する必要があります。
<p class="tmp cmd"><span>コマンド</span>再起動</p>
```
forever restart index.js
```

### 「list/log/config」による進捗・設定の確認方法

foreverモジュールを使っているNode.jsアプリの進捗状況を確認したい場合には「list」コマンドを利用します。

<p class="tmp cmd"><span>コマンド</span>進捗状況確認</p>
```
forever list
```
「list」コマンドは、現在foreverで実行しているNode.jsアプリのパスや実行時間、ログファイルの保存場所などの詳細情報を出力してくれます。

また、実行時のログ情報に関しては「logs」コマンドで確認することができます。

<p class="tmp cmd"><span>コマンド</span>ログ情報</p>
```
forever logs
```

さらに、「config」コマンドを実行するとforeverモジュールのコンフィグ情報を出力することもできます。
<p class="tmp cmd"><span>コマンド</span></p>
```
forever config
```

これにより、現在設定されているオプションなども合わせて確認することができます。




