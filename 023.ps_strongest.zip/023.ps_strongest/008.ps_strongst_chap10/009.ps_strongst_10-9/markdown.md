*[page-title]:10-9. 画像をクッキリと鮮明にするフィルター

## アンシャープマスク ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-09-1.jpg)](upload/10-09-1.jpg){.image}
</div>

## スマートシャープ ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-09-2.jpg)](upload/10-09-2.jpg){.image}
</div>

## ぶれの軽減 ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-09-3.jpg)](upload/10-09-3.jpg){.image}
</div>


## シャープ、シャープ（強）、シャープ（輪郭のみ） ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-09-4.jpg)](upload/10-09-4.jpg){.image}
</div>