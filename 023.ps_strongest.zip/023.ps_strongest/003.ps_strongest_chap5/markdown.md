*[page-title]:5章 レイヤーを使って画像を合成しよう

### 第5章 目次
<div markdown="1" class="page-mokuji auto-mokuji">
</div>