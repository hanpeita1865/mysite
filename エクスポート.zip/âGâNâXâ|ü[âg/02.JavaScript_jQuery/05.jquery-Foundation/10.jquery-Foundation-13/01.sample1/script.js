$(function() {
	$('.tb-include').each(function() {
		var tableName = $(this).data('table');

		switch (tableName) {
			case 2018 :
				tablePath = 'common/baseball_2018.json';
				break;
			case 2017 :
				tablePath = 'common/baseball_2017.json';
				break;
			case 2016 :
				tablePath = 'common/baseball_2016.json';
				break;
			default :
				tablePath = 'common/baseball_2019.json';
				break;
		}

		//テーブルの読み込み
		$.ajax({
			url: tablePath,
			type: 'GET',
			dataType: 'html',
			cache: false
		}).done(function(data){
			$('[data-table='+tableName+']').html(data);
		});
	}); 
});