*[page-title]:MySQL操作

## カラムを追加する

<p class="tmp"><span>書式1</span>ALTER TABLE ~ ADD</p>

```
ALTER TABLE テーブル名 ADD 新規カラム名 型情報 オプション;
```
テーブルにカラムを追加するには、テーブルの構造を変更する「ALTER TABLE」を使います。  
例えば「user」テーブルに対して、NULLを許可しない「nickname」というカラムを追加する場合は以下のようになります。
```
ALTER TABLE user ADD nickname varchar(255) NOT NULL;
```

## 追加するカラムの順序を指定する

また、追加するカラムの位置を指定することもできます。位置の指定には、「AFTER」と「FIRST」を使います。

<p class="tmp"><span>書式2</span>～AFTER～,～FIRST</p>
```
ALTER TABLE テーブル名 ADD 新規カラム名 型情報 AFTER 既存カラム名;
ALTER TABLE テーブル名 ADD 新規カラム名 型情報 FIRST;
```

```
ALTER TABLE compatible ADD comp_server_remarks varchar(300) AFTER comp_server;
```

「FIRST」を使えば一番の最初のカラムに、「AFTER」を使えば指定カラムの後に新規カラムが追加されます。

## 複数カラムを一括で追加する

さらに、括弧でくくることで複数のカラムを一括で追加することもできます。
<p class="tmp"><span>書式3</span>一括追加</p>
```
ALTER TABLE テーブル名 ADD (新規カラム名１ 型情報, 新規カラム名２ 型情報, ...);
```

追加するカラムは括弧でくくられ、カンマ「,」区切りで複数記述できます。  
「user」テーブルに、「mail」と「tel」の２つを追加する場合は以下のようなクエリになります。
```
ALTER TABLE user ADD (mail text, tel tinytext);
```

また、追加されたカラムは「ALTER TABLE ~ CHANGE」で名前や型情報を変更することもできます。


## データベースを登録

試しに、ajaxという名前のデータベースを登録してみます。  
ユーザ名staff、パスワードpasswordで設定し、localhostに設置します。

##### ajax.sql
```
drop database if exists ajax;/*今あるデータベースを削除します*/
create database ajax default character set utf8 collate utf8_general_ci;
grant all on ajax.* to 'staff'@'localhost' identified by 'password';
use ajax;
```
データベースが登録されました。
![](upload/database_ajax.png)

### データベースの削除

ajax.sqlの最初は、ajaxデータベースが既に存在する場合に、ajaxデータベースを削除する処理です。
```
drop database if exists ajax;
```


*drop database*は、データベースを削除するSQLのコマンド(命令)です。*if exists*は、 「指定するデータベースが存在する場合に」という条件を表します。

<p class="tmp"><span>書式1</span></p>
```
データベース名 database if exists ajax;
```

### データベースの作成

次に、ajaxデータベースを作成します。
```
create database shop default character set utf8 collate utf8_general_ci;
```
*create database*は、データベースを作成するコマンドです。続けて指定する名前で、デー タベースを作成します。  
*default character set*は、データベースで用いる文字コードを表します。ここではUTF-8 を表す「utf8」を指定します。  
*collate*は、データベースにおいて行を並べる順番を決めるための方式を表します。  
ここでは UTF-8を用いた方式の1つである、「utf8_general_ci」 を指定します。  
MySQLにおけるcollateの 詳細は、「<http://dev.mysql.com/doc/refman/5.6/ja/charset-collations.html>」などに記載さ れています。


<p class="tmp"><span>書式2</span></p>
```
create database データベース名 default character set utf8 collate utf8_general_ci;
```

### ユーザーの作成
続いて、shopデータベースを使用するためのユーザーを作成します。
```
grant all on ajax.* to 'staff'@'localhost' identified by 'password';
```
*grant*は、ユーザーに対してデータベースを操作する権限を与えるためのコマンドです。  
指定 したユーザーが存在しない場合には、新たにユーザーの作成も行います。 
<p>all on ajax.* は、 ajaxデータベースの全てのテーブルに対して、全ての権限を与えることを表します。</p>
to以下は、*ユーザー名*と*ホスト名*です。ここでは「*localhost*」というホストにおける「*staff*」というユーザーを指定しています。  
staffというユーザーが既に存在する場合は権限を設定し、存在 しない場合は、新規にユーザーを追加すると同時に権限を設定します。  
*identified by*以下は、ユーザーがデータベースにログインするための*パスワード*です。ここでは「*password*」というパスワードを指定します。  

<p class="tmp"><span>書式3</span></p>
```
grant all on データベース名.* to 'ユーザー名'@'ホスト名' identified by 'パスワード';
```

### データベースへの接続
最後に、作成したshopデータベースに接続します。 
```
use shop;
```
*use*は、データベースに接続するためのコマンドです。ここではajaxデータベースに接続します。  
これ以降の操作は、ajaxデータベースに対して適用されます。



## テーブルを作成

カラムid、name、priceがあるテープルproductsを作成します。

```
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
)
```
データベースajaxの中にproductsテーブルが作成されました。
![](upload/prodcts_table.png)

## データの追加

<p class="tmp"><span>書式4</span></p>
```
insert into テーブル名 values (列1の値, 列2の値, ...)
```

nameとpriceに「りんご」、「100」と「みかん」、「80」のデータを追加します。  
MySQLでデータを追加するproductsテーブルを選択し、下記のコードをSQLのページに入力して実行します。

```
INSERT INTO products(name, price) VALUES('りんご', 100), ('みかん', 80);
```

データが追加されました。

![](upload/insert1.png)

## データの更新

<p class="tmp"><span>書式5</span>update(行の指定)</p>
```
update テーブル名 set 列名=値 where 列名=値
```

更新する行を指定するには、次のようにwhere句を記述します。この場合はidが2の行の「みかん」、「80」を「もも」、「900」に更新します。

```
update products set name='もも', price=900 where id=2
```
データが更新されました。

![](upload/update1.png)

## データを削除する

delete from product where id=1
まずdelete(行を指定して削除)

<p class="tmp"><span>書式6</span>delete(行の指定)</p>
```
delete from テーブル名 where 列名=値
```

1行目のりんごがある行のデータを削除する場合は、以下のように記述します。
```
delete from products where id=1
```



