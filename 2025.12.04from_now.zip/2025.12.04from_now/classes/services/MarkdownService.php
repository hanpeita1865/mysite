<?php
namespace SocymSlim\SlimMiddle\Services;

use ParsedownExtra;
use ParsedownNoEncode;//追加
use Psr\Container\ContainerInterface;
use PDO;
use PDOException;

class MarkdownService
{
    private ContainerInterface $container;
    // private ParsedownExtra $parser;
    private ParsedownNoEncode $parser;//追加
    private $editService;

    public function __construct(ContainerInterface $container, EditService $editService)
    {
        $this->container = $container;
        $this->editService = $editService;
        
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");
        require_once("../php/ParsedownNoEncode.php");//追加

        // $this->parser = new ParsedownExtra();
        $this->parser = new ParsedownNoEncode();//追加
        // error_log('[DEBUG] parser class: ' . get_class($this->parser));//追加
    }


    //-----------------------------//
    //   マークダウンをHTMLに変換   
    //----------------------------//
    
    public function getMarkdownData(array $folderObj, string $folderName): array
    {
        $config = $this->container->get('config');
        $basePath = $config['basePath'];

        // 対象フォルダが存在するか確認
        if (empty($folderObj[$folderName])) {
            return ['html' => 'ページが存在しません。', 'title' => ''];
        }

        $folderPath = $folderObj[$folderName];
        $folderPath1 = str_replace('..', '', $folderPath); // ".."を削除

        // Markdownファイルを読み込み
        $markdownFile = $_SERVER["DOCUMENT_ROOT"] . $basePath . $folderPath1 . '/markdown.md';
        
        if (!file_exists($markdownFile)) {
            return ['html' => 'Markdownファイルが見つかりません。', 'title' => ''];
        }

        $md = file_get_contents($markdownFile);

        // ページタイトルを抽出
        preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
        $title = $ArrayTitle[1] ?? '';

        // HTML変換
        $htmlData = $this->parser->text($md);

        // 画像・リンク・iframeなどのパスを変換
        $replacements = [
            ['/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="' . $basePath . $folderPath1 . '/upload/$2"$3>'],
            ['/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="' . $basePath . $folderPath1 . '/upload/$2"$3>'],
            ['/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="' . $basePath . $folderPath1 . '/sample/$2" target="_blank">$4</a>'],
            ['/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i', '<iframe$1src="' . $basePath . $folderPath1 . '/sample/$2"$3></iframe>']
        ];

        foreach ($replacements as [$pattern, $replacement]) {
            $htmlData = preg_replace($pattern, $replacement, $htmlData);
        }

        return [
            'html' => $htmlData,
            'title' => $title
        ];
    }
    
 
    
    //------------------------------
    //  検索結果用 マークダウン変換
    //------------------------------

    public function markSearch(array $mdArray, string $word, bool $fullText){
        
        $pattern = '/'.$word.'/';
        $wordNum = 0;
        $htmlData = '';
        
        foreach($mdArray as $val){

            $dirNonum = preg_replace('/\/\d{3}./','/',$val['dir']).'/';
            $dirNonum = preg_replace('/\.\.\//','',$dirNonum);

            //ページタイトル markdown.mdの先頭にあるpage-titleの値を、$ArrayTitleに格納。
            preg_match("/^\*\[page-title\]:\s*(.+)/", $val['md'], $ArrayTitle);

            if(!empty($ArrayTitle[1])){
                $title = $ArrayTitle[1];//ページタイトル
            }else{
                $title = '';
            }

            $html = $this->parser->text($val['md']);
            $text = strip_tags($html,"<pre><code>");//<pre><code>は残す
            $getWord = null;

            if($fullText){
                //全文検索
                if(preg_match_all($pattern, $text, $getWord)){
                    $sumWord = array_unique($getWord[0]);

                    if($fullText){
                        foreach ($sumWord as $value) {
                            $patternDiff = '/'.$value.'/';
                            $text = preg_replace($patternDiff, '<mark class="hilight">'.$value.'</mark>', $text);//検索文字にマークを付ける
                        }    
                    }

                    $htmlData = $htmlData.'<section><h3><a href="'.$dirNonum.'" >'.$title.'</a></h3><div class="search-text">'.$text.'</div></section>';
                    $wordNum++;
                }
            } else {
                //タイトル検索
                $htmlData = $htmlData.'<section><h3><a href="'.$dirNonum.'" >'.$title.'</a></h3><div class="search-text">'.$text.'</div></section>';
                $wordNum++;
            }
        }
        
        $htmlData = '<p id="search-number">「'.$word.'」の検索結果：<span id="word-num">'.$wordNum.'</span>ページ</p>'.$htmlData;

        $markData = ['html' => $htmlData];

        return $markData;
    }
    
    
    //------------------------------
    //  プレビュー用 マークダウン変換
    //------------------------------       
    public function getPreviewMarkData(array $folderObj): array
    {
        $config = $this->container->get('config');
        $basePath = $config['basePath'];

        $md = $_REQUEST['report-p']; //記事原文
        $title = $_REQUEST['pagename-p']; //タイトル
        $folderPath = $_REQUEST['folderPath-p']; //パス
        $folderName = $_REQUEST['folder-p']; //フォルダ名

        $folderPath = $folderObj[$folderName];
        $folderPath1 = str_replace('..', '', $folderPath);

        $htmlData = $this->parser->text($md);

        //画像のパスを変換
        $htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);
        //ファイルリンクのパスを変換
        $htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);

        //sampleのパスを変換
        $htmlData = preg_replace('/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="' . $basePath . $folderPath1 . '/sample/$2" target="_blank">$4</a>', $htmlData);

        //iframeのパスを変換
        $htmlData = preg_replace('/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i', '<iframe$1src="' . $basePath . $folderPath1 . '/sample/$2"$3></iframe>', $htmlData);

        $markArray = ['html' => $htmlData, 'title' => $title];

        return $markArray;    
    }
    
    

    //---------------------------
    //  マークダウン変換のみ
    //---------------------------

    public function convertToText(string $md): string
    {
        $html = $this->parser->text($md);
        
        $html = strip_tags($html);
                
        $html = preg_replace('/^\s*[\r\n]+/m', '', $html);
        
        return $html;        
    }
    
    
    
    //-------------------------------------------------------
    //  page_list（DB）からタイトルまたは本文内テキストから検索
    //-------------------------------------------------------

    public function searchKeyword(string $keyword, array $searchObj, bool $fullText): string
    {
        $db = $this->editService->db();//サービス

        if($fullText){
            //本文内検索
            $sql = $db->prepare("SELECT * FROM page_list WHERE text LIKE :keyword");
        }else{
            //タイトル検索
            $sql = $db->prepare("SELECT * FROM page_list WHERE title LIKE :keyword");
        }

        $sql->bindValue(':keyword', '%' . $keyword . '%');
        $sql->execute();

        $results = $sql->fetchAll();
        $htmlData = '';
        
        $resultCount = count($results);
        
        foreach($results as $val){
            
            if(!isset($searchObj[$val['fdName']])){
                continue;
            }
            
            $folderDir = $searchObj[$val['fdName']];
            $text = $val['text'];
            $title = trim($val['title']);
            
            $dirNonum = preg_replace('/\/\d{3}./','/',$folderDir).'/';
            $dirNonum = preg_replace('/\.\.\//','',$dirNonum);
            
            if($fullText){
                $patternDiff = '/'.$keyword.'/';
                $text = preg_replace($patternDiff, '<mark class="hilight">'.$keyword.'</mark>', $text);//検索文字にマークを付ける
            }
                        
            $htmlData = $htmlData.'<section><h3><a href="'.$dirNonum.'" >'.$title.'</a></h3><div class="search-text">'.$text.'</div></section>';           
        }
        
        $htmlData = '<p id="search-number">「'.$keyword.'」の検索結果：<span id="word-num">'.$resultCount.'</span>ページ</p>'.$htmlData;
        
        return $htmlData;        
    }
    
}
