*[page-title]:フォルダ削除(rmdir)

## フォルダを丸ごと削除する方法

参考サイト
https://www.sejuku.net/blog/78776

rmdirで指定したディレクトリ内にファイルや別のディレクトリが存在する場合は、rmdirでは指定したディレクトリを削除することができません。  
その際には、指定したディレクトリ内を一度空にした後で、再度rmdirでディレクトリを削除する必要があります。

ここでは、再帰的にディレクトリ内を削除する関数を作成して、ディレクトリ名を引数としてそれを実行しています。

※再帰的とは、プログラミング言語において処理中に自分自身を呼び出すことができるという性質のことです。

サンプルフォルダ
: `C:\xampp\htdocs\from_now\trunk\pages\p__php_dirdelete\sample\folder_delete`


ディレクトリ作成リンク
: 下記のリンクにアクセスすると、ディレクトリが作成されます。
: <a href="sample/folder_delete/dir_create.php" target="_blank">test1ディレクトリ作成</a>

<p class="tmp list"><span>リスト</span>dir_create.php</p>
```
<?php
// ディレクトリ、ファイルを作成
mkdir('test1');
mkdir('test1/test2');
touch('test1/test2/test3');
```
作成されたディレクトリ
![](upload/test1ディレクトリ.png)


ディレクトリを中身ごと丸ごと削除リンク
: 下記のリンクにアクセスすると、作成したディレクトリを中身ごと削除します。
: <a href="sample/folder_delete/dir_delete.php" target="_blank">test1ディレクトリ削除</a>

<p class="tmp list"><span>リスト</span>dir_delete.php</p>
```
<?php
// 再帰的にディレクトリを削除する関数
function remove_directory($dir) {
    $files = array_diff(scandir($dir), array('.','..'));
    foreach ($files as $file) {
        // ファイルかディレクトリによって処理を分ける
        if (is_dir("$dir/$file")) {
            // ディレクトリなら再度同じ関数を呼び出す
            remove_directory("$dir/$file");
        } else {
            // ファイルなら削除
            unlink("$dir/$file");
        }
    }
    // 指定したディレクトリを削除
    return rmdir($dir);
}

// 空ではないディレクトリを削除
remove_directory('test1');
```

