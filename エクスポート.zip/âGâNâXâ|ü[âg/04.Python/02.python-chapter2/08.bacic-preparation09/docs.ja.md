---
title: 08.内包表記
taxonomy:
    category:
        - docs
visible: true
---

内包表記という機能を使うと、リストなどのデータ構造を定義するプログラムを簡潔に書けることがあります。

例として、1から9までの整数を2乗した値を格納したリストを定義するプログラムをfor文とrange関数の繰り返し、リストのappendメソッドを使ったやり方と、内包表記を使用したやり方の2種類で書いて比較してみます。

<p class="inpre"><span>インタプリタ</span>for文とrange関数とappendメソッドを使ったやり方</p>
<pre>
>>> b = []
>>> for x in range(1, 10):
...     b.append(x ** 2)
...
>>> b
[1, 4, 9, 16, 25, 36, 49, 64, 81]
</pre>

<p class="inpre"><span>インタプリタ</span>内包表記を使ったやり方</p>
<pre>
>>> a = [x ** 2 for x in range(1, 10)]
>>> a
[1, 4, 9, 16, 25, 36, 49, 64, 81]
</pre>

このように、内包表記を使うと、同じリストを作るプログラムでも簡潔に書くことができます。


リストの内包表記は次のような書式でかきます。イテラブルの部分には、リストや文字列、range関数やenumerate関数を指定することができます。

<p class="tmp"><span>書式1</span>リストの内包表記</p>
<pre>
[式 for 変数 in イテラブル]
</pre>

※イテラブルから値を取り出し、変数に代入します。次に式を評価し、結果をリストに追加します。<br>
　以上を繰り返すことによって、リストを作成します。
 
<p class="inpre"><span>インタプリタ</span>1～9を2乗した値を表示</p>
<pre>
>>> [x ** 2 for x in range(1, 10)]
[1, 4, 9, 16, 25, 36, 49, 64, 81]
</pre>

<p class="inpre"><span>インタプリタ</span>1～9を3乗した値を表示</p>
<pre>
>>> [x ** 3 for x in range(1, 10)]
[1, 8, 27, 64, 125, 216, 343, 512, 729]
</pre>


<h3 class="h-type3">内包表記とif</h3>

内包表記とifを組み合わせると、条件に合う値だけをリストに追加することができます。

<p class="tmp"><span>書式2</span>リストの内包表記とif</p>
<pre>
[式 for 変数 in イテラブル if 条件]
</pre>

※イテラブルから値を取り出し、条件を評価します。条件がTrueの場合だけ、値を変数に代入し、式を評価して、結果をリストに追加します。<br>
　以上を繰り返すことによって、リストを作成します。

<p class="inpre"><span>インタプリタ</span>1から9までの整数のうち、3の倍数だけを格納したリストを内包表記を使って作成する</p>
<pre>
>>> [x for x in range(1, 10) if x % 3 == 0]
[3, 6, 9]
</pre>

※if x % 3 == 0　→ 3で割ったときの余りが0かどうか調べます。

<p class="tmp"><span>書式3</span>内包表記による集合の作成</p>
<pre>
{式 for 変数 in イテラブル if 条件}
</pre>

<p class="tmp"><span>書式4</span>内包表記による辞書の作成</p>
<pre>
{キーの式:値の式 for 変数 in イテラブル if 条件}
</pre>


<h3 class="h-type3">内包表記と三項演算子</h3>

三項演算子とは、条件に応じて異なる値を返す演算子です。Pythonでは条件式とも呼ばれますが、ここではif文と区別するのに三項演算子と呼びます。

<p class="tmp"><span>書式5</span>三項演算子</p>
<pre>
Trueの値 if 条件 else Falseの値
</pre>

※条件がTrueのときは「Trueの値」、Falseのときは「Falseの値」を返します。

※三項演算子を使わなくても、if文を使って同様の処理を実現することはできます。<br>
　しかし三項演算子を使うと、if文よりもプログラムを簡潔に書ける場合があります。

<div class="box-example">
    <h3 class="h-example">例1</h3>
Fizz Buzzゲームは、3の倍数のときには「Fizz」、5の倍数のときには「Buzz」、15の倍数のときには「FizzBuzz」といいます。<br>
このゲームのルールを一部取り入れて、xが3の倍数のときには'Fizz'を返して、3の倍数ではないときにはxの値をそのまま返すプログラムを書きます。
試しにxに2と3を代入した時の動作を確認してみます。
</div>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> x = 2
>>> 'Fizz' if x % 3 == 0 else x
2
>>> x = 3
>>> 'Fizz' if x % 3 == 0 else x
'Fizz'
</pre>


<div class="box-example">
    <h3 class="h-example">例2</h3>
1から9までの数を格納したリストを作成し、3の倍数については'Fizz'を格納します。<br>
    （ヒント）<br>
    1から9までの数を格納したリスト → <span class="bold">[x for x in range(1, 10)]</span>
</div>
<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> ['Fizz' if x % 3 == 0 else x for x in range(1, 10)]
[1, 2, 'Fizz', 4, 5, 'Fizz', 7, 8, 'Fizz']
</pre>

<div class="box-example">
    <h3 class="h-example">例3</h3>
   （内包表記のネスト）<br>
繰り返し構文をネスト（入れ子）にするように、内包表記もネストすることができます。
内包表記をネストにしたときの動作は、繰り返し構文をネストした時の動作に似ています。<br>
例えば次のような内包表記を書くことができます。    
</div>
<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> [x * y for x in range(1, 10) for y in range(1, 10)]
[1, 2, 3, 4, 5, 6, 7, 8, 9, 2, 4, 6, 8, 10, 12, 14, 16, 18, …  9, 18, 27, 36, 45, 54, 63, 72, 81]
</pre>

※xは1から9まで変化します。xの各値に対して、yは1から9まで変化します。これらのxとyを使って「x*y」を計算し、リストに格納します。<br>
　結果は九九の表になります。





