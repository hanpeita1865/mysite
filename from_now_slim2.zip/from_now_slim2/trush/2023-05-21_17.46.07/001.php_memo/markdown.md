*[page-title]:PHP（よく利用するもの）

## 配列の最初と最後を取得する

参考サイト
: [PHPで配列の最後の値を取得する](https://qiita.com/rana_kualu/items/e780778413dba6eed422)
: [PHP マニュアル array_key_first](https://www.php.net/manual/ja/function.array-key-first.php)
: [PHP マニュアル array_key_last](https://www.php.net/manual/ja/function.array-key-last.php)

<p class="tmp"><span>書式</span>end()</p>
```
$array = [1, 2, 3];
$value = end($array); // 3
```

<p class="tmp"><span>書式</span>array_key_last()</p>
```
// 配列ポインタを変えずに最後の値を取得
$array = [1, 2, 3];
$value = $array[array_key_last($array)]; // 3

// 関数も渡せる
function getArray(){ return [1, 2, 3]; }
$value = getArray()[array_key_last(getArray())]; // 3
```

## 配列の最後から何番目の値を取得する
参考サイト
: [２次元配列の最後から○番目の要素を取り出す](https://teratail.com/questions/304002)

関数を使って、後ろから2番目の値を取得しています。
<iframe src="https://paiza.io/projects/e/RI4AfnmbeEo2HQWoN0MFFg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## 改行

参考サイト
: [コピペだけで試せる! PHPの改行方法「PHP_EOL」の使い方](https://it-kyujin.jp/article/detail/1528/)
: [PHP で改行コードを変換・削除する方法](https://webgroove.work/php-convert-remove-newline/)

```
<?php
      echo 'ABCD';
      echo PHP_EOL;
      echo 'EFGH';
?>
```

<p class="result"><span>結果</span></p>
```
ABCD
EFGH
```
「ABCD」の後に改行が付きます。

<span class="bold">改行コードは、下記のように OS に環境依存します。</span>

* \r : Mac OS 9 以前
* \n : Linux, macOS 以降
* \r\n : Windows

改行コードを削除する場合は、下記のように str_replace で空文字列に変換するだけで実現できます。
```
function removeNewline(string $str): string {
  return str_replace(["\r\n", "\r", "\n"], '', $str);
}
```

## 変数の型を調べる

参考サイト
: [変数の型を調べる（確認） - gettype()](https://webkaru.net/php/function-gettype/)
<p class="tmp"><span>書式</span></p>
```
gettype( 変数 )
```
## list関数について

PHPでは、配列の値を複数の変数に1つずつ代入できるlist関数があります。

参考サイト
: [【PHP入門】list関数の基本から応用までわかりやすく解説！](https://www.sejuku.net/blog/24406)


## PHPを使ってHTMLに変換して出力

<div class="exp">
<p class="tmp"><span>例</span>DBS</p>
次のファイルに接続し、<kbd>HTML出力</kbd>をクリックすると、「db_diagram.php」のHTMLファイルを「affairs/propersheet.html」に出力します。
<a href="http://localhost:7001/dbs/trunk/dbs_legacy/_database/db_diagram.php" target="_blank">http://localhost:7001/dbs/trunk/dbs_legacy/_database/db_diagram.php</a><br>

<a href="http://localhost:7001/dbs/trunk/dbs_legacy/_database/html_output/" target="_blank">http://localhost:7001/dbs/trunk/dbs_legacy/_database/html_output/</a><br>

<a href="http://localhost:7001/dbs/trunk/dbs_legacy/affairs/propersheet.html" target="_blank">http://localhost:7001/dbs/trunk/dbs_legacy/affairs/propersheet.html</a>
</div>


<p class="lang">output_file.php</p>
```
<?php
$url = (empty($_SERVER['HTTPS']) ? 'http://' : 'https://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$urlArray = explode('?', $url);
$urlReplace = str_replace('html_output/output_file.php', 'db_diagram.php', $urlArray[0]);
$html = file_get_contents($urlReplace);
file_put_contents( '../../affairs/propersheet.html', $html )
?>
```


<p class="lang">html_output/index.html</p>
```
<button class="btn-output">HTML出力</button>

<p>HTMLに出力します。</p>

<script>
    function codeOutput() {
		$.ajax({
			url: 'output_file.php',
			type: 'GET',
			dataType: 'html',
			cache: false
		}).done(function(data){
			alert('HTMLを出力しました。')
			
		}).fail(function(){
			alert('HTMLの出力に失敗しました。')
		});
    }

    $('.btn-output').on('click',function(){
		if(window.confirm('出力しますか？')){
				codeOutput();
			return true;

		} else {
			return false;
		}  
        
    });	
</script>
```

## 配列を結合する

参考サイト
: [【PHP入門】配列を結合するさまざまな方法まとめ！](https://www.sejuku.net/blog/21685)

### array_mergeとは
array_merge関数を使用すると、配列の後ろに配列を追加（結合）することができます。

<p class="tmp"><span>書式</span></p>
```
array array_marge(最初の配列名, 追加する配列1,  (, 追加する配列2, …)
```
引数：
: 第一引数には最初の配列を指定します。
: 第一引数以降は追加していく配列を1つ、または複数指定します。

返り値：
: 結合した結果の配列を返します。

<div class="exp">
	<p class="tmp"><span>例</span></p>
<iframe src="https://paiza.io/projects/e/Ud0mlrsSIlFqp3ZxWvpJRA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


### implodeとは
implode関数は、配列の値を文字列で結合するときに使用します。

<p class="tmp"><span>書式</span></p>
```
string  implode('結合する文字列', 配列名)
```
<p class="tmp"><span>書式</span></p>
```
string  implode(配列名)
```
引数：
: 結合する文字列は配列の要素を指定した文字列で連結したいときに使用します。  
デフォルトは空文字列となります。

implode関数に関しては、引数をどちらの順番でも指定することができます。（歴史的な理由とのことです）  
しかし、混乱を避けるためにマニュアルやドキュメントに記載された順番で、使用するのが望ましいと言えます。

返り値：
: 配列の要素間に結合する文字列ではさんで1つの文字列にした値を返します。

<div class="exp">
	<p class="tmp"><span>例</span></p>
<iframe src="https://paiza.io/projects/e/QzHMgXTLJ7QNWWFqQQSSwg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

## 数字の桁数を指定する

### sprintfを使う
参考サイト
: [phpマニュアル](https://www.php.net/manual/ja/function.sprintf.php)

```
$i = 1;
echo sprintf('%02d', $i);
```


<p class="result"><span>結果</span></p>
```
01
```
	
```
echo sprintf("%'.9d\n", 123);
echo sprintf("%'.09d\n", 123);
```
<p class="result"><span>結果</span></p>
```
......123
000000123
```

### str_padを使う
```
$i = 1;
echo str_pad($i, 2, '0', STR_PAD_LEFT);
```

<p class="result"><span>結果</span></p>
```
01
```

## JSONを配列に変換（decode）

<div class="exp">
	<p class="tmp"><span>例</span></p>
	JSONをdecodeを使って、配列に変換します。
	<iframe src="https://paiza.io/projects/e/WM-Hx2yEjmmZjuI7fbUj8Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

## 関数 戻り値

参考サイト
: [戻り値を使って関数から値を返す](https://www.javadrive.jp/php/function/index4.html)

<iframe src="https://paiza.io/projects/e/Vr74bUcJTzQQcNQ3MVMjKw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## PHPのstaticプロパティとstaticメソッド、定数

参考サイト
: [PHPのstaticプロパティとstaticメソッド、定数](https://atmarkit.itmedia.co.jp/ait/articles/1803/20/news005.html)

## 再帰処理について

参考サイト
: [PHPで再帰処理を実装する方法を現役エンジニアが解説【初心者向け】](https://magazine.techacademy.jp/magazine/40767)

再帰処理とは、関数がメソッドの中で自分自身を呼び出す処理のことです。  
再帰処理は自分自身を呼び出すため適切な終了処理をしない限り無限ループになってしまう点に注意する必要があります。

再帰処理はなかなか処理内容を理解するのが難しいところですですが使えるようになるとソースをシンプルに書けるようになります。

<iframe src="https://paiza.io/projects/e/EQow8Ejxy2MR0TX0NzPp3A?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

参考サイト
: [PHPとJavaScriptで入れ子配列を平坦にする方法(再帰処理)](https://zenn.dev/chromel/articles/92858f7e827d1c)

<iframe src="https://paiza.io/projects/e/g8vddH0JHpRLFkKP0AfphQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## データをフィルタリングする filter_var()

参考サイト
: [PHPマニュアルfilter_var](https://www.php.net/manual/ja/function.filter-var.php)
: [フィルタの型 ](https://www.php.net/manual/ja/filter.filters.php)

例1 filter_var() の例
```
<?php
var_dump(filter_var('bob@example.com', FILTER_VALIDATE_EMAIL));
var_dump(filter_var('http://example.com', FILTER_VALIDATE_URL, FILTER_FLAG_PATH_REQUIRED));
?>
```
上の例の出力は以下となります。

<p class="result"><span>結果</span></p>
```
string(15) "bob@example.com"
bool(false)
```

## 配列の全ての要素にユーザー定義の関数を適用する array_walk

参考サイト
: [PHP マニュアル array_walk](https://www.php.net/manual/ja/function.array-walk.php)

<div class="exp">
	<p class="tmp"><span>例1</span></p>
<iframe src="https://paiza.io/projects/e/g6_QIuBA0OrAi7Uz7g_1Qg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例2</span></p>
	無名関数を使った、array_walk() の例
	<iframe src="https://paiza.io/projects/e/yX9U0g8w4-u3aZb9A68ifA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe src="https://paiza.io/projects/e/znRHYoP_UV7EQhdAx7qFdw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


## array_map_recursive

[array_map_recursiveはPHPに標準実装されていた！](https://qiita.com/mpyw/items/2967ea1e36a144f76587)

## 日本時間を取得

参考サイト
: [【PHP】本日の日付,時間,曜日を日本時間で表示させる（date）](https://dailyrecords.blog/archives/8439)
: [PHP 現在の日付や時間を取得したい](https://wepicks.net/phpsample-date-today/)

<iframe src="https://paiza.io/projects/e/zC48c-xm298ex-g7my0KHg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>