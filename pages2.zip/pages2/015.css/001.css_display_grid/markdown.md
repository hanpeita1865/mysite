*[page-title]:Grid Layout

参考サイト
* [CSS Grid Layout入門対応ブラウザが出揃った新しいレイアウト仕様](https://ics.media/entry/15649/)
* [【CSS グリッドレイアウト】display: gridの使い方](https://webst8.com/blog/css-display-grid/)

grid-template-columns
: <https://developer.mozilla.org/ja/docs/Web/CSS/grid-template-columns>

* grid-template-rows：トラックの高さを指定する
* grid-template-columns：トラックの幅を指定する


<p class="tmp">例</p>
```
grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
```
repeat関数の第一引数に指定されている「auto-fit」は、画面サイズからカラムが溢れてしまうとカラムを下に折り返す処理です。  
第二引数のminmax関数では、各カラムの横幅が200px以下になるまでサイズが変化するという処理です。  
上記の内容をまとめると、カラム幅が200pxになるまでは要素幅が変化し、200pxになると下に折り返すという処理になります。

<iframe height="300" style="width: 100%;" scrolling="no" title="Grid Layout （grid-template-column）" src="https://codepen.io/hanpeita/embed/mdjoeVP?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/mdjoeVP">
  Grid Layout （grid-template-column）</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

* auto-fillでは、親要素にスペースが余る場合、空のグリッドが作られます
* auto-fitでは、親要素にスペースが余る場合、グリッド・アイテムの幅が変わってスペースが埋められます

![](upload/auto-fill.gif)

## タイル状のレイアウトをGrid Layoutで
タイルが並ぶように同じ幅のアイテムが繰り返し配置されるレイアウトをGrid Layoutでつくってみます。

![](upload/image7.png)

<p class="lang">CSS</p>
```
.container {
  /* グリッドコンテナ */
  display: grid;
  /* 最小100px、最大1frの列を繰り返しつくる */
  grid-template-columns: repeat(
    auto-fill,
    minmax(100px, 1fr)
  );
  column-gap: 10px;
  row-gap: 10px;
}
```

デモ
: <https://ics-creative.github.io/170901_css_grid_layout/grid-layout-sample-tile/>