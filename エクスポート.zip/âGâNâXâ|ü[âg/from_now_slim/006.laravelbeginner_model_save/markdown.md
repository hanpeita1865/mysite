*[page-title]:モデルの保存・更新・削除

モデルを利用して、新しいレコードを保存したり、更新や削除をしたりするにはどうすればいいのでしょうか？ サンプルを作りながらそのやり方を覚えましょう。


## モデルの新規保存

モデル（レコード）の検索関係の基本はだいぶわかってきました。検索については、もっといろいろな機能がありますが、この辺りで検索以外のものについても目を向けることにしましょう。

まずは、モデルの新規保存からです。Eloquentでは、レコードはモデルのインスタンスとして扱われます。ということは、新たにレコードを作成したい場合は、モデルのインスタンスを作成し、保存する、というやり方になるのです。  
では、モデルを作成して保存するにはどうするのか、簡単に整理しておきましょう。

<span class="green">① <span class="marker-yellow50">モデルのインスタンスを作る</span></span>
: まずはインスタンスを作成します。これは、「<span class="red">new</span>」を使って作成することができます。

<span class="green">② <span class="marker-yellow50">値を設定する</span></span>
: インスタンスのプロパティに値を設定していきます。これは1つ1つのプロパティに値を代入していくやり方でもいいですし、値を設定するメソッドを利用するやり方もあります。

<span class="green">③ <span class="marker-yellow50">インスタンスを保存する</span></span>
: モデルクラスには、保存のための「<span class="red">save</span>」メソッドがあります。これを呼び出すと、そ のインスタンスの内容がテーブルのレコードとしてデータベース側に保存されます。  
このように「<span class="red bold">インスタンス作成</span>」→「<span class="red bold">プロパティ設定</span>」→「<span class="red bold">保存</span>」という手順がわかれば、モデルの保存はそう難しいことではありません。

では、ここではCustomersテーブルを使用していきます。

Customersテーブルは、マイグレーションとシーディングの章で既に作成されていると思います。


## モデルを修正する

では、customersに新しいレコードを保存する処理として、「/customer/add」というアクションを作成してみることにしましょう。  
最初に、モデルの修正を行います。Customer.phpを開き、Customerクラスを以下のように 修正して下さい（useは省略してあります）。

<p class="tmp list"><span>リスト1-1</span>Models/Customer.php</p>
```
class Customer extends Model
{
   protected $guarded = array('id');

   public static $rules = array(
      'name' => 'required',
      'address' => 'required',
      'login' => 'required',
      'password' => 'required'
   );

   // getDataは残しておく
   public function getData()
   {
      return $this->id . ': ' . $this->name . ' (' . $this->age . ') '. $this->login .' '. $this->password;
   }
}
```
静的プロパティの<span class="red">$rules</span>は、既に利用したことがあります。    
バリデーションのところで登場しました。バリデーションのルールをまとめたものです。
バリデーションのルールは、このようにモデルに用意しておいたほうが便利です。

もう1つの「<span class="red">$guarded</span>」というプロパティは、入力のガード（保護）を設定しておくもの です。例えばフォームから送信した値を元にインスタンスを作り、保存する場合を考えてみて下さい。モデルでは、基本的に必要となるすべての項目に値が揃っていて初めて 保存ができます。が、時には「値を用意しておかない項目」というものも存在します。

このようなときに用いられるのが、$guardedです。例えばプライマリキーであるidフィールドは、データベース側で自動的に番号を割り振るので、モデルを作成する際には値は必要ありません。  
こうしたものでは、$guardedでidを「値を用意しておかない項目」に指定しておくのです。こうすれば、値がnullであってもエラーなく動作します。


## add.blade.phpを作成する

モデルの修正ができたら、次はテンプレートを作りましょう。「views」内の「customer」フォルダの中に、「<span class="red">add.blade.php</span>」という名前でファイルを作ります。そして以下の ようにソースコードを記述しておきます。

<p class="tmp list"><span>リスト2-1</span>add.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Person.Add')

@section('menubar')
   @parent
   新規作成ページ
@endsection

@section('content')
	{{--<!-- エラーがある場合にのみ処理を実行 -->--}}
   @if (count($errors) > 0)
   <div>
       <ul>
           @foreach ($errors->all() as $error)
               <li>{{ $error }}</li>
           @endforeach
       </ul>
   </div>
   @endif
   <table>
        <form action="/customer/add" method="post">
            {{ csrf_field() }}
            <tr>
                <th>name: </th>
                <td><input type="text" name="name" value="{{old('name')}}"></td>
            </tr>
            <tr>
                <th>address: </th>
                <td><input type="text" name="address" value="{{old('address')}}"></td>
            </tr>
            <tr>
                <th>login: </th>
                <td><input type="text" name="login" value="{{old('login')}}"></td>
            </tr>
            <tr>
                <th>password: </th>
                <td><input type="text" name="password" value="{{old('password')}}"></td>
            </tr>
            <tr>
                <th></th>
                <td><input type="submit" value="send"></td>
            </tr>
        </form>
   </table>
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```

ここでは、レコードの内容を記述するフォームを用意しています。用意するコントロールは、2つのtype="text"と、1つのtype="number"です。前者がname、address、後者がageの値を入力するものになります。  
これらは、すべてvalueに前回送信された値を設定するようにしてあります。例えば、nameの項目を見るとこうなっています。
```
<input type="text" name="name" value="{{old('name')}}">
```
oldは、以前に説明しましたが、前回入力した値を取り出すのに使いました。 また、フォームの手前には、バリデーションのエラーメッセージを表示する処理を用意してあります。@if (count( $errors) > 0)で、エラーがある場合にのみ処理を実行するようにしてあります。そして、
```
@foreach ($errors->all() as $error)
	<li>{{ $error }}</li> 
@endforeach
```
このようにしてエラーメッセージをすべて表示させています。この辺りは既にやったことですが、モデルを利用する場合でもほぼ同じやり方になります。



## addおよびcreateアクションを追記する

では、「/customer/add」のアクションをコントローラに作成しましょう。「CustomerController.php」ファイルに以下のメソッドを追記します。

<p class="tmp list"><span>リスト3-1</span>CustomerController.php</p>
```
public function add(Request $request)
{
   return view('customer.add');
}

public function create(Request $request)
{
   $this->validate($request, Customer::$rules);
   $customer = new Customer;
   $form = $request->all();
   unset($form['_token']);
   $customer->fill($form)->save();
   return redirect('/customer');
}
```

このcreateメソッドで、モデルを保存しています。詳細は後で触れるとして、まずはアクションを完成させましょう。

### ルート情報を追加する
最後は、ルート情報の追記です。web.phpを開いて、末尾に以下の文を記述して下さい。

<p class="tmp list"><span>リスト3-2</span></p>
```
Route::get('customer/add', [\App\Http\Controllers\CustomerController::class,'add']);
Route::post('customer/add', [\App\Http\Controllers\CustomerController::class,'create']);
```

完成したら、「/customer/add」にアクセスして送信してみましょう。  
フォームが表示され、入力してaddボタンを押すと
![](upload/customer_addにアクセス.png){.photo-border}

<span class="arrow-down ml-5"></span>

追加したレコードが表示されます。
![](upload/customer_addにアクセス追加されました。.png){.photo-border}


### 保存処理の流れ
一通り動作することを確認したら、どのようにフォームからモデルの保存がされたのか、その処理の流れを見てみることにしましょう。

「CustomerControllerクラスのcreateメソッド内」のコードてす。

#### 1. バリデーションの実行

```
$this->validate($request, Customer::$rules);
```
バリデーションは、$requestそのものを引数に指定すれば、そこにあるさまざまな値 をチェックできます。ここでは、第2引数に、Customerクラスの静的プロパティ $rulesを指定してあります。モデルにルールなどを保管しておけば、このように必要に応じて取り出し、処理することができます。

#### 2. Customerインスタンスの作成
```
$customer = new Customer;
```
バリデーションを通過したら、いよいよ保存作業です。まず、Customerインスタンスを newで作成します。これは、ただnewするだけです。

#### 3. 値を用意する
```
$form = $request->all(); 
unset($form['_token']);
```
保管する値を用意します。これは送信されたフォームの値をそのまま使えばいいで しょう。ただし、フォームに追加される非表示フィールド「<span class="red">_token</span>」だけは unsetで削除 しておきます。  
この_tokenという値は、CSRF用非表示フィールドとして用意される項目です。これ自身は、テーブルにはないフィールドです。こうしたものは、あらかじめ削除しておきます。

#### 4. インスタンスに値を設定して保存
```
$customer->fill($form)->save();
```
フォームの値がまとめられた$formを引数にして「<span class="red bold">fill</span>」メソッドを呼び出します。この fillは、引数に用意されている配列の値をモデルのプロパティに代入するものです。フォームのようにまとまった値がある場合は、fillを使うことで、個々のプロパティをまとめて設定できます。

こうして値が設定されたら、後は「<span class="red bold">save</span>」を呼び出してインスタンスを保存します。
ここでは、fillを使って値を設定しましたが、もちろん1つ1つの値をインスタンスに設定していっても構いません。
```
$customer = new Customer;
$customer->name = $request->name;
$customer->login = $request->login;
$customer->password = $request->password;
$customer->save();
```

このように実行しても問題なく値は保存できます。やり方はいろいろありますが、「<span class="marker-yellow50 bold">インスタンスを作り、値を設定してsaveする</span>」という基本は同じなのです。


## モデルを更新する

続いて、モデルの更新です。更新処理は、あらかじめどのモデルを更新するかを指定し、そのモデルの内容を書き換えて保存することになります。保存までのアプローチは新規作成とは違いますが、「モデルを保存する」という点では、実は新規作成と同じなのです。  

新規作成が、newでインスタンスを作成したのに対し、更新ではモデルの「<span class="red bold">findメソッド</span>」で更新するモデルを取得します。そして、そのモデルの内容を書き換えて「<span class="red bold">save</span>」すればいいのです。

### edit.blade.php の作成
では、これも実際にやってみましょう。今回は、/customer/editというアクションとして更新処理を作成します。  
まずはテンプレートの用意です。「views」内の「customer」フォルダ内に「<span class="red">edit.blade.php</span>」 という名前でファイルを作成して下さい。そして以下のようにソースコードを記述します。

<p class="tmp list"><span>リスト4-1</span>edit.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Person.Edit')

@section('menubar')
   @parent
   編集ページ
@endsection

@section('content')
   @if (count($errors) > 0)
   <div>
       <ul>
           @foreach ($errors->all() as $error)
               <li>{{ $error }}</li>
           @endforeach
       </ul>
   </div>
   @endif
   <table>
		<form action="/customer/edit" method="post">
			{{ csrf_field() }}
			<input type="hidden" name="id" value="{{$form->id}}">
			<tr>
				<th>name: </th>
				<td><input type="text" name="name" value="{{$form->name}}"></td>
			</tr>
				<th>address: </th>
				<td><input type="text" name="address" value="{{$form->address}}"></td>
			</tr>
			<tr>
				<th>login: </th>
				<td><input type="text" name="login" value="{{$form->login}}"></td>
			</tr>
			<tr>
				<th>password: </th>
				<td><input type="text" name="password" value="{{$form->password}}"></td>
			</tr>
			<tr>
				<th></th>
				<td><input type="submit" value="send"></td>
			</tr>
		</form>
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```

フォームを用意する点は同じですが、今回は$formというオブジェクトから値を取り出して、それぞれのコントロールのvalueに設定する形にしてあります。また、「&lt;input type="hidden" name="id"&gt;」という非表示フィールドも用意してあります。


## editおよびupdateアクションを追記する

続いて、コントローラにアクションメソッドを追記します。今回は、「/customer/edit」というアクションになります。editとupdateメソッドの2つをCustomerControllerクラスに追記していきます。

<p class="tmp list"><span>リスト5-1</span>CustomerController.php</p>
```
public function edit(Request $request)
{
   $customer = Customer::find($request->id);
   return view('customer.edit', ['form' => $customer]);
}

public function update(Request $request)
{
   $this->validate($request, Customer::$rules);
   $customer = Customer::find($request->id);
   $form = $request->all();
   unset($form['_token']);
   $customer->fill($form)->save();
   return redirect('/customer');
}
```

基本的な処理には、実は新しいものなど何もありません。すべて既にやっていることだったりします。  
editでは、<span class="red">Customer::find</span>を使って<span class="red">idパラメータ</span>の値のモデルを取得し、これをformという値に設定しています。このCustomerインスタンスが、edit.blade.phpのフォームのvalue に表示されることになります。

肝心のモデル更新を行うupdateは、先ほど新規作成で作ったcreateメソッドと非常に似ています。違いは、newではなく<span class="red bold">Customer::find</span>でインスタンスを用意する、という点 だけです。  

<span class="red bold">Customer::find</span>でインスタンスを取得し、<span class="red">fill</span>で送信されたフォームの内容を反映し、<span class="red">save</span> を呼び出す。これでモデルの更新ができてしまいます。

### ルート情報を追記する 
最後に、ルート情報を追記してアクションを完成させましょう。web.phpに以下の文を追記して下さい。

<p class="tmp list"><span>リスト5-2</span>web.php</p>
```
Route::get('customer/edit', 'CustomerController@edit');
Route::post('customer/edit', 'CustomerController@update');
```

すべて記述したら、「/customer/edit?id=番号」というように、idパラメータを付けてアクセスをして下さい。これで、指定のIDの内容がフォームに表示されます。
![](upload/customer_editにアクセス.png){.photo-border}

<span class="arrow-down ml-5"></span>

そのままフォームの値を書き換えて送信すると、モデルの内容が書き換わります。
![](upload/customer_editにアクセスchuya0110に変更.png){.photo-border}

<span class="arrow-down ml-5"></span>

変更後の表示。データが書き換わりました。
![](upload/customer_editにアクセスchuya0110に変更結果.png){.photo-border}



## モデルの削除

残るは、モデルの削除です。削除は、非常に簡単です。モデルのインスタンスから、「<span class="green bold marker-yellow50">delete</span>」メソッドを呼び出すだけです。

<p class="tmp"><span>書式1</span></p>
```
モデルインスタンス ->delete();
```

このような形です。引数などは必要ありません。では、これもサンプルを作成して試してみましょう。

### del.blade.php を作成

まず、テンプレートから作成をします。「views」内の「customer」フォルダ内に「<span class="red">del.blade.php</span>」という名前でテンプレートファイルを作成して下さい。そして以下のように記述をします。

<p class="tmp list"><span>リスト6-1</span>del.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Customer.Delete')

@section('menubar')
   @parent
   削除ページ
@endsection

@section('content')
   <table>
		<form action="/customer/del" method="post">
			{{ csrf_field() }}
			<input type="hidden" name="id" value="{{$form->id}}">
			<tr>
				<th>name: </th>
				<td>{{$form->name}}</td>
			</tr>
				<th>address: </th>
				<td>{{$form->address}}</td>
			</tr>
			<tr>
				<th>login: </th>
				<td>{{$form->login}}</td>
			</tr>
			<tr>
				<th>password: </th>
				<td>{{$form->password}}</td>
			</tr>
			<tr>
				<th></th>
				<td><input type="submit" value="send"></td>
			</tr>
		</form>
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```

フォームは用意されていますが、項目として用意してあるのは&lt;input type="hidden" name="id"&gt;の非表示フィールドだけです。これでIDの値を送信し、そのIDのモデルを検索して削除する、というわけです。

「続いて、コントローラです。今回は、「<span class="red">delete</span>」と「<span class="red">remove</span>」の2つのメソッドを用意します。 CustomerControllerクラスに、以下のメソッドを追記して下さい。

<p class="tmp list"><span>リスト6-2</span>CustomerController.php</p>
```
public function delete(Request $request)
{
   $customer = Customer::find($request->id);
   return view('customer.del', ['form' => $customer]);
}

public function remove(Request $request)
{
   Customer::find($request->id)->delete();
   return redirect('/customer');
}
```

コントローラのdeleteメソッドでは、「<span class="red">Customer::find</span>」で検索したモデルをそのままformという変数に設定してテンプレートに渡しています。これは、実は更新処理のeditメソッドと同じものです。  
削除を実行しているremoveメソッドでは、やはりCustomer::findで指定のIDのモデルを検索し、モデルのdeleteを呼び出して削除をします。非常にシンプルです。

### ルート情報の追加

最後にルート情報を追記しておきましょう。web.phpに以下の文を追記して下さい。 これで削除処理は完成です。
<p class="tmp list"><span>リスト6-3</span>web.php</p>
```
Route::get('customer/del', [\App\Http\Controllers\CustomerController::class,'delete']);
Route::post('customer/del', [\App\Http\Controllers\CustomerController::class,'remove']);
```

更新処理と同様に「<span class="red">/customer/del?id=番号</span>」というようにID番号をパラメータに指定してアクセスします。そのIDの内容が表示されます。そのままボタンを押して送信すれば、そのモデルが削除されます。

「徳川家康」のデータを削除してみます。
![](upload/徳川家康削除前.png){.photo-border}

<span class="arrow-down ml-5"></span>

「/customer/del?id=22」にアクセスして、sendをクリックします。
![](upload/徳川家康削除フォーム.png){.photo-border}

<span class="arrow-down ml-5"></span>

「徳川家康」のデータが削除されました。
![](upload/徳川家康削除後テーブル.png){.photo-border}



### モデルとDBクラスの共通性

これで、モデルを使ったCRUDの基本が一通りわかりました。実際にやってみて、どこか見たことがある感じがしたことでしょう。  
Eloquentによるモデル操作は、DBクラスのクエリビルダを使った操作に似ています。whereによる検索や、deleteによる削除はほぼ同じですし、新規作成や更新の手順が違っているぐらいでしょう。

が、「<span class="marker-yellow50 bold">モデルにメソッドを追加したり、スコープを使った絞り込み</span>」をしたりするなど、 モデルにはDBクラスにない強力な機能がいろいろと揃っています。<span class="marker-yellow50">より本格的な開発には、「<span class="bold">Eloquentによるモデル</span>」</span>、<span class="marker-yellow50">比較的簡単でシンプルな操作には「<span class="bold">DBクラス</span>」</span>、というように、開発内容に合わせてどちらでも使えるようにしておくとよいでしょう。

