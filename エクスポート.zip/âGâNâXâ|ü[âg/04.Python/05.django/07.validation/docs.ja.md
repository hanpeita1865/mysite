---
title: バリデーションを使いこなそう
media_order: 'form_validation.png,check_form.png,check_form1.png,check_form2.png,check_form3.png,check_form4.png,check_form5.png,check_form6.png,check_form7.png'
taxonomy:
    category:
        - docs
---

モデルを作成したり編集する場合、考えなければいけないのが「値のチェック」です。  
モデルは、データベースにデータを保存します。  
そのデータに問題があった場合、知らずに保存するとエラーになったり、あるいは保存したデータが原因で思わぬトラブルが発生したりするでしょう。  
モデルを使わない、一般的なフォームでも事情は同じです。  
フォームに記入する値が正しい形で入力されているかどうかをきっちり調べておかないと後でエラーにつながってしまいます。  
こうした「値のチェック」のために用意されている機能が「バリデーション」と呼ばれるものです。  
バリデーションは、フォームなどの入力項目に条件を設定し、その条件を満たしているかどうかを確認する機能です。  
条件を満たしていれば、そのままレコードを保存したり、フォームの内容をもとに処理を実行したりします。  
満たしていない場合は、再度フォームページに移動してフォームを再表示すればいいのです。  

このバリデーションは、「できれば覚えておきたい」機能と考えて下さい。  
今すぐでなくてもいいですが、実際に本格的なWebアプリを作るようになると、必ず必要になってくる機能です。  
全部は無理でも、基本的な使い方ぐらいは頭に入れておきたいですね。  

![](form_validation.png?classes=caption "図　フォームには、バリデーション機能を持たせることができる。これを利用して値をチェックし、問題ない場合に限り処理を行うようにすればいい。")


## forms.Formのバリデーション

まずは、モデルを使わない、一般的なフォームでのバリデーションについて見てみましょう。  
Djangoでは、フォームはforms.Formというクラスの派生クラスとして作成をしました。  
そこでは、CharFieldなど各種のフィールドクラスを使ってフォームの項目を作成していましたね。  
先に、Friendのレコード作成を行うために「HelloForm」を作成しました。  
これがどんなものだったか見てみましょう。

<p class="mb-05"><span class="tmp list">リスト4-8</span><span class="bold">forms.pyのクラスHelloForm</span></p>

```
class HelloForm(forms.Form):
    name = forms.CharField(label='Name')
    mail = forms.EmailField(label='Email')
    gender = forms.BooleanField(label='Gender',required=False)
    age = forms.IntegerField(label='Age')
    birthday = forms.DateField(label='Birth', required=False)
```

こんな感じのものでしたね、ここではさまざまなフィールドを用意しています。
よく見ると、その引数に、label以外のものが設定されているのがわかります。

```
required=False
```

こういうものです。これは何か?というと、実はこれが「バリデーションの設定」なのです。  
この**{c:red}required{/c}**は、「必須項目」として設定するためのバリデーション機能です。  
その値を**{c:red}False{/c}**に設定することで、必須項目でないようにしていたのですね。  

なぜ、そんなことをする必要があるのか? それは、Djangoでは、forms.Formにフィールドの項目を用意すると、「**{c:red}自動的にrequiredがTrueに設定される{/c}**」ためです。  
つまり何もしないとすべての項目が必須項目扱いとなるんですね。  
そこで、「これは必須項目にはしたくない」というものに、「required=False」を用意しておいた、というわけです。  
こんな具合に、forms.Formのバリデーションは、フィールドのインスタンスを作成する際に、必要ないバリデーションの設定を引数として用意しておくだけです。  
実に簡単ですね。  


## バリデーションをチェックする

このバリデーションは、どうやってチェックするんでしょう。  
モデル用のフォーム（models.Form）の場合なら、saveするときにチェックを自動的に行うなど想像ができますが、一般的なフォームの場合、送られたフォームの値を自分で取り出して利用するのが、一般的です。  
となると、バリデーションはいつどうやって行うんでしょうか。  
答えは、「自分でやる」です。つまり、自分で送られた値のチェックを行い、その結果に応じて処理をするようにスクリプトを組んでやらないといけないんです。  
といっても、これはそれほど難してものではありません。

<p class="mb-05"><span class="tmp">書式1</span><span class="bold">値のチェック</span></p>

```
if (《Form》.is_valid()):
	･･･エラー時の処理･･･
else:
	･･･正常時の処理･･･
```


こんな具合に、forms.Formの「**{c:red}is_valid{/c}**」というメソッドを使ってバリデーションチェックを行います。  
このメソッドは、フォームに入力された値のチェックを行い、1つでもエラーがあった場合にはFalseを、まったくなかった場合はTrueをそれぞれ返します。  
この値をチェックして、Falseならばエラー時の処理をおこなえばいいのです。


### バリデーションを使ってみる

では、実際にバリデーションを利用してみることにしましょう。  
今回は、新たにcheckというページを作ってバリデーションを試すことにします。  
まず、テンプレートを用意しましょう。  
「template」フォルダ内の「hello」フォルダの中に、新たに「check.html」という名前でファイルを作成しましょう。  
そして以下のようにソースコードを記述してください。

<p class="mb-05"><span class="tmp list">リスト4-9</span><span class="bold">check.htmlを作成</span></p>

```
{% load static %}
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>{{title}}</title>
    <link rel="stylesheet" type="text/css" 
        href="{% static 'hello/css/style.css' %}" />
</head>
<body>
    <h1>{{title}}</h1>
    <p>{{message}}</p>
    <table>
        <form action="{% url 'check' %}" method="post">
        {% csrf_token %}
        {{ form.as_table }}
        <tr><td></td><td><input type="submit" value="click"></td></tr>
        </form>
    </table>
</body>
</html>
```


## urlpatternsの追記

作成したら、URLの登録を行っておきましょう。  
「hello」フォルダ内のurls.pyを開き、urlpatternsの値に以下の文を追加してください。

<p class="mb-05"><span class="tmp list">リスト4-10</span><span class="bold">urls.pyのurlpatternsに追記</span></p>

```
path('check', views.check, name='check'),
```

urlpatternsの設定は、もう今まで何度となくやってきたので書き方はわかりますね?  
最後の記号の手前辺りを改行して追記するとよいでしょう。


## CheckFormの作成

続いて、フォームを用意します。  
ここでは、CheckFormというクラスとして作成しておくことにします。  
「hello」フォルダ内のforms.pyを開き、以下のスクリプトを追記してください。


<p class="mb-05"><span class="tmp list">リスト4-11</span><span class="bold">forms.pyに追記</span></p>

```
class CheckForm(forms.Form):
    str = forms.CharField(label='Name')
```

これは、「とりあえず動くかどうかチェック」というものなので、1つのフィールドを用意しておくだけにしてあります。  
これから、このクラスをいろいろと書き換えてバリデーションを検証していくことになります。



## check関数を作る

では、ビュー関数を用意しましょう。  
「hello」フォルダ内のviews.pyを開き、以下のcheck関数を追記してください。

<p class="mb-05"><span class="tmp list">リスト4-12</span><span class="bold">views.pyにcheck関数を追記</span></p>

```python
from .forms import CheckForm    #☆

def check(request):
    params = {
        'title': 'Hello',
        'message':'check validation.',
        'form': CheckForm(),
    }
    if (request.method == 'POST'):
        form = CheckForm(request.POST)
        params['form'] = form
        if (form.is_valid()):
            params['message'] = 'OK!'
        else:
            params['message'] = 'no good.'
    return render(request, 'hello/check.html', params)
```

ここでは、CheckFormクラスを利用するので、最初の行にあるimport文を追記しておくのを忘れないようにしてください。  

ここでは、POST送信された場合、以下のようにしてバリデーションのチェックをしています。  

```
if (form.is_valid()):
```

これでエラーがあれば、**{c:red}params['message']='OK!'{/c}** を実行します。  
そうでなければ、**{c:red}params['message']='no good.'{/c}** を実行します。  
バリデーションの結果に応じて、**{c:red}params['message']{/c}** のメッセージを設定しているわけです。  

![](check_form.png?classes=caption "図　用意されたフォームの完成した状態。まだ現段階ではビュー関数がないので表示されない。")



## サンプルフォームでバリデーションチェック

では、実際にフォームを送信してバリデーションをチェックしてみましょう。  
CheckFormにし、CharFieldが1つだけ用意されています。  
引数には、label以外には何もありません。ということは、requiredというバリデーションのも設定されていることになりますね。

では、何も入力しないで送信してみましょう。  
すると、フォームのところにエラーメッセージが表示されるはずです。  
これは、Webブラウザに組み込まれているバリデーション機能です。  
HTML5では、フォームの入力フィールドに簡単なチェック機能が組み込まれており、未入力だとこのようにブラウザのチェック機能が働くようになっているのです。  
ブラウザによる機能ですから、ブラウザによって表示のスタイルやメッセージは違います。

また、バージョンの古いブラウザなどでは、（まだこの機能が実装されてないため）動作しないこともあります。

入力フィールドの上を見ると、「check validation:」とテキストが表示されているのがわかりますね。  
初期状態のメッセージのままになっています。  
つまり、このフォームには送信されていないのです。  
何も書いてない状態で送信ボタンを押すと、ブラウザの機能により送信そのものがキャンセルされ、エラーメッセージが表示されているんです。

![](check_form1.png?classes=caption "図　未入力だと表示されるエラー。これはブラウザに組み込まれている機能だ。")


## Djangoでのバリデーションチェック

では、入力フィールドに半角スペースを1つだけ書いて送信してみましょう。  
今度は、先ほどのエラーは表示されず、フォームは送信されます。  
そして、「This field is required.」といったメッセージが表示されます。

![](check_form2.png?classes=caption "図	半角スペースを書いて送信すると、このようにサーバー側でバリデーションチェックを行い、結果を表示している。")

これは、Django側でのバリデーションチェックの結果です。  
フィールドの上には「no good」とテキストが表示されています。  
これはcheck関数で、is_validメソッドの結果がFalseだった場合に表示されるメッセージでしたね。  
つまり、フォームが送信され、is_validでバリデーションのチェックが実行され、エラーになったのです。  
バリデーションのチェックは、こんな具合に「Webブラウザ側のチェック機能」と「Djangoでのチェック機能」の2つが組み合わさって動いていることがわかります。


## どんなバリデーションがあるの?

Djangoのバリデーション機能がちゃんと動いていることはこれでわかりました。  
Formにフィールドを用意し、バリデーションの設定を用意すれば、Django側ではis_validだけでチェックを行えます。  
問題は、「どんなバリデーションが使えるのか」でしょう。  
これがわからないと設定のしようがありません。  
また、バリデーションは、入力する値の種類によっても用意されるものが違ってきます。  
どういうフィールドではどんなバリデーションが使えるのかがわかっていないといけません。  
では、Djangoに用意されているforms.Formのフィールド用バリデーションについて簡単にまとめておきましょう。


### CharFieldのバリデーション

もっとも基本となる、テキスト入力フィールド「CharField」に用意されているバリデーションです。
これは以下のようなものがあります。

required
: 既に触れましたが、必須項目とするものでしたね。
Trueならば必須項目、Falseならばそうではないようにします。

min_length, max_lemgth
: 入力するテキストの最小文字数、最大文字数を指定するものです。
これらはいずれも整数値で指定します。

empty_value
: 空の入力を許可するかどうかを指定します。
requiredと似ていますか、requiredでは、例えば半角スペース1個だけの入力などはエラーになりますが、empty_valueではOKです。

これらのバリデーションは、CharFieldだけでなく、その他のテキスト入力を行うためのフィールド（EmailFieldやURLFieldなど）でも同じように使えます。


### min_length/max_lengthを試す


実際にこれらをフォームに設定して動作を確認してみましょう。
先ほど作ったCheckFormを修正してみます。
「hello」フォルダを開き、forms.pyを開いて、そこにあるCheckFormクラスのスクリプトを以下のように修正しましょう。

<p class="mb-05"><span class="tmp list">リスト4-13</span><span class="bold">forms.pyのCheckFormクラスのスクリプトを修正</span></p>

```
class CheckForm(forms.Form):
    empty = forms.CharField(label='Empty', empty_value=True)
    min = forms.CharField(label='Min', min_length=10)
    max = forms.CharField(label='Max', max_length=10)
```

![](check_form3.png?classes=caption "図　修正したフォーム、3つの項目を用意してある")

今回は、3つのCharFieldを用意してみました。  
それぞれにempty_value、min_length、max_lengthを設定してあります。

実際にアクセスをして、入力を確かめてみましょう。  
emptyフィールドは、半角スペースのみの入力を許可します（エラーになりません）。  
minは、10文字以上を入力する必要があります。  
またmaxは10文字以下の入力のみ受け付けます。  
いろいろとテキストを記入して、実際にエラーとして判断されるか確認してみましょう。

![](check_form4.png?classes=caption "図　送信すると、ブラウザ側で設定されるエラーメッセージが表示される。")


### IntegerField/FloatFieldのバリデーション

続いて、数値を扱うIntegerFieldについて見てみましょう。  
数字関係のフィールドは他にもあります。  
forms.FloatFieldという実数を入力するフィールドも使いますね。  
これら数値関係のフィールドは、用意されているバリデーションのルールも同じです。  
まとめて説明しておきましょう。

	required

必須項目とするものでしたね。Trueならば必須項目、Falseならばそうではないようにします。  
これもIntegerFieldで利用できます。

	min_value, max_value

入力する数値の最小値、最大値を指定するものです。  
これらはいずれも整数値で指定します。

これも実際に使ってみましょう。  
「hello」フォルダ内のforms.pyを開き、CheckFormクラスを以下のように書き換えて下さい。

<p class="mb-05"><span class="tmp list">リスト4-14</span><span class="bold">forms.pyのCheckFormクラスを修正</span></p>

```
class CheckForm(forms.Form):
    required = forms.IntegerField(label='Required')
    min = forms.IntegerField(label='Min', min_value=100)
    max = forms.IntegerField(label='Max', max_value=1000)
```

今回は、min_value=100, max_value=1000をそれぞれ指定してあります。  
どちらもWebブラウザ側のチェック機能が働くようになっているのがわかるでしょう。

![](check_form5.png?classes=caption "図　今回用意したフィールド、3つの整数を入力するフィールドがある。")

![](check_form6.png?classes=caption "図　入力すると、Webブラウザのチェック機能が働く。")



### 日時関連のバリデーション

DateField、TimeField、DateTimeFieldといった日時関連のフィールドには、requiredの他に、フォーマットに関するバリデーションが設定されています。  
日時の形式に合わない値が入力されるとエラーになります。  
この日時のフォーマットは、「inpuut formats」という引数で指定することができます。  
これは以下のような形で指定します。

<p class="mb-05"><span class="tmp">書式2</span><span class="bold">inpuut formats</span></p>

```
input_formats=[フォーマット1,フォーマット2,…]
```


input formatsは、リストの形で値を指定します。  
リストには、フォーマット形式を表すテキストを必要なだけ用意します。


### フォーマットの書き方

フォーマットは、日時の各値を表す記号を組み合わせて作成します。  
用意されている記号には以下のようなものがあります。

| 	  |			 | 
| --- | -------- |
|**%y** |年を表す数字|
|**%m**	|月を表す数字|
|**%d**	|日を表す数字|
|**%H**	|時を表す数字|
|**%M**	|分を表す数字|
|**%S**	|秒を表す数字|


これらを使って、入力するテキストの形式を作っていきます。  
例えば、'%y/$m/%d'とすれば、2018/1/2のような形式のフォーマットになります。

では、これも実際に試してみましょう。
「hello」フォルダ内のforms.pyを開き、CheckFormクラスを以下のように修正します。

<p class="mb-05"><span class="tmp list">リスト4-15</span><span class="bold">forms.pyのCheckFormクラスを修正</span></p>

```
class CheckForm(forms.Form):
    date = forms.DateField(label='Date', input_formats=['%d'])
    time = forms.TimeField(label='Time')
    datetime = forms.DateTimeField(label='DateTime')
```

最初のフィールドには、**input_formats=['%d']** という形でフォーマットを設定しています。  
これで、日付を表す整数（1～31の間の数）が入力できるようになります。  
その他の2つは、正しい形式でなければエラーになります。  
Timeならば「時:分」という形式、日付ならば「日/月/年」という形式で記述します。  

![](check_form7.png?classes=caption "図　1番目は、1～31の整数だけでOK。他は正しい形式で記入しないとエラーになる。")



## バリデーションを追加する

デフォルトで用意されているバリデーションは、それほど多くはありません。  
ごく基本的なものだけなのがわかるでしょう。

もう少し、独自に「こういうときにバリデーションエラーになって欲しい」という処理を追加したいこともあります。
このような場合は、Formクラスにメソッドを追加します。  
こんな感じです。

```
class クラス名(forms.Form):
	･･･値の処理･･･

	def clean(self):
		変数 = super().clean()
		･･･値の処理･･･
```

「**clean**」というメソッドは、用意された値の検証を行う際に呼び出されます。  
このメソッドでは、最初にsuper().clean()というものを呼び出して、基底クラス（継承する元になっているクラス）のcleanを呼び出します。  
戻り値には、チェック済みの値が返されます。  
ここで、super().clean()で得られた値から値を取り出し、チェックを行えばいいのです。  
そこでもし、「こういう場合はエラーにしよう」となったらどうするか。

エラーを発生させればいいのです!









