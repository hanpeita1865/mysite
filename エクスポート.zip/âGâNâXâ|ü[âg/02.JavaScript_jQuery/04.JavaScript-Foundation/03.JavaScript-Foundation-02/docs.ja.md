---
title: '03. 算術演算子、小数点切り捨て、乱数'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    .bold {font-weight: bold;}
    .red {color: red;}
</style>

<h2 class="h-type2">算術演算子</h2>

算術演算子は，数値や変数の計算に使います．標準的な算術演算子には，足し算（+），  
引き算（-），掛け算（*），割り算（/），剰余（%）があります．

<iframe width="100%" height="300" src="//jsfiddle.net/a32gfe1b/16/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


---

##論理演算子

<table>
<thead>
<tr>
<th style="text-align: center;">演算子</th>
<th style="text-align: center;">使用例</th>
<th style="text-align: center;">意味</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: center;">&amp;&amp;</td>
<td>条件式1 <span class="red">&amp;&amp;</span> 条件式2</td>
    <td>条件式1 と 条件式2 が共に「true」の場合に「<span class="bold">true</span>」</td>
</tr>
<tr>
<td style="text-align: center;">||</td>
    <td>条件式1 <span class="red">||</span> 条件式2</td>
<td>条件式1 か 条件式2 の少なくとも一方が「true」の場合に「<span class="bold">true</span>」</td>
</tr>
<tr>
<td style="text-align: center;">!</td>
<td><span class="red">!</span>条件式</td>
<td>条件式が「true」の場合に「<span class="bold">false</span>」、条件式がfalseの場合に「<span class="bold">true</span>」</td>
</tr>
</tbody>
</table>

 判定の結果を変数b、c、dに格納して表示しています。
<!--
<iframe width="100%" height="400" src="//jsfiddle.net/g8wanse5/2/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>-->

<iframe width="100%" height="400" src="//jsfiddle.net/hirao/qfh6rdy7/2/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>



<h2 class="h-type2">小数点切り捨て</h2>

小数点切り捨ては，以下のコードで行います．

<iframe width="100%" height="150" src="//jsfiddle.net/a32gfe1b/22/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

答えは「1」と表示されるはずです．  
小数点第n位を切り捨てをしたいところですが，JavaScriptにはその機能がありません．  
そこで，次のような計算を行います．

<iframe width="100%" height="170" src="//jsfiddle.net/a32gfe1b/23/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

「1.44」と表示されます．難しそうですが，実は簡単なことです．  
Math.pow(10, n)は10のn乗という意味です．つまり，

<iframe width="100%" height="170" src="//jsfiddle.net/st37hrwn/4/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

ということです．小数点の位置をずらしてから切り捨て，位置を戻しただけです．  
ちなみに，小数点切り上げはMath.ceil，四捨五入はMath.roundを使います．

---

<h2 class="h-type2">乱数</h2>

乱数の発生は，以下のコードで行います．

<iframe width="100%" height="150" src="//jsfiddle.net/st37hrwn/19/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

結果を確認するたび，数値が変わることがわかります．Math.random()は0～1未満の乱数を発生させます．
もし，0～10の整数の乱数を発生させたいときは次のようにします．

<iframe width="100%" height="150" src="//jsfiddle.net/st37hrwn/22/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

11を掛けることで0～11未満の乱数を発生させ，小数点切り捨てを行っています．  
このように，任意の数値内で乱数を発生させるには工夫が必要です．
