<?php
globAll('../pages');

function globAll($folder) {

    $res = glob($folder . '/*'); 

    foreach ($res as $key => $f) {
        $dirArray = explode('/', $f);
        $lastDir = end($dirArray); //配列の最後の値

        //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
        if (preg_match('/^\d{2}./', $lastDir)) {
            echo '<li>'.$lastDir.'</li>';
            globAll($f);
        }
    }
}

?>
