<?php
namespace Asia¥¥Japan¥¥Hokkaido¥¥Hokkaido¥¥Sapporo;
function hello() {
        return 'もしもし';
}