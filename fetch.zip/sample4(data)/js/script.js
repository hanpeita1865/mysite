

// 送信するJSON
let data = [
	{
		"title": "K331",
		"category": "Classic",
		"release_date": "2019-11-25"
	},
	{
		"title": "Paradise",
		"category": "Rock",
		"release_date": "2019-12-18"
	},
	{
		"title": "Baby",
		"category": "Pops",
		"release_date": "2020-01-07"
	}
];

// FormDataオブジェクトを作成してJSON形式のデータをセット
let fd = new FormData();
fd.append('data', JSON.stringify(data));

// Fetch APIでデータ送信
fetch('exit/exit.php', {　// 送信先URL
	method: 'post', // 通信メソッド
	body: fd // JSON形式のデータをセットしたFormDataオブジェクト
})
	.then(response => response.text())
	.then(data => {
		console.log(data);
	});