sideNav = function(){

	scrollPos = $(window).scrollTop(); //トップからの位置
	headerHeight = $('header').outerHeight(); //headerの高さ
	menuPos = $('#left-menu').offset().top;//サイドメニューのある外側の要素の位置
	navHeight = $('#side-nav').outerHeight(true); //navの高さ
	scrollNav = scrollPos + navHeight //スクロール位置にサイドメニューの高さを足した数値
	footerPos = $('footer').offset().top;//フッターの位置

	//スクロールがサイドメニューの位置まできたらフローティング
	if (scrollPos > menuPos ) {
		$('#side-nav').addClass('position-fixed');
	}else{
		$('#side-nav').removeClass('position-fixed');
	}
	
	//フッターに来たらフローティング解除し、フッターの手前に固定
	if(scrollNav > footerPos) { 
		$('#side-nav').removeClass('position-fixed');
		$('#side-nav').addClass('position-bottom');	
	}else {
		$('#side-nav').removeClass('position-bottom');
	}
}

//ブラウザ高さがサイドメニューより小さい時の処理
winNavi = function(){
	
	winH = $(window).height();//画面高さ取得
	navH = $('#side-nav').outerHeight(true);//サイドメニューの高さ

	if(navH>winH){

		if ( $('#side-nav').hasClass('position-fixed') ){
			$('#side-nav').removeClass('position-fixed');
		}
		
		if ( $('#side-nav').hasClass('position-bottom') ){
			$('#side-nav').removeClass('position-bottom');
		}
		
	}
}

//画面をスクロール
$(window).on('scroll', function() {
	sideNav();
	winNavi();
});

//画面をリサイズ
$(window).on('resize', function() {
	sideNav();
	winNavi();
});
