*[page-title]:ログイン機能設定



## ログイン画面作成

参考サイト
: [ログインのデザインまとめ](https://design-library.jp/ui/category/login)

日清食品ログイン
: https://store.nissin.com/account/login?return_url=%2Faccount

商品一覧管理ページを表示する前のログインフォームを作成します。

資材
: C:\xampp\htdocs\php\shop1


### ユーザー用のテーブル作成

ユーザー名とパスワードを登録するテーブルを次の構造で作成します。
![](upload/userテーブル構造.png "図　テーブル構造"){.photo-border}

![](upload/userテーブル表示.png "図　テーブル表示"){.photo-border}


### ログインフォームを作成

ログインするフォームを作成します。ここには、ユーザ名とパスワードを入力するようにします。
![](upload/ログイン画面.png)

<http://localhost:7001/php/shop1/login.php>

<p class="tmp list"><span>リスト</span>HTML</p>
```
<form action="login-output.php" method="post" id="login-form">
	<h1>ログイン</h1>
	<dl>
		<dt>ユーザー名</dt>
		<dd><input type="text" id="user" name="user_name" value=""><span></span></dd>
		<dt>パスワード</dt>
		<dd><input type="password" id="pass" name="password" value=""><span></span></dd>
	</dl>
	<p class="submit"><input type="submit" id="login-button" value="ログイン"></p>
</form>
```


<p class="tmp list"><span>リスト</span>CSS</p>
```
form#login-form, form#logout-form {
    width: 600px;
    height: auto;
    background: #ffffff;
    border: 1px solid #cccccc;
    border-radius: 7px;
    box-shadow: 0 0 7px rgba( 0, 0, 0, 0.2 );
    padding: 40px 0;
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate( -50%, -55% );
}

form#login-form h1, form#logout-form h1 {
    width: 85%;
    margin: 0 auto;
    font-size: 215%;
    text-align: center;
    letter-spacing: 0.08em;
    text-shadow: 3px 4px 2px rgba( 0, 0, 0, 0.1 );
}

form#login-form dl {
    width: 80%;
    margin: 15px auto 0;
}

form#login-form dl dt,
form#login-form dl dd {
    margin: 0;
    padding: 0;
}


form#login-form dl dt:first-child {
    margin-top: 0;
}

form#login-form dl dd input {
    width: 95%;
    margin-top: 5px;
}

form#login-form input[type="text"], form#login-form input[type="password"] {
    padding: 5px 2%;
    background: #fafafa;
    border: 1px solid #cccccc;
    border-radius: 3px;
    font-size: 16px;
    font-family: inherit;
}

form#login-form p.submit, form#logout-form p.submit {
    width: 80%;
    margin: 30px auto 0;
}

form#login-form input[type="submit"] {
    display: inline-block;
    line-height: normal;
    padding: 5px 15px;
    background: #5cb85c;
    border: 1px solid #4cae4c;
    border-radius: 3px;
    color: #ffffff;
    font-size: 16px;
    font-family: inherit;
}

form#login-form input[type="submit"]:hover {
    cursor: pointer; 
}
```

## ログイン処理作成

<p class="tmp list"><span>リスト</span>login-output.php（完成）</p>
```
<?php
unset($_SESSION['user']);
$pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');

$sql=$pdo->prepare('select * from user where user_name=? and password=?');

//パスワードハッシュ化
//$loginPass = hash("sha256", $_REQUEST['password']);

$loginPass =$_POST['password'];

$sql->execute([$_POST['user_name'], $loginPass]);

session_start();

//同じユーザ名でログインされてるか確認
if(isset($_SESSION['user'])){
    if($_SESSION['user']['user_name']==$_POST['user_name'] && $_SESSION['user']['password']==$_POST['password']){
        $_SESSION['flash']['success'] = '既に「'.$_POST['user_name'].'」さんでログインしています。';
        header('Location:index.php');
        exit();  
    }    
}

//セッションにユーザーID、ユーザ名、パスワードを登録
foreach ($sql->fetchAll() as $row) {
    $_SESSION['user']=[
        'id'=>$row['user_id'], 
        'user_name'=>$row['user_name'], 
        'password'=>$row['password']];
}

//ログイン成功時と失敗時の分岐処理
if (isset($_SESSION['user'])) {
    $_SESSION['flash']['success'] = 'ログインに成功しました。';
    session_regenerate_id();//ログイン後にセッションIDの再発行
    header('Location:index.php');
    exit();

} else {
    $_SESSION['flash']['error'] = 'ユーザ名またはパスワードが間違っています。';
    header('Location:login.php');
    exit();
}
?>
```




### ログイン成功後と失敗後にリダイレクト設定

ログインに成功した場合は商品一覧ページへリダイレクトし、ログインに失敗した場合はログイン画面にまた戻るようにしています。  
「 session_regenerate_id();」はセキュリティの為、ログイン後にセッションIDを再発行して変更するようにします。

```
if (isset($_SESSION['user'])) {
    $_SESSION['flash']['success'] = 'ログインに成功しました。';
    session_regenerate_id();//ログイン後にセッションIDの再発行
    header('Location:index.php');
    exit();
} else {
    $_SESSION['flash']['error'] = 'ユーザ名またはパスワードが間違っています。';
    header('Location:login.php');
    exit();
}
```


### フラッシュメッセージを設定

ログイン画面にログイン失敗時のメッセージ表示設定を追加します。
<p class="tmp list"><span>リスト</span>login.php</p>
```
・・・
<?php
//セッションの開始
session_start();

//フラッシュメッセージ
if( isset($_SESSION['flash']['error']) ){
	$flash_error = $_SESSION['flash']['error'];
}

unset($_SESSION['flash']);

if (isset($flash_error)){
	echo '<p class="feedback">'.$flash_error.'</p>';
}
?>
・・・
```

<p class="tmp list"><span>リスト</span>login-output.php</p>
```
<?php
・・・

if (isset($_SESSION['user'])) {
    $_SESSION['flash']['success'] = 'ログインに成功しました。';
    header('Location:index.php');
    exit();
} else {
    $_SESSION['flash']['error'] = 'ユーザ名またはパスワードが間違っています。';
    header('Location:login.php');
}
?>
```

これでユーザ名やパスワードを間違って入力してログインボタンを押すと、次のようにメッセージが表示されます。
![](upload/ユーザ名またはパスワードが間違っています.png){.photo-border}


ログインが成功して、商品一覧ページが表示されたときのメッセージ設定を追加しています。

<p class="tmp list"><span>リスト</span>index.php</p>
```
<?php
// セッションの開始
session_start();

//フラッシュメッセージ
if( isset($_SESSION['flash']) ){
	$flash_success = $_SESSION['flash']['success'];
  }

unset($_SESSION['flash']);

if (isset($flash_success)){
	foreach ((array)$flash_success as $message){
		echo '<p class="feedback">'.$message.'</p>';
	}
}
?>

<?php
//ログインしているか確認
if (!isset($_SESSION['user'])) {
	//ログイン画面に移動
	header('Location:login.php');
	exit();
}
?>
・・・
```
ログインに成功して商品一覧ページにリダイレクトされたときには、次のようにメッセージがが表示されます。
![](upload/ログインに成功しました.png){.photo-border}


## ログアウト用のフォームを作成

ログアウト用のフォームと処理をそれぞれ作成します。

<p class="tmp list"><span>リスト</span>logout-input.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <p>ログアウトしますか？</p>
        <a href="logout-output.php">ログアウト</a>
    </div>
</body>
</html>
```

<p class="tmp list"><span>リスト</span>logout-output.php</p>
```
<?php session_start(); ?>

<?php
echo isset($_SESSION['user']);
if (isset($_SESSION['user'])) {
	unset($_SESSION['user']);
	echo 'ログアウトしました。';
	header('Location:index.php');
} else {
	echo 'すでにログアウトしています。';
	header('Location:index.php');
}
?>
```

<http://localhost:7001/php/shop1/logout-input.php>

![](upload/ログアウトしますか.png){.photo-border}



## ログインしたとき

ログインした時には商品一覧管理ページを表示できるようにして、URLは「～/admin」にします。  
通常の商品一覧ページは、～/index.phpにします。


