*[page-title]:Nuxt3入門チュートリアル

参考サイト
: [Nuxt3入門チュートリアル(1)](https://qiita.com/Eustace/items/95c2ccc86e8824cb3d6d)

## Nuxt3実行環境の準備
StackBlitzを使用してブラウザ上で試すことができます。
xiaoluobodingさんがGithub上で公開されているnuxt3-starterリポジトリを使うと便利です。

リポジトリ
: https://github.com/xiaoluoboding/nuxt3-starter.git

A Better Nuxt 3 Starter
: https://stackblitz.com/github/xiaoluoboding/nuxt3-starter

※Chrome、FireFoxでは、プレビューが開けなかった。Edgeで、他のタブは閉じて、アクセスしたらプレビューが表示できました。