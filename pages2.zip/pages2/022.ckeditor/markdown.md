*[page-title]:CKEditor

