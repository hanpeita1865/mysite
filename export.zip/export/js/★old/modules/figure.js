export function figure_comp() {

    //画像にfigureとfigcaptionを設置
    $('#text-markdown img').each(function (e) {
        if (!$(this).hasClass('figure-none')) {
            figureWrap($(this));
        }
    });

    //画像にfigureとfigcaptionを設置
    function figureWrap(e) {
        let clsName = e.closest('div').prop('class');

        if (/^photo/.test(clsName) && e.closest('a').length == 0) {
            if (e.parent()[0].tagName == 'P') {
                e.unwrap();
            }
            e.wrap('<figure>');

            e.attr('')

            if (e.is('[title]')) { //title属性がある場合
                let imgTitle = e.attr('title');
                e.after('<figcaption>' + imgTitle + '</figcaption>');
            }

        } else if (/^photo/.test(clsName) && e.closest('a').length > 0) {
            if (e.parents('a').parent()[0].tagName == 'P') {
                e.parents('a').unwrap();
            }
            e.parent('a').wrap('<figure>');

            if (e.is('[title]')) { //title属性がある場合
                let imgTitle = e.attr('title');
                e.parent('a').after('<figcaption>' + imgTitle + '</figcaption>');
            }

        } else if (e.closest('a').length == 0) {
            if (e.parent()[0].tagName == 'P') {
                e.unwrap();
            }
            e.wrap('<figure>');

            if (e.is('[title]')) { //title属性がある場合
                let imgTitle = e.attr('title');
                e.after('<figcaption>' + imgTitle + '</figcaption>');
            }

        } else if (e.closest('a').length > 0) {
            if (e.parents('a').parent()[0].tagName == 'P') {
                e.parents('a').unwrap();
            }
            //e.wrap('<figure>');
            $(e.closest('a')).wrap('<figure>');

            if (e.is('[title]')) { //title属性がある場合
                let imgTitle = e.attr('title');
                //e.after('<figcaption>' + imgTitle + '</figcaption>');
                $(e.closest('a')).after('<figcaption>' + imgTitle + '</figcaption>');
            }
        }
    }
}
