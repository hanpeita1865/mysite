<?php

require_once("vendor/autoload.php");

$loader = new \Twig\Loader\FilesystemLoader("templates");

$twig = new \Twig\Environment($loader);

$assign["items"] = [
    'tokyo' => '東京',
    'shibuya' => '渋谷',
    'harajuku' => '原宿',
    'yoyogi' => '代々木',
];

/*
$assign["users"] = [
    'username' => '田中',
    'username' => '鈴木',
    'username' => '山田',
    'username' => '吉田',
];
*/

echo $twig->render("for.twig", $assign);



//echo $twig->render('for.twig', ['the' => 'variables', 'go' => 'here']);


