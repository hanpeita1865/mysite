*[page-title]:問題（JS）

<span class="bold green fz-12">問題１</span>　クラスについてです。空欄に当てはまるコードを記入してください。
![](upload/myName2.png)

<div markdown="1" class="problem">
<div markdown="1">
<label for="1-1">①</label>
<input id="1-1" type="text" name="1-1" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="1-2" for="1-2">②</label>
<input id="1-2" type="text" name="1-2" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="1-3" for="1-3">③</label>
<input id="1-3" type="text" name="1-3" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="1-4" for="1-4">④</label>
<input id="1-4" type="text" name="1-4" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="1-5" for="1-5">⑤</label>
<input id="1-5" type="text" name="1-5" value="" autocomplete="off"></input>
</div>
</div>

<details><summary>解答</summary>
	① class　② construct(name, age)　③ set myName(value)　④ get myName()　⑤ new User
</details>


<span class="bold green fz-12">問題2</span>　クラス継承についてです。①と②と④は問題1と同じになります。③には、UserクラスからManクラスに継承されるコードを記入してください。
![](upload/extendsMan2.png)
<div markdown="1" class="problem">
<div markdown="1">
<label for="2-1">①</label>
<input id="2-1" type="text" name="2-1" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="2-2" for="2-2">②</label>
<input id="2-2" type="text" name="2-2" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="2-3" for="2-3">③</label>
<input id="2-3" type="text" name="2-3" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="2-4" for="2-4">④</label>
<input id="2-4" type="text" name="2-4" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="2-5" for="2-5">⑤</label>
<input id="2-5" type="text" name="2-5" value="" autocomplete="off"></input>
</div>
</div>

<details><summary>解答</summary>
	① class　② construct(name, age)　③ class Man extends User　④ new Man　⑤ taro.speak()
</details>