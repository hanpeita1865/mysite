*[page-title]:プロパティ·イベント·アクション


## クリックして値を変更する

Livewireでは、publicプロパティの値を外部から操作できます。  

テンプレートにボタンを設置し、onclickの代わりにwire:click="メソッド名"を使うことで、ボタンクリック時にLivewireコンポーネント内のメソッドを呼び出せます。  
JavaScriptを使わず、PHP側で処理を行えるのが特徴です。
<p class="tmp"><span>書式</span></p>
```html
wire:click = "メソッド名”
```

### クリックで表示を更新

HelloComponentクラスにupdateMessageメソッドを追加し、messageプロパティの値を変更するようにします。  
テンプレート側では、ボタンにwire:click="updateMessage"を指定することで、クリック時にそのメソッドが実行され、表示内容が更新されます。

<p class="tmp list"><span>リスト4-11</span>app/Livewire/HelloComponent.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class HelloComponent extends Component
{
  public $message = 'Hello, Livewire!';
 
  // ユーザー操作に応じたメソッド
  public function updateMessage()
  {
    $this->message = 'こんにちは、Livewire!';
  }
 
  // コンポーネントのレンダリング処理
  public function render()
  {
    return view('livewire.hello-component');
  }
}
```

<p class="tmp list"><span>リスト4-12</span>views/vewire/hello-component.blade.php</p>
```
<div>
  This is Livewire component!!
  <ul><li>{{ $message }}</li></ul>
  <button wire:click="updateMessage">Click</button>
</div>
```

<div markdown="1" class="d-flex">
![](upload/Livewireクリック.png){.photo-border}
![](upload/クリックすると、メッセージが表示.png){.photo-border}
</div>

`<button wire:click="updateMessage">Click</button>`のように記述するだけで、クリック時にupdateMessageメソッドが実行され、表示が「こんにちは、Livewire!」に変わります。シンプルにクリック操作で値を変更できます。


## Livewireの動作原理

LivewireはJavaScriptを使わず、PHPとBladeだけで動的なUIを実現します。クリックなどの操作があると自動でAJAX通信が行われ、サーバーで状態が更新されてHTMLの差分が返され、ブラウザ側で部分的に表示が更新されます。この仕組みにより、以下のメリットがあります。

<div markdown="1" class="green bold">
* 高速なレスポンス（部分更新で再読み込み不要）
* シンプルな実装（JavaScript不要）
* サーバー側ロジックとの統合が容易（保守性・セキュリティ向上）
</div>

### 双方向データバインディング

Livewireには「<span class="bold red">双方向データバインディング</span>」が実装されており、フロントエンドの表示とバックエンドの値が常に自動で同期されます。

これにより、フォーム入力などの変更が即座にコンポーネントのプロパティに反映され、リアルタイムなUI操作が可能になります。

<div markdown="1" class="flex-center">
![](upload/双方向データバインディング.png "図　双方向データバインディングでは、画面に表示されたコンポーネントとコンポーネントクラスのプロパティが常に同期する")
</div>

## フォームを利用する

Livewireでは、フォームでのユーザー入力を扱う際、フォーム自体には

* wire:submit 属性を使い、送信時に指定されたメソッドを実行します。これによりフォーム送信時の通常のページリロードは発生せず、処理だけが実行されます。

また、入力要素（`<input>、<select>、<textarea>`など）には

* wire:model 属性を付けることで、入力された値をLivewireのプロパティに双方向でバインドし、互いに自動更新されるようにできます。

<div markdown="1" class="line-box">
もう一つの説明文

Livewireでフォームを利用するには、`<form>`と`<input>`に属性を追加します。  
フォーム送信時には、wire:submit属性で指定したメソッドが実行され、通常のフォーム送信は行われません。また、`<input>`にはwire:model属性を使って、入力値をプロパティにバインドします。このバインディングは双方向で、どちらかを変更するともう一方も自動的に更新されます。
</div>


### フォームを利用する

Livewireでは、フォームにwire:submit、入力欄にwire:modelを使うことで、簡単にユーザー入力を処理できます。

例として、`<form wire:submit="updateMessage">` と `<input wire:model="message">` を使うと、messageプロパティに入力がバインドされ、ボタンを押すと updateMessage() メソッドが実行されます。このメソッド内で $count++が行われ、ページ上のカウント表示も即時に更新されます。

特に、<span class="red">wire:model </span>により message の値は自動で同期され、明示的な処理なしにフロントとバックエンドの値が一致する「<span class="bold green">双方向バインディング</span>」が実現します。

<p class="tmp list"><span>リスト4-13</span>app/Livewire/HelloComponent.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class HelloComponent extends Component
{
  // 双方向バインディングされる公開プロパティ
  public $message = 'Hello, Livewire!';
  public $count = 0;
 
  // フォーム送信時メソッド
  public function updateMessage()
  {
    $this->count++;
  }
 
  // コンポーネントのレンダリング処理
  public function render()
  {
    return view('livewire.hello-component');
  }
}
```

<p class="tmp list"><span>リスト4-14</span>views/vewire/hello-component.blade.php</p>
```
<div>
  This is Livewire component!!
  <ul>
    <li>{{ $message }}</li>
    <li>(count: {{ $count }})</li>
  </ul>
  <form wire:submit="updateMessage">
    <input type="text" wire:model="message">
    <button type="submit">Click</button>
  </form>
</div>
```
フィールドにテキストを書いてボタンを押すと、メッセージが更新し、カウンターが1増えます。
<div markdown="1" class="d-flex">
![](upload/書きかえてみる記入.png){.photo-border}
![](upload/書きかえてみる表示.png){.photo-border}
</div>

### wire:submitは必須ではない

Livewireでは、フォーム送信に`<form>`やwire:submitを使う必要は必ずしもありません。  

wire:clickでメソッドを直接ボタンに割り当てれば、`<form>`なしでも処理を実行できます。  
つまり、入力や表示更新のために`<form>`は必須ではなく、目的に応じて柔軟に使い分けが可能です。

<p class="tmp list"><span>リスト4-15</span>views/vewire/hello-component.blade.php</p>
```
<div>
  This is Livewire component!!
  <ul>
    <li>{{ $message }}</li>
    <li>(count: {{ $count }})</li>
  </ul>
  <input type="text" wire:model="message">
  <button wire:click="updateMessage">Click</button>
</div>
```

## ライフサイクルとイベントフック

Livewireのコンポーネントには「イベントフック」という仕組みがあり、コンポーネントのライフサイクルに応じて自動的に処理を実行できます。
主なフックは以下の通りです。

* <span class="red">mount()</span>：コンポーネントの初期化時に実行。初期値の設定などに使う。
* <span class="red">updating() / updated()</span>：プロパティの変更前後に実行。バリデーションやログ記録などに利用できる。

また、JavaScriptのイベントにも対応しており、柔軟な処理の追加が可能です。これらを使うことで、更新や初期化を自動化し、効率的なコンポーネント開発ができます。
<div markdown="1" class="flex-center">
![](upload/コンポーネント生成、更新、削除.png)
</div>

## updatingによるプロパティの更新チェック

Livewireのupdatingフックを使うことで、プロパティが更新される直前に処理を実行できます。

サンプルでは、2つの`<input>`にそれぞれwire:model="name"とwire:model="pass"を指定し、$nameや$passの更新に応じて、更新されたプロパティ名を$checkに記録する仕組みを実装しています。

<p class="tmp list"><span>リスト4-16</span>views/vewire/hello-component.blade.php</p>
```
<div>
  This is Livewire component!!
  <ul>
    <li>name:"{{ $name }}", pass:"{{ $pass }}"</li>
    <li>[update: {{ $check}}]</li>
  </ul>
  <form wire:submit="updateMessage">
    <div><input type="text" wire:model="name"></div>
    <div><input type="password" wire:model="pass"></div>
    <div><button type="submit">Click</button></div>
  </form>
</div>
```


### コンポーネントクラスのイベントフック処理

HelloComponent.phpでは、updating($propertyName)メソッドを使って、更新されたプロパティ名を取得し、$checkプロパティに保存しています。  
これにより、入力フィールドを変更してフォームを送信すると、内容とともに「update:〇〇」と更新プロパティ名が画面に表示されます。

<p class="tmp list"><span>リスト4-17</span>app/Livewire/HelloComponent.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class HelloComponent extends Component
{
  public $name = '';
  public $pass = '';
  public $check = '';

  // マウント時の処理
  public function mount()
  {
    $this->name = 'no name';
    $this->check ='no check.';
  }

  // プロパティ更新時の処理
  public function updating($propertyName)
  {
    $this->check = $propertyName;
  }

  // フォーム送信時の処理
  public function updateMessage()
  {
    // not used.
  }

  // レンダリング処理
  public function render()
  {
    return view('livewire.hello-component');
  }
}
```
<div markdown="1" class="d-flex">
![](upload/livewireフック記入.png){.photo-border}
![](upload/フック田中パスワード表示.png){.photo-border}
</div>

2つの入力フィールドのどちらかを変更して送信すると、その内容と一緒に「update:〇〇」と、更新されたプロパティ名が表示されます。  
<span class="bold blue">updating($propertyName)</span>メソッドで更新されたプロパティ名を取得し、$checkプロパティに保存して画面に表示しています。

## 更新プロパティの値

Livewireでは、プロパティが更新される際に新しい値を取得するには、updatingプロパティ名($value)というメソッドを使います。  
例えば$nameならupdatingName($value)を定義すると、更新時に新しい値が引数で渡され処理できます。

### 各プロパティの更新時に値を取り出す

テンプレートhello-component.blade.phpを修正し、プロパティ$message, $name, $pass, $checkの4つを使用します。  
特に$messageには、更新されたプロパティ名とその値を表示するようにします。

<p class="tmp list"><span>リスト4-18</span>hello-component.blade.php</p>
```
<div>
  {{ $message }}
  <ul>
    <li>name:"{{ $name }}", pass:"{{ $pass }}"</li>
    <li>[update: {{ $check}}]</li>
  </ul>
  <form wire:submit="updateMessage">
    <div>
      <input type="text" wire:model="name">
    </div>
    <div>
      <input type="password" wire:model="pass">
    </div>
    <div>
      <button type="submit">Click</button>
    </div>
  </form>
</div>
```

### コンポーネントクラスの修正

では、コンポーネントクラスを作成しましょう。HelloComponent.phpの内容を以下に修正してください。

<p class="tmp list"><span>リスト4-19</span>HelloComponent.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class HelloComponent extends Component
{
  public $message = '';
  public $name = '';
  public $pass = '';
  public $check = '';

  // マウント時の処理
  public function mount()
  {
    $this->message = 'Event hook.';
    $this->name = 'no name';
    $this->check ='no check.';
  }

  // プロパティ更新時の処理
  public function updating($propertyName)
  {
    $this->check = $propertyName;
  }

  // name更新時の処理
  public function updatingName($propertyValue)
  {
    $this->message = 'update: ' . $this->check 
        . '="' . $propertyValue . '"';
  }

  // pass更新時の処理
  public function updatingPass($propertyValue)
  {
    $this->message = 'update: ' . $this->check 
        . '="' . $propertyValue. '"';
  }

  // フォーム送信時の処理
  public function updateMessage()
  {
    // not used.
  }

  // レンダリング処理
  public function render()
  {
    return view('livewire.hello-component');
  }
}
```

![](upload/フィールドの値を木村で送信.png){.photo-border}

フィールドの値を変更して送信すると、更新されたプロパティ名と新しい値が$messageに表示されます。  
$nameと$passの更新用にupdatingとupdating○○メソッドを使い、変更されたプロパティ名を$check、新しい値を$propertyValueから取得して、メッセージにまとめています。  
これにより、プロパティの変更を柔軟に処理できます。


## コンポーネントのネストと親子間通信

複雑なアプリでは、機能ごとにLivewireコンポーネントを分割し再利用します。その際、他のコンポーネントを埋め込む方法やデータの受け渡しが重要です。データは@livewireディレクティブの第2引数で渡すことができ、以下のように記述します：

<p class="tmp"><span>書式</span></p>
```
@livewire(コンポーネント名, [渡す値])
```

### Notificationコンポーネントを作る

では、実際に複数コンポーネントの利用を行ってみましょう。例として、「Notification」というコンポーネントを作成します。これはタイトルと本文を受け取り、それを通知として表示するものです。  
では、ターミナルから以下のようにコマンドを実行してください。
<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:livewire Notification
```
![](upload/livewire_Notification実行.png)

これで、Notificationコンポーネントが作成されました。ではコードを記述しましょう。まずはコンポーネントクラスからです。「app」内の「Livewire」フォルダー内に「Notification.php」というファイルが作成されています。これを開いてください。

<p class="lang">app/Livewire/Notification.php（デフォルト）</p>
```
<?php

namespace App\Livewire;

use Livewire\Component;

class Notification extends Component
{
    public function render()
    {
        return view('livewire.notification');
    }
}
```

以下のようにコードを記述します。
<p class="tmp list"><span>リスト4-20</span>app/Livewire/Notification.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class Notification extends Component
{
  // 通知タイトルと内容を受け取る公開プロパティ
  public $title;
  public $content;

  public function render()
  {
    return view('livewire.notification');
  }
}
```
ここでは$title と $content の public プロパティが用意されており、これをテンプレート側で表示します。  

次に、resources/views/livewire/notification.blade.php を開き、通知の内容を表示するテンプレートを記述します。

<p class="tmp list"><span>リスト4-21</span>resources/views/livewire/notification.blade.php </p>
```
<div style="border:solid 2px red; padding:0px 20px; margin:10px 0px; color:red;">
  <p style="font-size:18px;">{{ $title }}</p>
  <p style="font-size:12px;">{{ $content }}<p>
</div>
```
これでNotificationコンポーネントが作成できました。これを、HelloComponent内に追加して、必要な情報を渡してみましょう。

### 親コンポーネントから子コンポーネントへ値を渡す

では、作成した NotificationをHelloComponent内に組み込んでみましょう。テンプレートファイルのhello-component.blade.phpを開き、以下のように記述してください。

<p class="tmp list"><span>リスト4-22</span>views/livewire/hello-component.blade.php</p>
```
<div>
  {{ $message }}
  @livewire('notification', [
    'title' => $alert_title, 
    'content' => $alert_content])
</div>
```

@livewire ディレクティブで Notification コンポーネントを配置し、第2引数でtitleとcontentを渡すと、それぞれ$titleと$contentのpublic プロパティに自動的に設定されます。 

これを受けて、HelloComponent.php を修正します。

<p class="tmp list"><span>リスト4-23</span>HelloComponent.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class HelloComponent extends Component
{
  public $message = '';  

  // マウント時のイベント処理
  public function mount()
  {
    $this->message = "内部コンポーネントの利用";
  }

  // レンダリング処理
  public function render()
  {
    $alert = [
      'alert_title'=>'重要なお知らせ',
      'alert_content'=>'システムからの重要な通知です。'
    ];
    return view('livewire.hello-component', $alert);
  }
}
```
![](upload/Notification赤い枠表示.png){.photo-border}

/helloにアクセスしてみると、赤い枠の表示が現れます。この枠内が、Notificationの表示になります。

renderメソッドで用意したalert_titleとalert_contentは、テンプレート内の@livewireを通じてNotificationコンポーネントに渡され、publicプロパティに設定されます。  
このようにして、外部からLivewireコンポーネントにデータを渡すことができます。


## コンポーネント間のイベント通信

Livewireでは、dispatchメソッドと`#[On]属性`を使ってコンポーネント間でイベントの送受信が可能です。  
dispatch(イベント名, データ...)でイベントを送信し、`#[On(イベント名)]`を付けたメソッドで受信・処理します。  
`#[On]属性`を使うには、`use Livewire\Attributes\On;`の記述が必要です。

<p class="lang">イベントの送信</p>
```
《Component》->dispatch(イベント名,送信データ, …… );
```

<p class="lang">イベントの受信</p>
```
#[On( イベント名 )]
メソッド定義
```
```
use Livewire\Attributes\On;
```
<div markdown="1" class="flex-center">
![](upload/親コンポーネントから子コンポーネント.png "図　dispatchと#[On]で、親から子にイベントを送り、それを受け取る処理を作れる")
</div>

## 親から子にイベントを送る

親コンポーネント（HelloComponent）から子コンポーネントにイベントを送る例として、まずはテンプレート（hello-component.blade.php）を修正します。

<p class="tmp list"><span>リスト4-24</span>hello-component.blade.php</p>
```
<div>
  {{ $message }}
  @livewire('notification', [
    'title' => $alert_title, 
    'content' => $alert_content])
  <input type="text" wire:model="input" />
  <button wire:click="doAction">click</button>
</div>
```
ここでは、`<input>`と`<button>`を追加しました。`<input>`では、wire:modelに"input"プロパティを指定しておきました。  
また`<button>`では、wire:click にdoActionメソッドを指定してあります。

### 親コンポーネントにイベント送信処理を用意する

では、コンポーネントクラスを修正しましょう。HelloComponent.phpを開いて、以下のようにコードを記述してください。

<p class="tmp list"><span>リスト4-25</span>HelloComponent.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class HelloComponent extends Component
{
  public $message = ''; 
  public $input = '';

  // マウント時のイベント処理
  public function mount()
  {
    $this->message = "内部コンポーネントの利用";
  }

  // buttonクリックイベント処理
  public function doAction()
  {
    $this->triggerChildEvent($this->input);
  }

  // 子コンポーネントにイベントを送るメソッド
  public function triggerChildEvent($msg)
  {
    // 'childEvent'イベントを発生させ、メッセージを渡す
    $this->dispatch('child-event', $msg);
  }
  
  // レンダリング処理
  public function render()
  {
    $alert = [
      'alert_title'=>'重要なお知らせ',
      'alert_content'=>'システムからの重要な通知です。'
    ];
    return view('livewire.hello-component', $alert);
  }
}
```

doActionメソッド内で $this->dispatch('child-event', $msg); を実行し、'child-event' イベントを送信します。  
あとは子コンポーネント側にこのイベントを受信する処理を用意すれば完了です。

### 子コンポーネントでイベントを受け取る

子コンポーネントのテンプレートはそのままで、コンポーネントクラス（Notification.php）のみを修正します。

<p class="tmp list"><span>リスト4-26</span>Notification.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;
use Livewire\Attributes\On;

class Notification extends Component
{
  // 通知タイトルと内容を受け取る公開プロパティ
  public $title;
  public $content;

  // child-eventイベントを受け取るメソッド
  #[On('child-event')]
  public function handleChildEvent($msg)
  {
    $this->content = '親からの送信：' . $msg;
  }
    
  public function render()
  {
    return view('livewire.notification');
  }
}
```

<div markdown="1" class="d-flex">
![](upload/雨がやみましたー記入.png){.photo-border}
<span class="arrow-right mt-5"></span>
![](upload/雨がやみましたー送信表示.png){.photo-border}
</div>

/helloにアクセスし、メッセージを入力してボタンを押すと、Notificationの表示が更新されます。  
これは、HelloComponentからdispatch('child-event', $msg)でイベントが送信され、Notification側で`#[On('child-event')] public function handleChildEvent($msg)`により受信・処理されているためです。  
これにより、渡されたメッセージでコンテンツが更新されます。


### 子から親へは?

親から子だけでなく、子から親や無関係なコンポーネント間でも、dispatchでイベントを送信し、#[On]で受信メソッドを定義することで、簡単に相互通信が可能になります。これにより柔軟なコンポーネント間連携が実現できます。
