<?php
require_once("vendor/autoload.php");
$loader = new \Twig\Loader\FilesystemLoader("templates");
$twig = new \Twig\Environment($loader);

// $assign["pathBase"] = '/from_now_slim';

require 'admin/basepath.php';
$assign["pathBase"] = $basePath;

echo $twig->render("layouts/head.twig", $assign);
?>
<main>
<div class="container-fluid">
    <?php echo $twig->render("layouts/side_menu.twig", $assign); ?>
    <div id="body" class="">
        <div id="text-markdown" class="search-result">
            <!-- マークダウンのコードを変換して、ここに挿入 -->
            <?php 
            if(!empty($_REQUEST['word'])){
                require 'common/search/search_conv.php'; 
            }
            ?>

        </div>
        <!--パーツページ用のトップへ戻るボタンは、必要なければ削除する -->
        <p id="parts-pagetop">
            <a href="#top"><span class="sr-only">このページの先頭へ</span></a>
        </p>
    </div>
</div>
</main>
<?php
echo $twig->render("layouts/footer.twig", $assign);
?>