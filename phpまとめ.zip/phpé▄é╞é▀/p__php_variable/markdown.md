*[page-title]:変数について

変数を使うには、次のような規則があります。

1. 変数名の前には、<span class="red">ドル記号($)</span> を付ける 
2. 1文字目は英字またはアンダースコア(_)を使う （数字を先頭に使うことはできません。）
3. 2文字目以降は英字、数字、アンダースコアのいずれかを使う 
4. 英字の大文字と小文字は区別される

例えば、次のような変数名は有効です。
$price $price2 $price_tag
「<span class="blue">$123price</span>」は、規則2により1文字目に数字が使えないので、無効な変数名です。また、「<span class="blue">$price</span>」と「<span class="blue">$Price</span>」は、規則通により大文字と小文字が区別されるので、別の変数となります。  
変数名には英単語や複数の英単語の組み合わせを使うのがおすすめです。一方で「$i」や「$j」のように、英字1文字だけのごく簡単な変数名を使うこともあります。


## グローバル変数とローカル変数

変数のスコープについては注意しなければならない点があります。グローバル変数の扱いが一般的な言語とやや異なります。

*グローバル変数（大域変数）*とはファイル全体で有効な変数のことです。その対義語として*ローカル変数（局所変数）*があります。  
ローカル変数の例としてわかりやすいのは関数内の変数です。関数内で使用している変数はその外の変数とは区別され、関数外では同じ名前であっても別の変数になります。

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	<iframe src="https://paiza.io/projects/e/ox5cQCQn6fSIAYv0SR39oQ?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>
</div>


この例ではechoときの$numには何も値が入っておらず未定義の変数であるというエラーとなってしまいます。


これに対し関数外で使用される変数がグローバル変数です。

## グローバル変数を関数内で使用した場合
では、グローバル変数を関数内で使用した場合どうなるでしょうか？  
以下の例のようにまず変数に値を入れ、関数内で変更してみます。

<div class="exp">
	<p class="tmp"><span>例2</span></p>
	<iframe src="https://paiza.io/projects/e/l25uHWHlxJaI8b5LeRYGyQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


しかし、この場合、$numは5と表示されてしまいます。func内で$numに10を入れているように見えますが、この$numは関数内で使用されるローカル変数の$numとみなされてしまいます。

つまり、同じ名前であっても関数内の変数は別の変数として扱われます。



## グローバル変数を関数内で利用する
ではグローバル変数を関数内で利用するにはどうしたらよいでしょうか？  
それには関数内で使用するグローバル変数をあらかじめ宣言しておく必要があります。

それには <span class="red">global </span>という命令を使います。


<div class="exp">
	<p class="tmp"><span>例3</span></p>
	<iframe src="https://paiza.io/projects/e/xIxPJHIITekwRMDObhS3Yg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


このようにglobalで$numを宣言しておくと、この変数はローカル変数では無くグローバル変数の$numである、ということになります。  
この結果、以下のように実行すると、変数$numは10と表示されます。

グローバル変数はPHPではデフォルトでは関数外でのみ使用される変数となっており、関数内で使うためにはグローバルで使う変数を宣言しなくてはなりません。これは忘れやすいのでよく覚えておくとよいでしょう。


## 参考サイト

* [PHPの変数と代入、リテラルとエスケープシーケンス](https://atmarkit.itmedia.co.jp/ait/articles/1403/20/news105_2.html)












