import { DialogPlugin } from '../DialogPlugin';

declare const math: DialogPlugin;

export default math;