*[page-title]:SQLメモ

## MySQLのデータベースに接続

<p class="tmp"><span>書式</span>PDOで接続</p>
```
$pdo=new PDO('mysql:host=localhost;dbname=データベース名;charset=utf8', 'ユーザー名', 'パスワード');
```

ユーザー名、パスワードをデータベースに設定してない場合は、ユーザー名を「<span class="red bold">root</span>」にしてパスワードは<span class="blue bold">空</span>にします。
```
$pdo=new PDO('mysql:host=localhost;dbname=データベース名;charset=utf8', 'root', '');
```