<h3>フォルダ内にある直下のフォルダ名だけを表示</h3>
<ul>
<?php
	$folder = glob('pages/*', GLOB_ONLYDIR);

    function AscSort($item1,$item2)
    {
        if ($item1['num'] == $item2['num']) return 0;
        return ($item1['num'] > $item2['num']) ? 1 : -1;
    }

    foreach ($folder as $dir) {
        $md = file_get_contents($dir.'/markdown.md'); //マークダウンの内容を変数に格納
        preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
        preg_match("/\*\[list-num\]:\s*(.+)/", $md, $ArrayNum);

        $ArrayMenu[] = array(
            "num" => $ArrayNum[1],
            "title" => $ArrayTitle[1],
            "href" => $dir
        );
    }

    usort($ArrayMenu,'AscSort');
    //print_r($ArrayMenu);

    $num = 1;

	foreach ($ArrayMenu as $item) {

        echo '<li id="'.$num.'" draggable="true">';
        echo '<a href="'.$item["href"].'/">'.$item['title'].'</a>';
        echo '</li>';

        $num++;
	}
?>
</ul>


<h3>指定したディレクトリ配下のファイル名をすべて表示</h3>
<?php
	function globAll($folder) {
		// 指定されたディレクトリ内の一覧を取得
		$files = glob($folder.'/*');

		// フォルダ内ループ
		foreach ($files as $file) {
			// ファイルかどうか判定
			if (is_file($file)) {
				// mdファイルだけ出力
                if(preg_match('/.md$/',$file)){
                    echo $file . "<br />";
                }

			} else {//フォルダの場合、再度glob関数で中身を取得
				globAll($file);
			}
		}
	}

	// 最初にディレクトリを指定する
	globAll('pages');
?>

