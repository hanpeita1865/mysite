*[page-title]:画像のアップロードと挿入

## 画像アップロードについて

### 1. 画像アップロード用欄から仮アップロード

画像を挿入するには、画像アップロード用欄の<kbd class="border border-secondary">ファイルを選択</kbd>ボタンから画像ファイルを選択した後、右上の<kbd class="border border-secondary">先にアップロード</kbd>ボタンを押し、「仮アップロード」をする必要があります。  

こちらのボタンは、「画像アップロード用」欄と「添付ファイル」欄で選択している画像やPDFなどのファイルがまとめて「仮のアップロード」されます。

📝「仮アップロード」とは、tempfilesフォルダに一旦格納されますが、確認画面の確定をせず、編集を中止すると削除されます。  
また、「先にアップロード」をせずにファイルを選択だけして確認画面の確定を実行すると、アップロードされ、次に編集画面を開いた時、登録された画像として欄に表示されます。  
<span class="red">（注意）本文内に挿入するには、先にアップロードしておく必要があります。</span>

<div markdown="1" class="d-flex justify-content-around align-items-center">
![](upload/画像アップロード用.png "図　ファイルを選択")
<p class="d-flex flex-column align-items-center"><kbd class="border border-secondary">先にアップロード</kbd>ボタンを押す<span class="fz-16">➡</span></p>
![](upload/画像アップロード用先にアップロード.png "図　仮のアップロード完了")
</div>

📝変更したい場合は、再度<kbd class="border border-secondary">ファイルを選択</kbd>ボタンから画像ファイルを選択し、<kbd class="border border-secondary">先にアップロード</kbd>ボタンを押せば画像が切り替わります。


### 2. 添付ファイルの欄から仮アップロード 

添付ファイルの欄からも上と同じように<kbd class="border border-secondary">ファイルを選択</kbd>ボタンからボックスの右上にある<kbd class="border border-secondary">先にアップロード</kbd>ボタンを押すと「仮アップロード」が実行されます。
<div markdown="1" class="d-flex justify-content-around align-items-center">
![](upload/添付ファイル画像選択.png "図　ファイルを選択")
<p class="d-flex flex-column align-items-center">右上の<kbd class="border border-secondary">先にアップロード</kbd>ボタンを押す<span class="fz-16">➡</span></p>
![](upload/添付ファイル画像選択先にアップロード.png "図　仮のアップロード完了（「ファイルを選択」と「リセット」が非表示になります）")
</div>


<div markdown="1" class="note-box">ただし、「1. 画像アップロード用欄」と違う点は、一度アップロードした場合、「2. 添付ファイルの欄」の<span class="red bold">アップしたファイルは変更ができない</span>ことです。  
添付用で変更する場合は、新たにアップロードします。そうすると自動的に下図のようにファイル名の末尾に文字が追加されます。  
その後、元あった画像の削除にチェックを入れておけば、確認画面から確定ボタンを押したときに削除されます。  
本文にある挿入したコードは自動では消えないので、そこは手動で削除してください。</div>
![](upload/添付ファイル画像同じ画像アップロード.png)

※ 画面右下の<kbd class="border border-secondary">中止（一覧に戻る）</kbd>を押すと、一覧画面に戻りますが、その時「仮アップロード」した画像は削除されます。


## 画像挿入について

本文内にアップロードした画像を配置するには、まず本文内に挿入したい位置にカーソルを持っていった後、<kbd class="border border-secondary">本文内に挿入</kbd>ボタンを押します。

<div markdown="1" class="d-flex justify-content-start align-items-center">
![](upload/本文内にカーソル1.png "図　挿入する位置にカーソルを持っていく")
<p class="d-flex flex-column align-items-center"><span class="fz-16 mx-3">➡</span></p>
![](upload/本文内に挿入.png "図　「本文内に挿入」ボタンを押す")
</div>

そうすると、原寸大で画像が本文内に挿入されます。  
（コンテンツより大きい幅の画像の場合は、コンテンツ幅いっぱいで表示されます）
<div markdown="1" class="flex-center">
![](upload/画像を本文内に挿入1.png "図　本文内に画像挿入")
</div>

## 画像のサイズ変更について

画像を挿入した後、赤丸で示した青の四角の所にカーソルを持っていき、ドラッグするとサイズ変更ができます。  
（原寸大より大きくすると画像がぼやけるので、サイズ変更は縮小したいときに使用します。）
<div markdown="1" class="figure-my-0">
![](upload/画像サイズ変更.png "図　角の青の四角をドラッグしてサイズ変更")
</div>
<p class="d-flex flex-column align-items-center"><span class="fz-16 rotate90">➡</span></p>
<div markdown="1" class="figure-mt-0">
![](upload/画像サイズ変更縮小.png)
</div>

また、下の右端のボタンをクリックすると、パーセントでの縮小も可能です。

<div markdown="1" class="d-flex justify-content-start align-items-center">
![](upload/画像サイズ変更パーセント縮小.png)
<p class="d-flex flex-column align-items-center"><span class="fz-16 mx-3">➡</span></p>
![](upload/画像サイズ変更パーセント表示.png)
</div>

<span class="notes">📝画像の縮小を設定した場合、下記のようにスマホ時（575px以下）の表示では、設定したサイズは解除され画面横幅いっぱいの表示か原寸大の表示になります。</span>

<div markdown="1" class="photo-center">
![](upload/画像サイズ変更スマホ時.png "図　スマホ時の画像表示")
</div>
