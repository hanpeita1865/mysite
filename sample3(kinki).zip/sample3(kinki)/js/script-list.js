const news_wrap = document.getElementById('news');
const title_link = document.querySelectorAll('.news-box a.title-link');
const news_tag = document.querySelectorAll('.news-box .cate-tag');
const tab_btn = document.querySelectorAll('.tab-box li button.nav-link');
const news_list = document.querySelectorAll('.news-box li');
const url_host = location.host;//ドメイン
//const host = 'kinki-3.ndd-sv.net';//本番用
const host = '10.203.1.68:55507';//ローカル
//const host = 'www.city.kishiwada.osaka.jp';//テスト
const hostRegexp = new RegExp(host);

//リンクパス修正
title_link.forEach(function (elm) {
    let href = elm.getAttribute('href');
    let host_match = hostRegexp.test(href);//当サイトのホストと一致するか判定

    //hrefが空のaはリンクを取る
    if (href == '') {
        let inner = elm.innerHTML;
        elm.replaceWith(inner);
    }

    //外部リンクには、「target="_blank"」を付け、ページ遷移リンクには、iframe親要素に表示させる「target="_parent"」を使用。
    if (/^http|^https/.test(href) && host_match==false) {
        //外部リンク
        elm.setAttribute('target', '_blank');
    } else if(document.querySelector('.tab-box')!=null && /.html$/.test(href)) {
        //トップ用　お知らせ サイト内ページ
        elm.setAttribute('target', '_parent');
    } else if(document.querySelector('.frame-box1')!=null && /.html$/.test(href)){
        //トップページ用　重要なお知らせ　サイト内ページ
        elm.setAttribute('target', '_parent');
    }
})

tab_btn.forEach(x => {
    x.addEventListener('click', tabClick);
    x.addEventListener('keydown', focusTranslate);
});

//表示するタブを切り替える
function tabClick(e) {
    //タブアクティブ化をはずす
    tab_btn.forEach(function (s) {
        s.closest('button').classList.remove('active');
        s.closest('button').setAttribute('aria-selected', false);
    })

    //タブアクティブ化
    e.target.closest('button').classList.add('active');
    e.target.closest('button').setAttribute('aria-selected', true);
    
    const aria_controls = e.target.closest('button').getAttribute('aria-controls');
    const tab_id = e.target.closest('button').getAttribute('id');

    document.querySelector('.news-box').setAttribute('aria-labelledby',tab_id);
    document.querySelector('.news-box').setAttribute('id', aria_controls);

    //記事の表示切り替え
    news_tag.forEach(function (t) {
        if(e.target.textContent=='すべて'){
            t.closest('.news-box li').classList.remove('d-none');
        }else if(t.getAttribute('data-category') != e.target.textContent) {
            t.closest('.news-box li').classList.add('d-none');
        }else{
            t.closest('.news-box li').classList.remove('d-none');
        }

    })

    //記事のtabIndexを設定
    console.log('記事tabIndex')
    
    tab_btn.forEach((x, index) => {
        //タブボタンにtabIndexを設定
        x.tabIndex = (index + 1);

        //記事リンクにtabIndexを設定
        if(x.textContent == 'すべて'){
            document.querySelectorAll('.news-box li a').forEach(s => {
               s.tabIndex = 1;  
            });
            
        }else{
            document.querySelectorAll('.news-box li a').forEach(s => {
                s.tabIndex = e.target.dataset.id;
            });
        }
    });


    //お知らせ　高さ調整
    const frame_box = document.querySelector('.sugu-window');		
    let frameHeight = frame_box.clientHeight;		
    let frameData3 = {
        height3: frameHeight	
    }

    // window.parent.postMessage(frameData3, "http://10.203.1.68:55508/");//トップページへ（ローカル用）
    //window.parent.postMessage(frameData3, "https://kinki-3-static.ndd-sv.net/");//トップページへ（本サイト用）
}

//矢印キーでTabを移動する
function focusTranslate(e) {
    if(e.key === 'ArrowLeft') {//左矢印
        const new_id = '[data-id="' + nextShow(-1) + '"]';

        console.log(nextShow(-1), document.querySelector(new_id), new_id);
        document.querySelector(new_id).focus();

    } else if(e.key === 'ArrowRight') {//右矢印
        const new_id = '[data-id="' + nextShow(1) + '"]';
        console.log(nextShow(1), document.querySelector(new_id), new_id);
        document.querySelector(new_id).focus();
    }

    console.log(e.key, e.code);

    //data-idの値を変更するための文字列操作
    function nextShow(dir) {
        const data_id = e.currentTarget.dataset.id;//タブを切り替えるボタンのdata-idを取得

        const tab_len = tab_btn.length;

        if(dir === 1) {//右矢印
            new_num = Number(data_id) % tab_len + 1;

        } else {//左矢印（-1）
            new_num = Number(data_id) - 1;

            if(new_num === 0) {
                new_num = tab_len;
            }
        }

        return new_num;
    }
}


//フォーカスの順番を制御
news_wrap.addEventListener('focus', tabIndexAdd, true);
news_wrap.addEventListener('blur', tabIndexRemove, true);




//tabIndexを設定する
function tabIndexAdd(e) { 

    const tab_len = document.querySelectorAll('button.nav-link').length;

    document.querySelectorAll('.news-box li a').forEach(s => {
        s.tabIndex = document.querySelector('.nav-link.active').dataset.id;
    });

    if(e.target.tagName=='A'){
        const tab_num = document.querySelector('.nav-link.active').dataset.id;

        tab_btn.forEach((x, index) => {
            //タブボタンにtabIndexを設定
            x.tabIndex = (index + 1);

            //記事リンクにtabIndexを設定
            if(x.textContent == 'すべて'){
                document.querySelectorAll('.news-box li a').forEach(s => {
                   s.tabIndex = 1;  
                });
                
            }else{
                document.querySelectorAll('.news-box li a').forEach(s => {
                    s.tabIndex = tab_num;
                });
            }
        });

        document.querySelector('.news-list-link a').tabIndex = tab_len;
    }
}

//tabIndexを削除する
function tabIndexRemove() {
    console.log('離れ')

    //タブの切り替えボタンのtabIndexを削除
    tab_btn.forEach(x => {
        x.removeAttribute('tabIndex');

        //タブパネルのリンクからtabIndexを削除
        document.querySelectorAll('.news-box li a').forEach(h => {
            h.removeAttribute('tabIndex');
        })
    });

    document.querySelector('.news-list-link a').removeAttribute('tabIndex');
}