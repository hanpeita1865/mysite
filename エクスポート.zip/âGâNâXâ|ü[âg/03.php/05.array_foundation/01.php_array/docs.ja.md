---
title: (移動済)配列（1次元の配列）
taxonomy:
    category:
        - docs
visible: true
---

* [配列の初期化と代入](#p1)
* [配列に要素を追加する方法](#p2)
* [配列の要素が空かどうか判定する](#p3)
* [配列を切り取る（array_slice）](#p4)
* [PHPからJSに配列を引き渡す方法](p5)

PHP においては「添字配列（キーが非負整数である配列）」と「連想配列（キーが文字列である配列）」の間に違いはなく、配列型は 1 つだけで、 同じ配列で整数のインデックスと文字列のインデックスを同時に使えます。


## 配列の初期化と代入 ##{#p1}

<p class="tmp"><span>書式</span>配列の初期化</p>
```
$array = array();
または
$array = [];
```


#### 添字配列の例
```
$array = array('りんご', 'もも', 'なし'); // キーは0から順に0,1,2が割り振られる
または
$array = ['りんご', 'もも', 'なし'];
```

#### 連想配列の例（キーを指定してセットする）
```
$array = array('apple'=>'りんご', 'peach'=>'もも', 'pear'=>'なし');
または
$array = ['apple'=>'りんご', 'peach'=>'もも', 'pear'=>'なし'];
```

#### 部分的にキーを指定することもできる
```
$array = array('バナナ', 'apple'=>'りんご', 'peach'=>'もも', 'pear'=>'なし', 'みかん');
または
$array = ['バナナ', 'apple'=>'りんご', 'peach'=>'もも', 'pear'=>'なし', 'みかん'];
```

この時、中身をprint_r($array);により確認すると
```
Array
(
    [0] => バナナ
    [apple] => りんご
    [peach] => もも
    [pear] => なし
    [1] => みかん
)
```
となっています。



## 配列に要素を追加する方法 ##{p2}

配列に要素を追加する３つの方法

### ① array_push()を使用して追加する方法

array_push()は配列の末尾に要素を追加する関数です。  

<p class="tmp"><span>書式1</span>array_push()</p>
```
array_push( 要素を追加する配列 , 追加したい要素1 [, 追加したい要素2 ] )
```
第３引数以降は省略可能です。第３引数以降にも値を渡すことで複数の要素を一度に追加することができます。

#### 添字配列の例
<iframe src="https://paiza.io/projects/e/AA4HFOBqUEuPXQjwni8k_Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>



### ② [] を使用して追加する方法

配列のキーを入れる「[]」ですが、キーを空のままにすることで自動的に要素が配列の末尾に追加されます。  

<p class="tmp"><span>書式2</span></p>
```
追加したい配列[] ＝ 要素
```

この場合はarray_push()と違って一度にひとつの要素しか一度に追加できませんが、非常に簡潔に記述することができます。

#### 添字配列での追加
<iframe src="https://paiza.io/projects/e/gZJsVux0-1xFfNXToBAAqQ?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>


#### キーを指定しての追加

<iframe src="https://paiza.io/projects/e/i5wE_yC7t1_bRKm9Mo4pOA?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>

### ③ array_merge()を使用して追加する方法

array_merge()は複数の配列（array）を連結する関数ですが、この関数でも配列に要素を追加することができます。

<p class="tmp"><span>書式3</span>array_merge()</p>
```
追加したい配列 = array_merge( 追加したい配列 [, 追加したい配列2... ] )
```

第２引数以降に配列を指定することで複数の配列を同時に連結することができます。  
また、array_merge()では連結後の配列を返し、元の配列は書き換えられないので注意してください。

<iframe src="https://paiza.io/projects/e/E6l63-2CKV91Xy-NtmXNZw?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>


## 配列の要素が空かどうか判定する ##{p3}

### empty()を使って配列の空判定

empty()は配列が空かを判定するものではなく、引数にセットした変数が空かどうかを判定します。  
空の場合には true を返してくれます。

<iframe src="https://paiza.io/projects/e/NlHnbZuWtiNtWOb3Tq5RWw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


**※ 配列の要素に空文字やNULLを設定した場合は、空では無い状態になります。**

<iframe src="https://paiza.io/projects/e/Neb-7x_BWEgJWwZGr9X_gQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## 配列を切り取る（array_slice）##{p4}

<p class="tmp"><span>書式4</span>array_slice()</p>
```
array_slice($array, $offset [,$length = NULL [,$preserve_keys = false]]);
```
※[]内は省略可能な引数

|<div style="width:5rem"> </div>|<div style="width:9rem"> </div>|	|
|:--:|:--:|:--|
|第一引数	|array(必須)	|処理を行う配列です。|
|第二引数	|offset(必須)	|切り取る配列の0から数えた開始位置です。0を選んだ場合、先頭から切り取ります。-2など負数の場合は、配列の最後から数えた位置になります。|
|第三引数	|length(任意)	|切り取る件数を指定します。初期値はNULLで、省略した場合、offsetで選んだ位置から末尾まですべての要素を返します。負数の場合は、配列の末尾から数えた位置まで取得します。(0から数えないので注意)|
|第四引数	|preserve_keys(任意)	|取得した配列のキーを0からの連番にするか、元のキーを参照するかを指定します。デフォルトはfalseで、元のキーは破棄され連番となります。|



#### 先頭から5件の配列を取得する

<iframe src="https://paiza.io/projects/e/X3-Q8PNvOw2JEvItHDiM7Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


#### 0から数えて4つ目の位置から、2件の配列を取得する

<iframe src="https://paiza.io/projects/e/vLRKnXVVw9K_Ft0pX7Ehfg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


#### 0から数えて3つ目の位置から、末尾までの配列を取得する

<iframe src="https://paiza.io/projects/e/5ty8TltMzJYnITBMTbuuvQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


#### 0から数えて5つ目の位置から、3件の配列を取得し、元のキーを維持する

<iframe src="https://paiza.io/projects/e/0OK4IBMX5PD8oEeJkCZrTA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## PHPからJSに配列を引き渡す方法 ##{p5}

phpの配列をjsの変数に渡したければjson_encode()を使います。

<iframe src="https://paiza.io/projects/e/l72sA_lIpzLdTKyEW81OGw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## 参考サイト 

* [【PHP】array_sliceの使い方。配列を範囲指定して切り取る関数](https://kinocolog.com/php_array_slice/)
* [PHPからJavaScriptへ配列を受け渡す方法を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/37729)









