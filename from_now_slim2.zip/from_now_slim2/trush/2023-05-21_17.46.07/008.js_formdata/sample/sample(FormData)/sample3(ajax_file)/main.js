$('button').on('click', function () {
	var fd = new FormData();
	fd.append('hoge', $('input[type=file]')[0].files[0]);

	$.ajax({
		url: 'ajax.php',
		type: 'POST',
		processData: false,
		contentType: false,
		cache: false,
		data: fd
	}).done(function (data) {
		//通信成功時の処理
		alert('成功しました～。')

	}).fail(function () {
		//通信失敗時の処理
		alert('失敗しました～。')
	});
});
