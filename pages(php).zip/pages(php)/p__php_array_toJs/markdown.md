*[page-title]:PHPからJSに配列を引き渡す方法

## PHPからJSに配列を引き渡す方法

phpの配列をjsの変数に渡したければjson_encode()を使います。
<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
<iframe src="https://paiza.io/projects/e/l72sA_lIpzLdTKyEW81OGw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

