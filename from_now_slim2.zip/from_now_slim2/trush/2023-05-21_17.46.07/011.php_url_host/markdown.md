*[page-title]:URL、ホスト名、ファイル名などの取得方法


## phpで現在のURLを取得する

現在のURL(自分のurl)を取得するにはスーパーグローバル変数にアクセスする必要があり、基本的には **$_SERVER** というスーパーグローバル変数にアクセスすることで値を取得することができます。

### 現在アクセスしているパス
$_SERVER の***'REQUEST_URI'***にアクセスすることで取得することができます。なお、この方法では、ホスト名は取得することができません。

<p class="tmp"><span>書式1</span>パスを取得</p>
```
$_SERVER['REQUEST_URI'];
```
新規タブをクリックすると、現在のパスが表示されます。

<a href="sample/url_host/path_test.php" target="blank">新規タブ1</a>

##### 新規タブ1 PHPコード
```
echo $_SERVER['REQUEST_URI'];//「/grav/trunk/grav-admin/sample/php/url_host/path_test.php」
```

### 現在アクセスしているホスト名
$_SERVER の***'HTTP_HOST'***にアクセスすることで取得することができます。

<p class="tmp"><span>書式2</span>ホスト名を取得</p>
```
$_SERVER['HTTP_HOST'];
```
<a href="sample/url_host/host_test.php" target="blank">新規タブ2</a>

##### 新規タブ2 PHPコード
```
echo $_SERVER['HTTP_HOST']; //「localhost:7001」
```

### 現在アクセスしているプロトコル (HTTP or HTTPS)

$_SERVER の***'HTTPS'***にアクセスすることで、HTTPでのアクセスかHTTPSでのアクセスなのかを判定することができます。

<p class="tmp"><span>書式3</span>プロトコル判定</p>
```
$_SERVER['HTTPS'];
```
<a href="sample/url_host/https_test.php" target="blank">新規タブ3</a>


##### 新規タブ3 PHPコード
```
echo (empty($_SERVER['HTTPS']) ? 'http://' : 'https://') //「http://」
```

### 現在アクセスしているURLの全部
プロトコル + ホスト名 + パス = 現在のURLとなります。下記のように実装することで、URLを取得することができます。
```
echo (empty($_SERVER['HTTPS']) ? 'http://' : 'https://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
//「http://localhost:7001/grav/trunk/grav-admin/sample/php/url_host/url_test.php」
```

<a href="sample/url_host/url_test.php" target="blank">新規タブ4</a>



## URLからファイル名や拡張子,ディレクトリ名を取得する方法

### basename関数で取得

パスの最後にある名前を取得できます。

<p class="tmp"><span>書式4</span>basename関数の構文</p>
```
basename (ファイル名を取得したいパス [, 除外したい最後の文字] （[ ]は省略可）);
```

basename()はパスを指定するだけで、自動的にファイル名を判別し取得してくれます。

/（スラッシュ）（windowsは\（バックスラッシュ）も）を区切り文字とし、最後の区切り文字以降をファイル名として取得し、区切り文字は削除されます。

除外したい最後の文字
: 第二引数の「除外したい最後の文字」は省略可ですが、ここを指定すると、その文字列もカットされます。（拡張子を除外したい場合によく使いますが、最後の文字列しか指定できません。）

例) file.txt→.txtを指定→file部分のみ取得


#### ファイル名を取得
フルパスからファイル名だけを取得してみます。
<p class="tmp list"><span>リスト1</span></p>
```
// ファイルのフルパスを指定し、basename関数で出力
echo basename('/home/example/www/file.txt');
```
##### 出力結果
```
file.txt
```

上記のようにフルパスをbasename()で出力するとfile.txtとファイル名だけが取得できます。


#### ディレクトリ名を取得
パスの最後がディレクトリ名だった場合、そのディレクトリを取得します。

<p class="tmp list"><span>リスト2</span></p>
```
// 最後がファイルではなくディレクトリだったら、最後のディレクトリを取得する
echo basename('/home/example/www/dir/');
```

##### 出力結果
```
dir
```

最後がディレクトリでも、最後の文字列を区切り文字/（スラッシュ）を除いて取得します。


#### ファイル名から拡張子を除外して取得
フルパスからファイル名を、拡張子を省いて取得してみます。

<p class="tmp list"><span>リスト3</span></p>
```
// basename関数の第二引数に拡張子を指定すると、そこを除外して取得できる
echo basename('/home/example/www/file.txt', '.txt');
```

##### 出力結果
```
file
```

今度は.txtも除外され、ファイル名のfileの部分だけが取得できました。


### pathinfo関数で取得

<p class="tmp"><span>書式5</span>pathinfo関数の構文</p>
pathinfo ( ファイル情報を取得したいファイルパス [, オプション]（[ ]は省略可） );

ファイル情報を連想配列に格納するので、呼び出したいキーを指定すれば自由に引き出し可能です。

ファイルパスに関する情報を取得できます。

#### ファイル名や拡張子などを取得
pathinfo()はファイル名だけではなく、拡張子やディレクトリなども配列で取得できます。

<div class="box-example">
<h3 class="h-example">例1</h3>
ファイル名や拡張子などのそれぞれの情報を配列に格納し、個々に取り出せます。
</div>
<iframe src="https://paiza.io/projects/e/Blo4WT2wJmtEQq6xERr22w?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


#### pathinfo関数のオプション一覧
オプションは以下の4つです。

|記述|説明|	例|
|--|--|--|
|'**dirname**'|	ディレクトリ名|	/home/example/www|
|'**basename**'|	ファイル名|	file.txt|
|'**extension**'|	拡張子|	txt|
|'**filename**'|	拡張子なしのファイル名|	file|


### realpath関数でフルパス取得

相対パスから絶対パスを取得します。

<p class="tmp"><span>書式6</span>realpath関数の構文</p>
```
realpath($path) # $pathは相対パスかファイル名を格納した変数
```
新規タブ5をクリックすると、絶対パスが表示されます。
<a href="sample/url_host/realpath_test1.php" target="blank">新規タブ5</a>


##### 新規タブ5 PHPコード
```
echo realpath("../");
```
こんな感じで取得した値が表示されます。（JQueryのprop()とはちょっとちがうみたい）
```
string(48) "C:\xampp\htdocs\grav\trunk\grav-admin\sample\php"
```

## IPアドレスを取得

訪問者のipアドレスを取得するには、サーバー環境変数の$_SERVER["REMOTE_ADDR"]を参照します。

<p class="tmp"><span>書式7</span>IPアドレスを取得</p>
```
$_SERVER["REMOTE_ADDR"]
```

## ServerNameを取得

$_SERVER['HTTP_HOST']は、リクエストヘッダーのHost：の内容が保存されています。一方で  **$_SERVER['SERVER_NAME']**は、apacheやnginxなどで設定されているServerNameとなります。

<p class="tmp"><span>書式8</span>ServerNameを取得</p>
```
$_SERVER['SERVER_NAME']
```
新規タブ6をクリックすると、ServerNameの値が表示されます。➡「localhost」
<a href="sample/url_host/sever_name.php" target="blank">新規タブ6</a>


## ドキュメントルート取得

<p class="tmp"><span>書式9</span>ドキュメントルート</p>
```
$_SERVER['DOCUMENT_ROOT']
```
何も設定せず、htdocsにファイルを設置すると、$_SERVER['DOCUMENT_ROOT']で取得したドキュメントルートは「C:/xampp/htdocs」と表示されます。

## 前ページURLを取得する

どのページからアクセスされたか、前ページのURLを取得するには、スーパーグローバル変数の $_SERVER を使います。  
$_SERVERは配列になっており、HTTP_REFERER というキーワードを指定することで前ページのURLを取得できます。

<p class="tmp"><span>書式10</span>前ページURLを取得</p>
```
// 遷移元URL
$motourl = $_SERVER['HTTP_REFERER'];
```

## 絶対パスとマジック定数` __DIR__`と`__FILE__`の使い方
絶対パスの場合マジック定数と合わせて使うことが多いです。  
マジック定数は、
```
<?php
// 実行中のファイルが格納されているフォルダまでの絶対パス
  echo __DIR__;
// 実行中のファイルまでの絶対パス
  echo __FILE__;

  // 絶対パスで指定
  require __DIR__ . '/file1.php';
```
`__DIR__`は実行中のファイルが格納されているフォルダまでの絶対パスを取得できます。
`__FILE__`は実行中のファイルまでの絶対パスを取得できます。


## 参考サイト

* [phpで現在のURLを取得する方法！](https://blog.codecamp.jp/php-request-url)
* [PHPでファイル名や拡張子,ディレクトリ名を取得する方法](https://www.flatflag.nir87.com/basename-844)
* [相対パスから絶対パスを取得 - realpath()](https://webkaru.net/php/function-realpath/)
* [ipアドレスを取得する方法](https://lab.syncer.jp/Web/PHP/Snippet/3/)
* [PHP $_SERVER（サーバー変数）のすべて！【初心者向け基本】](https://wepicks.net/phpref-server/)
* [PHPのディレクトリまとめ](https://qiita.com/okdyy75/items/cc9e99025345bb17c37b)
* [【PHP入門】pathinfo関数を使って拡張子名やファイル名を簡単取得](https://www.sejuku.net/blog/50670)
* [PHPでどこから遷移してきたか前ページURLを取得する方法](https://dev-lib.com/php-get-caller-url/#:~:text=%E3%81%A9%E3%81%AE%E3%83%9A%E3%83%BC%E3%82%B8%E3%81%8B%E3%82%89%E3%82%A2%E3%82%AF%E3%82%BB%E3%82%B9%E3%81%95%E3%82%8C,URL%E3%82%92%E5%8F%96%E5%BE%97%E3%81%A7%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
* [PHP でルートディレクトリパスを見つける](https://www.delftstack.com/ja/howto/php/php-root-directory/)