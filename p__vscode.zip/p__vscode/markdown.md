*[page-title]: VSCODE

## コード整形

### 保存時にコードを整形する

VSCodeでコード整形ツール(Fomatter)を使用します。

[ファイル]－[ユーザ設定]－[設定]で設定画面を開き、formatOnで検索します。

以下の画面が表示されるので、<span class="green bold">Editor: Fomat On Save</span> にチェックを入れます。

![](upload/保存時コード整形設定2.png)


### タブを整形する

<span class="green bold">Shift + Alt + F</span> でタブが揃います。

### head要素とbody要素の調節

参考サイト
: [Visual Studio Codeのフォーマッタを自分好みに設定してみる。](https://www.techscore.com/blog/2019/09/10/visual-studio-code%E3%81%AE%E3%83%95%E3%82%A9%E3%83%BC%E3%83%9E%E3%83%83%E3%82%BF%E3%82%92%E8%87%AA%E5%88%86%E5%A5%BD%E3%81%BF%E3%81%AB%E8%A8%AD%E5%AE%9A%E3%81%97%E3%81%A6%E3%81%BF%E3%82%8B%E3%80%82/)

デフォルトでは、フォーマッタを実行すると、htmlやbodyの間に空行ができてしまいます。  
![](upload/整形設定変更前空行ができる.png)

この空行を入れずに、コードを整形したい時は、以下のように設定を変えてやります。

settings.jsonと呼ばれるVSCodeの設定画面が開きます。  
settings.jsonに下記のコードを追加します。

```
"html.format.extraLiners": ""
```

<p class="tmp list"><span>リスト</span>setting.json</p>
```
{
  "launch": {
	
	～省略～
	
  "editor.formatOnSave": true,
  "[html]": {
    "editor.defaultFormatter": "vscode.html-language-features"
  },
  "html.format.extraLiners": "" //←追加（整形時に空行を挿入しない）
}
```
そうすると、フォーマッタを実行した時、空行が挿入されなくなりました（元々ある空行は、整形してもそのままです）。
![](upload/整形設定変更後空行なし.png)

これだけだと、すでに存在している空行は消えてくれません。  
空行を消したい場合は以下の行を追加します。

```
"html.format.preserveNewLines": false
```

<p class="tmp list"><span>リスト</span>setting.json</p>
```
{
  "launch": {
	
	～省略～
	
  "[html]": {
    "editor.defaultFormatter": "vscode.html-language-features"
  },
  "html.format.extraLiners": "", 
  "html.format.preserveNewLines": false //追加（整形時に空行を削除する）
}
```

上記を追加することで、フォーマット時に要素前の空行を自動削除してくれるようになります。
※要素内の空行は無視されます。

![](upload/整形設定変更前空行も削除.png "コード整形前")

![](upload/整形設定変更後空行も削除.png "コード整形後")

### 画面上でのコード折り返し

VScodeではエディタ上で「Alt + Z」キーを押すことで、コードの折返し設定を切り替える事が可能です。 このショートカットキーでは表示しているファイルに対してのみ折返しを切り替えられ、他のファイルにあるコードには影響しません。


## MDNリファレンスを非表示

参考サイト
: [Visual Studio CodeのReference informationを非表示にする方法](https://qiita.com/unsoluble_sugar/items/6985aba97a5a89ca609f#:~:text=Visual%20Studio%20Code%E3%81%AE%E3%83%A1%E3%83%8B%E3%83%A5%E3%83%BC%E3%81%8B%E3%82%89%E8%A8%AD%E5%AE%9A%E7%94%BB%E9%9D%A2%E3%81%B8%E3%82%A2%E3%82%AF%E3%82%BB%E3%82%B9%E3%80%82&text=%E6%A4%9C%E7%B4%A2%E7%AA%93%E3%81%AB%E3%80%8Ceditor.codeLens,%E3%83%81%E3%82%A7%E3%83%83%E3%82%AF%E3%82%92%E5%A4%96%E3%81%9B%E3%81%B0OK%E3%80%82)
: [VSCodeの邪魔な機能を無効にする](https://yoshiya-kiryu.com/vscode-obstacle-function/#:~:text=%E3%81%84%E3%82%89%E3%81%AA%E3%81%84%E3%83%9D%E3%83%83%E3%83%97%E3%82%A2%E3%83%83%E3%83%97,-%E3%82%82%E3%81%86%E4%B8%80%E3%81%A4&text=%E3%80%8CMDN%20Reference%E3%80%8D%E3%82%92%E3%82%AF%E3%83%AA%E3%83%83%E3%82%AF%E3%81%99%E3%82%8B%E3%81%A8,%E8%B5%A4%E4%B8%B8%E3%81%AE%E3%83%81%E3%82%A7%E3%83%83%E3%82%AF%E3%82%92%E5%A4%96%E3%81%99%E3%80%82)

コードを入力するとき、下図ののようにMDNリファレンスのメッセージが表示されて、煩わしいと思うことがあります。  
![](upload/MDNリファレンスメッセージ.png "MDNリファレンスメッセージ")
その場合、設定を変更し、非表示にするとよいです。

### 方法

設定画面を開き、検索窓に「**editor.codeLens**」と入力します。
![](upload/editor.codeLens.png)
「エディタでCodeLensを表示するかどうかを制御します」のチェックを外します。

これで、表示されなくなります。

かと思いきや、まだ表示されました。

![](upload/まだMDNリファレンス表示される.png)

なので、再度、設定を開き、「editor.hover」を検索窓に入力し、下記の「Editor>Hover:Enabled」の「ホバーを表示するかどうかを制御します。」のチェックを外してやります。
![](upload/editor_hover.png)

そうすると、今度は表示されなくなりました。
![](upload/表示されなくなりました.png)

これでポップアップが出なくなるのですが、カラーピッカーやコード入力補助まででなくなってしまいます。 

ですので、その都度必要な時にチェックを入れる必要が出てきます。


## 自動保存

参考サイト
: [エディターの自動保存の設定](https://www.javadrive.jp/vscode/setting/index2.html)

## 全角英数字を半角変換

VSCODEには、標準で全角、半角を相互に変換する「Convert Width for novel writer」の拡張機能がインストールされています。

ファイルを開き、「<span class="green bold">Shift＋Ctrl＋P</span>」で次のようなコマンド選択の一覧が表示されます。
![](upload/command選択.png)

この中から目的のコマンドをクリックすれば、全角から半角のように変換されます。

## SASSをコンパイル

### Live Sass Compiler

参考サイト
: [【自動コンパイル】VSCodeでSassを使う方法を解説](https://ralacode.com/blog/post/vscode-sass/)
: [【Live Sass Compiler】cssの出力先を変更する](https://shuu1104.com/2021/09/4145/)
: [「Live Sass Compiler」の設定方法 - VScodeでSassを書く](https://yumegori.com/vscode-sass-setting20200116)


まず、画面左側の「Extensions」ボタンをクリックします。

検索欄に「live sass compiler」と入力します。  
検索結果に「Live Sass Compiler」が表示されるので、インストールします。

インストールが完了したら、試しにデスクトップに「sass_lesson」というフォルダを作成し、その中にindex.htmlとstyle.scssを設置します。

<p class="tmp list"><span>リスト</span>inex.html</p>
```
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>SCSSをVSCODEで変換</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h2>SassTest</h2>
    </div>
    <div class="main">
        <h1>SCSSをVSCODEで変換</h1>
        <p>Sassで効率的にCSSを管理する</p>
    </div>
    <div class="footer"> © SassTest </div>
</body>
</html>
```
<p class="tmp list"><span>リスト</span>style.scss</p>
```
body, h1, h2, p {
  margin: 0;
  padding: 0;
}

.header {
  background-color: #f79314;
  padding-left: 20px;
  padding-right: 20px;
  color: white;

  & h2 {
    line-height: 100px;
    font-size: 30px;
  }
}

.main {
  background-color: #fcfaf5;
  height: calc(100vh - (100px + 50px));
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: center;

  & h1 {
    font-size: 60px;
  }
}

.footer {
  background-color: #f79314;
  line-height: 50px;
  text-align: center;
  color: white;
}
```
![](upload/sass_lessonフォルダ出力前.png "コンパイル前のsass_lessonフォルダ内")

Live Sass Compailerの設定画面を開きます。
![](upload/live_sass_設定.png)

タブのワークスペースを選択し、setting.jsonを開きます。
![](upload/setting_jsonを開く.png)

setting.jsonのコードを、コンパイルしたいフォルダだけ記述するか、除外の設定をします。  
（デフォルトでは、ワークスペースに登録しているフォルダがwatchされるように全部のフォルダのパスが記述されています。）
![](upload/ワークスペース内watchフォルダの指定.png "ワークスペース内watchフォルダの指定")

<p class="tmp list"><span>リスト</span>workspace.json</p>
```
{
  "folders": [
    {
      "path": "..\\..\\..\\..\\..\\Desktop\\sass_lesson"
    }
  ],
  "settings": {}
}
```

VSCODE画面下部の「Sass Watch」をクリックすると、
![](upload/下部WatchSass.png)

sass_lessonフォルダに、style.cssとstyle.css.mapが出力されています。
![](upload/sass_lessonフォルダ出力後.png)

<p class="tmp list"><span>リスト</span>style.css</p>
```
body,
h1,
h2,
p {
  margin: 0;
  padding: 0;
}

.header {
  background-color: #f79314;
  padding-left: 20px;
  padding-right: 20px;
  color: white;
}

.header h2 {
  line-height: 100px;
  font-size: 30px;
}

.main {
  background-color: #fcfaf5;
  height: calc(100vh - (100px + 50px));
  text-align: center;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
      -ms-flex-direction: column;
          flex-direction: column;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
}

.main h1 {
  font-size: 60px;
}

.footer {
  background-color: #f79314;
  line-height: 50px;
  text-align: center;
  color: white;
}
/*# sourceMappingURL=style.css.map */
```

<p class="tmp list"><span>リスト</span>style.css.map</p>
```
{
    "version": 3,
    "mappings": "AAAA,AAAA,IAAI;AACJ,EAAE;AACF,EAAE;AACF,CAAC,CAAC;EACE,MAAM,EAAE,CAAC;EACT,OAAO,EAAE,CAAC;CACb;;AAED,AAAA,OAAO,CAAC;EACJ,gBAAgB,EAAE,OAAO;EACzB,YAAY,EAAE,IAAI;EAClB,aAAa,EAAE,IAAI;EACnB,KAAK,EAAE,KAAK;CAMf;;AAVD,AAMI,OANG,CAMD,EAAE,CAAC;EACD,WAAW,EAAE,KAAK;EAClB,SAAS,EAAE,IAAI;CAClB;;AAGL,AAAA,KAAK,CAAC;EACF,gBAAgB,EAAE,OAAO;EACzB,MAAM,EAAE,4BAA4B;EACpC,UAAU,EAAE,MAAM;EAClB,OAAO,EAAE,IAAI;EACb,cAAc,EAAE,MAAM;EACtB,eAAe,EAAE,MAAM;CAK1B;;AAXD,AAQI,KARC,CAQC,EAAE,CAAC;EACD,SAAS,EAAE,IAAI;CAClB;;AAGL,AAAA,OAAO,CAAC;EACJ,gBAAgB,EAAE,OAAO;EACzB,WAAW,EAAE,IAAI;EACjB,UAAU,EAAE,MAAM;EAClB,KAAK,EAAE,KAAK;CACf",
    "sources": [
        "style.scss"
    ],
    "names": [],
    "file": "style.css"
}
```

これで、現在Watch状態になっているので、style.scssのコードを変更して保存すれば、変更したコードがstyle.cssに出力されます。


出力先のフォルダを指定するには、ユーザータブのsetting.lsonを開いて、下記のコードを追記します。
![](upload/scss出力先変更setting_json.png)
<p class="tmp list"><span>リスト</span>出力先指定コード</p>
```
"liveSassCompile.settings.formats": [ //追加
  {
    "format": "expanded",
    "extensionName": ".css",
    "savePath": "/css"
  }
],
```
これで、style.scssのコードを変更して保存すると、cssフォルダにstyle.cssとstyle.css.mapが出力されるようになります。
![](upload/scss出力先をcssフォルダに設定.png)

### DartJS Sass Compiler and Sass Watcher

参考サイト
: [Visual Studio Codeのプラグイン「DartJS Sass Compiler and Sass Watcher」を使ってSCSS（dart-sass）環境を簡単に作ってみよう！](https://arrown-blog.com/artjs-sass-compiler-and-sass-watcher/)
: [sassのパーシャルファイル変更時にコンパイルさせる方法【DartJS Sass Compiler and Sass Watcher】](https://shuu1104.com/2021/09/4258/)
: [【VSCode】Dart Sassが使える拡張機能 - DartJS Sass Compiler and Sass Watcherの使い方](https://yumegori.com/vscode-dart-sass-setting)
: [DartJSSassコンパイラとSassウォッチャー](https://marketplace-visualstudio-com.translate.goog/items?itemName=codelios.dartsass&_x_tr_sl=en&_x_tr_tl=ja&_x_tr_hl=ja&_x_tr_pto=sc)
: [Sassを使うならDart Sassに乗り換えよう！](https://tiplib-web.com/tips/211204_dart_sass/)
: [Dart SassをVSCodeの拡張機能(プラグイン)で利用する方法を紹介](https://moshashugyo.com/media/dart-sass)

 

公式が推奨する<span class="green bold">dart-sass</span>に準じたプラグインを使って、コンパイルする方法を紹介します。

フォルダは以下を使っていきます。

```
C:\Users\hirao\Desktop\test\sass_compile\DARTSASS-TEST
```

まず、「DartJS Sass Compiler and Sass Watcher」をインストールします。

次に、フォルダにsetting.jsonを作成します。

指定したフォルダをVSCODEで開きます。（ワークスペースは使用しない。単独で）

CTRL + SHIFT + P を押して、コマンド入力欄に「**Open Workspace Setting(JSON)**」を入力して、選択してからENTERを押します。

すると、<span class="green bold">.vscode</span>というフォルダが作成され、その中に<span class="green bold">setting.json</span>ファイルが生成されます！

![](upload/setting_json.png)

setting.jsonファイルに出力先フォルダを指定します。（デフォルトでは、scssファイルある場所と同じ階層に出力されます。）

```
{
    "dartsass.targetDirectory": "css/",
    "dartsass.outputFormat":"both"
}
```

この状態で、scssファイルを変更して保存すると、cssフォルダに **～.css**、**～.css.map**、**～.min.css**、**～.min.css.map** の4つのファイルが出力されます。

`"dartsass.outputFormat": "cssonly" `に変更すると、**～.css**、**～.css.map**の2つのファイルだけ出力されます。


<div markdown="1" class="gray-box">
設定コードまとめ
: dartsass.targetDirectory・・・出力するcssファイルはどのフォルダにするか
: dartsass.autoPrefixBrowsersList・・・Autoprefixerの指定
: dartsass.outputFormat・・・出力するcssのフォーマットを指定。cssonly、minified、bothの３つから選べます
: dartsass.disableSourceMap・・・ソースマップはデフォルトでは出力されます。trueにすると、出力されないようになります。
</div>

詳細画面からでも設定できます。  
左メニューの一番下の拡張機能アイコン![](upload/左メニュー拡張機能アイコン.png)をクリックして、表示された拡張機能から「DartJS Sass Compiler…」の歯車マークをクリックすると、詳細画面が開くので、
![](upload/DartSass詳細設定画面.png)
タブをワークスペースにして、チェックや記入をしていくとsettng.jsonが変更されます。
![](upload/DartSass詳細設定画面の内容.png)



#### パーシャルファイルを変更した時に、コンパイルする方法

参考サイト
: [パーシャルファイル](https://seisaku.fun/web/sass-partial/)

完成フォルダ
: `C:\Users\hirao\Desktop\test\sass_compile\DARTSASS-TEST`

![](upload/パーシャルファイル.png)
上図のように、「_（アンダースコア）」を付けることで、コンパイルしてもCSSが生成されないようにする機能のことを「<span class="green bold">パーシャル（partial）</span>」と言います。

<span class="green bold">パーシャルファイル</span>を変更した時に、コンパイルが実行できるようにする方法を説明します。。

Node.jsがインストールされてることを前提として、進めていきます。

コマンドプロンプトかターミナルを起動して、ファイルを置いているフォルダに移動します。　


package.jsonを作成します。

<p class="tmp cmd"><span>コマンド</span></p>
```
npm init -y
```

sassのプラグインをインストールします。
<p class="tmp cmd"><span>コマンド</span></p>
```
npm i -D sass
```

node_modulesが作成され、その中に先ほどインストールしたsassプラグインが入っています。

<!--ファイル > ユーザー > 設定 で**設定画面**を開き、検索窓から「<span class="green bold">Dartsass:Sass Bin Path</span>」で検索します。

出てきた項目に以下を入力してください。

<p class="tmp list"><span>リスト</span></p>
```
node_modules/sass/sass.js
```
-->

setting.jsonに次のdartsass.sassBinPathの設定コードを追記します。
<p class="tmp list"><span>リスト</span>setting.json</p>
```
{
    "dartsass.targetDirectory": "css/",
    "dartsass.outputFormat":"both",
    "dartsass.sassBinPath": "node_modules/sass/sass.js" ← 追加
}

```

これで設定は、完了です。

実行するには、sassフォルダ上で右クリックして、「<span class="green bold">DartSass: Watch Sass</span>」をクリックします。

![](upload/sass_watch.png)

次の画面が開かれ、コンパイルが実行され
![](upload/watch_nodeexe.png)

タスクバーに次のアイコンが表示されれば、
![](upload/タスクバーのアイコン.png)
sassフォルダがWatch状態になっています。

起動されない時は、右クリックから「Sass UnWatch」をクリックで、一度解除をしてから、再度「Sass Watch」をクリックしてください。  
それでもダメな場合は、VSCODEを再起動してから、「Sass Watch」をクリックしてください。

実際に実行されるか_variables.scssのパーシャルファイルのコードを変更して保存してみます。

<p class="tmp list"><span>リスト</span>test.scss</p>
```
@use "variables" as var;

.main-contents {
    div {
        color: var.$color;
    }
}
```


<p class="tmp list"><span>リスト</span>_variables.scss</p>
```
$color: red; を$color: blue; に変更
```

コンパイルされ、test.cssのコードは以下のように変更されています。

<p class="tmp list"><span>リスト</span>test.css</p>
```
.main-contents div {
  color: blue;
}

/*# sourceMappingURL=test.css.map */
```

フォルダの構成が次のような場合、
![](upload/vsdartsass_Projectフォルダ構成.png)

ディレクトリをtrunkに移動して、同じように
```
npm init -y
npm i -D sass
```
を実行して、package.jsonとnode_modulesなどを作成した後、

setting.jsonの設定のパスは以下のようにします。
```
{
    "dartsass.targetDirectory": "project/css/",
    "dartsass.outputFormat":"both",
    "dartsass.sassBinPath": "node_modules/sass/sass.js"
}
```

完成したフォルダ構成は、次のようになります。
![](upload/vsdartsass_TRUNKフォルダ構成.png)


## Live Server

参考サイト
: https://webdesign-trends.net/entry/14461

## 同じコードを一括して編集する

参考サイト
: https://1-notes.com/visual-studio-code-select-the-same-string/

同じ単語、文字列の範囲を全て選択するには、指定したい単語にカーソルを合わせるか、文字列の範囲を選択してショートカットキー「<span class="green bold">Shift + Ctrl + L</span>」を押します。

## 編集中のコードを編集前の状態と比較する

参考サイト
: [編集中のコードを編集前の状態と比較する](https://1-notes.com/visual-studio-code-compare-file/)

Visual Studio Code（VScode）で編集中のファイルのコードと編集前（最後に保存した状態）の状態と比較するには、~~ショートカットキー「Ctrl + K D」を押すか~~、コマンド「File: Compare Active File With Saved（保存済みのファイルと作業中のファイルを比較）」を実行します。

<span class="red bold">※この機能は自動セーブ「Auto Save」が有効になっている場合は同じコードとなるため、利用出来ません</span>

## HTMLの終了タグ自動生成を解除

[Visual Studio Code でHTMLの終了タグ自動生成が邪魔](https://teratail.com/questions/189128)

VS Codeに標準で組み込まれているHTML拡張機能が邪魔をしています。また、Auto Close Tagもそれを考慮して、HTMLが対象外になる初期設定になっています。

まずは、設定画面で「HTML: Auto Closing Tags」を検索し、デフォルトでチェックされているのを外してください。
![](upload/auto_closing_tag.png)
あとは、Auto Close Tagをインストールして、
![](upload/auto_close_tagインストール.png)
設定画面で「Auto-close-tag: Sublime Text3 Mode」をチェックし、
![](upload/auto_closing_tag_sublime_text3_modhttps://atmarkit.itmedia.co.jp/ait/articles/1806/08/news028.html.png)
「Auto-close-tag: Activation On Language」の「settings.jsonで編集」をクリックして、
![](upload/auto_closing_tag_actination.png)
設定の中に「"html",」を追加すれば、「自分で</まで入力したときだけ、残りをVS Codeが補完する」という動作になります。←<span class="red bold">ここがわからなかった</span>

## ファイルの比較

参考サイト
: [VS Codeでファイルを比較し、差分（diff）を表示するには](https://atmarkit.itmedia.co.jp/ait/articles/1806/08/news028.html)

Visual Studio Codeには2つのファイルの内容を比較して（diffを取って）、その差を分かりやすく表示してくれる機能が内蔵されています。

コマンドパレット（Shift + Ctrl + P）を表示したら、「***compare***」などと入力してから［ファイル: アクティブ ファイルを比較しています］コマンドを実行して、比較対象のファイルを指定します。

![](upload/compare.png)

### SVNにコミットする前に比較

作業中のファイルを開き、SVNのログからコミットしたファイルをVSCODEで開きます。
![](upload/svnコミットファイルを開く.png)

同じように、コマンドパレット（Shift + Ctrl + P）を表示して、［ファイル: アクティブ ファイルを比較しています］コマンドを実行して、比較対象のファイルを指定します。
![](upload/コミットしたファイルと比較.png)


## ショートキー
起動したときに、表示されていたショートキーです。
![](upload/VSCODE初期画面にあるショートキー.png)

## 行をまるごと選択

行選択は、<span class="green bold">CTRL + L</span> で一行丸ごと選択できます。

または、行番号をクリックしても、丸ごと選択できます。


## 指定した行番号に移動（Ctrl+G）

Visual Studio Codeを起動し、ファイルを開いている状態で【Ctrl】キーと【G】キーを押します。   
すると、Visual Studio Codeの上部にテキストボックスが表示されます。 
![](upload/行番号に移動.png)
表示されたテキストボックスに移動したい行番号を指定します


### 先頭行、最終行、対の括弧に移動

ファイルの先頭へジャンプ
: Ctrl + Fn + Home

ファイルの最後へジャンプ
: Ctrl + Fn + End

対の括弧にジャンプ
: Ctrl + Shift + \（円マーク）

SassやJavaScriptなどは、対となる括弧が離れた場所にある場合が多々あります。括弧にジャンプも覚えておくと便利です。

## Emmet記法の活用

参考サイト
: [【チートシート付き】Emmetをまとめてみた！コーディング速度アップを目指そう！](https://crestadesign.org/emmet/)
: [Emmet（エメット）でHTMLとCSSを効率的にコーディングする](https://b-risk.jp/blog/2021/06/emmet/)

### HTMLの基本テンプレートを呼び出す方法

参考サイト
: <https://manabu-biology.com/archives/%E3%80%90visual-studio-code%E3%80%91html%E3%81%AE%E5%9F%BA%E6%9C%AC%E3%83%86%E3%83%B3%E3%83%97%E3%83%AC%E3%83%BC%E3%83%88%E3%82%92%E5%91%BC%E3%81%B3%E5%87%BA%E3%81%99%E6%96%B9%E6%B3%95.html>

### 「!」を入力してtabキーを押す
ファイルを新規作成し、○○〇.html（○〇〇の名前は自由）とします。そのファイルを開き、「!」を入力してtabキーを押すと以下のテンプレートが自動入力されます。

```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
```

呼び出した後、lang属性がen（英語）になっているのでja（日本語）に変更しましょう。

css読み込みのlinkタグの場合

「link:css」 を入力して、Enterキーを押下します。  
そうすると、次のlinkタグが入力されます。
```
<link rel="stylesheet" href="style.css">
```

javascriptの読み込みコードの場合、「script:src」と入力してEnterキーを押下します。  
そうすると、次のコードが入力されます。
```
<script src=""></script>
```




### 通常のHTMLタグ

HTMLタグを入力したいときは、HTMLタグ名を入力してtabキーを押下します。

例えば、h1と入力してtabキーを押下すると、以下のようになります。

```
<h1></h1>
```

また、h1{タイトル}と入力してtabキーを押下すると、テキストが記入されます。

<div class="exp">
	<p class="tmp"><span>例</span></p>
「	h1{見出しです}」と入力した場合、次のようになります。
	</div>
```
<h1>見出しです</h1>
```

クラスを設定する場合、「.」（ピリオド）を付けます。



ulタグやolタグを入力するときは、「ul>li*リスト数」 や 「ol>li*リスト数」 を入力して、tabキーを押下します。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	「ul>li*3」と入力した場合、次のようになります。
	</div>
```
<ul>
    <li></li>
    <li></li>
    <li></li>
</ul>
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
「ul>li{リストです}*3」と入力した場合、次のようになります。
	</div>
```
<ul>
    <li>リストです</li>
    <li>リストです</li>
    <li>リストです</li>
</ul>
```

リストの中に、aのリンクを設置する場合は、ul>(li>a{リンク})*3を入力して、エンターキーを押します。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	ul>(li>a{リンク})*3を入力した場合
	</div>
```
	<ul>
    <li><a href="">リンク</a></li>
    <li><a href="">リンク</a></li>
    <li><a href="">リンク</a></li>
</ul>
```

### 「wrap with abbreviation」でタグを後から付け足す

参考サイト
: [【VSCode】まずはこれを覚えよう！初心者のためのショートカット２９選！](https://skillhub.jp/blogs/234)

1. 囲みたい部分を選択  
（囲みたい部分を全て選択します。カーソルがある行での実行ではありませんのでご注意ください。)
2. コマンドパレットを開いて、「wrap with abbreviation」を選択   
「wrap」と入力すると候補で出てきます。
3. 入力窓が出てきますので、囲みたいタグを入力

![](upload/タグを後から付け足す.gif)

## サイドバーの開閉ショートカットキー

参考サイト
: [VS Codeのサイドバーの表示をキーボードで切り替えるには](https://atmarkit.itmedia.co.jp/ait/articles/1807/13/news032.html)

サイドバーは、便利なツールだが、複数のエディタを並べて表示している場合などには表示領域の無駄となる。そこで、［Ctrl］＋［B］キー（macOSでは［Command］＋［B］キー）を押すことで、その表示／非表示をトグル形式に切り替えらます。


## Live Sever

参考サイト
: [Live Serverを使ってWeb制作でライブリロードを活用しよう](https://webdesign-trends.net/entry/14461)

ファイルを開き、その上で右クリックで、「Open with Live Server」をクリックします。
![](upload/Open_with_Live_Sever.png)

そうすると、そのファイルのサイトが開かれます。
C:\Users\hirao\Desktop\bootstrap\bootstrap_carousel\index.htmlで実行  
例）
http://127.0.0.1:5500/bootstrap_carousel/index.html

開けなかった時は、一旦「Stop Live Server」をクリックした後、再度「Open with Live Server」をクリックしてください。

### PHPのファイルの場合
PHPのファイルの場合も同じように、ファイルを開いた後、右クリックをして「PHP Server: Server Project」をクリックします。
![](upload/PHP_Server_Open.png)

そうすると、少ししてそのファイルのサイトが開かれます。
C:\xampp\htdocs\201810_gw_johosite\trunk\project\index.phpで実行  
例）  
http://localhost:3000/xampp/htdocs/201810_gw_johosite/trunk/project/index.php

開けなかった時は、「PHP Server: Stop sever」をクリックした後、再度「PHP Server: Server Project」をクリックしてください。


## マークダウンプレビュー

参考サイト
: [VS CodeでMarkdownで書いた文書ファイルをプレビューする方法](https://tonari-it.com/vscode-markdown-preview/)

**VS Codeでは、Markdownで作成したファイルのプレビュー機能がデフォルトで搭載されています。**

マークダウンのファイルを開き、右上のプレビューアイコンをクリックします。
![](upload/マークダウンプレビューアイコン.png)

そうすると、右側にプレビュー画面が表示されます。
![](upload/マークダウンプレビュー表示.png)

## setting.jsonの開き方

【ファイル】－【ユーザー設定】－【設定】で設定画面を開きます。
![](upload/ユーザー設定_設定.png)

設定画面右上の左端のアイコンをクリックすると、setting.jsonが開かれます。
![](upload/setting_json開くアイコン.png)