---
title: (移動済)URLを取得（location）
taxonomy:
    category:
        - docs
---

## locationのプロパティとメソッド一覧

| プロパティ名 | 内容 |
|: -------- | -------- |
|location.**href**	| 指定したURLに画面遷移する|
|location.**protocol**	| 現在のプロトコル情報(http:など)を取得する|
|location.**host**	| プロトコル情報を除外したURLを取得する(port情報あり)|
|location.**hostname**	| プロトコル情報を除外したURLを取得する(port情報なし)|
|location.**port**	| ポート番号を取得・設定する|
|location.**pathname**	| URLでパスの部分を取得・設定する|
|location.search	| URL内のクエリ情報を抽出して取得する|
|location.hash	| URL内のハッシュ情報を抽出して取得する|
|location.origin	| プロトコルやポートを含めたURLを取得する|

####  参考例

```
url.href = 'https://developer.mozilla.org:8080/en-US/search?q=URL#search-results-close-container';
console.log(url.href);      // https://developer.mozilla.org:8080/en-US/search?q=URL#search-results-close-container
console.log(url.protocol);  // https:
console.log(url.host);      // developer.mozilla.org:8080
console.log(url.hostname);  // developer.mozilla.org
console.log(url.port);      // 8080
console.log(url.pathname);  // /en-US/search
console.log(url.search);    // ?q=URL
console.log(url.hash);      // #search-results-close-container
console.log(url.origin);    // https://developer.mozilla.org:8080
```

<div class="box-example">
    <h3 class="h-example">例1</h3>
    「★★★[abcdefg.... 」をsplitを使って、"["の箇所で区切って、先頭の文字をコンソールに表示する。
</div>
<script async src="//jsfiddle.net/ac2vem08/embed/js,result/"></script>

<div class="box-example">
    <h3 class="h-example">例2</h3>
    ①「https://github.com/sshono1210/gitLesson」を「/」で区切って、一番最後と最後から2番目の文字をコンソールに表示する。<br>
    ②「http://www.sample.com/img/sample.jpg」を「/」で区切って、一番最後の文字をコンソールに表示する。
</div>
<script async src="//jsfiddle.net/xcuboaq1/1/embed/js,result/"></script>