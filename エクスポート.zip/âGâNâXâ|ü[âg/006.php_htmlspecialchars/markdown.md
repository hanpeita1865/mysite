*[page-title]:htmlspecialchars関数

 参考サイト
 : [PHP htmlspecialcharsについて](https://qiita.com/hyuy/items/a1b64c5902eb130a2530)
 : [クロスサイトスクリプティング（XSS）とは？わかりやすく解説](https://www.shadan-kun.com/waf_websecurity/xss/)
 : [【PHP】htmlspecialcharsの使い方を分かり易く解説！](https://flytech.work/blog/7620/)
 
 ## htmlspecialcharsについて
 
 phpのhtmlspecialchars関数は、 HTMLタグ(例：「&」、「”」、「’、「<」、「>」)などに使われる特殊文字をエンティティに変換します。  
XSS等による攻撃を防ぐためにhtmlspecialchars関数はよく使われます。  
これらの特殊文字が含まれていないことが確実ならば、htmlspecialchars関数を省略することもできます。また、含まれている可能性があるならば、Step6のようにhtmlspecialchars関数を使うとよいでしょう。
 
変換する理由
: XSSを防ぐため。
: テキストで入力されたものを正しくHTMLに出力するため。


### HTMLの特殊文字とは
特殊文字とは、文字列として入力を行えない特殊な文字のことをいいます。
例をあげると、HTML タグ(例：「&」、「”」、「’」、「<」、「>」)等です。  
そんな特殊文字ですが、以下のように変換されます。

特殊文字	| 変換
------ | ------
＆（アンパサンド）	| ＆amp
“（二重引用符）	| ＆quot;
‘（一重引用符）	| &apos;
<（より小）	| &lt;
>（より大きい）	| ＆gt;


## htmlspcialcharの使用方法

htmlspcialchar()関数は、「<」 「>」のような特殊文字をHTMLエンティティに変換することができます。

<p class="tmp"><span>書式</span></p>
```
htmlspecialchars( 変換対象文字, 変換パターン, 文字コード ) 
```
htmlspecialcharsには、( 変換対象の文字, 変換パターン, 文字コード ) の3つの引数があります。
<span class="red">第一引数</span>、変換対象の文字には変換したい文字を設定してください。リテラルでないく変数でも指定できます。  
<span class="red">第二引数</span>、変換パターンを指定してください。下記の例は、ENT_QUOTES(シングルクオートとダブルクオートを共に変換)を指定してます。  
<span class="red">第三引数</span>、文字コードを指定してください。下記の例ではUTF-8を指定してます。

<div class="exp">
	<p class="tmp"><span>例</span></p>
文字列に変換しています。
	<iframe src="https://paiza.io/projects/e/vk_xQFDNjIYszht2kmv4eg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>
