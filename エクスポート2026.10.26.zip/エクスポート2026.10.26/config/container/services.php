<?php

use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    DirReplaceService,
    MenuService,
    MarkdownService,
    LockService,
};
use SocymSlim\SlimMiddle\Config\AppConfig;
use SocymSlim\SlimMiddle\middlewares\EventLog;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Psr\Log\LoggerInterface;
use SocymSlim\SlimMiddle\Factory\PdoFactory;
use SocymSlim\SlimMiddle\middlewares\PageAccessLogMiddleware;



return function ($container) {
   
    $container->set(PDO::class, function ($c) {
        return (new PdoFactory())(
            $c->get(AppConfig::class)
        );
    });

    
    // Logger
    $container->set(LoggerInterface::class, function ($c) {
        $config = $c->get( AppConfig::class );
        $rootPath = $config->rootPath;

        $logger = new Logger('app');
        $logger->pushHandler(
                new StreamHandler($rootPath . '/logs/app.log', Logger::INFO)
        );
        return $logger;
    });
    

    
    // EventLog
    $container->set(EventLog::class, DI\autowire());
    
    //AcceesLog 追加   
    $container->set(
        PageAccessLogMiddleware::class,
        DI\autowire()
            ->constructorParameter(
                'accessLogger',
                DI\get('accessLogger')
            )
    );
    
    // EditService
    $container->set(EditService::class, DI\autowire());

    // FolderService
    $container->set(FolderService::class, DI\autowire());
        
    //DirReplaceService
    $container->set(DirReplaceService::class, DI\autowire());
    
    //MenuService   
    $container->set(MenuService::class, DI\autowire());
    
    //MarkdownService    
    $container->set(MarkdownService::class, DI\autowire());
 
    //LockService
    $container->set(LockService::class, DI\autowire());
    
    //テストHTML Purifier
    $container->set(HTMLPurifier::class, function () {
    
        $config = HTMLPurifier_Config::createDefault();

        // 許可するタグ・属性を限定（Markdown向け）

        $config->set('HTML.Allowed', '
            h1[id|class],h2[id|class],h3[id|class],h4[id|class],h5[id|class],h6[id|class],
            p[class],br,hr,
            strong,em,del,
            ul[class],ol[class],li[class],
            blockquote[class],
            pre,code,
            a[href|title|class],
            span,
        ');

        // target="_blank" 対応したい場合
        $config->set('HTML.TargetBlank', true);

        return new HTMLPurifier($config);
    });
};
