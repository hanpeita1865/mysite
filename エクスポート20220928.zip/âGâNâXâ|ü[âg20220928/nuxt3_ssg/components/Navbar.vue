<template>
  <div>
    <nav class="navbar navbar-expand-lg bg-light">
      <div class="container-fluid">
        <NuxtLink class="navbar-brand" to="#">Navbar</NuxtLink>

        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <NuxtLink class="nav-link" activeClass="active" aria-current="page" to="/">Home</NuxtLink>
            <NuxtLink class="nav-link" activeClass="active" to="/secondpage">Second Page</NuxtLink>
            <NuxtLink class="nav-link" activeClass="active" to="/fishdata">Fish Data</NuxtLink>
          </div>
        </div>
      </div>
    </nav>
  </div>
</template>

