---
title: その他プラグイン
media_order: 'sitemap.png,external1.png,external2.png,markdown-detail.png'
taxonomy:
    category:
        - docs
---

## External Links（外部リンクアイコン）


「http」や「https」などで始まるリンクを、自動で外部リンクに変更します。  
外部リンクの後ろには、別ウィンドウアイコンがつきます。
#### 例)

[google](https://www.google.co.jp/)

### 設定
External Linksタブを開き、Use built in CSSが「はい」になってるのを確認する。
![](external1.png)

Settingsタブを開くと初期値は以下のように設定されています  
上側は「www」で始まるリンクを設定します。 または外部として許可されたスキームのリストを設定します。  
下側は、**特定のクラス**またはドメインを持つリンクを外部リンクとして認識されないように**除外します**。
![](external2.png)


## Sitemap（サイトマップ表示）

トップページのURLの後ろに「sitemap」と入力し、Enterキーを押すと表示されます。  
Locationのページのリンクをクリックすれば、またサイトに戻れます。

![](sitemap.png)


## Markdown Details

 マークダウンを介して折りたたみ可能なテキストブロックを生成できます。  
このプラグインは、アコーディオンを生成するためのものではなく、独立した折りたたみ可能なセクションのためのものです。

折りたたみ可能なセクションは、見出し（トリガー/サマリー）で始まります。 区切り文字!>後の括弧の内容は、タイトルを囲むタグを定義します。


```xml
<details class="details">
    <summary class="details__trigger">
        <h3 class="details__title">About Charles Darwin</h3>
        <svg class="indicator" aria-hidden="true" focusable="false" viewBox="0 0 10 10"><rect class="indicator__vert" height="8" width="2" y="1" x="4"></rect><rect height="2" width="8" y="4" x="1"></rect></svg>　<!--「+」のアイコン -->
    </summary>
    <!-- 詳細コンテンツ -->
    <div class="details__content textflow">
        <p>Charles Robert Darwin, FRS FRGS FLS FZS (/ˈdɑːrwɪn/; 12 February 1809 – 19 April 1882) was an English naturalist, geologist and biologist, best known for his contributions to the science of evolution. His proposition that all species of life have descended over time from common ancestors is now widely accepted, and considered a foundational concept in science.</p>
        <p>See his <a href="https://en.wikipedia.org/wiki/Charles_Darwin">Wikipedia page</a> for more information.</p>
    </div>
    <!-- 詳細コンテンツここまで -->
</details>
```


<details class="details">
    <summary class="details__trigger">
        <h3 class="details__title">About Charles Darwin</h3>
        <svg class="indicator" aria-hidden="true" focusable="false" viewBox="0 0 10 10"><rect class="indicator__vert" height="8" width="2" y="1" x="4"></rect><rect height="2" width="8" y="4" x="1"></rect></svg>
    </summary>
    <div class="details__content textflow">
        <p>Charles Robert Darwin, FRS FRGS FLS FZS (/ˈdɑːrwɪn/; 12 February 1809 – 19 April 1882) was an English naturalist, geologist and biologist, best known for his contributions to the science of evolution. His proposition that all species of life have descended over time from common ancestors is now widely accepted, and considered a foundational concept in science.</p>
        <p>See his <a href="https://en.wikipedia.org/wiki/Charles_Darwin">Wikipedia page</a> for more information.</p>
    </div>
</details>

### 初期設定

![](markdown-detail.png)
