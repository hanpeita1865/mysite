*[page-title]:第7章コントローラクラス

コントローラークラスを導入すると、今までコールバック関数内に記述していた処理をクラスとしてまとめることができるようになり、コールバック関数内の記述をシンプルにできます。併せて、自作クラスをSlimアプリケーションで利用する方法も紹介します。

## 7-1 コールバック関数の問題点とコントローラクラス

<div markdown="1" class="green-box">
* リクエスト処理をひとつのクラスにまとめたものを、コントローラークラスという。
* コントローラクラスの名前空間は、クラスを格納したフォルダ階層に名前空間ブレフィックスを付与する。
* コントローラクラスのルーティング登録は、第2引数としてコントローラクラス名とメソッド名を使う。
* Slimで自作クラスを利用する場合は、オートロードの設定が必要。
</div>

これまでの章で作成したサンプルでは、アプリにアクセスしてきたときの処理（これを<span class="green bold">リクエスト処理</span>といいます）をルーティングコールバック関数内に記述していました。その問題点の確認から行いましょう。

### コールバック関数は肥大化する

各リクエスト処理をルーティングコールバック関数に記述していくと、コードの見通しが悪くなるという問題が生じます。  
本運用で使われるアプリの場合、各リクエスト処理のコード量はサンプルの比ではなく、ルーティング登録ファイル内はさらにコードの見通しが悪くなり、メンテナンス性が極端に下がります。

これを解決するには、<span class="red">ルーティング登録のコードとリクエスト処理のコードを分離する</span>ことです。  
そこで、Slimでは、リクエスト処理をクラスとして記述し、それをルーティング登録する方法が用意されています。そのようなリクエスト処理が記述されたクラスのことを、<span class="green bold">コントローラクラス</span>といいます。

### サンプルプロジェクトの作成

<p class="tmp list"><span>リスト7-1</span>public/index.php</p>
```
<?php
use Slim\Factory\AppFactory;

require_once($_SERVER["DOCUMENT_ROOT"]."/slimcontroller/vendor/autoload.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/slimcontroller/containerSetups.php");
$app = AppFactory::create();
require_once($_SERVER["DOCUMENT_ROOT"]."/slimcontroller/routes.php");
$app->run();
```

<p class="tmp list"><span>リスト7-2</span>public/containerSetups.php</p>
```
<?php
use DI\Container;
use Slim\Factory\AppFactory;
use Slim\Views\Twig;

$container = new Container();
$container->set("view",
	function() {
		$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimcontroller/templates");
		return $twig;
	}
);
AppFactory::setContainer($container);
```

<p class="tmp list"><span>リスト7-3</span>routes.php</p>
```
<?php
$app->setBasePath("/slimcontroller/public");
```


### コントローラクラスの作り方
プロジェクトが作成できたところで、実際にコントローラクラスを作成していきましょう。  
コントローラクラスは、これまでのサンプルで利用してきたクラスと違い、自作クラスです。そのような自作クラスファイル類を格納するフォルダについて、Slimでの取り決め事項は特にありません。そこで、プロジェクトフォルダ直下にそういうクラス類をまとめて入れておくフォルダとしてclassesフォルダを用意し、そのフォルダ以下に役割ごとにサブフォルダを作ると管理が楽になります。

そこで、コントローラクラス類は、controllersフォルダに格納することにします。その中に次のリスト7-4のSeveralHelloControllerクラスを作成してください。

<p class="tmp list"><span>リスト7-4</span>classes/controllers/SeveralHelloController.php</p>
```
<?php
namespace SocymSlim\SlimController\controllers; //-----(3)

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;

class SeveralHelloController //----(1)
{
	public function showFirst(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface //----(2)
	{
		$content = "コントローラクラスのshowFirstメソッドでHello World!";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
}
```

* (1)クラス名は「〇〇Controller」を推奨
* (2)リクエスト処理ごとにメソッドを用意する
* (3)フォルダ構成に合わせて名前空間を用意する

それぞれ順に説明します。

* <span class="green">(1) クラス名は「〇〇Controller」を推奨</span>
: <span class="bold blue">(1)</span>が該当します。  
コントローラクラスのクラス名については、Slimでは特に指定はありません。ですので、自由に付けてもらってもかまいませんが、どのような処理を行うコントローラクラスなのかわかるようにしておいた方がいいでしょう。おすすめなのは、「〇〇Controller」のようなネーミングにすることです。

* <span class="green">(2) リクエスト処理ごとにメソッドを用意する</span>
: <span class="bold blue">(2)</span>が該当します。  
リクエスト処理ごとにメソッドを用意します。メソッド名は自由ですが、クラス名同様、どのようなリクエスト処理かわかるような名称にしましょう。  
引数と戻り値については、ルーティングコールバック関数と同じです。

* <span class="green">(3) フォルダ構成に合わせて、名前空間を用意する</span>
: <span class="bold blue">(3)</span>が該当します。  
名前空間は、classesフォルダ以降のフォルダ階層と同じ階層構造にし、その前に名前空間プレフィックスを付与します。リスト7-4では、実際のフォルダ構成であるcontrollersの前に、名前空間プレフィックスとしてSocymSlimControllerを付与しています。これについては、もう一度後で触れます。


#### COLUMN
PHPの名前空間に関しては、<span class="green bold">PSR-4</span>にその規約が記述されています。それによると、クラスの完全修飾名は次の書式となっています。
```
\<NamespaceName>\<SubNamespaceNames>\<ClassName>
```
最初の NamespaceName にあたる部分を<span class="green bold">トップレベル名前空間名</span>、あるいは、<span class="green bold">ベンダー名前空間名</span>といいます。


例）
```
\SocymSlim\SlimController\controllers\SeveralHelloController
```
これを分解すると、次のようになります。
* トップレベル名前空間名: SocymSlim
* サブ名前空間名: SlimController と controllers
* クラス名: SeveralHelloController


～時間ある時に記入～

### コントローラクラスのルーティング登録
次の２行のコードをroutes.phpに追記して下さい。

<p class="tmp list"><span>リスト7-5</span>routes.php</p>
```
<?php
use SocymSlim\SlimController\controllers\SeveralHelloController;//追記

$app->setBasePath("/slimcontroller/public");
$app->any("/several/showFirst", SeveralHelloController::class.":showFirst");//追記
```
<p class="tmp"><span>書式</span>コントローラクラスのルーティング登録</p>
```
$app->any(ルーティングパターン, コントローラクラス名::class.":メソッド名");
```

### オートロードの設定 ###{#7-1-5}

ここまで記述できたら実際に次のURLにアクセスしてみて下さい。
http://localhost:9810/slimcontroller/public/several/showFirst

ただ、このままではエラーが表示されます。エラーの文面にあるように、SeveralHelloControllerクラスが読み込まれていないことになります。これは、index.phpで読み込んでいるautoload.phpに問題があります。

各パッケージをインストールしただけの状態で自動生成されたautoload.phpでは、vendorフォルダ内にダウンロードされたクラスしか読み込まないような設定になっています。SeveralHelloControllerのように自作したクラスはこのautoload.phpの読み込み対象には含まれていません。

そこで、自作クラス類が格納されたclassesフォルダ内のクラスをautoload.phpの読み込み対象とするように変更します。  
これは、composer.jsonを変更し、Composerコマンドを実行することで行います。まず、composer.jsonに次のコードを追記してください。

<p class="tmp list"><span>リスト7-6</span>composer.json</p>
```
{
	"require": {
	～省略～
	},
	"autoload": {
		"psr-4": {
			"SocymSlim\\SlimController\\": "classes/"
		}
	}
}
```

上記の追記した部分が、classesフォルダ内に作成した自作クラスを読み込むためのオートロードの設定部分です。

<p class="tmp"><span>書式</span>composer.jsonへのオートロード設定</p>
```
	"autoload": {
		"psr-4": {
			"名前空間プレフィックス": "アプリ内で対応するフォルダ"
		}
	}
```

<p class="tmp cmd"><span>コマンド</span>autoload.phpを作り直すComposerコマンド</p>
```
composer dump-autoload
```
このコマンドをslimcontrollerフォルダで実行してください。その上で、再度次のURLにアクセスしてみて下さい。
http://localhost:9810/slimcontroller/public/several/showFirst

「コントローラクラスのshowFirstメソッドでHello World!」と表示されてると思います。

このように、リクエスト処理をコントローラクラスとして記述することで、ルーティング登録ファイルはすっきりし、メンテナンスしやすくなります。

### コントローラクラスには複数のメソッドを記述できる

リクエスト処理をコントローラクラスのメソッドとして記述できるということは、リクエスト処理ごとにメソッドを作成することで、複数のリクエスト処理をひとつのクラスにまとめることができます。

ここでは、SeveralHelloControllerクラスにもうひとつメソッドを追加して、それを表示させてみましょう。

<p class="tmp list"><span>リスト7-7</span>classes/controllers/SeveralHelloController.php</p>
```
<?php
～省略～
class SeveralHelloController
{
	～省略～
	public function showSecond(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
	{
		$content = "コントローラクラスのshowSecondメソッドでHello World!";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
}
```
次に、このメソッドをルーティング登録しましょう。リスト7-8をroutes.phpに追記して下さい。

<p class="tmp list"><span>リスト7-8</span>routes.php</p>
```
$app->any("/several/showSecond", SeveralHelloController::class.":showSecond");
```
追記したら、次のURLにアクセスして下さい。

http://localhost:9810/slimcontroller/public/several/showSecond

「コントローラクラスのshowSecondメソッドでHello World!」と表示されるはずです。

このように、コントローラクラスにメソッドを増やすことで、リクエスト処理をひとまとめにできます。  
となると、今度はコントローラクラス自体が肥大化していきます。そこで、何でもかんでもひとつのコントローラクラスにまとめるのではなく、例えば会員処理や受注管理といった機能ごとにひとつのコントローラクラスとし、各リクエスト処理をそのクラスのメソッドとして記述することで、よりメンテナンスしやすいアプリケーションとなります。

#### メモ_COLUMN

1処理１クラスのコントローラクラス

～時間ある時に記述～

## 7-2. コントローラクラスとコンテナの連携

ここまではコントローラクラスのメソッド内の処理というのは、単純に文字列を画面に表示させるものでした。では、次に、テンプレートを利用して画面を表示させる方法に展開していきましょう。

<div markdown="1" class="green-box">
* コントローラクラスでコンテナを扱う場合は、コンストラクタでコンテナインスタンスを受け取る。
* コンストラクタで受け取ったコンテナは、プロパティに格納して、クラス内で利用する。
</div>

### コントローラクラス内の <span class="red">$this</span> はコンテナではない

コールバック関数内で$thisを記述すると、それはコンテナインスタンスそのものを指しました。ですので、コールバック関数内でコンテナからインスタンスを取得しようとすれば、例えば、次のようなコードを記述すればすみました。
```
$this=$this->get("view");
```
ところが、コントローラクラスでは、この$thisは当然ですがコントローラクラスインスタンスを指すので、コンテナではありません。したがって、コンテナ内のインスタンスを取得するために先の記述はできません。

### コンストラクタの引数としてコンテナを受け取る

では、コントローラクラスでコンテナを扱いたい場合はどのようにすればいいのでしょうか。そこで登場するのがコンストラクタです。  
実際にコードを作成してみましょう。リスト7-9のConstructorControllerクラスを作成してください。

<p class="tmp list"><span>リスト7-9</span>classes/controllers/ConstructorController.php</p>
```
<?php
namespace SocymSlim\SlimController\controllers;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Container\ContainerInterface;

class ConstructorController
{
	private $container;

	public function __construct(ContainerInterface $container)
	{
		$this->container = $container;
	}
	
	public function helloWithContainer(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
	{
		$assign["name"] = "コントローラ";
		$twig = $this->container->get("view");
		$response = $twig->render($response, "helloWithVals.html", $assign);
		return $response;
	}
}
```

### コントローラクラスでのコンテナの扱い

<p class="tmp list"><span>リスト7-10</span>routes.php</p>
```
<?php
～省略～
use SocymSlim\SlimController\controllers\ConstructorController;

～省略～
$app->any("/constructor/helloWithContainer", ConstructorController::class.":helloWithContainer");
```

追記が終了したら、次のURLにアクセスして下さい。
http://localhost:9810/slimcontroller/public/constructor/helloWithContainer

以下の画面が表示されれば成功です。

![](upload/こんにちはコントローラさん.png)


