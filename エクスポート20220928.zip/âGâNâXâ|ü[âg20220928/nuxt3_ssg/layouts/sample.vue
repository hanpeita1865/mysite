<template>
    <div>
     <p>サンプルページです。</p>
      <slot />
    </div>
</template>