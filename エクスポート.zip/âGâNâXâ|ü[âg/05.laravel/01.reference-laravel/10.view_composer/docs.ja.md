---
title: '10. ビューコンポーザ'
media_order: 'view_composer01.png,view_composer02.png,view_composer03.png,view_composer04.png'
taxonomy:
    category:
        - docs
---

* [ビューコンポーザとは?](#p1)
* [サービスプロバイダについて](#p2)
* [HelloServiceProviderを作成する](#p3)
* [クロージャでコンポーザ処理を作る](#p4)
* [サービスプロバイダの登録](#p5)
* [ビューコンポーザを利用する](#p6)
* [ビューコンポーザクラスの作成](#p7)

ビューには、コントローラとは別にビジネスロジックを使って必要な情報などを処理し、ビューにデータを結合する「ビューコンポーザ」という機能があります。その基本について説明しましょう。

## ビューコンポーザとは? ##{#p1}
Laravelでは、ビューはテンプレートを利用して作成されます。Bladeでは、@PHPディレクティブを利用することでPHPのスクリプトを埋め込むことができました。これにより、ビュー独自に何らかの処理が必要な場合もテンプレート側で処理を行うことができます。  
ただし、テンプレートというものの役割を考えるなら、そこにビジネスロジックを含めるのは感心しません。といって、コントローラ側でビューのための処理を記述していくのも何か違う気がするかもしれません。「ビューにビジネスロジックをもたせたい場合は、どこに処理を置くべきなのか?」というのは、MVCアーキテクチャー登場の当初からある、非常に悩ましい問題です。  
Laravelでは、この問題を解決するための機能を提供します。それが「ビューコンポーザ」です。

### ビューのビジネスロジック
ビューコンポーザは、ビューをレンダリングする際に自動的に実行される処理を用意するための部品です。これは関数やクラスとして用意できます。ビューコンポーザを作成し、これをアプリケーションに登録することで、ビューをレンダリングする際に常に 処理を自動実行させることが可能になります。  
ビューコンポーザでは、ビューのオブジェクト(Viewクラス)が引数として渡され、それを利用することでテンプレート側に必要な情報などを渡すことができます。渡された値は、テンプレートで変数として利用することができます。

![](view_composer01.png?classes=caption "図　ビューコンポーザは、テンプレートがレンダリングされる際に呼び出され実行される。")

## サービスプロバイダについて ##{#p2}
ビューコンポーザを利用するためには、その前に「サービスプロバイダ」について理解 しておかなければいけません。  
サービスプロバイダは、その名の通り、サービスを提供するための仕組みです。これは、 以下のようなクラスとして定義されます。

<p class="tmp"><span>書式1</span>サービスプロバイダの基本形</p>
```
use Illuminate\Support\Facades\View; 
use Illuminate\Support\Service Provider;

class プロバイダクラス extends ServiceProvider
{
	public function boot()
    {
    	//コンポーザの設定
    }
}
```

サービスプロバイダは、ServiceProviderというクラスを継承して作成されます。これには、***boot***というメソッドを用意します。  
***bootメソッド***は、アプリケーションサービスへのブートストラップ処理（わかりやすくいうなら、アプリケーションが起動する際に割り込んで実行される処理）です。ここにコンポーザを設定する処理を用意することで、設定したビューをレンダリングする際、に自動的にコンポーザが呼び出されるようになります。  
継承元のServiceProviderクラスには他にも各種のメソッドが用意されていますが、とりあえずこのbootだけ覚えておけば、ビューコンポーザの利用はできるようになります。

## HelloServiceProviderを作成する ##{#p3}
では、実際にサービスプロバイダを作成してみましょう。これは、手作業でファイル を作成してもいいのですが、artisanを利用すればもっと簡単に作成できます。  
コマンドプロンプトまたはターミナルでアプリケーションフォルダにカレントディレクトリを移動し、以下のようにコマンドを実行して下さい。
<p class="tmp"><span>書式2</span>artisanコマンド</p>
```
php artisan make:provider HelloServiceProvider
```
![](view_composer02.png?classes=caption "図 artisan make:providerで、HelloServiceProviderを作る。")


##### コマンドプロンプト
```
C:¥Users\tuyano\Desktop\laravelapp>php artisan make:provider HelloServiceProvider, 
Provider created successfully.
C:\Users\tuyano\Desktop\laravelapp>
```
これで、「HelloServiceProvider」というサービスプロバイダが作成されます。artisan make:providerは、その後に記述した名前のサービスプロバイダを作成するコマンドです。

### HelloServiceProvider.phpをチェックする
では、作成されたサービスプロバイダを見てみましょう。これは、「**app**」内の「**Providers**」というフォルダの中に作成されます。この中から、「HelloServiceProvider. php」を開いて、その中に書かれているソースコードを確認してみて下さい(コメントは省略して掲載します)。

<p class="tmp list"><span>リスト1</span>HelloServiceProvider. php</p>
```
<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class HelloServiceProvider extends ServiceProvider
{
   public function boot()
   {
       //
   }

   public function register()
   {
       //
   }
}
```

これが、自動生成されたスクリプトです。SeviceProviderクラスを継承した HelloServiceProviderクラスが定義されているのがわかります。  
クラス内には、*boot*と*register*というメソッドが用意されています。bootは、既に説明したとおりですね。registerは、必要なサービスの登録を行うためのもので、今回は特に使いません。

## クロージャでコンポーザ処理を作る ##{#p4}
では、ビューコンポーザを用意しましょう。これには、2通りの方法があります。1つは、ビューコンポーザのクラスを定義し、それをbootで設定するというもの。もう1つは、 boot内に無名クラスでビューコンポーザの処理を組み込んでしまうというものです。  
まずは、簡単な「無名クラスを使った方法」からやってみましょう。今回は、簡単な値をビューに追加するサンプルを作ってみます。HelloServiceProvider.phpを以下のように書き換えて下さい。

<p class="tmp list"><span>リスト2</span>app/Providers/HelloServiceProvider.php</p>
```
<?php
namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class HelloServiceProvider extends ServiceProvider
{
   public function boot()
   {
       View::composer(
           'hello.index', function($view){
               $view->with('view_message', 'composer message!');
           }
       );
   }

}
```

ここでは、/helloのindexビュー(「views」内の「hello」フォルダ内にある「index.blade. php」テンプレートによるビュー)に「view_message」という値を設定する処理を作成して います。

### View::composer について
ここでは、***View::composer***というメソッドを実行しています。これがビューコンポーザを設定するためのものです。このメソッドは以下のように利用します。

<p class="tmp"><span>書式3</span></p>
```
View::composer( ビューの指定 , 関数またはクラス );
```

第1引数には、ビューコンポーザを割り当てるビューを指定します。第2引数には、実行する処理となるクロージャか、ビューコンポーザのクラスを指定します。ここでは、 以下のような関数を用意してあります。

```
function($view) {
	$view->with('view_message', 'composer message!');
}
```
引数には、*$view*が用意されていますが、これはIlluminate\Support\Facades名前空間にあるViewクラスのインスタンスです。これが、ビューを管理するオブジェクトになり ます。ここにあるメソッドなどを利用してビューを操作することができます。  
ここでは、「*with*」というメソッドを使っています。これはビューに変数などを追加するためのもので、以下のように利用します。

<p class="tmp"><span>書式4</span></p>
```
$view->with( 変数名 , 値 );
```
例題では、'view_message'という名前で、'composer message!"というテキストを値に設定しています。


## サービスプロバイダの登録 ##{#p5}
これでHelloServiceProviderは完成ですが、しかしこの状態ではまだ動きません。サー ビスプロバイダをアプリケーションに登録する必要があります。  
登録は、プロジェクトの「config」フォルダ内にある「app.php」に記述をします。このファイルを開くと、以下のような記述が見つかります。

```
'providers' => [
    ILLuminate\Auth\AuthServiceProvider::class, 
    Illuminate\Broadcasting\BroadcastServiceProvider::class,
    ......以下略......
],
```
この'providers'という名前に設定された配列が、アプリケーションに登録されている プロバイダの一覧です。ここにプロバイダクラスを追記すれば、アプリケーション起動時にそれが登録され、利用できるようになります。 では、'providers'の配列を閉じる **]** の直前辺りを改行し、以下の文を追記しましょう。

<p class="tmp list"><span>リスト3</span>config/app.php</p>
```
App\Providers\HelloServiceProvider::class
```

これで、HelloServiceProviderクラスがプロバイダとしてアプリケーションに登録され ます。

## ビューコンポーザを利用する ##{#p6}
では、実際にビューコンポーザを使ってみましょう。ここでは「hello」内の「index.blade.php」を修正します。 @section('content')の部分を以下のように修正して下さい。
<p class="tmp list"><span>リスト4</span>resources/views/hello/index.blade.php</p>
```
@section('content')
   <p>ここが本文のコンテンツです。</p>
   <p>Controller value<br>'message' = {{$message}}</p>
   <p>ViewComposer value<br>'view_message' = {{$view_message}}</p>
@endsection
```
ここでは、{{$message}}と{{$view_message}}の2つの変数を埋め込んでいます。 $view_messageは、先ほどビューコンポーザで値をビューに追加していましたね。後は、 コントローラ側のアクションで$messageを用意するだけです。  
では、HelloControllerクラスのindexアクションメソッドを以下のように修正しておきましょう。

<p class="tmp list"><span>リスト5</span>app/Http/Controllers/HelloController.php</p>
```
public function index()
{
   return view('hello.index', ['message'=>'Hello!']);
}
```

これで修正完了です。では、php artisan serveでサーバーを起動し、/helloにアクセス して表示を確認しましょう。   
messageとview_messageのいずれも正しく値が表示されます。コントローラとビューコンポーザのそれぞれで用意した変数がどちらもちゃんとテ ンプレートで受け取れたことが確認できます。

![](view_composer03.png?classes=caption "図　/helloにアクセスすると、messageとview_messageの値がそれぞれ表示される。")


## ビューコンポーザクラスの作成 ##{#p7}
ビューコンポーザの基本がわかったところで、より本格的な処理が作成できるように、独立したクラスとしてビューコンポーザを用意することにしましょう。  
ビューコンポーザのクラスは、特に配置する場所は用意されていません。アプリケー ションで利用できるスクリプトは、「Http」フォルダ内であればどこにおいても利用可能です。  
今回は、「**Http**」フォルダ内に、新たに「**Composers**」という名前でフォルダを作成しましょう。そしてこのフォルダの中に、「*HelloComposer.php*」という名前でスクリプトファ イルを用意することにします。 ファイルができたら、クラスのソースコードを以下のように記述しておきましょう。

<p class="tmp list"><span>リスト6</span>app/Http/Composers/HelloComposer.php</p>
```
<?php
namespace App\Http\Composers;

use Illuminate\View\View;

class HelloComposer
{
  
   public function compose(View $view)
   {
       $view->with('view_message', 'this view is "' 
            . $view->getName() . '"!!');
   }
}
```

ビューコンポーザクラスは、ごく一般的なPHPのクラスです。特に継承なども利用していません。  
コンポーザクラスで必要となるのは、「*compose*」メソッドです。これはViewインスタンスを引数として持っており、サービスプロバイダのbootからView::composerが実行 された際に呼び出されます。  
ここでは、*$view->getName()*というメソッドを使い、ビューの名前をview_message に設定しています。

### HelloService Provider OBTE
では、HelloComposerをビューコンポーザとして利用するように、 HelloServiceProviderを修正しましょう。bootメソッドを以下のように書き換えて下さい。
<p class="tmp list"><span>リスト7</span>app/Providers/HelloServiceProvider.php</p>
```
public function boot()
{
   View::composer(
       'hello.index', 'App\Http\Composers\HelloComposer'
   );
}
```
ビューコンポーザクラスを利用する場合は、View::composerメソッドの第2引数に、 呼び出すクラス名をテキスト値で指定します。  
修正したら、/helloにアクセスし、表示を確認しましょう。view_messageの値には「this view is "hello.index"!!」と表示されます。

![](view_composer04.png)

<http://localhost:9101/hello>

ビューコンポーザは、特定のビューを表示する際に必要となる処理を実行し、結果などの情報を組み込みます。ビューは、その情報を受け取り、表示するだけです。

ビューコンポーザによる処理は、コントローラーから見えません。コントローラーで処理をする必要があるものは、ビューコンポーザに用意すべきではありません。

コントローラで何らかの処理を行う必要がなく、「このビューでは常にこの処理をしてこの結果をビューに渡す」ということが決まっているような場合にビューコンポーザ は役立ちます。「その処理は、指定のビューで常に行うものか、それとも必要に応じて 呼び出すものか」をよく考えた上で、ビューコンポーザとして用意するか決めるようにしましょう。






