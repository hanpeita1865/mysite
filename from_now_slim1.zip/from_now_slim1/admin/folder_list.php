<?php
$folder_dir = glob('../pages/*', GLOB_ONLYDIR); 
$folder = str_replace('../pages/', '', $folder_dir);

