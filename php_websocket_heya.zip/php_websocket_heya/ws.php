<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sample2</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/style.min.css">
	<style>
		.c-name-list__item fieldset label {
			display: block;
			margin-bottom: .4rem;
		}

		section.c-section .c-name-list__item:first-of-type fieldset legend {
			font-size: 15px;
		}
        
        .c-result-list {
            display: flex;
        }
        .d-none {
            display: none;
        }
	</style>
</head>
<body>

<main class="p-main">
		<img src="images/page-title.png" alt="へやわけくん">
		<div>
			<section class="c-section">
				<h2 class="c-heading2">使い方</h2>
				<ol>
					<li>欠席者の名前にチェックを入れます。</li>
					<li>使用する会議室の数を選択します。</li>
					<li>「部屋分け実行」ボタンをクリックすると部屋分け完了です。「部屋分け結果」の欄に会議室別に名前が表示されます。結果はスクリーンショットで共有してください。</li>
					<li>結果が不満だったりメンバーや部屋数に変動が生じた場合は、条件を変更し「もう一度部屋分け」ボタンをクリックしてください。画面に表示されている条件で、再度部屋分けを行います。</li>
				</ol>
				<p>リセットをクリックすると入力した条件がすべて削除されますので注意してください。</p>
			</section>
			<section class="c-section">
				<h2 class="c-heading2">必要情報入力</h2>
				<p>欠席者にチェックを入れてください。</p>

				<div class="c-name-list">
                    <?php
                    require 'database_access.php';

                    $teams = $pdo->query('select * from team');

                    foreach($teams as $num):
                        $query_team = "SELECT id,name,absence FROM member WHERE team_id=".$num['team_id']; ?>
                        <div class="c-name-list__item">
                            <fieldset>
                                <legend><?= $num['team_name'] ?></legend>

                                <?php 
                                foreach($pdo->query($query_team) as $row): ?>
                                    <label for="check<?= $row['id'] ?>">
                                    <?php if($row['absence']=='true'): ?>
                                        <input type="checkbox" name="member" id="check<?= $row['id'] ?>" class="name" value="<?= $row['name'] ?>" checked><?= $row['name'] ?>
                                    <?php else: ?>
                                        <input type="checkbox" name="member" id="check<?= $row['id'] ?>" class="name" value="<?= $row['name'] ?>"><?= $row['name'] ?>
                                    <?php endif; ?>
                                    </label>
                                <?php endforeach ?>

                            </fieldset>
                        </div>
                    <?php endforeach ?>
				</div>

				</div>
				<div class="c-operate-area">
					<form>
						<label for="room-length">会議室数を選択してください</label>
						<select id="room-length">
							<option class=room value="1">1</option>
							<option class=room value="2">2</option>
							<option class=room value="3">3</option>
							<option class=room value="4">4</option>
							<option class=room value="5">5</option>
							<option class=room value="6">6</option>
							<option class=room value="7">7</option>
						</select>
					</form>
				</div>
					<div class="c-operate-area">
					<button class="c-button" type="button" id="js-start" aria-label="入力されている情報から部屋分けを実行">部屋分け実行</button>
					<button class="c-button" type="button" id="js-reset" aria-label="入力されている情報をすべて消去">リセット</button>
				</div>
			</section>
			<section class="c-section">
				<h2 class="c-heading2">部屋分け結果</h2>
				<p id="js-hide">ここに結果が表示されます。</p>
				<div id="js-result" class="c-result-list"></div>
			</section>
	</div>
</main>


    <div class="container">
        <div id="msg_log" class="msg-log"></div>
        <div class="input-area">
            <textarea id="msg" class="msg"></textarea>
            <button class="btn" onclick="send();">送信</button>
        </div>
    </div>
    <script type="text/javascript">

        let conn = "";

        //webSocketに接続
        function open() {
            conn = new WebSocket('ws://localhost:8283');

            conn.onopen = function (e) {
            };

            conn.onerror = function (e) {
                alert("エラーが発生しました");
            };

            //データを受信
            conn.onmessage = function (e) {
                let data = JSON.parse(e.data);//オブジェクトに変換
                let dataObj = JSON.parse(data.msg);

                switch(dataObj['type']){
                    case 'check':
                        document.getElementById(dataObj['id']).checked = dataObj['check'];
                    break;

                    case 'result':
                        document.getElementById('js-result').innerHTML= dataObj['html'];
                    break;
                }
            };

            conn.onclose = function () {
                alert("切断しました");
                setTimeout(open, 5000);
            };
        }

        //WebSocketにデータ送信テスト用
        function send() {
            conn.send('HELLO!!');
        }

        function close() {
            conn.close();
        }

        open();

        //欠席にチェックをいれる
        document.querySelectorAll('.name'),addEventListener('change',function(e){

            //チェックした人のオブジェクト取得
            let staffObj = {type: 'check', id: e.target.getAttribute('id'), name: e.target.value, check: e.target.checked};
            let staffStr = JSON.stringify(staffObj);//文字列に変換

            //WebSocketにデータ送信
            conn.send(staffStr);

            //データベースのmemberテーブルに登録
            const formData = new FormData;
            formData.append('id', e.target.getAttribute('id'));
            formData.append('name', e.target.value);
            formData.append('check', e.target.checked);

            fetch('update.php', {
                method: 'POST',
                body: formData,
            }, { cache: "no-store" })
                .then((response) => {
                    if (!response.ok) {
                        throw new Error();
                    }
                    return response.text();
                })
                .then(data => {
                    //通信成功時の処理
                    console.log('通信成功です。')
                })
                .catch((reason) => {
                    alert('失敗しました～。')
                });           
        });

    </script>
    <script src="js/script.js"></script>
</body>
</html>