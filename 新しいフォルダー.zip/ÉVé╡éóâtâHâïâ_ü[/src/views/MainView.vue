<template>
  <div>
    <h3>メインビュー</h3>
    <img src="../assets/wings.jpg" />
  </div>
</template>