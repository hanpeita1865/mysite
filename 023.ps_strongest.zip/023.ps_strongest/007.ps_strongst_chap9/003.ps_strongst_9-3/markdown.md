*[page-title]:9-3. 描いたパスやシェイプの編集

## パスコンポーネント選択ツールでパスやシェイプを移動・変形する。 ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-03-1.jpg)](upload/9-03-1.jpg){.image}
</div>

## ライブシェイプの変形 ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-03-2.jpg)](upload/9-03-2.jpg){.image}
</div>

## パスの曲がり具合を調整する ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-03-3.jpg)](upload/9-03-3.jpg){.image}
</div>

## アンカーポイントを追加・削除する ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-03-4.jpg)](upload/9-03-4.jpg){.image}
</div>

## アンカーポイントの位置を移動する ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-03-5.jpg)](upload/9-03-5.jpg){.image}
</div>

## アンカーポイントを切り替える ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-03-6.jpg)](upload/9-03-6.jpg){.image}
</div>

