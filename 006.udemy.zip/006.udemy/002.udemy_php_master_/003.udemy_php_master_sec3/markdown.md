*[page-title]:セクション3（配列と繰り返し）


## 26. 変数の「型」と型キャスト

```
<?php
$number1 = 10; // int型（整数型）
$number2 = '10';

if ($number1 === (int)$number2) {
    echo '同じです';
}
```

>$number1 = 10;（整数型）と$number2 = '10';（文字列型）で「===」を実行すると、型が違うので一致しません。  
>$number1 = 10;（整数型）と$number2 = 10;（浮動小数点型）で「===」を実行すると、数値ですがこれも型が違うので一致しません。  
>「==」を使うと不具合が発生してしまう場合があるので、できるだけ「===」を使う方がいいです。  
>$number1 = 10;（整数型）と (int)$number2 = 10;（浮動小数点型）のように(int)をつけるとint型になり「===」を実行すると、一致します。  
>PHPでは型について厳密ではないですが、型を意識してプログラミングしていくとよいです。

## 27. switch構文

参考サイト
: [switch](https://www.php.net/manual/ja/control-structures.switch.php)

```
<?php
echo '色を選んでください（1.黒, 2.白, 3.赤） >';
$color = (int)trim(fgets(STDIN));

// if ($color === 1) {
//     echo '黒が選ばれました';
// } elseif ($color === 2) {
//     echo '白が選ばれました';
// } elseif ($color === 3) {
//     echo '赤が選ばれました';
// }

switch ($color) {
    case 1:
        echo '黒が選ばれました';
    break;
    case 2:
        echo '白が選ばれました';
    break;
    case 3:
        echo '赤が選ばれました';
}
```

> キーボードから入力する値はすべて文字列型になります。そのため「$color === 1」のように書くと一致しません。  そのため「$color === '1'」にするか、「(int)trim(fgets(STDIN));」のように入力値をキャストすれば一致できます。  


> 複数の比較条件があるときは、if構文よりswitch構文を使用する方が、すっきりしたコードになります。
> break;はswitchの処理を終わるためのものですが、これをかかないと次の条件式も実行されてしまいます。  
> ただし上級的にテクニックでわざとbreak;を書かないやり方もあります。


## 28. 配列とは

```
<?php
// $black = '黒';
// $white = '白';
// $red = '赤';

// $color[] = '黒';
// $color[] = '白';
// $color[] = '赤';

// 配列を一気に指定する
$color = ['黒', '白', '赤'];
// $color = array('黒', '白', '赤'); // PHP 5以前の書き方

$number = 10;

$myfavorite = 2;
echo $color[$myfavorite];
```

> $color = array('黒', '白', '赤'); の書き方は、PHP 5以前の古い書き方になります。  


## 29. 配列の内容を手軽に確認しよう-print_r

参考サイト
: [print_r]https://www.php.net/manual/ja/function.print-r.php()

```
<?php
// $book[0][0] = 'デザイン入門';
// $book[0][1] = 'デザインの基礎';

// $book[1][0] = 'PHP入門';
// $book[1][1] = '高度なPHP開発';
// $book[1][2] = 'Laravel入門';

// $book[2][0] = 'JavaScript入門';

$book = [
    ['デザイン入門', 'デザインの基礎'],
    ['PHP入門', '高度なPHP開発']
];

//echo $book[1][0];

print_r($book);
```

<div markdown="1" class="note-box">
```
$book[0][0] = 'デザイン入門';
$book[0][1] = 'デザインの基礎';

$book[1][0] = 'PHP入門';
$book[1][1] = '高度なPHP開発';
```
多次元配列は上記のように書くこともできますが、以下のように書くこともできます。
```
$book = [
    ['デザイン入門', 'デザインの基礎'],
    ['PHP入門', '高度なPHP開発']
];
```
</div>


## 30.連想配列とは

```
<?php
// $pref['hokkaido'] = '北海道';
// $pref['aomori'] = '青森県';
// $pref['iwate'] = '岩手県';

// $pref = [
//     'hokkaido' => '北海道',
//     'aomori' => '青森県',
//     'iwate' => '岩手県'
// ];

$pref['hokkaido'] = [
    '赤平市',
    '旭川市',
    '芦別市'
];
$pref['aomori'] = [
    '青森市',
    '鰺ヶ沢町'
];

// >= 以上
// => 連想配列の代入

// $mypref = 'aomori';
// echo $pref[$mypref];

echo $pref['aomori'][1];
```

> 連想配列の代入記号「<span class="bold green">=></span>」は、 「<span class="bold red">>=</span>」の比較演算子と似てるので間違わないようにしましょう。


<div markdown="1" class="memo-box">
##### 変数名 prefについて
変数名 pref は、一般的に「都道府県」や「プレフィックス (接頭辞)」などの意味を表すために使用される変数名です。文脈によって意味が異なるため、使用する際には注意が必要です。

都道府県の場合:
: pref は、都道府県を表す変数名としてよく使われます。例えば、日本の都道府県を扱うプログラムで、ユーザーが選択した都道府県を保存する変数名として pref が使われることがあります。
: 例：pref = "広島県"

プレフィックス (接頭辞) の場合:
: pref は、文字列の接頭辞を表す変数名として使われることがあります。例えば、ファイル名やURLの接頭辞を扱うプログラムで、pref が使われることがあります。
: 例：pref = "https://"

その他:
: pref は、上記以外にも、プログラムの文脈によって様々な意味を持つ場合があります。  
変数名を使用する際には、その変数が何を表すのか、他の変数と区別がつくように、より具体的な名前を付けることが推奨されます。﻿
</div>



## 31.配列で使えるファンクション

参考サイト
: [配列 関数](https://www.php.net/manual/ja/ref.array.php)
: [implode](https://www.php.net/manual/ja/function.implode.php)
: [explode](https://www.php.net/manual/ja/function.explode.php)

```php
<?php
$color = ['黒', '白', '赤'];
// $max = count($color);

// array_unshift($color, '緑', '黄');

// print_r($color);

// Array
// (
//     [0] => 緑
//     [1] => 黄
//     [2] => 黒
//     [3] => 白
//     [4] => 赤
// )

//array_push($color, '緑', '黄');
// $color[] = '緑';
// $color[] = '黄';

// $array2[] = '赤';
// $result = array_merge($color, $array2);

// print_r($result);

// $mycolor = array_pop($color);
// echo $mycolor;
// $mycolor = array_pop($color);
// echo $mycolor;

$color_string = implode(',', $color);
$color_string .= ',緑,黄'; // 黒,白,赤,緑,黄
$newarray = explode(',', $color_string);

print($color_string);
print_r($newarray);
```

> 配列の前に追加する場合は「<span class="bold red">array_unshift()</span>」、後ろに追加する場合は「<span class="bold green">array_push()</span>」を使います。  
> また後ろに追加するのには、$color<span class="bold red">[]</span> = '緑';でもできます。ただ一気に追加したい場合は、array_push()を使うとよいです。  
> 注意してほしいのが、array_unshift()やarray_push()は元の配列の変数を直接加工します。  
> 加工したくない場合は、array_merge()を使うとよいです。

> array_shift()は配列の先頭の値を取り出します。実行した後、元の配列から先頭にあった値はなくなり、添え字は一つ前にずれます。  
> array_pop()は配列の最後の値を取り出します。同じく元の配列からはなくなります。




## 32.繰り返し処理を行おう-for構文

```
<?php
$color = ['黒', '白', '赤', '黄'];

// echo $color[0];
// echo "\n";

// echo $color[1];
// echo "\n";

// echo $color[2];
// echo "\n";

// for (初期値, 繰り返し条件, 更新処理)
for ($i=0; $i<count($color); $i++) {
    echo '・', $color[$i], "\n";
}
```

## 33. 配列を繰り返しで処理しよう

```
<?php
$pref = [
    'hokkaido' => '北海道',
    'aomori' => '青森県',
    'iwate' => '岩手県',
    'akita' => '秋田県'
];

foreach ($pref as $pref_key => $pref_name) {
    echo '・', $pref_key, ': ', $pref_name, "\n";
}
```


## 34. 回数の決まっていない繰り返し-while構文

```
<?php
$q1 = 5;
$q2 = 10;

echo $q1, '+', $q2, 'は？ >';
$answer = (int)trim(fgets(STDIN));

while ($answer !== $q1+$q2) {
    echo 'はずれ。もう一回 >';
    $answer = (int)trim(fgets(STDIN));
}

echo 'あたり！';
```

## 35. 3-10条件を後から判断する繰り返し-do while構文

```php
<?php
// $dice = rand(1, 6);

// while ($dice !== 1) {
//     echo $dice, "\n";
//     $dice = rand(1, 6);
// }
// echo $dice;

do {
    $dice = rand(1, 6);
    echo $dice, "\n";
} while ($dice !== 1);
```

> rand(1, 6) は、1から6の整数値をランダムに取得します。

## 36. 3-11 繰り返しを中断する-break, continue

```
<?php
$color = ['黒', '白', '', '赤'];

foreach ($color as $color_name) {
    if ($color_name === '') {
        //continue;
        break;
    }

    echo $color_name, "\n";
}
```

> continue; は、繰り返し構文の先頭に戻って、引き続き繰り返し処理をおこなわせるものです。例外が発生した時の処理に使われたりします。

> break; は、そこで繰り返しの処理を終わらせるものです。



## 37. [実践]合計と平均を求めるプログラム

参考サイト
: [do-while](https://www.php.net/manual/ja/control-structures.do.while.php)

```
<?php
$scores = []; // 点数を蓄積する配列

do {
    echo '点数を入力 >';
    $score = (int)trim(fgets(STDIN));
    if ($score === -1) {
        break;
    }
    
    array_push($scores, $score);
    
    $sum = 0; // 合計
    for ($i=0; $i<count($scores); $i++) {
        echo $i+1, '.', $scores[$i], "\n";

        $sum += $scores[$i];
    }

    echo '合計: ', $sum, "\n";

    // 平均を算出
    $avg = $sum / count($scores);
    echo '平均: ', $avg, "\n";
} while(true);
```