*[page-title]:3-3. 制御関連のディレクティブ

本節では、条件分岐やループなどの制御にかかわるディレクティブについて解説します。JavaScript の if および for 命令に相当する機能で、動的なテンプレートの組み立てには欠かせません。

### 3-3-1 式の真偽に応じて表示と非表示を切り替える - <span class="green">v-if</span>

v-if は、JavaScript の if 命令に相当するディレクティブです。指定された条件式が true の場合にだけ、現在の要素を出力します。
たとえば以下は、チェックボックスのオン/オフに対して、&lt;div id="panel"&gt; 要素の表示と非表示 を切り替える例です。

<p class="tmp list"><span>リスト3-41 / 3-42</span></p>
チェックを外すと、非表示になります。
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-41、3-42" src="https://codepen.io/hanpeita/embed/zYaOqoq?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/zYaOqoq">
  Vue3 リスト3-41、3-42</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/if.html

<span class="bold">表示（チェック有り）</span>
![](upload/if_true.png)
<span class="bold">非表示（チェック無し）</span>
![](upload/if_false.png)

v-if には true や false として評価できる式を指定します。この例では、データオブジェクトの show プロパティを渡しています。show プロパティはチェックボックスに紐付いているので、結果として、 チェックボックスのオン/オフに応じてパネルの表示と非表示も切り替わるというわけです。


### 式が false の場合の表示を定義する
条件式が true のときだけでなく、false のときにもなんらかのコンテンツを表示したい場合には、 v-else ディレクティブを利用します。  
たとえば以下は、リスト3-41 の if.html を修正して、チェックボックスをオフにした場合は「現在、 非表示状態です。」というメッセージを表示します。

<p class="tmp list"><span>リスト4-43</span></p>
if.htmlに追記
```
・・・
<div v-else>現在、非表示状態です。</div>
・・・
```
※v-else は、v-if (または後述する v-else-if)の直後に置かれていなければなりません。

http://localhost:7008/chap03/if_01.html

<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-41、3-43" src="https://codepen.io/hanpeita/embed/VwdZazy?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/VwdZazy">
  Vue3 リスト3-41、3-43</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>


### 複数の分岐を表現する

if ...else if に相当するディレクティブもあります。v-else-if ディレクティブです。v-else-if は v-if の直後に複数列記でき、いわゆる多岐分岐を表すために利用できます。

<p class="tmp list"><span>リスト3-44 / 3-45</span>セレクトボックスの値を変えるごとに、表示するテキストも変わっていきます。</p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-44、3-45" src="https://codepen.io/hanpeita/embed/ZEROBYO?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/ZEROBYO">
  Vue3 リスト3-44、3-45</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/if_else.html


## 3-3-2 式の真偽に応じて表示/非表示を切り替える - v-show


<span class="green bold">v-show ディレクティブ</span>は、与えられた条件式が true の場合にだけ、現在の要素を表示します。一見して、v-if と同じに見えますが、もちろん双方は異なるものです。  
まずは、v-if のサンプル(リスト 3-41 の if.html) を実行し、Chromeのデベロッパーツールの[要素]タブから文書ツリーの変化を確認してみましょう。

<p class="lang">表示 display: block</p>
![](upload/表示display_block.png)

<p class="lang">非表示 要素自体がない</p>
![](upload/非表示要素自体がない.png)

v-if の世界では、パネルが非表示になったとき、要素そのものが文書ツリーから破棄されていることが確認できます。逆に言えば、v-if は条件式が true になるまで要素を出力しません(遅延描画)。  
その性質上、v-if は頻繁に表示と非表示を切り替える場合に、描画コストが高まるおそれがあります。 そのような状況では、v-show を利用してください。

以下は、3-3-1 項の if.html を v-show で書き換えた例です。
```
<div id="panel" v-if="show">　→　<div id="panel" v-show="show">
```
<p class="lang"> v-show に書き換え</p>
![](upload/v-showに書き換え.png)

今度は要素そのものは常に文書ツリーに組み込まれた状態で、スタイルシート (display プロパティ) によってのみ表示と非表示が切り替わっていることが確認できます。 以上から、一般的には、以下の基準で v-show と v-if を使い分けてください。

* 表示と非表示を頻繁に切り替えるコンテンツには → <span class="green bold">v-show </span>
* 最初に表示(非表示)にしたら、めったに変更しないものは → <span class="blue bold">v-if</span>


## 3-3-3 配列やオブジェクトを繰り返し処理する　v-for

<span class="green bold">v-for ディレクティブ</span>は、指定された配列やオブジェクトから順に要素を取り出し、その内容をループ処理します。JavaScript の for 命令に相当します。 さまざまな構文があるので、具体的な例とともに用法を見ていきましょう。

### 配列から要素を順に取得する
たとえば以下は、あらかじめ用意された書籍情報(オブジェクト配列)から書籍リストを生成するサンプルです。

<p class="tmp list"><span>リスト3-47 / 3-48</span></p>
<iframe height="400" style="width: 100%;" scrolling="no" title="Vue3 リスト3-47、3-48" src="https://codepen.io/hanpeita/embed/abKZBLq?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/abKZBLq">
  Vue3 リスト3-47、3-48</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/for.html

<p class="result"><span>結果</span></p>
![](upload/for_書籍.png)

このリスト3-17の例では、配列 books (引数 list)から順に書籍オブジェクトを取り出し、仮変数 b (引数 item) に格納します。配下では、「b.isbn」のような形式で、オブジェクトのプロパティ値にアクセスできます。 v-for では、これを配列の中身がなくなるまで繰り返すわけです。

v-for ディレクティブの構文は、以下のとおりです。

<p class="tmp"><span>書式</span>v-for ディレクティブ</p>
```
<element v-for="item in list">...</element>
```
element :任意の要素   
item :仮変数   
list :任意の配列

![](upload/v-for_ディレクティブによる出力.png)

### インデックス番号を取得する
v-for の仮変数には、既定で配列要素がセットされます。しかし、仮変数を2個用意することで「配列要素, インデックス番号」の順にセットすることも可能です。先ほどのリスト 3-47 を書き換えて、 インデックス番号で No. を振ってみましょう。インデックス番号は0から始まるので、+1 している点にも注目です。

<p class="tmp list"><span>リスト3-49</span></p>
<iframe height="350" style="width: 100%;" scrolling="no" title="Vue3 リスト3-49" src="https://codepen.io/hanpeita/embed/WNyxPzQ?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/WNyxPzQ">
  Vue3 リスト3-49</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/for_index.html

<p class="result"><span>結果</span></p>
インデックス番号をもとにNoを振る
![](upload/インデックス番号をつける.png)


### オブジェクトのプロパティを順に処理する

v-for では、配列要素だけでなく、オブジェクトのプロパティを順に処理することもできます。以下は、オブジェクト book の内容を順にリスト表示する例です。

<p class="tmp list"><span>リスト3-50</span></p>
<p class="codepen" data-height="350" data-default-tab="html,result" data-slug-hash="vYrKbjv" data-user="hanpeita" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/hanpeita/pen/vYrKbjv">
  Vue3 リスト3-50</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>
http://localhost:7008/chap03/for_obj.html

<p class="result"><span>結果</span></p>
オブジェクトbookの内容を順に列挙
![](upload/オブジェクトbookの内容を順に列挙.png)

オブジェクトを扱う場合、仮変数は最大3個(先頭から順に「値、キー名、インデックス番号])受け取れます。この例では、先頭から順に value、key、i で表しています。ただし、キー名、インデックス番号は不要であれば、省略しても構いません。

<div markdown="1" class="note-box">
プロパティの列挙順 プロパティの列挙順は、Object.keys メソッドの戻り値に依存します。ただし、keys メソッド による列挙順序は、ブラウザーの実装によって変動する可能性があります。必ずしも定義順に 並ぶわけではないので、注意してください。
</div>

### Map の内容を順に処理する
Map (マップ)は ES2015 で追加された、いわゆる純正の連想配列です。オブジェクトにも似た構造ですが、v-for ディレクティブで処理する際には、仮引数の受け取り方が変化するので要注意です。

<p class="tmp list"><span>リスト3-52 / 3-53</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-52/3-53" src="https://codepen.io/hanpeita/embed/KKeMJYa?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/KKeMJYa">
  Vue3 リスト3-52/3-53</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/for_map.html

<p class="result"><span>結果</span></p>
![](upload/for_map結果.png)

オブジェクトの場合と異なるのは以下の点です。

* 受け取る仮引数は key (キー)、value(値)の2個 
* 引数の順序は key、value(オブジェクトの場合は value が先) 
* 仮引数を括るのは [...]

ちなみに、キー/値だけを列挙したいならば、以下のようにも表せます。
```
<li v-for="[key] in map">
{{key}} 
</li>
```
```
<li v-for="[, value] in map">
{{value}} 
</li>
```

いずれの場合も [...] は除去できないこと※1、value の場合は key を省略したことが判るように、カン マ(,)を付ける点に注目です。

※1 単に「v-for="key in map"」とした場合、仮変数 key には [ "PHP", "PHP: Hypertext Preprocessor" ]のような配列が渡されます。

### 数値を列挙したい場合
v-for では、配列やオブジェクトの代わりに、整数値を渡すこともできます。この場合、v-for は 1 ~指定値の間で値を変化させながら、ループを繰り返します(いわゆる JavaScript の一般的な for ルー プです)。

<p class="tmp list"><span>リスト3-54 / 3-55</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-54/3-55" src="https://codepen.io/hanpeita/embed/qBKNvWQ?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/qBKNvWQ">
  Vue3 リスト3-54/3-55</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/for_num.html

<p class="result"><span>結果</span></p>
![](upload/for_num結果.png)


## 3-3-4 v-for によるループ処理の注意点

以上が、v-for ディレクティブの基本的な用法です。ただし、v-for ディレクティブは、よく利用するディレクティブだけに、利用にあたっては注意点もあります。以下に、その主なものをまとめます。  

### 異なる要素のセットを繰り返し出力する - <span class="green">&lt;template&gt; 要素</span>

v-for は、それが指定された開始タグから終了タグまでをひとつの塊として、要素を繰り返し出力します。その性質上、複数の要素セットをそのまま v-for で出力することはできません。  
たとえば以下のコードであれば、&lt;header&gt; 要素だけが繰り返しの対象となり、&lt;div&gt; および &lt;footer&gt; 要素はループの外です。

```
<header v-for="a in articles">...</header> //— 繰り返しの対象となるのはここだけ
<div>...</div> 
<footer>...</footer>
```
もしも &lt;header&gt; に加え、&lt;div&gt; / &lt;footer&gt; 要素までをループの対象としたい場合、まずは以下のような方法があります。
```
<div v-for="a in articles">
<header>...</header> 
<div>...</div>
<footer>...</footer> 
</div>
```
ループの対象を便宜的な &lt;div&gt; 要素で束ねるわけです。ただし、v-for の都合で、本来のマークアッ プとしては無駄な &lt;div&gt; 要素を一段挟み込むのは望ましい状態ではありません。このような状況では、 &lt;template&gt; 要素を利用します。&lt;template&gt; は、その名のとおり、テンプレートを定義するための要素で、 それそのものは出力されません。複数の要素を束ねるためだけの役割を担います。

<p class="tmp list"><span>リスト3-56 /3-57</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-56/3-57" src="https://codepen.io/hanpeita/embed/gOKMEap?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/gOKMEap">
  Vue3 リスト3-56/3-57</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/for_multi.html

ループして、全データを表示しています。

<p class="result"><span>表示結果</span></p>
![](upload/for_multi結果.png)

![](upload/複数の要素セットを繰り返し出力する方法.png)


<div markdown="1" class="note-box">
&lt;template&gt; 要素は v-if でも利用できる

&lt;template&gt; 要素は、v-if で複数の要素を束ねる場合も同様に利用できます。

```
<template v-if="songs[0].title">
<header>{{ songs[0].title }}</header> 
<div>{{ songs[0].lyrics }}</div>
<footer>{{ songs[0].composer }} 作曲</footer> 
</template>
```
一番目のデータが表示されます。
<p class="result"><span>表示結果</span></p>
![](upload/一番目のデータが表示されます。.png)
ちなみに、v-for、v-if / v-else-if / v-else を伴わない &lt;template&gt; 要素は、ネイティブな HTML要素として扱われます(そのまま残ります)。
</div>

### 配列の絞り込みには算出プロパティを利用する

たとえば価格が2500円以上の書籍情報だけを列挙したい場合には、以下のようにします。

<p class="tmp list"><span>リスト3-58 /3-59</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-58/3-59" src="https://codepen.io/hanpeita/embed/gOKMELa?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/gOKMELa">
  Vue3 リスト3-58/3-59</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/for_filter.html

<p class="result"><span>表示結果</span></p>
* 2500円以上の書籍だけを表示しています。
![](upload/for_filter結果.png)

(1)の filter は JavaScript 標準のメソッドで、コールバック関数の条件に合致する(=戻り値が true である)要素だけを返します。算出プロパティ expensiveBooks は、filter メソッドの戻り値を返すことで、フィルター済みの配列を v-for に渡しています。

<div markdown="1" class="note-box">
##### ソートも同じように
配列をソートしたうえで列挙したい、という場合にも、同じように算出プロパティを利用でき ます。算出プロパティ経由で、ソート済みの配列を返すようにするわけです。 算出プロパティを利用できない状況では、メソッドを利用しても構いません。
</div>

リスト 3-58 の別解として、v-for / v-if を併用しても良いと思うかもしれません。たとえばリスト 3-58 -(2)は、以下のように表せそうな気がします。
```
<tr v-for="b in books" v-if="b.price >= 2500">...</tr>
```
しかし、このコードは「Cannot read properties of undefined (reading 'price')」(変数 b が undefined なので、price プロパティを読み取れない)のようなエラーで動作しません。というのも、 同じ要素に v-for と v-if を併記した場合、v-if ⇒ v-for の優先順で処理されるからです(v-for で生成される仮変数 b が、v-if を評価するタイミングではまだ生成されていません)。

この例であれば、まずは算出プロパティを利用するのがあるべきですが、条件を複数分岐するなどの理由で v-if を利用せざるを得ない場合には、&lt;template&gt; 要素で一階層挟むようにしてください。
```
<tr v-for="b in books">
<template v-if="b.price >= 2500">
・・・
</template> 
</tr>
```
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-58/3-59 ifも使う" src="https://codepen.io/hanpeita/embed/xxzOBrM?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/xxzOBrM">
  Vue3 リスト3-58/3-59 ifも使う</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
![](upload/for_filterとif.png)
ちなみに、v-if の条件式が v-for の仮変数を参照しないならば、v-if / v-for を同居させることは可能です。ただし、その場合も v-if / v-for の優先順位を考慮しなければならないという意味で、コー ドは読みづらくなります。まずは上の例のように、v-if を下位(上位)の要素に移動させることを検討してください。


## 3-3-5 配列の変更を反映する - 変更メソッド

Vue.js では、2.x、3.x系いずれを利用しているかによって、配列の操作方法が異なります。

### 2.x の場合（読みとばしていい）
まずは、2.x系での動作からです。配列の既存の要素を書き換えた場合、これを検出することはできません(配列への参照そのものは変化しないためです)。よって、以下のようなコードは正しく動作しません。

～省略～

<p class="tmp list"><span>リスト3-60 / 3-61</span></p>
![](upload/リスト3-61.png)
http://localhost:7008/chap03/for_change_v2.html

※setメソッドは、更新を Vue.js に通知してくれるので、正しく変更が画面にも反映されるはずです。
<!--
下記に書き換える
```
Vue.set(this.list, 1, '茶パジャマ');
```
-->
![](upload/for_change_v2_1.png)
↓ 変更をクリックすると、青パジャマが茶パジャマに変わる
![](upload/for_change_v2_2.png)

![](upload/変更系の配列メソッド.png)

### 3.x の場合
その点、3.x系では、配列の操作が賢く改良されており、<span class="red">Vue.set メソッドによる操作は不要</span>になっています。以下は、リスト3-61 を 3.x 対応に書き換えたものです。

<p class="tmp list"><span>リスト3-62</span></p>
<http://localhost:7008/chap03/for_change.html>
![](upload/リスト3-62.png)

<!--
リスト3-62
```
methods: {
  onclick() {
      this.list[1] = '茶パジャマ';
      //this.list.shift();      
  }
}
```
-->

ただし、バージョン3でも元の配列を変更しない(=処理結果の配列を戻り値として返す) たとえば、<span class="red">filter</span>、<span class="red">slice</span> のようなメソッドには要注意です*15。  
これらのメソッドを利用する場合には、以下のように戻り値を元のプロパティに書き戻すようにします。

```
× this.list.concat('茶パジャマ'); 
〇 this.list = this.list.concat(茶パジャマ');
```

*15 pop、splice などによる変更が正しく認識できる点は変わりありません。これら元々の配列に影響を与えるメソッドのことを<span class="red">破壊的メソッド</span>と呼びます。


### 3-3-6 配列要素の追加/削除を効率的に行う

先ほどのリスト3-62 の太字部分を以下のように修正したうえで、Chrome のデベロッパーツールの要素タブを開いた状態で実行してみましょう。
<p class="tmp list"><span>リスト3-63</span></p>
http://localhost:7008/chap03/for_change_3-63.html
![](upload/リスト6-63.png)
<!--リスト3-63
```
onclick() {
    this.list.shift();
}
```
-->
クリックするたびに、先頭行が削除されていきます。
![](upload/先頭行が削除される.png)

![](upload/すべての項目が再生成される.png "図　変更ボタンをクリックすると、全ての項目が再生成される")

&lt;ul&gt; および &lt;li&gt; 要素に注目すると、要素が削除されるだけでなく、すべての &lt;li&gt; 要素がピンクに 点灯する(=再生成された)ことが確認できるはずです。Vue.js からはどの項目が削除されたかは識別できないので、配列からリスト全体を生成しているわけです。これは、このサンプル程度のデータ量であれば問題ありませんが、より大きなリストでは無視できない<span class="green bold">オーバーヘッド</span>となります。

![](upload/配列を操作した時の挙動.png "図　配列を操作した時の挙動")

そこで登場するのが、予約属性である key です。key は、要素を識別するためのキー情報を Vue.js に 通知するための属性です。テンプレート(for_change.html)を修正してみましょう。

<p class="tmp list"><span>リスト3-64 for_change.html</span></p>
```
<ul>
	<li v-for="item in list" v-bind:key="item">{{ item }}</li> 
</ul>
```
http://localhost:7008/chap03/for_change_3-64.html

これで再生成されるオーバーヘッドはなくなりました。

key 属性には、要素を一意に識別できるならば任意の文字列や数値を渡せます*1。。ここでは、配列の 要素値をそのまま渡していますが、一般的には、データ個々を識別するための id 値を渡すことになるでしょう(要素値そのものは、必ずしも一意を保証できるとは限りません)。

*1 配列やオブジェクトのようなスカラー値は不可です。

<div markdown="1" class="note-box">
##### インデックス値は不可 
配列であれば、インデックス値が一意になるではないか、と思われるかもしれませんが、これは不可です。というのも、インデックス値は一意ですが、要素の追加や削除、ソートによって、 変化する可能性があるからです。
</div>

テンプレートを修正した状態で、デベロッパーツールの[要素] タブを開いたまま、サンプルを実行してみると、どうでしょう。今度は、該当の要素だけが削除され、他の要素は維持される(=他の &lt;li&gt;要素はピンク色に点灯しない)ことが確認できます。  
v-for ディレクティブを伴うリストで更新を行う場合には、必ずkey属性を指定するようにしてください。

