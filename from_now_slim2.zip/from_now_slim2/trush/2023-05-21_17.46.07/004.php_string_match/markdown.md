*[page-title]:特定の文字列を含むかのチェック（strpos、preg_match、in_array、array_search、array_keys、substr_count）

## 正規表現を使わない場合【strpos()】
strpos, strstr, preg_matchではstrposが最も早いのでstrposを使う。  
PHPマニュアルにもそのように書いてある。

<span class="green bold">strstr</span>
: もし特定の haystack に needle があるかどうかを調べるだけの場合、 より高速でメモリ消費も少ない strpos() を代わりに使用してください。

<span class="green bold">strpos</span>
: 該当する文字列が見つからなかった場合は、falseを返す。  
該当する文字列が見つかった位置を数値で返すので（※１）、型までチェックする必要がある。そのため、===falseもしくは!==falseを使うこと

※１ 例えば、strpos('abcd','ab')は、0を返す。

<p class="tmp"><span>書式1</span>strpos()</p>
```
$subject = 'abcd';

if(strpos($subject,'bc') !== false){
  //'abcd'のなかに'bc'が含まれている場合
}

if(strpos($subject,'bc') === false){
  //'abcd'のなかに'bc'が含まれていない場合
}
```

## 正規表現を使う場合【preg_match】

preg_matchはマッチした場合は1を返し、マッチしなかった場合は0を返します。    
preg_match関数は一つの実行結果のみを返します。

正規表現内に変数を付け足す場合、下記のようにします。

```
preg_match("/".$value."（img[0-9]*）/", $string) 
```


<p class="tmp"><span>書式2</span>preg_match()</p>
```
$subject = 'abcd';

if(preg_match('/bc/',$subject)){
  //$subjectのなかにbcが含まれている場合
}

if(!preg_match('/bc/',$subject)){
  //$subjectのなかにbcが含まれていない場合
}
```

<p class="exp"><span>例1</span></p>
* 先頭にあるか調べる場合は、「**^**」を文字の頭につける。例） /**^**ab/
* 最後尾にあるか調べる場合は、「**$**」を文字の最後につける。例） /cd**$**/

<iframe src="https://paiza.io/projects/e/_Abxy6A3D3cExlvFeITo-A?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


### 検索文字に変数を使った場合

JSのようにRegexpを使わなくても、そのまま正規表現の中に変数を記入すればよい。

<iframe src="https://paiza.io/projects/e/A1rnyvqIK-oSLzWFgDFlaA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


### 最初に検索にヒットした文字（単語）を取得

<iframe src="https://paiza.io/projects/e/kmLCH5mV6o7JDkrRB7mumg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

1行目は検索の対象となる文字列を用意し、2行目は変数$resの初期化を行います。

preg_match関数の第3パラメータとして、先ほど初期化した$resを渡します。  
この変数には、検索して一致した文字列が入ります。  
上記コード例では単純に「dog」という単語を検索しているため、検索対象からこの単語が見つかったら$resに格納し、最後のvar_dump関数で出力します。

preg_match関数は、文字列検索をして一番最初にヒットした時点で検索を終了します。  
つまり、該当する単語が2つ以上含まれている場合に、単語が何件含まれているかを調べることはできません。  
この件数を含めて取得したい場合は、preg_match_all関数を使います。


### switch文を使った例

<p class="exp"><span>例2</span></p>
trueの時は「**1**」が返ってくるので、**switch(1)** と記述する。
<iframe src="https://paiza.io/projects/e/O5obzMjC84x88Ga8eKP_cg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## 正規表現を使って、全て検索する【preg_match_all】

preg_match_all関数を利用することで繰り返し正規表現検索することができます。

<p class="tmp"><span>書式</span></p>
```
preg_match_all (正規表現パターン , 検索対象の文字列  [, 検索結果が代入される配列 [, 動作フラグ [,検索開始位置]])
```
※ []内は省略可です。  
※ 動作フラグに「PREG_PATTERN_ORDER」を指定することでパターン全体、サブマッチパターン、パターン単位に結果がまとめられます。

<iframe src="https://paiza.io/projects/e/dL_WRvsd2FekHd7hSvGD2w?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

上記は$stringを先頭から「0-9の数値3桁」と「0-9の数値4桁」の正規表現パターンにマッチしているかどうかを繰り返しチェックするサンプルプログラムとなっています。


<p class="result"><span>結果</span></p>
```
Array (
	[0] => Array ( [0] => 192-0043 [1] => 162-2235 ) 
    [1] => Array ( [0] => 192 [1] => 162 ) [2] => Array ( [0] => 0043 [1] => 2235 ) 
)
```

PREG_SET_ORDERを指定することで、$dataにはマッチした文字列から順に格納されていきます。

結果は以下の通りです。

<p class="result"><span>結果</span>（PREG_SET_ORDER指定）</p>
```
Array ( 
	[0] => Array ( [0] => 192-0043 [1] => 192 [2] => 0043 ) 
    [1] => Array ( [0] => 162-2235 [1] => 162 [2] => 2235 ) 
)
```

<iframe src="https://paiza.io/projects/e/lFGC-qSxV2bVUn2xCLs1HA?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>

文字列から（img～）を抽出して、配列に格納しています。

<p class="result"><span>結果</span></p>
```
Array ( 
	[0] => Array ( 
    	[0] => （img9） 
    	[1] => （img7） 
    	[2] => （img10） 
    	[3] => （img2） 
    	[4] => （img4） 
    ) 
)

（img9）（img7）（img10）（img2）（img4）
```

### 一つ一つ検索にヒットした文字（単語）を取得　【preg_match_all関数】

<iframe src="https://paiza.io/projects/e/n5ARFZozhvho64uFqEa4Mg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>



## 配列に指定した値が存在するかチェックする方法 

### in_array関数
PHPのin_array関数は、配列の中に指定した値が存在するかチェックする関数です。

<p class="tmp"><span>書式</span>in_array()</p>
```
in_array ($検索する値 , $配列 [,?$strict = FALSE ] )
```
第三引数はオプションでboolean型のtrueを渡すことで、検索する値の型まで厳密にチェックできます。(strict = 厳密)  
デフォルトでは、boolean型のfalseが設定されてるため、第三引数にtrueを渡さなければ型までチェックしない検索を行います

<p class="exp"><span>例3</span></p>
<iframe src="https://paiza.io/projects/e/eUONR95SgMYZ7b8OvEEUMw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

### isset関数

参考サイト
: [PHP | 配列・連想配列のキー名が存在するか確認する方法](https://1-notes.com/php-existence-check-for-variables-and-arrays/)

<span class="green bold">連想配列のキー名が存在するか確認します。  </span>
連想配列の場合も同様にisset()でキー名の存在をチェックする事ができる関数です。
```
$data = array('apple' => '100', 'banana' => '200', 'pine' => '300');

if (isset($data['banana'])) {
	// ある場合
} else {
	// ない場合
}
```
確認してから処理を実行する事で「Undefined array key ～」エラーや「Undefined variable ～」などのエラーを回避します。

### 名前を行で分けて、セレクトボックス生成

<p class="exp"><span>例4</span></p>
<p>配列の文字列をあ行、か行...と分けて、セレクトボックスを作成する。<br>
行に名前がない場合、その行は表示しないようになっています。</p>
<iframe src="https://paiza.io/projects/e/bI7DZsBGWEpOpixuu9iIrg?theme=twilight" width="100%" height="800" scrolling="no" seamless="seamless"></iframe>

以前作成したコード（不完全）
https://paiza.io/projects/e/VF35TaD26an-4OrEniuUVQ?theme=twilight

<p class="exp"><span>例5</span></p>
<p>役職のセレクトボックスを作成する</p>
<iframe src="https://paiza.io/projects/e/gix3IVNmr2UsSJopHY0s6Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

### array_search

配列の値を検索するのに使われる基本的な関数array_searchは、検索した要素がある場合、in_arrayと違って<span class="red bold">要素番号</span>を返してくれます。（最初の値のインデックスキーのみを返します。）

<p class="tmp"><span>書式</span>array_search</p>
```
array_search(検索する値, 検索対象の配列, 型の比較を行うか)
```

第一引数には、検索したい要素(値)を指定します。第二引数ではどの配列から検索したいか、検索する配列名を指定します。第三引数にtrueを指定すると型の比較も行います。省略可能。

検索する値が見つかった場合は値のインデックスキー(要素番号)を、その他の場合はfalseを返します。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	$array配列のPythonのインデックス番号の「2」を返しています。
	</div>
<iframe src="https://paiza.io/projects/e/mPX-Lcd0umpDHkP9t_kLeA?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

※検索する値が文字列の場合、大文字小文字は区別して比較が行われます。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	検索文字を「python」にすると、falseを返します。
	</div>
<iframe src="https://paiza.io/projects/e/zokDu3GwdIxSI0gcXBUa7A?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

第三引数を指定しない場合、型の比較は行いません。  
今回は検索する要素の型も見るためvar_dumpで出力していますが、結果がfalseなので真偽値型のboolが出力されています。  
要素の型の比較まで行う場合には、第三引数にtrueを指定します。

### array_keys関数

検索する値が配列に複数ある場合でも、array_search関数は最初の値のインデックスキーのみを返しました。  
全てのインデックスキーを取得したい場合は、array_keys関数を使います。

<p class="tmp"><span>書式</span>array_keys関数</p>
```
array_keys(検索対象の配列, 検索する値)
```
第一引数に検索する配列の配列名を指定します。第二引数に検索する値を指定します。省略可能。

array_search関数やin_array関数と引数の順番が違う点に注意してください。array_search関数は検索して見つかった全てのインデックスキーを配列にして返してくれます。

第二引数を省略した場合は配列すべてのインデックスキーが返されます。






## 文字列内の指定した文字の個数【substr_count関数】 

<p class="tmp"><span>書式</span>substr_count()</p>
指定した文字列の出現回数を返します。
```
substr_count( 検索対象の文字列, 検索する文字列 )
```
または
```
substr_count ( 検索対象の文字列, 検索する文字列  [, 検索する開始位置 [,開始位置から検索する文字列の長さ ]] )
```
※ []内は省略可

<iframe src="https://paiza.io/projects/e/FnbyIO92GVn0YIHUxnrKKQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

「文字列」というワードの出現回数をカウントしました。3回出現するので、int型の「3」が返されます。

## 参考サイト

* [【in_array】PHPで配列に指定した値が存在するかチェックする方法を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/32999)
* [都道府県selectメニューコードジェネレータ](https://webtools.dounokouno.com/prefecture/index.html)
* [PHP の正規表現](https://www.webdesignleaves.com/pr/php/php_basic_03.php)
* [正規表現で文字を検索する：preg_match関数](https://gray-code.com/php/search-of-strings/)
* [正規表現の検索結果からヒットした文字列やヒット件数を取得](https://gray-code.com/php/search-of-strings2/)
* [[必見!] PHP preg_match_all関数とは? 分かりやすく解説します!](https://www.web-knowledge-info.com/wp/php43/)
* [指定した文字列の出現回数をカウント - substr_count()](https://webkaru.net/php/function-substr-count/)
* [【PHP入門】配列の値を検索するarray_searchと他4つの関数](https://www.sejuku.net/blog/22098)