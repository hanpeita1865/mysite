---
title: 02.リスト
taxonomy:
    category:
        - docs
visible: true
---

リストは、データ構造の一つです。データ構造とは、文字列や整数などのデータをまとめて扱う仕組みです。<br>
リストには、データを要素として登録することができます。要素は0個でも、1個でも、複数でも構いません。
また、要素の型はバラバラでも大丈夫です。

<p class="tmp"><span>書式1</span>リストの初期化</p>
<pre>
[値]
</pre>

<p class="tmp"><span>書式2</span>空のリスト</p>
<pre>
[]
</pre>

<p class="tmp"><span>書式3</span>リストの初期化（複数個）<br>
複数の値を登録するには、値を「,」（カンマ）で区切ります。</p>
<pre>
[値,値,・・]
</pre>

<p class="inpre"><span>インタプリタ</span>文字列をリストに登録</p>
<pre>
>>> todo = ['プレゼント', '昼食', '会議', 'メール対応']
>>> todo
['プレゼント', '昼食', '会議', 'メール対応']
</pre>

<iframe src="https://paiza.io/projects/e/mMz66rGJMN2MLmHwn6wmXw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式4</span>リストからの要素の取り出し</p>
<pre>
リスト[インデックス]
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> todo = ['プレゼント', '昼食', '会議', 'メール対応']
>>> todo[1]
'昼食'
>>> todo[2]
'会議'
>>> todo[-1]
'メール対応'
</pre>

<iframe src="https://paiza.io/projects/e/D733VBtBupCyJF9V12l-TQ?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式5</span>リストの連結</p>
<pre>
リストA + リストB
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> todo = ['プレゼント', '昼食', '会議', 'メール対応']
>>> todo + ['営業']
['プレゼント', '昼食', '会議', 'メール対応', '営業']
</pre>

<iframe src="https://paiza.io/projects/e/8mePSNxbrAvi1nDeimTnQQ?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式6</span>複合代入演算子を使ったリストの連結</p>
<pre>
リストA += リストB
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> todo2 = ['外出']
>>> todo += todo2
>>> todo
['プレゼント', '昼食', '会議', 'メール対応', '<span class="red">外出</span>']
</pre>

<iframe src="https://paiza.io/projects/e/hFJurPgKUAUJAOfpzO2qUw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

作成済みのリストに要素を追加するには、<span class="bold red">appendメソッド</span>を使います。


<p class="tmp"><span>書式7</span>要素の追加</p>
<pre>
リスト.append(要素)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> todo.append('定時退社')
>>> todo
['プレゼント', '昼食', '会議', 'メール対応', '外出', '<span class="red">定時退社</span>']
</pre>

<iframe src="https://paiza.io/projects/e/ggFFpAxMkCv7rR_xTg25_Q?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式8</span>リストの取り出し（スライス）</p>
<pre>
リスト[開始インデックス:終了インデックス]
※開始インデックス要素から、終了インデックス-1に対応する要素までを取り出します。
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> event = ['正月', '節分', '卒業', '新人歓迎会', '連休', '梅雨', '七夕', '花火', '月見', 'ハロウィン', '収穫祭', '忘年会']
>>> event[6:9]
['七夕', '花火', '月見']
</pre>

<iframe src="https://paiza.io/projects/e/3oR4TpZcvzwTZMVPX0zs9g?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

※文字のスライスと同じように、開始インデックスと終了インデックスを省略できます。

<p class="tmp"><span>書式9</span>要素の変更</p>
<pre>
リスト[インデックス] = 値
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> event[7] = 'お盆'<span class="comment">  # '花火'を'お盆'に変更</span>
>>> event
['正月', '節分', '卒業', '新人歓迎会', '連休', '梅雨', '七夕', '<span class="red">お盆</span>', '月見', 'ハロウィン', '収穫祭', '忘年会']
</pre>

<iframe src="https://paiza.io/projects/e/KwhHnUXsEgVFJmKxJy_ntQ?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

リストの途中に要素を挿入するには、<span class="bold red">insertメソッド</span>を使います。インデックスが示す位置に指定した要素を挿入します。

<p class="tmp"><span>書式10</span>要素の挿入</p>
<pre>
リスト.insert(インデックス,要素)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> event.insert(2,'バレンタイン')<span class="comment">  # '節分'と'卒業'の間に'バレンタイン'を挿入</span>
>>> event
['正月', '節分', '<span class="red">バレンタイン</span>', '卒業', '新人歓迎会', '連休', '梅雨', '七夕', 'お盆', '月見', 'ハロウィン', '収穫祭', '忘年会']
</pre>

<iframe src="https://paiza.io/projects/e/JhySD1IgHSXCiD8eHf-Vyg?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

リストの要素を削除するには、<span class="bold red">removeメソッド</span>を使います。

<p class="tmp"><span>書式11</span>要素の削除</p>
<pre>
リスト.remove(値)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> event.remove('節分')<span class="comment">  # '節分'をリストから削除</span>
>>> event
['正月', 'バレンタイン', '卒業', '新人歓迎会', '連休', '梅雨', '七夕', 'お盆', '月見', 'ハロウィン', '収穫祭', '忘年会']
</pre>

<iframe src="https://paiza.io/projects/e/_H1wuCI0F4UElBH5sp6LRQ?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

リストの要素を数えるには、文字列の文字数を数えるのと同じく<span class="bold red">len関数</span>を使います。

<p class="tmp"><span>書式12</span>要素の個数を数える</p>
<pre>
len(リスト)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> len(event)
12<span class="comment">  # 要素の個数</span>
</pre>

<iframe src="https://paiza.io/projects/e/sSi7RmSGNuaIxEVoTWDc5w?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

リストの要素を並べた文字列を作るには、<span class="bold red">joinメソッド</span>を使います。

<p class="tmp"><span>書式13</span>リストの要素を並べた文字列を作る</p>
<pre>
文字列.join(リスト)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> '→'.join(event)
'正月→バレンタイン→卒業→新人歓迎会→連休→梅雨→七夕→お盆→月見→ハロウィン→収穫祭→忘年会'
</pre>

<iframe src="https://paiza.io/projects/e/IOvpbgY6p7dUH2cOOgm_1A?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

文字列を分割してリストにするには、<span class="bold red">splitメソッド</span>を使います。

<p class="tmp"><span>書式14</span>文字列を分割して、リストを作成</p>
<pre>
文字列.split(区切りの文字)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> s = '→'.join(event)
>>> s
'正月→バレンタイン→卒業→新人歓迎会→連休→梅雨→七夕→お盆→月見→ハロウィン→収穫祭→忘年会'
>>> s.split('→')
['正月', 'バレンタイン', '卒業', '新人歓迎会', '連休', '梅雨', '七夕', 'お盆', '月見', 'ハロウィン', '収穫祭', '忘年会']
</pre>

<iframe src="https://paiza.io/projects/e/Ypl3XdkCuWzuACUEvXEXrw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>




