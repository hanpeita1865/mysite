---
title: 11.発展的な機能
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    .t-caption {
    	font-size: 1.5rem;
        text-align: center;
        font-weight: bold;
        margin-bottom: .5rem;
    }
    .t-caption + table {margin-top: .5rem;}
    #FirebugUI {top: 100px;}
    pre {
        margin-top: 0.5rem;
    }
    section {margin-bottom: 4rem;}
    .mt-05 {margin-top:0.5rem;}
    .mb-05 {margin-bottom:0.5rem;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: blue;}
    .black {color: black}
    .smp-box {
         margin: 2rem 0 3rem;
    }
    .text-nowrap {white-space: nowrap;}
   dl dt {
     font-weight: bold;   
    }
    .gray-box {
     	border: 1px solid gray;
        padding: 20px 30px;
        display: inline-block;
    }
    .w-400 {
      	width: 400px;
     }
    .comment {
        font-style: italic;
        color: green;
        font-size: 1rem;
        font-weight: normal;
    }
    .hljs-comment {
        font-style: italic;
        color: green;
        font-size: 1rem;
        font-weight: normal;        
    }
    h4 {margin-top: 3rem;}
    .indent-01 {
		padding-left: 1rem;
    	text-indent: -1rem;
    }
    .outline-box {
    	border: 1px solid #aaa;
        padding: 0.2rem 0.5rem;
        font-size: 0.8rem;
        font-weight: normal;
        background: #ddd;
    }
    .list-title {
    	font-weight: bold;
        margin-bottom: 0.5rem;
    }
    .list-title + ul {
    	margin-top: 0.5rem;
    }
    .pre-title {
    	font-weight: bold;
        margin-bottom: 0.5rem;
    }
    .pre-title + pre {
    	margin-top: 0.5rem;
    }
    .result {
    	font-weight: bold;
        color: blue;
        margin-bottom: 0;        
    }
    .result + pre {
    	margin-top: 0.2rem;        
    }
</style>

<h2 class="h-type2">デコレータ</h2>

デコレータは、関数やメソッドを加工する機能です。Pythonが提供するデコレーターを適用することで、関数やメソッドに色々な機能を追加することができます。

<p class="tmp"><span>書式1</span>デコレータの適用</p>

	@デコレータ名

<p class="t-caption">主要なデコレータ一覧</p>

|デコレータ名|機能            |
|:--------|:----------|
| @abc.abstractmethod    | 抽象メソッド       |
| @abc.abstractproperty    | 抽象プロパティ   |
| @asyncio.coroutine  | ジェネレータベースのコルーチン  |
| @atexit.register       | 終了時に実行する関数     |
| @classmethod   | クラスメソッド       |
| @contextlib.contextmanager | with文コンテキストマネージャ用のファクトリ関数 |
| @functools.lru cache | 戻り値のキャッシュ（一時保存） |
| @functools.singledispatch | ジェネリック関数 |
| @functools.total ordering | 拡張順序比較メソッドの定義 |
| @functools.wraps | ラッパー関数の定義 |
| @property | プロパティ |
| @staticmethod  | 静的メソッド |
| @types.coroutine | ジェネレータからコルーチンへの変換 |
| @unittest.mock.patch | オブジェクトに対するパッチ（修正）と復元 |
| @unittest.mock.patch.dict | 辞書に対するパッチと復元 |
| @unittest.mock.patch.multiple | 単一呼び出しに対する複数のパッチ |
| @unittest.mock.patch.object | オブジェクト属性のパッチ |


※デコレータは自分で定義することもできます。

<p class="tmp"><span>書式2</span>関数の前後に処理を追加するデコレータの定義</p>

    import functools
    def デコレータ名(f):
        @functools.wraps(f)
        def wrapper(*x, **y):
            前処理
            f(*x, **y)
            後処理
    return wrapper

<p class="indent-01">※このデコレータを適用した関数を呼び出すと、最初に前処理を行い、次に関数を実行し、最後に後処理を行います。
つまり関数に対して、前処理と後処理を追加することができます。<br>
デコレータを定義するためには、プログラムの先頭に「import functools」という記述が必要です。<br>
importはモジュールをインポートするための構文です。インポートというのは、モジュールを取り込んで使えるように
する操作のことです。<br>
上記ではデコレータの定義に関するfunctoolsモジュールをインポートします。</p>


<div class="box-example">
    <h3 class="h-example">例1</h3>
	デコレータ名decoを適用すると、関数の実行前に「BEGIN」と表示し、実行後に「END」と表示します
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    import functools

    def deco(f):　　　　　　　　# デコレータ名(deco)
        @functools.wraps(f)
        def wrapper(*x, **y):
            print('BEGIN!')    # 前処理(BEGIN!と表示する)
            f(*x, **y)         # 関数の呼び出し
            print('END!')　　　# 後処理(END!と表示する)
        return wrapper


	@deco						# デコレータの適用
    def hello():　　　　　　　 # hello関数の定義
        print('hello')


    hello()　　　　　　　　　 # hello関数の呼び出し

<p class="result">実行結果</p>

    BEGIN!　　　　　　　　　　# デコレータによる前処理
    hello 　　　　　　　　　　# hello関数の処理
    END! 　　　　　　　　　　 # デコレータによる後処理




<h2 class="h-type2">静的メソッド</h2>

メソッドはインスタンスを使って呼び出しますが、<span class="red bold">静的メソッド</span>は、インスタンスを使わないで呼び出すことができます。<br>
クラスに関する情報を参照したり設定したりする用途に向いています。

<p class="tmp"><span>書式3</span>静的メソッドの定義</p>

    class クラス名:
        @staticmethod
        def メソッド名(引数, …):
            処理

※staticは静的という意味です。通常のメソッドでは最初の引数がselfですが、静的メソッドでは引数selfは使いません。

<p class="tmp"><span>書式4</span>静的メソッドの呼び出し</p>

	クラス名.メソッド名(引数, …)

<div class="box-example">
    <h3 class="h-example">例2</h3>
	Playerクラスに、静的メソッドのprint_limitを定義します
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        LEVEL_LIMIT = 10　　　　　　　# クラス属性

        @staticmethod　　　　　　　　 # 静的メソッドの定義
        def print_limit():
            print(Player.LEVEL_LIMIT)　# クラス属性のLEVEL_LIMITを表示


    Player.print_limit()　　　　　　　 # Playerクラスのprint_limitを呼び出す

<p class="result">実行結果</p>

	10　　　　　　　　　　　　　　　　 # LEVEL_LIMITの値が表示される


<h2 class="h-type2">クラスメソッド</h2>

<span class="red bold">クラスメソッド</span>は、静的メソッドと同様にインスタンスを使わないで呼び出すことができます。<br>
用途も静的メソッドと同様で、クラスに関する情報を参照したり設定したりするような使い方に向いています。<br>
<span class="red bold">@classmethod</span>はPythonが提供するデコレータの一種で、指定したメソッドをクラスメソッドにします。<br>

<p class="tmp"><span>書式5</span>クラスメソッドの定義</p>

    class クラス名:
        @classmethod
        def メソッド名(cls, 引数, …):
            処理

<p class="indent-01">※クラスメソッドの最初の引数は、clsにすることが推奨されています。この引数clsには、クラスメソッドを呼び出したときに使ったクラスが入ります。clsを使ってクラス属性などを操作することができます。</p>

<p class="tmp"><span>書式6</span>クラスメソッドの呼び出し</p>

	クラス名.メソッド名(引数, …)


<div class="box-example">
    <h3 class="h-example">例3</h3>
	Playerクラスに、クラスメソッドのprint_limitを定義します
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        LEVEL_LIMIT = 10            # クラス属性

        @classmethod　　　　　　　　# クラスメソッドの定義
        def print_limit(cls):
            print(cls.LEVEL_LIMIT)　#クラス属性のLEVEL_lIMITを表示


    Player.print_limit()　　　　　  //クラスメソッドの呼び出し（静的メソッドと同じ）

<p class="result">実行結果</p>

	10

<h3 class="h-type3">静的メソッドとクラス名メソッドの使い分けは? </h3>

継承を行ったときに、静的メソッドの場合、どのクラスに対して呼び出されたのかを知る方法はありませんが、クラスメソッドの場合、引数clsを使えば、どのクラスに対して呼び出されたのか知ることができます。

<p class="t-caption">各種メソッドの使い分け</p>

| メソッドの種類 | 機能と用途 |
|:------|:------|
| メソッド	| 引数selfでインスタンスを特定できるので、特定のインスタンスに対する処理を定義するために使います。		|
| クラスメソッド		| インスタンスは特定できませんが、引数clsでクラスを特定できるので、特定のクラスに対する処理を定義するために使います。		|
| 静的メソッド		| インスタンスもクラスも特定できませんが、あるクラスに関連する処理を、そのクラスの中に整理して定義したいときに役立ちます。　		|

　
<h2 class="h-type2">プロパティ</h2>

<span class="red bold">プロパティ</span>は、データ属性の参照や設定に関する機能です。データ属性の参照や設定を行う際に、指定した処理を実行することができます。<br>
プロパティを利用すると、例えばデータ属性を設定する際に値をチェックすることによって不適切な値が設定されないように防止する、といったことができます。

<div class="box-example">
    <h3 class="h-example">例4</h3>
	プレイヤーを表すPlayerクラスです。クラス属性のLEVEL_LIMITがレベルの上限値（10）を表しています。このPlayerクラスを使って、インスタンスを生成し、データ属性のlevelに100を設定します。最後にlevelの値を表示します。
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        LEVEL_LIMIT = 10     # クラス属性


    p = Player()　　　　　　 # インスタンスの生成
    p.level = 100　　　　　　# データ属性のlevelに100を設定
    print(p.level)　　　　　 # levelを表示

<p class="result">実行結果</p>

	100

<p class="tmp"><span>書式7</span>プロパティの定義</p>

    class クラス名
        @property
        def プロパティ名(self):
            処理A

        @プロパティ名.setter
        def プロパティ名(self, 変数):
            処理B

<p class="indent-01">※<span class="red bold">@property</span>はプロパティを作成するためのデコレータで、<span class="red bold">@プロパティ名.setter</span>はプロパティ値を設定するためのメソッドを定義するためのデコレータです。一般に、処理Aにはプロパティ値を返す処理を書き、処理Bにはプロパティの値保存する処理を書きます。</p>

<p class="tmp"><span>書式8</span>読み出し専用プロパティの定義</p>

    class クラス名:
        @property
        def プロパティ名(self):
            処理A


<div class="box-example">
    <h3 class="h-example">例5</h3>
	Playerクラスにレベルを表すlevelプロパティを定義してみます。レベルの値を保存するためにデータ属性__levelを使いました。__levelはクラスの外側からは直接操作しないことを想定しています。変数名の先頭に「__」（アンダーバー2個）がついているので、マングリングが行われます。
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        LEVEL_LIMIT = 10                   # クラス属性

        @property　　　　　　　　　　　　　# プロパティの定義
        def level(self):
            return self.__level　　　　　　# データ属性__levelの値を返す

        @level.setter　　　　　　　　　　　# セッターの定義
        def level(self, value):
            if value > Player.LEVEL_LIMIT:　# レベルが上限値を超えていたら
                value = Player.LEVEL_LIMIT　# レベルを上限値に補正する
            self.__level = value　　　　　　# データ属性__levelにレベルを保存する


    p = Player()
    p.level = 100
    print(p.level)

<p class="result">実行結果</p>

	10　　　　# レベルが100から上限値の10に設定される



<h2 class="h-type2">インスタンスの判定</h2>

isinstance関数を使うと、あるインスタンスが指定したクラスのインスタンスかどうかを調べることができます。<br>
指定したクラスのインスタンスならTrue、そうでなければFalseを返します。

<p class="tmp"><span>書式9</span>isinstance関数</p>

	isinstance(変数, クラス名)



<div class="box-example">
    <h3 class="h-example">例6</h3>
	Playerクラスのインスタンスを作成し、これがPlayerクラスのインスタンスかどうか調べます
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:                 # Playerクラスの定義
        pass

    p = Player()　　　　　　　　　# Playerのインスタンスを生成
    print(isinstance(p, Player))　# Playerクラスのインスタンスか?

<p class="result">実行結果</p>

	True



<div class="box-example">
    <h3 class="h-example">例7</h3>
	Fighterクラスのインスタンスを作成し、これがPlayer、Fighter、Wizardクラスのインスタンスかどうか調べます
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        pass


    class Fighter(Player):
        pass


    class Wizard(Player):
        pass


    f = Fighter()
    print(isinstance(f, Player))
    print(isinstance(f, Fighter))
    print(isinstance(f, Wizard))

<p class="result">実行結果</p>

    True   # Playerクラスのインスタンスである（Fighterの基底クラスがPlayerなのでTrueになる）
    True   # Fighterクラスのインスタンスである
    False  # Wizardクラスのインスタンスではない

<p class="indent-01">※継承を使う場合、派生クラスは基底クラスが持つすべての機能を引き継ぎます。そのため、派生クラスのインスタンスは、基底クラスのインスタンスとしても動作します。したがって、isinstance関数を使って、派生クラスのインスタンスが基底クラスのインスタンスかどうか調べると、結果はTrueになります。</p>

多重継承を使う場合についても、同様にisinstance関数を使って、あるインスタンスが指定したクラスのインスタンスかどうか調べることができます。


<div class="box-example">
    <h3 class="h-example">例8</h3>
    多重継承を使った場合のisinstance関数の結果<br>
	MagicKnightクラスのインスタンスを作成し、これがPlayer、Fighter、Wizard、MagicKnightクラスのインスタンスかどうか調べます
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        pass


    class Fighter(Player):
        pass


    class Wizard(Player):
        pass


    class MagicKnight(Fighter, Wizard):
        pass


    mk = MagicKnight()
    print(isinstance(mk, Player))
    print(isinstance(mk, Fighter))
    print(isinstance(mk, Wizard))
    print(isinstance(mk, MagicKnight))

<p class="result">実行結果</p>
    True
    True
    True
    True


<h2 class="h-type2">抽象クラス</h2>

インスタンスを作れないクラスのことです。抽象クラスを基底クラスにしたうえで継承と組み合わせると、便利に使える場面があります。

<div class="box-example">
    <h3 class="h-example">例9</h3>
	
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:　　　　　　# Playerクラスの定義
        def battle(self):
            print('...')


    class Fighter(Player):　 # Fighterクラスの定義
        def battle(self):
            print('slash')


    class Wizard(Player):　 # Wizardクラスの定義
        def battle(self):
            print('magic')


    for p in [Player(), Fighter(), Wizard()]:　　# 作成したインスタンスをリストに格納し、for文を使って順番にbattleメソッドを呼び出します。
        p.battle()

<p class="result">実行結果</p>

	...
    slash
    magic



※Playerクラスを抽象基底クラスにすることによって、Playeクラスのインスタンスの作成を禁止します。

<p class="tmp"><span>書式10</span>抽象基底クラスの定義</p>

    import abc
    class クラス名(abc,ABC):
        @abc.abstracmethod
        def メソッド名(self, 引数, …):
            pass

<p class="indent-01">※抽象基底クラスを使うためには、プログラムの先頭に「<span class="red bold">import abc</span>」という記述が必要です。ここでは抽象基底クラスの機能を提供するabcというモジュールをインポートしています。abcというのはabstract base classesの略で、Pythonが提供するモジュールの1つです。<br>
@abc.abstracmethodは、指定したメソッドを抽象メソッドにするためのデコレータです。</p>

<p class="list-title">抽象基底クラスと抽象メソッドは、次のように使います。</p>

1. 抽象基底クラスを定義し、抽象メソッドを定義する
1. 抽象基底クラスの派生クラスを定義し、抽象メソッドをオーバーライドする
1. 抽象基底クラスのインスタンスは生成することができる
1. 派生クラスのインスタンスは生成することができる

<div class="box-example">
    <h3 class="h-example">例10</h3>
	Playerクラスから、FighterクラスとWizardクラスを派生させます
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    import abc


    class Player(abc.ABC):
        @abc.abstractmethod
        def battle(self):
            pass


    class Fighter(Player):
        def battle(self):
            print('slash')


    class Wizard(Player):
        def battle(self):
            print('magic')


    for p in [Fighter(), Wizard()]:
        p.battle()

<p class="result">実行結果</p>

    slash
    magic



<div class="box-example">
    <h3 class="h-example">例11</h3>
	抽象基底クラスであるPlayerクラスについて、インスタンスが作れないことを確認してみましょう。
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    import abc

    class Player(abc.ABC):
        @abc.abstractmethod
        def battle(self):
            pass


    class Fighter(Player):
        def battle(self):
            print('slash')


    class Wizard(Player):
        def battle(self):
            print('magic')


    for p in [Player(), Fighter(), Wizard()]:
        p.battle()

<p class="result">実行結果⇒エラーが表示される</p>

    Traceback (most recent call last):
      File "C:\abstract3.py", line 20, in <module>
        for p in [Player(), Fighter(), Wizard()]:
    TypeError: Can't instantiate abstract class Player with abstract methods battle


<p class="indent-01">※狙い通り、「インスタンス化することができません」と表示されます。Playerのインスタンス生成を禁止することができました。</p>



<h3 class="h-type3">抽象基底クラスから派生するクラス</h3>

抽象基底クラスから派生するクラスについて、インスタンスを生成するためには、抽象メソッドをオーバーライドして、具体的な処理を記述する必要があります。もし<span class="red bold">抽象メソッドをオーバーライドしないと、派生クラスのインスタンスも生成できなくなります。</span>

<div class="box-example">
    <h3 class="h-example">例12</h3>
	Fighterクラスからbattleメソッドの定義を取り除いてみます。
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    import abc

    class Player(abc.ABC):
        @abc.abstractmethod
        def battle(self):
            pass


    class Fighter(Player):
        pass


    class Wizard(Player):
        def battle(self):
            print('magic')


    for p in [Fighter(), Wizard()]:
        p.battle()

<p class="result">実行結果</p>

    Traceback (most recent call last):
      File "C:\abstract4.py", line 19, in <module>
        for p in [Fighter(), Wizard()]:
    TypeError: Can't instantiate abstract class Fighter with abstract methods battle



Fighterのインスタンスを生成している部分でエラーが出ています。エラーメッセージの意味は、「抽象メソッドbattleを持つ抽象クラスFighterを　インスタンス化することができません」です。

　このように抽象基底クラスと抽象メソッドを利用することで、次の事柄が実現できます。

1. インスタンスを生成しないクラスを定義することができる
2. 派生クラスにメソッドのオーバーライドを義務付けることができる。


<h2 class="h-type2">演算子のオーバーライド</h2>

「+」や「*」といった演算子を、プログラマが独自に定義するための機能です。<br>
プログラマが定義したクラスに対して演算子を割り当てることによって、そのクラスを使った演算を簡潔に記述できるようになります。

<div class="box-example">
    <h3 class="h-example">例13</h3>
	Colorクラスは、色の情報をRGBで表現するためのクラスです。<br>
	2つのインスタンスを生成し、変数c1とc2に代入してから、printメソッドを呼び出して内容を表示します。
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Color:                         # Colorクラスの定義
        def __init__(self, r, g, b):     # init__メソッドの定義
            self.r = r
            self.g = g
            self.b = b

        def print(self):　　　　　　　　 # printメソッドの定義
            print(self.r, self.g, self.b)


    c1 = Color(10, 20, 30)　　　　　　　 # インスタンスの生成
    c1.print()　　　　　　　　　　　　　 # RGB値を表示

    c2 = Color(40, 50, 60)　　　　　　　 # インスタンスの生成
    c2.print()　　　　　　　　　　　　　 # RGB値を表示

<p class="result">実行結果</p>

        10 20 30
        40 50 60



<div class="box-example">
    <h3 class="h-example">例14</h3>
	
</div>
<p class="editpre"><span>テキストエディタ</span>普通の数値を加算するようなプログラムを書いてみます。</p>

    c3 = c1 + c2
    c3.print()

<p class="result">実行結果</p>

    c3 = c1 + c2
	TypeError: unsupported operand type(s) for +: 'Color' and 'Color'

<p class="indent-01">※「c3 = c1 + c2」の部分でエラーが出ます。ColorとColorに対して+演算子を適用することはできないという意味です。
そこで、演算子のオーバーロードを行い、Colorクラスに対する+演算子を定義します。</p>

<p class="tmp"><span>書式11</span>+演算子のオーバーロード</p>

    class クラス名:
        def __add__(self, other)
            処理



<table>
	<caption>演算子に対応するメソッドの例</caption>
	<thead>
		<tr>
			<th>演算子</th>
			<th>メソッド</th>
			<th>内容</th>				
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>+</td>
			<td>__add__</td>
			<td>加算</td>				
		</tr>
		<tr>
			<td>-</td>
			<td>__sub__</td>
			<td>減算</td>				
		</tr>
		<tr>
			<td>*</td>
			<td>__mul__</td>
			<td>乗算</td>				
		</tr>
		<tr>
			<td>/</td>
			<td>__tuediv__</td>
			<td>除算</td>				
		</tr>
		<tr>
			<td>//</td>
			<td>__floodiv__</td>
			<td>除算(結果の小数点以下は切り捨て)</td>				
		</tr>
		<tr>
			<td>%</td>
			<td>__mod__</td>
			<td>剰余算</td>				
		</tr>
		<tr>
			<td>**</td>
			<td>__pow__</td>
			<td>べき乗</td>				
		</tr>
	</tbody>
</table>



<div class="box-example">
    <h3 class="h-example">例15</h3>
	Colorクラスについて__add__メソッドを定義すると次のようになります。
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Color:
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b

        def print(self):
            print(self.r, self.g, self.b)

        def __add__(self, other):　　　# add__メソッドの定義
            r = self.r + other.r
            g = self.g + other.g
            b = self.b + other.b
            return Color(r, g, b)　　　# 結果のインスタンスを生成して返す


    c1 = Color(10, 20, 30)
    c1.print()

    c2 = Color(40, 50, 60)
    c2.print()

    c3 = c1 + c2　　　　　　　　　　　# +演算子を使用(__addメソッドを呼び出す)
    c3.print()

<p class="result">実行結果</p>
　　　　　　　
	10 20 30　　　　　　　　　　　　　
	40 50 60　　　　　　　　　　　　　
	50 70 90　　　　　　　　　# RGB値をそれぞれ加算した値

c1の「10 20 30」とcs「40 50 60」について、RGB値をそれぞれ加算した「50 70 90」が計算できていることがわかります。<br>
このように演算子のオーバーロードを活用すると、独自に定義したクラスに対して、Pythonに元々ある数値や文字列などと同じ感覚で、演算ができるようになります。


<h2 class="h-type2">__str__メソッド</h2>

<p><span class="red bold">__str__メソッド</span>を定義すると、print関数やformat関数にインスタンスを渡して、出力できるようになります。</p>


<p class="tmp"><span>書式12</span>__str__メソッドの定義</p>

    class クラス名
        def __sr__(self):
            処理


<div class="box-example">
    <h3 class="h-example">例16</h3>
	__str__メソッドを定義します。この__str__メソッドは、RGB値を「R G B」のように、空白で区切って結合した文字列を返します。
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Color:
        def __init__(self, r, g, b):　　# __init__メソッドの定義(以前と同じ)
            self.r = r
            self.g = g
            self.b = b

        def __add__(self, other):　　# __add__メソッドの定義(以前と同じ)
            r = self.r + other.r
            g = self.g + other.g
            b = self.b + other.b
            return Color(r, g, b)

        def __str__(self):          # __str__メソッドの定義
            return str(self.r) + ' ' + str(self.g) + ' ' + str(self.b)　# 空白で区切って結合した文字列を返します


    c1 = Color(10, 20, 30)
    print(c1)

    c2 = Color(40, 50, 60)
    print(c2)

    c3 = c1 + c2
    print(c3)

<p class="result">実行結果</p>

	10 20 30
	40 50 60
	50 70 90

上記の例は、print関数が使えるようになったことが違いです。print関数を使うことによって、通常の数値や文字列と同じ方法でインスタンスを出力できます。


<h2 class="h-type2">ダックタイピング</h2>

<span class="red bold">ダックタイピング</span>とは、「あるインスタンスが、必要なメソッドやデータ属性を備えていれば、実際にはどのクラスのインスタンスであるかは問わない」という考え方です。<br>
Pythonはダックタイピングの立場をとっています。あるインスタンスに対して、ある処理を行うときには、その処理に必要な機能をインスタンスが備えていれば、どのクラスのインスタンスかは問わないという動作です

<div class="box-example">
    <h3 class="h-example">例17</h3>
	引数x,y,zの合計を求めるsum関数です
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Color:
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b

        def __add__(self, other):
            r = self.r + other.r
            g = self.g + other.g
            b = self.b + other.b
            return Color(r, g, b)

        def __str__(self):
            return str(self.r) + ' ' + str(self.g) + ' ' + str(self.b)


    def sum(x, y, z):
        return x + y + z


    n = sum(1, 2, 3)
    print(n)

    s = sum('Hello', 'Python', 'World')
    print(s)

    c = sum(Color(10, 20, 30), Color(40, 50, 60), Color(70, 80, 90))
    print(c)

<p class="result">実行結果</p>

	6　　　　　　　　　　　　　# 数値に対する結果
    HelloPythonWorld　　　　　 # 文字列に対する
    120 150 180　　　　　　　　# Colorのインスタンスに対する結果

<h4>ここまでのまとめ</h4>
<table>
	<thead>
		<tr>
			<th>解説項目</th>
			<th>概要</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="text-nowrap">オブジェクト指向プログラミング</td>
			<td class="text-left">関連が深いデータと操作をまとめて、オブジェクトという部品にすることにより、プログラムの構造を整理する手法です。クラス、インスタンス、メソッド、データ属性、クラス属性、継承、オーバーライドなどについて解説しました</td>
		</tr>
		<tr>
			<td class="text-nowrap">例外処理</td>
			<td class="text-left">例外はプログラムの実行中に起きるエラーです。例外処理を記述することで、エラーが起きてもプログラムの実行を継続することができます。</td>
		</tr>
		<tr>
			<td class="text-nowrap">発展的な機能</td>
			<td class="text-left">デコレータ、静的メソッド、クラスメソッド、プロパティ、インスタンスの判定、抽象クラス、演算子のオーバーロード、__str__メソッド、ダックタイピングなど、少し発展的な機能を解説ました。</td>
		</tr>
	</tbody>
</table>







