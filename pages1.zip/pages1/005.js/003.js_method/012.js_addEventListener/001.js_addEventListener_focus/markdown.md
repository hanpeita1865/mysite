*[page-title]:フォーカスのイベント

参考サイト
: [mdn_web Element: focus イベント](https://developer.mozilla.org/ja/docs/Web/API/Element/focus_event)

## イベント委譲
このイベントのイベント委譲を実装する方法は二つあります。 focusin イベントを使用するか、 addEventListener() の useCapture 引数に true を設定するかです。

<p class="lang">HTML</p>
```
<form id="form">
  <input type="text" placeholder="text input">
  <input type="password" placeholder="password">
</form>
```

<p class="lang">JS</p>
```
const form = document.getElementById('form');

form.addEventListener('focus', (event) => {
  event.target.style.background = 'pink';
}, true);

form.addEventListener('blur', (event) => {
  event.target.style.background = '';
}, true);
```