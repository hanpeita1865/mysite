import { Api } from '../api.js';
import { Dom } from '../dom.js';
import { getAdminData } from '../adminData.js';


export async function renameFolder({ newName, oldName, menuId, menuObj }) {
    
    const dirName = menuObj[oldName];
    const dirReName = dirName.replace(oldName, newName);

    const fd = new FormData();
    fd.append('post_dir', dirName);
    fd.append('post_redir', dirReName);
    fd.append('post_folderName', oldName);
    fd.append('post_folderReName', newName);
    fd.append('eventName', 'フォルダ名変更');

    const { adminFull } = getAdminData();

    const data = await Api.postJSON(adminFull + 'folder_rename', fd);    
    
    if (!data.success) {
        throw new Error(data.message);
    }

    // DOM更新
    Dom.updateFolderName(menuId, newName);
    Dom.updateHref(menuId, newName);

    return 'フォルダ名を変更しました。';
}