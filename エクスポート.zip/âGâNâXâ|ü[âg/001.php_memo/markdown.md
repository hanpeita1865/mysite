*[page-title]:PHP（よく利用するもの）


## 改行

参考サイト
: [コピペだけで試せる! PHPの改行方法「PHP_EOL」の使い方](https://it-kyujin.jp/article/detail/1528/)
: [PHP で改行コードを変換・削除する方法](https://webgroove.work/php-convert-remove-newline/)

```
<?php
      echo 'ABCD';
      echo PHP_EOL;
      echo 'EFGH';
?>
```

<p class="result"><span>結果</span></p>
```
ABCD
EFGH
```
「ABCD」の後に改行が付きます。

<span class="bold">改行コードは、下記のように OS に環境依存します。</span>

* \r : Mac OS 9 以前
* \n : Linux, macOS 以降
* \r\n : Windows

改行コードを削除する場合は、下記のように str_replace で空文字列に変換するだけで実現できます。
```
function removeNewline(string $str): string {
  return str_replace(["\r\n", "\r", "\n"], '', $str);
}
```

## 変数の型を調べる

参考サイト
: [変数の型を調べる（確認） - gettype()](https://webkaru.net/php/function-gettype/)
<p class="tmp"><span>書式</span></p>
```
gettype( 変数 )
```
## list関数について

PHPでは、配列の値を複数の変数に1つずつ代入できるlist関数があります。

参考サイト
: [【PHP入門】list関数の基本から応用までわかりやすく解説！](https://www.sejuku.net/blog/24406)


## PHPを使ってHTMLに変換して出力

<div class="exp">
<p class="tmp"><span>例</span>DBS</p>
次のファイルに接続し、<kbd>HTML出力</kbd>をクリックすると、「db_diagram.php」のHTMLファイルを「affairs/propersheet.html」に出力します。
<a href="http://localhost:7001/dbs/trunk/dbs_legacy/_database/db_diagram.php" target="_blank">http://localhost:7001/dbs/trunk/dbs_legacy/_database/db_diagram.php</a><br>

<a href="http://localhost:7001/dbs/trunk/dbs_legacy/_database/html_output/" target="_blank">http://localhost:7001/dbs/trunk/dbs_legacy/_database/html_output/</a><br>

<a href="http://localhost:7001/dbs/trunk/dbs_legacy/affairs/propersheet.html" target="_blank">http://localhost:7001/dbs/trunk/dbs_legacy/affairs/propersheet.html</a>
</div>


<p class="lang">output_file.php</p>
```
<?php
$url = (empty($_SERVER['HTTPS']) ? 'http://' : 'https://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$urlArray = explode('?', $url);
$urlReplace = str_replace('html_output/output_file.php', 'db_diagram.php', $urlArray[0]);
$html = file_get_contents($urlReplace);
file_put_contents( '../../affairs/propersheet.html', $html )
?>
```


<p class="lang">html_output/index.html</p>
```
<button class="btn-output">HTML出力</button>

<p>HTMLに出力します。</p>

<script>
    function codeOutput() {
		$.ajax({
			url: 'output_file.php',
			type: 'GET',
			dataType: 'html',
			cache: false
		}).done(function(data){
			alert('HTMLを出力しました。')
			
		}).fail(function(){
			alert('HTMLの出力に失敗しました。')
		});
    }

    $('.btn-output').on('click',function(){
		if(window.confirm('出力しますか？')){
				codeOutput();
			return true;

		} else {
			return false;
		}  
        
    });	
</script>
```


## 数字の桁数を指定する

### sprintfを使う
参考サイト
: [phpマニュアル](https://www.php.net/manual/ja/function.sprintf.php)

```
$i = 1;
echo sprintf('%02d', $i);
```


<p class="result"><span>結果</span></p>
```
01
```
	
```
echo sprintf("%'.9d\n", 123);
echo sprintf("%'.09d\n", 123);
```
<p class="result"><span>結果</span></p>
```
......123
000000123
```

### str_padを使う
```
$i = 1;
echo str_pad($i, 2, '0', STR_PAD_LEFT);
```

<p class="result"><span>結果</span></p>
```
01
```


## 関数 戻り値

参考サイト
: [戻り値を使って関数から値を返す](https://www.javadrive.jp/php/function/index4.html)

<iframe src="https://paiza.io/projects/e/Vr74bUcJTzQQcNQ3MVMjKw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## PHPのstaticプロパティとstaticメソッド、定数

参考サイト
: [PHPのstaticプロパティとstaticメソッド、定数](https://atmarkit.itmedia.co.jp/ait/articles/1803/20/news005.html)



## データをフィルタリングする filter_var()

参考サイト
: [PHPマニュアルfilter_var](https://www.php.net/manual/ja/function.filter-var.php)
: [フィルタの型 ](https://www.php.net/manual/ja/filter.filters.php)

例1 filter_var() の例
```
<?php
var_dump(filter_var('bob@example.com', FILTER_VALIDATE_EMAIL));
var_dump(filter_var('http://example.com', FILTER_VALIDATE_URL, FILTER_FLAG_PATH_REQUIRED));
?>
```
上の例の出力は以下となります。

<p class="result"><span>結果</span></p>
```
string(15) "bob@example.com"
bool(false)
```

## 配列の全ての要素にユーザー定義の関数を適用する array_walk

参考サイト
: [PHP マニュアル array_walk](https://www.php.net/manual/ja/function.array-walk.php)

<div class="exp">
	<p class="tmp"><span>例1</span></p>
<iframe src="https://paiza.io/projects/e/g6_QIuBA0OrAi7Uz7g_1Qg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例2</span></p>
	無名関数を使った、array_walk() の例
	<iframe src="https://paiza.io/projects/e/yX9U0g8w4-u3aZb9A68ifA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe src="https://paiza.io/projects/e/znRHYoP_UV7EQhdAx7qFdw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


## array_map_recursive

[array_map_recursiveはPHPに標準実装されていた！](https://qiita.com/mpyw/items/2967ea1e36a144f76587)

## 日本時間を取得

参考サイト
: [【PHP】本日の日付,時間,曜日を日本時間で表示させる（date）](https://dailyrecords.blog/archives/8439)
: [PHP 現在の日付や時間を取得したい](https://wepicks.net/phpsample-date-today/)

<iframe src="https://paiza.io/projects/e/zC48c-xm298ex-g7my0KHg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


### 補足　日付のフォーマット
参考サイト
: [【PHP】DateTimeでの日時取得とフォーマット方法まとめ](https://www.sejuku.net/blog/21772)
こちらのやり方でも日付の形式を指定できる。

<iframe src="https://paiza.io/projects/e/POyZVhCAKQKhgqVrK0Wj8g?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

形式の指定には変換文字を使用します。

|変換文字|説明	|表記例|
| :--: | -- | :--: |
|Y	|4桁の西暦	|2018|
|y	|2桁の西暦	|18|
|m	|先頭に0を付けた2桁の月	|05|
|n	|先頭に0を付けない月	|5|
|d	|先頭に0を付けた2桁の日付	|07|
|j	|先頭に0を付けない日付	|7|
|G	|先頭に0を付けない24時間単位の時	|13|
|g	|先頭に0を付けない12時間単位の時	|1|
|H	|先頭に0を付けた24時間単位の時	|13|
|h	|先頭に0を付けた12時間谷の時	|01|
|i	|先頭に0を付けた分	|30|
|s	|淺津に0を付けた秒	|02|


## 配列の値を正規表現で検索する

参考サイト
: [【PHP入門】配列の値を検索するarray_searchと他4つの関数](https://www.sejuku.net/blog/22098)

正規表現とは特定の文字列からパターンになっている(文字列)部分を表すために使用されます。  
array_searchとin_array関数では検索する値に正規表現を使うことができません。  
検索する値が文字列の正規表現を使う場合にはpreg_grep関数を使います。

<p class="tmp"><span>書式</span>preg_grep</p>
```
preg_grep(検索するパターン文字列, 検索対象の配列)
```

## global変数を$GLOBALS配列を使っての書き方

参考サイト
: [PHPにおける変数のスコープと静的変数――「バグの温床」としないための使い方](https://atmarkit.itmedia.co.jp/ait/articles/1710/11/news001_2.html)

「$GLOBALS配列」
: グローバル変数は、PHP内部ではスーパーグローバルである$GLOBALS配列で参照できるようになっています。

```
global $list;
foreach($list as $value) {
```
の部分は
```
foreach($GLOBALS["list"] as $value) {
```

と記述できます。
<iframe src="https://paiza.io/projects/e/mmbIgk9rY3bHevKJ4cAZkg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## ジェネレータは値を次々と生成（yield）

<iframe src="https://paiza.io/projects/e/BEGm25UNn1JJ9D0-BQ5Fcg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

yieldは、returnと同じようにその次に書かれた値、例えば、6行目なら$ansを呼び出し元に返します。ただし、returnとは全く違う動きをします。このyieldが書かれたfunctionブロックは、functionで始まっていますが通常の関数ではありません。これがジェネレータ関数です。なお、yieldは「産出する」という意味の英単語です。

![](upload/yieldを利用.jpg)

### ジェネレータはループで使用する

通常のループだと次のようになります。
<iframe src="https://paiza.io/projects/e/ZmLz5S_duXk8GGPEqGLgXQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

ここでは要素数が10コの配列なので問題ないですが、要素数が100万個となると、100MBを超えるメモリを使うことになります。

ところが、この問題点はジェネレータを使うことで解決できます。上記と同じ処理を、ジェネレータを使って作成し、実行してください。
<iframe src="https://paiza.io/projects/e/WINNG1Wohom_8P99KhJOuw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
実行結果は、乱数を使っているので値は変わっていますが、リスト6と同じようなものになります。

　ここでのポイントは、randGenerator()ジェネレータ関数と、その内部で値をyieldしている5行目です。このジェネレータ関数では、その場で乱数を生成し、それをyieldしています。こうすることで、全部の値が格納された配列を用意する必要がなく、値がループされるたびに生成されるのでメモリの節約になります。これは、生成する値が多ければ多いほど、その恩恵にあずかれます。
 
 ## voidについて
 
 参考サイト
 : [PHPにおけるvoidとは何か](https://qiita.com/tadsan/items/154070f1ee4c7fe4ae47)
 


## ログイン機能作成方法について

参考サイト
: [PHP のセッションを使ったログイン認証はなぜ安全なのか？](https://blog.apar.jp/php/12373/)