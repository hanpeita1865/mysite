---
title: 'Image Maps'
taxonomy:
    category:
        - docs
---

## 参考サイト
[【jQuery】クリッカブルマップ『RWD Image Maps』を使いこなせば、レスポンシブでもズレませーん](https://125naroom.com/web/3701)

## デモ

[新規タブ](../../../../sample/jquery/image_maps/jquery-rwd-image-maps/index.html?target=_blank)

<iframe height="300" style="width: 100%;" scrolling="no" title="【jQuery】画像のレスポンシブ対応でクリッカブルマップがズレない『RWD Image Maps』を使いこなす" src="https://codepen.io/125naroom/embed/poyPNXR?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/125naroom/pen/poyPNXR">
  【jQuery】画像のレスポンシブ対応でクリッカブルマップがズレない『RWD Image Maps』を使いこなす</a> by 125naroom (<a href="https://codepen.io/125naroom">@125naroom</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>