---
title: '07. 配列'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table caption {font-size: 1.2rem;}  
    .mb-2 {margin-bottom: 2rem;}
    .mb-1 {margin-bottom: 1rem;}
    .mb-0 {margin-bottom: 0;}
    .lead {margin-bottom: 4rem;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: blue;}
    .mt-2 {margin-top: 2rem;}
    .mt-4 {margin-top: 4rem;}
    .smp {margin-top: 2rem; margin-bottom: 0;}
    .p-example {margin-bottom: 0;}
    .p-example span {
        background: #bc495b;
        color: #fff;
        font-size: .8rem;
        letter-spacing: .3rem;
        padding: .2rem 0.3rem .2rem .7rem;
        white-space: nowrap;
        font-weight: normal;
        margin-right: 1rem;
     }
    h3 span {
        border-bottom: 3px solid green;
    }
</style>

<section>
<p class="lead">配列はカバンのようなもので、複数のデータを1つにまとめて管理するのに使われます。<br>
もし配列を使わずに、各項目を一つずつ変数に代入していこうとすると、やることが増えるにつれて変数の数も膨大になり、収拾がつかなくなってしまいます。<br>
でも配列を使えば、変数を一つにまとめられ、データの管理が楽になります。</p>

<p class="mb-0 bold">いちいち一個一個変数を作っていくと大変<br>
　　↓</p>
            
<pre class="mb-1">
var tool1 = '鉛筆';
var tool2 = '消しゴム';
var tool3 = 'ものさし';
　　　・
   　 ・
      ・
</pre>

<p class="mb-0 bold">このように一つの変数にまとめた方が楽です<br>
　　↓</p>
            
<pre class="mb-1">
var tool = ['鉛筆', '消しゴム', 'ものさし', ・,・,・,・・・・・];
</pre>
</section>

<section>
<h2 class="h-type2">配列の設定と読み取り</h2>
    <p>配列を使用する際は配列の宣言をする必要があります。宣言するときは「<span class="red">［］</span>もしくは<span class="red">Array</span>」を使用します。</p>

	<p class="tmp"><span>書式1</span>項目数が0個の配列を作成して変数に保存する。</p>
    <span class="att">※ 配列には後からデータを追加することができるので、初めが0個でも問題ありません。</span>
<pre class="mb-2">
var 変数名 = [];

または

var 変数名 = new Array(); 
</pre>
  
<p class="tmp"><span>書式2</span>１個以上のデータを持つ配列を作成する</p>    
<pre>
var 変数名 = [データ1,データ2, ... ,データX];

または

var 変数名 = new Array(データ1,データ2, ... ,データX);
</pre>

<p>※このように二通りの書き方がありますが、ここからは、[ ] の方を使って説明していきます。</p>

<p class="tmp"><span>書式3</span>配列のデータを読み取る</p>  
<span class="att">※ 配列の場合、<span class="red">インデックス番号は、0から始まります。</span></span>
<pre>
変数[インデックス番号];
</pre>
 
<div class="box-example">
	<h3 class="h-example">例7-1</h3>
	勉強会のテーマを配列にし、変数に代入しています。
    [～]が配列でthemeが変数になります。
    theme[0]で指定したテーマを読み取り、コンソールで表示しています。theme[1]にするとjQuery、theme[2]だとJavascriptが表示されます。
</div>
<!--<script async src="//jsfiddle.net/qgs6w18x/9/embed/js,result/"></script>-->

<iframe width="100%" height="200" src="//jsfiddle.net/f0sk9qc5/1/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>

<section>
<h2 class="h-type2">配列の各項目をすべて読み取る</h2>
<div class="box-example">
	<h3 class="h-example">例7-2</h3>
    lengthプロパティは配列で使う場合、データ数を取得します。ここでは、theme.lengthは「4」になります。インデックス番号は「0」から始まるので、「i」の値が「0」から始まり「4」になるひとつ前で繰り返し文は終了するようになっています。i++ は、i = i + 1 の省略形です。
</div>
    
<!--<script async src="//jsfiddle.net/joby5pm7/embed/js,result/"></script>-->
    
<iframe width="100%" height="200" src="//jsfiddle.net/032n5kdL/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>



<section>
<h2 class="h-type2">項目を追加する（push）</h2>
<p class="tmp"><span>書式4</span></p>  
<pre>
変数名.push(データ)
</pre>

<div class="box-example">
	<h3 class="h-example">例7-3</h3>
    今ある配列の最後に「PHP」の文字を追加してから、全てのデータを表示しています。.pushは配列の最後にデータを追加するメソッドです。
</div>
<!--<script async src="//jsfiddle.net/bqjfcx7g/1/embed/js,result/"></script>-->

<iframe width="100%" height="200" src="//jsfiddle.net/46rafkLb/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
    

<table>
    <caption>配列にデータを追加・削除する主なメソッド</caption>
    <tr>
        <th>変数名.pop()</th>
        <td>配列の最後のデータを削除する</td>
    </tr>
    <tr>
        <th>変数名.push(データ)</th>
        <td>配列の最後にデータを追加する</td>
    </tr>
    <tr>
        <th>変数名.shift()</th>
        <td>配列の最初のデータを削除する</td>
    </tr>
    <tr>
        <th>変数名.unshift(データ)</th>
        <td>配列の最初にデータを追加する</td>
    </tr>
</table>

</section>
<section>
    <h2 class="h-type2">データのインデックスを取得する（indexOf）</h2>
    <p class="tmp"><span>書式5</span></p>
    <pre class="mb-0">変数名.indexOf(検索するデータ[, fromIndex])</pre>   
    <span class="att mb-2">※ fromIndex～検索の開始位置を示します。 fromIndex を省略すると、検索はインデックス 0 から開始されます。</span>    
    
<div class="box-example">
	<h3 class="h-example">例7-4</h3>
    javascriptのインデックス番号を取得して表示しています。
</div>
    <!--<script async src="//jsfiddle.net/p5e2gsn8/1/embed/js,result/"></script>-->
 
    <iframe width="100%" height="200" src="//jsfiddle.net/L7rz62tv/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>

<section>
    <h2 class="h-type2">インデックス位置を指定してデータを削除する（splice）</h2>
        <p>指定された数の要素を start（インデックス番号）の位置からdeleteCount個だけ削除し、新しいデータを挿入しています。
挿入するデータの部分は省略可能です。</p>
<p class="tmp"><span>書式6</span>指定された数の要素を start（インデックス番号）の位置からdeleteCount個だけ削除し、新しいデータを挿入しています。<br>
（挿入するデータの部分は省略可能です。）</p>
    <pre>変数.splice(start, deleteCount, データ1,データ2, ... データX)</pre>

<div class="box-example">
	<h3 class="h-example">例7-5</h3>
    「jQuery」と「Javascript」を削除し、その削除した位置に「PHP」と「Bootstrap」を挿入しています。
</div>
    <!--<script async src="//jsfiddle.net/8oj197bL/8/embed/js,result/"></script>-->
<iframe width="100%" height="200" src="//jsfiddle.net/r8fsqdx4/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
 
<div class="box-example mt-2">
	<h3 class="h-example">例7-6</h3>
    こちらは「jQuery」と「Javascript」を削除だけしています。
</div>
    <!--<script async src="//jsfiddle.net/8oj197bL/9/embed/js,result/"></script>-->
<iframe width="100%" height="200" src="//jsfiddle.net/quhe381c/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
    
</section>

<section>
    <h2 class="h-type2">配列をコピーする（slice）</h2>
    <p>元の配列の変更は行いませんが、 元の配列から切り取ったデータのコピーを新しい配列にコピーします。</p>
    <p class="tmp"><span>書式6</span>2つの引数を指定し、その間の文字列を抜き出します</p>
    <pre>変数.slice(start, end) </pre>
    <p>start～必須です。抽出する部分の先頭位置。<br>
        end～省略可能です。 抽出する部分の終端位置。省略すると最後のデータまでをコピーします</p>
    
 <div class="box-example">
	<h3 class="h-example">例7-7</h3>
    startの引数が2なので、前から3番目以降のデータを変数のthemeCopyにコピーして表示しています。
</div>
    <!--<script async src="//jsfiddle.net/rjqo2acz/1/embed/js,result/"></script>-->
<iframe width="100%" height="200" src="//jsfiddle.net/daLrfyw5/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>

<section>
    <h2 class="h-type2">配列を使った応用例</h2>
  
    <p class="tmp"><span>書式</span>文字列を置換する</p>
    <pre>変数.replace( 対象の文字, 置換する文字 );</pre>
    
<h3><span>サンプル</span></h3>
<p>文章中の下記の指定した文字を置換する。</p>
<p><span class="bold">置換文字</span><br>
     羅生門 ⇒ 清水寺 、老婆 ⇒ 若者 、失望 ⇒ 絶望 、勇気 ⇒ 自信 、下人 ⇒ 坊主</p>

  
<iframe width="100%" height="400" src="//jsfiddle.net/a9kyLun0/6/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
<dl>
    <dt><strong>解説</strong></dt>
    <dd>beforeとafterに配列を設定する。<br>
        文章を取得し、変数searchTextに格納する。<br>
        for文を使って配列で指定した文字を順番に置換していく。その時、replaceは最初に検索してみつかった文字しか置換しないので、while文で検索する文字がなくなるまですべて置換する。<br>
        置換した文章の変数searchTextをid=storyのテキストにもどす。</dd>
</dl>

</section>

<h2 class="h-type2">参考サイト</h2>

[Array オブジェクトについて](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Global_Objects/Array)