*[page-title]:Chpa3-3 Laravel Mix（Viteに切り替え）でフロントエンドを作る

Ver9のどこかから、<span class="red">Laravel mix</span> から　<span class="green bold">vite</span> に切り替わっています。  
参考書ではLaravel mixを使って解説しているが、インストールしてるLaravelのバージョンは、「ver10」なのでviteを使う。
![](upload/laravel_v10.16.1.png " 図　composer.lock")

<p class="tmp list"><span>リスト</span>vite.config.js（デフォルト）</p>
```
import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/css/app.css',
                'resources/js/app.js',
            ],
            refresh: true,
        }),
    ],
});

```

開発用のサーバーにアクセスするためには、vite.config.jsを以下のように修正しました。  
serverを追記しました。

<p class="tmp list"><span>リスト</span>vite.config.js</p>
```
import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    server: {
        hmr: {
            host: 'localhost',
        },
    },
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js'],
            refresh: true,
        }),
    ],
});
```

<p class="tmp cmd"><span>コマンド</span></p>
```
sail npm run dev
```
コマンドを実行すると、<span class="green bold">vite</span>の画面が表示されます。

![](upload/vite画面表示.png)

JS, CSSをフロント画面で読み込むには、bladeに以下を指定します。  
ホットリロードが効きますので、ファイルを修正すると画面にすぐに反映されます。

<p class="tmp list"><span>リスト</span></p>
```
	<head>
			@vite(['resources/css/app.css', 'resources/js/app.js'])
	</head>
```

<p class="tmp list"><span>リスト</span>tweet/index.blade.phptweet/index.blade.php</p>
```
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>つぶやきアプリ</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
```

<http://localhost/tweet>に再接続すると、反映されています。
![](upload/viteclientなど.png)

下記のコマンドを実行すると、app.cssとapp..jsが出力されます。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail npm run build
```
![](upload/npm_run_build実行.png)

ここに出力されます。
![](upload/app.cssとapp.jsを出力.png){.photo-border}


## Bladeテンプレートのコンポーネント機能を利用する


コンポーネントの機能には<span class="green bold">クラスコンポーネント</span>と<span class="purple bold">匿名コンポーネント</span>の2種類があります。  
まずは<span class="green bold">匿名コンポーネント</span>を利用して画面を作っていきます。  


### 匿名コンポーネント

匿名コンポーネントでは resources/views/componentsの中に作成し たbladeファイルを 「`<x-{name}></x-{name}>`」 という形で呼び出すこと ができます。
たとえばresources/views/components/alert/success.blade. phpというファイルがある場合、resources/views/index.blade.phpから 「`<x-alert.success></x-alert.success>`」 といった形で呼び出すことができます。このようにcomponents以下のディレクトリを掘っていった場合は ドットでつなぐことで該当のファイルに到達します。

index.blade.phpをコピーして、layout.blade.phpファイルを新規作成し、コードを書き換えてください。

※index.blade.phpのコードが参考書とちがう。デフォルトのindex.blade.phpのコードのことかも。

<p class="tmp list"><span>リスト</span>resources/views/components/layout.blade.php</p>
```
<!doctype html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ $title ?? 'つぶやきアプリ' }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])<!--vite用に書き換えてます-->
</head>
<body class="bg-gray-50">
    {{ $slot }}
</body>
</html>
```

index..blade.phpのコードを次の3行のみに変更します。

p class="tmp list"><span>リスト</span>resources/views/tweet/index.blade.php</p>
```
<x-layout title="TOP | つぶやきアプリ">
    <h1>ここに内容が入ります</h1>
</x-layout>
```

<http://localhost/tweet/>にアクセスしてみます。
![](upload/ここに内容がはいります.png){.photo-border}



なお、ここでは使用しませんが、slotが複数欲しい場合には名前付きslotが利用できます。

<p class="tmp list"><span>リスト</span>layout.blade.php（複数のslotを利用する場合の例）</p>
```
<!doctype html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="{{ mix('/css/app.css') }}" rel="stylesheet">
    <script src="{{ mix('/js/app.js') }}" async defer></script>
    <title>{{ $title ?? 'つぶやきアプリ' }}</title>
</head>
<body class="bg-gray-50">
    {{ $slot }}
     <aside>{{ $aside }}</aside>
</body>
</html>
```

上記のように{{$aside}}と宣言した場合、利用側は次のようになります。

<p class="tmp list"><span>リスト</span>index.blade.php（複数のslotを利用する場合の例）</p>
```
<x-layout title="TOP | つぶやきアプリ">
    <h1>ここに内容が入ります</h1>
        <x-slot name="aside">追加したslot</x-slot>
</x-layout>
```

このようにx-slotタグおよびname属性をつけることで、複数のslotを作ることができます。


### 投稿フォームをコンポーネント化する

resources/views/components/resources/views/components/以下にフォルダを作成して配置していきます。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/form/post.blade.php（フォーム）</p>
```
@auth
<div class="p-4">
    <form action="{{ route('tweet.create') }}" method="post">
        @csrf
        <div class="mt-1">
            <textarea
                name="tweet"
                rows="3"
                class="focus:ring-blue-400 focus:border-blue-400 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md p-2"
                placeholder="つぶやきを入力"></textarea>
        </div>
        <p class="mt-2 text-sm text-gray-500">
            140文字まで
        </p>

        @error('tweet')
        <x-alert.error>{{ $message }}</x-alert.error>
        @enderror

        <div class="flex flex-wrap justify-end">
            <x-element.button>
                つぶやく
            </x-element.button>
        </div>
    </form>
</div>
@endauth
```


<p class="tmp list"><span>リスト</span>resources/views/components/alert/error.blade.php（アラート）</p>
```
<div class="w-full mt-1 mb-2 p-2 bg-red-500 items-center text-white leading-none lg:rounded-full flex lg:inline-flex" role="alert">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
    </svg>
    <span class="font-semibold mr-2 text-left flex-auto pl-1">{{ $slot }}</span>
</div><div class="w-full mt-1 mb-2 p-2 bg-red-500 items-center text-white leading-none lg:rounded-full flex lg:inline-flex" role="alert">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
    </svg>
    <span class="font-semibold mr-2 text-left flex-auto pl-1">{{ $slot }}</span>
</div>
```


<p class="tmp list"><span>リスト</span>resources/views/components/element/button.blade.php（ボタン）</p>
```
<button
        type="submit"
        class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
>
    {{ $slot }}
</button>
```

<p class="tmp list"><span>リスト</span>resources/views/components/layout/single.blade.php（コンテナ）</p>
```
<div class="flex justify-center">
    <div class="max-w-screen-sm w-full">
        {{ $slot }}
    </div>
</div>
```

index.blade.phpを次のように書き換えます。

<p class="tmp list"><span>リスト</span>resources/views/tweet/index.blade.php</p>
```
<x-layout title="TOP | つぶやきアプリ">
    <x-layout.single>
        <h2 class="text-center text-blue-500 text-4xl font-bold mt-8 mb-8">
            つぶやきアプリ
        </h2>
        <x-tweet.form.post></x-tweet.form.post>
    </x-layout.single>
</x-layout>
```

ここまできたら、<http://localhost/tweet/>にアクセスしてみましょう。

※CSSが反映されない場合は、「sail npm run build」を実行してみてください。

スタイルが反映されました。
![](upload/つぶやきアプリ表示.png){.photo-border}


### 未ログイン時の表示を作る

未ログイン時にはログインボタンと会員登録ボタンを表示されるように対応します。  
まずは、ログインページと会員登録ページに遷移するためのaタグのボタンコンポーネントを作成します。

<p class="tmp list"><span>リスト</span>resources/views/components/element/button-a.blade.php（ボタン）</p>
```
@props([
    'href' => '',
    'theme' => 'primary',
])
@php
    if(!function_exists('getThemeClassForButtonA')){
      function getThemeClassForButtonA($theme) {
          return match ($theme) {
              'primary' => 'text-white bg-blue-500 hover:bg-blue-600 focus:ring-blue-500',
              'secondary' => 'text-white bg-red-500 hover:bg-red-600 focus:ring-red-500',
              default => '',
          };
        }
    }
@endphp
<a href="{{ $href }}" class="
    inline-flex justify-center
    py-2 px-4
    border border-transparent
    shadow-sm
    text-sm
    font-medium
    rounded-md
    focus:outline-none focus:ring-2 focus:ring-offset-2 {{ getThemeClassForButtonA($theme) }}">
    {{ $slot }}
</a>
```

ここで@propsというディレクティブが登場しました。先ほど登場したpropsのデフォルトの値を設定できるディレクティブです。  
続いてpost.blade.phpにこのボタンを利用してログインへの動線を追加します。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/form/post.blade.php（ログインボタン）</p>
```
@auth
// 省略
@endauth
@guest
<div class="flex flex-wrap justify-center">
    <div class="w-1/2 p-4 flex flex-wrap justify-evenly">
        <x-element.button-a :href="route('login')">ログイン</x-element.button-a>
        <x-element.button-a :href="route('register')" theme="secondary">会員登録</x-element.button-a>
    </div>
</div>
@endguest
```

@authの終了ディレクティブに続けて@guest ディレクティブを宣言します。  
@guest ディレクティブは未ログインのユーザーのみ表示される領域です。  
先ほど作成したaタグのコンポーネントを利用し、 それぞれrouteヘルパー 関数を利用してログインページと会員登録ページにリンクします。  
これで未ログインの場合は、次のようにつぶやきのフォームではなくリンク導線が表示されるようになります。
![](upload/未ログイン時の表示.png "図　未ログイン時の表示")


### ログアウトボタンを追加する

さらに、ログイン済みの場合にはログアウトボタンが表示されるようにします。

<p class="tmp list"><span>リスト</span>resources/views/components/layout/single.blade.php</p>
```
<div class="flex justify-center">
    <div class="max-w-screen-sm w-full">
			<!--追加-->
        @auth
        <form method="post" action="{{ route('logout') }}">
            @csrf
            <div class="flex justify-end p-4">
                <button
                        class="mt-2 text-sm text-gray-500 hover:text-gray-800"
                        onclick="event.preventDefault(); this.closest('form').submit();"
                >ログアウト</button>
            </div>
        </form>
        @endauth

        {{ $slot }}
    </div>
</div>
```

これで、ログイン済みの場合にログアウトボタンが表示されるようになりました。
![](upload/ログアウトボタン設置.png)

しかし、このままではログアウト後に「<http://localhost/>」に遷移してしまいます。  
「<http://localhost/tweet>」に遷移されるように変更しましょう。

ログアウトの際には、Breezeで作成されたAuthenticatedSessionControllerのdestroyメソッドが実行されるので、これを変更します。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Auth/AuthenticatedSessionController.php</p>
```
public function destroy(Request $request)
{
    Auth::guard('web')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    return redirect('/tweet');
}
```

return redirectの部分を「/tweet」に変更することで、遷移先を変更できます。


### つぶやき一覧をコンポーネント化する


続けて、つぶやき一覧のコンポーネントを作っていきます。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/list.blade.php</p>
```
@props([
    'tweets' => []
])
<div class="bg-white rounded-md shadow-lg mt-5 mb-5">
    <ul>
        @foreach($tweets as $tweet)
        <li class="border-b last:border-b-0 border-gray-200 p-4 flex items-start justify-between">
            <div>
                <span class="inline-block rounded-full text-gray-600 bg-gray-100 px-2 py-1 text-xs mb-2">
                    {{ $tweet->user->name }}
                </span>
                <p class="text-gray-600">{!! nl2br(e($tweet->content)) !!}</p><!-- 特殊文字をエスケープ、改行コードを<br>に変換-->
            </div>
            <div>
                <!-- TODO 編集と削除 -->
            </div>
        </li>
        @endforeach
    </ul>
</div>
```

編集と削除のコンポーネントは別途作成します。  
このコンポーネントは、tweetsというpropsほ渡さなくても初期値として空配列が定義されているので、コンポーネントを使う際に引数を宣言しなくてもエラーなく表示できます。

<div markdown="1" class="memo-box">
Laravelのヘルパー関数「e」はPHPの関数 「html specialchars」 をオプション 「double_encode」 が true の設定で実行する関数です。
</div>

一覧のコンポーネントを作成したので、index.blade.phpから呼び出しましょう。

<p class="tmp list"><span>リスト</span>resources/views/tweet/index.blade.php</p>
```
<x-layout title="TOP | つぶやきアプリ">
    <x-layout.single>
        <h2 class="text-center text-blue-500 text-4xl font-bold mt-8 mb-8">
            つぶやきアプリ
        </h2>
        <x-tweet.form.post></x-tweet.form.post>
        <x-tweet.list :tweets="$tweets"></x-tweet.list><!--追加-->
    </x-layout.single>
</x-layout>
```

<http://localhost/tweet/>にアクセスすると、次のようになります。

![](upload/list.blade設置.png)


### クラスベースコンポーネントを作る

編集と削除のコンポーネントを「クラスベースコンポーネント」で作成しましょう。  
クラスベースコンポーネントは匿名コンポーネントと異なり、artisanコマンドから作成できます。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:component Tweet/Options
```

コマンドを実行すると、「resouses/views/components/tweet/<span class="blue bold">options.blade.php</span>」と「app/View/Components/Tweet/<span class="green bold">Options.php</span>」が生成されます。

※実行すると、Options.phpは生成されるが、options.blade.phpの生成でエラーが出る。

エラー内容  
「 file_put_contents(/var/www/html/resources/views/components/tweet/options.blade.php): Failed to open stream: Permission denied」

パーミッションのエラーだと思うが対応がわからないので、直接options.blade.phpを作成した。

<p class="tmp list"><span>リスト</span>options.blade.php</p>
```
@if($myTweet)
<details class="tweet-option relative text-gray-500">
    <summary>
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
        </svg>
    </summary>
    <div class="bg-white rounded shadow-md absolute right-0 w-24 z-20 pt-1 pb-1">
        <div>
            <a href="{{ route('tweet.update.index', ['tweetId' => $tweetId]) }}" class="flex items-center pt-1 pb-1 pl-3 pr-3 hover:bg-gray-100">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                    <path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" />
                </svg>
                <span>編集</span>
            </a>
        </div>
        <div>
            <form action="{{ route('tweet.delete', ['tweetId' => $tweetId]) }}" method="post" onclick="return confirm('削除してもよろしいですか?');">
                @method('DELETE')
                @csrf
                <button type="submit" class="flex items-center w-full pt-1 pb-1 pl-3 pr-3 hover:bg-gray-100">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                    </svg>
                    <span>削除</span>
                </button>
            </form>
        </div>
    </div>
</details>
@endif
```

<p class="tmp list"><span>リスト</span>Options.php（デフォルト）</p>
```
<?php

namespace App\View\Components\Tweet;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class Options extends Component
{
    /**
     * Create a new component instance.
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.tweet.options');
    }
}
```

<p class="tmp list"><span>リスト</span>Options.php</p>
```
<?php

namespace App\View\Components\Tweet;

use Illuminate\View\Component;

class Options extends Component
{
    private int $tweetId;
    private int $userId;

    public function __construct(int $tweetId, int $userId)
    {
        $this->tweetId = $tweetId;
        $this->userId = $userId;
    }

    public function render()
    {
        return view('components.tweet.options')
            ->with('tweetId', $this->tweetId)
            ->with('myTweet', \Illuminate\Support\Facades\Auth::id() === $this->userId);
    }
}
```

また、Tailwind CSSだけでは表現できない装飾をつけたいので、別途CSSを定義します。  
Bladeテンプレートに続けて下記を挿入します。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/options.blade.php</p>
```
@once
@push('css')
    <style>
        .tweet-option > summary {
            list-style: none;
            cursor: pointer;
        }
        .tweet-option[open] > summary::before {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 10;
            display: block;
            content: " ";
            background: transparent;
        }
    </style>
@endpush
@endonce
```


<p class="tmp list"><span>リスト</span>resources/views/components/layout.blade.php（全体）</p>
```
<!doctype html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="{{ mix('/css/app.css') }}" rel="stylesheet">
    <script src="{{ mix('/js/app.js') }}" async defer></script>
    <title>{{ $title ?? 'つぶやきアプリ' }}</title>
    @stack('css')
</head>
<body class="bg-gray-50">
    {{ $slot }}
</body>
</html>
```


<p class="tmp list"><span>リスト</span>resources/views/components/tweet/list.blade.php</p>
```
<div>
		<!-- TODO 編集と削除 -->
		<x-tweet.options :tweetId="$tweet->id" :userId="$tweet->user_id"></x-tweet.options><!--追加-->
</div>
```

ここまで作成して、<http://localhost/tweet/>　にアクセスします。

![](upload/編集と削除リンク表示.png){.photo-border}


## 編集ページのデザインを整える

編集ページのデザインを整えていきます。  
まずは投稿フォームと同様に編集フォームのコンポーネントを作成します。


<p class="tmp list"><span>リスト</span>resources/views/components/tweet/form/put.blade.php</p>
```
@props([
    'tweet'
])
<div class="p-4">
    <form action="{{ route('tweet.update.put', ['tweetId' => $tweet->id]) }}" method="post">
        @method('PUT')
        @csrf
        @if (session('feedback.success'))
        <x-alert.success>{{ session('feedback.success') }}</x-alert.success>
        @endif
        <div class="mt-1">
            <textarea
                name="tweet"
                rows="3"
                class="focus:ring-blue-400 focus:border-blue-400 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md p-2"
                placeholder="つぶやきを入力">{{ $tweet->content }}</textarea>
        </div>
        <p class="mt-2 text-sm text-gray-500">
            140文字まで
        </p>

        @error('tweet')
        <x-alert.error>{{ $message }}</x-alert.error>
        @enderror

        <div class="flex flex-wrap justify-end">
            <x-element.button>
                編集
            </x-element.button>
        </div>
    </form>
</div>
```

次に編集に成功したときの表示の作成です。

<p class="tmp list"><span>リスト</span>resources/views/components/alert/success.blade.php</p>
```
<div class="w-full mt-1 mb-2 p-2 bg-green-500 items-center text-white leading-none lg:rounded-full flex lg:inline-flex" role="alert">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
    </svg>
    <span class="font-semibold mr-2 text-left flex-auto pl-1 text-blue-500">{{ $slot }}
</span><!--text-blue-500を追加-->
</div>
```

続いて、パンくずリストのコンポーネントを作成します。

<p class="tmp list"><span>リスト</span>resources/views/components/element/breadcrumbs.blade.php</p>
```
@props([
    'breadcrumbs' => [
        [
            'href' => '/',
            'label' => 'TOP'
        ]
    ]
])
<nav class="text-black mx-4 my-3" aria-label="Breadcrumb">
    <ol class="list-none p-0 inline-flex">
        @foreach($breadcrumbs as $breadcrumb)
        @if ($loop->last)
        <li>
            <a href="{{ $breadcrumb['href'] }}" class="text-gray-500" aria-current="page">{{ $breadcrumb['label'] }}</a> 
        </li>
        @else
        <li class="flex items-center">
            <a href="{{ $breadcrumb['href'] }}" class="hover:underline">{{ $breadcrumb['label'] }}</a> <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"> <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" /> </svg> 
        </li> 
        @endif @endforeach 
    </ol> 
</nav>
```

最後に編集画面を組み立てます。

<p class="tmp list"><span>リスト</span>resources/views/tweet/update.blade.php（全体書き換え）</p>
```
<x-layout title="編集 | つぶやきアプリ">
    <x-layout.single>
        <h2 class="text-center text-blue-500 text-4xl font-bold mt-8 mb-8">
            つぶやきアプリ
        </h2>
        @php
            $breadcrumbs = [
                ['href' => route('tweet.index'), 'label' => 'TOP'],
                ['href' => '#', 'label' => '編集']
            ];
        @endphp
        <x-element.breadcrumbs :breadcrumbs="$breadcrumbs"></x-element.breadcrumbs>
        <x-tweet.form.put :tweet="$tweet"></x-tweet.form.put>
    </x-layout.single>
</x-layout>
```

@phpディレクティブはPHPコードを記述することができます。  
パンくずリストに必要な配列をその場で組み立ててコンポーネントに渡すようにしています。

ここで、<http://localhost/tweet/update/11>　にアクセスすると次のように表示されます。
![](upload/つぶやきを編集しました.png){.photo-border}

※編集ボタンを押したとき、「編集しました」が表示されない。text-whiteのクラスのスタイルが反映されている。なので、success.blade.phpのspanに「text-blue-500」クラスを追加してみました。


これでWebアプリケーションがひとまず完成しました。 BladeのコンポーネントとTailwind CSSを利用して、フロントエンドを柔軟に作れることが体験できたことと思います。  
次 CHAPTERからはこのWebアプリケーションにさらにさまざまな機能を追加していきましょう。
