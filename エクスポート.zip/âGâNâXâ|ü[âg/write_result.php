<?php
require 'database_access.php';

$datetime = date('Y-m-d H:i:s');

$sql=$pdo->prepare('delete from result');
if ($sql->execute()) {
    echo '削除しました。';
}else{
    echo '削除に失敗しました。';
}

$sql = $pdo->prepare('insert into result value(?, ?)');

if ($sql->execute([$datetime, $_POST['result']])) {
    echo '更新に成功しました。';
}else{
    echo '更新に失敗しました。';
}