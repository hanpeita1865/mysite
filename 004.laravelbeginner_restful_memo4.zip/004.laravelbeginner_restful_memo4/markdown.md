*[page-title]:リソースコントローラメモ4（フォーム）


## カレンダー表示

inputのtypeを「date」にすると、クリックした時カレンダーが表示されます。

<p class="tmp list"><span>リスト</span></p>
```
<tr>
	<th>日付: </th>
	<td><input type="date" name="date" value=""></td>
</tr>
```
![](upload/Laravel_date入力.png){.photo-border}


## bootstrap-datepicker

codepen
: <https://codepen.io/saka212/pen/xxgWzvg>

サンプル
: <a href="sample/bootstrap-datepicker-range/" target="_blank">bootstrap-datepicker-range</a>
![](upload/bootstrapクリックでカレンダーが表示.png)

<p class="tmp list"><span>リスト</span>index.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodePen - bootstrap-datepicker-range</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css'>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css'>
</head>
<body>
    <div class="container">
        <div class="row">
          <div class="col-12 mt-3">
      
            <div class="input-daterange input-group" id="datepicker">
              <div class="input-group-prepend">
                <span class="input-group-text">開始日付</span>
              </div>
              <input type="text" class="input-sm form-control" name="from" />
              <div class="input-group-append">
                <span class="input-group-text">終了日付</span>
              </div>
              <input type="text" class="input-sm form-control" name="to" />
            </div>
      
          </div>
        </div>
      
      </div>   
      <script src='https://code.jquery.com/jquery-3.5.1.slim.min.js'></script>
      <script src='https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js'></script>
      <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>
      <script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js'></script>
      <script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/locales/bootstrap-datepicker.ja.min.js'></script><script  
      src="js/script.js"></script>
</body>
</html>
```

<p class="tmp list"><span>リスト</span>script.js</p>
```
$('.input-daterange').datepicker({
    language: 'ja',
    format: 'yyyy/mm/dd',
    forceParse: false,
});
```

※「forceParse: false,」で他の値も入力出来るようになります。  
※「format: 'yyyy年mm月dd日',」にすると、年月日表示になります。