*[page-title]:10-10. 2色の絵画調にしてみよう


<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-10.jpg)](upload/10-10.jpg){.image}
</div>