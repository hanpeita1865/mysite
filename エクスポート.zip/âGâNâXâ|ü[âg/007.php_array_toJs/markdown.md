*[page-title]:PHPでのJSON変換方法

参考サイト
: [JavaScriptの連想配列とは？オブジェクトとの違いや値の取得方法まで徹底解説](https://www.brain-gate.net/content/column/system-program-associative-array/)

## JSON変換について

JSONはJavaScriptのデータフォーマットですが、PHPにはJSONを扱うための関数が用意されています。それらを使うことでJSONをプログラム内で簡単に扱えます。

下記の2つの関数で変換できます。
* <span class="green bold">json_decode</span> : JSON 文字列をデコードする
* <span class="purple bold">json_encode</span> : 値を JSON 形式にして返す

非同期通信で送られたJSONデータを、PHPで利用するために使う関数が「<span class="green bold">json_decode</span>」です。

<p class="tmp"><span>書式</span>json_decode</p>
```
json_decode( JSON文字列、trueで連想配列/falseでオブジェクト,  ネストの深さ,  フラグ );
```
2番目の引数を省略した場合、json_decode関数は<span class="blue bold">オブジェクト</span>を返します。

<p class="lang">JSONをオブジェクトに変換する例</p>
```
$obj = json_decode( $json )
```

2番目の引数にtureを指定すると、JSONが<span class="red bold">連想配列</span>に変換されます。

<p class="lang">JSONを連想配列に変換する例</p>
```
$arr = json_decode( $json, true );
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
	JSONをdecodeを使って、連想配列に変換します。
	<iframe src="https://paiza.io/projects/e/WM-Hx2yEjmmZjuI7fbUj8Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

<div markdown="1" class="memo-box">
JavaScriptには「連想配列」という言葉は存在しません。他のプログラミング言語で「連想配列」というのですが、JavaScriptでは「オブジェクト」または「オブジェクトリテラル」といいます。

なぜ、JavaScriptでは連想配列といわないのか。それは、連想配列は値が入っているのに対し、JavaScriptのオブジェクトは、値としてデータだけではなく、 関数（処理）も入れることができるためです。値だけしか入っていないのであれば、連想配列と言ってもよいでしょう。しかし、JavaScriptでは関数（処理）も入れることができるため、広い意味でオブジェクトと呼ぶわけです。

ですので、JavaScriptにおいてはオブジェクトが連想配列であると考えて問題ありません。
</div>


### json_decode関数がデコードに失敗したら
もし、json_decode関数がデコードに失敗したら、どうなるでしょうか。JSONのデータが破損してデコードできない場合、または、JSONに記載されたデータのネストが深すぎる場合、json_decode関数はnullを返します。

また、JSONデータそのものがnull、false、tureだった場合もnullを返します。非同期通信でエラーが発生した場合は、適切にエラー処理するプログラムを作っておきましょう。

<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
```
<?php
$json = null
$arr = json_decode($json, true);
var_dump($arr);  // NULLが表示される
?>
```

## PHPからJSに配列を引き渡す方法

phpの配列をjsの変数に渡したければ「<span class="green bold">json_encode()</span>」を使ってJSONに変換して渡します。

この時注意するのが、日本語の値の場合このままJSに渡すとUnicode文字になってしまいます。  
そのときは、「json_encode」に「<span class="red">JSON_UNESCAPED_UNICODE</span>」をOptionにつけると文字化けしなくなります。

<p class="tmp"><span>書式</span></p>
```
 json_encode(PHP配列, JSON_UNESCAPED_UNICODE);
```
<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
<iframe src="https://paiza.io/projects/e/l72sA_lIpzLdTKyEW81OGw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


