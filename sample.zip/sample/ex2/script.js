function showTotal(price) {
    let tax = price * 0.08;
    let total = price + tax;

    document.getElementById("result").textContent = "税込み価格：" + total + "円";
}

showTotal(1000);