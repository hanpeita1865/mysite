<?php
namespace SocymSlim\SlimMiddle\Services;

use PDO;
use Exception;

class LockService {
    private $editService;

    public function __construct(EditService $editService) {
        $this->editService = $editService;
    }


    //---------------------
    //   ページロック追加   
    //---------------------

    public function addLock(string $folder, string $under_dir, string $pageArea): string {
        
        $db = $this->editService->db();

        try {
            $db->beginTransaction();
            
            // すでに存在するかチェック（※ EXISTSにした方が良い）
            $stmt = $db->prepare(
                'SELECT 1 FROM locklist WHERE page = :folder AND page_area = :pageArea LIMIT 1'
                // 'SELECT 1 FROM locklist WHERE page = :folder LIMIT 1'
            );
            $stmt->bindValue(':folder', $folder);
            $stmt->bindValue(':pageArea', $pageArea);
            $stmt->execute();

            if ($stmt->fetchColumn()) {
                $db->rollBack();
                return 'すでにロックされています。';
            }
            
            // INSERT
            $stmt = $db->prepare(
                'INSERT INTO locklist (page, under_dir, page_area) VALUES (:folder, :under, :pageArea)'
                // 'INSERT INTO locklist (page, under_dir) VALUES (:folder, :under)'
            );
            $stmt->bindValue(':folder', $folder);
            $stmt->bindValue(':under', 'all');
            $stmt->bindValue(':pageArea', $pageArea);

            if (!$stmt->execute()) {
                throw new Exception('ロックの追加に失敗しました。');
            }

            // メタ更新
            $stmt = $db->prepare(
                'UPDATE locklist_meta SET updated_at = NOW() WHERE page_area = :pageArea'
            );
            
            $stmt->bindValue(':pageArea', $pageArea);
            
            // $stmt = $db->prepare(
            //     'UPDATE locklist_meta SET updated_at = NOW() WHERE id = 1'
            // );
            
            if (!$stmt->execute()) {
                throw new Exception('更新日時の更新に失敗しました。');
            }

            $db->commit();
            return 'ロックを追加しました。';

        } catch (Exception $e) {
            
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            
            throw $e;
        }        

    }



    //-----------------------
    //   ページロック解除   
    //-----------------------

    public function removeLock(string $folder, string $pageArea): string {
        
        $db = $this->editService->db();
        
        try {
            $db->beginTransaction();
            
            $stmt = $db->prepare(
                'DELETE FROM locklist
                WHERE page = :folder
                AND page_area = :pageArea
                LIMIT 1'
            );
            
            $stmt->bindValue(':folder', $folder);
            $stmt->bindValue(':pageArea', $pageArea);
            $stmt->execute();

            if ($stmt->rowCount() === 0) {
                $db->rollBack();
                return 'ロックは存在しません。';
            }
            
            // メタ更新
            $stmt = $db->prepare(
                'UPDATE locklist_meta
                SET updated_at = NOW()
                WHERE page_area = :pageArea'
            );
            
            $stmt->bindValue(':pageArea', $pageArea);
            $stmt->execute();

            $db->commit();
            
            return 'ロックを解除しました。';

        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }



    //-------------------------------------------------//
    //   locklistテーブルから削除（フォルダ削除時など）   
    //------------------------------------------------//
        
    public function deleteLockData(string $folder, string $pageArea): string
    {
        $db = $this->editService->db();

        $isTransactionOwner = !$db->inTransaction();

        if ($isTransactionOwner) {
            $db->beginTransaction();
        }

        try {
            // ロックデータを取得
            $stmt = $db->prepare("
                SELECT id_lock
                FROM locklist
                WHERE page = :page
                AND page_area = :page_area
            ");

            $stmt->execute([
                ':page' => $folder,
                ':page_area' => $pageArea
            ]);

            $lockData = $stmt->fetch(\PDO::FETCH_ASSOC);

            if (!$lockData) {
                if ($isTransactionOwner) {
                    $db->rollBack();
                }

                return 'ロックデータは存在しません。';
            }

            // ロックデータを削除
            $stmt = $db->prepare("
                DELETE FROM locklist
                WHERE page = :page
                AND page_area = :page_area
            ");

            $stmt->execute([
                ':page' => $folder,
                ':page_area' => $pageArea
            ]);

            // ロックデータ更新日時を更新
            $stmt = $db->prepare("
                UPDATE locklist_meta
                SET updated_at = NOW()
                WHERE page_area = :page_area
            ");

            $stmt->execute([
                ':page_area' => $pageArea
            ]);

            if ($isTransactionOwner) {
                $db->commit();
            }

            return 'ロックデータを削除しました。';

        } catch (\Throwable $e) {

            if ($isTransactionOwner && $db->inTransaction()) {
                $db->rollBack();
            }

            throw $e;
        }
    }

    // public function deleteLockData(string $folder, string $pageArea): string {
        
    //     $db = $this->editService->db();
        
    //     try {
    //         $db->beginTransaction();
        
    //         // ロックデータ確認
    //         $stmt = $db->prepare(
    //             'SELECT page
    //             FROM locklist
    //             WHERE page = :folder
    //             AND page_area = :pageArea'
    //         );
            
    //         $stmt->bindValue(':folder', $folder);
    //         $stmt->bindValue(':pageArea', $pageArea);
    //         $stmt->execute();
            
    //         if (!$stmt->fetchColumn()) {
    //             $db->rollBack();
    //             return 'ロックデータは存在しません。';
    //         }

    //         //ロックデータ削除
    //         $stmt = $db->prepare(
    //             'DELETE FROM locklist
    //             WHERE page = :folder
    //             AND page_area = :pageArea
    //             LIMIT 1'
    //         );
            
    //         $stmt->bindValue(':folder', $folder);
    //         $stmt->bindValue(':pageArea', $pageArea);
    //         $stmt->execute();

    //         // メタ更新
    //         $stmt = $db->prepare(
    //             'UPDATE locklist_meta
    //             SET updated_at = NOW()
    //             WHERE page_area = :pageArea'
    //         );
            
    //         $stmt->bindValue(':pageArea', $pageArea);
    //         $stmt->execute();
            
    //         $db->commit();
            
    //         return 'ロックデータを削除しました。';
        
    //     } catch (\Throwable $e) {

    //         if ($db->inTransaction()) {
    //             $db->rollBack();
    //         }

    //         throw $e;
    //     }
    // }
    
    
    //----------------------------------
    //   locklistテーブルから一覧を取得 追加  
    //---------------------------------
    
    public function getLockList(): array
    {
        $sql = "
            SELECT
                id_lock,
                page,
                under_dir
            FROM locklist
            ORDER BY page
        ";
        
        $db = $this->editService->db();
        $stmt = $db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }    
    
}