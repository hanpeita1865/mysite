*[page-title]:Chpa4-1 メールの送信機能を追加する（example-app12）

メールの送信は基本的な機能ですが、1から実装するのはとても難しい機能でもあります。  
Laravelにはメールに関する便利な機能がたくさん用意されています。

<span class="bold green">Chap4-1 完成品</span>
* \\wsl.localhost\Ubuntu-24.04\root\example-app12
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>　データベース名は「example_app5」にしてます。
* ユーザー名「y-hirao@cc22.ne.jp」、パスワード「ryouma0305」

## メールを送受信するための開発環境

まず、メールを受け取れる環境を構築していきます。といっても、Laravel Sailにはメールをプレビューするために「<span class="green bold">MailPit</span>」というツールが最初から入っていますので、これを使っていきます。

※ちなみに以前のSailのバージョンでは、MailHogが採用されていました。最新のLaravelではMailpitに置き換わっています。

参考サイト
: [【Laravel】開発用のメールサーバーを使おう【Mailpit】](https://chigusa-web.com/blog/mailpit/)

MaiPitはメール送信を行うアプリケーションを開発する際に、非常に便利です。

MailPitを使用するメリット
: ● 送信先のメールアドレスにメールは送信せず、送ったメールはWebブラウザ上で確認することができます。
: ● 複数のメールアカウントにメール送信のテスト行いたい場合、実在するメールアカウントを用意するのではなく、送ったメールは、直ぐにブラウザ上から確認できます。

### メールを送るための設定を追加

まずは、メールを送信するための設定をしていきましょう。  
.envファイルの「<span class="bold">MAIL_FROM_ADDRESS</span>」の部分に送信元メールアドレスを設定します。 ここに設定したメールアドレスはメール送信時のデフォルトのメールアドレスとして使われます。 ここでは "<span class="red">info@example. com</span>" に設定しています。

<p class="tmp list"><span>リスト</span>.envでデフォルトのメールアドレスを設定</p>
```
MAIL_FROM_ADDRESS="info@example.com"
```
![](upload/envでデフォルトのメールアドレスを設定.png){.photo-border}

### mailpitの導入

Laravel Sailを起動していれば、<span class="green bold">MailPit</span>もすでに起動しているはずです。MailPitの起動についてはdocker-compose.ymlに記述されています。  
デフォルトでは、MailPitのメールサーバーのポート番号は1025、ダッ シュボードのポート番号は8025に設定されています 。

![](upload/docker-compose.yml_mailpit.png "docker-compose.yml"){.fig-top}


<div markdown="1" class="memo-box">
バージョン確認
: Laravel9.21から、Laravelの状況を一目で確認できるコマンドが追加されたのでそれが使えます。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail art about
```

![](upload/sail_art_about.png)
</div>

### 各種動作確認を行う

tinkerを起動し、動作確認を実施します。
<p class="tmp cmd"><span>コマンド</span>tinkerを起動</p>
```
sail art tinker
```

redisを確認します。

tinker上で、redisへ読み書きを行います。
```
> Cache::put('test', 'hoge');
= true

> Cache::get('test');
= "hoge"

> Cache::clear();
= true
```

![](upload/redisを確認する.png)

tinker上で、テストメールを送信します。
```
Mail::raw('hello world', fn($msg) => $msg->subject('test')->to('test@example.com'));
```

![](upload/mailpitを確認する.png)

### mailpitを開く

<http://localhost:8025/>

![](upload/mail_pitを開く.png "図　mailpit画面"){.photo-border}

テストメールをキャッチできたかを確認します。  
Mark all resd をクリックしてconfirmを押すと、以下のようにテストメールが確認できます。
![](upload/mailPitテストメール確認.png){.photo-border}


Laravelの設定(.env)を確認しましょう。  
SMTPサーバーに、Mailpitが指定されています
![](upload/mailpit_env.png ".env"){.fig-top}

※青の項目は任意のアドレスを設定します。


## 認証機能でメール送信を試す

メール送信を試してみましょう。  
アカウント登録画面（<http://localhost/register>）を開き、アカウントを登録しました。（存在しないメールアドレスでも問題ありません。）

登録をここでは、メール「daichi@test.co.jp」、パスワード「daichi0807」で登録しました。
![](upload/daichi@test.co.jp.png "図　ユーザー登録画面"){.photo-border}

<http://localhost/login>に接続し、メール送信を試すために「<span class="red">Forgot your password?</span>」をクリックします。
![](upload/Forgot_your_password.png "図　ユーザー登録画面 Forgot your password?をクリック")

先程アカウント登録したメールアドレスを指定します。
![](upload/アカウント登録したメールアドレスを指定.png){.photo-border}
翻訳）パスワードをお忘れですか？問題ない。あなたの電子メール アドレスをお知らせください。新しいパスワードを選択できるパスワード リセット リンクを電子メールでお送りします。

パスワードのリセットリンクが、メール送信されました。
![](upload/パスワードのリセットリンク送信.png){.photo-border}

MailPit(<http://localhost:8025/>)を開くと送信されたのが確認できます。
![](upload/パスワードのリセットリンク送信確認.png){.photo-border}

受信ボックスを開くと、メールの本文が確認できます。
![](upload/メール本文確認.png "図　メール本文確認"){.photo-border}

※このようにHTMLメールも確認できますし、プレーンテキスト、ソースも見ることができます。


<div markdown="1" class="memo-box">
#### メールの保存について
メールの保存は、デフォルトでメモリになっておりますので、Sailを再起動した段階で消えてしまいます。  
テスト用のメールの確認ですので、困ることはないと思いますが、一応永続化することもできるようです。

Email-storage 
: <a href="https://github.com/axllent/mailpit/wiki/Email-storage" target="blank">https://github.com/axllent/mailpit/wiki/Email-storage</a>
</div>

## メーラーの設定

次にメーラーの設定について説明していきます。現在はMailPitにメールが送られるように設定されていますが、実際にWebサービスを提供するときにはユーザーにメールが送られるようにしなければなりません。そのようなときのために、使うメーラーの切り替え方を知っておきましょう。メールの設定はconfig/mail.phpに書かれています。

<p class="tmp list"><span>リスト</span>config/mail.php</p>
```
<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Mailer
    |--------------------------------------------------------------------------
    |
    | This option controls the default mailer that is used to send any email
    | messages sent by your application. Alternative mailers may be setup
    | and used as needed; however, this mailer will be used by default.
    |
    */

    'default' => env('MAIL_MAILER', 'smtp'),

    /*
    |--------------------------------------------------------------------------
    | Mailer Configurations
    |--------------------------------------------------------------------------
    |
    | Here you may configure all of the mailers used by your application plus
    | their respective settings. Several examples have been configured for
    | you and you are free to add your own as your application requires.
    |
    | Laravel supports a variety of mail "transport" drivers to be used while
    | sending an e-mail. You will specify which one you are using for your
    | mailers below. You are free to add additional mailers as required.
    |
    | Supported: "smtp", "sendmail", "mailgun", "ses", "ses-v2",
    |            "postmark", "log", "array", "failover"
    |
    */

    'mailers' => [
        'smtp' => [
            'transport' => 'smtp',
            'url' => env('MAIL_URL'),
            'host' => env('MAIL_HOST', 'smtp.mailgun.org'),
            'port' => env('MAIL_PORT', 587),
            'encryption' => env('MAIL_ENCRYPTION', 'tls'),
            'username' => env('MAIL_USERNAME'),
            'password' => env('MAIL_PASSWORD'),
            'timeout' => null,
            'local_domain' => env('MAIL_EHLO_DOMAIN'),
        ],

        'ses' => [
            'transport' => 'ses',
        ],

        'mailgun' => [
            'transport' => 'mailgun',
            // 'client' => [
            //     'timeout' => 5,
            // ],
        ],

        'postmark' => [
            'transport' => 'postmark',
            // 'client' => [
            //     'timeout' => 5,
            // ],
        ],

        'sendmail' => [
            'transport' => 'sendmail',
            'path' => env('MAIL_SENDMAIL_PATH', '/usr/sbin/sendmail -bs -i'),
        ],

        'log' => [
            'transport' => 'log',
            'channel' => env('MAIL_LOG_CHANNEL'),
        ],

        'array' => [
            'transport' => 'array',
        ],

        'failover' => [
            'transport' => 'failover',
            'mailers' => [
                'smtp',
                'log',
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Global "From" Address
    |--------------------------------------------------------------------------
    |
    | You may wish for all e-mails sent by your application to be sent from
    | the same address. Here, you may specify a name and address that is
    | used globally for all e-mails that are sent by your application.
    |
    */

    'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'hello@example.com'),
        'name' => env('MAIL_FROM_NAME', 'Example'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Markdown Mail Settings
    |--------------------------------------------------------------------------
    |
    | If you are using Markdown based email rendering, you may configure your
    | theme and component paths here, allowing you to customize the design
    | of the emails. Or, you may simply stick with the Laravel defaults!
    |
    */

    'markdown' => [
        'theme' => 'default',

        'paths' => [
            resource_path('views/vendor/mail'),
        ],
    ],

];
```
![](upload/mailers設定.png)

「env (XXXXX)」の部分は 「.envファイルのXXXXXの値を使いますよ」という意味なので、<span class="red">.envファイル</span>にあるメールの設定部分も同時に見ていきま しょう。


<p class="tmp list"><span>リスト</span>.env（メール設定部分）</p>
```
MAIL_MAILER=smtp
MAIL_HOST=mailpit
MAIL_PORT=1025
MAIL_USERNAME=null
MAIL_PASSWORD=null
MAIL_ENCRYPTION=null
MAIL_FROM_ADDRESS="info@example.com"
MAIL_FROM_NAME="${APP_NAME}"
```
![](upload/env_mail.png)

この2つのファイルから、MailPitがメーラーとして設定されていること がわかります。 この設定を変更することによってメーラーを変更できるほか、 smtpとなっているデフォルトのメーラーをsesやmailgunといったサービス に変更することでもメールを送信できるようになります。


## メール送信を実装する

では、メールの送信を実装していきましょう。  
今回はユーザーが新規登録されたら、 登録済みユーザーに新規ユーザー追加の通知メールを送る機能を追加していきます。  
このメール送信機能を作る過程で、次のようなことを学んでいきます。

* メールの送り方
* メールの本文の作成
* メールのテンプレートのカスタマイズ

### メール送り元の名前とメールアドレスの設定

とにかくまずはメールを送ってみるところから始めましょう。  
最初に、送り元の名前とメールアドレスを設定します。 送り元の名前とメー ルアドレスは、個別のメールごとにも設定できますが、 config に設定することで、送信するメール全体で使い回すことができます。

<p class="lang">config/mail.php（送り元メー ルアドレス設定部分）</p>
```
    'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'hello@example.com'),
        'name' => env('MAIL_FROM_NAME', 'Example'),
    ],
```


env() の第二引数は、.envファイルで設定されていない場合の初期値です。2つとも.envで設定されているため、必要に応じて.env「MAIL_FROM_ADDRESS」や「MAIL_FROM_NAME」を変更しましょう。現状では、送り元のメールアドレスは 下記の.envに設定した「<span class="bold">info@example.com</span>」、名前は.envでの「<span class="bold">${APP_NAME}</span>」、つまりWebアプリケーション名が使用されます。
![](upload/mail_from_address.png ".env"){.fig-top}


### 送信内容の設定

次にMailの送信内容を決めるMailableクラスを作っていきます。  
Mailableクラスは、Mailの送信元、送信先、タイトル、本文など送信するメールについての情報を持つクラスです。まずはartisanコマンドでMailableクラスを追加します。

<p class="tmp cmd"><span>コマンド</span>Mailableクラスを追加</p>
```
sail artisan make:mail NewUserIntroduction
```
![](upload/Mailableクラスを追加.png)

これでapp/Mail/NewUserIntroduction.phpのファイルが生成されます。このクラスは、Mailableクラスを継承して作られています 。
![](upload/NewUserIntroduction.phpのファイルが生成.png){.photo-border}


<p class="lang">app\Mail\NewUserIntroduction.php（デフォルト）</p>
```
<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class NewUserIntroduction extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'New User Introduction',
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'view.name',
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
```

Mailableクラスを継承しているクラスは、メール送信に必要なクラスが基本的にはすべて実装されています。タイトル、本文を設定してメールの実装をしていきましょう。次のように変更します。


<p class="tmp list"><span>リスト</span>app/Mail/NewUserIntroduction.php</p>
```
<?php

namespace App\Mail;

use App\Models\User;//追加
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NewUserIntroduction extends Mailable
{
    use Queueable, SerializesModels;

    public $subject = '新しいユーザーが追加されました！'; //追加

		～省略～

    public function content(): Content
    {
        return new Content(
            view: 'email.new_user_introduction',
        );
    }
		
		～省略～
}
```
メールの本文は、「resources/views/email」フォルダを作り、そこに「new_user_introduction.blade.php」ファイルを作成して、メールの本文を書き込みます。

<p class="tmp list"><span>リスト</span>resources/views/email/new_user_introduction.blade.php</p>
```
新しいユーザーが追加されました！
```

### メールの送信

では、これでメールを送ってみましょう。  
今回のメールは、すでに登録済みのユーザーに新しいユーザーが追加されたことを通知するメールです。ユーザーの登録完了の処理は「app/Http/Controllers/Auth/<span class="red">RegisteredUserController.php</span>」に書かれています。ここにメール送信の処理を足していきます。  
メールを送信する時にはMailerクラスを使います。Illuminate\ Contracts\Mail\MailerInterface をメソッドインジェクションします。送信先は「<span class="bold">test@example.com</span>」というメールアドレスにしました。


<p class="tmp list"><span>リスト</span>app/Http/Controllers/Auth/RegisteredUserController.php</p>
```
<?php

namespace App\Http\Controllers\Auth;

～省略～
use App\Mail\NewUserIntroduction;//追加
use Illuminate\Contracts\Mail\Mailer;//追加

class RegisteredUserController extends Controller
{

～省略～

    public function store(Request $request, Mailer $mailer) { //「Mailer $mailer」を追加
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        event(new Registered($user));

        Auth::login($user);

        // メールの送信処理を追加
        $mailer->to('test@example.com')
            ->send(new NewUserIntroduction());

        return redirect(RouteServiceProvider::HOME);
    }
}
```

これで<http://localhost/register>からユーザ登録してみます。

ユーザ名　やまだ  
Email　yamada@test.ne.jp  
Password　yamada0808

<http://localhost:8025/>にアクセスして、下記をクリックして本文を開くと
![](upload/New_User_Introductionユーザー登録.png){.photo-border}
　↓　本文内容
 ![](upload/New_User_Introductionユーザー登録本文.png){.photo-border}

これで、メールを送信するまでの基本的な流れがわかりました。  
次にこのメールをカスタマイズしながら、新規登録ユーザーを紹介する機能を作っていきます。

## メールにデータを渡す

メールを<span class="red">複数のユーザー</span>に送る部分を書いていきます。  
先ほどの例ではtest@example.comにのみメールを送っていましたが、ここからはすでに登録済みのユーザー全員に向けてメールを送ってみます。また、メールの送り先に合わせて本文も変えてあげましょう。  
まず、登録済みのユーザーを取得して、全員にメールを送る部分を書いていきます 。


<p class="tmp list"><span>リスト</span>app/Http/Controllers/Auth/RegisteredUserController.php（store関数全体）</p>
```
public function store(Request $request, Mailer $mailer)
{

～省略～

	// メールの送信処理を追加
	$allUser = User::get();
	foreach ($allUser as $user) {
		$mailer->to($user->email)
			->send(new NewUserIntroduction());
	}

	return redirect(RouteServiceProvider::HOME);
}
```
これで全員にメールが送られるようになります。  
次にメールに送信先のユーザーのデータを渡していきましょう。まずは NewUserIntroductionクラスがUserクラスのデータを受け取れるように変更していきます。

<p class="tmp list"><span>リスト</span>app/Mail/NewUserIntroduction.php</p>
```
<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NewUserIntroduction extends Mailable
{
    use Queueable, SerializesModels;

    public $subject = '新しいユーザーが追加されました！';
    public User $toUser;//追加
    public User $newUser;//追加

	～省略～

    //追加変更
    public function __construct(User $toUser, User $newUser)
    {
        $this->toUser = $toUser;
        $this->newUser = $newUser;
    }

	～省略～
}
```

次に送信部分を変更して、データを渡すようにしています。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Auth/RegisteredUserController.php</p>
```
	･･･省略･･･
   /**
     * Handle an incoming registration request.
     * …省略…
     */
    public function store(Request $request, Mailer $mailer)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);

        $newUser = User::create([ //$newUserに変更
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        event(new Registered($newUser));//「$newUser」追加

        Auth::login($newUser);//「$newUser」追加

        $allUser = User::get();
        foreach ($allUser as $user) {
            $mailer->to($user->email)
                ->send(new NewUserIntroduction($user, $newUser));//「$user, $newUser」追加
        }

        return redirect(RouteServiceProvider::HOME);
    }
```

最後に、メール本文を変更します。メールを受け取るユーザの名前を表示して、その人宛てだとわかるようにしてあげましょう。

<p class="tmp list"><span>リスト</span>resources/views/email/new_user_introduction.blade.php</p>
```
{{ $toUser->name }}さんこんにちは！新しく{{ $newUser->name }}さんが参加しましたよ！
```

メール文章中の変数はmailableクラスを継承したクラスのプロパティをそのまま使うことができます。  
今回でいうと<span class="red">$toUser</span>と<span class="red">$newUser</span>はメールの文章でそのまま使えます。

では<http://localhost/register>から新規に登録してみましょう。  
登録してMailPitを開くと、「新しい参加者が追加されました」という複数のメールが届いているのが確認できます。
![](upload/新しい参加者が追加されました複数送信.png){.photo-border}
文章には、メールの送り先のユーザー名と新しく参加したユーザー名が追記されています。
![](upload/山田さんこんにちは新しく伊藤さんが参加しましたよ.png){.photo-border}

これでメールにデータを渡して使う方法がわかりしました。より複雑なメールでも、基本的にはこのようにデータを受け渡せば問題ありません。

※Dokerを落としたあと、Mailpitを開くとメールが表示されません。再度新しくregisterで登録するとメールが送信され表示されます。

## メールの見た目をカスタマイズする

Laravelのメールの機能には、リッチなUIを提供するための機能も豊富に用意されており、HTMLメールなどもかんたんに作ることができます。

### Markdown でメールを記述する

LaravelのHTMLメールのUIはMarkdown 形式のフォーマットで記述することができます。これが自動的にHTMLに変換され、HTMLメールとしてユーザーに送信されます。  
まず、先ほどのメールをMarkdown形式に書き換えてみます。

<p class="tmp list"><span>リスト</span>resources/views/email/new_user_introduction.blade.php</p>
```
@component('mail::message')

# 新しいユーザーが追加されました！

{{ $toUser->name }}さんこんにちは！

新しく{{ $newUser->name }}さんが参加しましたよ！

@endcomponent
```

この@componentの部分はWebページのBladeテンプレートと同じです。'mail::message'の部分はLaravelのフレームワークが提供しているメール用のコンポーネントの名前です。  
次に、Markdown形式のviewを渡すときはそのことを明示する必要がありますので、メールクラスのviewのところを<span class="red">Markdown</span>に変更します。

<p class="tmp list"><span>リスト</span>app/Mail/NewUserIntroduction.php　変更が必要</p>
```
<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NewUserIntroduction extends Mailable
{
    use Queueable, SerializesModels;

    public $subject = '新しいユーザーが追加されました！';
    public User $toUser;
    public User $newUser;


    public function __construct(User $toUser, User $newUser)
    {
        $this->toUser = $toUser;
        $this->newUser = $newUser;
    }

	//追加
	public function content(): Content
	{
			return new Content(
					markdown: 'email.new_user_introduction',
			);
	}
}
```

これでメールを送ってみると、HTMLメールとしてメールが送られるはずです。

![](upload/HTMLメールとしてメールが送られる.png){.photo-border}

### スタイルをカスタマイズする

実際にサービスを運営する際は、Laravelのメールのスタイルでは満足できないことももちろんあるでしょう。そんなときはメールのスタイルをカスタマイズしましょう。  
スタイルをカスタマイズするために、Laravelフレームワークのソースコードの一部を自分のプロジェクトにコピーしてきます。これには「vendor: publish」コマンドを使います。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan vendor:publish --tag=laravel-mail
```
![](upload/sailartisanvendorpublish.png)

これにより、「resources/views/vendor/mail」以下にファイルがコピーされているのが確認できると思います。

![](upload/sailartisanvendorpublishvファイルがコピー.png){.photo-border}

このファイル群をカスタマイズしていきます。  
まずヘッダーの部分を変更します。resources/views/vendor/mail/ html/header.blade.php を変更して、Laravelのロゴの部分を自分のサービス名に変えてみます。


<p class="lang">resources/views/vendor/mail/ html/header.blade.php（ロゴ名を追加）</p>
```
@props(['url'])
<tr>
<td class="header">
<a href="{{ $url }}" style="display: inline-block;">
@if (trim($slot) === 'Laravel')
<img src="https://laravel.com/img/notification-logo.png" class="logo" alt="Laravel Logo">
<span>つぶやきアプリ</span>
@else
{{ $slot }}
@endif
</a>
</td>
</tr>
```
`<span>つぶやきアプリ</span>`を追加しました。

次にコンポーネントのスタイルを変えてみます。 「resources/views/ vendor/mail/html/theme/default.css」を変更して、文字の色、サイズや 背景色等、好きなように変えることができます。  
今回は背景の色を変更してみます。 「 #edf2f7」 の部分を 「 #fee3cf」に置換してみてください 。

<p class="tmp list"><span>リスト</span>resources/views/vendor/mail/html/themes/default.css</p>
```
.wrapper {
    …省略…
    background-color: #fee3cf;
    …省略…
}

.body {
    …省略…
    background-color: #fee3cf;
    border-bottom: 1px solid #fee3cf;
    border-top: 1px solid #fee3cf;
    …省略…
}

.panel-content {
    background-color: #fee3cf;
    color: #718096;
    …省略…
}
```

これで、全体の背景やパネルの背景が変わりました。

![](upload/全体の背景やパネルの背景が変わりました.png){.photo-border}

タイトルやスタイルの変更でこのようにメールをカスタマイズすることができます。  
ただし、HTMLメールでは対応しているCSSに制限があります。 受け取り側のメールクライアントによりますが、基本的にWebページのCSSほどには 高機能ではないので、 その点に注意して開発しましょう。






