
# PHP Extension Pack

Includes the most important extensions to get you started with PHP development in Visual Studio Code.

|              |         |
|--------------|---------|
| Debugger     | [![vs marketplace](https://img.shields.io/vscode-marketplace/v/xdebug.php-debug.svg?label=vs%20marketplace)](https://marketplace.visualstudio.com/items?itemName=xdebug.php-debug) [![downloads](https://img.shields.io/vscode-marketplace/d/xdebug.php-debug.svg)](https://marketplace.visualstudio.com/items?itemName=xdebug.php-debug) [![rating](https://img.shields.io/vscode-marketplace/r/xdebug.php-debug.svg)](https://marketplace.visualstudio.com/items?itemName=xdebug.php-debug) |
| IntelliSense | [![vs marketplace](https://img.shields.io/vscode-marketplace/v/zobo.php-intellisense.svg?label=vs%20marketplace)](https://marketplace.visualstudio.com/items?itemName=zobo.php-intellisense) [![downloads](https://img.shields.io/vscode-marketplace/d/zobo.php-intellisense.svg)](https://marketplace.visualstudio.com/items?itemName=zobo.php-intellisense) [![rating](https://img.shields.io/vscode-marketplace/r/zobo.php-intellisense.svg)](https://marketplace.visualstudio.com/items?itemName=zobo.php-intellisense) |
