<?php
$file = file_get_contents('scss/style.scss');//scssファイルの内容を取得
$mark = file_get_contents('markdown.md');//markdownファイルの内容を取得
var_dump($mark);
//file_put_contents('markdown.md', $file);//markdown.mdファイルにデータを書き込む

    //$fruits = 'りんご,オレンジ,メロン,りんご';
     
    $replace = str_replace('### chapter1', $file, $mark);//読み込んだデータを置換する

    //var_dump($replace);

    file_put_contents('markdown.md', $replace);//markdown.mdファイルにデータを書き込む

?>
