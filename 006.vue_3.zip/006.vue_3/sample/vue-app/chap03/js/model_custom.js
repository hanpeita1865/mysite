Vue.createApp({
  data() {
    return {
      mails: [],
    };
  }
}).mount('#app');
