const app = Vue.createApp({});
app.config.compilerOptions.isCustomElement = tag => tag.startsWith('my-');//-----(2)
app.mount('#app');