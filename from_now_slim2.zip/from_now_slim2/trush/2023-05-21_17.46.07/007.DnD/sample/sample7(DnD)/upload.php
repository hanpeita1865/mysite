<?php
//フォルダがなければ作成する
if(!file_exists('upload')){
	mkdir('upload');
}

$file = array();

if (!empty($_FILES['file'])){  
	foreach ($_FILES['file'] as $string=>$naiyou){  
		foreach ($naiyou as $key=>$val){  
			$file[$key][$string] = $val;  
		}  
	}  
	foreach ($file as $key=>$val){  
		move_uploaded_file($val['tmp_name'], 'upload/'.$val['name']);  
	}  
}  
?>  
