*[page-title]:初期化・追加・変更について

## 配列の初期化と代入 ##
<p class="tmp"><span>書式</span>配列の初期化</p>
```
$array = array();
または
$array = [];
```

### 添字配列の例
```
$array = array('りんご', 'もも', 'なし'); // キーは0から順に0,1,2が割り振られる
または
$array = ['りんご', 'もも', 'なし'];
```

### 連想配列の例（キーを指定してセットする）
```
$array = array('apple'=>'りんご', 'peach'=>'もも', 'pear'=>'なし');
または
$array = ['apple'=>'りんご', 'peach'=>'もも', 'pear'=>'なし'];
```

### 部分的にキーを指定することもできる
```
$array = array('バナナ', 'apple'=>'りんご', 'peach'=>'もも', 'pear'=>'なし', 'みかん');
または
$array = ['バナナ', 'apple'=>'りんご', 'peach'=>'もも', 'pear'=>'なし', 'みかん'];
```

この時、中身をprint_r($array);により確認すると
```
Array
(
    [0] => バナナ
    [apple] => りんご
    [peach] => もも
    [pear] => なし
    [1] => みかん
)
```
となっています。



## 配列に要素を追加する方法

配列に要素を追加する３つの方法

### ① array_push()を使用して追加する方法

<span class="green bold">array_push()</span>は、配列の末尾に要素を追加する関数です。  

<p class="tmp"><span>書式1</span>array_push()</p>
```
array_push( 要素を追加する配列 , 追加したい要素1 [, 追加したい要素2 ] )
```
第3引数以降は省略可能です。第3引数以降にも値を渡すことで複数の要素を一度に追加することができます。

<div class="exp">
	<p class="tmp"><span>例1</span>添字配列の例</p>
</div>
<iframe src="https://paiza.io/projects/e/AA4HFOBqUEuPXQjwni8k_Q?theme=twilight" width="100%" height="550" scrolling="no" seamless="seamless"></iframe>


### ② [] を使用して追加する方法

配列のキーを入れる「[]」ですが、キーを空のままにすることで自動的に要素が配列の末尾に追加されます。  

<p class="tmp"><span>書式2</span></p>
```
追加したい配列[] ＝ 要素
```

この場合はarray_push()と違って一度にひとつの要素しか一度に追加できませんが、非常に簡潔に記述することができます。

<div class="exp">
	<p class="tmp"><span>例2</span>添字配列での追加</p>
</div>
<iframe src="https://paiza.io/projects/e/gZJsVux0-1xFfNXToBAAqQ?theme=twilight" width="100%" height="550" scrolling="no" seamless="seamless"></iframe>

#### 連想配列での追加方法

<div class="exp">
	<p class="tmp"><span>例</span>キーを指定しての追加</p>
</div>
<iframe src="https://paiza.io/projects/e/i5wE_yC7t1_bRKm9Mo4pOA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

#### 配列と連想配列のセットの追加方法

<div class="exp">
	<p class="tmp"><span>例</span>連想配列一式の追加</p>
<iframe src="https://paiza.io/projects/e/aHj_9Eegqf6b_IDFdc9KTw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

### ③ array_merge()を使用して追加する方法

<span class="green bold">array_merge()</span>は複数の配列（array）を連結する関数ですが、この関数でも配列に要素を追加することができます。

<p class="tmp"><span>書式3</span>array_merge()</p>
```
追加したい配列 = array_merge( 追加したい配列 [, 追加したい配列2... ] )
```

第2引数以降に配列を指定することで複数の配列を同時に連結することができます。  
また、array_merge()では連結後の配列を返し、元の配列は書き換えられないので注意してください。

<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
<iframe src="https://paiza.io/projects/e/E6l63-2CKV91Xy-NtmXNZw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless">
</iframe>

## 連想配列の値の変更

### 指定キーの値を変更
次のソースコードでは、連想配列のキー”strawberry”を指定して「**イチゴ**」を「**苺**」に値を変更します。

<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
```
<?php 
 
$arr = array("banana" => "バナナ", "strawberry" => "イチゴ");
 
// 「イチゴ」を漢字の「苺」に変更する
$arr["strawberry"] = "苺";
 
var_dump($arr);
 
?>
```
<p class="result"><span>結果</span></p>
```
array(2) {
  ["banana"]=>
  string(9) "バナナ"
  ["strawberry"]=>
  string(3) "苺"
}
```
同じキー”strawberry”の値「イチゴ」が「苺」変わりました。

### ループ条件の中で値を変更

連想配列をforeachでループしながら条件に一致した場合、値が変更されるようにソースコードを書いてみます。

<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
```
<?php 
 
$arr = array("banana" => "バナナ", "strawberry" => "イチゴ");
 
// 連想配列をループしてキーが「strawberry」なら値を「苺」に変更する
foreach ($arr as $key => $val) {
    if ($key == "strawberry") {
        $arr[$key] = "苺";
    }
}
 
var_dump($arr);
 
?>
```
<p class="result"><span>結果</span></p>
```
array(2) {
  ["banana"]=>
  string(9) "バナナ"
  ["strawberry"]=>
  string(3) "苺"
}
```

## 連想配列のキーを変更する方法

参考サイト
: [PHPで連想配列のキーを変更する方法を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/33706)

PHPで連想配列のキーを変更する方法は色々とありますが、今回は<span class="green bold">array_values()</span>と<span class="green bold">array_combine()</span>を使用する方法をご紹介します。

#### array_values()
PHPの<span class="green bold">array_values()</span>は、配列の値だけを抽出する関数です。  
この関数を使用して、もとの連想配列から値だけを抽出します。

<p class="tmp"><span>書式</span>array_values</p>
```
array_values($配列)
 ```

array_values()に引数で連想配列を渡すと、値だけを抽出し、配列で返却してくれます。  
まずは、値だけを抽出し、新しいキー名をつける準備をします。


<div class="exp">
	<p class="tmp"><span>例</span>array_valuesを使って、値を抽出</p>
</div>
```
<?php
    $fruits = ["apple" => "りんご", "lemon" => "れもん", "melon" => "メロン"];
    $array = array_values($fruits);
    print_r($array);
?>
```

<p class="result"><span>結果</span></p>
```
Array
(
    [0] => りんご
    [1] => れもん
    [2] => メロン
)
```

#### array_combine()
PHPの<span class="green bold">array_combine()</span>は、第一引数に渡した配列の値を「キー」として、第二引数に渡した配列の値を「値」にして、連想配列を作成する関数です。

第一引数に新しいキー名を値に持つ配列を渡し、第二引数にarray_values()で抽出した値を持つ配列を渡すことで、「<span class="red bold">連想配列のキーの変更</span>」が完了します。

<p class="tmp"><span>書式</span>array_combine</p>
```
array_combine($キー名を含む配列, $値を含む配列)
```

上記のように引数を渡すと、キー名と値をマッピングして連想配列を返却します。
<div class="exp">
	<p class="tmp"><span>例</span>array_combine</p>
</div>
```
<?php
    $keys = ["red", "yellow", "green"];
    $values = ["りんご", "れもん", "メロン"];
    $array = array_combine($keys, $values);
    
    print_r($array);
?>
```

<p class="result"><span>結果</span></p>
```
Array
(
    [red] => りんご
    [yellow] => れもん
    [green] => メロン
)
```

それでは、実際にarray_values()とarray_combine()を使用して、連想配列のキーを変更する例を見ていきましょう。
<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
<iframe src="https://paiza.io/projects/e/l8VOw4d2cz_vwUFuVAU6Og?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

実行結果の上のArrayが最初に作成した連想配列で、下のArrayがキーを変更した連想配列です。  
キーが変更されていることが確認できると思います。