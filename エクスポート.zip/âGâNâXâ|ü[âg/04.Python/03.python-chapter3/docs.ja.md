---
title: 標準ライブラリーを使ってみる
media_order: 'cmd_01.png,cmd_02.png,cmd_03.png,cmd_04.png,cmd_05.png,cmd_06.png,dir_01.png,dir_02.png,dir_03.png,dir_04.png,pycode2.png,pycode1.png'
taxonomy:
    category:
        - docs
visible: true
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:12px 0 12px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
</style>


## 目次

1. [モジュール](library-preparation01)
2. [日時を扱うモジュール](library-preparation01-2)
3. [プログラムの実行時間を計測する](library-preparation01-3)
4. [コマンドライン引数やキーボードからの入力を受け取る](library-preparation01-4)
5. [ファイルの入出力](library-preparation01-5)
6. [JSONを利用したデータ交換](library-preparation01-6)
7. [正規表現を扱う](library-preparation01-7)
