<?php require '../header.php'; ?>
<?php
echo rand(1, 6);
?>
<?php require '../footer.php'; ?>
