---
title: 'php artisan make:authが使えない問題の対処法'
media_order: '8082b0df382f.png,auth_artisan1.png,auth_artisan2.png'
taxonomy:
    category:
        - docs
---

## はじめに
Laravelの６系から php artisan maek:auth コマンドを使用すると下記画像のメッセージが出てしまいます。

![](8082b0df382f.png)

## 何が変わったのか
Laravel6系から認証機能（Laravel/ui）が別パッケージとして管理されるようになりました。そのためまずはcomposerでパッケージをインストールしましょう。

<p class="tmp cmd"><span>コマンド1</span>composerでlaravel/uiのインストール</p>
````
composer require laravel/ui
```
![](auth_artisan1.png)

<p class="tmp cmd"><span>コマンド2</span>コンテナ内で php artisanコマンドを実行</p>
```
php artisan ui vue --auth
```

![](auth_artisan2.png)

これでLaravel６系以上でもLaravelデフォルトの認証機能を使うことができるようになります。