<?php
namespace SocymSlim\SlimMiddle\Services;
use PDO;
use PDOException;
use SocymSlim\SlimMiddle\Config\AppConfig;

use Spatie\Async\Pool;

class FolderService {
    
    protected $editService;
    private AppConfig $config;

    public function __construct(EditService $editService, AppConfig $config)
    {
        $this->editService = $editService;
        $this->config = $config;
    }


    //----------------------//
    //     並べ替え確定   
    //---------------------//

    //会社で使用
    public function sortTogether(array $sortHistory, string $pageDir): void {
        
        $folderObj = $this->globAll($pageDir);

        foreach ($sortHistory as $key => $item) {
            
            // 現在の実際のパスを取得
            $from = $folderObj[$item['fdName']] ?? null;
            $to   = $item['to'];

            if ($from === null) {
                error_log(
                    "[FolderService] Source folder not found: {$item['fdName']}"
                );
                continue;
            }

            // 同じ場所への移動は不要
            if ($from === $to) {
                unset($sortHistory[$key]);
                continue;
            }

            $success = false;

            // 最大3回試行
            for ($i = 0; $i < 3; $i++) {
                
                if (rename($from, $to)) {
                    $success = true;
                    unset($sortHistory[$key]);
                    break;
                }
                
                error_log(
                    "[FolderService] Rename retry " . ($i + 1) .
                    ": {$from} → {$to}"
                );
            
                sleep(1);
            }

            if (!$success) {
                error_log(
                    "[FolderService] Rename failed: {$from} → {$to}"
                );
            }

            // ファイル状態キャッシュをクリアして、
            // 現在のフォルダ構成を再取得
            clearstatcache();
            $folderObj = $this->globAll($pageDir);
        }

        // 失敗した移動が残っている場合
        if (!empty($sortHistory)) {

            error_log(
                '[FolderService] Some folders could not be moved: ' .
                print_r($sortHistory, true)
            );
        }
    }
    

    //---------------------------------
    // 並べ替え後のフォルダ番号の整理
    //---------------------------------

    public function dirNumReplace(array $menuArray, array $folderObj): void
    {
        $menuObj = [];

        // メニュー配列から番号なしフォルダ名を作成
        foreach ($menuArray as $val) {
            $dirArray = explode('/', $val);
            $lastDir = end($dirArray);
            $folderNoNum = preg_replace('/^\d{3}\./', '', $lastDir);
            $menuObj[$folderNoNum] = $lastDir;
        }

        // 実際のフォルダとの突合
        foreach ($folderObj as $key => $dir) {
            if (!isset($menuObj[$key])) {
                continue;
            }

            $menuDirAry = explode('/', $menuObj[$key]);
            $menuFdName = end($menuDirAry);

            $dirArray1 = explode('/', $dir);
            $pagesFdName = end($dirArray1);

            if ($pagesFdName !== $menuFdName) {
                array_pop($dirArray1); // 最後を削除
                $dirArray1[] = $menuFdName; // 新しいフォルダ名を追加
                $newPath = implode('/', $dirArray1);

                if (!rename($dir, $newPath)) {
                    error_log("[FolderService] Rename failed: {$dir} → {$newPath}");
                }
            }
        }
    }
    
    
    //-------------------------
    //   フォルダ一覧を取得
    //-------------------------

    public function getFolderComp(string $dir='../pages'): array {
        return $this->globAll($dir);
    }


    //---------------------------------
    // pages配下のフォルダ一覧（再帰）
    //---------------------------------

    private function globAll(string $folder, array &$folderArray = []): array {
        $folderObj = [];

        if (!is_file($folder)) {
            $res = glob($folder . '/*');

            foreach ($res as $f) {
                $dirArray = explode('/', $f);
                $lastDir = end($dirArray);

                if (preg_match('/^\d{3}\./', $lastDir)) {
                    $folderNoNum = preg_replace('/^\d{3}\./', '', $lastDir);
                    $folderObj[$folderNoNum] = $f;
                    $folderArray[] = $f;

                    // 再帰
                    $folderObj = array_merge($folderObj, $this->globAll($f, $folderArray));
                }
            }
        }

        return $folderObj;
    }
    
    

    //-------------------------------------
    // $folderObjのキャッシュファイル存在判定
    //-------------------------------------
    
    public function getFolderCompCached(string $dir = '../pages'): array
    {
        $cacheFile = $dir === '../pages'
            ? '../cache/folder.php'
            : '../cache/manual_folder.php';

        if (file_exists($cacheFile)) {
            return include $cacheFile;
        }

        $data = $this->getFolderComp($dir);

        file_put_contents(
            $cacheFile,
            '<?php return ' . var_export($data, true) . ';'
        );

        return $data;
    }

    

    //-------------------------
    // パス一覧を取得
    //-------------------------
    public function getFolderPathComp(string $dir = '../pages', string $baseUrl/*string $basePath*/): array
    {
        // $baseUrl = $basePath . '/public/pages/';
        return $this->globPathAll($dir, $baseUrl);
    }
    
    

    //---------------------------------
    // pages配下のフォルダ一覧（再帰）
    //---------------------------------
    private function globPathAll(
        string $folder,
        string $baseUrl,
        array &$folderArray = []
    ): array {
        $folderObj = [];

        if (!is_file($folder)) {
            $res = glob($folder . '/*', GLOB_ONLYDIR);

            foreach ($res as $f) {

                // フォルダ名取得
                $lastDir = basename($f);

                // 001.guide 形式のみ対象
                if (preg_match('/^(\d{3})\.(.+)$/', $lastDir, $m)) {

                    $folderNoNum = $m[2]; // guide
                    $folderArray[] = $f;

                    // URL用パス生成
                    $urlPath = rtrim($baseUrl, '/') . '/' . $folderNoNum . '/';

                    $folderObj[$folderNoNum] = [
                        'fs'  => $f,
                        'url' => $urlPath,
                    ];

                    // 再帰
                    $child = $this->globPathAll($f, $urlPath, $folderArray);
                    $folderObj = array_merge($folderObj, $child);
                }
            }
        }

        return $folderObj;
    }


        

    //-----------------------------
    //   タイトルとパスの一覧を取得　まだ残しておく
    //-----------------------------

    public function getTitlePathList(string $dir='../pages'): array {
        
        $basePath = $this->config->basePath;
        
        return $this->globTitlePath($dir, $basePath);
    }    


    //-------------------------------------
    // $titlePathのキャッシュファイル存在判定　追加
    //-------------------------------------
    public function getTitlePathListCached(string $dir='../pages'): array {
        
        $cacheFile = '../cache/titlePath.php';
        
        $basePath = $this->config->basePath;

        if (file_exists($cacheFile)) {
            return include $cacheFile;
        }
        
        // 元データを取得
        $cacheData = $this->globTitlePath($dir, $basePath);

        // PHPファイルとして保存
        $cacheContent = '<?php return ' . var_export($cacheData, true) . ';';

        file_put_contents($cacheFile, $cacheContent);

        return $cacheData;
        
        // return $this->globTitlePath($dir, $basePath);
    }


    //-------------------------------------
    // $titlePathのキャッシュファイル削除　テスト
    //-------------------------------------

    public function clearTitlePathCache(): void
    {
        $cacheFile = $this->config->rootPath . '/cache/titlePath.php';

        if (file_exists($cacheFile)) {
            unlink($cacheFile);
        }
    }


    //-------------------------------------
    // 配下のタイトルとパスの一覧（再帰）
    //-------------------------------------
        
    private function globTitlePath(string $folder, string $basePath): array {
        $list = [];

        // ファイルであれば処理しない
        if (is_file($folder)) {
            return $list;
        }

        // ディレクトリ一覧取得
        $items = glob($folder . '/*');

        foreach ($items as $f) {

            $dirArray = explode('/', $f);
            $lastDir = end($dirArray);

            // 例: 001.xxx のフォルダだけ対象
            if (!preg_match('/^\d{3}\./', $lastDir)) {
                continue;
            }

            $title = '';
            $subCategory = '';

            // タイトル取得
            if (file_exists($f . '/markdown.md')) {
                $md = file_get_contents($f . '/markdown.md');

                // if (preg_match("/^\*\[page-title\]:\s*(.+)/m", $md, $match)) {
                //     $title = trim($match[1]);
                // }
                
                // page-title取得
                preg_match('/^\*\[page-title\]:\s*(.+)$/m', $md, $matchTitle);
                $title = $matchTitle[1] ?? '';

                // category取得
                preg_match('/^\*\[sub-category\]:\s*(.+)$/m', $md, $matchCategory);
                $subCategory = $matchCategory[1] ?? '';
            }
            
            // パス整形
            $path = str_replace('../pages/', '', $f) . '/';
            $pathRe = preg_replace('/^\d{3}\./', '', $path);
            $pathRe = preg_replace('/\/\d{3}\./', '/', $pathRe);
            $converted = $basePath . '/public/pages/' . $pathRe;           

            $list[] = [
                'title' => $title,
                'path'  => $converted,
                'subCategory' => $subCategory,//追加
            ];

            // ★ 再帰（戻り値をマージ）
            $childList = $this->globTitlePath($f, $basePath);
            $list = array_merge($list, $childList);
        }

        return $list;
    }
        
    
 
    //--------------------------------------------------
    // サブページフォルダを上位階層に移動する（削除で使用）
    //--------------------------------------------------
        
    public function subpageMove(
        string $delFolder,
        string $folderName,
        string $pageArea
    ): array {

        $delAry = explode('/', $delFolder);
        $delFd = end($delAry);
        $num = explode('.', $delFd)[0];

        array_pop($delAry);
        $parent = implode('/', $delAry);

        $movedFiles = $this->moveSubpages(
            $delFolder,
            $delFd,
            $num,
            $parent
        );

        // サブページ移動に失敗した場合
        if ($movedFiles === false) {
            throw new \RuntimeException(
                'サブページの移動に失敗しました。'
            );
        }

        // DBのレコード削除
        $db = $this->editService->db();

        $sql = $db->prepare(
            'DELETE FROM page_list
            WHERE fdName = :fdName
            AND page_area = :pageArea'
        );

        $sql->bindValue(':fdName', $folderName);
        $sql->bindValue(':pageArea', $pageArea);

        if (!$sql->execute()) {
            throw new \RuntimeException(
                "{$folderName} のDBからのレコード削除に失敗しました。"
            );
        }

        return $movedFiles;
    }

    

    //------------------------------------------
    // 実際にサブページを移動する処理（内部専用）
    //------------------------------------------

    private function moveSubpages(
        string $delFolder,
        string $delFd,
        string $num,
        string $parent
    ) {
        if (!is_dir($delFolder)) {
            error_log(
                "[FolderService] 指定フォルダが存在しません: {$delFolder}"
            );

            return false;
        }

        $files = glob($delFolder . '/*');
        $movedFiles = [];

        foreach ($files as $file) {

            $dirArray = explode('/', $file);
            $lastDir = end($dirArray);

            if (preg_match('/^\d{3}\./', $lastDir)) {

                $newPath = preg_replace(
                    '/'.preg_quote($delFd, '/').'\/\d{3}\./',
                    $num . '.',
                    $file
                );

                if (!rename($file, $newPath)) {

                    error_log(
                        "[FolderService] ファイル移動失敗: {$file} → {$newPath}"
                    );

                    return false;
                }

                $movedFiles[] = [
                    'old' => $file,
                    'new' => $newPath
                ];
            }
        }

        return $movedFiles;
    }


    //--------------------------------------
    //  削除フォルダをtrushにバックアップ 
    //--------------------------------------
    
    public function trushBackup(string $delFolder): void {
        date_default_timezone_set('Asia/Tokyo');
        $dateTime = date('Y-m-d_H.i.s');

        $trushDir = '../trush/' . $dateTime;
        if (!file_exists($trushDir)) {
            mkdir($trushDir, 0777, true);
        }

        $delDir = str_replace('pages', 'trush/' . $dateTime, $delFolder);
        if (!file_exists($delDir)) {
            mkdir($delDir, 0777, true);
        }

        $this->copyDirectory($delFolder, $delDir);
    }

    

    //--------------------------------
    //   ディレクトリを再帰的に削除
    //--------------------------------
    public function removeDirectory(string $dir): bool {
        if (!is_dir($dir)) {
            return false;
        }

        $files = array_diff(scandir($dir), ['.', '..']);

        foreach ($files as $file) {

            $path = $dir . DIRECTORY_SEPARATOR . $file;

            if (is_dir($path)) {

                $this->removeDirectory($path);

            } else {

                if (!unlink($path)) {
                    return false;
                }
            }
        }

        return rmdir($dir);
    }

    

    //-------------------------------
    //   ディレクトリを再帰的にコピー
    //-------------------------------
    
    private function copyDirectory(string $src, string $dst): void
    {
        if (!file_exists($dst)) {
            if (!mkdir($dst, 0777, true)) {
                throw new \RuntimeException(
                    "コピー先ディレクトリを作成できませんでした: {$dst}"
                );
            }
        }

        $files = array_diff(scandir($src), ['.', '..']);

        foreach ($files as $file) {

            $srcPath = "$src/$file";
            $dstPath = "$dst/$file";

            if (is_dir($srcPath)) {

                $this->copyDirectory($srcPath, $dstPath);

            } else {

                if (!copy($srcPath, $dstPath)) {
                    throw new \RuntimeException(
                        "ファイルのコピーに失敗しました: {$srcPath}"
                    );
                }
            }
        }
    }

    // private function copyDirectory(string $src, string $dst): void {
    //     if (!file_exists($dst)) {
    //         mkdir($dst, 0777, true);
    //     }
        

    //     $files = array_diff(scandir($src), ['.', '..']);
    //     foreach ($files as $file) {
    //         $srcPath = "$src/$file";
    //         $dstPath = "$dst/$file";

    //         if (is_dir($srcPath)) {
    //             $this->copyDirectory($srcPath, $dstPath);
    //         } else {
    //             copy($srcPath, $dstPath);
    //         }
    //     }
    // }



    //-----------------------------------------------------
    // 同階層フォルダの番号をリセット（001.～の番号振り直し）
    //-----------------------------------------------------
    
    public function numberReset(string $parent): void {
        $parentAry = glob($parent . '/*');
        $num = 1;

        foreach ($parentAry as $val) {
            $valAry = explode('/', $val);
            $lastData = end($valAry);

            if (preg_match('/^\d{3}\./', $lastData)) {
                $name = explode('.', $lastData)[1];      // 例: aaa
                $fdNum = sprintf('%03d', $num);          // 3桁番号
                $fdName = $fdNum . '.' . $name;

                array_pop($valAry);
                array_push($valAry, $fdName);
                $newDir = implode('/', $valAry);

                rename($val, $newDir);
                $num++;
            }
        }
    }
    

    /**
     * 並び替え（フォルダ番号修正）
     * 旧: dirNumReplace
     */
    // public function dirNumReplace(string $parent): void
    // {
    //     $this->numberReset($parent);
    // }
    

    
    //------------------------------------------------------------
    // 対象フォルダを中身ごと削除
    //------------------------------------------------------------

    public function deleteAllFolder(
        string $delFolder,
        array $deleteList,
        string $pageArea
    ): void {

        // 対象のフォルダを削除
        if (!$this->removeDirectory($delFolder)) {
            throw new \RuntimeException(
                "[FolderService] フォルダ削除失敗: {$delFolder}"
            );
        }

        // 親フォルダのパス取得
        $delAry = explode('/', $delFolder);
        array_pop($delAry);
        $parent = implode('/', $delAry);

        // 番号を再設定
        $this->numberReset($parent);

        // DBのレコード削除
        $db = $this->editService->db();

        $sql = $db->prepare("
            DELETE FROM page_list
            WHERE fdName = :fdName
            AND page_area = :page_area
        ");

        foreach ($deleteList as $fdName) {

            $sql->bindValue(':fdName', $fdName, PDO::PARAM_STR);
            $sql->bindValue(':page_area', $pageArea, PDO::PARAM_STR);

            if (!$sql->execute()) {
                throw new \RuntimeException(
                    "DB削除に失敗: {$fdName}"
                );
            }
        }
    }
        
    
    //削除フォルダ一覧
    public function getDeleteTargetFdNames(string $delFolder, string $pageDir): array
    {
        // pages 全体の構造一覧
        $folderObj = $this->getFolderComp($pageDir);

        $deleteList = [];

        foreach ($folderObj as $fdName => $path) {
            // delFolder の配下かどうか判定
            if (strpos($path, $delFolder) === 0) {
                $deleteList[] = $fdName; 
            }
        }

        return $deleteList;
    }


    
  
    //-------------------------------
    //      新規フォルダ作成
    //-------------------------------

    public function createNewFolder(string $newFolder, string $pageDir, string $pageArea): bool {
        // --- 1️. 入力チェック ---
        if (trim($newFolder) === '') {
            throw new \InvalidArgumentException('フォルダ名を入力してください。');
        }

        // 半角英数字記号のみ許可
        if (!preg_match("/^[!-~]+$/", $newFolder)) {
            throw new \InvalidArgumentException('半角英数字記号で入力してください。');
        }

        // --- 2️. pages 直下の最大番号を調べる ---
        // $pageDir = '../pages';
        if (!is_dir($pageDir)) {
            throw new \RuntimeException('pagesディレクトリが存在しません。');
        }

        $pagesGlob = glob($pageDir . '/*', GLOB_ONLYDIR);
        $maxNum = 0;
        
        //修正
        foreach ($pagesGlob as $val) {

            $dirName = basename($val);

            // 例：001.test
            if (preg_match('/^(\d+)\.(.+)$/', $dirName, $m)) {

                $num = (int)$m[1];
                $folderName = $m[2];

                // 最大番号を取得
                if ($num > $maxNum) {
                    $maxNum = $num;
                }

                // 同名フォルダチェック
                if ($folderName === $newFolder) {
                    throw new \RuntimeException(
                        "同名のフォルダ '{$newFolder}' がすでに存在します。"
                    );
                }
            }
        }
        
                
        // --- 3️. 新しい番号とディレクトリ名を作成 ---
        $nextNum = sprintf('%03d', $maxNum + 1);
        $baseDir = "{$pageDir}/{$nextNum}.{$newFolder}";
        
        
        // --- 4. 実際の作成処理 → エラーならロールバック ---
        $db = $this->editService->db();
        $db->beginTransaction();

            try {
            // フォルダ作成
            if (!mkdir($baseDir, 0777, true)) {
                throw new \RuntimeException("フォルダ作成に失敗しました。: {$baseDir}");
            }

            // upload フォルダ作成
            mkdir("{$baseDir}/upload", 0777, true);

            // markdown.md 作成
            $mdPath = "{$baseDir}/markdown.md";
            
            if (!file_put_contents($mdPath, '*[page-title]:メニュー名')) {
                throw new \RuntimeException("{$mdPath} の作成に失敗しました。");
            }

            // -- 5. DBのpage_listテーブルに登録
            // 上書き保存 or 新規登録
            $sql = $db->prepare("INSERT INTO page_list (fdName, title, text, page_area) VALUES (:fdName, :title, :text, :page_area) ON DUPLICATE KEY UPDATE title = VALUES(title), text = VALUES(text)");

            $sql->bindValue(':fdName', $newFolder);
            $sql->bindValue(':title', 'メニュー名');
            $sql->bindValue(':text', '');
            $sql->bindValue(':page_area', $pageArea);
            
            if (!$sql->execute()) {
                throw new \RuntimeException("{$newFolder} のDBへの登録に失敗しました。");
            }
            
            // すべて成功
            $db->commit();      
            
            return true;

        } catch (\Throwable $e) {
            
            // --- DBロールバック ---
            if ($db->inTransaction()) {
                $db->rollBack();
            }

            // ---- ロールバック処理（作成済みフォルダ削除） ----
            if (is_dir($baseDir)) {
                $this->removeDirectory($baseDir);
            }

            throw $e; // 例外をそのまま投げ直す
        }
    }

    
    


    //---------------------
    // ページ名変更
    //---------------------

    public function renameMenu(string $dirName, string $oldMenu, string $newMenu, string $folderName, string $pageDir, string $pageArea): bool
    {
        $targetFile = "{$pageDir}/{$dirName}/markdown.md";

        if (!file_exists($targetFile)) {
            throw new \Exception("ファイルが見つからないか書き込むことができません: {$targetFile}");
        }
        
        // 元の内容をバックアップ
        $originalMd = file_get_contents($targetFile);
        $updatedMd = $originalMd;
        
        // page-title 行を置換
        if (preg_match("/^\*\[page-title\]:\s*(.+)/m", $updatedMd)) {
            $updatedMd = preg_replace(
                "/^\*\[page-title\]:\s*(.+)/m",
                "*[page-title]:{$newMenu}",
                $updatedMd
            );
        } else {
            $updatedMd = "*[page-title]:{$newMenu}\n\n" . $updatedMd;
        }
        
        // --- DB更新（先に行う） ---
        $db = $this->editService->db();
        $db->beginTransaction();
        
        try {
            // page_list の title 更新
            $plSql = $db->prepare("UPDATE page_list SET title = ? WHERE fdName = ? AND page_area = ?");

            if (!$plSql->execute([$newMenu, $folderName, $pageArea])) {
                throw new \RuntimeException("page_list のページ名更新に失敗しました。");
            }
            
            // ▼ ファイル書き込み（最後に行う）
            if (file_put_contents($targetFile, $updatedMd) === false) {
                throw new \RuntimeException("markdown.md の書き込みに失敗しました");
            }            
            
            // DB もファイルも成功
            $db->commit();
            return true;
            
        } catch (\Throwable $e) {

            // ▼ DBロールバック
            $db->rollBack();
            
            // ▼ ファイルが更新されていたら必ず元に戻す
            file_put_contents($targetFile, $originalMd);
        
            error_log($e->getMessage());
            throw $e;            
        }       
    }

    
    
    //--------------------------
    //     フォルダ名変更
    //--------------------------

    public function renameFolder(string $oldDir, string $newDir, string $oldName, string $newName, string $pageDir, string $pageArea): string
    {
        // 入力値バリデーションをここで実施
        $this->validateFolderName($newName);
        
        // 半角英数字記号チェック
        if (!preg_match("/^[!-~]+$/", $newDir)) {
            return "半角英数字記号で入力してください。";
        }
        
        $oldPath = "{$pageDir}/{$oldDir}";
        $newPath = "{$pageDir}/{$newDir}";

        // $oldPath = "../pages/{$oldDir}";
        // $newPath = "../pages/{$newDir}";
        
        if (!file_exists($oldPath)) {
            return "旧フォルダが存在しません: " . realpath($oldPath);
        }
        
        
        $db = $this->editService->db();
        $db->beginTransaction();

        try {
            // DB更新（先に行う！）
            $plSql = $db->prepare("UPDATE page_list SET fdName = ? WHERE fdName = ? AND page_area = ?");
            
            if (!$plSql->execute([$newName, $oldName, $pageArea])) {
                throw new \RuntimeException("page_list のフォルダ名更新に失敗しました。");
            }
  
            $sql = $db->prepare("SELECT * FROM locklist WHERE page = ?");
            $sql->execute([$oldName]);
            $lockCnt = $sql->rowCount();

            if ($lockCnt) {
                $result = $sql->fetch(PDO::FETCH_ASSOC);
                $updateSql = $db->prepare("UPDATE locklist SET page = ? WHERE id_lock = ?");
                if (!$updateSql->execute([$newName, $result['id_lock']])) {
                    throw new \RuntimeException("locklist のフォルダ名更新に失敗しました。");
                }
            }

            // DBコミット
            $db->commit();

        } catch (\Throwable $e) {
            $db->rollBack();
            return "DB更新に失敗しました: " . $e->getMessage();
        }

        
        
        // ---------- ここから rename（最後に行う） ----------
        if (!rename($oldPath, $newPath)) {

            // rename が失敗したので DB を元に戻す（補償トランザクション）
            $db->beginTransaction();

            try {
                $plSql = $db->prepare("UPDATE page_list SET fdName = ? WHERE fdName = ? AND page_area = ?");
                $plSql->execute([$oldName, $newName, $pageArea]);                

                if ($lockCnt) {
                    $result = $sql->fetch(PDO::FETCH_ASSOC);
                    $updateSql = $db->prepare("UPDATE locklist SET page = ? WHERE id_lock = ?");
                    $updateSql->execute([$oldName, $result['id_lock']]);
                }

                $db->commit();

            } catch (\Throwable $e) {
                $db->rollBack();
                return "重大エラー：フォルダ名変更もDB復元も失敗しました。手動修復が必要です。";
            }

            return "フォルダ名変更に失敗したため、DBを元に戻しました。";
        }        
                
        return "フォルダ名を「{$newName}」に変更しました。";
    }
    
    
    /**
     * 🔹 フォルダ名バリデーション
     */
    private function validateFolderName(string $name): void {
        // 空チェック
        if ($name === '') {
            throw new Exception("フォルダ名が空です。");
        }

        // 禁止文字チェック
        if (preg_match('/[.*":?<>\/\\\\]/', $name)) {
            throw new Exception('フォルダ名に使用できない文字（. * " : ? < > / \\）が含まれています。');
        }

        // 半角英数字記号チェック
        if (!preg_match('/^[!-~]+$/', $name)) {
            throw new Exception('英数字以外の文字、または全角文字・空白が含まれています。');
        }
    }
    
    

    //-----------------------------------
    //   アップロードファイル一覧
    //-----------------------------------
        
    public function uploadList(?string $dir = null, ?string $folder = null) {
        
        //更新日付順表示（古い順）
        $sort_by_lastmod = function ($a, $b) {
            return  filemtime($a) - filemtime($b);
        };
        
        if($dir === null){
            // 通常パターン
            $dir = '../pages';
            $folderObj = $this->globAll($dir);
            
            if ($folder === null || !isset($folderObj[$folder])) {
                throw new \InvalidArgumentException('フォルダが不正です');
            }
            
            $folderDir = $folderObj[$folder];
            
        }else{
            // $dir が直接パスとして渡された場合
            $folderDir = $dir;
        }
        
        $totalList = '';

        $files = glob($folderDir . '/upload/*');
        
        usort($files, $sort_by_lastmod);

        if (empty($files)) {
            $fileList = '';
        } else {
            foreach ($files as $item) {
                $file_name = basename($item); //ファイル名だけを抜き出す
                $fileClass = '';
                $photo = false;

                switch (1) {
                        //エクセル
                    case preg_match('/.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/', $file_name):
                        $fileClass = 'file_icon excel-icon';
                        break;
                        //テキスト
                    case preg_match('/.txt$/', $file_name):
                        $fileClass = 'file_icon text-icon';
                        break;
                        //ワード
                    case preg_match('/.doc$|.docm$|.docx$|.dot$|.dotx$/', $file_name):
                        $fileClass = 'file_icon word-icon';
                        break;
                        //パワーポイント
                    case preg_match('/.pptx$/', $file_name):
                        $fileClass = 'file_icon pptx-icon';
                        break;
                        //zipファイル
                    case preg_match('/.zip$/', $file_name):
                        $fileClass = 'file_icon zip-icon';
                        break;
                        //PDFファイル
                    case preg_match('/.pdf$/', $file_name):
                        $fileClass = 'file_icon pdf-icon';
                        break;
                        //画像
                    case preg_match('/.png$|.PNG$|.jpg$|.jpeg$|.JPG$|.JPEG$|..svg$|.svgz$|.gif$|.webp$/', $file_name):
                        $fileClass = 'file_icon pdf-icon';
                        $photo = true;
                        break;
                }

                if (!$photo == true) {
                    $fileList = '<li class="file-list"><span class="filename ' . $fileClass . '">' . $file_name . '</span><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                } else {
                    $fileList = '<li class="photo-list"><span class="filename">' . $file_name . '</span><img src="' . $folderDir . '/upload/' . $file_name . '" alt=""><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                }

                $totalList = $totalList . $fileList;
            }
        }

        return $totalList;
    }
      
    
    //-----------------------------------
    //   下書き設定（temporaryにコピー）
    //-----------------------------------

    public function temporaryCopy(string $srcFolder, string $tempDir): void {

        $this->srcDirectory($srcFolder, $tempDir, true);
    }


    private function srcDirectory(string $src, string $dst, bool $isRoot = false): void {
        if (!file_exists($dst)) {
            mkdir($dst, 0777, true);
        }
        

        $files = array_diff(scandir($src), ['.', '..']);
        
        // 最初の1回だけ除外
        if ($isRoot) {
            $files = array_filter($files, function ($file) use ($src) {
                $fullPath = $src . '/' . $file;

                return !(is_dir($fullPath) && preg_match('/^\d{3}\./', $file));
            });
        }

        foreach ($files as $file) {
            $srcPath = "$src/$file";
            $dstPath = "$dst/$file";

            if (is_dir($srcPath)) {
                $this->srcDirectory($srcPath, $dstPath, false);
            } else {
                copy($srcPath, $dstPath);
            }
        }
    }
    
    

    //-----------------------------------
    //   temporary内リスト取得
    //-----------------------------------    

    public function temporaryList() {
        
        $basePath = $this->config->basePath;
        $list = [];
        // ディレクトリ一覧取得
        $items = glob('../temporary' . '/*');

        foreach ($items as $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray);
            $title = '';

            // タイトル取得
            if (file_exists($f . '/markdown.md')) {
                $md = file_get_contents($f . '/markdown.md');

                if (preg_match("/^\*\[page-title\]:\s*(.+)/m", $md, $match)) {
                    $title = trim($match[1]);
                }
            }
                
            // パス整形
            $path = str_replace('../', 'public/', $f) . '/';
            $converted = $basePath.'/'. $path;           

            $list[] = [
                'title' => $title,
                'path'  => $converted,
                'fdName' => $lastDir,
            ];
        }

        return $list;
    }

    

    //----------------------------------------------
    //   temporary内からpages内へ下書きフォルダをコピー
    //----------------------------------------------

    public function copyDir(string $src, string $dst): void {
        
        if (!is_dir($src)) {
            throw new \RuntimeException("コピー元が存在しません: {$src}");
        }

        if (!file_exists($dst)) {
            if (!mkdir($dst, 0777, true)) {
                throw new \RuntimeException("ディレクトリ作成失敗: {$dst}");
            }
        }

        $files = scandir($src);
        
        if ($files === false) {
            throw new \RuntimeException("ディレクトリ読み込み失敗: {$src}");
        }

        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;

            $srcPath = $src . '/' . $file;
            $dstPath = $dst . '/' . $file;

            if (is_dir($srcPath)) {
                $this->copyDir($srcPath, $dstPath);
            } else {
                if (!copy($srcPath, $dstPath)) {
                    throw new \RuntimeException("ファイルコピー失敗: {$srcPath}");
                }
            }
        }
    }    



    //----------------------------------------------
    //   対象フォルダ削除（下書き反映処理用）
    //----------------------------------------------

    public  function deleteDir(string $dir): void {
        
        if (!is_dir($dir)) {
            return; // 無いなら何もしない（安全）
        }

        $files = scandir($dir);
        if ($files === false) {
            throw new \RuntimeException("ディレクトリ読み込み失敗: {$dir}");
        }

        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;

            $path = $dir . '/' . $file;

            if (is_dir($path)) {
                $this->deleteDir($path);
            } else {
                if (!unlink($path)) {
                    throw new \RuntimeException("ファイル削除失敗: {$path}");
                }
            }
        }

        if (!rmdir($dir)) {
            throw new \RuntimeException("ディレクトリ削除失敗: {$dir}");
        }
    }
    
    
    //編集許可されてるページ取得
    public function getPageFoldersByUserId($userId)
    {
        $db = $this->editService->db();
        
        $sql = "SELECT page_folder FROM user_page_permissions WHERE user_id = :user_id";
        $stmt = $db->prepare($sql);
        $stmt->execute(['user_id' => $userId]);
        
        return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'page_folder');
    }
    

    
    //---------------------
    // 下書き作成
    //---------------------

    public function createDraft( string $srcFolder, string $tempDir, string $folderName, string $title, ?int $createdBy = null ): array {

        if (file_exists($tempDir)) {

            return [
                "success" => false,
                "message" => "すでに下書き中です",
            ];
        }

        try {

            $db = $this->editService->db();
            
            $db->beginTransaction();

            // temporaryへコピー
            $this->temporaryCopy($srcFolder, $tempDir);

            // DB登録
            $sql = " INSERT INTO draft_list ( folder_name, title, created_by, created_at, updated_at ) VALUES ( :folder_name, :title, :created_by, NOW(), NOW() ) ";

            $stmt = $db->prepare($sql);

            $stmt->execute([
                ':folder_name' => $folderName,
                ':title'       => $title,
                ':created_by'  => $createdBy,
            ]);

            $db->commit();

            return [
                "success" => true,
                "message" => "下書き用ページを作成しました。",
            ];

        } catch (\Throwable $e) {

            $db->rollBack();

            // コピー済みフォルダ削除
            if (file_exists($tempDir)) {
                $this->deleteDirectory($tempDir);
            }

            throw $e;
        }
    }
    
    
    //---------------------
    // ディレクトリ削除
    //---------------------

    public function deleteDirectory(string $dir): void {
        if (!file_exists($dir)) {
            return;
        }

        $files = array_diff(scandir($dir), ['.', '..']);

        foreach ($files as $file) {

            $path = $dir . '/' . $file;

            if (is_dir($path)) {
                $this->deleteDirectory($path);
            } else {
                unlink($path);
            }
        }

        rmdir($dir);
    }
    
    
    //------------------------------------
    // カテゴリーごとに配列化　追加
    //------------------------------------

    public function groupByCategory(array $list): array {

        $grouped = [];

        foreach ($list as $item) {

            $category = $item['subCategory'] ?? '未分類';

            $grouped[$category][] = [
                'title' => $item['title'],
                'path'  => $item['path'],
            ];
        }

        return $grouped;
    }
    

    //------------------------------------
    // アクセスログ用データを取得　追加
    //------------------------------------

    public function getAccessLogData(
        string $folderName,
        // string $path
    ): array {


        // フォルダ一覧取得（キャッシュ）
        $folderObj = $this->getFolderCompCached();
        
        $path = $folderObj[$folderName] ?? '';
        

        //追加
        $userlog = 'guest';

        // 本番環境（Webラッパー）
        if (!empty($_COOKIE['comauth'])) {

            preg_match(
                '/&uid=(\w+)/',
                $_COOKIE['comauth'],
                $match
            );

            $userlog = $match[1] ?? 'guest';

        // ローカル環境
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {

            $userlog = $_SERVER['REMOTE_ADDR'];
        }


        // 初期値
        $logData = [
            'folderName' => $folderName,
            'title' => '',
            'user' => $userlog,
            'path' => $path,
        ];



        // フォルダ存在確認
        if (
            empty($folderObj[$folderName])
        ) {
            return $logData;
        }

        $folderPath = str_replace(
            '..',
            '',
            $folderObj[$folderName]
        );

        $markdownFile =
            $this->config->rootPath .
            $folderPath .
            '/markdown.md';

        // markdown.md が無ければ返す
        if (!file_exists($markdownFile)) {
            return $logData;
        }

        // タイトルだけ先頭から読む
        $handle = fopen(
            $markdownFile,
            'r'
        );

        if (!$handle) {
            return $logData;
        }

        while (
            ($line = fgets($handle))
            !== false
        ) {

            if (
                preg_match(
                    "/^\*\[page-title\]:\s*(.+)/",
                    $line,
                    $match
                )
            ) {

                $logData['title'] =
                    trim($match[1]);

                break;
            }
        }

        fclose($handle);

        return $logData;
    }    

    
    
    //------------------------------------
    // 削除前バックアップ
    //------------------------------------

    public function createDeleteBackup(string $delFolder, string $folderName): string
    {
        if (!is_dir($delFolder)) {
            throw new \RuntimeException(
                "削除対象フォルダが存在しません: {$delFolder}"
            );
        }

        $pageDir = dirname($delFolder);

        // ../pages → ../delete_work
        $workDir = $pageDir . '/../delete_work';

        if (!is_dir($workDir) && !mkdir($workDir, 0777, true)) {
            throw new \RuntimeException(
                "一時退避フォルダを作成できませんでした。"
            );
        }

        // 同じ秒に複数回実行しても衝突しないようにする
        $timestamp = date('Y-m-d_H.i.s');
        $backupDir = $workDir . '/' . $timestamp;

        $counter = 1;

        while (is_dir($backupDir)) {
            $backupDir = $workDir . '/' . $timestamp . '_' . $counter;
            $counter++;
        }

        if (!mkdir($backupDir, 0777, true)) {
            throw new \RuntimeException(
                "一時退避用のフォルダを作成できませんでした。"
            );
        }

        $backupPath = $backupDir . '/' . $folderName;

        $this->copyDirectory($delFolder, $backupPath);

        return $backupPath;
    }
    
    

    //------------------------------------
    // 移動したフォルダを元に戻す
    //------------------------------------

    public function restoreMovedFiles(array $movedFiles): void
    {
        foreach (array_reverse($movedFiles) as $move) {

            if (!file_exists($move['new'])) {
                continue;
            }

            if (!rename($move['new'], $move['old'])) {
                error_log(
                    "[FolderService] 復元失敗: {$move['new']} → {$move['old']}"
                );
            }
        }
    }    
    
    
    
    //------------------------------------
    // バックアップを trush に移動
    //------------------------------------
        
    public function moveDeleteBackupToTrash(
        string $backupPath,
        string $folderName
    ): string {

        if (!is_dir($backupPath)) {
            throw new \RuntimeException(
                "退避フォルダが存在しません: {$backupPath}"
            );
        }

        // ../delete_work/2026-10-04_08.51.23
        $backupDateDir = dirname($backupPath);

        // ../delete_work
        $workDir = dirname($backupDateDir);

        // ../trush
        $trashDir = dirname($workDir) . '/trush';

        if (!is_dir($trashDir) && !mkdir($trashDir, 0777, true)) {
            throw new \RuntimeException(
                "trushフォルダを作成できませんでした。"
            );
        }

        $dateDirName = basename($backupDateDir);

        $trashDateDir = $trashDir . '/' . $dateDirName;

        if (!mkdir($trashDateDir, 0777, true)) {
            throw new \RuntimeException(
                "trush内の退避フォルダを作成できませんでした。"
            );
        }

        $trashPath = $trashDateDir . '/' . $folderName;

        if (!rename($backupPath, $trashPath)) {
            throw new \RuntimeException(
                "trushへの移動に失敗しました。"
            );
        }

        // 空になった日付フォルダを削除
        @rmdir($backupDateDir);

        return $trashPath;
    }
    
    
    
    //------------------------------------
    // エラー時にバックアップを戻す
    //------------------------------------

    public function restoreDeleteBackup(
        string $backupPath,
        string $delFolder
    ): void {

        if (!is_dir($backupPath)) {
            return;
        }

        $parentDir = dirname($delFolder);

        if (!is_dir($parentDir)) {
            mkdir($parentDir, 0777, true);
        }

        if (is_dir($delFolder)) {
            $this->deleteDirectory($delFolder);
        }

        if (!rename($backupPath, $delFolder)) {
            error_log(
                "[FolderService] 削除前フォルダの復元に失敗しました: {$delFolder}"
            );
        }
    }
}