---
title: 文字列を配列に分割する方法
taxonomy:
    category:
        - docs
---

### サンプルコード
```
<mt:Ignore>配列に分割する文字列</mt:Ignore>
<mt:SetVar name="str" value="吉田優子,千代田桃,リリス">
 
<mt:Unless name="str" eq="">
  <mt:SetVarBlock name="arrCount"><mt:Var name="str" regex_replace="/[^,]/g","" count_characters="1"></mt:SetVarBlock>
 
  <mt:For var="i" from="0" to="$arrCount">
    <mt:SetVarBlock name="arr" function="push"><mt:Var name="str" regex_replace="/^([^,]+).*/","$1"></mt:SetVarBlock>
    <mt:SetVarBlock name="str"><mt:Var name="str" regex_replace="/^[^,]+,/",""></mt:SetVarBlock>
  </mt:For>
</mt:Unless>
 
<ul>
<mt:Loop name="arr">
  <li><mt:Var name="__value__"></li>
</mt:Loop>
</ul>
```

5行目は分割する数を取得していて、regex_replaceでカンマ以外を除去して、count_charactersで文字数(カンマの数)を取得しています。  
ループ内の8行目で先頭からカンマまでの文字列を配列に格納、9行目で先ほど追加した文字列+カンマを文字列から削除しています。  
最後に14〜16行目のループで、配列に格納した値を出力しています。
　

こちらで再構築を行うと、以下のように出力できました。

### 出力HTML
```
<ul>
  <li>吉田優子</li>
  <li>千代田桃</li>
  <li>リリス</li>
</ul>
```
今回は動作検証のため変数に値をベタ書きで指定しましたが、カスタムフィールドで複数の値を設定したい場合などに使うと便利かもしれません。
