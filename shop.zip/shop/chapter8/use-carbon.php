<?php
require 'Carbon.php';
use Carbon\Carbon;
echo Carbon::now('Japan');
?>
