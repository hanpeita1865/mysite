<?php
echo 'マッターモスト用の画像を保存しました。';

$base64data = $_REQUEST['file-matter'];

if(preg_match('/jpeg;base64/',$base64data)){//JPEG
	$base64data = str_replace('data:image/jpeg;base64,','',$base64data);
	$ext = 'jpg';
	
}elseif(preg_match('/png;base64/',$base64data)){
	$base64data = str_replace('data:image/png;base64,','',$base64data);
	$ext = 'png';
	
}elseif(preg_match('/gif;base64/',$base64data)){
	$base64data = str_replace('data:image/gif;base64,','',$base64data);
	$ext = 'gif';
}

// base64デコード
$data = base64_decode($base64data);

//保存用のフォルダを作成する
if(!file_exists($_REQUEST['chatImg'])){
	mkdir($_REQUEST['chatImg']);
};

//ファイル名のパスを作成
$photo = $_REQUEST['chatImg'].'/image.'.$ext;

// 画像ファイルの保存
file_put_contents($photo, $data);

require 'phpGd.php';//画像を縮小リサイズ

?>



























/*if(isset($_FILES['hoge']['tmp_name'])){
	
	//一時的保存にファイルがあるか確認
	if (is_uploaded_file($_FILES['hoge']['tmp_name'])) {

		//保存用のフォルダがなければ作成する
		if(!file_exists($_REQUEST['name'])){
			mkdir($_REQUEST['name']);
		}   

		//ファイルの拡張子を取得
		$file_type = pathinfo($_FILES['hoge']['name'], PATHINFO_EXTENSION);
		
		//保存先のファイルのパスを変数に設定。
		$photo = $_REQUEST['name'].'/image.'.$file_type;

		//フォルダにファイルを一時的保存から移動して格納
		move_uploaded_file($_FILES['hoge']['tmp_name'], $photo);//「日時フォルダ/image.拡張子」に格納

		require 'phpGd.php';
	}
	
} else if(isset($_REQUEST['base64'])){//一時的保存からの投稿で、最初から保存してるトップ画像がある場合
	echo $_REQUEST['base64'];
	
	// base64デコード
	$data = base64_decode($_REQUEST['base64']);

	//保存用のフォルダがなければ作成する
	if(!file_exists($_REQUEST['name'])){
		mkdir($_REQUEST['name']);
	}   

	// finfo_bufferでMIMEタイプを取得
	$finfo = finfo_open(FILEINFO_MIME_TYPE);
	$mime_type = finfo_buffer($finfo, $data);

	//MIMEタイプをキーとした拡張子の配列
	$extensions = [
		'image/gif' => 'gif',
		'image/jpeg' => 'jpg',
		'image/png' => 'png'
	];
	
	//MIMEタイプから拡張子を選択してファイル名を作成
	$photo = $_REQUEST['name'].'/image.' . $extensions[$mime_type];

	// 画像ファイルの保存
	file_put_contents($photo, $data);
	
	require 'phpGd.php';
}*/
?>
