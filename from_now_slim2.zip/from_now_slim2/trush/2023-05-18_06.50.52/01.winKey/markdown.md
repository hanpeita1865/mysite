*[page-title]:Windowsショートカットキー

ショートカットキーについては、次のサイトなどを参考にしました。
* [Windows10 ショートカットキーの一覧表（まとめ）](https://pc-karuma.net/windows-10-keyboard-shortcuts-list/)
* [ショートカットキー一覧［完全版］- パソコン仕事が爆速になるWindows、Office、Googleのキー操作 286選](https://dekiru.net/article/18619/)
* [Windows10 ショートカットキーの一覧表（まとめ）](https://pc-karuma.net/windows-10-keyboard-shortcuts-list/)

これらのサイトから、作業の効率化しそうなものをピックアップしてまとめました。  
マウスでの操作とショートカットキーをうまく使い分けていけば、作業がだいぶ効率化できるかなと思います。

## よく使うショートカットキー

### キャプチャを撮る

<div class="dl-side" markdown="1">
<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key">Shift</span></span><span class="plus">+</span><span class="bg-key">S</span>![](upload/キャプチャ切り取りサムネイル.png)
: 「<span class="blue bold">切り取り＆スケッチ</span>」アプリが起動し、画面の任意の範囲を撮影できます。<br>
新しいシンクラだと<span class="red bold">保存</span>ができますが、古いシンクラの方はクリップボードへ一時的に保存されるのみです。<br>
<span class="fz-09">※一般的には［PrtSc］キーを押しますが、ウィンドウズ10以降から、キャプチャの切り取りができるようになりました。</span>

<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key">PrtSc</span>
: 画面全体のキャプチャを撮り、PC/ピクチャ/スクリーンショットのフォルダへ自動保存されます。

<span class="bg-key">Alt</span><span class="plus">+</span><span class="bg-key">PrtSc</span>
: ウインドウがいくつも表示されている時に、ひとつのアクティブになっているウインドウだけ撮影したい時に使います。  
撮影した画像データはクリップボードに一時保存されます。
</div>

### リンクをクリックして別ウィンドウで開く

<div class="dl-side" markdown="1">
<span class="bg-key">Ctrl</span><span class="font-weight-normal"> を押しながら <span class="blue bold">リンク</span>を<br>クリック</span>
: リンク先を新しいタブで開きます。（**移動はなし**）

<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">Shift</span><span class="font-weight-normal"> を押しながら <br><span class="blue bold">リンク</span>をクリック</span>
: リンク先を新しいタブで開き、<span class="red bold">移動します</span>。
</div>

### ページ内検索
<div class="dl-side" markdown="1">
<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">F</span><br><span class="fz-09">※<span class="red bold">F3キー</span>だけでも表示できます。</span>![](upload/検索ボックス.png)<span class="fz-09 font-weight-normal">※FireFoxの場合は、画面下部に表示<br>（Ctrl + G ～次検索）<br>（Ctrl + Shift + G～前検索）</span><br><span class="fz-09 red">※キーでの移動は、IE使用不可。</span>
: 画面上部に検索ボックスを表示して、ページ内で指定した文字を検索できます。<br><br>（「ページ」での検索結果【Chromeでの表示】）<br>![](upload/検索結果ページ.png)
</div>

### アドレスバーに移動
<div class="dl-side" markdown="1">
<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">L</span>
: アドレスバーに移動します。<br>
<span class="fz-09">※Ctrl+C や Ctrl+V などと組み合わせることで、URLをコピーしたり貼り付けたりするのに便利です。</span>

### クリップボード履歴

<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key">V</span>
: クリップボードの履歴を表示します。（初期設定では無効になってるので、Win+V を押した後、有効ボタンをクリックしてください。）<br>
<span class="fz-09">※ピン留めをしたデータは、シャットダウンや再起動しても残ります。<br>
※クリップボードの設定は、設定>システム>クリップボードの画面で行えます。<br>
※個別のデータは「 Delete 」キーでも消去できます。</span>![](upload/クリップボード.png)
</div>

### ページのスクロール

<span class="fz-09">※上下矢印キーより早くスクロールできます。</span>

<div class="dl-side" markdown="1">
<span class="bg-key">Space</span>
: 下にスクロールします。

<span class="bg-key">Shift</span><span class="plus">+</span><span class="bg-key">Space</span>
: 上にスクロールします。
</div>

## タブ
### タブを移動
<div class="dl-side" markdown="1">
<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">Tab</span>
: 右隣のタブに移動

<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">Shift</span></span><span class="plus">+</span><span class="bg-key">Tab</span>
: 左隣のタブに移動します。

<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key key-small">数字キー(1〜8)</span>
: 特定のタブに移動します。（左端からの数字キー番目）<br>
<span class="fz-09 red">※IEは使用不可。</span>

<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key key-small">数字キー(9)</span>
: 一番右のタブに移動します。<br><span class="fz-09 red">※IEは使用不可。</span>
</div>
<hr>
### タブを開く・閉じる
<div class="dl-side" markdown="1">
<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">T</span>
: 新規タブを開き、開いたタブに移動します。

<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">W</span><br>（または、Ctrl + F4）
: タブを閉じます。

<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">Shift</span></span><span class="plus">+</span><span class="bg-key">T</span>
: 閉じたタブをもう一度開き直します。（最後に閉じたタブが開かれます）<br>
<span class="fz-09">※タブを閉じたけど、やっぱりもう一度見たいときにいいです。</span>
</div>


## ウィンドウを開く・閉じる

<div class="dl-side" markdown="1">
<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">N</span>
: FireFox、Chrome、Edge は、新規ページが開かれます。<br>
（IEの場合は、同じページが開かれます。）

<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key">Shift</span></span><span class="plus">+</span><span class="bg-key">W</span>
: 現在のウィンドウを閉じます。
</div>

## ページやウィンドウの拡大・縮小

### ページ表示の拡大・縮小
<div class="dl-side" markdown="1">
<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key key-one">+</span>
: ページの表示を拡大します。

<span class="bg-key">Ctrl</span><span class="plus">+</span><span class="bg-key key-one">-</span>
: ページの表示を縮小します。
</div>


### ウィンドウのサイズ変更
<div class="dl-side" markdown="1">
<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key key-one">←</span>
: ウィンドウを左半分にします。

<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key key-one">→</span>![](upload/二分割1.png)
: ウィンドウを右半分にします。<br>
<span class="fz-09">※画面に二つ並べて作業したい時、マウスで行うより多分早いと思います。</span>
</div>
<hr>
<div class="dl-side" markdown="1">
<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key key-one"> ↑</span>
: ウィンドウを最大化します。

<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key key-one">↓</span>
: ウィンドウを縮小します。

<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key key-one">M</span>
: すべてのウィンドウを最小化します。<br>
<span class="fz-09">※<span class="red bold">Win+D</span>（デスクトップを表示する）でも同じように最小化できます。</span>

</div>




## 開いているアプリやウィンドウの一覧を表示

<div class="dl-side" markdown="1">
<span class="bg-key">Alt</span><span class="plus">+</span><span class="bg-key">Tab</span>![](upload/画面切り替え.png)
: 開いているアプリやウィンドウ一覧を画面上に表示して、切り替えます。（切り替えは、Altを押したままTabか矢印キーで移動します、）

<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key">Tab</span>![](upload/画面タスクビュー1.png)
: タスクビューを表示します。<br>
<span class="fz-09">※過去の利用した履歴が表示されます。<br>
※タスクバーの![](upload/タスクビューアイコン2.png)アイコンをクリックしたときの動作と同じです。</span>
</div>

## タスクバーのアプリ選択

<div class="dl-side" markdown="1">
<span class="bg-key">Win</span><span class="plus">+</span><span class="bg-key">T</span>
: タスクバーでアプリを切り替える![](upload/タスクバー選択.png)「矢印キー」で移動できます。
</div>

## 絵文字を表示

参考サイト
: https://pc-klik.com/chrome-emoji-period/

Win+「.」（ピリオド）で、絵文字の画面が表示できます。🧡💛💚

![](upload/絵文字画面表示.png)

VSCODEの場合
: ![](upload/VSCODE絵文字.png)




