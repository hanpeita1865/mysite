---
title: '04. FormData()、Ajax送信'
media_order: ajax_file_multi1.png
taxonomy:
    category:
        - docs
visible: true
---

<style>
    section {margin-bottom: 4rem;}
    h4 {margin-top: 3rem;}
</style>

* [FormData オブジェクトとは](#p1)
* [FormData オブジェクトをインスタンス化](#p2)
* [フィールドの追加方法](#p3)
* [FormData オブジェクトの中身を見るには？](#p4)
* [メソッドの種類](#p5)
* [Ajaxでのデータ送信](#p6)
* [その他　FormDataサンプル](#p7)

<h2 class="h-type2" id="p1">FormData オブジェクトとは</h2>

FormData オブジェクトは、XMLHttpRequest を使用して、データを送信するためのキーと値のセットを追加することができるインターフェイスです。  
キーのついたデータを送信するためにフォームとは独立して使用することができます。  
送信されるデータは、フォームのエンコードタイプがmultipart/form-dataに設定されている場合と同じ形式になります。

<h2 class="h-type2" id="p2">FormData オブジェクトをインスタンス化</h2>

まず最初にFormData オブジェクトのインスタンスを作成します。

<p class="tmp"><span>書式</span></p>

	var formData = new FormData();

<h2 class="h-type2" id="p3">フィールドの追加方法</h2>

<p class="tmp"><span>書式</span></p>

	FormData.append( "name" , "value" )
    
第1引数	name属性値を文字列で指定。  
第2引数	value属性値を文字列で指定。

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
以下のように FormData オブジェクトをインスタンス化したら append() メソッドを呼び出すことでフィールドに追加することができます。

    var formData = new FormData();
    formData.append('id', '00000001');
    formData.append('name','karabiner');
    
</div>


### FormData で Blob をファイルとしてアップロード

file 型の input 要素を使わなくても、 JavaScript で Blob を使うことによって、データをファイルとして POST することも可能です。

<p class="tmp"><span>書式</span></p>

	FormData.append( "name" , Blob , "ファイル名" )
    
第1引数	名前を文字列で指定。  
第2引数	Blob や File オブジェクトを指定。  
第3引数(略可)	第2引数で指定した Blob オブジェクトのファイル名を指定。   

<div class="box-example" markdown="1">
### 例 ### {.h-example}
次のようにすると、Blob オブジェクトはテキストファイル相当のデータとみなされます。
```
const f1 = document.getElementById('f1');
const fd = new FormData(f1);
let blob = new Blob(['Sample text'], {
    type: 'text/plain'
});
fd.append('data1', blob, 'foo.txt');
```
</div>
    

<h2 class="h-type2" id="p4">FormData オブジェクトの中身を見るには？</h2>

<h3 class="h-type3">get() getAll()メソッドで確認</h3>

get()は引数にキー名を渡すと、値を返します。  
getAll()は引数にキー名を渡すと、値（配列）を返します。

<div class="box-example" markdown="1">
### 例2 ### {.h-example}
<script async src="//jsfiddle.net/ufdtpbxc/embed/js,result/"></script>
</div>
    
しかし、それぞれ特定のキーの値を取得するメソッドになるので、全てを一括で見れません。

<h3 class="h-type3">一括で確認する方法</h3>

**entries()**メソッドを使う。

<p class="tmp"><span>書式</span></p>

    for (let value of formData.entries()) { 
        console.log(value); 
    }

<div class="box-example" markdown="1">
### 例3 ### {.h-example}
<script async src="//jsfiddle.net/02rm1vh3/2/embed/js,result/"></script>
</div>

<h2 class="h-type2" id="p5">メソッドの種類</h2>

| 種類 | 機能 |
| -------- | -------- |
| **{c:red}FormData.append(){/c}** | FormData オブジェクト内の既存のキーに新たな値を追加するか、キーが存在しない場合はキーを追加します。 |
| **{c:red}FormData.delete(){/c}** | FormData オブジェクトからキーと値のペアを削除します。|
| **{c:red}FormData.entries(){/c}** | オブジェクトに含まれているすべてのキーと値のペアを走査できるようにするため、iterator を返します。|
| **{c:red}FormData.get(){/c}** | FormData オブジェクトから、指定したキーに関連付けられた最初の値を返します。|
| **{c:red}FormData.getAll(){/c}** | FormData から、指定したキーに関連付けられたすべての値の配列を返します。|
| **{c:red}FormData.has(){/c}** | FormData オブジェクトがあるキーと値のペアを持っているかを示す真偽値を返します。|
| **{c:red}FormData.keys(){/c}** | オブジェクト内に存在するキーと値のペアから、すべてのキーを走査できるようにするための [iterator](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Iteration_protocols)を返します。|
| **{c:red}FormData.set(){/c}** | FormData オブジェクト内の既存のキーに新たな値を設定するか、キーが存在しない場合はキーと値のペアを追加します。|
| **{c:red}FormData.values(){/c}** | オブジェクト内に存在するキーと値のペアから、すべての値を走査できるようにするための iterator を返します。|


<h2 class="h-type2" id="p6">Ajaxでのデータ送信</h2>

<h3 class="h-type3">基本データ送信</h3>
<div class="box-example" markdown="1">
### 例4 ### {.h-example}
送信ボタンを押すと、dataが「ajax.php」に送信されます。  
Console画面の「**POST ajax.php**」をクリックすると、送信されたdataが確認できます。
[新規タブ](../../../sample/sample1(ajax)/index.html?target=_blank)

<iframe width="100%" height="450" src="../../sample/sample1(ajax)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

**JS**

    $('button').on('click',function(){
        $.ajax({
            url: 'ajax.php',
            type: 'POST',
            cache: false,
            data : {post_data_1:"hoge", post_data_2:"piyo"}
        }).done(function(data) {
            //通信成功時の処理
            alert('成功しました。');

        }).fail(function(){
            //通信失敗時の処理
            alert('失敗しました～。')
        });
    });
    

**送信先（ajax.php）**

    <?php
        //ajax送信でPOSTされたデータを受け取る
        $post_data_1 = $_POST['post_data_1'];
        $post_data_2 = $_POST['post_data_2'];

        //受け取ったデータを配列に格納
        $return_array = [$post_data_1, $post_data_2];

        //「$return_array」をjson_encodeして出力
        echo json_encode($return_array);
    ?>


<h3 class="h-type3">FormData()のテキストデータを送信</h3>

<div class="box-example" markdown="1">
### 例5 ### {.h-example}
送信ボタンを押すと、ajaxで送信したFormData()のテキストデータをConsoleに表示します。
[新規タブ](../../../sample/sample2(ajax_text)/index.html?target=_blank)
<iframe width="100%" height="450" src="../../sample/sample2(ajax_text)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

* processDataで、dataをクエリ文字列に変換せずに送信するか設定出来る
* contentTypeで、content-typeヘッダを変換せず送信するか設定出来る

データが変換されてしまうと、正常に通信が完了しない為、FormData()で送信する場合は、上記二つをfalseに指定して、変換を止める

<script async src="//jsfiddle.net/jvfeqL07/embed/js,html/"></script>

送信先（ajax.php）

    <?php
        $id = $_REQUEST['id'];
        $name = $_REQUEST['name'];

        //受け取ったデータを配列に格納
        $return_array = [$id, $name];

        //「$return_array」をjson_encodeして出力
        echo json_encode($return_array);
    ?>


### FormData()の画像やファイルのデータを送信 ###{.h-type3 #ex6}

<div class="box-example" markdown="1">
### 例6 ### {.h-example}
uploadフォルダに選択したファイルがアップロードされる
[新規タブ](../../../sample/sample(FormData)/sample3(ajax_file)/index.html?target=_blank)

<iframe width="100%" height="250" src="../../sample/sample(FormData)/sample3(ajax_file)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

※ファイルとテキストデータを一緒にアップロードすることもできます。

<script async src="//jsfiddle.net/rxyf08vc/embed/js,html/"></script>

**送信先（ajax.php）**

FormDataでファイルを送信する場合、「is_uploaded_file」ではなく、下記の「!empty」方を使う。

    <?php
        //一時的保存にファイルがあるか確認
        if (!empty($_FILES['hoge']['tmp_name'])) {

            //保存用のフォルダがなければ作成する
            if(!file_exists('upload')){
                mkdir('upload');
            }

            //保存先のファイルのパスを変数に取得。
            $file='upload/'.basename($_FILES['hoge']['name']);

            //フォルダにファイルを一時的保存から移動して格納
            move_uploaded_file($_FILES['hoge']['tmp_name'], $file);
        }
    ?>



### 複数のファイルの読み込み

<div class="box-example" markdown="1">
### 例7 ### {.h-example}
commonフォルダ内の2つのファイル(category.json、report.json)を読み込み、コンソールにデータを表示する
[新規タブ](../../../sample/sample(FormData)/sample3(ajax_file_multi)/index.html?target=_blank)

</div>

##### JS
```
$(function(){
  var path1 = "common/category.json";
  var path2 = "common/report.json";

  var d = $.Deferred();
	
  $.when(
    $.ajax({url:path1}).done(function(data){
		dataCate = data;
		d.resolve();
	}),
    $.ajax({url:path2}).done(function(data){
		dataRepo = data;
		d.resolve();
	})).done(function(data){
	  
      console.log(dataCate);
      console.log(dataRepo);

    });
});
```
##### コンソール表示結果
「category.json」と「report.json」のそれぞれのデータが表示されている。
![](ajax_file_multi1.png)


## その他　FormDataサンプル ##{#p7}

他のサイトにあったFormDataを使ったサンプルです。

参考サイト
: [Postで送信した値をページ遷移せずに受け取る方法](https://analogstd.com/pc/javascript/method-post-with-xhr/)

通常のPost送信  
: <http://localhost:7000/test/url_change/sample2_post/>  
ページ遷移されて、Post値が表示されます。

ページ遷移せずに送信  
: <http://localhost:7000/test/url_change/sample2_post_nochange/>  
画面の下にPost値が表示されます。FormDataを使って送信しています。


##### HTML
```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Postで送信（遷移なし） | sample2_post_nochange</title>
</head>
<body>
	<form id="userinfo2">
		<p>
			<label for="item1">名前</label>
			<input name="name" id="item1">
		</p>
		<p>
			<label for="item2">年齢</label>
			<input name="old" id="item2">
		</p>
		<p>
			<label for="item3">住所</label>
			<input name="address" id="item3">
		</p>
	</form>
	<p>
		<button type="button" id="send_mixdata">入力値と固定値を送信する</button>
	</p>
	<div id="mixdata_response">
		<!-- 結果を出力する -->
	</div>
	<script>
	// ページ読込完了後にボタンにclickイベントを登録する
	window.addEventListener("load", function(){
		document.getElementById("send_mixdata").addEventListener("click", function(){
			// FoemDataオブジェクトに要素セレクタを渡して宣言する
			let formDatas = document.getElementById("userinfo2");
			let mixedDatas = new FormData(formDatas);

			// appendメソッドでキーとデータの組をセットする
			// append("キー(FORMで云うところのname属性値)",  "データ")でデータをセットできる
			// appendではデータは追加となる
			mixedDatas.append("filename",  "test.txt");
			mixedDatas.append("filesize",  "10,154B");

			// XHRの宣言
			let XHR = new XMLHttpRequest();

			// openメソッドにPOSTを指定して送信先のURLを指定します
			XHR.open("POST", "fuga.php", true);

			// sendメソッドにデータを渡して送信を実行する
			XHR.send(mixedDatas);

			// サーバの応答をonreadystatechangeイベントで検出して正常終了したらデータを取得する
			XHR.onreadystatechange = function(){
				if(XHR.readyState == 4 && XHR.status == 200){
					// POST送信した結果を表示する
					document.getElementById("mixdata_response").innerHTML = XHR.responseText;
				}
			};
		} ,false);
	}, false);
	</script>
</body>
</html>
```

##### fuga.php（送信先）
```
<?php 
echo $_POST['name']; 
echo $_POST['old'];
echo $_POST['address'];  
?>
```


## 参考サイト

* [FormData の使い方](https://javascript.keicode.com/newjs/how-to-use-formdata.php)
* [FormData オブジェクトの使用](https://developer.mozilla.org/ja/docs/Web/API/FormData/Using_FormData_Objects)
* [フォームデータの送信](https://developer.mozilla.org/ja/docs/Learn/Forms/Sending_and_retrieving_form_data)
* [FormData](https://ja.javascript.info/formdata)






