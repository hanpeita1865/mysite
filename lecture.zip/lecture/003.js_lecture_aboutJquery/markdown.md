*[page-title]:jQueryについて



## JavaScriptとjQueryの違い

**<span class="red">jQueryは、JavaScriptをより簡単に書けるようにしたライブラリ</span>**です。

ライブラリとは、よく使う処理をまとめた便利な部品集のようなものです。

以前はブラウザごとに動作が異なることが多く、JavaScriptだけでは複雑なコードを書く必要がありました。そのため、少ないコードで簡単に記述できるjQueryが広く利用されるようになりました。

現在ではJavaScript自体が進化し、昔よりもシンプルに書けるようになっています。そのため、新しいWeb開発ではバニラJavaScript（ライブラリを使わないJavaScript）が採用されることも増えています。

一方で、多くの既存システムでは現在もjQueryが利用されており、社内システムでもjQueryが使われています。そのため、このレクチャーではJavaScriptの基礎を理解したうえで、業務でよく使用するjQueryの書き方も学びます。

### 補足）

#### その他のライブラリ

| ライブラリ        | 用途                      |
| ------------ | ----------------------- |
| Chart.js     | グラフ表示                   |
| highlight.js | ソースコードのシンタックスハイライト      |


#### ライブラリとフレームワークについて

| 種類      | 説明                         | 例                                       |
| ------- | -------------------------- | --------------------------------------- |
| ライブラリ   | 必要な機能を必要なときに利用する部品集        | jQuery、Chart.js、Day.js                  |
| フレームワーク | アプリケーション全体の構成や開発ルールを提供する土台 | Bootstrap（CSSフレームワーク）、React、Vue、Angular |



---

### 例1：ボタンをクリックする

#### JavaScript

https://jsfiddle.net/hirao/sf0zkmgd/

```javascript
document.getElementById("btn").addEventListener("click", function () {
    alert("クリックされました");
});
```

#### jQuery

https://jsfiddle.net/hirao/7kobvprs/6/

```javascript
$("#btn").click(function () {
    alert("クリックされました");
});
```

jQueryでは、イベント登録を短く書くことができます。

---

### 例2：要素を非表示にする

#### JavaScript

https://jsfiddle.net/hirao/jg1ayhpu/2/

```javascript
document.getElementById("message").style.display = "none";
```

#### jQuery

https://jsfiddle.net/hirao/7eday8qx/2/

```javascript
$("#message").hide();
```

jQueryには**hide()**や**show()**など、よく使う処理がメソッドとして用意されています。

---

### 例3：文字を書き換える

#### JavaScript

https://jsfiddle.net/hirao/jg1ayhpu/6/

```javascript
document.getElementById("title").textContent = "JavaScript";
```

#### jQuery

https://jsfiddle.net/hirao/u8vezLoj/1/

```javascript
$("#title").text("JavaScript");
```

どちらも同じ結果になりますが、jQueryの方がシンプルに記述できます。

---

### 例4：CSSを変更する

#### JavaScript

https://jsfiddle.net/hirao/mc70ydqb/2/

```javascript
document.getElementById("title").style.color = "green";
```

#### jQuery

https://jsfiddle.net/hirao/uat2sfed/2/

```javascript
$("#title").css("color", "green");
```

jQueryではCSSの変更も分かりやすく記述できます。

---

### 例5：クラスを追加する

#### JavaScript

https://jsfiddle.net/hirao/hm4ndv5t/4/

```javascript
document.getElementById("menu").classList.add("active");
```

#### jQuery

https://jsfiddle.net/hirao/msuy9hwc/3/

```javascript
$("#menu").addClass("active");
```

メニューの表示切替などでよく使われる処理です。

---

### JavaScriptとjQueryの比較

| 項目     | JavaScript | jQuery                |
| ------ | ---------- | --------------------- |
| 種類     | プログラミング言語  | JavaScriptのライブラリ      |
| 動作     | ブラウザに標準搭載  | 読み込みが必要               |
| 記述量    | やや多い       | 少ない                   |
| 学習     | 基本となる知識    | JavaScriptを理解すると覚えやすい |
| 社内システム | 一部使用       | 多くの画面で使用              |
| 最近の開発  | よく使われる     | 新規開発では減少傾向            |

### 覚えておきたいポイント

* **JavaScript**はプログラミング言語そのものです。
* **jQuery**はJavaScriptを簡単に書くためのライブラリです。
* 現在はJavaScriptだけでも多くのことが簡単に書けます。
* <span class="bold red">社内システムではjQueryが使われているため、JavaScriptとjQueryの両方を理解しておくことが大切です。</span>



## jQueryライブラリの読み込み

JavaScriptはブラウザに標準で搭載されているため、特別な準備をしなくても使用できます。

一方、**jQueryはライブラリ**なので、使用する前に読み込む必要があります。

HTMLファイルの`<script>`タグでjQueryを読み込むと、jQueryの機能が使えるようになります。


### CDNから読み込む方法

最も簡単な方法は、CDN（Content Delivery Network）を利用する方法です。

```html
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
```

この1行を追加するだけで、jQueryが利用できるようになります。

---

### JavaScriptファイルより先に読み込む

jQueryを使用するJavaScriptファイルより**先**に読み込む必要があります。

```html
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>サンプル</title>
</head>
<body>

    <button id="btn">クリック</button>

    <!-- jQueryを読み込む -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- 自分で作成したJavaScript -->
    <script src="script.js"></script>

</body>
</html>
```

もし順番が逆になると、

```text
$ is not defined
```

というエラーになり、jQueryを使用できません。

---

### 社内システムでは

社内システムでは、CDNではなく**サーバーに保存したjQueryファイル**を読み込んでいることが多くあります。

例えば、

```html
<script src="/js/jquery-3.7.1.min.js"></script>
```

や

```html
<script src="/assets/js/jquery.min.js"></script>
```

のように読み込みます。

この方法であれば、インターネットに接続できない環境でも利用できます。

---

### 読み込めたか確認する方法

ブラウザの開発者ツール（F12）の**Console**で次のコードを実行します。

```javascript
console.log($);
```

または

```javascript
console.log(jQuery);
```

正常に読み込まれていれば、jQueryのオブジェクトが表示されます。

逆に、

```text
Uncaught ReferenceError: $ is not defined
```

と表示された場合は、

* jQueryが読み込まれていない
* `<script>`の順番が間違っている
* パスが間違っている

などが原因です。

---

### 覚えておきたいポイント

<div markdown="1" class="green">
* **JavaScriptはブラウザに標準搭載されている。**
* **jQueryはライブラリなので、使用前に読み込む必要がある。**
* **jQueryは、自分で作成したJavaScriptより先に読み込む。**
* **読み込みに失敗すると「`$ is not defined`」などのエラーが表示される。**
</div>

---


> **JavaScriptはブラウザにもともと入っている機能ですが、jQueryは追加で読み込む便利なライブラリです。そのため、jQueryを使うには最初にライブラリを読み込む必要があります。**
