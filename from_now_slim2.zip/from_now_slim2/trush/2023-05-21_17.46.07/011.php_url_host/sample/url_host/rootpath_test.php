<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="/css/style.css" />
<script src="/js/script.js"></script>
</head>
<body>
<?php
echo $_SERVER['REQUEST_URI'];
//途中です。
?>
    <p><a href="<?= $_SERVER['REQUEST_URI'] ?>/pages/test.html">ルートパステスト</a></p>

</body>
</html>
