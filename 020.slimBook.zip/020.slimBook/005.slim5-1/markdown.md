*[page-title]:第5章Slimにおけるビュー

Twig公式サイト （Tags Filter Functionの使い方ページ）
: <https://twig.symfony.com/doc/3.x/>

## Slimにおけるビューの扱いとJSONデータ送信

<div markdown="1" class="green-box">
* Slimは、PSR-7のResponsiveオブジェクトを生成し、返すことのみに責任を持つように作られている。
* Slimは、レスポンスとしてHTMLだけでなくJSONデータを返すのにも対応している。
* JSONデータをレスポンスとして返すには、元データとなる連想配列をjson_encode()関数を使ってJSON文字列に変換する
* JSONデータをレスポンスとして返すには、$response の withHeader() メソッドを使って、レスポンスヘッダーを変更する
</div>

### Slimにおけるビューはレスポンスオブジェクト

1-3-3項で説明したように、Slimはルーティングに重点を置いた軽量フレームワークなので、画面表示を担うビュー機能は含まれていません。Slimは、適切なPSR-7のResponseオブジェクトを生成し、返すことのみ責任を持つように作られています。

このことは、HTTPのレスポンスとして必ずHTMLを返さなければならない、といった束縛から自由になることを意味し、さまざまなWebアプリケーションの形態に柔軟に対応できるフレームワークであることを示しています。

HTML以外のレスポンスを返す場合で一番多いのがJSONデータでしょう。例えば、Webアプリケーションのフロントエンドをシングルページアプリケーション<sup class="green bold">注1）</sup>とし、そのサーバサイドををすべてAPI化したものを考えます。あるいは、AndroidやiOSなどのスマートフォンアプリとデータのやり取りをするためサーバ処理を考えます。そのどちらの場合でも、サーバサイドとしては、JSONデータをHTTPレスポンスとして送信するのが通常です。Slimはそういったアプリケーションにも対応しています。

<p class="fz-08"><span class="green bold">注1）</span> Webサーバからは単一のHTMLページを最初に詠み込んでおき、その後はクライアント側のJavascriptの処理のみですべての表示処理、データ処理を行うWebアプリケーションが、シングルアプリケーションです。</p>

ではプロジェクトを作成します。フォルダ名は、「****slimview****」です。このフォルダ内のindex.phpとroutes.phpに下記を追記します。


<p class="tmp list"><span>リスト5-1</span>slimview/public/index.php</p>
```
<?php
use Slim\Factory\AppFactory;

require_once($_SERVER["DOCUMENT_ROOT"]."/slimview/vendor/autoload.php");

$app = AppFactory::create();

require_once($_SERVER["DOCUMENT_ROOT"]."/slimview/routes.php");

$app->run();
```

<p class="tmp list"><span>リスト5-2</span>slimview/routes.php</p>
```
<?php
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;

$app->setBasePath("/slimview/public");
```

これでプロジェクトが作成されました。以降、このプロジェクトに追記やファイルの作成を行っていきます。なお、slimview は、ここまでの内容を含んだものとなっています。

### SlimでJSONデータを送信する方法

SlimでJSONデータを送信するコードをルーティング登録ファイルである routes.php に下記を追記します。

<p class="tmp list"><span>リスト5-3</span>routes.php</p>
```
$app->any("/getDataByJSON/{id}",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        $id = $args["id"];
        $jsonArray = ["id" => $id, "name" => "田中和彦", "age" => 26]; //･･･(1) Jsonデータを連想配列で用意
        $jsonData = json_encode($jsonArray); //･･･(2) json_encode()で連想配列を文字列に変換
        $responseBody = $response->getBody(); //･･･(3) レスポンスボディとして格納 
        $responseBody->write($jsonData); //･･･(3)  上に同じ
        $response = $response->withHeader("Content-Type", "application/json"); //･･･(4) withHeader()メソッドを
        //使って新たなResponseInterfaceインスタンスを生成し、HTTPヘッダーのContent-Typeをapplication/jsonにする
		return $response;
	}
);
```

Postmanで次のURLにアクセスしてください。  
アクセスするHTTPメソッドは何でもかまいません。

http://localhost:9810/slimview/public/getDataByJSON/46

以下のように、格納したデータが表示されます。

![](upload/getDataByJSON46.png)

リスト5-3を書式にすると、次のようになります。
<p class="tmp"><span>書式1</span>JSONデータの送信（コールバック関数の中身）</p>
```
function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
	//JSONデータの元となるPHP連想配列を生成
	$jsonData = json_encode(生成されたPHP連想配列); //･･･(1)
	$responseBody = $response->getBody();
	$responseBody->write($jsonData);
	$response = $response->withHeader("Content-Type", "application/json");
	return $response;
}
```
PHPには、上記の(1)のコードにある連想配列をJSON文字列へと変換する <span class="green bold"> json_encode() </span>があります。

## 5-2. テンプレートエンジン Twig との連携

JSONデータの送信する方法を前項で説明しました。次はこの章のメインテーマであるHTMLデータをレスポンスとして送信する方法を扱っていきましょう。


<div markdown="1" class="green-box">
* HTML表示処理をコールバック関数から分離できるのがテンプレートエンジン。
* Slimでは、テンプレートエンジンTwigと連携できるパッケージが用意されている。
* SlimでTwigを利用するには、テンプレートファイルを用意し、Twigインスタンスを取得し、render()メソッドを実行する。
</div>

### HTMLコードを分離できるテンプレートエンジン

HTMLデータをレスポンスとして送信する方法も、実はJSONと変わりません。  
基本コードは、以下になります。
```
$responseBody = $response->getBody();
$responseBody->write($content);
return $response;
```

この$contentとしてHTML文字列を事前に生成しておけば、それでHTMLデータをレスポンスとして送信できます。ただ、この方法が可能なのは、ここまで生成してきたサンプルのように、HTML文字列が簡易なものの場合のみです。実際の業務で作成するアプリの画面となると、そもそもデザインされたHTMLですので、もっと複雑なHTMLであることが通常です。

そういった複雑なHTML表示をPHPソースの中に混在させると、それだけで可読性が下がります。ましてや、コールバック関数中にHTMLを表示させる処理を記述しなければならないとなると、なおさらです。さらに、別のPHP処理でほぼ同様の画面を表示したい場合にも、いちいち同じHTMLコードを記述しておく必要があります。つまり画面の再利用が出来ません。

そこで登場するのが<span class="green bold">テンプレートエンジン</span>です。HTMLコードを記述したファイルを別に用意しておきます。このファイルのことをテンプレートと呼びます。一方で、PHP側でそのテンプレートに埋め込むデータを用意しておきます。テンプレートエンジンはそれらを統合してHTMLレスポンスを生成する仕組みです。

テンプレートエンジンを利用することで、PHP処理が書かれたファイルとHTMLコードが書かれたファイルを分離でき、PHPコード、HTMLコードそれぞれの可読性が向上します。  

なお、テンプレートファイルをもとにHTMLを表示させるためのPHPコードを生成することを、テンプレートファイルでは、<span class="green bold">コンパイル</span>といいます。

### Slimで利用するテンプレートエンジン

Slimにはビュー層は含まれていませんので、テンプレートエンジンも含まれていません。しかし、Twigと連携できるライブラリ <span class="text-green bold">Twig-View</span> が提供されています。それを導入することで問題なくテンプレートエンジンが使えます。

次のコマンドで、Twig-Viewをcomporserで導入できます。  
slimviewフォルダで実行してください。
<p class="tmp cmd"><span>コマンド</span>twig導入</p>
```
composer require slim/twig-view
```
実行すると、composer.json へ以下のように、twig-viewのバージョンが記入されます。composerlockファイルも更新され、必要なパッケージがダウンロードされます。

<p class="tmp">composer.json</p>
```
{
    "require": {
        "slim/slim": "^4.8",
        "slim/psr7": "^1.4",
        "slim/twig-view": "^3.2" //･･･追記される
    }
}
```

### SlimでのTwigを利用して画面を表示させる

templatesフォルダを作成し、その中にテンプレートファイルを作成します。  

<p class="tmp list"><span>リスト5-4</span>template/hello.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>Twigによるこんにちは</title>
</head>
    <body>
        <h1>こんにちは! Twig</h1>
    </body>
</html>
```

次に、テンプレートファイルを利用するルーティング登録を行います。

<p class="tmp list"><span>リスト5-5</span>routes.php</p>
```
use Slim\Views\Twig; //･･･(1)use文を追記する
～省略～
$app->any("/helloTwig",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
			$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");//･･･(2)Twigインスタンスを取得
			$response = $twig->render($response, "hello.html");//･･･(3)Twigインスタンスのrender()メソッドを実行
			return $response;
		}
);
```
このように実行されたrender()メソッドは、テンプレートファイルをもとに生成されたHTMLデータをレスポンスボディとして設定したレスポンスオブジェクトを返します。それをルーティングコールバック関数の戻り値としてリターンすることで、生成されたHTMLがHTTPレスポンスとして送信されます。

http://localhost:9810/slimview/public/helloTwig にアクセスすると、「こんにちは! Twig」と画面に表示されます。


### SlimでのTwig利用の基本手順

#### 1. テンプレートファイルを作成する

templatesフォルダにテンプレートファイルを作成する。  
なお、Twigではテンプレートファイルはテキストファイルであればよく、拡張子は特に指定はありません。そのため、ここでは .html としています。

#### 2. Twigインスタンスを取得する

SlimとTwigを連携させるTwig-Viewの中心となるクラスは、Slim\Views\<span class="text-green">**Twig**</span>です。  
このクラスをuseしておき、$twig = ～ でそのインスタンスを取得し、create() を実行します。

<p class="tmp"><span>書式2</span>Twigインスタンスの取得</p>
```
$twig = Twig::create(テンプレートファイルフォルダパス);
```

#### 3. render() メソッドを実行する

Twigインスタンスの**<span class="text-green">render()</span>**メソッドを実行することで、テンプレートファイルをもとにしたレスポンスオブジェクトが生成されます。

<p class="tmp"><span>書式3</span></p>
```
$response = $twig->render($response, テンプレートファイル);
```

### Twig の環境設定
リスト5-5 (2) でTwigインスタンスを取得する際、create()メソッドの引数としてテンプレートフォルダパスを指定しました。このcreate()メソッドは第2引数として環境設定を記述した連想配列を渡すこともできます。第2引数を渡すことで、デバッグモードの設定やキャッシュの有無など、細かい挙動を設定できます。その場合は、例えば、次のような記述になります。
```
$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates", ["debug" => true]);
```
リスト5-5 (2) は第2引数を省略した形であり、その場合は、すべてデフォルトの挙動となります。

Twigの環境設定としてどのような設定項目があるのかを表5-1にまとめています。特に問題がなければ、リスト5-5のようにすべてデフォルトの挙動でかまいません。

<p class="tb-caption"><span>表5-1</span>Twigの環境設定</p>
| 設定項目 | データ型 | 内容 | 初期値 |
| -------- | -------- | -------- | -------- |
| debug<sup class="green bold">注1）</sup>     | boolean    | trueの場合、デバッグ出力が可能となる     | false     |
| charset     | string     | テンプレートファイルの文字コードセット     | utf-8     |
| base_template_class     | string  | テンプレートファイルを処理するクラス     | \Twig\Template     |
| cache    | string<br>または<br>false     | コンパイル済みテンプレートをキャッシュとして保存するフォルダパス。falseの場合はキャッシュを使用しない     | false     |
| auto_reload    | boolean     | テンプレートファイルを変更した時に再コンパイルするかどうかの指定    | debugの値    |
| strict_variables<sup class="green bold">注2）</sup>    | boolean     | trueの場合テンプレート中の不正な記述をnullとして扱い例外を発生させない   | false     |
| autoescape<sup class="green bold">注3）</sup>    | string     | テンプレート中の記述で自動的にエスケープする種類を指定     | html     |
| optimizations<sup class="green bold">注4）</sup>   | integer     | テンプレートをコンパイルする際にどのような最適化を行うか指定するフラグ。0が最適化を行わず、-1がすべての最適化を行う     | -1     |

<div markdown="1" class="list-notes">
注1）
: debugでは、次節で扱うテンプレート変数をdump表示させたい場合にtrueとします。（5-7-3項で詳しく解説します。）

注2）
: strict_variablesについて、不正な記述の具体例は、存在しない変数や属性、メソッドをテンプレート変数として指定するなどです。（5-3-3項で詳しく解説します。）

注3）
: autoescapeについて、エスケープする種類の設定値として、html以外に js、css、url などがあります。

注4）
: optimizationsについて、最適化が行われると実行時間とメモリの節約になります。
</div>


通常、このTwigインスタンスの取得処理はルーティングコールバック関数内には記述せず、Slimのコンテナという機能を利用し、そこからTwigインスタンスを取得します。このコンテナの利用方法は、第6章で紹介します。


## 5-3. テンプレート変数

PHP側から渡されたデータを表示するようにします。

<div markdown="1" class="green-box">
* PHP側から渡されたデータを表示するには、Twigのテンプレート変数を使う。
* テンプレート変数は、**{{･･･}}** と 波括弧を２個重ねて使う。
* テンプレート変数は、「.」(ドット) でつなぐことで、さらに内部のデータを表示できる。
* テンプレート内のコメントは、{#･･･#} の書式を使う。
</div>

### テンプレート変数の基本は波括弧２個

PHP側から渡されたデータを表示するには、Twigの<span class="green bold">テンプレート変数</span>を使います。記述方法は、<span class="green bold">{{･･･}}</span> と波括弧を2個重ねます。

<p class="tmp list" id="list5-6"><span>リスト5-6</span>templates/helloWithVals.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>テンプレート変数</title>
</head>
    <body>
        <h1>こんにちは! {{name}}さん!</h1><!--･･･(1)テンプレート変数を使用-->
    </body>
</html>
```
<p class="tmp list" id="list5-7"><span>リスト5-7</span>routes.php</p>
```
$app->any("/helloWithVals",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$assign["name"] = "夏目";//･･･(1)データを格納
		$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "helloWithVals.html", $assign);//･･･(2)
		return $response;
	}
);
```
リスト5-7(2)で、Twigインスタンスの render()メソッドを実行する際、第3引数が増えています。この第3引数は、テンプレートに渡すデータが格納された連想配列を指定し、ここでは、$assignという連想配列名とし、リスト5-7の(1)でデータを格納しています。

http://localhost:9810/slimview/public/helloWithVals にアクセスすると、「こんにちは! 夏目さん!」と表示されます。


<p class="tmp"><span>書式</span>Twigクラスのrender()メソッド</p>
```
$response = $twig->render(レスポンスオブジェクト, テンプレートファイルパス, テンプレート変数の連想配列)
```

### テンプレート変数のドットアクセス

テンプレート変数は、「**<span class="text-red">.</span>**」でつなぐことで、さらに別の値を探し出して表示してくれます。

例）item<span class="red bold">.</span>name　➡　黒ラベル

<p class="tmp list"><span>リスト5-8</span>slimview/DotAccessData.php</p>
```
<?php
class DotAccessData {
    public $deptName = "経理部";//･･･(2)
    private $csName = "武者小路実篤";//･･･(4)
    public function makeMessage()//･･･(3)
    {
        return "makeMessageの戻り値です";
    }
    public function getCsName()//･･･(4)
    {
        return $this->csName;
    }
    public function isFlgOn()//･･･(5) 判定メソッド　
    {
        return true;
    }
    public function hasMiddleParam()//･･･(6) 存在メソッド
    {
        return true;
    }
}
```
#### 判定メソッドや存在メソッドの戻り値

クラス内に is〇〇() の判定メソッドや has〇〇() の存在メソッドが存在し、そのisやhasを削除した小文字から始まるメソッド名をテンプレートに記述すると、その戻り値が表示されます。

このテンプレート変数の利用方法は表示のためというよりは、のちほど扱う制御構文で利用するためのものです。

<p class="tmp list"><span>リスト5-9</span>templates/dotAccess.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>Twigによるこんにちは</title>
</head>
<body>
    <h1>テンプレート変数のドットアクセス</h1>
    <section>
        <h2>連想配列の要素</h2>
        <p>{{item.name}}</p><!--･･･(1)-->
    </section>
    <section>
        <h2>クラスのpublicプロパティ</h2>
        <p>{{dotAccessData.deptName}}</p><!--･･･(2)「経理部」-->
    </section>
    <section>
        <h2>クラスのメソッド</h2>
        <p>{{dotAccessData.makeMessage}}</p><!--･･･(3)-->
    </section>
    <section>
        <h2>ゲッタの戻り値</h2>
        <p>{{dotAccessData.csName}}</p><!--･･･(4)「武者小路実篤」-->
    </section>
    <section>
        <h2>判定メソッドの戻り値</h2>
        <p>{{dotAccessData.flgOn}}</p><!--･･･(5)-->
    </section>
    <section>
        <h2>存在確認メソッドの戻り値</h2>
        <p>{{dotAccessData.middleParam}}</p><!--･･･(6)-->
    </section>
    <section>
        <h2>存在しない値</h2>
        <p>{{mue}}</p><!--･･･(7)-->
    </section>
</body>
</html>
```

<p class="tmp list"><span>リスト5-10</span>routes.php</p>
```
～省略～
require_once("DotAccessData.php"); //通常は、use文を利用してrequire_onceでクラスファイルを読み込むことはしません。
//現段階ではこの方法を使ってるだけです。独自に作成したクラスのオートロードの方法は第7章で扱います。

$app->any("/dotAccess",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$itemData = ["name"=>"黒ラベル", "price"=>260];
		$assign["item"] = $itemData;
		$dotAccessData = new DotAccessData();
		$assign["dotAccessData"] = $dotAccessData;
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "dotAccess.html", $assign);
		return $response;
	}
);
```

http://localhost:9810/slimview/public/dotAccess にアクセスすると、$assign["item"] と DotAccessData クラスに格納したデータが確認できます。

#### （表示結果）
![](upload/dotAccess.png)


### テンプレート変数のアクセスルール

テンプレート内に **{{hoge.bow}}** の記述がある場合、Twigは次のルールで変数を表示させています。

1. hogeが連想配列の場合、キーbowに該当する要素を表示する。
2. hogeがクラスのインスタンスの場合
<div markdown="1" class="list-none">
	* 2-1. bowがpublicプロパティとして存在すれば、その値を表示する
	* 2-2. そうでない場合、publicなbow()メソッドが存在すれば、その戻り値を表示する
	* 2-3. そうでない場合、publicなgetBow()メソッドが存在すれば、その戻り値を表示する
	* 2-4. そうでない場合、publicなisBow()メソッドが存在すれば、その戻り値を表示する
	* 2-5. そうでない場合、publicなhasBow()メソッドが存在すれば、その戻り値を表示する
</div>
3. 上記のどれでもない場合は、不正な値としてnullとし、何も表示しない

上記ルールの３について少し補足します。不正な値の場合に null として何も表示させないのは表5-1にあるTwigの環境設定の設定項目 strict_variables の値をデフォルトのfalseとした場合です。これを true とすると、エラーが表示されます。  
その確認となるのが、リスト5-9の(7)です。テンプレート変数として存在しないものを次のように記述しています。
```
<p>{{mue}}</p>
```
リスト5-10の$twigの記述に ` , ["strict_variables"=>true]` を追記してみます。（※routes.phpの51行目のコメントアウトを取って、50行目をコメントアウトしてみてください。）
```
$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates", ["strict_variables"=>true]);
```
そして、<http://localhost:9810/slimview/public/dotAccess>にアクセスすると、  
次のエラーメッセージが表示されます。
```
al error: Uncaught Twig\Error\RuntimeError: Variable "mue" does not exist. 
```
※確認したら、コメントアウトを元に戻しておいてください。

### コメント

テンプレートにコメントを記述する方法は、HTML記述がベースとなっているファイルですので、もちろん`<!-- -->`のHTMLコメントも利用できます。一方、Twigのコメントは次の構文となっています。

<p class="tmp"><span>書式</span>Twigのテンプレート内コメント</p>
```
{# コメント #}
```


## 5-4. フィルタ

テンプレート変数は、表示の際に加工することが可能です。これを**<span class="text-green">フィルタ</span>**といいます。

<div markdown="1" class="green-box">
* テンプレート変数が表示されるときに加工できるのがフィルタ。
* フィルタを利用するには、|（パイプ）に続けてフィルタ名を記述する。
* フィルタは、複数併用できる。
</div>

### フィルタはパイプを記述

テンプレート変数が表示されるときに加工を施すフィルタの利用方法は、テンプレート変数に「<span class="red bold"> |</span>（パイプ）」を続けてフィルタ名を記述します。

<p class="tmp list"><span>リスト5-11</span>routes.php</p>
```
$app->any("/useFilter",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$assign["msg"] = "こんにちは。\nさようなら。";//･･･(1) 
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "useFilter.html", $assign);
		return $response;
	}
);
```
(1)では、テンプレート変数として改行付きの文字列（\n）を用意しています。これをそのままテンプレートに表示させたとしてもうまくいきません。というのは、HTMLでは改行記号は改行として表示されないからです。HTMLの改行はbrタグです。元データとして改行が含まれている文字列を表示する際は、改行記号をbrタグに書き換える必要があります。

PHPではそのための関数として**<span class="red blod">nl2br()</span>** が用意されてます。通常はこの関数を利用して改行記号をbrタグに変換して表示させます。  Twigのテンプレートではこの処理をフィルタに任せます。

次のテンプレートファイルを作成します。
<p class="tmp list"><span>リスト5-12</span>templates/useFilter.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>フィルタの利用</title>
</head>
    <body>
        <p>{{msg}}</p>
        <hr>
        <p>{{msg|nl2br}}</p><!-- nl2brでbrタグに変換しています。
    </body>
</html>
```

http://localhost:9810/slimview/public/useFilter にアクセスしてみましょう。以下の画面が表示されるはずです。

![](upload/useFilter.png)

下の方では、msg という変数名の次に 「**<span class="text-red">|</span>**」を記述し、改行記号をbrタグに変換してくれるフィルタである**<span class="text-red"> nl2br </span>**を記述しています。


### Twigのフィルタ一覧

ここで、Twigでどのようなフィルタが利用可能なのか、主なものを表5-2にまとめています。

<p class="tb-caption"><span>表5-2</span>Twigで利用可能な主なフィルタ</p>
|フィルタ名|　内容|　対応するPHP関数|
|--|--|--|
|<span class="green bold">date</span> |日時のフォーマットを行う |date()|
|<span class="green bold">default</span> |テンプレート変数の値がない場合に表示されるデフォルト値を設定 |なし|
|<span class="green bold">escape</span> |エスケープを行う |htmlspecialchars()|
|<span class="green bold">json_encode</span> |JSONエンコードを行う |json_encode()|
|<span class="green bold">length</span> |配列などの要素数を表示 |count()|
|<span class="green bold">nl2br</span> |改行記号をbrタグに変換する |nl2br()|
|<span class="green bold">number_format</span> |数値のフォーマットを行う |number_format()|
|<span class="green bold">url_encode</span> |URLエンコードを行う |rawurlenncode()|

上記の表以外でも、さまざまなものが用意されています。それらは、下記のTwigの公式ドキュメントから確認できます。
<https://twig.symfony.com/doc/3.x/filters/index.html>

表5-2の補足として、escapeについてです。TwigはデフォルトでHTMLのエスケープを行って表示されます。ですので、本来、escapeフィルタは不要です。使用する場合といえば、あえて、autoescapeがfalseでエスケープが適用されない状態で、部分的にエスケープを行いたい、といった状況です。

なお、フィルタによっては引数が必要なものがあります。例えば、dateフィルタはその元となる関数が日付フォーマット形式を表す文字列が引数として必要ですので、同様にフィルタでもフォーマット文字列を渡す必要があります。その場合は、関数と同じように次のような記述をします。
```
{{updatedDate|date("Y/m/d H:i:s")}}
```


### 複数のフィルタを併用する

フィルタは複数重ねることができます。例えば、次のような記述です。
```
{{memo|nl2br|default(("&nbsp")}}
```

上記のコードは、まず、テンプレート変数memo 中の改行記号をbrタグに変更します。  
その次に、値がないかどうかを判定して、ない場合にdefault フィルタの引数として指定された半角スペースを出力します。


### メモ

#### TwigExtention クラス

Twig-Viewパッケージでは、Twigの機能拡張として TwigExtention クラスというものが用意されており、それを導入することでルーティングパターンを元にURLに展開表示してくれるようになります。次のようなコードです。
```
<p>{{url_for("dummy")}}</p>
```
このdummyは、4章の「[ルーティングに名前を付ける](../p__slim4-1/#4routingName)」で紹介したルーティング名であり、このようにルーティング名を指定することで、例えば、次のように、そのルーティングパターンに自動展開してくれます。
```
<p>/slimview/public/dummyPath</p>
```

## 5-5. 条件分岐

変数を使って画面の表記を制御する、**<span class="text-green">条件分岐</span>**と**<span class="text-green">ループ</span>**を説明します。

<div markdown="1" class="green-box">
* Twigで制御構文を記述するには、{%･･･%} と波括弧と % で囲む
* 条件分岐は、通常のPHP同様に if～elseif～else が利用できるが、必ずendif ブロックを記述する必要がある。
* 条件を記述するときの()は不要。
* 条件の isset や empty も不要。
* 条件の論理演算子は、and、or、not と英単語を使う。
</div>


### 条件分岐を使う

条件分岐に限らず、Twigで制御構文を記述するには<span class="red bold"> {%･･･%}</span> と波括弧と % で囲みます。そのうち、条件分岐は通常のPHP構文と同じように if-elseif-else が利用できます。

<p class="tmp list"><span>リスト5-13</span>routes.php</p>
```
$app->any("/ifStatement",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$assign["rand"] = rand(1, 3);//･･･(1) 1～3の乱数
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "ifStatement.html", $assign);
		return $response;
	}
);
```
上記の(1)の乱数を使って、おみくじのようなテンプレートを作成します。

<p class="tmp list"><span>リスト5-14</span>templates/ifStatement.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>条件分岐</title>
</head>
    <body>
        <p>
        {% if rand == 1 %}
            大吉です!<br>
            おめでとうございます!
        {% elseif rand == 2 %}
            中吉です!
        {% else %}
            凶です!
        {% endif %}
        </p>
    </body>
</html>
```
作成が完了したら、  
http://localhost:9810/slimview/public/ifStatement にアクセスしてみて下さい。


「凶です!」

「中吉です!」

「大吉です!  
おめでとうございます!」

更新するたびに、上記の文字がランダムに表示されます。

※リスト5-14にあるように、条件中で利用する変数はテンプレート変数とになりますので、$ の記述は不要になります。


### 条件中の isset や empty は不要

通常のPHPでは、**isset()関数**や **empty()関数** を利用してデータが存在するかチェックするコードを記述します。  
これが、Twigでは不要となります。例えば、次のようなコードです。

```
{% if validationMsgs %}
<section id="errorMsg">
			：
</section>
{% endif %}
```
このコードでは、テンプレート変数**validationMsgs** が存在していれば、endif で囲まれた範囲のsectionタグが表示されることになります。
これは、つまりは、次の条件分岐コードと同じです。

```
if(isset($validations)) {･･･}
```

もし**validationMsgs** が連想配列ならば、空の配列でなければ、同様に、sectionタグが表示されます。これは、次の条件分岐コードと同じです。

```
if(!empty($validationMsgs)) {･･･} 
```

### 論理演算子は英単語

通常のPHPで isset() を例に考えるならば、次のように否定<span class="red">** ! **</span>をつけます。

```
if(!isset($validationMsgs)) {･･･}
```
これを、Twig の構文にすると次のように <span class="red bold">not</span> を記述することになります。

```
{% if not validationMsg %}
<section id="errorMsg">
			･･･
</section>
{% endif %}
```

同様に、「かつ」を表す **&&** は <span class="red bold">and</span>、「または」を表す** ||** は <span class="red bold">or</span> を使います。例えば、次のようなコードとなります。

```
{% if age >= 20 and age <= 80 %}
```
この場合は、テンプレート変数 age が20以上かつ80以下、という条件になります。


## 5-6. ループ

<div markdown="1" class="green-box">
* Twigのループ構文は for を記述し、必ず、endfor ブロックを記述する。
* foreachと同等の使い方をする場合は、as の代わりに in を記述し、=>の代わりにカンマを記述する。
* カウンタ変数を利用したループの代わりは、.. （ドット2個）で範囲を指定する。
* ループが回らなかった時の処理として、else を記述する。
* ループ内では、ループの状態を取得できる特殊な変数が利用できる。
</div>


### 配列のループ

Twigのループ構文は次の通りです。

<p class="tmp"><span>書式</span>Twigのループ構文</p>
```
{% for 各要素を格納する変数名 in ループ対象 %}
	:
{% endfor %}
```

具体例でみていきます。まず、routes.phpに下記のリスト5-15を追記します。

<p class="tmp list"><span>リスト5-15</span>routes.php</p>
```
$app->any("/forStatement",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$validationMsgs[] = "お名前の入力は必須です。";//･･･(1) メッセージ文字列を登録
		$validationMsgs[] = "年齢は数値で入力してください。";//･･･(1) 上記に同じ
		$assign["validationMsgs"] = $validationMsgs;//･･･(2) テンプレート変数として登録
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "forStatement.html", $assign);
		return $response;
	}
);
```

<p class="tmp list"><span>リスト5-16</span>templates/forStatement.html</p>
```
<!DOCTYPE html>
<html lang="ja">

<head>
	<meta charset="UTF-8">
	<title>ループ</title>
</head>

<body>
	<ul>
		{% for msg in validationMsgs %}
		<li>{{msg}}</li>
		{% endfor %}
	</ul>
</body>

</html>
```

http://localhost:9810/slimview/public/forStatement にアクセスしてみて下さい。

下記のように表示されるはずです。
![](upload/forStatement.png)


リスト5-16のループの部分を通常のPHPで書くと、以下のようになります。
```
foreach($validationMsgs as $msg) {･･･}
```
※通常のPHPのforeach構文の<span class="red bold">as</span>の代わりとなるのが<span class="blue bold">in</span>ですが、前後の順序が逆となるのに注意してください。

### 連想配列のループ

前項では配列のループを扱いました。これが連想配列となると、どうなるでしょうか

<p class="tmp list"><span>リスト5-17</span>routes.php</p>
```
$app->any("/forStatement2",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$resultList = ["A"=>"田中", "B"=>"中野", "C"=>"野村"];//･･･(1) 
		$assign["resultList"] = $resultList;
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "forStatement2.html", $assign);
		return $response;
	}
);
```

<p class="tmp list"><span>リスト5-18</span>forStatement2.html</p>
```
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>連想配列のループ</title>
</head>

<body>
    <ul>
        {% for key, value in resultList %}<!--･･･(1) 格納した値をループして表示-->
        <li>{{key}}は{{value}}です</li>
        {% endfor %}
    </ul>
</body>

</html>
```
リスト5-17で連想配列$resultListに値を格納して、

http://localhost:9810/slimview/public/forStatement2 にアクセスしてみて下さい。

以下のように、表示されるはずです。

![](upload/forStatement2.png)


通常のPHPのループ構文で書き換えると、以下のようになります。  
=>のかわりに、Twigではカンマを使っているのがわかると思います。

```
foreach($resultList as $key=>$value) {･･･}
```


### カウンタ変数を使ったループ
ループ処理は何も配列を対象としたものだけではありません。カウンタ変数を使ったループも可能です。  
例えば、通常のPHPループ構文で次のような記述の場合を考えます。
```
for($month = 1; $month <= 12; $month++) {･･･}
```
上記はカウンタ変数として $month を用意し、それが1～12まで変化するループ処理です。  
これをTwigのテンプレート上に記述すると次のようになります。
<p class="tmp"><span>書式</span></p>
```
{% for month in 1..12 %}
・・・
{% endfor %}
```
ループ対象として、<span class="green bold">..</span>（ドット2個）を数値で挟み込んだ記述をすると、その数値の範囲をカウントアップしながらループしていきます。


### ループのelseブロック

テンプレートに（連想）配列のループ処理を記述していくと、場合によっては対象となる（連想）配列が空の場合があります。その場合、通常は表示を変えます。  
例えば、ある検索結果をリスト表示させる場合を考えます。検索結果がある場合は、その検索結果をループさせながらリスト表示させますが、検索結果がない場合は、「該当するデータはありません」のようなメッセージを表示させる必要があります。ここで、検索結果の連想配列が $resultList だとすると、通常のPHPの構文では次のようなコードになります。
```
if(empty($resultList)) {
	「該当するデータはありません」と表示させる処理
] else {
	foreach($resultList as $result) {
		リスト表示させる処理
	}
}
```

これが、Twigの記法では、次のようになります。
<p class="tmp"><span>書式</span></p>
```
{% for result in resultList %}
	リスト表示させる処理
{% else %}
	「該当するデータはありません」と表示させる処理
{% endfor %}
```

### ループ変数

ループ変数とは、ループブロック内ではそのループの状態を取得できる特殊な変数のことです。  
これらはすべて {{<span class="green bold">loop</span>.〇〇}} の記述となっています。どのような変数があるのか表5-3にまとめています。


<p class="tb-caption"><span>表5-3</span>ループ変数</p>
| 変数名 | 内容 |
| -------- | -------- 
|  loop.<span class="green bold">index</span>    | 現在の繰り返し回数（1始まり）を取得    |
| loop.<span class="green bold">index0</span>     |  いわゆるインデックス値を取得。0始まりの値で、繰り返し回数を-1したもの   |
| loop.<span class="green bold">revindex</span>     | 残りの繰り返し回数を取得。ただし、最後のループを残り1として計算したもの    |
| loop.<span class="green bold">revindex0 </span>    | 残りの繰り返し回数を取得。ただし、最後のループを残り０として計算したもの    |
| loop.<span class="green bold">first</span>     | 最初の繰り返しならばtrue    |
| loop.<span class="green bold">last</span>     | 最後の繰り返しならばtrue    |
| loop.<span class="green bold">length</span>     | ループ対象の要素数を取得    |
| loop.<span class="green bold">parent</span>     | ループが入れ子になっている場合、親ループのloop変数を取得    |




<p class="tmp list"><span>リスト5-19</span>routes.php</p>
```
$app->any("/loopVals",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$resultList = ["A"=>"田中", "B"=>"中野", "C"=>"野村", "D"=>"村井", "E"=>"井田"];
		$assign["resultList"] = $resultList;
    $twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "loopVals.html", $assign);
		return $response;
	}
);
```

<p class="tmp list"><span>リスト5-20</span>loopVals.html</p>
```
<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>ループ変数</title>
</head>

<body>
    <ul>
        {% for key, value in resultList %}
        <li>
            {% if loop.first %} <!-------・ -->
            ループの始まりです。<br><!---- (1) 条件分岐1-->
            {% endif %}<!---------------・ -->
            {{loop.index}}回目: {{key}}は{{value}}です。残り回数は{{loop.revindex0}}回です。<!-- (2) -->
            {% if loop.last %} <!--------・ -->
            <br>ループの終わりです。<!---- (3) 条件分岐2-->
            {% endif %} <!---------------・ -->
        </li>
        {% endfor %}
    </ul>
</body>

</html>
```

http://localhost:9810/slimview/public/loopVals にアクセスしてみて下さい。  
以下のように表示されます。

![](upload/loopVals.png)

`{{loop.index}}回目: {{key}}は{{value}}です。残り回数は{{loop.revindex0}}回です。`

を

`{{loop.index0}}回目: {{key}}は{{value}}です。残り回数は{{loop.revindex}}回です。`

のように、**loop.index** を**<span class="text-green"> loop.index0</span>** に変更し、**loop.revindex0** を **<span class="text-green">loop.revindex</span>** に変更すると、次のような表示になります。

![](upload/loopVals0.png)

## 5-7. その他の便利な Twig構文三種盛り

Twig構文のうち、便利なものを3個ほど紹介します。

<div markdown="1" class="green-box">
* テンプレート内で変数を用意するには、<span class="green bold">set構文</span>を使う。
* 別のテンプレートを読み込むには、<span class="green bold"> include 関数</span>を使う。
* 変数の内容を表示するには、<span class="green bold">dump関数</span>を使う。
</div>

### テンプレート内変数を作成する set

テンプレートで利用する変数は極力コールバック関数内で用意します。しかし、場合によってはテンプレート上で変数を用意しなければならないこともあります。その場合に使われる Tag が <span class="red bold">set</span> です。これは次の構文となります。

<p class="tmp"><span>書式</span>テンプレート内で変数を用意する set 構文</p>
```
{% set 変数名 = 値 %}
```
例えば、次のようなコードとなります。
```
{% set temp = "一時変数" %}
```
このようなコードを記述した場合、テンプレート内では通常のテンプレート変数同様に {{temp}} という記述で変数の内容を表示できます。

格納する値には、配列や連想配列も使えます。

配列の場合だと、通常のPHP同様に次の記述となります。
```
{% set msgs = ["こんにちは", "さようなら"] %}
```
連想配列の場合だと、
```
{% set lists = {"A":"田中", "B":"中野"} %}
```
のように、配列を囲むかっこが、波括弧 <span class="red bold">{}</span> となり、キーと値を結ぶ記号が コロン <span class="red bold">:</span> となります。


### テンプレートの共通部分を別ファイルにできる include

「nav.html」を読み込む場合、次のようなコードになります。
```
{{ include("nav.html") }}
```
この<span class="red bold">include</span>を利用すると、デザインされた画面の共通部分（例えば、ヘッダーやフッターやグローバルナビなど）を別ファイルとして管理することができ、メンテナンス性に優れたアプリの作成が可能となります。


### 変数の内容を表示する dump

テンプレート上で（連想）配列やクラスのインスタンス（オブジェクト）の内容を確認したい場合に、**var_dump()**の代わりに使います。

次のように記述します。
```
{{dump(resultList)}}
```
ただし、dump()関数を有効にするためには、表5-1の環境設定項目 <span class="red bold">debugをtrue</span>にしておく必要があります。


## マークダウンを出力

### エスケープしないで出力する方法

参考サイト
: <https://qiita.com/tomk79/items/5ab61b4b24fb80fe8a90>

デフォルトでは、以下のように文字列に変換されて出力されます。
```
echo $twig->render('{{html}}', array('html' => '<p>Hello World</p>'));
```
<p class="tmp">出力</p>
```
&lt;p&gt;Hello World&lt;/p&gt;
```
※明示的にエスケープする場合、|e または |escape をつけます。

あえてHTMLなどをそのままソースに出力したい場合は、`|raw` で戻すことができます。

```
echo $twig->render('{{html|raw}}', array('html' => '<p>Hello World</p>'));
```

<p class="tmp">出力</p>
```
<p>Hello World</p>
```

Slimでマークダウンファイルを変換サンプル
: <http://localhost:9810/slimview/public/markdownTest>

<p class="tmp list"><span>リスト</span>routes.php</p>
```
$app->any("/markdownTest",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

		$md = file_get_contents("../markdown.md");//マークダウンファイル取得
		$md = file_get_contents($_SERVER["DOCUMENT_ROOT"]."/slimview/pages/p_php/markdown.md");//マークダウンファイル取得
		$Extra = new ParsedownExtra();
		$htmlData = $Extra->text($md);//HTMLに変換

		$assign["htmlData"] = $htmlData;

		$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "markTest.html", $assign);

		return $response;
	}
);
```

<p class="tmp list"><span>リスト</span>markTest.html</p>
```
<!DOCTYPE html>
<html lang="ja">

<head>
	<meta charset="UTF-8">
	<title>Twigによるこんにちは</title>
</head>

<body>
	<div>{{ htmlData|raw }}</div>
</body>

</html>
```

### URLから、出力するマークダウンファイルを選別

<p class="tmp">routes.php</p>
```
//フォルダ名からマークダウンを出力
$app->any('/pages/{folderName}',
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

		$folder = $args['folderName'];
		$md = file_get_contents($_SERVER["DOCUMENT_ROOT"].'/slimview/pages/'.$folder.'/markdown.md');//マークダウンファイル取得
		$Extra = new ParsedownExtra();
		$htmlData = $Extra->text($md);//HTMLに変換

		$assign["htmlData"] = $htmlData;

		$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
		$response = $twig->render($response, "markTest.html", $assign);

		return $response;
	}
);
```
下記のリンクの末尾の「/p_php」と「/p_slim」によって、表示する内容が変わります。
* <http://localhost:9810/slimview/public/pages/p_php>
* <http://localhost:9810/slimview/public/pages/p_slim>
* <http://localhost:9810/slimview/public/pages/p_vscode>

作成中
* <http://localhost:9810/slimview2/public/pages/p__vscode>
