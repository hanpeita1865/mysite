*[page-title]:第8章ミドルウェア

ミドルウェアを利用することで、各リクエスト処理の前後に自動的に処理を挿入することができ、メンテナンス性の高いコードにすることができます。

## 8-1. ミドルウェアとその作り方

<div markdown="1" class="green-box">
* リクエスト処理の前後に処理を挿入できる仕組みがミドルウェア。
* ミドルウェアは、Middlewareinterface インターフェースを実装したクラスとして作成する
* ミドルウェアクラスでは、process() メソッドを実装し、その中でhandle()メソッドを実行する
* ミドルウェアを利用するには、ルーティング登録メソッドに続けて add()メソッドを実行する
</div>

～時間ある時に画像挿入～
図8-1 ミドルウェアとは

### サンプルプロジェクトの作成
composer requireコマンドを実行し、次の5パッケージを配置します。
* slim/slim
* slim/psr7
* slim/twig-view
* php-di/php-di
* monolog/monolog

次のオートロードの設定を追記し、Composerのdump-autoloadコマンドを実行してください。

<p class="tmp list"><span>リスト</span>composer.json</p>
```
"autoload": {
    "psr-4": {
        "SocymSlim\\SlimMiddle\\": "classes/"
    }
}
```

<p class="tmp list"><span>リスト8-1</span>public/index.php</p>
```
<?php
use Slim\Factory\AppFactory;

require_once($_SERVER["DOCUMENT_ROOT"]."/slimmiddle/vendor/autoload.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/slimmiddle/containerSetups.php");
$app = AppFactory::create();
require_once($_SERVER["DOCUMENT_ROOT"]."/slimmiddle/routes.php");
$app->run();
```

<p class="tmp list"><span>リスト8-2</span>containerSetups.php</p>
```
<?php
use DI\Container;
use Slim\Factory\AppFactory;
use Slim\Views\Twig;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

$container = new Container();
$container->set("view",
	function() {
		$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimmiddle/templates");
		return $twig;
	}
);
$container->set("logger",
	function() {
		$logger = new Logger("slimmiddle");
		$fileHandler = new StreamHandler($_SERVER["DOCUMENT_ROOT"]."/slimmiddle/logs/app.log");
		$logger->pushHandler($fileHandler);
		return $logger;
	}
);
AppFactory::setContainer($container);
```

<p class="tmp list"><span>リスト8-3</span>routes.php</p>
```
<?php
$app->setBasePath("/slimmiddle/public");
```
これでプロジェクトが作成されました。  
ここに追加していきます。

### ミドルウェアの作り方
ミドルウェアはひとつのクラスとして作成します。ですので、ミドルウェアクラスをまとめて入れておくフォルダとして、<span class="red">classesフォルダ</span>のサブフォルダとして<span class="red">middlewaresフォルダ</span>を作成します。その中に次のリスト8-4のRecordIPAddressクラスを作成してください。

<p class="tmp list"><span>リスト8-4</span>classes/middlewares/RecordIPAddress.php</p>
```
<?php
namespace SocymSlim\SlimMiddle\middlewares; //----(1-1)

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class RecordIPAddress implements MiddlewareInterface //-----(1-2)
{
	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface //-----(2)
	{
		$response = $handler->handle($request); //----(3)

		$serverParams = $request->getServerParams(); //-----(5)
		$ipAddress = $serverParams["REMOTE_ADDR"]; //-----(6)
		$path = $serverParams["REQUEST_URI"]; //-----(7)
		$content = "<p>IPアドレスは".$ipAddress."でパスは".$path."</p>"; //-----(8)ここから
		$responseBody = $response->getBody();
		$responseBody->write($content); //-----(8)ここまで
		
		return $response; //-----(4)
	}
}
```

ミドルウェアの作成手順は次の通りです。
1. 適切なフォルダにミドルウェアクラスを作成する。
2. process() メソッドを実装する。
3. process() メソッド内でhandle()メソッドを実行する。
4. process() メソッドの戻り値として、ResponseInterfaceインスタンスを返す。

順に説明していきます。

#### 1. 適切なフォルダにミドルウェアクラスを作成する。
リスト8-4の(1)、特に、(1-2)が該当します。  
ミドルウェアクラスのクラス名については自由につけることができますが、\Psr\Http\Server\<span class="green bold">MiddlewareInterface</span> インターフェースを実装（implements）したクラスである必要があります。そのため、リスト8-4の(1-2)のクラス宣言では、次の記述になっています。
```
implements MiddlewareInterface //----(1-2)
```
このMiddleInterfaceインターフェースはその完全修飾名からわかるように、<span class="green bold">PSR-15</span>で定義されたインターフェースであり、PSR-15はミドルウェアに関する規約です。ということは、Slimのミドルウェアは、PSRのミドルウェアに準拠したものとなっています。  

なお、このクラスの名前空間について少し補足しておきます。ミドルウェアクラスを作成する場合、格納するフォルダに関して特に取り決めはありません。ただし、オートロードの関係上、<span class="red">フォルダと名前空間に関連性を持たせておく必要があります</span>。slimmiddleプロジェクトでは、slimmiddle/classes/middlewaresフォルダに格納していますので、これに対応するように名前空間を設定しています。  
それが、リスト8-4の(1-1)です。
```
namespace SocymSlim\SlimMiddle\middlewares; //----(1-1)
```


#### 2. process() メソッドを実装する。

リスト8-4の(2)が該当します。  
MiddlewareInterfaceインターフェースでは、メソッドがひとつだけ定義されており、それは次のシグネチャとなっています。
```
public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
```
このことから、ミドルウェアにクラスでは、<span class="green bold">process()</span>メソッドをひとつ実装する必要があります。  
このprocess()メソッドの第1引数は \Psr\Http\Message\SeverRequestsInterfaceインスタンス、第2引数は \Psr\Http\Sever\RequestHandlerInterfaceインスタンスとし、\Psr\Http\Message\ResponseInterfaceインスタンスを戻り値とするものです。



#### 3. process() メソッド内でhandle()メソッドを実行する。
```
$response = $handler->handle($request); //----(3)
```
リスト8-4の(3)が該当し、このコードはprocess()メソッド内では必ず記述する必要があります。  
$handlerはprocess()メソッドの第2引数であるRequestsHandlerInterfaceインスタンスです。詳細は次節で扱いますが、このRequestsHandlerInterfaceインスタンスは、リクエスト処理を行うものであり、そのメソッドhandle()を実行するタイミングでリクエスト処理が行われることになります。  
また、このhandle()メソッドの戻り値はResponseInterfaceインスタンスとなります。


#### 4. process() メソッドの戻り値として、ResponseInterfaceインスタンスを返す。

リスト8-4の(4)が該当します。
```
return $response; //----(4)
```
2の「process() メソッドを実装する」項目で実装したprocessメソッド内にミドルウェアとしての処理、つまり、リクエスト処理の前後に挿入したい処理を記述します。リスト8-4では(5)～(8)が該当し、これについては後述します。そのような挿入したい処理を記述した後、必ずResponseInterfaceインスタンスを戻り値とする必要があります。コールバック関数やコントローラクラスメソッドではその引数にResponseInterfaceインスタンスがあるので、それを利用して戻り値としていました。一方、ミドルウェアクラスのprocess()メソッドの引数にはResponseInterfaceインスタンスがありません。そこで、(3)のhandle()メソッドの戻り値として取得した$responseを利用します。  
このResponseInterfaceインスタンスとしてhandle()メソッドの戻り値を利用する方法は、process()メソッド内の処理にも使われています。具体的に、リスト8-4の(5)～(8)を見ていきます。
　
リスト8-4の(5)～(8)では、本来IPアドレスを取得してどこかに記録するという処理を想定していますが、実際に記録するのではなく画面に表示するようにしています。

IPアドレスを取得しているのがリスト8-4の(5)～(6)です。4-2-2項表4-2にある通り、ServerRequestInterfaceの<span class="green bold">getSeverParams()</span>メソッドを使うと、$_SERVERと同等の連想配列を取得できます。そのコードが(5)です。その連想配列のキー<span class="green bold">REMOTE_ADDR</span>を指定すると、クライアントのIPアドレスが取得できます。それが(6)です。同様に、キー<span class="green bold">REQUEST_URI</span>を指定してルーティングパターンも取得しています。それが(7)です。

そうやって取得したIPアドレスをルーティングパターンを本来はどこかに記録するのでしょうが、ここでは(8)で画面表示しています。画面への表示処理というのは、これまでのサンプルでも紹介したレスポンスボディへの格納コードですが、この部分で、$responseとしてhandle()メソッドの戻り値のResponseInterfaceインスタンスを利用しています。



### ミドルウェアの利用方法

<p class="tmp list"><span>リスト8-5</span>classes/controllers/SlimMiddleController.php</p>
```
<?php
namespace SocymSlim\SlimMiddle\controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;

class SlimMiddleController
{
	private $container;

	public function __construct(ContainerInterface $container)
	{
		$this->container = $container;
	}

	public function middlewareTest(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
	{
		$content = "<p>ミドルウェアのテスト。こちらはリクエスト処理。</p>";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
}
```

<p class="tmp list"><span>リスト8-6</span>routes.php</p>
```
<?php
use SocymSlim\SlimMiddle\controllers\SlimMiddleController;
use SocymSlim\SlimMiddle\middlewares\RecordIPAddress;//----(1)

$app->setBasePath("/slimmiddle/public");//既存（リスト8-3）
$app->any("/doRecordIPAddress", SlimMiddleController::class.":middlewareTest")->add(new RecordIPAddress());//----(2)
```

<p class="tmp"><span>書式</span>ルーティングへのミドルウェア設定</p>
```
$app->any(･･･)->add(ミドルウェアインスタンス);
```
一通りコードが記述できたら、動作確認をしておきましょう。次のURLにアクセスして下さい。

http://localhost:9810/slimmiddle/public/doRecordIPAddress

成功すると、以下のように表示されます。


![](upload/ミドルウェアのテスト.png)


## 8-2. ミドルウェア処理の位置

前項では、リクエスト処理の後に無事ミドルウェアの処理が挿入されたことが実行結果からも確認できました。では、なぜ、リクエスト処理の後なのでしょうか。その種明かしに話をうつしていきましょう。

<div markdown="1" class="green-box">
* ミドルウェアは、handle()メソッドの記述位置で、リクエスト処理の前後どちらにも処理を挿入できる。
* ミドルウェアの設定は、add()メソッドをつなげることで複数設定できる。
* ミドルウェアは、リクエスト処理を中心とする同心円の入れ子構造のように処理が行われていく。
</div>

### リクエスト処理の前に挿入する場合

<p class="tmp list"><span>リスト8-7</span>classes/middlewares/RecordIPAddressBefore.php</p>
```
<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class RecordIPAddressBefore implements MiddlewareInterface
{
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $serverParams = $request->getServerParams();
        $ipAddress = $serverParams["REMOTE_ADDR"];
        
        $path = $serverParams["REQUEST_URI"];
        print("<p>IPアドレスは".$ipAddress."でパスは".$path."</p>");//----(1)

        $response = $handler->handle($request);//----(2)

        return $response;
    }
}
```

<p class="tmp list"><span>リスト8-8</span>routes.php</p>
```
<?php
～省略～
use SocymSlim\SlimMiddle\middlewares\RecordIPAddressBefore;
～省略～
$app->any("/doRecordIPAddressBefore", SlimMiddleController::class.":middlewareTest")->add(new RecordIPAddressBefore());
```

コードが記述できたら、次のURLにアクセスして下さい。

http://localhost:9810/slimmiddle/public/doRecordIPAddressBefore

以下のように表示されれば、成功です。

![](upload/doRecordIPAddressBefore表示テスト.png)

先ほどの/doRecordIPAddressの実行結果と違い、ミドルウェアの処理がリクエスト処理の「<span class="red bold">前</span>」に行われているのが読み取れます。

### 処理の挿入移置はhandle()メソッドの記述位置

ここで、ミドルウェアの処理の前後の区別の種明かしをしていきましょう。ポイントは、次のコードの記述位置です。
```
$response = $handler->handle($request);
```
リクエスト処理の後にミドルウェアの処理を挿入する**リスト8-4**は、process()メソッドの最初に上記コード<span class="green bold">(3)位置</span>が記述されています。つまり、

「<span class="red bold">handle()の実行」 → 「ミドルウェアの処理」</span>

という記述になっています。

一方、リクエスト処理の前にミドルウェアの処理を挿入する**リスト8-7**のprocess()メソッドでは、<span class="green bold">(2)の位置</span>に記述されています。それより前のコードがミドルウェアの処理にあたります。つまり、

<span class="green bold">「ミドルウェアの処理」 → 「handle()の実行」</span>という記述になっています。 

ミドルウェア処理をリクエスト処理の前後どちらに挿入するかは、handle()メソッドの実行位置の前にミドルウェアの処理を記述するか、後に記述するかの違いなのです。この内容を踏まえて、process()メソッドの記述を構文としてまとめておきましょう。

<p class="tmp"><span>書式</span>リクエスト処理の<span class="red">前</span>に処理を挿入する場合</p>
```
public function process(･･･): ResponseInterface
{
	～挿入したい処理～
	$response = $handler->handle($request);
	return $response;
}
```

<p class="tmp"><span>書式</span>リクエスト処理の<span class="green">後</span>に処理を挿入する場合</p>
```
public function process(･･･): ResponseInterface
{
	$response = $handler->handle($request);
	～挿入したい処理～
	return $response;
}
```

### handle()メソッドの正体

process()メソッドの第2引数の型として記述されている \Psr\Http\Sever\<span class="green bold">RequestHandlerInterface</span>は、MiddlewareInterface同様に、PSR-15で定義されたインターフェースで、リクエスト処理を行うもの、と定義されています。このRequestHandlerInterfaceにはhandle()メソッドが定義されており、引数としてSeverRequestInterfaceインスタンスをもらい、そのSeverRequestInterfaceインスタンスをもとにリクエスト処理を行い、

～時間ある時に記入～

### リクエスト処理前後の両方に処理を挿入

前項のhandle()メソッドの正体がわかると、process()メソッド内でhandle()の位置は、ミドルウェア処理の前か後かの二択ではなく、実は柔軟に変えられることに気づきます。つまり、ひとつのミドルウェアクラスによって挿入される処理というのは、リクエスト処理の前後の両方に挿入できる記述が可能なのです。

実際にコードで確認してみましょう。まず、ミドルウェアクラスとして、リスト8-9のBeforeAndAfterクラスを作成してください。

<p class="tmp list"><span>リスト8-9</span>classes/middlewares/BeforeAndAfter.php</p>
```
<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class BeforeAndAfter implements MiddlewareInterface
{
	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
	{
		print("<p>リクエスト処理の前のミドルウェア</p>");

		$response = $handler->handle($request);

		$content = "<p>リクエスト処理の後のミドルウェア</p>";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		
		return $response;
	}
}
```

<p class="tmp list"><span>リスト8-10</span>routes.php</p>
```
<?php
～省略～
use SocymSlim\SlimMiddle\middlewares\BeforeAndAfter;//追加
～省略～
$app->any("/beforeAndAfter", SlimMiddleController::class.":middlewareTest")->add(new BeforeAndAfter());//追加
```

コードの記述が出来たら、次のURLにアクセスして下さい。

http://localhost:9810/slimmiddle/public/beforeAndAfter

![](upload/前後ミドルウェア.png)

前後にミドルウェアの処理が挿入されているのが、見て取れると思います。

～時間ある時に画像挿入～
図8-2 ミドルウェアとリクエスト処理の関係

図8-1ではリクエスト処理の前後に挿入されるようなイメージ図でしたが、どちらかというと、図8-2のように、リクエスト処理から同心円状に包み込むようなものがミドルウェアといえます。リクエストは、まずミドルウェアのprocess()メソッドで処理され、その中でhandle()を実行することでリクエスト処理が実行されます。そのリクエスト処理により生成されたレスポンスを受け取り、さらにそれをバケツリレー的にリターンすることで、実際のレスポンスとしてクライアントに送信されていきます。

### ミドルウェアのチェイン

さらに、このミドルウェアはひとつだけではなく、複数設定することができます。実際に行ってみましょう。まず、リスト8-9のBeforeAndAfterミドルウェアクラスとほぼ同じ内容のミドルウェアクラスとして、リスト8-11のOuterクラスを作成してください。

<p class="tmp list"><span>リスト8-11</span>classes/middlewares/Outer.php</p>
```
<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class Outer implements MiddlewareInterface
{
	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
	{
		print("<p>リクエスト処理の前の外側のミドルウェア</p>");

		$response = $handler->handle($request);

		$content = "<p>リクエスト処理の後の外側のミドルウェア</p>";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		
		return $response;
	}
}
```

<p class="tmp list"><span>リスト8-12</span>routes.php</p>
```
<?php
～省略～
use SocymSlim\SlimMiddle\middlewares\Outer;
～省略～
$app->any("/nested", SlimMiddleController::class.":middlewareTest")->add(new BeforeAndAfter())->add(new Outer()); //----(1)
```
ここでのポイントは、リスト8-1２の(1)です。add()メソッドの実行を2回行っています。1回目でBeforeAndAfterの設定を、2回目でOuterの設定を行っています。このように、add()を複数つなげる（チェインする）だけでミドルウェアを複数設定できます。 

では、次のURLにアクセスして下さい。

 http://localhost:9810/slimmiddle/public/nested
 
 ![](upload/ミドルウェアのチェイン.png)

～時間ある時に図を挿入～

図8-3 複数ミドルウェアとリクエスト処理の関係


### ミドルウェアにデータを渡す方法

<div markdown="1" class="green-box">
* ミドルウェアでコンテナを利用する場合は、コンストラクタの引数として定義しておく。
* コンテナ以外にも、コンストラクタの引数として必要なデータを定義しておくと、
</div>

### ミドルウェアでコンテナを利用するには

ミドルウェアで画面に何かを表示する処理を記述することはまれです。というのは、画面表示処理というのは、リクエストとレスポンスの対の中で一番中心となる処理であり、それはリクエスト処理そのものに任せるということの方が普通だからです。では、ミドルウェアが活躍する場面というのはどういうのかというと、やはりリクエスト処理の前後において何かを記録する。あるいは、何かのデータの整合性をチェックする、といった裏方的な処理となります。

最初の節で例に挙げたIPアドレスの記録というのも、本来ならば、DBやログに記録するものです。もしログに記録するとなると、Monologを利用することになりますが、このMonologのインスタンスはコンテナから取得する必要があります。ところが、ミドルウェアクラス内ではそのままではコンテナが存在しませんので、他からもらう必要があります。これにはコンストラクタを利用します。実際にコードで確認していきましょう。

<p class="tmp list"><span>リスト8-13</span>classes/middlewares/RecordIPAddressToLog.php</p>
```
<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;

class RecordIPAddressToLog implements MiddlewareInterface
{
	private $container;

	public function __construct(ContainerInterface $container)
	{
		$this->container = $container;
	}

	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
	{
		$serverParams = $request->getServerParams();
		$ipAddress = $serverParams["REMOTE_ADDR"];
		$path = $serverParams["REQUEST_URI"];
		$content = "IPアドレスは".$ipAddress."でパスは".$path;
		$logger = $this->container->get("logger");
		$logger->info($content);

		$response = $handler->handle($request);
		return $response;
	}
}
```

### ミドルウェアにコンテナを渡すには

コンストラクタを通してコンテナを受け取れるようになったミドルウェアを実際に使ってみましょう。

コントローラの場合は、コンストラクタの引数でコンテナを設定しておくだけでSlim本体が自動でコンテナを渡してくれる仕組みでしたが、ミドルウェアはそのようになっていません。ですので、手動でコンテナを渡してあげるようにコードを記述する必要があります。といっても、簡単なコードです。

<p class="tmp list"><span>リスト8-14</span>routes.php</p>
```
<?php
～省略～
use SocymSlim\SlimMiddle\middlewares\RecordIPAddressToLog;
～省略～
$app->any("/doRecordIPAddressToLog", SlimMiddleController::class.":middlewareTest")->add(new RecordIPAddressToLog($container));//----(1)
```

コードを記述したら、次のURLにアクセスして下さい。

http://localhost:9810/slimmiddle/public/doRecordIPAddressToLog

![](upload/ミドルウェアにデータを渡す.png)

### コンテナ以外のデータも渡せるコンストラクタ

このコンストラクタを利用してミドルウェアにコンテナインスタンスを渡す方法というのは、そのまま他のデータに関しても利用可能です。というのは、コンストラクタの引数というのはいくつでも設定できるからです。例えば、次のようなコンストラクタを定義したRecordSomethingミドルウェアがあるとします。

```
public function __construct(ContainerInterface $container, array $params) {･･･
```
すると、このミドルウェアを利用する場合は次のようにnewの時に第2引数としてパラメータを渡すことが可能です。
```
$params = ["pattern"=>2, "auth"=>1];
$app->any(･･･)->add(new RecordSomething($container, $params));
```
RecordSomethingミドルウェア内では、コンストラクタ経由で受け取った$paramsのデータを利用してログに記録する内容をさまざまに分岐することも可能です。  
この方法を利用することで、ミドルウェアの可能性はどんどん広がっていきます。

## ミドルウェア設定のバリエーション

<div markdown="1" class="green-box">
* ルーティンググループにミドルウェアを設定するには、group()メソッドに続けて add()メソッドを実行する。
* アプリケーション全体にミドルウェアを設定するには、$app->add()メソッドを実行する
</div>

### ルーティンググループにミドルウェアを設定

まず、一つ目はルーティンググループへのミドルウェア設定です。  
複数のルーティング登録をグループ化することが可能です。それは、例えば、次のようなコードとなります。
```
$app->group("/management", function(RouteCollectorProxy $group) {
	$group->any("/users/showList", ･･･);
	$group->any("/users/addUser", ･･･);
	$group->any("/users/showDetail", ･･･);
})->add(new RecodeManagerId($container));
```

$group()メソッドに続けてadd()メソッドを実行するだけです。

<p class="tmp"><span>書式</span>ルーティンググループへのミドルウェア設定</p>
```
$app->group("･･･", function(RouteCollectorProxy $group) {
	・・・
})->add(ミドルウェアインスタンス);
```
これを利用すると、特定のルーティングパターン配下のリクエスト処理にまとめてミドルウェアを適用したい場合に便利です。

### アプリケーション全体にミドルウェアを設定

二つ目は、アプリケーション全体にミドルウェアを設定する方法です。ルーティングパターンに関係なく、そのアプリケーションのリクエスト処理すべてにミドルウェアを適用するには次の構文を使います。

<p class="tmp"><span>書式</span></p>
```
$app->add(ミドルウェアインスタンス);
```

Slimの本体クラスインスタンスである$appに対してadd()メソッドを実行します。例えば、次のようなコードです。
```
$app = AppFactory::create();
$app = add(new RecordAccess($container));
```
このコードを、例えばindex.phpなどに記述しておくと、このアプリケーションでのすべてのリクエストに対して、RecordAccessミドルウェアが適用されることになります。





