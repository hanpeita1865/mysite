*[page-title]:文字列操作（explode、implode、trim、mb_substr）

## 文字列を分割して配列に格納（explode）

PHPで「CSVを取り込んだ文字列をカンマで分割したい」と思ったことは誰でもあると思います。そこで便利なのがexplode関数です。この関数を使えば１行で文字列の分割を行うことができます。

<p class="tmp"><span>書式</span></p>
```
配列変数 = explode('区切り文字', '文字列', [最大の要素数]);
```

<div class="exp">
	<p class="tmp"><span>例1</span></p>
</div>
<iframe src="https://paiza.io/projects/e/7PhMlot1e_NUUEXw5WO0MA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

第三引数に要素数3を指定してみます。
<div class="exp">
	<p class="tmp"><span>例2</span></p>
</div>
<iframe src="https://paiza.io/projects/e/HD9MzL8UhYU9OpMHioNp4A?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
「ハラミ,ホルモン,*ロース,カルビ,タン*」のうち、3つの要素が配列に格納されます。赤文字の箇所は1つの要素になります。

explode()の分割結果を受け取るには、配列で受ける方法とlist()を使う方法とがあります。  
分割される数があらかじめ分かっている場合はlist()を使うことができます。

### list() 

<iframe src="https://paiza.io/projects/e/_-o5rjKIUq3sfRHsD8SCAg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
文字列「田中,おはよう,25」を「,」で分割して、$name, $message, $numの変数にそれぞれ格納しています。

## 配列を結合する（implode）

<p class="tmp"><span>書式</span></p>
```
implode('区切り文字', 配列);
```
※implode()は、引数をどちらの順番でも受けつけることが可能です。しかし、explode() との統一性の観点からは、 書式に記述された引数の順番を使用する方が混乱が少なくなるでしょう。

<iframe src="https://paiza.io/projects/e/9C4B5B69AMEXyKENTnamlw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
変数にそれぞれ格納した「西川」「真田」「藤原」をarray()で配列にしてから、implodeで結合しています。

## 空白や指定した文字を削除する（trim） 

文字列の先頭と末尾にある余分な空白を取り除きたい場合は、trim関数を使用します。

<p class="tmp"><span>書式</span></p>
```
string trim( '対象文字列' [, '削除したい文字'] )
```
第一引数には対象の文字列を指定します。  
第二引数には削除したい文字を指定したり、削除したい全ての文字をリストで指定することも可能です。

なお、第二引数を指定しない場合は通常の空白（” “）のほか、  
「タブ（”\t”）」「リターン（”\n”）」「改行（”\r”）」「NULL(“\0”)」「垂直タブ（”\x0B”）」  
も空白と同様に削除されます。

<iframe src="https://paiza.io/projects/e/zuJVg_HtxGiV7Ab7aMeA7g?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
trim関数を使用して、先頭と末尾のスペースを取り除いています。

### 削除する文字を指定する

trim関数は第二引数を指定することで、空白以外に削除したい文字を指定することができます。  
第二引数は1文字ずつ指定、または'ABCD'のように複数の削除したい文字を指定することも可能です。

<iframe src="https://paiza.io/projects/e/GmoKwKp2CmzK4VsezX7jDQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## 文字列の文字を取得する（substr、mb_substr） 

文字列の中から指定した位置から指定した分だけ文字を取り出します。（バイト数で指定）

<p class="tmp"><span>書式</span>substr()</p>
```
substr(対象の文字列, 取り出し開始位置(0なら先頭) [, 取り出す文字のバイト数])
```

<iframe src="https://paiza.io/projects/e/KgAewnExiASd-MqgkCiB_w?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


**文字数**で指定した場合には「mb_substr」関数を使います。半角文字も全角文字も1文字は1文字として扱います。  
また開始位置をマイナスの値で指定した場合、文字列の最後の位置から先頭に向かって何文字目かという意味になります。

<p class="tmp"><span>書式</span>mb_substr()</p>
```
mb_substr(対象の文字列, 取り出し開始位置(0なら先頭) [, 取り出す文字数])
```

### 例）文字数単位で文字を切り出すサンプル

```
<?php
 $aa = "あいうABCえお";

 //3文字目から後ろを取得する
 print mb_substr($aa, 2);
 →うABCえお

 //先頭から4文字分取得する
 print mb_substr($aa, 0, 4);
 →あいうA

 //2文字目から6文字分取得する
 print mb_substr($aa, 1, 6);
 →いうABCえ
 ```

<iframe src="https://paiza.io/projects/e/GaX10N1DtK2EasMxegbBUw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>






## 参考サイト ##{#p-reference}

* [文字列の一部を取得(substr, mb_substr)](https://www.javadrive.jp/phpfunc/string/index2.html)
* [PHPで先頭と末尾から空白文字を削除する：trim, ltrim, rtrim ](https://uxmilk.jp/26446)
* [文字数単位で文字を切り出す（mb_substr）](https://php.programmer-reference.com/php-mb_substr/)

