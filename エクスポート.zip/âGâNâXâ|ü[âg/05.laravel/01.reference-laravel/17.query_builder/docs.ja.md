---
title: '17. クエリビルダ'
media_order: 'query_builder1.png,query_builder2.png,query_builder3.png,query_builder4.png,query_builder5.png,query_builder6.png,query_builder7.png,query_builder8.png,query_builder9.png,query_builder10.png,bullder_all1.png,bullder_all2.png,bullder_show.png,bullder_show2.png,bullder_like1.png,bullder_show3.png,bullder_show4.png,bullder_order1.png,bullder_offset0.png,bullder_offset1.png,bullder_offset2.png,bullder_insert1.png,bullder_insert2.png,bullder_update1.png,bullder_update2.png,bullder_update3.png,bullder_delete1.png,bullder_delete2.png,bullder_delete3.png,bullder_show.png'
taxonomy:
    category:
        - docs
---

* [クエリビルダとは?](#p1)
* [DB::tableとget](#p2)
* [指定したIDのレコードを得る](#p3)
* [演算記号を指定した検索](#p4)
	* [あいまい検索](#p4-1)
* [where と or Where](#p5)
* [whereRawによる条件検索](#p6)
* [並び順を指定する「orderBy」](#p7)
* [offset と limit](#p8)
* [insertによるレコード追加](#p9)
* [updateによるレコード更新](#p10)
* [deleteによるレコード削除](#p11)

DBクラスには、「***クエリビルダ***」と呼ばれる機能が用意されています。これを利用することで、メソッドチェーンを使ってデータベースアクセスが行えるようになります。その使い方を説明しましょう。

## クエリビルダとは? ##{#p1}
SQLクエリ文をデータベースに送信することでデータベースを操作するやり方は、SQLがわかっていれば簡単です。が、あまりいい方法はといえません。  
なにより、「バグが紛れ込みやすい」という欠点があります。SQL文にパラメータ配列の値を組み込んで文を生成するため、正しくSQL文ができているのかがわかりにくいのは確かです。また、渡される値の内容などによっては、予想外のSQL文が実行されてしまう危険もあります。

そもそも、「PHPでプログラムを書いているのに、データベースの部分だけは別の言語で書かないといけない」というのは非常にストレスでしょう。  
そこで用意されたのが、「***クエリビルダ***」です。*クエリビルダは、SQLのクエリ文を生成するために用意された一連のメソッドです。*さまざまな要素を表すメソッドをメソッドチェーンとして連続して呼び出していくことで、SQLクエリ文を内部で生成し、実行することができます。   
メソッドを呼び出していくだけなので、生成されるSQLクエリ文は表面に現れることはなく、制作している人間もクエリの存在を意識することはありません。ごく普通のPHPの処理としてメソッドを呼び出していくだけで、主なデータベースアクセスが実現できます。

## DB::tableとget ##{#p2}
では、早速クエリビルダを利用してみましょう。まずは、基本である「テーブルの全レコードを取得する」という操作を作成してみます。  
先に、/helloアクションで全レコードを表示する処理を作成していました。これを書き換えて使うことにしましょう。HelloControllerクラスのindexアクションメソッドを、 クエリビルダ利用に書き換えてみます。

<p class="list tmp"><span>リスト1</span></p>
```
public function index(Request $request)
{
   $items = DB::table('customer')->get();
   return view('hello.index', ['items' => $items]);
}
```

修正したら、/helloにアクセスしてみましょう。すると、customerテーブルの全レコードが表示されます。DB::selectでレコードを取得したのと、動作に全く変わりがないことがわかるでしょう。

![](bullder_all1.png?classes=caption "図1　ビルダで全レコード表示")


### DB::table について
ここでは、DBクラスの「table」というメソッドを呼び出しています。これは、以下のように利用します。
<p class="tmp"><span>書式1</span></p>
```
$変数 = DB::table( テーブル名 );
```
この***DB::table***は、指定したテーブルの「***ビルダ***」を取得します。ビルダは、Illuminatel Database\Query名前空間にあるBuilderクラスで、SQLクエリ文を生成するための機能を提供します。

DB::tableでビルダを用意し、後はこのビルダの中に用意されているメソッドを呼び出していくことで、ビルダの具体的な設定を行ったり、テーブルの操作などが行ったりで きる、というわけです。

### get について
ここでは、ビルダの「***get***」メソッドを使っています。これは、そのテーブルにあるレコードを取得するもので、SQLのselect文に相当するものと考えていいでしょう。実行結果は コレクションになっており、この中に取得したレコードのオブジェクトがまとめられています。

引数は今回付けていませんが、取得するフィールドを特定する場合は引数を利用できます。例えば、**get(['id', 'name'])**とすれば、**id**と**nameフィールド**だけを取り出すことができます。試しに下記のようにHelloControllerクラスのindexアクションメソッドのget()の引数にidとnameを入れてみます。

<p class="list tmp"><span>リスト1-1</span></p>
```
$items = DB::table('customer')->get(['id', 'name']);
```
    
そして、index.blade.phpのtableを修正します。

<p class="list tmp"><span>リスト1-2</span></p>
```
@section('content')
   <table>
   <tr><th>id</th><th>name</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->id}}</td>
           <td>{{$item->name}}</td>
       </tr>
   @endforeach
   </table>
@endsection
```

これで/helloにアクセスすると、図2のようにidとnameのフィールドだけのレコードを表示することができます。
![](bullder_all2.png?classes=caption "図2　idとnameのフィールドのレコードを表示")
    
省略すると、最初の図１のように全フィールドの値が取得されます。  
取得したコレクションには、各レコードの値をオブジェクトにまとめたものが保管されています。この辺りの操作は、DB:selectと大きな違いはありません。  
確認が出来たら、index.blade.phpとHelloController.phpはビルドの全フィールド表示用に戻しておいてください。

## 指定したIDのレコードを得る ##{#p3}
続いて、特定のレコードを取得する処理を考えてみましょう。CRUDの処理では、「指定したIDのレコードを得る」ということをよく行いました。これをクエリビルダで行うにはどうすればいいのか考えてみます。  
これも、まずはサンプルを動かしてみましょう。今回は、/hello/showというアクションとして用意してみます。まずは、「views」内の「hello」フォルダ内に「**show.blade.php**」 というファイルを作成します。内容は以下の通りです。

<p class="list tmp"><span>リスト2-1</span></p>
```
@extends('layouts.helloapp')

@section('title', 'Show')

@section('menubar')
   @parent
   詳細ページ
@endsection

@section('content')
   <table>
      <tr><th>id: </th><td>{{$item->id}}</td></tr>
      <tr><th>name: </th><td>{{$item->name}}</td></tr>
      <tr><th>age: </th><td>{{$item->age}}</td></tr>
      <tr><th>address: </th><td>{{$item->address}}</td></tr>
      <tr><th>login: </th><td>{{$item->login}}</td></tr>
	  <tr><th>password: </th><td>{{$item->password}}</td></tr>
   </table>
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```
ここでは、$itemという変数にレコードのオブジェクトを渡し、それを表示するようにしています。それ以外には、特に説明が必要な部分はありません。  
では、/showの処理をHelloControllerクラスに作成しましょう。ここでは、showというメソッドとして追加します。

<p class="list tmp"><span>リスト2-2</span></p>
```
public function show(Request $request)
{
   $id = $request->id;
   $item = DB::table('customer')->where('id', $id)->first();
   return view('hello.show', ['item' => $item]);
}
```

記述したら、web.phpにルート情報を追記しておきます。

<p class="list tmp"><span>リスト2-3</span></p>
```
Route::get('hello/show', 'HelloController@show');
```

これで完成です。/hello/showに、idという名前でパラメータを用意してアクセスして みて下さい。例えば、/hello/show***?id=13***という形です。これで、IDが13番のレコードの内容が表示されます。

![](bullder_show.png?classes=caption "図3　IDが13番のレコードを表示")

### show メソッドの処理
では、showメソッドの内容を見てみましょう。ここでは、以下のようにしてメソッド チェーンが組み立てられています。
```
$item = DB::table('customer')-> where('id', $id)->first();
```
見覚えのないメソッドが2つほど登場しているのわかるでしょう。これらはいずれも クエリビルダのメソッドです。以下に簡単にまとめておきましょう。


#### where 
これは、SQLのwhere句に相当するものです。このwhereは、引数にフィールド名と値を指定することで、***指定された条件に合致するレコード***に絞り込みます。
<p class="tmp"><span>書式2</span>条件に合致するレコード</p>
```
where(フィールド名 , 値 )
```
このような形です。これにより、指定したフィールドの値が第2引数の値と同じレコードを検索します。レコード検索の条件を設定する際の基本となるメソッドといえま
す。

#### first 
これは、「***最初のレコード***」だけを返すメソッドです。getの場合、検索されたレコードすべてを返しますが、firstは最初のものだけです。  
例えば指定したID番号のレコードというのは1つしかありません。このように「1つしかレコードがない」ことがわかっているような場合、getではなくfirstを使ってレコードの取得を行ったりします。  
1つしかないので、戻り値は配列やコレクションではなく、検索されたレコードのオブジェクトになります。レコードが見つからなければ、戻り値はnullになります。 

ここでは、whereとfirstを組み合わせて、指定したIDのレコードを1つだけ取り出し、$itemに渡しています。  
ここまでの「**where**」「**get**」「**first**」は、レコードの取得を行う際、もっとも重要となるメソッドです。この3つがしっかり理解できれば、基本的なレコード検索は行えるようになるでしょう。

## 演算記号を指定した検索 ##{#p4}
whereメソッドは、非常に簡単にレコードの検索が行えますが、欠点もあります。それは、「***指定した値と一致するものしか検索できない***」という点です。  
検索は、もっと細かな条件設定が必要となるものです。例えば、「**指定の数以上・以下のもの**」とか、「**指定の文字が含まれているもの**」といった具合です。whereは簡単でいいのですが、こうした「値が一致する」以外の検索はどのようにすればいいのでしょう。

実は、whereは3つの引数を持たせて呼び出すこともできるのです。以下のような形です。
<p class="tmp"><span>書式3</span></p>
```
where(フィールド名 , 演算記号 , 値 );
```
例えば、**where('id', '>', 5);** とすれば、**IDが5より大きいもの**を検索できる、というわけです。では、実際の利用例を挙げておきましょう。  
まず、先ほど作成したshow.blade.phpの@section('content)ディレクティブ部分を、複数のレコードが表示できるように修正しておきます。

<p class="list tmp"><span>リスト3-1</span>show.blade.php</p>
```
@section('content')
   @if ($items != null)
       @foreach($items as $item)
       <table width="400px">
       <tr><th width="50px">id:</th>
       <td width="50px">{{$item->id}}</td>
       <th width="50px">name:</th>
       <td>{{$item->name}}</td></tr>
       </table>
       @endforeach
   @endif
@endsection
```

続いて、HelloControllerクラスのshowメソッドを書き換えましょう。以下のように変更して下さい。

<p class="list tmp"><span>リスト3-2</span></p>
```
public function show(Request $request)
{
   $id = $request->id;
   $items = DB::table('customer')->where('id', '<=', $id)->get();
   return view('hello.show', ['items' => $items]);
}
```
修正したら、**/hello/show?id=5**とアクセスしてみてください。すると、**IDが5以下のレコード**がすべて表示されます。**/show?id=10**とすれば**10以下**をすべて表示します。
![](bullder_show2.png?classes=caption "図4　IDが5以下のレコード")

ここでは、以下のようにしてwhereメソッドを呼び出しています。

```
where('id', '<=', $id)
```
これで、idの値が、クエリ文字列として渡されたidパラメータ以下のものを検索していたのです。

### あいまい検索 ###{#p4-1}

また、指定したフィールドであいまい検索することもできます。  
nameフィールドであいまい検索をする場合は、以下のように書きます。

<p class="list tmp"><span>リスト4-1</span></p>
```
public function show(Request $request)
{
   $name = $request->name;
   $items = DB::table('customer')->where('name', 'like', '%' . $name . '%')->get();

   return view('hello.show', ['items' => $items]);
}
```
これで、「/hello/show?name=熊」とアクセスすると、下図のように「熊木 和夫」さんのレコードが表示されます。
![](bullder_like1.png)

## where と orWhere ##{#p5}
より複雑な検索として、「複数の条件を設定する」という場合もあります。この場合は、 whereと一緒に「***orWhere***」を使って設定できます。

### すべての条件に合致するものだけ検索
<p class="tmp"><span>書式4</span></p>
```
where(...)->where(....)
```
複数の条件を設定し、すべての条件に合致するものだけを検索する場合は、このよう にwhereメソッドを複数続けて記述していきます。

### 条件に1つでも合致すればすべて検索
<p class="tmp"><span>書式5</span></p>
```
where(...)->orWhere (...)
```
複数の条件のどれか1つでも合致すればすべて検索する、という場合は、最初にwhere で条件を指定した後、「orWhere」を使って条件を追加します。このorWhereの使い方は、 whereとまったく同じです。

### nameとaddress から検索する
では、実際に複数条件の検索を使ってみましょう。先ほどのHelloControllerクラスの showメソッドを修正してみます。

<p class="list tmp"><span>リスト5-1</span></p>
```
public function show(Request $request)
{
   $name = $request->name;
   $items = DB::table('customer')
	   ->where('name', 'like', '%' . $name . '%')
	   ->orWhere('address', 'like', '%' . $name . '%')
	   ->get();
   return view('hello.show', ['items' => $items]);
}
```
ついでに、show.blade.phpのテーブルもaddressを追加して、スタイルを少し修正しています。
<p class="list tmp"><span>リスト5-2</span></p>
```
@section('content')
   @if ($items != null)
       @foreach($items as $item)
		<table width="800px">
			<tr>
				<th width="50px">id:</th>
				<td width="50px">{{$item->id}}</td>
				<th width="50px">name:</th>
				<td width="120px">{{$item->name}}</td>
				<th width="100px">address:</th>
				<td>{{$item->address}}</td>
			</tr>
		</table>
       @endforeach
   @endif
@endsection
```


修正したら、/hello/show?name=○○というようにしてアクセスをしてみて下さい(○○には検索テキストを指定)。これで、nameまたはaddressフィールドのいずれかに検索テキストを含むレコードをすべて表示します。

/hello/show?name=大阪 でアクセスすると、以下の検索結果が表示されます。

![](bullder_show3.png)

ここでは、以下のように検索条件が設定されています。
```
->where('name', 'like', '%' . $name . '%') 
->or Where('address', 'like', '%' . $name '%')
```
whereでnameに like検索の条件設定をしており、その後にorWhereでaddressにもlike検索を設定しています。 like検索というのは、検索テキストを含むものを探すのに使うもので、 SQLでは、
<p class="tmp"><span>書式6</span></p>
```
フィールド like '% テキスト%'
```
こんな形で実行されます。%記号は、「そこにどんな文字があってもOK」ということを示すもので、例えば、"%abc%"ならば、abcの前後にどんなテキストがあってもOK(つまり、 テキストの中にabcが含まれていればOK)となります。

こんな具合に、where/orWhereでどんどん検索条件を追加していけば、複雑な条件も作り出すことができます。  
ここでは検索テキストを指定するのに'%'.$name.'%'という書き方をしていますが、 これはwhere/orWhereがパラメータ結合に対応していないためです。このため、このように変数と記号をつなぎ合わせて検索テキストを用意しています。

## whereRawによる条件検索 ##{#p6}
検索条件が複雑になった場合は、いくつもwhereを続けて書くよりも、検索の条件を 文字列で指定する「***whereRaw***」メソッドのほうが役立つかもしれません。これは、以下のように利用します。
<p class="tmp"><span>書式7</span></p>
```
whereRaw(条件式 , パラメータ配列 );
```
見ればわかるように、whereRawは、**パラメータ配列**に対応した条件設定のメソッドです。第1引数に検索のための式を用意し、第2引数にパラメータの配列を用意します。  
では、これも実際に試してみましょう。HelloControllerクラスのshowメソッドを以下のように書き換えて下さい。

<p class="list tmp"><span>リスト6</span></p>
```
public function show(Request $request)
{
   $min = $request->min;
   $max = $request->max;
   $items = DB::table('customer')
       ->whereRaw('id >= ? and id <= ?', [$min, $max])->get();
   return view('hello.show', ['items' => $items]);
}
```

/hello/show?min=3&max=8　とアクセスすると、ID番号が3以上8以下のレコードが表示されます。
![](bullder_show4.png)

ここでは、minとmaxという2つのパラメータをクエリ文字列で渡して検索をします。  
whereRawメソッドを以下のように呼び出しています。

```
whereRaw('id >= ? and id <= ?', [$min, $max])
```
条件式には、'id >= ? and id <= ?' が用意されています。この式の?部分に、その後にあるパラメータ配列の値がはめ込まれていきます。  
whereRawのプレースホルダは、 このように**?記号**になります。:nameというような形で変数名を埋め込んだりはできないので、注意して下さい。


## 並び順を指定する「orderBy」 ##{#p7}
レコードを検索して取得する場合、取り出されるレコードは基本的に作成した順番になっています。サンプルのcustomerではIDが順に割り振られますので、基本的にID番号順 に表示されます。  
この並び順を変更したい場合に用いられるのが「***orderBy***」メソッドです。これは、以下のように利用します。

<p class="tmp"><span>書式8</span></p>
```
orderBy(フィールド名 , 'asc または desc')
```

第1引数には、並び順の基準となるフィールド名を指定します。そして第2引数には 'asc'か'desc'を指定します。ascは昇順(数字なら小さい順、テキストならABC順・あいうえお順)、descは降順(数字なら大きい順、テキストはABC順の逆順)となります。これにより、取り出したレコードの並び方を変更できるようになります。 例として、HelloControllerのindexメソッドを修正し、並び順を変えてみましょう。

<p class="list tmp"><span>リスト7</span></p>
```
public function index(Request $request)
{
   $items = DB::table('customer')->orderBy('id', 'desc')->get();
   return view('hello.index', ['items' => $items]);
}
```

/helloにアクセスすると、レコードの一覧が、idが大きい順に表示されます。 
![](bullder_order1.png)

ここでは、以下のようにして並び順を設定しています。
```
orderBy('id', 'desc')
```

これで、idフィールドに対し降順(desc)で並べ替えるようになります。後は、ここからgetでレコードを取得するだけです。  
注意しておきたいのは、orderByの呼び出し場所です。これは、getメソッドの前に書いておかなければいけません。whereなど検索条件のメソッドを利用している場合は、それらのメソッドの後に追加するとよいでしょう。

## offset と limit ##{#p8}
レコードが大量にあった場合は、すべてを取り出すのではなく、そこから部分的にレコードを取り出して表示することが多いでしょう。このような場合に用いられるのが 「***offset***」と「***limit***」です。

### 指定した位置からレコードを取得する
<p class="tmp"><span>書式9</span></p>
```
offset( 整数 )
```
offsetは、指定した位置からレコードを取得するためのものです。例えば、offset(10) とすると、最初から10個分だけ移動し、11個目からレコードを取得します。

### 指定した数だけレコードを取得する
<p class="tmp"><span>書式10</span></p>
```
limit( 整数 )
```
指定した数だけレコードを取得します。例えば、limit(10)とすると、10個だけレコー ドを取得します。  
この2つを組み合わせることで、ずらっと並んでいるレコードから必要な部分だけを取り出せるようになります。  
実際の利用例を挙げておきましょう。今回は、/hello/showで表示される内容を修正してみます。HelloControllerクラスのshowアクションメソッドを以下のように修正して 下さい。

<p class="list tmp"><span>リスト8</span></p>
```
public function show(Request $request)
{
   $page = $request->page;
   $items = DB::table('customer')
       ->offset($page * 3)
       ->limit(3)
       ->get();
   return view('hello.show', ['items' => $items]);
}
```
/hello/show?page=0 とアクセスすると
![](bullder_offset0.png)

/hello/show?page=1 とアクセスすると
![](bullder_offset1.png)

/hello/show?page=2 とアクセスすると
![](bullder_offset2.png)

/hello/show?page=3 とアクセスすると
![](bullder_show3.png)


ここでは、パラメータとしてpageを用意すると、そのページのレコードを表示するようになっています。各ページは3レコードずつになっています。/hello/show?page=0で アクセスすると、最初の1~3番目のレコードが表示され、page=1とすると4~6番目 のレコードが.・・・というように、3つずつレコードが表示されていきます。 ここでは、以下のようにして表示するレコードを指定しています。
```
->offset($page * 3) 
->limit(3)
```
$pageは、ページ番号を表す変数です。offsetで$page * 3の位置に移動し、limitで3つだけレコードを取得することで、1ページ3レコードずつ表示されるようになります。

## insertによるレコード追加 ##{#p9}
検索以外の機能も、クエリビルダには用意されています。レコードの新規追加は、 DB::insertを使って行いました。これは、引数に用意するSQLクエリ文に新規追加の処理 を書いてあったわけで、あまり使いやすいものではありません。  
クエリビルダによる新規追加は、「***insert***」というメソッドを使います。といっても、 DB::insertとは違います。こちらはBuilderクラスに用意されているメソッドで、以下のように利用します。

<p class="tmp"><span>書式11</span></p>
```
DB::table(....)->insert(データをまとめた配列 );
```
DB::tableで指定したテーブルのビルダを取得し、そこからinsertメソッドを呼び出し ます。引数には、保存するフィールド名をキーとする連想配列を用意します。これで、 配列のデータがレコードとして保存されます。

見ればわかるように、こちらのinsertでは、SQLクエリ文はまったく出てきません。ただ、値を配列にまとめて呼び出すだけでいいのです。

### /hello/create を修正する
では、実際に試してみましょう。今回は、先に作成した/hello/addアクションを再利用します。HelloControllerのadd/createメソッドを以下のように記述しましょう。

<p class="list tmp"><span>リスト9</span></p>
```
public function add(Request $request)
{
   return view('hello.add');
}

public function create(Request $request)
{
   $param = [
		'name' => $request->name,
        'age' => $request->age,
		'address' => $request->address,
		'login' => $request->login,
		'password' => $request->password,
   ];
   DB::table('customer')->insert($param);
   return redirect('/hello');
}
```
/hello/addにアクセスし、現れたフォームのフィールドに値を記入して送信すると、それらがレコードとしてテーブルに追加されます。

![](bullder_insert1.png)

送信後、自動的に/helloにリダイレクトされるので、表示されるテーブルの内容をよく確認しておきましょう。
![](bullder_insert2.png)

  
ここでは、まず送信されたフォーム値をもとに、$param変数を用意しています。これは配列になっており、それぞれのフィールド名をキーとして値をまとめてあります。 後は、この配列$paramを引数に指定してinsertメソッドを呼び出すだけです。

##### ビルダを使ったinsertの書き方
```
DB::table('customer')->insert($param);
```
DB::tableの後にメソッドチェーンとしてinsert文を追加して呼び出します。これだけ で新規追加の処理は完了です。DB::insertの場合は、こんな具合に記述していました。

##### 先述の「DB::insertを使った書き方」
```
DB::insert('insert into customer (name, age, address, login, password) values 
	(:name, :age, :address, :login, :password)', $param);
```
ビルダを使った書き方の方がずいぶんとわかりやすく、PHPらしいやり方に変わっていることがわかるでしょう。 SQLクエリ文を書く必要がないため、「書き間違えておかしな動作をしてしまう」といっ たこともなくなります。


## updateによるレコード更新 ##{#p10}
続いて、レコードの更新処理です。これはビルダに用意されている「update」というメソッドを使います。使い方は以下のようになります。

<p class="tmp"><span>書式12</span></p>
```
DB::table(.......)->where( 更新対象の指定 )->updatel 配列 );
```

updateメソッドそのものは、insertとほとんど同じです。更新する値を連想配列にまとめ、引数に指定して呼び出すだけです。ただし、このupdateを使うには、「どのレコー ドを更新するか」が明確になっていなければいけません。  
そこで、whereを使い、更新するレコードを絞り込み、それに対してupdateを呼び出します。こうすることで、特定のレコードの内容を書き換えます。

**※whereしないでtableから直接updateを呼び出すと、すべてのレコードの内容を更新 しますので注意しましょう。**

### /hello/update を修正する
では、これも実際に試してみましょう。先に、/hello/editと/hello/updateアクション を使ってレコードを更新する処理を作りましたが、これをビルダのupdateメソッドを使う形に書き換えてみましょう。 HelloControllerクラスのedit/updateメソッドを以下のように書き換えて下さい。

<p class="list tmp"><span>リスト10</span></p>
```
public function edit(Request $request)
{
   $item = DB::table('customer')
	   ->where('id', $request->id)->first();
   return view('hello.edit', ['form' => $item]);
}

public function update(Request $request)
{
   $param = [
	   'id' => $request->id,
	   'name' => $request->name,
       'age' => $request->age,
	   'address' => $request->address,
	   'login' => $request->login,
	   'password' => $request->password,
   ];
   DB::table('customer')
	   ->where('id', $request->id)
	   ->update($param);
   return redirect('/hello');
}
```
/hello/edit?id=13 とアクセスし、下図のようにレコードを変更し、送信ボタンを押します。

![](bullder_update1.png)

レコードが書き換わります。

![](bullder_update2.png?classes=caption "図　更新前のレコード")

![](bullder_update3.png?classes=caption "図　更新後のレコード")



使い方は、先に作成したときとまったく同じです。/hello/edit?id=番号という形でアクセスをすると、そのID番号のレコードの値がフォームに表示された状態になります。 これを書き換えて送信すると、そのレコードの内容が書き換えられて更新されます。

ここでは、以下のような形でupdateを利用しています。

##### ビルダを使ったupdateの書き方
```
DB::table('customer')
	->where('id', $request->id) 
    ->update($param);
```
DB::tableでcustomerテーブルのビルダを取得し、whereで送信されたID番号のレコードを指定しています。そして、更にupdateメソッドを呼び出し、引数にフォームから送られた値を配列にまとめて指定します。これで指定のレコードが書き換えられます。

では、DB::updateを使った場合はどうなっていたか、見てみましょう。

##### 先述の「DB::updateを使った書き方」
```  
DB::update('update customer set name =:name, address = :address, 
	login = :login, password = :password where id = :id', $param);
```

かなり変わっています。なにより、updateのSQLクエリ文は少し複雑な書き方をするので、慣れないとよく間違います。ビルダのupdateを使えば、(whereの使い方さえ間違えなければ)安全にレコードの更新が行えます。

## deleteによるレコード削除 ##{#p11}
残るは、レコードの削除です。これは、ビルダの「delete」というメソッドを使って行います。

```
DB::table(...)->where( 更新対象の指定 )->delete();
```

このdeleteメソッドは、引数もなく、ただ呼び出すだけです。先ほどのupdateと同様、あらかじめwhereメソッドを使って削除するレコードを絞り込んでおきます。そして deleteを呼び出すことで、whereで検索されたレコードが削除されます。

**※whereを付けずにDB::tableから直接deleteを呼び出すと全レコードを削除してしまうので注意しましょう。**

### /hello/removeの修正
では、これも試してみましょう。先ほど作成した/hello/delと/hello/removeのアクションを書き換えて使うことにします。  
HelloControllerクラスのdelとremoveメソッドを以下のように書き換えましょう。

<p class="list tmp"><span>リスト11</span></p>
```
public function del(Request $request)
{
   $item = DB::table('people')
       ->where('id', $request->id)->first();
   return view('hello.del', ['form' => $item]);
}

public function remove(Request $request)
{
   DB::table('people')
       ->where('id', $request->id)->delete();
   return redirect('/hello');
}
```
/hello/del?id=13 とアクセスすると、ID番号13のレコードが表示されます。  
送信ボタンを押すと、このレコードが削除されます。

![](bullder_delete1.png)

![](bullder_delete2.png?classes=caption "図　削除前のレコード")

![](bullder_delete3.png?classes=caption "図　削除後のレコード")

使い方は修正前と同じです。/hello/del?id=番号というアドレスにアクセスすると、 そのID番号のレコードが表示されます。そのままボタンを押すと、そのレコードが削除 されます。 ここでは、以下のような形でdeleteメソッドを呼び出しています。
```
DB::table('customer')
	->where('id', $request->id)->delete();
```
whereでIDが$request->idのレコードを検索し、それをdeleteしています。これで、指定したレコードが削除されます。  
参考までに、先述のDB::deleteを使った場合の処理は、下記のようになっていました。
```
DB::delete('delete from customer where id = :id', $param);
```
ビルダを利用すると、SQLクエリ文がきれいに消えてしまい、単にメソッドを呼び出すだけで削除できるようになります。  
これで、クエリビルダによるCRUDの基本が使えるようになりました。検索関係はかなりいろいろなメソッドが用意されているため、ここで紹介したのはもっとも基本となる部分だけです。それでも、一般的な検索作業の大半はできるようになるはずです。













