delete from product where id=1;
