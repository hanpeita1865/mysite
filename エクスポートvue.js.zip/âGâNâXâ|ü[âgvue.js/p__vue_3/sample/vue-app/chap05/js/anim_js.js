Vue
  .createApp({
    data() {
      return {
        flag: true
      };
    },
    methods: {
      onclick() {
        this.flag = !this.flag;
      },
      //要素が表示状態になる時の処理
      onenter(el, done) {
        Velocity(el, { opacity: 1}, { duration: 2000, complete: done });//-----(3)
      },
      //要素が非表示状態になる時の処理
      onleave(el, done) {
        Velocity(el, { opacity: 0 }, { duration: 2000, complete: done });
      }
    }
  })
  .mount('#app');