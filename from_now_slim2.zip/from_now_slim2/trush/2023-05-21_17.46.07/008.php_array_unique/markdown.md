*[page-title]:配列の同じ値をまとめる（array_unique）

PHPで配列に同じ値が複数あった場合に一つにまとめたい場合があります。  
PHPの関数でarray_unique()を使用すれば、重複した値を削除することができます。  
下記にPHPのarray_unique関数を使用して、配列内の同じ値（重複値）を取り除いた時の方法をメモします。

<p class="tmp"><span>書式</span>array_unique関数</p>
```
array_unique(配列);
```

<iframe src="https://paiza.io/projects/e/v6V0mpSjlDKlf514QdWLKA?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>

### 参考サイト
 * [PHP：配列内の同じ値を一つにまとめる「array_unique」](http://raining.bear-life.com/php/%E9%85%8D%E5%88%97%E5%86%85%E3%81%AE%E5%90%8C%E3%81%98%E5%80%A4%E3%82%92%E4%B8%80%E3%81%A4%E3%81%AB%E3%81%BE%E3%81%A8%E3%82%81%E3%82%8B%E3%80%8Carray_unique%E3%80%8D)