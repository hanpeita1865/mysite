Vue.createApp({
    data() {
        return {
            myName: '匿名'
        };
    }
}).mount('#app');

Vue.createApp({
    data() {
        return {
            myNumber: 0
        };
    }
}).mount('#app1');

Vue.createApp({
    data() {
        return {
            myRange: 0
        };
    }
}).mount('#app2');

Vue.createApp({
    data() {
        return {
            myPassword: ''
        };
    }
}).mount('#app3');

Vue.createApp({
    data() {
        return {
            myDate: ''
        };
    }
}).mount('#app4');

Vue.createApp({
    data() {
        return {
            myColor: ''
        };
    }
}).mount('#app5');