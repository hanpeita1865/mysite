<?php
//現在アクセスされているパス
echo $_SERVER['REQUEST_URI'];
?>