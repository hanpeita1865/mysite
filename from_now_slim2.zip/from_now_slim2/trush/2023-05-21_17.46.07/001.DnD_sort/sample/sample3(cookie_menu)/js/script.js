const elem_box = document.getElementById('menu');
const items = document.getElementsByClassName('box-item');
const array_start = [];//デフォルトの並び順
const elem_reset = document.getElementById('reset')
let sortCookie = '';//Cookie値
let orderArray = [];//並び順の配列

Array.prototype.slice.call(items).forEach(function(value){
	array_start.push(value.getAttribute('id'));
});

cookieSortGet();//cookieの値を取得
boxSortOrder();//メニュー作成

//ボックス並び作成
function boxSortOrder() {

	//並び順で生成
	for (var i = 0; i < orderArray.length; i++) {
		elem_box.appendChild(document.getElementById(orderArray[i]));
	}

	elem_box.classList.add('side-show');

	document.querySelectorAll('.side-link li').forEach (elm => {
		elm.ondragstart = function (e) {
			e.dataTransfer.setData('text/plain', e.target.id);
		};

		elm.ondragover = function (e) {
			e.preventDefault();
			let rect = this.getBoundingClientRect();
			if ((e.clientY - rect.top) < (this.clientHeight / 2)) {
				//マウスカーソルの位置が要素の半分より上
				this.style.borderTop = '2px solid blue';
				this.style.borderBottom = '';
			} else {
				//マウスカーソルの位置が要素の半分より下
				this.style.borderTop = '';
				this.style.borderBottom = '2px solid blue';
			}
		};

		elm.ondragleave = function () {
			this.style.borderTop = '';
			this.style.borderBottom = '';
		};

		elm.ondrop = function (e) {
			e.preventDefault();
			let id = e.dataTransfer.getData('text/plain');
			let elm_drag = document.getElementById(id);
	
			let rect = this.getBoundingClientRect();
			if ((e.clientY - rect.top) < (this.clientHeight / 2)) {
				//マウスカーソルの位置が要素の半分より上
				this.parentNode.insertBefore(elm_drag, this);
			} else {
				//マウスカーソルの位置が要素の半分より下
				this.parentNode.insertBefore(elm_drag, this.nextSibling);
			}
			this.style.borderTop = '';
			this.style.borderBottom = '';

			cookieSortSet();//並べ替え確定
		};
	});
}


//cookieに値を格納
function cookieSortSet(){
	const array_items = Array.prototype.slice.call(items);
	let listItems = [];

	//ボックス並び順を配列に格納
	array_items.forEach(function(value){
		listItems.push(value.getAttribute('id'));
	});

	let cookies = 'sortKadai =' + JSON.stringify(listItems) + ';';
	//Cookieに保存
	document.cookie = cookies;	
}


//cookieの値を取得
function cookieSortGet() {

    //データを1つずつに分ける
    let cookieArray = document.cookie.split(';');

    //cookieに並び順データがある場合
    if (cookieArray.some(value => value.split('=')[0].match(/sortKadai/))) {
        orderArray = JSON.parse(cookieArray.find(value => value.split('=')[0].match(/sortKadai/)).split('=')[1]);
		boxSortOrder();
	}else{
		boxSortOrder();
	}
}

//cookieの値を削除
elem_reset.addEventListener('click', function(){
	if (window.confirm('並び順をリセットしていいですか')) {
		document.cookie = 'sortKadai=; max-age=0';
		orderArray = array_start;
		boxSortOrder();
		alert('並び順をリセットしました。')
	}
});
