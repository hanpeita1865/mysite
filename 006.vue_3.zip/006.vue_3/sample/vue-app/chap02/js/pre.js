Vue.createApp({
  data: function() {
    return {
      message: 'こんにちは、世界！'
    };
  }
}).mount('#app');