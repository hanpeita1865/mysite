<?php
	require_once $_SERVER['DOCUMENT_ROOT'].$basePath.'common/php/Parsedown.php'; //Parsedownを読み込み
	require_once $_SERVER['DOCUMENT_ROOT'].$basePath.'common/php/ParsedownExtra.php'; //Extraを読み込み
	require $_SERVER['DOCUMENT_ROOT'].$basePath.'common/user_check.php';//ユーザー閲覧権限チェック

	$md = file_get_contents("markdown.md"); //マークダウンの内容を変数に格納

	//ページタイトル取得
	preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
	$title = $ArrayTitle[1];//ページタイトル

	//$md = preg_replace('/<script(.*?)>(.*?)<\/script>/ims', '&lt;script$1&gt;$2&lt;/script&gt;', $md);//scriptタグ文字変換

	$html = md2html($md);
	//$h2Num = substr_count($html, "<h2>");
	$h2Num = preg_match('/<h2(.*)>(.*)<\/h2>/',$html);
	
	function md2html($md)
	{
		$Extra = new ParsedownExtra();
		$html = $Extra->text($md);

		return $html;
	}

	$base_path = '../';

	//スクロールトップの値
	if(!isset($_REQUEST['scroll'])){
		$_REQUEST['scroll'] = 0;
	};
?>