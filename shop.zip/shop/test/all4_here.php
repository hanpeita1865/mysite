<?php


// ヒアドキュメント全体を変数に格納


$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
foreach ($pdo->query('select * from product') as $row) {
    //$city = $row['id'];
    $city = '横浜市';
    $str = <<<EOD
    ヒアドキュメントで、<br>
    テキスト出力も $city 自由自在！！
    EOD;
    
    echo $str;
}
