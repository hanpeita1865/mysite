let gulp = require("gulp");
let watch = require('gulp-watch');
let concat = require('gulp-concat');

gulp.task("default", function() {
  return gulp.src(['src_js/file1.js','src_js/file2.js','src_js/file3.js'])
    .pipe(concat('script.js'))
    .pipe(gulp.dest('js/'));
});

/*gulp.task("watch", function() {
  return gulp.watch('src_js/*.js', ['default']);
});*/

gulp.task("watch", function() {
  return watch('src_js/*.js', function() {
      gulp.start(['default']);
  });
});