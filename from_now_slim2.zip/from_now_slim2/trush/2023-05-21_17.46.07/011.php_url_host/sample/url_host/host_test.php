<?php
//現在アクセスされているホスト名
echo $_SERVER['HTTP_HOST'];
?>