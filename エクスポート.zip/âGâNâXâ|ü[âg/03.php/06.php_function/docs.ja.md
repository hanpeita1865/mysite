---
title: 関数・メソッド
taxonomy:
    category:
        - docs
tablesorter:
    active: true
    include_widgets: true
    table_nums: '1,2'
    themes: green
    args:
        1:
            widgets:
                - zebra
                - filter
        2:
            widgets:
                - zebra
                - filter
---

<style>
    table.tablesorter th {text-align: center;}
    table.tablesorter tr td {font-size: .8rem;}
    table.tablesorter tr td:nth-child(2) {color:red; font-weight:bold; font-size: .9rem;}
</style>

|カテゴリ|関数|	概要|　参考リンク|
|--|--|--|--|
|	|file_get_contents	|ファイルの内容を全て文字列に読み込む|[php.net](https://www.php.net/manual/ja/function.file-get-contents.php) |
|	|file_put_contents|データをファイルに書き込む	|[php.net](https://www.php.net/manual/ja/function.file-put-contents.php)	|
|	|file_exists|ファイルまたはディレクトリが存在するかどうか調べる	|[php.net](https://www.php.net/manual/ja/function.file-exists.php)	|
|	|var_dump|指定した変数や式に関してその型や値を含む構造化された情報を 返します。|[php.net](https://www.php.net/manual/ja/function.var-dump.php)	|
|	|fetchall|SQLスクリプトを実行した結果を取得します。<br>【書式】{c:blue}foreach (PDOの変数->fetchAll() as 結果を代入する変数){/c}|	|
|	|execute|クエリを実行します。プリペアドステートメントでクエリを組み立てて、executeメソッドでクエリを実行するのが基本的な書き方です。	|[marronブログ](http://lovee7.blog.fc2.com/blog-entry-42.html)	|
|	|prepare|executeメソッドによって実行される SQL ステートメントを準備します。<br>【queryとprepareの違い】<br>query()の場合、ユーザからの入力を利用しない<br>prepare()の場合、ユーザからの入力を利用する|[queryとprepareの違い](https://se-tomo.com/2018/07/12/php%E3%81%AEquery%E3%81%A8prepare%E3%81%AE%E9%81%95%E3%81%84/)	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|
|	|	|	|	|

