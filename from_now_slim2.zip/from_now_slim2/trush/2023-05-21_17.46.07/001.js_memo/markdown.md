*[page-title]:JSメモ（よく利用するもの）


## HTMLコレクションやNodeListを配列に変換

<p class="tmp"><span>書式</span>Array.prototype.slice.call</p>
HTMLコレクションやNodeListは、このままではmapやforEachを使えないので、変換してやる必要があります。
```
Array.prototype.slice.call(HTMLコレクションまたは、NodeList);
```

```
Array.prototype.slice.call(HTMLコレクションやNodeList).forEach(function( value ) {
		value.処理～;
});
```

ES6からは、配列化とmapの両方をやってくれる、<span class="green bold">Array.from()</span>というメソッドがあります。まぁ親切。
<p class="tmp"><span>書式</span>Array.from</p>
```
Array.from(HTMLコレクションまたは、NodeList);
```

## data属性の値を指定して要素を取得する

参考サイト
: [【JavaScript】data属性の値を指定して要素を取得する](https://into-the-program.com/javascript-get-element-custom-data-value/)

```
//data属性をして取得
const data = document.querySelectorAll('[data-user-id]');
//値を指定して取得
const elements = document.querySelectorAll('[data-user-id="100"]');
//変数ので取得
const data = document.querySelectorAll('[data-user-id="'+userId+'"]');
```
		
## e.targetとthisの違いについて

参考サイト
: [e.targetの扱いには注意しよう](https://qiita.com/sasurai_usagi3/items/45d61fd08cdf7cff57fa)
: [【JavaScript】無名関数とアロー関数とイベントリスナーのthis](https://laboradian.com/js-anon-func-arrow-func/)

e.targetは文字通りクリックされた要素を指します。  thisは、クリックイベントを指定した要素を指します。

アロー関数野場合、thisはイベントの起こった要素を指さないので、こんなときには、「<span class="red bold">currentTarget</span>」を使います。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	「click here」のイベントは、通常の書き方です。「アロー関数 click here」は、アロー関数を使ったイベントになります。
	<a href="sample/sample1(target_this)/" target="_blank">新規タブ</a>
	<iframe width="100%" height="400" src="//jsfiddle.net/hirao/L7fs94uv/2/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


## 特定のクラスがあるかを判定

参考サイト
: [JavaScriptで特定のクラス名があるかどうかを判別して条件分岐する方法](https://www.imamura.biz/blog/27372)



## ネイティブなJavaScriptへの書き換え方まとめ

参考サイト
: [【脱jQuery！】ネイティブなJavaScript（Vanilla JS）への書き換え方まとめ](https://wemo.tech/2101)


## 型を判定する方法
型を判定するにはtypeof演算子を使用します。typeof演算子の使用方法は以下のとおりです。
<p class="tmp"><span>書式</span></p>
```
typeof(型を調べる値)
```

## 関数とメソッドの違い

参考サイト
: [【Javascript】関数とメソッドの違い](https://yayoi.tech/entry/differences_between_functions_and_methods_in_javascript)


## 要素があるか判定

参考サイト
: [【javascript】要素があるかないかを判定する方法](https://gxy-life.com/2PC/PC/PC20210527.html)

「要素 != null」 で判定

## 配列が空か判定

参考サイト
: [JavaScript の配列が空かどうか .length でチェックする方法](https://www.freecodecamp.org/japanese/news/check-if-javascript-array-is-empty-or-not-with-length/#:~:text=%E9%85%8D%E5%88%97%E3%81%8C%E7%A9%BA%E3%81%8B%E3%81%A9%E3%81%86%E3%81%8B%E3%82%92%E3%83%81%E3%82%A7%E3%83%83%E3%82%AF%E3%81%99%E3%82%8B%E3%81%AB%E3%81%AF,%E3%81%AE%E6%95%B0%E3%81%AF%200%20%E3%81%A7%E3%81%99%E3%80%82)

```
const arr = []
arr.length //0は空
```

## タグ名の判定

要素のタグ名
```
e.target.tagName
```

要素のタグ名を判定 下記はaタグか判定
```
e.target.tagName=='A'
```

## 位置取得

参考サイト
: https://developer.mozilla.org/ja/docs/Web/API/MouseEvent/clientY
: https://developer.mozilla.org/ja/docs/Web/API/Element/getBoundingClientRect

MouseEvent.clientY ～ clientY は MouseEvent の読み取り専用のプロパティで、このイベントが発生した時点のアプリケーションのビューポートにおける垂直座標を定義します（ページにおける座標ではありません）。

getBoundingClientRect() ～ 要素の寸法と、そのビューポートに対する相対位置に関する情報を返します。

![](upload/ビューポート位置.png "図　要素の寸法と相対位置")

## Event.currentTargetとEvent.targetの違いについて

参考サイト
: [Event.currentTargetとEvent.targetの違いについて](https://www.javadrive.jp/javascript/event/index9.html)

## append()

Element.append() メソッドは、一連の Node または DOMString オブジェクトを Element のの最後の子の後に挿入します。 DOMString オブジェクトは等価な Text ノードとして挿入されます。

Node.appendChild() との違いは次の通りです。

* Element.append() は DOMString も追加することができますが、Node.appendChild() はNode オブジェクトのみを受け付けます。
* Element.append() には返値がありませんが、Node.appendChild() は追加された Node オブジェクトを返します。
* Element.append() は<span class="red bold">複数のノードや文字列を追加</span>することができますが、Node.appendChild() はノードを 1 つだけしか追加することができせん。

<p class="tmp">要素の追加</p>
```
let div = document.createElement("div")
let p = document.createElement("p")
div.append(p)

console.log(div.childNodes) // NodeList [ <p> ]
Copy to Clipboard
```

<p class="tmp">テキストの追加</p>
```
let div = document.createElement("div")
div.append("Some text")

console.log(div.textContent) // "Some text"
Copy to Clipboard
```

<p class="tmp">要素とテキストの追加</p>
```
let div = document.createElement("div")
let p = document.createElement("p")
div.append("Some text", p)

console.log(div.childNodes) // NodeList [ #text "Some text", <p> ]
```

## トランジションの終了イベント

[Document: transitionend イベント](https://developer.mozilla.org/ja/docs/Web/API/Element/transitionend_event)

<p class="tmp"><span>書式</span></p>
```
//transitionendの場合
element.addEventLisner('transitionend', () => {
	//アニメーション完了後に実行する内容を記述
});
```

例）  
このコードはリスナーに transitionend イベントを追加します。
```
document.addEventListener('transitionend', () => {
  console.log('Transition ended');
});
```

同様に、 ontransitionend プロパティを addEventListener() の代わりに使用した例です。
```
document.ontransitionend = () => {
  console.log('Transition ended');
};
```

## アニメーションの終了イベント

参考サイト
: [【JavaScript】animationendとtransitionendでCSSアニメーションの完了時にイベント処理を行う](https://logical-studio.com/develop/frontend/20211015-animationend-transitionend/)

<p class="tmp"><span>書式</span></p>
```
element.addEventLisner('animationend', () => {
	//アニメーション完了後に実行する内容を記述
});
```

[新規タブ](http://localhost:7001/test/animated/pen-export-zYzxbjz/)

左側（item1）のアニメーションが完了したら、右側（item2）にactiveクラスが付いてアニメーションが実行されます。
<iframe height="300" style="width: 100%;" scrolling="no" title="Untitled" src="https://codepen.io/ls_pr/embed/zYzxbjz?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/ls_pr/pen/zYzxbjz">
  Untitled</a> by LOGICAL STUDIO PR部 (<a href="https://codepen.io/ls_pr">@ls_pr</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>


## 要素の順番を取得

参考サイト
: [【2019年版】 JavaScriptで何番目の要素か取得する方法](https://qiita.com/nishihara_zari/items/9471389f995448e9526e)

findeIndex()は配列にしか適用できないので、const lists = Array.from(document.querySelectorAll("li"));で配列様オブジェクトを配列に変換しています。liにaddEventListenerでクリックイベントを付与し、クリックした要素とli要素の配列（lists）の要素が合致したものをfindIndex()を使ってインデックス番号を返しています。

<iframe height="300" style="width: 100%;" scrolling="no" title="何番目？" src="https://codepen.io/Nishihara/embed/VwZJxJv?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/Nishihara/pen/VwZJxJv">
  何番目？</a> by Nishihara (<a href="https://codepen.io/Nishihara">@Nishihara</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

## javascript submitを無効にする

参考サイト
: [javascript submitを無効にする](https://mebee.info/2022/03/19/post-62121/)

### submitを無効
「submit」を無効にするには、「onsubmit」の戻り値を「false」にします。

<p class="tmp"><span>書式</span></p>
```
要素.onsubmit = function(){ return false }
```
実際に、無効にしてみます。

```
<form action="index.php" id="frm" method="post">
  <input type="text" placeholder="name" name="name" />
  <input type="submit" value="送信" />
</form>

<script>
document.getElementById("frm").onsubmit = function(){ return false }
</script>
```
実行結果を見ると、「submit」ボタンをクリックしても、ENTERキーを押しても「submit」されないことが確認できます。


## importについて

参考サイト
: [【JavaScript入門】importで外部ファイルを読み込む方法](https://www.sejuku.net/blog/52998)

## data属性の取得

参考サイト
: [【JavaScript】data属性の取得・設定・更新【dataset】](https://into-the-program.com/dataset/)
<p class="tmp"><span>書式</span>data属性の値取得</p>

```
data-〇〇

element.dataset.〇〇
```


## ラジオボタンの値をJavaScriptを使って取得・設定する

参考サイト
: <https://www.javadrive.jp/javascript/form/index4.html>

## 追加した要素にイベント設定

参考サイト
: [【JavaScript】動的に挿入した要素に対応したイベント登録方法](https://lifehackdev.com/ZakkiBlog/articles/detail/web34)

<p class="lang">js</p>
```
//「▼」アイコンクリックでサブメニューを開閉
document.addEventListener('click', function(e) {
	if(e.target && e.target.className=='icon-slide'){
		e.target.closest('.box-item').classList.toggle('s-close');
	}
});
```

## 子孫要素を残して自身の要素のみを削除

参考サイト
: [子孫要素を残して自身の要素のみを削除](https://shanabrian.com/web/javascript/element-unwrap.php)

引数 elementに削除したい要素を設定
```
var unWrap = function(element) {
	if (!element) return;

	var childElems = element.children;

	if (childElems.length > 0) {
		element.parentNode.insertBefore(childElems, element.nextElementSibling);
	}

	return element.parentNode.removeChild(element);
};
```

## JavaScriptのchildNodesやchildrenにforEachを適用するときはArray.fromを使う

参考サイト
: [JavaScriptのchildNodesにforEachを適用するときはArray.fromを使う](https://www.irohabook.com/js-childnodes)

```
const main = document.getElementById('main');
Array.from(main.childNodes).forEach(function (a) {
    a.remove();
})
```


## 桁数を揃える（01, 02, …や001, 002, …）

参考
: [ゼロパディング(zero padding)とは](https://zenn.dev/cigar/articles/js-zero-padding)

ゼロパディング(zero padding)とは、書式の桁数に満たない数値の場合に,足りない桁数だけ0を追加して桁数を合わせることです。

<p class="tmp"><span>書式</span></p>
```
String.prototype.padStart()
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe src="https://paiza.io/projects/e/t8eObWecal65mDbrQMMtFA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

## iframeをリロード

参考サイト
: [【JavaScript入門】reloadでページを更新する(一部だけ更新/禁止)](https://www.sejuku.net/blog/25316)

<div class="exp" markdown="1">
<p class="tmp"><span>例</span></p>
5秒ごとにiframeを再読み込みしています。  
[http://localhost:7001/test/iframe/reload/](http://localhost:7001/test/iframe/reload/)
</div>

ただし上記は、同一ドメインだけ可能です。


## 文字列とJSONを相互変換

オブジェクト→文字列
JSON.stringifyでオブジェクトを文字列に変換できます。
```
var str = JSON.stringify(obj);
```

文字列→オブジェクト
JSON.parseで文字列をオブジェクトに変換できます。
```
var obj = JSON.parse(str);
```


<iframe src="https://paiza.io/projects/e/7AWachNDlUzmwTZhArej8g?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## ページのリロード

参考サイト
: [javascript location.reload() を一度だけ実行する](https://mebee.info/2020/09/03/post-18017/)
: [【JavaScript入門】reloadでページを更新する(一部だけ更新/禁止)](https://www.sejuku.net/blog/25316#:~:text=%E3%83%9A%E3%83%BC%E3%82%B8%E3%82%92%E5%86%8D%E8%AA%AD%E3%81%BF%E8%BE%BC%E3%81%BF%E3%81%97,%E3%83%9A%E3%83%BC%E3%82%B8%E3%81%8C%E6%9B%B4%E6%96%B0%E3%81%95%E3%82%8C%E3%81%BE%E3%81%99%E3%80%82)

## ページ遷移

参考サイト
: [【JavaScript】指定したURLにページ遷移（移動）する方法・新規タブで開く方法](https://www.motokis-brain.com/article/43#:~:text=%E6%96%87%E7%8C%AE%E3%83%BB%E3%81%8A%E3%81%99%E3%81%99%E3%82%81%E6%96%87%E7%8C%AE-,%E6%8C%87%E5%AE%9A%E3%81%97%E3%81%9FURL%E3%81%AB%E3%83%9A%E3%83%BC%E3%82%B8%E9%81%B7%E7%A7%BB%E3%81%99%E3%82%8B%E6%96%B9%E6%B3%95,%E5%90%8C%E3%81%98%E5%8B%95%E4%BD%9C%E3%82%92%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)

## 配列の要素を後ろから取得

参考サイト
: [JavaScript | 配列から最後の値を取得する方法](https://1-notes.com/javascript-get-the-last-value-from-the-array/)

### array.slice()を使って配列から最後の値や最後から何番目の値を取得する
array.slice()メゾッドを使って最後の値を取得するサンプルコードです。  
この方法の場合も、配列そのものに変更を加えず、最後の値を取得する事が可能です。

```
const fruits = ['apple', 'pine', 'banana'];

let last_data = fruits.slice(-1)[0];
console.log(last_data);// banana

let last2_data = fruits.slice(-2)[0];
console.log(last2_data);//pine
```


### array.pop()で配列から最後の値を取得する
JavaScriptで配列から最後の値を取得するにはpop()メゾッドが利用できます。  
pop()メゾッドは、配列から最後の値を切り取り、取得した値を返り値として返します。  
返り値とは別に配列そのものを変更をしますので注意が必要です。
```
const fruits = ['apple', 'pine', 'banana'];

let last_data = fruits.pop();

console.log(fruits );
// ["apple", "pine"]

console.log(last_data);
// banana
```
配列が空の場合は「undefined」を返します。

### array.lengthで配列から最後の値を取得する
lengthプロパティを使って最後の値を取得する事が可能です。  
lengthプロパティで配列の長さを取得、キー名にして最後の値を取得します。  
この方法では、配列そのものに変更を加えません。
```
const fruits = ['apple', 'pine', 'banana'];

let last_data = fruits[fruits.length - 1];

console.log(fruits );
// ["apple", "pine", "banana"]

console.log(last_data);
// banana
```

## オブジェクトのキーに存在するか判定

参考サイト
: [JavaScriptオブジェクトにキーが存在するかどうかを確認します](https://www.techiedelight.com/ja/determine-key-exists-javascript-object/)
: [JavaScript でオブジェクトにキーが存在するかどうかをチェックする](https://www.delftstack.com/ja/howto/javascript/check-if-key-exists-in-javascript/)

## GETパラメータを取得

参考サイト
: [URLに含まれるGETパラメータを取得する](https://gray-code.com/javascript/get-parameter-of-url/)

## 半角英数字記号を正規表現で指定

### 正規表現のパターン一覧

参考サイト
: [【正規表現】記号のみや半角英数記号のみ（初心者向け解説）](https://tabibitojin.com/regular-expression-symbols-alphanumeric/)

<p class="tmp list"><span>リスト</span>半角英数字（空白なし）</p>
```
^[!-~]+$
```