---
title: '06. 繰り返し for文、while文'
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">for文</h2>

for文は、決められた回数だけ処理を繰り返す場合に使用します。

<p class="tmp"><span>書式1</span></p>
```
for ( var i = 初期値 ; 繰り返し条件 ; i++ ){ 処理 }
	条件を満たしている間、処理を繰り返します。
```

### for文の例

<iframe width="100%" height="200" src="//jsfiddle.net/sbh0uno7/7/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

for文のカッコ内は半角セミコロンで区切られた3つの区分になっています。
* 最初の区分は変数「i」を宣言して、初期値「1」を代入しています。繰り返し文では「i」を用いるのが一般的です。
* 2つ目の区分は繰り返し条件を指定します。「i」が「10」以下の間（つまり10回）処理を繰り返しています。
* 3つ目の区分は、iの値の増減を記述します。通常は「i++」とします。for文の中カッコ内の処理を1回繰り返すごとに、「i」の値が1つ大きくなっていきます。

---

<h2 class="h-type2">continueとbreak</h2>

繰り返し処理から抜ける時は「break」、繰り返し処理の先頭に戻る時は「continue」を使用します。

<p class="tmp"><span>書式2</span></p>
```
break
	以下の処理をスルーして、繰り返し文から抜け出します。
continue
	以下の処理をスルーして、繰り返し文の先頭に戻ります。
```

### continueとbreakの例
<!--
<iframe width="100%" height="300" src="//jsfiddle.net/sbh0uno7/20/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>-->

<iframe width="100%" height="350" src="//jsfiddle.net/hirao/n49ou6hk/3/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


上のスクリプトでは1から100まで順番に書き出そうとしています。  
iの数値が3の倍数の時、continueで以下の処理をスルーして次の繰り返しに入っています。  
また、iの数値が20に達した時点で、breakでfor文から抜け出しているので、20以降は書き出されていないことがわかります。

---

<h2 class="h-type2">while文</h2>

繰り返し回数が分からない場合は、while文を使います。  
while文はある一定の条件を指定し、その条件を満たしている間繰り返します。

<p class="tmp"><span>書式3</span></p>
```
while ( 繰り返しの条件 ) { 処理 }
	条件を満たしている間、中括弧内の処理を繰り返します。
```

繰り返しの条件の部分には、ある変数と数値の比較などを指定します。

```
while ( num < 100 ) { 処理 } //numが100未満の間繰り返す
```

### while文の例

while文を使って、「1+2+3+…で幾つまで足すと合計が5桁になるか」と言う問題を解いてみます。

<iframe width="100%" height="250" src="//jsfiddle.net/c1uo9wdz/6/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

* 変数numには「連番」を、変数gokeiには「連番の合計」を入れていきます。  
numの初期値を0にしていますが、while文の最初でnum++としているので1から足し算することになります。
* 繰り返し条件は「gokei < 10000」で、5桁未満の場合は繰り返すとしています。
* while文の中で、最初にnum++として変数numの値を＋1にしています。次に変数gokeiと変数numを加えた合計を、変数gokeiに上書きしています。
* 最後に、document.write()を使って5桁に達した段階の数（変数numの値）を表示しています。