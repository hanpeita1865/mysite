import { SubmenuPlugin } from '../SubmenuPlugin';

declare const horizontalRule: SubmenuPlugin;

export default horizontalRule;