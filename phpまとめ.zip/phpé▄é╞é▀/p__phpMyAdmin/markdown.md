*[page-title]:phpMyAdmin

参考サイト
: [phpMyAdminのログイン/パスワードに関する設定](https://www.javadrive.jp/xampp/mysql/index3.html)
: [phpMyAdmin の設定で久しぶりにハマる!](https://qiita.com/mighty-n/items/8ec2bd5c140eee83d9b0)
: [phpMyAdminを使ってデータベースやテーブルを作成する](https://www.javadrive.jp/xampp/mysql/index5.html)

## phpMyAdminのパスワード設定ができない。
config.inc.phpの19行目の「config」を「cookie」に変更。パスワードを設定して、phpMyAdminのページにアクセスして、パスワードを入力してログインしてみると、エラーの表示がでてしまう。
<p class="tmp list"><span>リスト</span>config.inc.php</p>
```
/* Authentication type and info */
$cfg['Servers'][$i]['auth_type'] = 'cookie';
$cfg['Servers'][$i]['user'] = 'root';
$cfg['Servers'][$i]['password'] = 'ryouma';
$cfg['Servers'][$i]['extension'] = 'mysqli';
$cfg['Servers'][$i]['AllowNoPassword'] = true;
$cfg['Lang'] = '';
```

![](upload/phpMyAdminログイン画面.png '図　phpMyAdminログイン画面')

![](upload/phpMyAdminログイン画面接続不可.png "図　接続エラー画面")
