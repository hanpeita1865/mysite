*[page-title]:デベロッパーツール

## デベロッパーツールで下記のスタイルを右クリックしてコピーした場合
```
.green-box ul li {
    list-style: none;
    position: relative;
    padding-left: 1.5rem;
    margin-bottom: .6rem;
    line-height: 1.7;
}
```

![](upload/スタイルポップアップ.jpg)

<p class="tmp"><span>機能</span>Copy declaration</p>
```
padding-left: 1.5rem;
```

<p class="tmp"><span>機能</span>Copy property</p>
```
position
```

<p class="tmp"><span>機能</span>Copy value</p>
```
.6rem
```

<p class="tmp"><span>機能</span>Copy rule</p>
```
.green-box ul li {
    list-style: none;
    position: relative;
    padding-left: 1.5rem;
    margin-bottom: .6rem;
    line-height: 1.7;
}
```

<p class="tmp"><span>機能</span>Copy all declarations</p>
```
list-style: none;
position: relative;
padding-left: 1.5rem;
margin-bottom: .6rem;
line-height: 1.7;
```

## grid layoutを表示

参考サイト
: [CSS Grid（display:grid）の使い方](https://www.webdesignleaves.com/pr/css/css_display_grid.html)

インスペクターで display: grid を指定した要素にマウスオーバーするとグリッドレイアウトがオーバーレイ表示されます。

![](upload/デベロッパーGrid_overlays1.png)

![](upload/デベロッパーGrid_overlays2.png)


## DOMツリーの操作

ノードを選択した状態で、右矢印キーを押すと展開され、左矢印キーを押すと折りたたまれます。






