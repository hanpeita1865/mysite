*[page-title]:Chap2-4 つぶやきを削除する処理を作成する（example-app8）

<span class="bold green">Chap2-4 完成品</span>
* \\wsl.localhost\Ubuntu-24.04\root\example-app8
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>　データベース名は「example_app5」にしてます。

## コントローラの作成

Artisanコマンドを利用してコントローラを作成します。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:controller Tweet/DeleteController --invokable
```

![](upload/DeleteController作成コマンド.png)

![](upload/DeleteControllerファイル作成.png)

routes/web.phpにエンドポイントを追加します。

<p class="tmp list"><span>リスト</span>routes/web.php</p>
```
Route::delete('/tweet/delete/{tweetId}', \App\Http\Controllers\Tweet\DeleteController::class)->name('tweet.delete');
```


## 削除処理の実装

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/DeleteController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tweet;//追加

class DeleteController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
			//追加
        $tweetId = (int) $request->route('tweetId');
        $tweet = Tweet::where('id', $tweetId)->firstOrFail();
        $tweet->delete();
        return redirect()
            ->route('tweet.index')
            ->with('feedback.success', "つぶやきを削除しました");
    }
}
```

削除の場合はEloquentモデルを取得してdeleteメソッドを実行することで対象のモデルを削除、つまりデータベースからデータを削除する処理になります。  
実装方法は他にもあり、 直接主キーを指定して削除を実行することも可能です。


```
Tweet::destroy($tweetId);
```


<p class="tmp list"><span>リスト</span>resources/views/tweet/index.blade.php</p>
```
･･･省略･･･

<p>投稿フォーム</p>
@if (session('feedback.success'))
    <p style="color: green">{{ session('feedback.success') }}</p>
@endif

･･･省略･･･

@foreach($tweets as $tweet)
<details>
    <summary>{{ $tweet->content }}</summary>
    <div>
        <a href="{{ route('tweet.update.index', ['tweetId' => $tweet->id]) }}">編集</a>
        <form action="{{ route('tweet.delete', ['tweetId' => $tweet->id]) }}" method="post">
            @method('DELETE')
            @csrf
            <button type="submit">削除</button>
        </form>
    </div>
</details>
@endforeach

･･･省略･･･
```

<http://localhost/tweet>　にアクセスすると、つぶやきを詳細を開いたら削除ボタンが表示されています。
それをクリックすると、つぶやきデータが削除されます。

![](upload/削除画面.png){.photo-border}

以上で表示・追加 編集 削除の動作が作成できました。   
この一連の処理を<span class="green bold">CRUD (Create, Read, Update, Delete)</span> と呼びます。

この一連の処理が作れることで、 基本的なWebアプリケーションは作成できます。  
LaravelではArtisanコマンドによりこの<span class="green bold">CRUD処理</span>の作成を強力にサポートしてくれます。

