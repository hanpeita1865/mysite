---
title: '03. File API'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {
        margin-top: 0.5rem;
    }
    #body img {margin-top: 0;}
    section {margin-bottom: 4rem;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    dl dt {
        font-weight: bold;   
    }
    .w-400 {
        width: 400px;
    }
    h4 {margin-top: 3rem;}
    .hljs-comment,
    .comment {
        font-style: italic;
        color: green;
        font-size: 1rem;
        font-weight: normal;        
    }
</style>

<h2 class="h-type2">File APIとは</h2>

File APIでできることを簡潔に言うと、ローカルマシンに存在するファイルをJavaScriptから操作することです。例えば、次のような実装が可能です。

 
* ローカルにある画像をアップロードする前にプレビューを表示する
* ローカルにある画像をブラウザで加工してダウンロードする
* テキストファイルをブラウザで解析する
* データをJSONファイルとしてエクスポートして、インポートする
* 大きなファイルを分割してサーバーに送信する


<h2 class="h-type2">FileListとFile</h2>
    
単一のファイルを扱うFile、Fileをオブジェクトとして持つFileListがあります。

input[type="file"]に渡したファイル（FileList）をfilesプロパティで参照できます。またinput[type="file"]要素にはmultiple属性を付けることで、複数のファイルを選択できるようにできます。

※FileListは配列ではなくオブジェクトですので、注意してください。
    
    
<div class="box-example">
    <h3 class="h-example">例1</h3>
	選択したファイルのプロパティをコンソールに表示
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/he61f4m5/1/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>





<h3 class="h-type3">Fileオブジェクトのプロパティ</h3>

Fileオブジェクトは選択したファイルの情報を内包しています。

| プロパティ | 解説 | 
| -------- | -------- | 
| lastModifiedDate     | ファイルの最終更新日（Dateオブジェクト）     | 
| name     | ファイル名    | 
| size     | ファイルのサイズ（byte）    | 
| type     | ファイルのMIMEタイプ   | 


Fileオブジェクトにはtypeプロパティや、sizeプロパティがありますので、MIMEタイプやファイル容量をフロント側で制限することも可能です。



<div class="box-example">
    <h3 class="h-example">例2</h3>
	10KB以下のJPEG画像ファイルしか選択できないサンプル
</div>

<script async src="//jsfiddle.net/bgnxetc8/1/embed/js,html,result/"></script>


<h2 class="h-type2">FileReader API</h2>

FileReaderでは、Fileオブジェクトのファイルを実際に読み込みます。プレビューとして表示するというような動作はFileReaderを利用して行います。

まずはコンストラクタからインスタンスを作ります。

	var reader = new FileReader();

<h3 class="h-type3">FileReaderの読み込みメソッド</h3>

そしてFileReaderには非同期な3つの読み込みメソッドが定義されていますので、いずれかを使ってファイルを読み込みます。

| メソッド | 引数 | 解説 |
| -------- | -------- |: -------- |
| readAsArrayBuffer     | Blob or File      | ファイルをArrayBufferとして読み込む     |
| readAsText     | Blob or File    | ファイルをテキストとして読み込む   |
| readAsDataURL     | Blob or File      | ファイルをDataURLとして読み込む     |
| readAsBinaryString    | Blob or File    | ファイルをバイナリ形式で読み込む   |


ファイルをDataURLとして読み込む場合は、次のようなコードになります。

	reader.readAsDataURL(file);


<h3 class="h-type3">FileReaderのその他のメソッドとプロパティ</h3>

読み込みメソッド以外には、次のようなメソッドがあります。

| メソッド | 　　解説 |
| -------- |: -------- |
| abort     | 読み込みを破棄する      |


また、次のようなプロパティがあります。


| プロパティ | 　　解説 | 
| -------- |: -------- |
| state     | 読み込みステータス      |
| result     | 読み込み結果    |

resultはreadAs~を実行した後、次に解説するonloadイベントのタイミングで取得できるようになります。


<h3 class="h-type3">FileReaderのイベント</h3>

readAs~でファイルの読み込みを実行または、読み込みをabortすると、FileReaderのイベントが発行されます。

| イベント | 　　解説 |
| -------- |: -------- |
| onloadstart     | 読み込みを開始した      |
| onprogress     | 読み込み中    |
| onabort     | 読み込みを破棄した      |
| onerror     | エラーが発生した      |
| onload     | 読み込みが成功して完了した    |
| onloadend     | 読み込みが完了した（エラーを含む）      |




<div class="box-example">
    <h3 class="h-example">例3</h3>
	選択した画像を表示（何回でも選択切り替え可）
</div>

<script async src="//jsfiddle.net/yk4zspdc/embed/result,html,js/"></script>





<h2 class="h-type2">txtファイルやmdファイルなどを読み込む</h2>

<div class="box-example">
    <h3 class="h-example">例4</h3>
	txtファイル等を読み込み、textareaに表示
</div>
<script async src="//jsfiddle.net/rqgeL14s/1/embed/result,js,html/"></script>


## 参考サイト

* [File APIとFileReader APIの利用](https://www.codegrid.net/articles/fileapi-1/)
* [FileList](https://developer.mozilla.org/ja/docs/Web/API/FileList)
