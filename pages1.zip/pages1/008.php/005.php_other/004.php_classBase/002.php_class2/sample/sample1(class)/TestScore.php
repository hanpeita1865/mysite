<?php
class TestScore
{
	public $name = "";
	public $math = 0;
	public $english = 0;
	public $japanese = 0;
}

