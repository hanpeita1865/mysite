<?php
// ファイルの保存先
$uploadfile = 'files/memo.txt';
// アップロードされたファイルに、パスとファイル名を設定して保存
move_uploaded_file($_FILES['upload']['tmp_name'], $uploadfile);
// 完了メッセージを表示
echo 'アップロード完了！';