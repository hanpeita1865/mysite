*[page-title]:$thisについて

参考サイト
: [【初心者向け】PHPの擬似変数$thisの使い方](https://webukatu.com/wordpress/blog/39165/)
: [【PHP入門】変数の使い方 | 基本・可変・スコープ・疑似変数this](https://www.sejuku.net/blog/23897)
: [【徹底解説】PHPの$thisはこう使う！](https://webukatu.com/wordpress/blog/27325/#privatethis)


## 疑似変数this
クラス内でメンバ変数が定義されている場合、疑似変数$thisを使用することで、クラスの変数にアクセスすることができます。  
例えばクラスのメンバ変数を定義して、メンバ変数をそのクラスのメソッド内で参照したい場合、$変数のみの指定では参照することができません。  
そのため、クラス内のメンバ変数にアクセスするためには疑似変数$thisを使用します。  
thisはクラス内に定義されているメンバを、ひとつにまとめたオブジェクトのようなものです。  
疑似変数$thisは以下のように使用します。


<p class="tmp"><span>書式</span>疑似変数の使い方</p>
```
class クラス名{
  public $変数名 = 値;
  public function メソッド名(){
    echo this->$変数名;
  }
}
```
上記のようにメソッド内でクラス内のメンバ変数にアクセスするために、this->$変数名とすれば値を参照することができます。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe src="https://paiza.io/projects/e/b4mgvDqj5sS2ENHxJyv82g?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe src="https://paiza.io/projects/e/GW47_-YiS6bdWP81LSFwRA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe src="https://paiza.io/projects/e/mG5jrItBBqyVS8Z77rqbbg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>