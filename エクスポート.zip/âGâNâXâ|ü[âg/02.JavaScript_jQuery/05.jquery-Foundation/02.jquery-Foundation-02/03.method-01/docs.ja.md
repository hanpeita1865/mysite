---
title: '03. 要素や文字列の取得や書き替えや挿入<br>（html、before、append）'
taxonomy:
    category:
        - docs
visible: true
---

要素内のHTMLの取得や変更には，「html()」というjQueryメソッドを使います．  
また要素内のテキストの取得や変更には，「text()」というjQueryメソッドを使います．

<h2 class="h-type2">要素内のHTML・テキストの取得</h2>

<div class="box-example">
    <h3 class="h-example">例１</h3>
    要素内のHTML・テキストを取得する．
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/z5y6v2fm/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずはHTMLを見てください．  
idが"demo"というboxに太字（Bold）で「デモテスト」というテキストが表示されるようになっています．

次はJavaScriptを見てください．   
HTMLを取得するには，「対象要素.html()」と記述します．  
テキストを取得するには，「対象要素.text()」と記述します．

Resultを見て、結果を確認します．  
Consoleの1行目はHTMLを取得した場合です．対象要素内のタグを含んだHTMLが表示されています．  
2行目はテキストを取得した場合です．対象要素内のテキストが表示されています．

---

<h2 class="h-type2">要素内のHTML・テキストの変更</h2>

<div class="box-example">
    <h3 class="h-example">例２</h3>
    要素内のHTML・テキストを変更する．
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/58tbek2j/11/embedded/html,result,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずはHTMLを見てください．  
テスト１とテスト２という文字列が表示されるようになっています．  

次はResultを見てください。  
結果では，太字（Bold）で「デモテスト」と「デモテスト テキスト」と表示されます．  
これはJavaScriptのコードによって変更されたためです．

では、JavaScriptを見てください．   
HTMLを変更するには，「対象要素.html('変更したい内容')」と記述します．  
テキストを変更するには，「対象要素.text('変更したい内容')」と記述します．

---

<h2 class="h-type2">要素の前後にHTML・テキストを挿入</h2>

<div class="box-example">
    <h3 class="h-example">例３</h3>
    要素の前、または後にHTML・テキストを挿入する．
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/ookiki/c24mt5dL/26/embedded/html,result,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずはHTMLを見てください．  
要素の挿入を行うボタンが4つと，idがtargetというDiv要素があります．  
このDiv要素に対して，挿入を行います．

次はResultを見てください．  
結果では，各々のボタンをクリックすることでidがtargetというDiv要素を軸にしてP要素が挿入されます．

では、JavaScriptを見てください．   
要素の内側に挿入する場合は，「対象要素.prepend('挿入したい内容')」・「対象要素.append('挿入したい内容')」を使います．  
要素の外側に挿入する場合は，「対象要素.before('挿入したい内容')」・「対象要素.after('挿入したい内容')」を使います．
