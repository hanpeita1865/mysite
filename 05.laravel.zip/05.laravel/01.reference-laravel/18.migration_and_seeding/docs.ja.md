---
title: '18. マイグレーションとシーディング'
media_order: 'mygration1.png,mygration2.png,mygration3.png,php_artisan.png,php_artisan_customer.png,mygration_table.png,mygration_table2.png,mygration_table3.png,seeder1.png,artisan_seed.png,customer_seed.png,customer_seeder_hello.png,php_artisan_customers.png,shop_db.png,mygration_customers.png,mygration_table2-1.png,customer_seed1.png'
taxonomy:
    category:
        - docs
---

* [マイグレーションとは?](#p1)
* [マイグレーションファイルの生成](#p2)
* [マイグレーション処理について](#p3)
* [テーブル生成の処理](#p4)
* [テーブルの削除処理](#p5)
* [シーディングについて](#p6)
* [シーダーファイルの作成](#p7)
* [シーディング処理について](#p8)
* [シーダーファイルの登録](#p9)
* [シーディングを実行する](#p10)

データベースの内容を自動生成するために用意されているのが「***マイグレーション***」と 「***シーディング***」です。これらの使い方を覚え、データベースを効率良く管理しましょう。

## マイグレーションとは? ##{#p1}
データベースを扱うとき、もっとも注意しなければならないのは「データベースの構造」でしょう。例えばデータベースを移行したり、環境を移行したりする場合、データベー スをまた一から構築しなければいけないことになります。このとき、すべてのデータベー スをまったく同じ構造で作らなければ、データベース関係は正しく動作しなくなります。

現在、使っているデータベースの構造を確認し、それとまったく同じものを再現するための仕組みがあれば、データベースの管理はずいぶんと楽になります。そのために提供されているのが「***マイグレーション***」と呼ばれる機能です。  
マイグレーションは、データベースのバージョン管理機能です。データベースのテーブルを作成したり削除したりする機能を持っており、PHPのスクリプトを使ってテーブ ルの作成処理などを用意しておけます。

このマイグレーションの機能を使って、使用するテーブル類の作成処理を用意しておけば、環境が変わった場合もコマンド一発でデータベースのテーブル類を生成することができます。また、途中でテーブルの構造などを変更した場合も、古いテーブルをすべ て削除して最新のテーブルに更新するような作業が簡単に行えます。

### マイグレーションの手順
このマイグレーションを利用するには、いくつかの作業を順に行っていきます。以下に手順を整理しておきましょう。

① 専用のスクリプトファイルの作成
: まず最初に、マイグレーションを記録するためのスクリプトファイルを作成します。 これはコマンドを使って生成することができます。

② スクリプトの記述、
: 作成されたスクリプトファイルに、データベース管理の処理を記述します。これは、 テーブルの生成や削除などの処理をPHPで書くことになります。ここまでが準備の段階
です。

③ マイグレーションの実行
: マイグレーションを行う場合は、コマンドで実行します。コマンドにより、用意され たマイグレーション用のスクリプトファイルを実行してテーブルの生成や削除などが行えます。

マイグレーション機能を使うためには、まず②の下準備となる作業を行っておかなければいけません。それらが完了して、ようやく③のマイグレーションの実行が可能になります。

## マイグレーションファイルの生成 ##{#p2}
では、マイグレーションのスクリプトファイルを作成しましょう。これは、コマンドを使って行います。コマンドプロンプトあるいはターミナルを開き、カレントディレク トリをプロジェクトのフォルダ(「laravelapp」フォルダ)に移動してから、以下のようにコマンドを実行しましょう。
<p class="tmp cmd"><span>コマンド1</span></p>
```
php artisan make:migration create_customers_table
```
![](php_artisan_customers.png)


これは、customerテーブルを生成するためのマイグレーションファイルを作成するものです。マイグレーションファイルの作成のコマンドは、以下のような書式になります。

<p class="tmp"><span>書式1</span></p>
```
php artisan make:migration ファイル名
```
これで、指定のテーブルを作成するためのマイグレーションファイルが作られます。 マイグレーションのファイル名は、どのような作業をするものかがわかるようにしておきましょう。ここでは、customersテーブルを作成するので、「**create_customers_table**」としておきました。

### 「database」フォルダをチェック
では、マイグレーションファイルが作成されたか確認しましょう。マイグレーションファイルは、プロジェクトの「database」フォルダの中に作成されます。このフォルダの 中には「***migrations***」という名前のフォルダが用意されています。これが、マイグレーションファイルを保管しておくフォルダになります。  
このフォルダを開くと、その中に以下のようなファイルが見つかります。
上の1つ目と2つ目は元からあるファイルで、3つ目が新しく作成されたファイルです。

XXXX_create_users_table.php   
XXXX_create_password_resets_table.php   
***XXXX_create_customers_table.php***

(xxxxには日時を表す数値が当てはめられる)

マイグレーションファイルには、冒頭にファイルを生成した日付と時間を表す数字が付けられます。いつ作成されたのかが一目でわかるようになっています。  
**xxxx_create_customers_table.php**が先ほど作成したマイグレーションファイルですが、その他に2つのファイルが用意されていることがわかるでしょう。これは、プロジェクト に最初から用意されているusersとpassword_resetsというテーブルのためのファイルです。これらは認証などのセキュリティ関連で利用されるものです。今は特に利用することはありません。

## マイグレーション処理について ##{#p3}
では、作成されたxxxx_create_customer_table.phpを開いてみましょう。ここには、マイグレーションの基本的な枠組みが記述されています(コメントは省略してあります)。
<p class="tmp list"><span>リスト1</span>app/databse/migrations/xxxx_create_customer_table.php</p>
```
<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePeopleTable extends Migration
{
   public function up()
   {
       //
   }

   public function down()
   {
       //
   }
}
```

これが、マイグレーションの基本コードになります。これをベースに、必要に応じて 処理を追記してマイグレーション処理を完成させます。  
マイグレーション処理は、Migrationを継承したクラスとして作成されます。このクラスには以下の2つのメソッドが用意されます。

***upメソッド*** 
: テーブルを生成するための処理を記述します。

***downメソッド*** 
: テーブルを削除するための処理を記述しておきます。

この2つのメソッドが、テーブル操作の基本となります。これらはマイグレーション のコマンドによって自動的に呼び出されます。

## テーブル生成の処理 ##{#p4}
では、これらの処理を作成していきましょう。まずは、***upメソッド***です。これは、テーブルを生成する処理を用意しておくものです。 今回は、以下のような処理を記述しておくことにしましょう。

<p class="tmp list"><span>リスト2</span>app/database/mygrations/XXXX_create_customers_table.php</p>
```
public function up()
{
	Schema::create('customers', function (Blueprint $table) {
		$table->increments('id');
		$table->string('name');
        $table->string('age');
		$table->string('address');
		$table->string('login');
		$table->string('password');
		$table->timestamps();
	});
}
```

これが、customerテーブル生成の処理です。これを記述しておけば、customerテーブルの生成を行えるようになります。

### Schema::create について
テーブルの作成は、Schemaクラスの「***create***」メソッドを使って行います。これは次のように定義します。

<p class="tmp"><span>書式2</span></p>
```
Schema::create(テーブル名 , function(Blueprint stable){
	～ テーブルの作成処理 ～
});
```

createは、第1引数にテーブル名、第2引数にはテーブルを作成するための処理をまとめたクロージャが用意されます。createでテーブルそのものは作れるのですが、その中に用意する各フィールドなどはクロージャ内で設定します。

フィールドの設定は、クロージャの引数として渡されるBlueprintクラスのメソッドを 使って行います。これは多数のメソッドが用意されていますので、ここで主なものだけ 整理しておきましょう。


### プライマリキーの設定
<p class="tmp"><span>書式3</span></p>
```
$table->increment( フィールド名 );
```
自動的に整数値が割り付けられる(オートインクリメント)プライマリキーを設定します。プライマリキーは、レコードを識別するのに用いられるIDとなるフィールドです。 特別な事情がない限り、このincrementでプライマリキーのフィールドを設定すればいいでしょう。

### 指定した型のフィールドの設定
<p class="tmp"><span>書式4</span></p>
```
$table->integer( フィールド名 ); 
$table->bigInteger( フィールド名 ); 
$table->float(フィールド名 ); 
$table->double(フィールド名 ); 
$table->char(フィールド名 ); 
$table->string(フィールド名 ); 
$table->text(フィールド名); 
$table->longText(フィールド名 ); 
$table->boolean(フィールド名 ); 
$table->date(フィールド名 ); 
$table->dateTime(フィールド名);
```
テーブルに用意するフィールドを設定します。**フィールドの型を示すメソッド**を使って呼び出していきます。例えば、テキストを保管するnameというフィールドを用意するならば、**$table->string('name");**とすればいいわけです。  
数値やテキストに関するメソッドがいくつもありますが、これらは使用するデータ ベースによって使うものが違ってくるためです。SQLiteの場合、以下のものだけ利用すればいいでしょう。

|	|	|
|--|--|
|**整数**|	integer|
|**実数**|	float|
|**テキスト**|	string|
|**真偽值**|	boolean|
|**日時**|	date Time|

    

### タイムスタンプの設定
```
$table->timestamp();
```
Blueprintには、作成日時と更新日時を保管するフィールドを自動設定する機能があります。それが、このtimestampメソッドです。これを実行すると、**created_at** と **updated_at** という2つのdateTime型フィールドが自動設定されます。

## テーブルの削除処理 ##{#p5}
もう1つ、***downメソッド***も作成しておかなければいけません。これは、テーブルを削除します。このメソッドの処理は非常に簡単です。以下のように書いて下さい。

<p class="tmp list"><span>リスト3</span></p>
```
public function down()
{
   Schema::dropIfExists('customers');
}
```

テーブルの削除は、Schemaクラスに用意されているメソッドを用います。これは2つ用意されています。

### テーブルを削除
<p class="tmp"><span>書式5</span></p>
```
$chema::drop( テーブル名 );
```
テーブルを削除します。引数にはテーブル名を文字列で指定します。ただし、テーブ ルがなかった場合はエラーになります。

### テーブルがあれば削除
<p class="tmp"><span>書式6</span></p>
```
$chema::dropIfExists( テーブル名 );
```
指定した名前のテーブルがあった場合は削除します。ない場合は何もしません。

### マイグレーションを試す
では、実際にマイグレーションを試してみましょう。まず、「database」フォルダを開き、 そこにある「database.sqlite」ファイルを他の場所に移動しましょう。そしてコマンドプ ロンプトまたはターミナルでプロジェクトフォルダ(「laravelapp」フォルダ)にカレント ディレクトリを設定します。 以下のようにマイグレーションを実行しましょう。

もしSQLiteを使用している場合は、下記のコマンドを実行するとフォルダにSQLiteデータベースファイルが新たに作成されます。  
```
touch database/database.sqlite_
```
MySQLを使用している場合は、先ほど使用したshopデータベースを利用します。  
customerテーブルは一応エクスポートしておいてから、削除してください。  
マイグレーションとシーディングで新たにcustomerテーブルを作成し、レコードを登録していきます。


### マイグレーションを実行
マイグレーションを実行します。これは以下のコマンドで実行されます。  
実行する前に、migrationsフォルダに最初からあった以下の２つのファイルは、今は使わないのでbackupか何かのフォルダを作成して、そこに一旦格納しておきます。

* XXXX_create_users_table.php   
* XXXX_create_password_resets_table.php 
 
#### 実行コマンド
<p class="tmp cmd"><span>コマンド2</span></p>
```
php artisan migrate
```

コマンドを実行すると、  
shopデータベースに**customers** と **mygrations** の2つのテーブルが作成されます。

![](shop_db.png?classes=caption "図 データベースツリー")

<hr>

![](mygration_table2-1.png?classes=caption "図 customersテーブル")

<hr>

![](mygration_table3.png?classes=caption "図 mygrationsテーブル")



このように、マイグレーションファイルをあらかじめ作成しておけば、このようにコマンドで全て実行し、テーブルが用意されます。

## シーディングについて ##{#p6}
テーブルの用意は、これでできるようになりました。が、実際にartisan serveでサーバー を実行してみるとわかりますが、テーブルにはレコードはまったく用意されていません。 これでも、まぁ使えないわけではありませんが、初期状態でいくつかダミーのレコード を用意しておけるともっと便利です。  
こうした機能は「***シーディング***」と呼ばれます。これは、シード（最初から用意しておくレコード）を作成する機能です。これもマイグレーションと同様、Laravelには用意されています。  
シーディングも、マイグレーションと同様にいくつかの手順があります。

1. シーディングのためのスクリプトファイルを作成します。これはコマンドで用意できます。 
1. スクリプトファイルを編集してシードを追加しておきます。 
1. コマンドでシーディングを実行します。

この手順で実行すれば、テーブルにレコードを登録しておくことができます。ではやってみましょう。

## シーダーファイルの作成 ##{#p7}
まず、シードを作成するためのスクリプト（シーダー）ファイルを生成しましょう。これはコマンドとして実行します。コマンドプロンプトまたはターミナルから以下のよう に実行して下さい。
<p class="tmp cmd"><span>コマンド3</span></p>
```
php artisan make:seeder CustomersTableSeeder
```
実行すると、以下のように出力され、
![](seeder1.png)

seedsフォルダに「CustomersTableSeeder.php」のファイルが作成されます。

この他に、「DatabaseSeeder.php」というファイルも用意されています。これはデフォルトで用意されているシーダーファイルで、作成したシーダーファイルを登録するところです（これについては後で説明します）。

## シーディング処理について ##{#p8}
では、作成されたシーダーファイルを見てみましょう。これには以下のようなソース コードが記述されています。これが、シーディング処理を行うための基本となるコード です（コメントは省略しています）。

<p class="tmp list"><span>リスト4</span>app/database/seeds/CustomersTableSeeder.php</p>
```
<?php

use Illuminate\Database\Seeder;

class CustomersTableSeeder extends Seeder
{
   public function run()
   {
       //
   }
}
```

シーディング処理は、このように「Seeder」を継承したクラスとして定義します。ここには、「run」メソッドが1つだけ用意されています。このメソッド内に、レコードを作成するための処理を用意すればいいのです。

### シードを作成する
では、runメソッドに、customerテーブルのシードを作成する処理を用意してみましょう。 CustomerTableSeeder.phpのrunメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト5</span></p>
```
// use Illuminate\Support\Facades\DB;　を追記

public function run()
{
   $param = [
	   'name' => '熊木 和夫',
	   'age' => '25',
	   'address' => '東京都新宿区西新宿2-8-1',
	   'login' => 'kumaki',
	   'password' => 'BearTree1',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '鳥居 健二',
	   'age' => '47',
	   'address' => '神奈川県横浜市中区日本大通1',
	   'login' => 'torii',
	   'password' => 'BirdStay2',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '鷺沼 美子',
	   'age' => '21',
	   'address' => '大阪府大阪市中央区大手前2',
	   'login' => 'saginuma',
	   'password' => 'EgretPond3',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '鷲尾 史郎',
	   'age' => '33',
	   'address' => '愛知県名古屋市中区三の丸3-1-2',
	   'login' => 'washio',
	   'password' => 'EagleTail4',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '牛島 大悟',
	   'age' => '57',
	   'address' => '埼玉県さいたま市浦和区高砂3-15-1',
	   'login' => 'ushijima',
	   'password' => 'CowIsland5',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '相馬 助六',
	   'age' => '18',
	   'address' => '千葉県地足中央区市場町1-1',
	   'login' => 'souma',
	   'password' => 'PhaseHorse6',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '猿飛 菜々子',
	   'age' => '43',
	   'address' => '兵庫県神戸市中央区下山手通5-10-1',
	   'login' => 'sarutobi',
	   'password' => 'MonkeyFly7',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '犬山 陣八',
	   'age' => '67',
	   'address' => '北海道札幌市中央区北3西6',
	   'login' => 'inuyama',
	   'password' => 'DogMountain8',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '猪口 一休',
	   'age' => '15',
	   'address' => '福岡県福岡市博多区東公園7-7',
	   'login' => 'inokuchi',
	   'password' => 'BoarMouse9',
   ];
   DB::table('customers')->insert($param);

   $param = [
	   'name' => '中原 中也',
	   'age' => '47',
	   'address' => '東京都下宇野令村1-1',
	   'login' => 'nakahara',
	   'password' => 'naka1451',
   ];
   DB::table('customers')->insert($param);
}

```

見ればわかるように、実は特別な処理をしているわけではありません。DB::table ->insertを使って、レコードをいくつか作成しているだけです。レコードの作成は既にやっていますから、それをそのまま利用すればいいのです。

## シーダーファイルの登録 ##{#p9}
これでシーダーファイルは用意できましたが、まだこれだけでは使えません。作成したファイルが実行されるように、DatabaseSeederに登録をしておく必要があります。  
プロジェクトには、デフォルトでDatabaseSeeder.phpというファイルが用意されていました。これが、シーディングのコマンドで実行されるスクリプトなのです。それ以外のファイルは、直接実行されるわけではありません。ですから、このファイルの中に、CustomerTableSeederを呼び出す処理を用意しておくのです。  
では、DatabaseSeeder.phpを開き、以下のようにスクリプトを修正して下さい。

<p class="tmp list"><span>リスト6</span>app/database/seeds/DatabaseSeeder.php</p>
```
<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
   public function run()
   {
       $this->call(CustomersTableSeeder::class); //★
   }
}
```
記述したのは★マークの一文だけです。このDatabaseSeederも、CustomersTableSeederと 同じくSeederクラスを継承して作られています。このrunに、シーダーを実行する処理 を記述します。これは以下のようになっています。
```
$this->call( シーダークラス ::class);
```
実行するシーダークラスのclassプロパティを引数にして「***call***」というメソッドを呼び出します。これはSeederクラスにあるメソッドで、これにより指定したクラスのrunメ ソッドが呼び出され、シーディング処理が実行されるようになっています。


## シーディングを実行する ##{#p10}
さあ、これでシーディングの処理が完成しました。コマンドプロンプトあるいはター ミナルからシーディング処理を実行しましょう。以下のようなコマンドを使います。
<p class="tmp cmd"><span>コマンド4</span></p>
```
php artisan db:seed
```
シーディング処理の実行は、**artisan db:seed**というコマンドで実行します。これで、DatabaseSeederのrunが実行され、そこから各シーダーファイルのrunが呼び出されて実行されます。

1. コマンドを実行すると、メッセージが表示され、
![](artisan_seed.png)

2. CustomerTableSeeder.phpに追記したデータが下図のようにcustomersテーブルに追加されます。
![](customer_seed1.png)

/helloにアクセスして、確認すると以下のように表示されます。
![](customer_seeder_hello.png)
