*[page-title]:画像のリサイズ

## 画像をリサイズしてみる

使用する関数と、役割を書きます。

* getimagesize・・・画像のサイズの取得
* imagecopyresampled・・・コピーと伸縮
* imagejpeg(※「image」の後は出力する画像形式によって変化)・・・画像の出力

その他のGDの関数
: <https://www.php.net/manual/ja/book.image.php>

対応している画像形式
: png
: gif
: jpeg(.jpg)
: xbm
: bmp

※扱う画像の拡張子によって使用する関数が変わる場合があるので注意です。  
imagejpegはjpegを出力する関数ですが、gifの場合はimagegifとなります。

## 実際に画像をリサイズする

方法
: ① getimagesizeとimagecreatefromjpegとimagecreatetruecolorで画像を作る準備をします。
: ② imagecopyresampledで画像のコピーとリサイズをします。
: ③ imagejpegで出力します。


次のファイルにアクセスすると、実行されます。

<a href="sample/image_resize/phpGd.php" target="_blank">新規タブ（image_resize）</a>

<p class="tmp list"><span>リスト</span>phpGd.php</p>
```
phpGd.php
<?php
    list($width, $hight) = getimagesize('test.jpg'); // 元の画像名を指定してサイズを取得
    $baseImage = imagecreatefromjpeg('test.jpg'); // 元の画像から新しい画像を作る準備
    $image = imagecreatetruecolor(100, 100); // サイズを指定して新しい画像のキャンバスを作成
    
    // 画像のコピーと伸縮
    imagecopyresampled($image, $baseImage, 0, 0, 0, 0, 100, 100, $width, $hight);
    
    // コピーした画像を出力する
    imagejpeg($image , 'new.jpg');
?>
```
因みにtest.jpg等、ファイル名を記載している部分はパス名を記載できます。  
好きな場所に出力したり、好きな場所の画像をコピーする事ができます。


## 画像の縦横比を固定してリサイズ

### 画像の縦横のサイズを取得して縮小後のサイズを計算するfunction

縦横どちらか大きい方の辺に合わせて、反対の辺を縮小した際の比率を計算します。
```
function ratio($w, $h){
  $newwidth = 0; // 新しい横幅
  $newheight = 0; // 新しい縦幅
  $res_w = 800; // 最大横幅
  $res_h = 800; // 最大縦幅

  if ($w > $h) {
    // 横長の画像は横のサイズを指定値にあわせる
    $ratio = $h / $w;
    $newwidth = $res_w;
    $newheight = $res_w * $ratio;
  } else {
    // 縦長の画像は縦のサイズを指定値にあわせる
    $ratio = $w / $h;
    $newwidth = $res_h * $ratio;
    $newheight = $res_h;
  }


  $rtn_wh = [
    'width' => $newwidth,
    'height' => $newheight,
  ];

  return $rtn_wh;
}
```

### 画像をリサイズするfunction

```
function img_resize($url, $res_w, $res_h, $p_w, $p_h, $x, $y, $picturename){
  list($w, $h, $type) = getimagesize($url);
  
  switch($type){
    case IMAGETYPE_JPEG:
      $in = imagecreatefromjpeg($url);
      break;
    case IMAGETYPE_GIF:
      $in = imagecreatefromgif($url);
      break;
    case IMAGETYPE_PNG:
      $in = imagecreatefrompng($url);
      break;
  }


  // コピー画像のリソース
  $out = imagecreatetruecolor($res_w, $res_h);
  imagealphablending($out, false);
  imagesavealpha($out, true); 
  // リサイズ
  ImageCopyResampled($out, $in, 0, 0, $x, $y, $res_w, $res_h, $p_w, $p_h);
  
  imagepng($out, UP_PATH_TALK.$picturename);

  imagedestroy($out);
  imagedestroy($in);
}
```

### 参考サイト

* [PHPで画像アップロード時に比率を保ったまま縮小する](https://mugenweb-note.com/web/php/php_image_resize)


## 透過処理

### 参考サイト

* [PHP | GDで透過背景のテキスト画像を作成する方法](https://1-notes.com/php-gd-create-text-image-with-transparent-background/)


## base64から画像ファイルを保存する


### base64とは
文字列、画像、オブジェクト、ファイルなど様々なデータを64種類の英数字と記号(a-z, A-Z, 0-9, +, /)で表現したものです。元々ASCII文字のテキストしか扱えなかったメール通信で画像などのバイナリデータを扱う為にASCII文字に変換する方式として導入されました。

少ない文字で表現しますので、元のデータよりも33%以上サイズが増えます。その特徴から、主にサイズの小さいデータを扱うことが多いです。


### base64形式のメリット
base64処理を用いるメリットとしては、画像ファイルをbase64に変換すると文字列になりますので、サーバーにデータを送信する場合などに元のバイナリデータのままよりも、処理が単純になります。  
また、base64エンコードされた画像はウェブページに直接埋め込むこともできます。これによって、HTTPリクエストの回数を減らす効果があります。

さらに、データを保存する場合も、文字列として扱えますので、データベースのテキストフィールドにそのまま保存できます。

### エンコード、デコードとは
どちらもあるデータを異なる形式のデータに変換することを意味しますが、変換する方向が異なります。

エンコードは元のデータを別の形式のデータに変換する処理を指し、デコードは変換後のデータを元の形式のデータに戻す処理を指します。

![](9e9a910c2daacfd75519fcd1a0b67fee-400x114.png)

base64エンコード・デコードの場合も変換する形式がbase64である点以外は同じです。

base64エンコードがデータをbase64形式のデータに変換し、base64デコードがbase64データを元の形式のデータに変換します。

### PHPによる処理
phpでは、この処理にbase64_encode関数とbase64_decode関数を使います。

```
$greeting = 'Hello World!';

//文字列をbase64にエンコード
$encoded = base64_encode($greeting);

//base64形式データをデコードして元の文字列に戻す
$decoded = base64_decode($encoded);

print $decoded;
```

<p class="tmp">実行結果</p>
```
Hello World!
```

### finfo_bufferメソッドとは

**finfo_buffer関数**を使うとバイナリデータからMIMEタイプのような情報を取得できます。例えば、finfo_bufferを使えば画像データのMIMEタイプを取得して、特定のMIMEタイプかどうか判断したり、対応する拡張子を選ぶなどが可能になります。
インターネット上で送られてきたファイルやアップロードされたファイルには、拡張子のようなファイルの情報が付属するのが普通ですが、こうした情報は送信側で偽装することができます。ファイルのデータを安全に操作する為にも、実際のデータのMIMEタイプをfinfo_bufferで調べてそれを利用するのをお勧めします。

<p class="tmp"><span>finfo_buffer関数</span></p>
```
finfo_buffer ( resource $finfo , string $string )
```
この関数は、第1引数にfinfo_open() が返す fileinfo リソースを、第2引数に調べたいファイルデータを渡します。戻り値はファイルデータの情報を文字列で返します。エラーの場合は false を返します。

### finfo_bufferのコード例
ファイルのデータからMIMEタイプを取得するコードは次のようになります。

```
 // ファイルデータを取得
 $path = 'sample.jpg';
 $data = file_get_contents($path);

 // まず、fileinfoリソースを作成（MIMEタイプなどのファイル情報を調べるためのデータベース）
 $finfo = finfo_open(FILEINFO_MIME_TYPE);

 //ファイルデータのMIMEタイプを取得
 $mime_type = finfo_buffer($finfo, $data);

 // MIMEタイプを出力
 print $mime_type;
 ```

<p class="tmp">実行結果</p>
```
image/jpeg
```

### 実際に書いてみよう
これまでの知識を使ってbase64形式の画像データを読み込んで、画像ファイルとして適切な拡張子を付けて保存するコードを実際に書いてみましょう。

まずサンプルとして、カモメのjpeg画像(searbird.jpg)を使います。

![](seabird-400x266.jpg)

まず、この画像を変換してbase64形式のデータを用意します。
<p class="tmp list"><span>リスト</span>base64/index.php</p>
```
// ファイルのデータを取得
$file_path = 'original/seabird-400x266.jpg';
$data = file_get_contents($file_path);

// データをbase64にエンコード
$base64data = base64_encode($data);
```

以下のコードではbase64形式で変換した画像データ使いますが、base64形式のデータを外部から受信して処理することもあります。その場合は、HTTPリクエストで送信されたデータを取得するために、$_GETなどのグローバル変数を利用します。


<p class="tmp list"><span>リスト</span>base64/index.php</p>
```
<?php

// base64デコード
$data = base64_decode($base64data);

// finfo_bufferでMIMEタイプを取得
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime_type = finfo_buffer($finfo, $data);

//MIMEタイプをキーとした拡張子の配列
$extensions = [
    'image/gif' => 'gif',
    'image/jpeg' => 'jpg',
    'image/png' => 'png'
];

//MIMEタイプから拡張子を選択してファイル名を作成
$filename = 'image.' . $extensions[$mime_type];

// 画像ファイルの保存
file_put_contents($filename, $data);
```

#### 実行結果

次のファイルにアクセスすると、実行されます。  
わかりやすように、途中の変換したコードを表示されるようにしています。  
oriinalフォルダの画像（seabird-400x266.jpg）を base64にエンコード して、それからbase64デコードで画像ファイルにして、image.jpg として保存しています。

<a href="sample/base64/" target="_blank">新規タブ（phpGd.php）</a>


同じフォルダ内にimage.jpgファイルがあり、カモメの画像が保存されました。

![](seabird-400x266.jpg)

#### 解説
ここではまず、上で用意したbase64データをbase64_decode関数を使ってデコードして元の画像データに変換します。次にfinfo_buffer関数でMIMEタイプ（ここでは image/jpeg ）を取得しています。最後に image/jpeg に対応する拡張子（ jpg ）を使って画像ファイルとして保存しています。

### 参考サイト

[PHPでbase64から画像ファイルを保存する方法を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/47478)







## 参考サイト

* [PHPで画像をリサイズしよう！表示・保存方法もわかる](https://www.sejuku.net/blog/74338)
* [PHPでの画像の保存・表示方法まとめ](https://qiita.com/okdyy75/items/669dd51b432ee2c1dfbc)
* [FormDataの使い方](https://javascript.keicode.com/newjs/how-to-use-formdata.php)