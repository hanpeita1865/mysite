*[page-title]:Twig 設定方法

## インストール

まず、composerでTwigをインストールします。  
フォルダを指定して、次のコマンドを実行してください。

<p class="tmp cmd"><span>コマンド</span></p>
```
composer require "twig/twig:^3.0"
```

<p class="tmp">実行結果</p>
```
C:\Users\hirao\Desktop\twig>composer require "twig/twig:^3.0"
Info from https://repo.packagist.org: #StandWithUkraine
./composer.json has been created
Running composer update twig/twig
Loading composer repositories with package information
Info from https://repo.packagist.org: #StandWithUkraine
Updating dependencies
Lock file operations: 3 installs, 0 updates, 0 removals
  - Locking symfony/polyfill-ctype (v1.25.0)
  - Locking symfony/polyfill-mbstring (v1.25.0)
  - Locking twig/twig (v3.3.9)
Writing lock file
Installing dependencies from lock file (including require-dev)
Package operations: 3 installs, 0 updates, 0 removals
  - Downloading symfony/polyfill-mbstring (v1.25.0)
  - Downloading twig/twig (v3.3.9)
  - Installing symfony/polyfill-mbstring (v1.25.0): Extracting archive
  - Installing symfony/polyfill-ctype (v1.25.0): Extracting archive
  - Installing twig/twig (v3.3.9): Extracting archive
Generating autoload files
3 packages you are using are looking for funding.
Use the `composer fund` command to find out more!
C:\Users\hirao\Desktop\twig>
```
インストールが完了すると、指定したフォルダに次のファイルが作成されます。

![](upload/インストール後フォルダ構成.png "インストール後フォルダ構成")

※とりあえず、デスクトップにtwigフォルダを作成して、そこにインストールしました。

フォルダの直下に次のファイルを作成します。
<p class="tmp list"><span>リスト</span>index.php</p>
```
<?php
//require_once '/vendor/autoload.php';
require_once($_SERVER["DOCUMENT_ROOT"]."/twig/vendor/autoload.php");

$loader = new \Twig\Loader\ArrayLoader([
    'index' => 'Hello {{ name }}!',
]);
$twig = new \Twig\Environment($loader);

echo $twig->render('index', ['name' => 'Fabien']);

```
`require_once($_SERVER["DOCUMENT_ROOT"]."/twig/vendor/autoload.php");` の中にあるtwigは、ドキュメントルート以下のパスになります。  
フォルダ名が変わるごとに、適宜変更してください。

次のリンクに接続すると、  
<a href="sample/base/" target="_blank">サンプル（sample/base/）</a>

「Hello Fabien!」と表示されると思います。

### テンプレート

Twigは、ローダー（\ Twig \ Loader \ ArrayLoader）を使用してテンプレートを検索し、環境（\ Twig \ Environment）を使用してその構成を保存します。  
render（）メソッドは、最初の引数として渡されたテンプレートをロードし、2番目の引数として渡された変数を使用してそれをレンダリングします。  
テンプレートは通常ファイルシステムに保存されるため、Twigにはファイルシステムローダーも付属しています。（公式サイトを翻訳）


<p class="tmp list"><span>リスト</span>index2.php</p>
```
<?php
require_once("vendor/autoload.php");
$loader = new \Twig\Loader\FilesystemLoader("templates");

$twig = new \Twig\Environment($loader);

echo $twig->render('index.html', ['the' => 'variables', 'go' => 'here']);
```

次のリンクに接続すると、  
<a href="sample/base/index2.php" target="_blank">baseサンプル2</a>

<div markdown="1" class="photo-border">
![](upload/variable.png)  
</div>
と表示されます。