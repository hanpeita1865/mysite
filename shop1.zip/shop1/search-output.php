<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>検索結果</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <table>
        <tr>
            <th>商品番号</th>
            <th>商品名</th>
            <th>生産地</th>
            <th>商品価格</th>
        </tr>
        <?php
        $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
        $sql = $pdo->prepare('select * from products where name=?');
        $sql->execute([$_REQUEST['keyword']]);

        // foreach ($sql->fetchAll() as $row) {
        //     echo '<tr>';
        //     echo '<td>', $row['id'], '</td>';
        //     echo '<td>', $row['name'], '</td>';
        //     echo '<td>', $row['price'], '</td>';
        //     echo '</tr>';
        //     echo "\n";
        // }
        ?>

        <?php foreach ($sql->fetchAll() as $row): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['local'] ?></td>
            <td><?= $row['price'] ?></td>
        </tr> 
        <?php endforeach ?>
    </table>
</body>
</html>