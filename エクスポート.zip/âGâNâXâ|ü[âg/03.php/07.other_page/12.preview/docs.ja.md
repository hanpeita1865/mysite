---
title: プレビュー機能
taxonomy:
    category:
        - docs
---

## 別ウィンドウにプレビュー表示

base64として、inputで送信する方法です。（サーバーの設定によっては使えません）

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
ファイルを選択して送信ボタンをクリックすると別ウィンドウが開き、プレビュー画像が表示されます。  
選択して表示された画像のimgのsrcの値（base64）を送信用のinputのvalue値に入れて、preview.phpに送っています。
[新規タブ](../../../sample/php/other_page/preview/preview(base64)/index.html?target=_blank)
</div>

<p class="tmp">HTML</p>
```
<input type="file" name="file" id="btn-img">
<div id="image-area"></div>

<button>送信</button>
<form id="form-preview" class="extlink1" target="newtab" action="preview.php" method="POST">
	<input type="hidden" name="top-img" id="top-img" value="">
	<!--画像データ-->
</form>
```

<p class="tmp">JS</p>
```
$(function () {
    $('#btn-img').change(function (e) {

        var imgTopSize = this.files[0].size; //ここでファイルサイズを取得
        if (imgTopSize >= 2000000) {
            resetTopImg();
            $('#image-area').html('');//表示されてる画像を最初にクリア
            alert('ファイルサイズが大きすぎます。（' + imgTopSize + 'Byte）')
        } else {

            $('#image-area').html('');//表示されてる画像を最初にクリア

            var file = e.target.files[0];//Fileオブジェクトを取得
            var reader = new FileReader(); //オブジェクトを生成

            //ファイル情報をキャプチャする
            reader.onload = (function (file) {
                return function (e) {
                    // サムネイル用のimgタグ
                    var $html = '<figure><img id="photo-top" class="thumb" src="' + e.target.result + '"></figure>';

                    // サムネイルタグを生成
                    $('#image-area').append($html);
                };
            })(file);

            reader.readAsDataURL(file);

        }
    });


    $('button').on('click', function () {
        var photo = $('#photo-top').attr('src');//画像データ
        $('#top-img').val(photo);
        $('#form-preview').submit();
    });

}); 
```

<p class="tmp">preview.php</p>
```
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>プレビュー</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
	<img src="<?= $_REQUEST['top-img'] ?>" class="photo" id="top-img" alt="">	
</body>
</html>
```

## 画像を保存せずbase64として遷移なしで表示

<div class="box-example" markdown="1">
### 例2 ### {.h-example}
ファイルを選択して送信ボタンをクリックすると、同ページにプレビュー画像が表示されます。  
選択して表示された画像を非同期でpreview.phpに送り、画像をbase64に変換してimgのsrcに格納して送信元のページに返して、プレビューとして表示させています。
[新規タブ](../../../sample/php/other_page/preview/preview(base64)2/index.html?target=_blank)
</div>

<p class="tmp">HTML</p>
```
<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="x-ua-compatible" content="IE=Edge" />
	<meta name="viewport" content="width=device-width, user-scalable=no" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<title>（平尾ローカル）BASE64データ送信テスト</title>
	<link rel="stylesheet" href="css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
</head>

<body>
	<input type="file" name="file" id="img-file">
	<div id="image-area"></div>

	<button>送信</button>
	<form id="form-preview" class="extlink1" target="newtab" action="preview.php" method="POST">
		<input type="hidden" name="imgName" id="img-name" value="">
	</form>
	<div id="preview"></div>
	<script type="text/javascript" src="js/script.js"></script>
</body>

</html>
```

<p class="tmp">JS</p>
```
$(function () {
    let imgName;//ファイル名

    $('#img-file').change(function (e) {

        let imgTopSize = this.files[0].size; //ここでファイルサイズを取得
        imgName = this.files[0].name;//ファイル名を取得

        if (imgTopSize >= 2000000) {
            resetTopImg();
            $('#image-area').html('');//表示されてる画像を最初にクリア
            alert('ファイルサイズが大きすぎます。（' + imgTopSize + 'Byte）')
        } else {

            $('#image-area').html('');//表示されてる画像を最初にクリア

            var file = e.target.files[0];//Fileオブジェクトを取得
            var reader = new FileReader(); //オブジェクトを生成

            //ファイル情報をキャプチャする
            reader.onload = (function (file) {
                return function (e) {
                    // サムネイル用のimgタグ
                    var $html = '<figure><img id="photo-top" class="thumb" src="' + e.target.result + '"></figure>';

                    // サムネイルタグを生成
                    $('#image-area').append($html);

                };
            })(file);

            reader.readAsDataURL(file);

        }
    });


    $('button').on('click', function () {

        let fd = new FormData();
        fd.append('upimg', $('#img-file')[0].files[0]);

        $('#img-name').val(imgName);

        $.ajax({
            url: 'preview.php',
            type: 'POST',
            processData: false,
            contentType: false,
            cache: false,
            data: fd
        }).done(function (data) {
            //通信成功時の処理
            $('#preview').html(data);

        }).fail(function () {
            //通信失敗時の処理
            alert('失敗しました～。')
        });
    });

}); 
```

<p class="tmp">preview.php</p>
```
<?php
	if (!empty($_FILES['upimg']['tmp_name'])) {

		$fp = fopen($_FILES['upimg']['tmp_name'], "rb");
		$img = fread($fp, filesize($_FILES['upimg']['tmp_name']));
		fclose($fp);
		
		$enc_img = base64_encode($img);
		
		$imginfo = getimagesize('data:application/octet-stream;base64,' . $enc_img);
		
		echo '<img src="data:' . $imginfo['mime'] . ';base64,'.$enc_img.'">';
	}
?>
```

## 画像をTextAreaでbase64として送信して表示

<div class="box-example" markdown="1">
### 例3 ### {.h-example}
ファイルを選択して送信ボタンをクリックすると、textareaに格納したbase64の画像データがpreview.phpに送信され、プレビュー表示されます。<br>
textareaは、display:noneで非表示にしています。
[新規タブ](../../../sample/php/other_page/preview/preview(base64)3/index.html?target=_blank)
</div>

## 参考サイト

* [PHPでの画像の保存・表示方法まとめ](https://qiita.com/okdyy75/items/669dd51b432ee2c1dfbc)
* [fopen関数から始める!ファイルの読み込み・書き込み方法【PHP入門】](https://www.sejuku.net/blog/24369)
* [formから画像をBase64に変換した文字列を送信](https://chocolateorange.github.io/2016/11/20/02/)