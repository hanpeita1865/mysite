*[page-title]:補足（Veu.jsについて）

## データベースの利用

参考サイト
: [Vue.jsからデータベースに対して読み書きをしたい](https://reffect.co.jp/vue/vue-js-database)

下記の項目にあるSQLiteとそれをつなぐPrismaでデータベースの利用を試してみたい。

### Expressサーバ編(Prisma + SQLite)
Supbase, Firebaseはどちらもクラウドベースのサービスでサーバの構築を行う必要がありませんでした。ここではNode.jsのExpresサーバ用を準備してデータベースへの接続を行います。Vue.jsからアクセスは一度Expressサーバを経由してデータベースへアクセスすることになります。

データベースにはSQLiteを利用しますがExpressサーバとSQLiteデータベースの間にORMであるPrismaを利用します。Prismaを利用することでSQLではなくPrisma上で定義するモデルオブジェクトのメソッドを通してデータベースの操作を行います。Prismaを利用した場合はSQLiteだけではなくMySQLやPostgres, mongoDBの接続にも利用することができます。

続きは、上記の参考サイトを見てください。