---
title: Djangoの概略と使い方
media_order: 'anaconda_sitetop.png,django_sitetop.png,anaconda_download.png'
taxonomy:
    category:
        - docs
visible: true
---

Pythonは、Web開発用に設計された言語というわけではありません。  
PythonでWeb開発を行う場合、全部自分でプログラムを作っていくとなるとかなり大変です。  
そこでフレームワークと呼ばれるソフトウェアがけっこう使われます。フレームワークというのは、いろんな機能だけでなく「仕組み」そのものまで作成してあるソフトウェアのことです。

Python用のフレームワークとしてもっとも広く使われているのが「**{c:red}Djangot（ジャンゴ）{/c}**」です。  
Djangoは、MVCフレームワークと呼ばれるものです。MVCというのは、Webアプリケーションの設計に関するもので、アプリケーション全体の制御やデータベースアクセスなどを容易に行えるようにしてくれます。 

このDjangoを使うことで、データベースを使った複雑なWebアプリケーションを個人でも簡単に作成できるようになりました。  
「**Djangoのおかげで、Web開発にPythonが普通に使えるようになった**」といってもいいでしょう。

Djangoには、以下のような多くのメリットがあるため、広く使われています。

* 便利な管理画面
* Django一つでWebフレームワークとして完結している
* Pythonで書かれていて読みやすい

### Djangoの公式サイト

トップページ　[https://www.djangoproject.com/](https://www.djangoproject.com/)  

[![](django_sitetop.png?cropResize=400)](https://www.djangoproject.com/)


Django ドキュメント　[https://docs.djangoproject.com/ja/3.0/](https://docs.djangoproject.com/ja/3.0/)



### DjangoでWeb開発に必要なもの

* Python言語
* Django
* 開発環境
* Webサーバー
: Web開発には、自分のパソコンでWebサーバー動かし、その場で動作チェックを行いながら開発を進めるのが一般的です。


これらを一通り用意し、いろいろセットアップしてなんてことをしたら大変面倒です。  
こうしたものが全部セットアップされているものが「**{c:red}Anaconda（アナコンダ）{/c}**」というソフトウェアになります。  
Anacondaは、特に数値処理などを行うプログラマの間で結構使われています。  
そうした数値処理関係のプログラムがいろいろと入っているためです。

Anaconda公式サイト
: [https://www.anaconda.com/](https://www.anaconda.com/)

[![](anaconda_sitetop.png?cropResize=400)](https://www.anaconda.com/)


### ダウンロード

公式サイト右上にある「Download」ボタンをクリックしてください。
それぞれのOS用のソフトウェアをダウンロードするページに移動します。

その画面に、Anaconda 2019.10 for Windows Installerの下に「Python 3.7 version」「Python 2.7 vertion」という2つの表示があります。(2020.2.19現時点でのバージョン)  
ここにあるボタンをクリックすると、インストーラがダウンロードできるので、ver3用のものをインストールしましょう。
「Python 3.7 version」にある「Download」ボタンをクリックすると、Python3のAnacondaインストーラがダウンロードされます。

![](anaconda_download.png)


### Anaconda3へのSeleniumのインストール方法について

Environmentsを選び、プルダウンメニューでAllかNot installedを指定して、検索窓にSeleniumと入れてやると、Seleniumが表示されました。そのままApplyボタンを押してイントール。この操作でうまくSeleniumuがインストールできました。  
その方法が出来ない場合は、そこで、base(rood)という文字の横の三角形（矢頭）をクリックするとOpen terminalが選ぶのでそれを選んで、ターミナルウインドウを起動します。そして、ウェブ記事<https://anaconda.org/conda-forge/selenium>を参考に、
```
conda install -c conda-forge selenium
```
としてやると、セレニウムのモジュールがちゃんとアナコンダにインストールされます。

## 参考サイト

[Anaconda3へのSeleniumのインストール](http://scienceandtechnology.jp/archives/35881)











