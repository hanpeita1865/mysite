---
title: ログイン・ログアウト設定
taxonomy:
    category:
        - docs
---

## ログイン機能の作成

***※ハッシュ化したパスワードを使って、ログインできるようにはなってません。***

データベースにはSQLiteを使用しており、databaseフォルダに格納しています。  
データベース名は、「shop」です。

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
上部メニューの「ログイン」をクリックすると、ログイン画面が開きます。下記のユーザー名とパスワードでログインできます。パスワードには、hash関数を使って変換した値をデータベースに記録しています。
[新規タブ](../../../sample/php/php_intro/chapter7/index.php?target=_blank)
</div>

例) ユーザ名: hirao　パスワード: ryouma1222

##### login-input.php
```
<form action="login-output.php" method="post">
ログイン名<input type="text" name="login"><br>
パスワード<input type="password" name="password"><br>
<input type="submit" value="ログイン">
</form>
```

##### login-output.php
```
unset($_SESSION['customer']);
$pdo = new PDO( 'sqlite:../database/shop.db' );//SQLite用
//$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 'staff', 'password');//MySQL用
//hirao ryouma1222でログイン
$sql=$pdo->prepare('select * from customer where login=? and password=?');

//パスワードハッシュ化
//$loginPass = hash("sha256", $_REQUEST['password']);

$loginPass =$_REQUEST['password'];

$sql->execute([$_REQUEST['login'], $loginPass]);
foreach ($sql->fetchAll() as $row) {
	$_SESSION['customer']=[
		'id'=>$row['id'], 'name'=>$row['name'], 
		'address'=>$row['address'], 'login'=>$row['login'], 
		'password'=>$row['password']];
}
if (isset($_SESSION['customer'])) {
	echo 'いらっしゃいませ、', $_SESSION['customer']['name'], 'さん。';
} else {
	echo 'ログイン名またはパスワードが違います。';
}
?>
```

### 解説

SQL文をexecuteメソッドで実行した結果は、**fetchAllメソッド** で取得することができます。**foreachループ** と組み合わせて、取得した結果を処理します。

<p class="mb-05"><span class="tmp">書式1</span><span class="bold"></span></p>
```
foreach ($sql->fetchAll() as $row) {
```

ログイン名とパスワードの組み合わせが見つかった場合には、foreachループの内部が実行され ます。内部では次の処理を行います。

変数$rowには、データベースから取得した顧客テーブルの行が格納されています。顧客番号 (id) は、$row['id']という記述で取得することができ、同様に、顧客名(name)、住 所(address)、ログイン名(login)、パスワード(password) を取得し、各々の列名を添字にして、配列にします。  
この配列を**$_SESSION['customer']**に代入します。

```
$_SESSION['customer']=[
	'id'=>$row['id'], 'name'=>$row['name'], 
	'address'=>$row['address'], 'login'=>$row['login'], 
	'password'=>$row['password']];
```

そして最後に、変数が定義されているかどうかを調べる **isset関数** を使って、ログインに成功したかどうかを調べます。

```
if (isset($_SESSION['customer'])) {//登録データがあるので、ログイン
    //ログインが成功した時の処理

} else {//登録データがない
     //ログインが失敗した時の処理
}
```


## ログアウト機能の作成

ログイン機能と対になるログアウト機能を作成しましょう。ログアウトするには、ログイン時に 作成したセッションデータを削除します。 

ログアウト画面
: <http://localhost/php/shop/chapter7/logout-input.php>

##### logout-input.php
```
<p>ログアウトしますか？</p>
<a href="logout-output.php">ログアウト</a>
```
##### logout-output.php
```
<?php
session_start();

if (isset($_SESSION['customer'])) {
	unset($_SESSION['customer']);
	echo 'ログアウトしました。';
} else {
	echo 'すでにログアウトしています。';
}
?>
```

まだログインしていない場合や、既にログアウトしていた場合には、「すでにログアウトしています。」と表示されます。

### 解説

#### セッションデータの削除

ログアウトのスクリプトでもセッションを利用するので、最初にsession_start関数を呼び出します。
```
session_start();
```
次に、現在ログインしているかどうかを調べます。isset関数を使って、$_SESSION['customer']が定義されているかどうかを確認します。

```
if (isset($_SESSION['customer'])) {
```
ログインしている場合には、ログアウトします。  
unset関数を使って、$_SESSION['custom er'] に定義された顧客情報を削除します。
```
unset($_SESSION['customer']);
```



