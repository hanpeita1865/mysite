<?php
namespace SocymSlim\SlimMiddle\middlewares;

use PDO;
use PDOException;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;

class FolderSortCheck implements MiddlewareInterface
{
    // コンテナインスタンス
    private $container;

    // コンストラクタ
    public function __construct(ContainerInterface $container)
    {
        // 引数のコンテナインスタンスをプロパティに格納。
        $this->container = $container;
    }


    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $sourcePath = '../pages';

        $pagesObj1 = $this->container->get("folderComp"); //pagesオブジェクト

        $folderCnt1 = count($pagesObj1);

        $menuArray1 = json_decode($_POST['list']);
        $menuObj = [];

        foreach ($menuArray1 as $val) {
            $dirArray = explode('/', $val);
            $lastDir = end($dirArray); //配列の最後の値
            $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
            $menuObj[$folderNoNum] = '../pages/'.$val;
        }

        $sabunFolder = array_diff($pagesObj1, $menuObj);

        $array2 = [];

        $before = [];
        $after = [];

        $fdArray = [];

        foreach ($sabunFolder as $key => $value){
            $array1 = explode('/', $value);

            $menuObj[$key];
            $array2 = explode('/', $menuObj[$key]);

            $cnt1 = count($array1);
            $cnt2 = count($array2);
            
            iF($cnt1==3 && $cnt2==3){
            // iF($cnt2==3){
                array_push($fdArray, ["name"=>$key, "before"=>$value, "after"=>$menuObj[$key]]);
            }
        }

        // $res2 = array_unique($fdArray);

        $content = "true";

        foreach($fdArray as $fd){

            try{
                if(rename ( $fd['before'] , $fd['after'] )){

                }else{
                    throw new PDOException();
                }

            }catch(PDOException $e){
                // echo $e->getMessage();
                $content = "false";

                // exit('処理を強制終了します。');//処理を強制終了

            }finally{
                // echo "処理が終了しました";
            }
        }

        $response = $handler->handle($request);

        return $response;
    }
}