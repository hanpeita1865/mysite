<?php
    /*foreach (glob('./upload/*') as $item) {
        $file_name = basename($item);//ファイル名だけを抜き出す
        echo '<li><span class="filename">'.$file_name.'</span><button class="fileDelete">削除</button></li>';
    }

 