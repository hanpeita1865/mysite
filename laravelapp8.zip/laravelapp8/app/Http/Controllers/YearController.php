<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Year;

class YearController extends Controller
{
    public function index(Request $request)
    {
        $years = Year::all();

        return view('year.index', ['years'=>$years]);
    }


    public function create(Request $request)
    {
        $year = new Year;
        // $form['nendo'] = 2024;

        $lastNendo = $year->latest('nendo')->first();//最終年度

        $newNendo = $lastNendo->toArray()['nendo'] + 1;//新年度

        $form['nendo'] = $newNendo;

        unset($form['_token']);
        $year->fill($form)->save();
        return redirect('/year');
    }
}
