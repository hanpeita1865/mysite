*[page-title]:10-17. 光の反射で表現してみよう


## 炎フィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-17-1.jpg)](upload/10-17-1.jpg){.image}
</div>

## 照明効果フィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-17-2.jpg)](upload/10-17-2.jpg){.image}
</div>