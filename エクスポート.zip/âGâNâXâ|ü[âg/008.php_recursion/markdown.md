*[page-title]:再帰処理


参考サイト
: [PHPで再帰処理を実装する方法を現役エンジニアが解説【初心者向け】](https://magazine.techacademy.jp/magazine/40767)
: [PHPとJavaScriptで入れ子配列を平坦にする方法(再帰処理)](https://zenn.dev/chromel/articles/92858f7e827d1c)

## 再帰処理について

再帰処理とは、関数がメソッドの中で自分自身を呼び出す処理のことです。  
自分自身を呼び出すため適切な終了処理をしない限り<span class="red">無限ループになってしまう点に注意</span>する必要があります。

再帰処理はなかなか処理内容を理解するのが難しいところですですが使えるようになるとソースをシンプルに書けるようになります。

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	再帰関数に引数1を引き渡し、処理で「+1」を追加し、再び関数の中の処理を実行します。それを10になるまで繰り返しています。
	<iframe src="https://paiza.io/projects/e/VYaSv3NVBPmhu0ivNx291g?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例2</span></p>
	ここでは階乗の計算を行います。<br>
	階乗とは数学の計算方法の1つで4!や5!のように「数字!」と書きます。1から数字までの整数を掛け合わせた値を得ることができます。<br>
	6!だと以下のような計算になります。  <br>
「6! = 6 * 5 * 4 * 3 * 2 * 1」<br>
例では、6と7の引数から開始し、処理で1になるまで再帰関数を繰り返しています。
	<iframe src="https://paiza.io/projects/e/EQow8Ejxy2MR0TX0NzPp3A?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例3</span></p>
	[1,[4,9],16,[25,[36,49]],64] みたいな恰好をした入れ子の配列を順番をそのままで一階層の配列に直す方法です。（練習用）
	<iframe src="https://paiza.io/projects/e/g8vddH0JHpRLFkKP0AfphQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

