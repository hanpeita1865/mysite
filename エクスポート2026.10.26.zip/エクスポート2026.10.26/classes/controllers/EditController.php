<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
// use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MenuService,
    MarkdownService,
    LockService,
};
use HTMLPurifier;
use SocymSlim\SlimMiddle\Config\AppConfig;
use SocymSlim\SlimMiddle\Config\PageArea;



class EditController
{
    private EditService $editService;
    private FolderService $folderService;
    private MenuService $menuService;
    private MarkdownService $markdownService;
    private LockService $lockService;
    private HTMLPurifier $purifier;
    private AppConfig $config;


    public function __construct(EditService $editService, FolderService $folderService, MenuService $menuService, MarkdownService $markdownService, LockService $lockService, HTMLPurifier $purifier, AppConfig $config)
    {
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->menuService = $menuService;
        $this->markdownService = $markdownService;
        $this->lockService = $lockService;
        $this->purifier = $purifier;
        $this->config = $config;
    }
    
    

    //---------------------
    // マークダウン変換
    //---------------------

    public function markData(Request $request, Response $response, array $args): Response
    {
        
        $basePath = $this->config->basePath;
        $siteName = $this->config->siteName;
        $viewFlag = $request->getAttribute('viewFlag');
        $pageArea = $request->getAttribute('pageArea');
        $pageDir = PageArea::getPageDir($pageArea);

        
        try {
                       
            //URLデコード          
            $path = rawurldecode(
                rtrim($request->getUri()->getPath(), '/')
            );

            $params = $request->getAttribute('params');
            // print_r($params);
            $folderName = basename($params);
            // print_r($folderName);
                        
            $folderObj = $this->folderService->getFolderCompCached($pageDir);
            
            // print_r($folderObj);
            
            // error_log('$folderObj: ' . print_r($folderObj, true));//テスト
                     
            $searchMenu = $this->menuService->buildSearchMenu($pageDir);//サービス（検索カテゴリーリスト取得）
                        
            $json_searchMenu = json_encode($searchMenu, JSON_UNESCAPED_UNICODE);
            file_put_contents('../common/search/search_menu.json', $json_searchMenu);
                                                
            $menuData = $this->menuService->buildMenuCached($pageDir);//サービス（メニュー生成）
            
            $markData = $this->markdownService->getMarkdownData($folderObj, $folderName, $viewFlag);//サービス（マークダウン変換）
                        
            if (!$markData['success']) {
                $assign["errorMsg"] = $markData['message'];
                $templatePath = "error.twig";

                $twig = $this->editService->view();
                return $twig->render($response, $templatePath, $assign);
            }

            $htmlData = $markData['html'];
            // $title = $markData['title'];

                        
            $text = strip_tags($htmlData);
            $text = preg_replace('/\s+/u', '', $text);
                       
            $titlePathObj = $this->folderService->getTitlePathListCached();
            
            
            $updateDay = trim($markData['updateDay'] ?? '');

            $date = \DateTime::createFromFormat('Y-m-d', $updateDay);

            if ($date === false || $date->format('Y-m-d') !== $updateDay) {
                $updateDay = '';
            }
                
                
            $assign["isLogin"] = $request->getAttribute('isLogin');
            $assign["canView"] = $request->getAttribute('canView');
            $assign["canEdit"] = $request->getAttribute('canEdit');
            $assign["isAdmin"] = $request->getAttribute('isAdmin');
            $assign["isEditor"] = $request->getAttribute('isEditor');
            $assign["userName"] = $request->getAttribute('userName');
            $assign["isDraft"] = $request->getAttribute('isDraft');
                
            $assign["menuData"] = $menuData;
            $assign["folderObj"] = $folderObj;
            $assign["htmlData"] = $htmlData;
            // $assign["title"] = $title;
            $assign["title"] = $markData['title'];
            $assign["updateDay"] = $updateDay;
            $assign["titlePathObj"] = $titlePathObj;
            $templatePath = "base.twig";
            $assign["folderDir"] = $folderObj[$folderName] ?? null;
            $assign["folderName"] = $folderName;
            $assign['draftBadgeClass'] = $request->getAttribute('isDraft')
                    ? ($request->getAttribute('canEdit') ? 'success' : 'warning')
                    : null;
            
        }

        catch (PDOException $ex) {
            $assign["errorMsg"] = "データベース処理に失敗しました。もう一度始めからやり直してください。";
            $templatePath = "error.twig";
        }       

        $assign["pathBase"] = $basePath;
        $assign["siteName"] = $siteName;
        $assign["redirect"] = $path;
        $assign['pageArea'] = $pageArea;
        

        $twig = $this->editService->view();
                
        $response = $twig->render($response, $templatePath, $assign);
        
        return $response;
    }



    //---------------------
    // 編集画面
    //---------------------

    public function editData(Request $request, Response $response, array $args): Response
    {
        $basePath = $this->config->basePath;        
        
        //追加
        $pageArea = $request->getAttribute('pageArea');
        $pageDir = PageArea::getPageDir($pageArea);
        
        $data = $request->getQueryParams() ?? [];//Getの値を受け取り
        $redirect = $data['redirect'] ?? null;

        if ($redirect && str_starts_with($redirect, '/')) {
            $_SESSION['redirect_after_login'] = $redirect;
        }
        
        $pageUrlBase = PageArea::getUrlBase($pageArea, $basePath);

        $redirectUrl = $_SESSION['redirect_after_login']
            ?? $pageUrlBase . 'guide/';//会社では「about_wiki」にする。
        
        // $redirectUrl = $_SESSION['redirect_after_login'] ?? '/public/pages/guide/';
        

        try {
            $folderObj = $this->folderService->getFolderComp($pageDir);//サービス（フォルダオブジェクト）
            $folderDir = $folderObj[$data['folder']];
            

            $mkData = file_get_contents($folderDir . '/markdown.md');

            $twig = $this->editService->view();
            
            
            $folder = $data['folder'] ?? null;
            $filelist = $this->folderService->uploadList(null, $folder);

            $assign["pathBase"] = $basePath;
            $assign["mkData"] = $mkData;
            $assign["edit"] = $data['edit'];
            $assign["folder"] = $data['folder'];
            $assign["folderPath"] = $data['folderPath'];
            $assign["scroll"] = $data['scroll'];
            $assign["motourl"] = $redirectUrl;
            $assign["fileList"] = $filelist;
            $assign["folderDir"] = $folderDir;
            $assign["pageArea"] = $pageArea;//追加

            $response = $twig->render($response, "edit.twig", $assign);

        } catch (Exception $ex) {
            echo $ex->getMessage();
            // header('Location:'. $motourl); //遷移元かトップに戻る
            exit;
        }

        return $response;
    }




    //---------------------
    //  編集保存
    //---------------------

    public function markdownUpload(Request $request, Response $response, array $args): Response {
        
        $parsedBody = $request->getParsedBody();
        
        // error_log('$parsedBody: ' . print_r($parsedBody, true));

        
        $folderDir = $parsedBody['folderDir'] ?? null;
        
        $md = $parsedBody['report'] ?? null;
        $mode = $parsedBody['mode'] ?? 'edit';   
        
        if (!$folderDir || !$md) {
            return $this->json($response, [
                "success" => false,
                "message" => "パラメータが不正です"
            ], 200);
        }
        
        $filePath = $folderDir . '/markdown.md';//例: ../pages/042.aaa/markdown.md
        $dir = dirname($filePath);//例: ../pages/042.aaa
        
        // ディレクトリ存在チェック
        if (!is_dir($dir)) {
            return $this->json($response, [
                "success" => false,
                "message" => "保存先ディレクトリが存在しません"
            ], 200);
        }              
        
        // $text = $this->markdownService->convertToText($md);       
        $ArrayFolder = explode('/', $folderDir);
        
        $db = $this->editService->db();
        
        try {
            
            $db->beginTransaction();
            
            if($mode === 'edit'){
                
                $folder = end($ArrayFolder); // 例: 042.aaa
                $folderName = explode('.', $folder)[1] ?? '';
                
                $pageArea = $parsedBody['pageArea'] ?? PageArea::NORMAL;//追加

                // ▼ DB のテキストを更新

                $this->markdownService->updatePageText($db, $folderName, $md, $pageArea);
                // $this->markdownService->updatePageText($db, $folderName, $md);
            }
            
            // draftモード
            if ($mode === 'draft') {
                
                $folderName = end($ArrayFolder); // 例: aaa

                $sql = " UPDATE draft_list SET updated_at = NOW() WHERE folder_name = :folder_name ";

                $stmt = $db->prepare($sql);

                $result = $stmt->execute([
                    ':folder_name' => $folderName
                ]);

                if (!$result) {

                    throw new \RuntimeException(
                        '下書き更新日時の更新に失敗しました'
                    );
                }
            }
            
            // ファイル書き込み
            if (
                @file_put_contents($filePath, $md)
                === false
            ) {

                throw new \RuntimeException(
                    'ファイル書き込みに失敗しました'
                );
            }

            $db->commit();
            
            return $this->json($response, [
                "success" => true,
                "message" => "更新に成功しました"
            ], 200);

        } catch (\Throwable $e) {

            if (
                isset($db) &&
                $db->inTransaction()
            ) {

                $db->rollBack();
            }
            
            error_log($e->getMessage());


            return $this->json($response, [
                "success" => false,
                "message" => $e->getMessage()
            ], 500);
        }
    }


    

    //---------------------
    //  ファイル保存
    //---------------------

    public function fileSave(Request $request, Response $response, array $args): Response
    {
        $uploadedFiles = $request->getUploadedFiles();
        $parsedBody = $request->getParsedBody();
        $folderDir = rtrim($parsedBody['folderDir'] ?? '', '/');

        // ファイルがアップロードされていない場合
        if (empty($uploadedFiles['hoge'])) {
            return $response->withStatus(400)->write('No file uploaded');
        }

        $file = $uploadedFiles['hoge'];
        $uploadDir = $folderDir . '/' . 'upload';

        // アップロードフォルダがなければ作成
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // 保存先ファイル名
        $filePath = $uploadDir . '/' . basename($file->getClientFilename());
        $file->moveTo($filePath);

        // ファイル一覧を更新日順で取得
        $files = glob($uploadDir . '/*');
        usort($files, fn($a, $b) => filemtime($a) - filemtime($b));

        $thmbSrc = str_replace('../../', '../', $folderDir); // サムネイルパス調整

        // ファイルアイコン分類表
        $fileTypes = [
            'excel' => ['xlsx', 'xls', 'xlsm', 'xlsb', 'xltx', 'xltm', 'xlt', 'xml', 'xlam', 'xla', 'xlw', 'xlr'],
            'text'  => ['txt'],
            'word'  => ['doc', 'docm', 'docx', 'dot', 'dotx'],
            'ppt'   => ['pptx'],
            'zip'   => ['zip'],
            'pdf'   => ['pdf'],
            'image' => ['png', 'jpg', 'jpeg', 'gif', 'svg', 'svgz', 'webp']
        ];

        $html = '';
        foreach ($files as $item) {
            $fileName = basename($item);
            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $type = $this->detectFileType($ext, $fileTypes);

            if ($type === 'image') {
                $html .= <<<HTML
                <li class="photo-list">
                    <span class="filename">{$fileName}</span>
                    <img src="{$thmbSrc}/upload/{$fileName}" alt="">
                    <button class="fileDelete">削除</button>
                    <button class="fileInsert">挿入</button>
                </li>
                HTML;
            } else {
                $html .= <<<HTML
                <li>
                    <span class="filename file_icon {$type}-icon">{$fileName}</span>
                    <button class="fileDelete">削除</button>
                    <button class="fileInsert">挿入</button>
                </li>
                HTML;
            }
        }

        $response->getBody()->write($html);
        return $response;
    }

    /**
     * 拡張子からファイル種別を判定する
     */
    private function detectFileType(string $ext, array $map): string
    {
        foreach ($map as $type => $exts) {
            if (in_array($ext, $exts, true)) {
                return $type;
            }
        }
        return 'other';
    }

    

    //---------------------
    //  ファイル削除
    //---------------------
    
    public function fileDelete(Request $request, Response $response, array $args): Response
    {
        $parsedBody = $request->getParsedBody();
        $folderDir = rtrim($parsedBody['folderDir'] ?? '', '/');
        $fileName  = basename($parsedBody['item'] ?? '');

        if (empty($folderDir) || empty($fileName)) {
            return $response->withStatus(400)->write('Missing parameters');
        }

        // 削除対象ファイルのパスを作成
        $uploadDir = $folderDir . '/upload';
        $filePath = $uploadDir . '/' . $fileName;

        // ファイルが存在しなければエラー
        if (!file_exists($filePath)) {
            return $response->withStatus(404)->write('File not found');
        }

        // ファイル削除
        if (!unlink($filePath)) {
            return $response->withStatus(500)->write('Failed to delete file');
        }

        // 残りのファイル一覧を取得
        $files = glob($uploadDir . '/*');
        usort($files, fn($a, $b) => filemtime($a) - filemtime($b));

        $thmbSrc = str_replace('../../', '../', $folderDir); // サムネイルパス調整

        // ファイルアイコン分類表（fileSaveと共通）
        $fileTypes = [
            'excel' => ['xlsx', 'xls', 'xlsm', 'xlsb', 'xltx', 'xltm', 'xlt', 'xml', 'xlam', 'xla', 'xlw', 'xlr'],
            'text'  => ['txt'],
            'word'  => ['doc', 'docm', 'docx', 'dot', 'dotx'],
            'ppt'   => ['pptx'],
            'zip'   => ['zip'],
            'pdf'   => ['pdf'],
            'image' => ['png', 'jpg', 'jpeg', 'gif', 'svg', 'svgz', 'webp']
        ];

        // ファイル情報をJSON用に整形
        $fileList = [];
        foreach ($files as $item) {
            $name = basename($item);
            $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $type = $this->detectFileType($ext, $fileTypes);

            $fileList[] = [
                'name' => $name,
                'type' => $type,
                'url'  => $thmbSrc . '/upload/' . $name,
                'mtime' => date('Y-m-d H:i:s', filemtime($item))
            ];
        }

        // JSONとして返す（fileSaveと統一）
        $response->getBody()->write(json_encode([
            'message' => 'File deleted successfully',
            'files' => $fileList
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        return $response->withHeader('Content-Type', 'application/json');
    }

    
    

    public function helloWithContainer(Request $request, Response $response, array $args): Response
    {
        $db = $this->editService->db(); 
 
        $assign["name"] = "コンテーナ";
        $twig = $this->editService->view(); //viewサービス
        
        $response = $twig->render($response, "helloWithVals.html", $assign);
        return $response;
    }
    

    
    //------------------------------------------
    //  フォルダ名、ディレクトリ、パスのオブジェクト
    //------------------------------------------

    public function folderObjGet(Request $request, Response $response, array $args): Response
    {
        $basePath = $this->config->basePath;
        $params = $request->getQueryParams();
        $pageArea = $params['pageArea'] ?? PageArea::NORMAL;
        // $pageArea = $request->getAttribute('pageArea');
        $dir = PageArea::getPageDir($pageArea);
        
        $baseUrl = PageArea::getUrlBase($pageArea, $basePath);
        
        $folderObj = $this->folderService->getFolderPathComp($dir, $baseUrl);
        // $folderObj = $this->folderService->getFolderPathComp($dir, $basePath);

        $payload = json_encode($folderObj, JSON_UNESCAPED_UNICODE);
        $response->getBody()->write($payload);
        return $response
            ->withHeader('Content-Type', 'application/json');
    }
    
    
    //----------------------------
    //  タイトルとパスのオブジェクト
    //---------------------------- 

    public function titlePathObjGet(Request $request, Response $response, array $args): Response
    {
        $pageArea = $request->getAttribute('pageArea');
        $dir = PageArea::getPageDir($pageArea);
            
        $titlePathObj = $this->folderService->getTitlePathList($dir);
        // $titlePathObj = $this->folderService->getTitlePathList();
        
        $payload = json_encode($titlePathObj, JSON_UNESCAPED_UNICODE);
        $response->getBody()->write($payload);
        return $response
            ->withHeader('Content-Type', 'application/json');
    }
    

    //-------------------------
    //  jsonで返すヘルパ関数
    //-------------------------

    private function json(Response $response, array $data, int $status = 200): Response {
        $response->getBody()->write(json_encode($data));
        return $response->withHeader('Content-Type', 'application/json')
                        ->withStatus($status);
    }
    

    //---------------------
    //  検索用カテゴリー生成
    //---------------------

    public function searchMenu(Request $request, Response $response): Response {
        
        $pageArea = $request->getAttribute('pageArea');//追加
        $pageDir = PageArea::getPageDir($pageArea);//追加

        $searchMenu = $this->menuService->buildSearchMenu($pageDir);//引数追加
        // $searchMenu = $this->menuService->buildSearchMenu();

        $payload = json_encode($searchMenu, JSON_UNESCAPED_UNICODE);

        $response->getBody()->write($payload);
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    
    //----------------------------
    //  DBからロック一覧を取得
    //---------------------------- 

    public function lockListGet(Request $request, Response $response): Response {
        
        $lockList = [];

        // 未ログイン時だけ取得
        if (!isset($_SESSION['auth_user'])) {

            $lockList =
                $this->lockService->getLockList();
        }

        $response->getBody()->write(
            json_encode(
                $lockList,
                JSON_UNESCAPED_UNICODE
            )
        );

        return $response
            ->withHeader(
                'Content-Type',
                'application/json'
            );
    }    
    
    
}
