<?php
use Slim\Factory\AppFactory;

// $basePath = '/from_now_slim';
require '../admin/basepath.php';


require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/php/Parsedown.php");
require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/php/ParsedownExtra.php");

require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/vendor/autoload.php");
require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/containerSetups.php");
$app = AppFactory::create();
require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/bootstrappers.php");
require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/routes.php");


$app->run();



