import { u as useRoute, _ as __nuxt_component_0$1 } from './server.mjs';
import { mergeProps, unref, withCtx, createTextVNode, useSSRContext } from 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/vue/index.mjs';
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate, ssrRenderComponent } from 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/vue/server-renderer/index.mjs';
import { d as data } from './data.12335034.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/ohmyfetch/dist/node.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/ufo/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/hookable/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/unctx/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/vue-router/dist/vue-router.node.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/h3/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/defu/dist/defu.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/@vue/shared/index.js';
import './nitro-prerenderer.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/node-fetch-native/dist/polyfill.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/destr/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/radix3/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/unenv/runtime/fetch/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/scule/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/ohash/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/unstorage/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/unstorage/dist/drivers/fs.mjs';

const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const id = Number(route.params.id);
    const fishdata = data.find((res) => res.id === id);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container mt-5" }, _attrs))}><div class="card" style="${ssrRenderStyle({ "width": "18rem" })}"><div class="card-header">\u540D\u79F0\u3000${ssrInterpolate(unref(fishdata).name)}</div><ul class="list-group list-group-fishdata"><li class="list-group-item">\u751F\u606F\u5730\u3000${ssrInterpolate(unref(fishdata).place)}</li><li class="list-group-item">\u65EC\u3000${ssrInterpolate(unref(fishdata).season)}</li></ul></div>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/fishdata" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u623B\u308B`);
          } else {
            return [
              createTextVNode("\u623B\u308B")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/fishdata/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_.195387af.mjs.map
