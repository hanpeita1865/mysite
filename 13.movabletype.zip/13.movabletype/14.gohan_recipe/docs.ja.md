---
title: サンプルサイト「ごはんレシピ」
media_order: 'file_tree.jpg,constructtion_data_error.jpg,site_top_newlist_error.jpg,search.html.jpg,archive_category.jpg,archive_entry.jpg,template_management.png,category_management.jpg,custom_field_list.jpg'
taxonomy:
    category:
        - docs
---

ごはんレシピサイト（公式サイト）
<https://makanai.sixapart.jp/>

### 1. テーマサンプルをダウンロードする。  
[サンプルダウンロード(Movable Type 6　本格活用ガイドブック)  ](https://book.mynavi.jp/support/pc/4861/)


このページの「04_theme.zip（1.65MB）」をダウンロードします。  
解凍したフォルダ内の以下のファイルを本体のフォルダに格納してください。
![](file_tree.jpg)

### 2. 新規にサイトを作成する。

サイトを作成する時に、サイトテーマに「Six Apartのごはんレシピのテーマ」を選択する。
サイト作成ボタンを押した後、再構築を行う。

再構築が完了したら、サイトを表示させてください。  
そうすると、以下のようなメッセージが表示されます。  
（これの原因は調査中です。）

![](constructtion_data_error.jpg)

とりあえず、OKを押してサイトを確認してみます。
##　テンプレート

### テンプレート管理画面
![](template_management.png)


### インデックステンプレート
#### トップ画像
名前：index_top  
出力ファイル：index.html

##### プレビュー
![](site_top_newlist_error.jpg)

##### HTML
```
<mt:Unless name="compress" compress="2">
<mt:Include module="config">
<mt:Ignore>
==================================================
Template Name : index_top
Template Type : index / website
Required Vars : meta_title, og_type, og_url, og_image, og_description
==================================================
</mt:Ignore>

<mt:SetVars>
meta_title=<mt:WebsiteName>
og_type=blog
og_url=<mt:Var name="website_url">
og_image=/common/images/common/logo.png
og_description=<mt:WebsiteDescription remove_html="1" regex_replace="/\n/","">
</mt:SetVars>

<mt:Include module="mod_html_head">
<body id="topPage" class="headerBg">
<mt:Include module="mod_googletagmanager">
  <div class="wrapper">
<mt:Include module="mod_header_top">
<mt:Include module="mod_search">

    <div class="profileBlock">
      <div class="description"><p><mt:WebsiteDescription></p></div>
      <div class="prof">
      <div class="profPic"><img src="/common/images/common/makanai_sato_prof.png" alt="佐藤さん"></div>
        <div class="profTxt">
          <div class="profTitle">佐藤さんのプロフィール</div>
          <dl>
            <dt>佐藤さん</dt>
            <dd>シックス・アパート株式会社勤務。シェフではなくエンジニア。弁当男子社員として、NHK「サラメシ」で取り上げられた経験を持つ、社内一の料理男子。まかないごはんのために、「ごはん」を美味しく食べられるメニューを日々研究中。愛読誌は『dancyu』。</dd>
          </dl>
        </div>
      </div>
    </div>

    <h3 class="h3_title">新着一覧</h3>

    <div id="entries" class="listWrapper">
      <mt:Entries lastn="$limit_count">

      <div class="list">
        <mt:Unless name="compress" compress="3">
        <div class="thum">
          <a href="<mt:EntryPermalink>">
            <mt:ImgThumbnailAsset>
            <img src="<mt:AssetThumbnailURL width="220" square="1">" alt="">
            </mt:ImgThumbnailAsset>
            <div class="listDescription">
              <span class="listDescriptionTxt"><mt:EntryTitle escape="html"></span>
            </div>
          </a>
```


### 検索ページ

検索	search.html

※「データの取得に失敗しました: オブジェクトのロード中にエラーが発生しました。」のメッセージが表示される。

![](search.html.jpg)


#### HTML
```
<mt:Unless name="compress" compress="2">
<mt:Include module="config">
<mt:Ignore>
==================================================
Template Name : search
Template Type : index / website
Required Vars : meta_title, og_type, og_url, og_image, og_description
==================================================
</mt:Ignore>

<mt:SetVars>
meta_title=検索結果 | <mt:WebsiteName>
og_type=blog
og_url=<mt:Var name="website_url">
og_image=/common/images/common/logo.png
og_description=<mt:WebsiteDescription remove_html="1" regex_replace="/\n/","">
</mt:SetVars>

<mt:Include module="mod_html_head">
<body id="topPage" class="headerBg">
<mt:Include module="mod_googletagmanager">
  <div class="wrapper">
<mt:Include module="mod_header">
<mt:Include module="mod_search">

    <h3 id="pageTitle" class="h3_title">検索結果</h3>

    <div id="entries" class="listWrapper">
      <div id="resultMsg"  class="detailDescription"></div>
      <div id="loadingImg" class="loding" style="display:none;"><img src="<mt:Var name="website_url">common/images/common/loding.gif" alt=""></div>
    </div>

  </div>
  <input type="hidden" name="searchEnable" value="true">
<mt:Include module="mod_script" data_api="1" top="1">
</body>
</html></mt:Unless>
```



### アーカイブテンプレート

名前：archive_category	  
出力ファイル名：category/sub_category/index.html


##### プレビュー
![](archive_category.jpg)


##### HTML
```
<mt:Unless name="compress" compress="2">
<mt:Include module="config">
<mt:Ignore>
==================================================
Template Name : archive_category
Template Type : archive_category / website
Required Vars : meta_title, og_url, og_image, og_description, limit, category_count
==================================================
</mt:Ignore>

<mt:SetVars>
meta_title=<mt:CategoryLabel> | <mt:WebsiteName>
og_url=<mt:CategoryArchiveLink>
og_image=/common/images/common/logo.png
og_description=<mt:CategoryLabel>
limit=8
category_count=<mt:CategoryCount>
</mt:SetVars>

<mt:Include module="mod_html_head">
<body id="topPage" class="headerBg">
<mt:Include module="mod_googletagmanager">
  <div class="wrapper">
<mt:Include module="mod_header">
<mt:Include module="mod_search">

    <h3 class="h3_title"><mt:CategoryLabel>一覧</h3>

    <div id="entries" class="listWrapper">
      <mt:Entries lastn="$limit_count">

      <div class="list">
        <mt:Unless name="compress" compress="3">
        <div class="thum">
          <a href="<mt:EntryPermalink>">
            <mt:ImgThumbnailAsset>
            <img src="<mt:AssetThumbnailURL width="220" square="1">" alt="">
            </mt:ImgThumbnailAsset>
            <div class="listDescription">
              <span class="listDescriptionTxt"><mt:EntryTitle escape="html"></span>
            </div>
          </a>
        </div>
        </mt:Unless>
        <mt:EntryPrimaryCategory><p class="listCategory<mt:If tag="CategoryColor"> <mt:CategoryColor></mt:If>"><a href="/<mt:CategoryBasename>/"><mt:CategoryLabel></a></p></mt:EntryPrimaryCategory>
      </div>
      </mt:Entries>

      <mt:Ignore>==========<div id="loadingImg" class="loding" style="display:none;"><img src="<mt:Var name="website_url">common/images/common/loding.gif" alt=""></div>==========</mt:Ignore>
    </div>

  </div>
  <mt:If name="category_count" gt="$limit">
    <input type="hidden" name="category" class="params" value="<mt:CategoryLabel>">
  <mt:Else>
    <input type="hidden" name="bottomLoad" value="false">
  </mt:If>
<mt:Include module="mod_script" data_api="1" top="1">
</body>
</html></mt:Unless>
```


名前：archive_entry	
出力ファイル：archive/%f

##### プレビュー
![](archive_entry.jpg)

##### HTML
```
<mt:Unless name="compress" compress="2">
<mt:Include module="config">
<mt:Ignore>
==================================================
Template Name : archive_entry
Template Type : archive_entry / website
Required Vars : meta_title, og_type, og_url, og_image, og_description
==================================================
</mt:Ignore>

<mt:SetVars>
meta_title=<mt:EntryTitle escape="html"> | <mt:WebsiteName>
og_type=article
og_url=<mt:EntryPermalink>
og_image=<mt:ImgThumbnailAsset><mt:AssetThumbnailURL width="400" square="1"></mt:ImgThumbnailAsset>
og_description=<mt:EntryExcerpt remove="html" regex_replace="/\n/",""/>
</mt:SetVars>

<mt:Include module="mod_html_head">
<body id="entryPage" class="headerBg">
<mt:Include module="mod_googletagmanager">
  <div class="wrapper">
<mt:Include module="mod_header">
<mt:Include module="mod_search">

    <div class="detailWrapper">

      <ul class="categoryList">
        <mt:EntryCategories compless="3">
        <li class="<mt:CategoryColor>">
          <a href="<mt:CategoryArchiveLink>"><mt:CategoryLabel></a>
        </li>
        </mt:EntryCategories>
        <mt:EntryTags compless="3">
        <li>
        <a href="<mt:Var name="website_url">search.html?tag=<mt:TagLabel>"><mt:TagLabel></a>
        </li>
        </mt:EntryTags>
      </ul>

      <h3 class="mainTitle"><mt:EntryTitle escape="html"></h3>
      <div class="detail">
        <div class="mainImg"><mt:ImgMainAsset><img src="<mt:AssetURL>" alt=""></mt:ImgMainAsset></div>
        <div class="detailDescription"><mt:EntryExcerpt convert_breaks="1"></div>

        <div class="detailInner">
          <mt:If tag="txtingredient">
          <h4>材料</h4>
          <mt:txtingredient split="\n" setvar="ingredient">
          <mt:SetVar name="ul_cond" value="close">
          <mt:Loop name="ingredient">
            <mt:If name="__value__" like="^・">
              <mt:If name="ul_cond" eq="close">
              <ul class="detailUL">
              </mt:If>
              <li>　<mt:Var name="__value__" regex_replace="/^・/",""></li>
              <mt:SetVar name="ul_cond" value="open">
            <mt:Else>
              <mt:If name="ul_cond" eq="open">
              </ul>
              </mt:If>
              <p class="mb5"><mt:Var name="__value__"></p>
            </mt:If>
          </mt:Loop>
          <mt:If name="ul_cond" eq="open">
          </ul>
          </mt:If>
          </mt:If>

          <mt:If tag="txttime">
          <h4>所要時間</h4>
          <mt:txttime convert_breaks="1">
          </mt:If>

          <h4>難易度</h4>
          <mt:SetVar name="stars[1]" value="★☆☆☆☆">
          <mt:SetVar name="stars[2]" value="★★☆☆☆">
          <mt:SetVar name="stars[3]" value="★★★☆☆">
          <mt:SetVar name="stars[4]" value="★★★★☆">
          <mt:SetVar name="stars[5]" value="★★★★★">
          <mt:txtlevel setvar="levelcount">
          <p><mt:Var name="stars[$levelcount]"></p>

          <mt:EntryBody>

        </div>

      <!-- X:S ZenBackWidget --><script type="text/javascript">document.write(unescape("%3Cscript")+" src='http://widget.zenback.jp/?base_uri=http%3A//makanai.sixapart.jp/&nsid=104305259689578195%3A%3A115687743631152774&rand="+Math.ceil((new Date()*1)*Math.random())+"' type='text/javascript'"+unescape("%3E%3C/script%3E"));</script><!-- X:E ZenBackWidget -->

      </div>
      <div class="backBtn"><a href="<mt:Var name="website_url">">トップへ戻る</a></div>
    </div>
  </div>
<mt:Include module="mod_script">
</body>
</html></mt:Unless>
```


## カテゴリー

##### 管理画面
![](category_management.jpg)

## カスタムフィールド

##### 管理画面
![](custom_field_list.jpg)




