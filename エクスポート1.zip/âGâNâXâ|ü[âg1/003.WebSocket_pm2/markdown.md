*[page-title]:PM2

参考サイト
: [node.js のアプリを永続化(デーモン化)](https://blitzgate.co.jp/blog/2569/)

サーバーのSSHが終了するとプログラムも停止してしまいます。
そこで node.js を永続化させる方法についてです。  

多分サービスに登録することだと思います。・・・

今回は「<span class="green bold marker-yellow50"> pm2</span>」 というモジュールを使い、node.js をデーモン化していきます。  
これは通常のデーモン化ではなく、<span class="marker-yellow50">pm2のサービスとして起動させる</span>ものです。

## 設定

まずはインストールしていきます。

<p class="tmp cmd"><span>コマンド</span>PM2インストール</p>
```
npm install pm2 -g
```
![](upload/pm2インストール.png)

この時、プロジェクトに追加するのではなく、システムとして稼働させるため 「<span class="red">-g</span>」 をつけることを忘れないでください。  
また、インストールは必ず node.js のファイルを実行させるユーザーで行ってください。  
さらに、このままでも機能するのですが、実運用を考えてログファイルをローテートさせる機能もインストールします。

<p class="tmp cmd"><span>コマンド</span>ローテート機能インストール</p>
```
pm2 install pm2-logrotate
```
![](upload/ローテート機能インストール1.png)
・・・省略・・・
![](upload/ローテート機能インストール2.png)

続いて、デーモン化させるための設定ファイル(service.json)をnode.jsのプロジェクト内に作成します。
（内容は適宜読み替えてください）

<p class="tmp list"><span>リスト</span>server_io2/service.json</p>
```
{
    "name" : "server_io2",
    "script" : "/xampp/htdocs/server_io2/server.js",
    "log-date-format": "YYYY-MM-DD HH:mm:ss Z",
    "env" : {
        "NODE_ENV" : "production"
    },
    "env_development" : {
        "NODE_ENV" : "development"
    }
}
```

## サービス実行

起動ファイルが作成できたら、サービスを起動するコマンドを実行します。

```
# 本番用
pm2 start /xampp/htdocs/server_io2/service.json

# 開発用
pm2 start /xampp/htdocs/server_io2/service.json --env development
```
開発用を実行してみます。
![](upload/サービス起動.png)

「<http://localhost:3001/>」にアクセスし、無事に表示できてました。
![](upload/localhost3001.png){.photo-border}

リアルタイム更新もちゃんと動作できてます。
![](upload/localhost3001リアルタイム更新.png){.photo-border}


## 再起動する・停止する

pm2 のサービスを再起動するには、下記のコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>再起動</p>
```
pm2 restart [id または name または namespace]
```

そして pm2 のサービスを停止するには、下記のコマンドを実行します。
```
pm2 stop [id または name または namespace]
```
![](upload/pm2サービス停止.png)

サービスを再起動/停止するには、そのサービスを指定する必要があります。


## 一覧表示
pm2 のサービス一覧を見るには、下記のコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>サービス一覧表示</p>
```
pm2 ls
```

## ログを確認する
pm2 で利用しているプログラムのログを確認するには、下記のコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span></p>
```
pm2 logs (id または name または namespace)
```

また、pm2自体のログを確認する場合は、idなどをつけずに使用することで確認できます。

 