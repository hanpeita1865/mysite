---
title: '11. ミドルウェア'
media_order: 'middle_ware01.png,middle_ware02.png,middle_ware03.png,middle_ware04.png,middle_ware05.png,middle_ware05.png'
taxonomy:
    category:
        - docs
---

* [ミドルウェアとは?](#p1)
* [HelloMiddlewareクラス](#p2)
* [Hello Middlewareを修正する](#p3)
* [ミドルウェアの実行](#p4)
* [ビューとコントローラの修正](#p5)
* [リクエストとレスポンスの流れ](#p6)
* [レスポンスを操作する](#p7)
* [グローバルミドルウェア](#p8)
* [ミドルウェアのグループ登録](#p9)

ミドルウェアは、リクエストを受け取るとコントローラ処理の前後に割り込み、独自の処理を追加する仕組みです。このミドルウェアの使い方と開発の方法を覚え、独自のミドルウェアを作成できるようになりましょう。

## ミドルウェアとは? ##{#p1}
MVCアーキテクチャーは、モデル・ビュー・コントローラがそれぞれ切り離されています。プログラムの基本部分はコントローラですが、コントローラはそれぞれのアクションごとに処理を用意していきます。これは、個別に処理を作れるという点はよいのです が、「すべてのアクセス時に何かを処理しておく」ということになるとけっこう面倒臭いものになってしまいます。  
例えば、フォームに入力された値をチェックするような仕組みを考えてみましょう。 フォームをPOST送信したときのアクションで、送られた値を1つずつチェックすることは可能です。が、フォームのあるページが1つでなかったら? 10ページ、あるいは 100ページもあったらどうするのでしょう。全てに1つ1つの値をチェックする処理を書いていくのは、あまり効率的なやり方とは思えませんね。  
そこでLaravelでは、コントローラとは別に、「*指定のアドレスにリクエストが送られてきたら、自動的に何らの処理を行う*」という仕組みを用意したのです。それが「***ミドル ウェア***」です。

### ミドルウェアはアプリケーションの前にあるレイヤー
ミドルウェアとは、リクエストがコントローラのアクションに届く前(または後)に配置されるレイヤー層となるプログラムです。  
特定のアドレスにアクセスがあると、Laravelはルート情報を元に指定のコントローラ のアクションを呼び出します。ミドルウェアは、その前に割り込んで、アクションの処 理が実行される前(あるいは、後)に、指定の処理を実行させることができます。  
ミドルウェアの設定は、ルート情報を記述する際に指定できます。コントローラのアクションで処理を呼び出しているわけではありません。コントローラと完全に分離しているため、コントローラで行っている処理の内容には左右されません。

![](middle_ware01.png?classes=caption "図　ミドルウェアは、リクエストがアクションに届く前や後に割り込んで処理を実行する。")


### ミドルウェアを作成する
では、実際にミドルウェアを作成してみましょう。ミドルウェアは、手作業でスクリプトファイルを作成すれば作れますが、例によってArtisanコマンドを使えばもっと快適 に作成することができます。  
簡単なサンプルとして「HelloMiddleware」という名前で作ってみることにしましょう。 コマンドプロンプトまたはターミナルを起動し、コマンドを入力します。
```
php artisan make:middleware HelloMiddleware
```
ミドルウェアの作成は、「**aritisan make:middlewae ミドルウェア名**」という形で実行します。ここではHelloMiddlewareという名前で作成をしました。

### HelloMiddleware.php を確認する
ミドルウェアは、「Http」内にある「Middleware」というフォルダの中に作成されます。 このフォルダには、既に標準でいくつかのミドルウェアが入っています。ここに、作成したHelloMiddleware.phpも作成されています。

![](middle_ware02.png?classes=caption "図　「Middleware」フォルダの中身。いくつかのミドルウェアが用意されている。HelloMiddleware. phpもここに作成される。")

では、このMiddleware.phpを開いてみましょう。すると中には以下のようなスクリプトが記述されています(※コメントは省略してあります)。

<p class="tmp list"><span>リスト1</span>Middleware.php</p>
```
<?php

namespace App\Http\Middleware;

use Closure;

class HelloMiddleware
{
   public function handle($request, Closure $next)
   {
       return $next($request);
   }
}
```

## HelloMiddlewareクラス ##{#p2}
作成されたHelloMiddlewareは、特に何かのクラスを継承しているわけでもない、比較的シンプルなクラスです。ソースコードを見ると、以下のように書かれています。  
```
namespace App\Http\Middleware;
```
「app」内の「Http」フォルダ内にある「Middleware」フォルダの中にスクリプトファイルは置かれます。namespaceを指定しておかないと正しくクラスが利用できないので注意しましょう。

### handle メソッドについて
このHelloMidlewareクラスには、1つだけメソッドが用意されています。「handle」と いうもので、以下のように定義されます。
```
public function handle($request, Closure $next)
{
...... 実行する処理 ......
}
```
第1引数の$requestは、リクエストの情報を管理するRequestインスタンスが渡されます。そして$nextは、Closureクラスのインスタンスです。これは無名クラスを表すため のクラスです。ここで渡された$nextはクロージャになっており、これを呼び出して実行することでミドルウェアからアプリケーションへと送られるリクエスト(Requestイン スタンス)を作成することができます。

## Hello Middlewareを修正する ##{#p3}
では、実際に簡単な処理を作成してみましょう。HelloMiddlewareクラスのソースコードを以下のように修正して下さい(namespace、useは省略してあります)。

<p class="tmp list"><span>リスト2</span></p>
```
class HelloMiddleware
{
   public function handle($request, Closure $next)
   {
       $data = [
           ['name'=>'taro', 'mail'=>'taro@yamada'],
           ['name'=>'hanako', 'mail'=>'hanako@flower'],
           ['name'=>'sachiko', 'mail'=>'sachico@happy'],
       ];
       $request->merge(['data'=>$data]);
       return $next($request);
   }
}

※ミドルウェア記述後、
/app/Http/Kernel.php 内の$routeMiddleware 配列内に以下の文を追記。

'hello' => \App\Http\Middleware\HelloMiddleware::class,
```

ここでは、handleメソッド内で「merge」というメソッドを呼び出しています。これは 以下のように利用します。
<p class="tmp"><span>書式1</span></p>
```
$request->merge( 配列 );
```
このmergeは、フォームの送信などで送られる値(inputの値)に新たな値を追加するものです。これにより、dataという項目で$dataの内容が追加されます。コントローラ側では、$request->dataでこの値を取り出すことができるようになります。  
記述したら、HelloMiddlewareを登録します。「app」内の「Http」内にあるKernel.phpを 開き、$routeMiddlewareに代入している変数内に以下の文を追加して下さい。

<p class="tmp list"><span>リスト2-1</span></p>
```
'hello' =>\App\Http\Middleware\HelloMiddleware::class,
```
これでHelloMiddlewareが登録され、利用可能になります。

## ミドルウェアの実行 ##{#p4}
作成されたミドルウェアは、それだけではまだ利用することはできません。これを使うには、「*利用するミドルウェアを呼び出す処理*」の追記が必要になります。これは、ルーティングの際に実行するのが一般的です。  
web.phpを開き、ルート情報にミドルウェアの呼び出し処理を追記しましょう。 Route::getで/helloのルート情報を設定している文を以下のように変更して下さい。

<p class="tmp list"><span>リスト3</span>routes/web.php</p>
```
// use App\Http\Middleware\HelloMiddleware;　を先頭の方に追記

Route::get('hello', 'HelloController@index')
   ->middleware(HelloMiddleware::class);
```

ミドルウェアを利用する場合は、Rouge::getの後にメソッドチェーンを使って 「middleware」メソッドを追加します。引数には、利用するミドルウェアクラスを指定します。  
このmiddlewareメソッドは、そのままメソッドチェーンとして連続して記述することができます。複数のメソッドチェーンを利用したい場合は、
```
Route::get(.....)->middleware(.....)->middleware(.....);
```
このように middlewareを連続して記述していくことができます。

## ビューとコントローラの修正 ##{#p5}
これでミドルウェアHelloMiddlewareが/helloで動作するようになりました。では、ミドルウェアで組み込まれる変数$dataが正しく動いているか、ビューとコントローラを 修正して確認しましょう。  
まずは、コントローラの修正です。HelloControllerクラスのindexアクションメソッド を以下のように修正して下さい。
<p class="tmp list"><span>リスト4</span>app\Http\Controllers\HelloController.php</p>
```
public function index(Request $request)
{
   return view('hello.index', ['data'=>$request->data]);
}
```
続いて、テンプレートの修正です。index.blade.phpに記述してある@section('content') ディレクティブを以下のように修正しましょう。
<p class="tmp list"><span>リスト5</span>resources\views\hello\index.blade.php</p>
```
@section('content')
   <p>ここが本文のコンテンツです。</p>
   <table>
   @foreach($data as $item)
   <tr><th>{{$item['name']}}</th><td>{{$item['mail']}}</td></tr>
   @endforeach
   </table>
@endsection
```
これで、ミドルウェアで追加されたデータが表示されるようになります。実際に /helloにアクセスして表示を確認して下さい。テーブルにデータがまとめられて表示されます。

![](middle_ware03.png?classes=caption "図　 /helloにアクセスすると、$dataのデータがテーブルで表示される。")


ここでは、コントローラのアクションメソッドでviewの引数に['data'=>$request ->data]という形で$request->dataの値を設定しておき、テンプレート側で@foreachを使 い、その内容を出力させています。配列データの表示がわかれば、特に説明するまでもないでしょう。  
ここでは配列としてデータを持たせていますが、この先、データベースを本格的に利用するようになると、ミドルウェアを使って事前に必要なデータを処理したりできるため、コントローラの負担がずいぶんと軽くなります。

## リクエストとレスポンスの流れ ##{#p6}
今回、サンプルとして作ったHelloMiddlewareは、リクエストがあったら処理を実行し、それからコントローラのアクションが呼び出されていました。が、実はミドルウェアは、 「アクション後の処理」も作成することができます。  
これには、ミドルウェアのhandleメソッドの引数として渡されるクロージャと、メソッドの返値の働きをよく理解しておかなければいけません。 handleでは、デフォルトでこのように処理が用意されていました。
```
public function handle($request, Closure $next)
{
	return $next($request);
}
```
引数として$requestが渡され、そして一緒に渡されたクロージャの戻り値がreturnで 返されていました。この$nextで返されるのは一体、何なのでしょうか?   
実は、「レス ポンス(Response)」インスタンスなのです。

リクエストが送られてきてからクライアントにレスポンスが返されるまでの流れを整理すると、以下のようになります。

1. リクエストが送られる。 
2. ミドルウェアのhandleが呼び出される。
3. $nextを実行する。これは、複数のミドルウェアが設定されている場合は、次の ミドルウェアのhandleが呼び出される。他にミドルウェアがない場合は、コントローラにあるアクションが呼び出される。
4. アクションメソッドが終わると共にページがレンダリングされ、レスポンスが生成される。この生成されたレスポンスが、$nextの戻り値として返される。
5. 返されたレスポンスが、returnとして返され、これがクライアントへ返送される。

![](middle_ware04.png?classes=caption "図 クライアントからリクエストが送られると、ミドルウェアが受け取り、$nextでコントローラの アクションが呼び出される。その結果としてレスポンスが返され、これをreturnしたものがクライアントに戻される。")

### 前処理と後処理
この流れを理解すれば、コントローラの前に実行するミドルウェアと、後で実行する ミドルウェアの作成方法がわかってきます。

■前処理
: コントローラの前に実行する処理は、先ほど作成しました。これは、必要な処理をすべて実行してから$nextを実行し、それをreturnします。

<p class="tmp"><span>書式2</span></p>
```
public function handle($request, Closure $next)
{
    ......処理を実行する...... 
    return $next($request);
}
```
■後処理 
: コントローラの後に実行する処理は、$nextを実行してレスポンスを受け取ってから、 必要な処理を実行していきます。そして処理が終わったところで、保管してあったレスポンスをreturnします。

<p class="tmp"><span>書式3</span></p>
```
public function handle($request, Closure $next)
{
    $response = $next($request) 
    ......処理を実行する..... 
    return $response;
}
```
このように、handleメソッドの実装の仕方を少し変えることで、コントローラの前処理・後処理を作成できます。

## レスポンスを操作する ##{#p7}
では、先ほどコントローラの前に実行される例を挙げましたから、今度はコントローラの呼び出し後に実行されるミドルウェアのサンプルを作ってみることにしましょう。  
新たにミドルウェアを作ってもいいのですが、今回は先ほどのHelloMiddleware.php を書き換えて利用することにします。HelloMiddlewareクラスを以下のように修正して下さい。
<p class="tmp list"><span>リスト6</span>HelloMiddleware.php</p>
```
class HelloMiddleware
{
   public function handle($request, Closure $next)
   {
       $response = $next($request);
       $content = $response->content();

       $pattern = '/<middleware>(.*)<\/middleware>/i';
       $replace = '<a href="http://$1">$1</a>';
       $content = preg_replace($pattern, $replace, $content);

       $response->setContent($content);
       return $response;
   }
}
```

ここでは、レスポンスから、クライアントに返送されるコンテンツを取り出し、その 一部を置換して返送しています。

### 処理の流れ
では、handleメソッドで行っている処理を見ていきましょう。まず最初に$nextを実行し、結果を$responseに代入します。
```
$response = $next($request);
```
これで、コントローラのアクションが実行され、その結果のレスポンスが変数 $responseに収められます。このレスポンスを使って処理を行います。 まず、レスポンスから返送されるコンテンツを取得します。
```
$content = $response->content();
```
$responseのcontentメソッドで、レスポンスに設定されているコンテンツが取得できます。これは、送り返されるHTMLソースコードのテキストが入っています。ここから、 <middleawre>というタグを正規表現で置換します。
```
$pattern = '/<middleware>(.*)<V/middleware>/i'; 
$replace = '<a href="http://$1">$1</a>'; 
$content = preg_replace($pattern, $replace, $content);
```
これは、<middleware> ○ ○</middleware>というテキストを、<a href="http://〇〇">〇〇</a>というテキストに置換する処理です。これにより、<middleware>というタグにドメイン名を書いておけば、そのドメインにアクセスするためのリンクが自動生成されるようになります。 後は、レスポンスにコンテンツを設定し、returnするだけです。
```
$response->setContent($content); 
return $response;
```
レスポンスへのコンテンツ設定は、**setContent**というメソッドを使います。これでクライアントに返送されるコンテンツが変更されました。後は、レスポンスをreturnすれば作業終了です。

### ビューとコントローラの修正
では、この新しいミドルウェアを使ってみましょう。まず、テンプレートの修正です。 index.blade.phpの@section('content)ディレクティブを以下のように修正しましょう。
<p class="tmp list"><span>リスト7</span> index.blade.php</p>
```
@section('content')
   <p>ここが本文のコンテンツです。</p>
   <p>これは、<middleware>google.com</middleware>へのリンクです。</p>
   <p>これは、<middleware>yahoo.co.jp</middleware>へのリンクです。</p>
@endsection
```
今回は、サンプルとして2つの<middleware>タグを用意しておきました。google.com とyahoo.co.jpを値に設定してあります。  
後はコントローラの修正ですね。HelloControllerクラスのindexアクションメソッドを 以下のように変更しておきます。
    
<p class="tmp list"><span>リスト8</span>HelloController.php</p>
```
public function index(Request $request)
{
   return view('hello.index');
}
```
今回、コントローラ側では何も処理はしていません。値も特に設定してはおらず、ほぼデフォルトの状態でページを表示しているだけです。  
では、修正が完了したら/helloにアクセスしてみましょう。すると、&lt;middleware&gt;タグの部分が、&lt;a&gt;タグのリンクに変更されているのがわかります。

![](middle_ware05.png?classes=caption "図　/helloにアクセスすると、<middleware>タグが<a>タグのリンクに変換されている。")
    
<http://localhost:9111/hello>

## グローバルミドルウェア ##{#p8}
ミドルウェアの基本的なコーディングがわかったところで、登録について改めて目を向けてみましょう。先ほどは、ルート情報を設定するところでmiddlewareメソッドを呼 び出してミドルウェアを実行していました。このように、特定のアクセスにのみミドル ウェアを割り当てる場合は、1つ1つのルートに追記をしていきます。  
が、例えば「すべてのアクセスで自動的にミドルウェアが実行されるようにしたい」という場合は、1つ1つのルートに追記をしていくのでは埒が明きません。 このような場合は、「グローバルミドルウェア」と呼ばれる機能を使います。これはすべてのリクエストで利用可能となるものです。
    
### グローバルミドルウェアの登録
ミドルウェアの登録は、「**Http**」フォルダ内にある「**Kernel.php**」というスクリプトファイルを利用します。  
このファイルを開くと、その中に以下のような部分が見つかります。これが、グローバルミドルウェアの登録を行っているところです。
    
<p class="tmp list"><span>リスト9</span>app\Http\Kernel.php</p>
```
protected $middleware = [
       \Illuminate\……略……\CheckForMaintenanceMode::class,
       \Illuminate\……略……\ValidatePostSize::class,
       ……以下略……
];
```
    
グローバルミドルウェアは、Kernelクラスの$middlewareという変数の中に配列としてまとめられています。 では、$middlewareの配列を閉じる **]** 記号の前を改行し、以下の文を追記して下さい。
<p class="tmp list"><span>リスト10</span>app\Http\Kernel.php</p>
```
\App\Http\Middleware\HelloMiddleware::class,
```
これで、HelloMiddlewareがグローバルミドルウェアとして登録されます。グローバルミドルウェアとして登録すると、個々のミドルウェアの呼び出し処理は不要になりま
す。  
先に記述した、Route:getのmiddlewareメソッドを削除しましょう。web.phpの以下の部分ですね。
##### rotes/web.php
```
Route::get('hello', 'HelloControlleraindex')
	->middleware(HelloMiddleware::class);
```
　　↓　後ろの「;」を忘れず付ける。
```
Route::get('hello', 'HelloControlleraindex');
```

これで、middlewareの呼び出し処理はなくなりました。/helloにアクセスすると、ミドルウェアが呼び出されなければ、先ほどのリンクの作成機能は動作しなくなるはずで す。が、middlewareメソッドは呼び出していないのに、きちんとリンクが生成されています。グローバルミドルウェアに登録したことで、どこにアクセスしても常にミドルウェアが実行されるようになっているのです。

## ミドルウェアのグループ登録 ##{#p9}
    
多数のミドルウェアを使うようになると、複数のミドルウェアを一つにまとめて扱えるようにできれば管理が楽になります。  
ミドルウェアには、グループ化して登録するための仕組みも用意されています。これは、Kernel.phpの「$middlewareGroups」という変数として用意されています。この変数 には、以下のような形で値が設定されています。
    
<p class="tmp list"><span>リスト11</span>Kernel.php</p>
```
protected $middlewareGroups = [
   'web' => [
       ……ミドルウェアクラス……
   ],

   'api' => [
       ……ミドルウェアクラス……
   ],
];
```
$middlewareGroups内には、**'web'**と**'api'** という項目があり、その中にミドルウェアのクラスがまとめられています。この'web'や'api'がグループです。  $middlewareGroups では、このようにグループ名をキーとする値を用意し、そこにミドルウェアの配列を設定しています。こうすることで、その名前のグループで使われるミドルウェアが指定できます。
    
ここでは、webとapiというグループが用意されていますが、これらはルーティング情報を設定するところでmiddlewareメソッドを使って指定することができます。
    
### グループを利用する
では、実際に簡単なグループを作って利用してみましょう。まず、グループの登録を行います。Kernel.phpの$middlewareGroupsの配列を閉じる]記号の手前を改行し、以下 の文を追記しておきましょう。

<p class="tmp list"><span>リスト12</span>Kernel.php</p>
```
'helo' => [
   \App\Http\Middleware\HelloMiddleware::class,
],
```
グループ化ですから複数のミドルウェアクラスを指定するのが一般的ですが、今回はとりあえずHelloMiddlewareクラス1つだけのグループ" helo'を用意してみました。なお、 先に$middlewareに登録しておいたHelloMiddlewareクラスの指定は削除しておいて下さい。  
続いて、web.phpを開き、/helloのルート情報を以下のように修正します。
    
<p class="tmp list"><span>リスト13</span>web.php</p>
```
Route::get('hello', 'HelloController@index')
   ->middleware('helo');
```
これで、/helloにheloグループが設定されます。/helloにアクセスした際には、heloグループに登録してあるすべてのミドルウェアが実行されます。  
とりあえず、
1. ***個々のルーティング情報への登録***
2. ***グローバルミドルウェアの登録***
3. ***グループの登録***

この3つの登録方法がわかれば、ミドルウェアの利用はマスターできた といってよいでしょう。

    
    
    
    

