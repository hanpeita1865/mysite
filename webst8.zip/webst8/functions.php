<?php
// function webst8_setup()
// {
//    //ここに関数の中身を記述します。
//    add_theme_support('post-thumbnails'); //アイキャッチ画像をON
//    add_theme_support('menus');  //メニュー機能をON
// }
// add_action('after_setup_theme', 'webst8_setup'); //after_setup_themeアクションフック※に登録します。


// // カスタム投稿タイプの追加
// add_action('init', 'create_post_type');

// function create_post_type()
// {
//    register_post_type(
//       'news', // 投稿タイプ名の定義
//       array(
//          'labels' => array(
//             'name' => __('更新情報'), // 表示する投稿タイプ名
//             'singular_name' => __('更新情報')
//          ),
//          'public' => true,
//          'menu_position' => 5,
//          'show_in_rest' => true,
//          'has_archive' => true
//       )
//    );
// }

function add_news()
{
	$name = "ニュース";

	$labels = [
		'name' => $name,
		'manu_name' => $name,
		'all_items' => $name . '一覧',
		'add_new' => $name . '追加',
		'singular_name' => $name,
		'not_found' => $name . 'は見つかりませんでした'
	];

	$args = [
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,//静的URLで一覧ページを表示
		'menu_position' => 5,
		'show_in_rest' => true,//グーテンベルグ使用
	];

	register_post_type('news', $args);
}
add_action('init', 'add_news');


//デフォルトの投稿をブログに変更
function change_menu()
{
	global $menu;
	global $submenu;

	$name = 'ブログ';

	$menu[5][0] = $name;
	$submenu['edit.php'][5][0] = $name . '一覧';
	$submenu['edit.php'][10][0] = $name . '追加';
}
add_action('admin_menu', 'change_menu');

function change_post_page()
{
	global $wp_post_types;
	$name = 'ブログ';

	$labels = &$wp_post_types['post']->labels;

	$labels->add_new = $name . "追加";
	$labels->name = $name;
	$labels->singular_name = $name;
	$labels->add_new = _x($name . 'を追加', $name);
	$labels->add_new_item = $name . 'の新規追加';
	$labels->edit_item = $name . 'の編集';
	$labels->new_item = '新規' . $name;
	$labels->view_item = $name . 'を表示';
	$labels->search_items = $name . 'を検索';
	$labels->not_found = $name . 'が見つかりませんでした';
	$labels->not_found_in_trash = 'ゴミ箱に' . $name . 'は見つかりませんでした';
}
add_action('init', 'change_post_page');
