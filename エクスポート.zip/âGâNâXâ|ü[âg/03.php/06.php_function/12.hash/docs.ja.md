---
title: ハッシュ関数
taxonomy:
    category:
        - docs
---

ハッシュとは
: ハッシュとはアルゴリズムに基づき、読解不可能な文字列などに置換する仕組みのことです。

※パスワードなどの機密情報を扱う時になどに使用します。

## 代表的なハッシュ関数
PHPには標準で、文字列からハッシュ値を計算し、生成する関数が存在します。

※以下が代表的な、ハッシュ関数です。

| ハッシュ関数 | 詳細 | 
| -------- | -------- |
|	hash	|	指定したアルゴリズムで、ハッシュ値を生成する ※バージョン 5.1.2以降|
|	md5	|	MD5方式で、16進数・32文字のハッシュ値を生成する|
|	sha1 |	SHA-1方式で、16進数・40文字のハッシュ値を生成する|
|	password_hash |	機密性の高い文字列のハッシュ値を生成する ※バージョン 5.5以降|

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
hash
: 実行すると、毎回同じハッシュ値が生成されます。
<iframe src="https://paiza.io/projects/e/ziQANm7qyLnywu3Ca_GFvg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>



## 参考サイト

* [PHP ハッシュ関数](https://qiita.com/kurodariuto/items/676ef655869656b2f168)