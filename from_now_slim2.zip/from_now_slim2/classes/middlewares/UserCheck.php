<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;

class UserCheck implements MiddlewareInterface
{
    private $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $serverParams = $request->getServerParams();

        $response = $handler->handle($request);

        //$ipAddress = $serverParams["REMOTE_ADDR"];
        $folderName = basename($_SERVER['REQUEST_URI']);
        $ipAddress = $_SERVER["REMOTE_ADDR"];//取得したIPアドレス

        $db = $this->container->get("db");

        if(empty($_SERVER['HTTP_REFERER'])){
            //echo '未定義';
            $motourl = '../pages/p__base/';
        }else{
            $motourl = $_SERVER['HTTP_REFERER'];//遷移元のURL
        }

        $sql_page=$db->prepare('select * from locklist where page=?');
        $sql_page->execute([$folderName]);

        $countPage=$sql_page->rowCount();

        $sql_ip=$db->prepare('select * from admin_ip where ip_address=?');
        $sql_ip->execute([$ipAddress]);

        $countIp=$sql_ip->rowCount();

        if($countPage!=0 && $countIp==0 ) {
            header('Location:'. $motourl);
            exit;
        }

        return $response;
    }
}