// 表示要素 DOM操作用定数
const contents = document.getElementById('news');
const redraw_elements = document.querySelectorAll('#news > li');//記事総数

// ページネーション DOM操作用の定数
const total_el = document.querySelector('.total_counter');
const page_counter = document.querySelector('.page_counter');
const prev_btn = document.querySelector('.prev');
const next_btn = document.querySelector('.next');
const current_num= 1;//初期ページ表示
const count = 6;//表示する1ページの記事件数
const both = 7, mlboth = 2, mrboth = 2, rev_num = 3, mboth = 2;//両端番号ボタン数,反対側の番号ボタン数など（最大の番号ボタン数 11個）→ボタン数の調整時に使用
let current_step, index_start, index_end, total_step;
let btn_num;
const ellips = {class: 'ellipsis', data: '…'}


// class付与・削除関数
prev_btn_active = () => {
    prev_btn.classList.add('disable');
}
prev_btn_disable = () => {
    prev_btn.classList.remove('disable');
}
next_btn_disable = () => {
    next_btn.classList.remove('disable');
}
next_btn_active = () => {
    next_btn.classList.add('disable');
}


counter_set = i => {
    let count_list = document.createElement('li');
    count_list.setAttribute('data-counter-id', i);
    count_list.classList.add('page_number');
    count_list.textContent = i;
    page_counter.appendChild(count_list);
}


//省略記号含む先頭と後ろのリスト生成
function list_set(listArray, page_counter){
    listArray.forEach(function(value){
        let count_list = document.createElement('li');

        if(value.class==='page_number'){
            count_list.setAttribute('data-counter-id', value.data);
        }

        count_list.classList.add(value.class);
        count_list.textContent = value.data;
        page_counter.appendChild(count_list);
    });
}


//番号と省略記号を後ろに挿入
btn_before_set = () => {

    let listArray = [
        {class: 'ellipsis', data: '…'},
    ]

    for (let i = 0; i < rev_num; i++) {
        btn_num = {
            "class": "page_number",
            "data": total_step - i,
        }

        listArray.splice(1, 0, btn_num);
    }
    
    total_one_before = total_step-1;
    total_two_before = total_step-2;

    for (let i = 1; i <=both; i++) {
        counter_set(i);
    }

    list_set(listArray, page_counter);
}


//番号と省略記号を前後に挿入
btn_middle_set = current_num => {

    let listArray1 = [];

    for (let i = 1; i <= mboth; i++) {
        btn_num = {
            "class": "page_number",
            "data": i,
        }

        listArray1.push(btn_num);
    }

    listArray1.push(ellips);

    list_set(listArray1, page_counter);

    for (let i = current_num-mlboth; i <= current_num+mrboth ; i++) {
        counter_set(i);
    }


    let listArray2 = [
        {class: 'ellipsis', data: '…'},
    ]

    for (let i = 0; i < mboth; i++) {
        btn_num = {
            "class": "page_number",
            "data": total_step - i,
        }

        listArray2.splice(1, 0, btn_num);
    }

    list_set(listArray2, page_counter);
}

//番号と省略記号を前に挿入
btn_after_set = () => {

    let listArray = [];

    for (let i = 1; i <= rev_num; i++) {
        btn_num = {
            "class": "page_number",
            "data": i,
        }

        listArray.push(btn_num);
    }

    listArray.push(ellips);

    list_set(listArray, page_counter);

    for (let i = total_step - both + 1; i <= total_step ; i++) {
        counter_set(i);
    }
}


//省略記号なし
btn_base_set = (total_step) => {
    for (let i = 1; i <=total_step; i++) {
        counter_set(i);
    }
}


// 記事の描画
function redraw(total, total_step, current_step, count) 
{
    let index_start = current_step * count - count + 1;
    let index_end = current_step * count;
    let index_array = [];

    for (let i = index_start-1; i < index_end; i++) {
        index_array.push(i);
    }

    // 一時削除
    while( contents.lastChild ) {
        contents.lastChild.remove();
    }

    // 記事の再描画
    redraw_elements.forEach((element, index) => {
        if(index_array.indexOf(index) != -1) {
            contents.appendChild(element);
        }
    });

}


// ページ数を算出
split_page = current_num => 
{  
    total_step = Math.ceil(redraw_elements.length / count);//ページ数
    if( current_num === undefined || current_num === 1) {//最初のページ
        current_step = 1;
        next_btn_disable();
         prev_btn_active();
    } else if( current_num === total_step ) {//最後のページ
        next_btn_active(); 
        prev_btn_disable();
    } else {
        current_step = current_num;
        next_btn_disable(); 
        prev_btn_disable();
    }

    total_el.textContent = current_step + '/' + total_step;//ページ番号とトータルページ数を挿入
    redraw(redraw_elements.length, total_step, current_step, count);
}


//ページ移動時のページボタンのカレント変更
function page_counter_change(current_num){

    // 一時削除
    while( page_counter.lastChild ) {
        page_counter.lastChild.remove();
    }

    if(total_step > both + rev_num){
        
        if(current_num < both){//番号がboth以下の場合
            btn_before_set();

        }else if(total_step-both+2 <= current_num){//番号がトータルから3つ前以降の場合
            btn_after_set();

        }else{//番号が、5～(total-4)の場合
            btn_middle_set(current_num);
        }

    }else{
        btn_base_set(total_step);
    }

    let pager_current = document.querySelector('[data-counter-id="'+current_num+'"]');
    pager_current.classList.add('current');//カレント用クラス設定

    document.querySelectorAll('.page_number').forEach((e) => {
        e.addEventListener('click', function() {
            current_step = Number(e.getAttribute('data-counter-id'));//ページ番号取得
            split_page(current_step);
            page_counter_change(current_step);//省略記号ある時に実行 
        })
    });
}


split_page(current_num);
page_counter_change(current_num)


// イベント処理
next_btn.addEventListener('click', () => {
    split_page(current_step += 1);
    page_counter_change(current_step);//省略記号ある時に実行
});

prev_btn.addEventListener('click', () => {
    split_page(current_step -= 1);
    page_counter_change(current_step);//省略記号ある時に実行
});
