import { Api } from '../api.js';
import { show, hide } from '../modalManager.js';
import { getAdminData } from '../adminData.js';


export function initFolderLock({ soating, completeMsg }) {

    let currentFolderName = null;
    let lockElm = null;
    const { adminFull } = getAdminData();

    document.addEventListener('click', async (e) => {

        if (soating()) {
            show('soatWarn');
            return;
        }
        

        // ロック
        if (e.target.classList.contains('btn-lock')) {

            const modal = document.getElementById('lockModal');
            const nameElm = document.getElementById('folder-name-lock');

            const listDir = e.target.closest('.box-item').children[0].getAttribute('href');
            currentFolderName = listDir.split('/').slice(-2)[0];

            nameElm.textContent = currentFolderName;
            lockElm = e.target;

            show('lockModal');
        }

        // ロック解除
        if (e.target.classList.contains('unlock')) {

            lockElm = e.target;

            const listDir = e.target.closest('.box-item').children[0].getAttribute('href');
            const folderName = listDir.split('/').slice(-2)[0];

            const fd = new FormData();
            fd.append('eventName', 'ロック解除');
            fd.append('folderName', folderName);

            try {
                const text = await Api.postText(adminFull + 'page_unlock', fd);

                if (!text.match(/エラー/)) {
                    completeMsg('ロック解除しました');
                    
                    lockElm.closest('.box-item').children[0].classList.remove(
                        // 'lock',
                        'all-lock'
                    );
                    
                    lockElm.classList.remove('unlock');
                    lockElm.classList.add('btn-lock');
                    lockElm.textContent = 'ロック設定';

                } else {
                    alert(text);
                }

            } catch {
                alert('失敗しました');
            }
        }
    });

    // モーダル内ボタン
    const allLock = document.getElementById('all-lock');
    
    if(allLock){       
        allLock.addEventListener('click', async () => {
            
            hide('lockModal');
    
            const fd = new FormData();
            fd.append('eventName', 'ロック設定');
            fd.append('folderName', currentFolderName);
    
            try {
                await Api.post(adminFull + 'page_lock', fd);
                
                lockElm.closest('.box-item').children[0].classList.add('all-lock');
                lockElm.classList.remove('btn-lock');
                lockElm.classList.add('unlock');
                lockElm.textContent = 'ロック解除';

                completeMsg('ロックしました');

            } catch {
                alert('失敗しました');
            }
        });
    }
}