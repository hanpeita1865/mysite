$('button').on('click',function(){
	var fd = new FormData();
	fd.append('id', '00000001');
	fd.append('name','karabiner');

	$.ajax({
		url: 'ajax.php',
		type: 'POST',
		processData: false,
		contentType: false,
		cache: false,
		data : fd
	}).done(function(data) {
		//通信成功時の処理
		console.log(data);
		
	}).fail(function(){
		//通信失敗時の処理
		alert('失敗しました～。')
	});
});



