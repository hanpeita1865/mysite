*[page-title]:多次元配列

参考サイト
: [Let'sプログラミング 多次元配列](https://www.javadrive.jp/php/array/index6.html)

<div class="exp">
	<p class="tmp"><span>例</span></p>
	3次元の配列を作成しています。ここでは、array()を使っています。
</div>
```
$detail = array('良い','普通','悪い');
$maker = array('富士通', 'NEC', 'Sony', 'Sharp');
$type = array('Note', 'Desktop', $detail);

$pc = array($maker, $type);

print_r($pc);
```

<p class="result"><span>結果</span></p>
```
Array
(
    [0] => Array
        (
            [0] => 富士通
            [1] => NEC
            [2] => Sony
            [3] => Sharp
        )

    [1] => Array
        (
            [0] => Note
            [1] => Desktop
            [2] => Array
                (
                    [0] => 良い
                    [1] => 普通
                    [2] => 悪い
                )

        )
)
```