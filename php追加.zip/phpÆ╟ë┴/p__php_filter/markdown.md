*[page-title]:配列の要素をフィルタリングする array_filter

参考サイト
: [PHP マニュアル array_filter](https://www.php.net/manual/ja/function.array-filter.php)

<p class="tmp"><span>書式</span></p>
```
array_filter($array, $callback)
```
array: 処理する配列  
callback: 使用するコールバック関数。

<div class="exp">
	<p class="tmp"><span>例1</span>array_filter() の例</p>
	<iframe src="https://paiza.io/projects/e/n_NVWMDC_D_PZ1cZaPFNQg?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>
</div>