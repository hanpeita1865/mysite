<?php
$database='from_now';
$user='staff';
$password='password';
?>