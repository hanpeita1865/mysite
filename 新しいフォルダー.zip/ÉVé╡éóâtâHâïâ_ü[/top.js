const iframe1 = document.getElementById('iframe1');//重要なお知らせ用
const iframe2 = document.getElementById('iframe2');//お知らせ用
let toObj;
let numBool = true;

message();

function message() {

    window.addEventListener("message", (event) => {

        // console.log(event.data)

        // if(typeof event.data) == 'string'){
        //     var toObj = JSON.parse(event.data);           
        // }else{
        //     var toObj = event.data;
        // }

        console.log(event.data)

        console.log(typeof(event.data))

        if(typeof(event.data)=='string'){
            toObj = JSON.parse(event.data);             
        }


        // console.log(toObj) 

        if (event.origin != "https://www3.jeed.go.jp/") {
            if(toObj.height1){
                //重要なお知らせ
                console.log('height1がある')
                
                if (toObj.num == 0) {
                    //記事件数が0件の場合
                    document.getElementById('importance').closest('section').classList.add('visually-hidden');
                    document.getElementById('myCarousel').classList.add('mb-0');
                    numBool = false;
                } else {
                    //iframeの高さの設定
                    iframe1.style.height = toObj.height1 + 'px';
                }
                
            }else if(toObj.height2){
                //お知らせ
                console.log('height2がある')
                iframe2.style.height = toObj.height2 + 15 + 'px';
            }
        }

        return;
    });
}


function resizeWindow() {
    message();
}

window.addEventListener('resize', resizeWindow);


window.addEventListener('load', (event) => {
  console.log('ページが完全に読み込まれました');

    console.log(numBool)

    if((!iframe1.hasAttribute('style') && numBool)||!iframe2.hasAttribute('style')){
        console.log('styleなし')
        console.log(window.name)
        if (window.name != "any") {
            console.log('リロードします')
            location.reload();
            window.name = "any";
        } else {
            window.name = "";
        }
    }else{
         console.log('styleある')
    }

});



