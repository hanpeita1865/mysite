<?php
namespace SocymSlim\SlimMiddle\Services;

use PDO;

class SearchService {
    private PDO $db;
    private MenuService $menuService;
    private MarkdownService $markdownService;
    private LockService $lockService;

    public function __construct(PDO $db, MenuService $menuService, MarkdownService $markdownService, LockService $lockService) {
        $this->db = $db;
        $this->menuService = $menuService;
        $this->lockService = $lockService;
        $this->markdownService = $markdownService;
    }

    public function search(string $basePath, string $category, string $word, bool $fullText): array {
        // 🔹 1. 検索フォルダ決定
        $searchFolder = '../pages' . ($category ? '/' . $category : '');

        // 🔹 2. ロックリスト取得
        $lockData = $this->lockService->getLockList($this->db);

        // 🔹 3. メニュー生成
        $menuData = $this->menuService->buildMenu('../pages');

        // 🔹 4. Markdown 検索
        $results = $this->markdownService->searchMarkdowns($basePath, $searchFolder, $word, $fullText);

        // 🔹 5. Markdown → HTML に変換
        $htmlData = $this->markdownService->convertToHtml($results);

        return [
            'menuData' => $menuData,
            'htmlData' => $htmlData,
            // 'lockData' => $lockData,
            'searchFolder' => $searchFolder,
        ];
    }
}