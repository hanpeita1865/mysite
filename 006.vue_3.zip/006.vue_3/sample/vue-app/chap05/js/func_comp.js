Vue.createApp({})
  .component('my-random', (props, context) => {//-----(1)
    const result = Math.floor(Math.random() *
      (props.max - props.min + 1) + props.min);
    return Vue.h('p', result);
  })
  .mount('#app');
