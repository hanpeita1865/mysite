*[page-title]:リソースコントローラメモ3（コンポーネントの使い方について）


参考サイト
: [Laravel 10.x Bladeテンプレート　コンポーネント](https://readouble.com/laravel/10.x/ja/blade.html)
: [コンポーネント内のファイルに変数を受け渡し、foreach構文を使う方法](https://biz.addisteria.com/component_foreach/)


## コンポーネントの作成

コンポーネントとスロットは、セクション、レイアウト、インクルードと同様の利便性を提供します。ただし、コンポーネントとスロットのメンタルモデルが理解しやすいと感じる人もいるでしょう。コンポーネントを作成するには、クラスベースのコンポーネントと匿名コンポーネントの2つのアプローチがあります。

クラスベースのコンポーネントを作成するには、「<span class="red">make:component Artisan</span>」コマンドを使用できます。コンポーネントの使用方法を説明するために、単純な「アラート（Alert）」コンポーネントを作成してみます。make:componentコマンドは、コンポーネントを「**app/View/Components**」ディレクトリに配置します。

<p class="tmp cmd"><span>コマンド1-1</span>Alertコンポーネント作成</p>
```
php artisan make:component Alert
```
![](upload/Alertコンポーネント作成.png)

また、サブディレクトリ内にコンポーネントを作成することもできます。
<p class="tmp cmd"><span>コマンド1-2</span>サブディレクトリ内にコンポーネント作成</p>
```
php artisan make:component Forms/Input
```
上記のコマンドは、「app/View/Components/Forms」ディレクトリにInputコンポーネントを作成し、ビューは「resources/views/components/forms」ディレクトリに配置します。

匿名コンポーネント(Bladeテンプレートのみでクラスを持たないコンポーネント)を作成したい場合は、make:componentコマンドを実行するとき、<span class="bold green">--viewフラグ</span>を使用します。
<p class="tmp cmd"><span>コマンド1-3</span>匿名コンポーネント作成</p>
```
php artisan make:component forms.input --view
```
上記のコマンドは、「resources/views/components/forms/input.blade.php」へBladeファイルを作成します。このファイルは`<x-forms.input />`により、コンポーネントとしてレンダできます。

---

コマンド1-1を実行すると、<span class="bold green">alert.blade.php</span>と<span class="bold green">alert.php</span>が作成されます。
![](upload/alert.blade.phpが作成されました.png "alert.blade.phpディレクトリ"){.fig-top}

![](upload/alert.blade.phpデフォルトコード.png "alert.blade.phpデフォルトコード")

![](upload/Alert.phpが作成された.png "Alert.phpディレクトリ"){.fig-top}

![](upload/Alert.phpデフォルトコード.png "Alert.phpデフォルトコード")

既存の「sample/index.blade.php」に`<x-alert/>`を追記して表示を確認してみましょう。
<p class="tmp list"><span>リスト1-1</span>sample/index.blade.php</p>
```
<!doctype html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>つぶやきアプリ</title>
</head>
<body>
    <h1>つぶやきアプリ</h1>
    <p>{{ $name }}</p>
    <x-alert/>
</body>
</html>
```

<p class="tmp list"><span>リスト1-2</span>alert.blade.php</p>
```
<div>
    ままままま
</div>
```

http://localhost:6002/sample/22 にアクセスすると、次のようにalert.blade.phpに記入した「ままままま」が表示されます。
![](upload/sampleでalert表示確認.png){.photo-border}


## コンポーネントのレンダ

コンポーネントを表示するために、Bladeテンプレート１つの中でBladeコンポーネントタグを使用できます。Bladeコンポーネントタグは、文字列「<span class="bold red">x-</span>」で始まり、その後にコンポーネントクラスの<span class="red">ケバブケース名</span>を続けます。
```
<x-alert/>
```

コンポーネントクラスが「app/View/Components」ディレクトリ内のより深い場所にネストしている場合は、「<span class="bold red">.</span>」文字を使用してディレクトリのネストを表せます。たとえば、コンポーネントが「app/View/Components/Inputs/Button.php」にあるとしたら、以下のようにレンダリングします。
```
<x-inputs.button/>
```

もし、コンポーネントを条件付きでレンダしたい場合は、コンポーネントクラスで<span class="red">shouldRender</span>メソッドを定義してください。<span class="red">shouldRender</span>メソッドが<span class="red">false</span>を返した場合、<span class="marker-yellow50 bold">コンポーネントをレンダしません</span>。
```
use Illuminate\Support\Str;

/**
 * コンポーネントをレンダするか
 */
public function shouldRender(): bool
{
    return Str::length($this->message) > 0;
}
```

## コンポーネントへのデータ渡し

HTML属性を使用してBladeコンポーネントへデータを渡せます。ハードコードするプリミティブ値は、単純なHTML属性文字列を使用してコンポーネントに渡すことができます。PHPの式と変数は、接頭辞として「<span class="bold red">:</span>」文字を使用する属性を介してコンポーネントに渡す必要があります。

<p class="tmp list"><span>リスト3-1</span>sample/index.blade.php</p>
```
・・・
<body>
    <h1>つぶやきアプリ</h1>
    <p>{{ $name }}</p>
    <x-alert type="error" msg="めめめめ"/>
</body>
</html>
```
※「<span class="bold blue">:msg</span>」ではなく「<span class="bold red">msg</span>」にしたら変数を渡せた。


<p class="tmp list"><span>リスト3-2</span>app/View/Components/Alert.php</p>
```
<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;


class Alert extends Component
{
    /**
     * Create a new component instance.
     */
    public function __construct(public string $type, public string $msg,
    ){}

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.alert');
    }
}
```

<p class="tmp list"><span>リスト3-3</span>resources/views/components/alert.blade.php</p>
```
<div class="alert alert-{{ $type }}">
    {{ $msg }}
</div>
```

<http://localhost:6002/sample/22>にアクセスすると、$msgの値が表示されます。
![](upload/alert変数引き渡し.png){.photo-border}


## リソースコントローラーで利用

実際にリソースコントローラーで作成したファイルで変数の受け渡しなどをやってみます。

配列のままでは受け渡しができなかったので、一つずつ変数に格納して受け渡しています。

<p class="tmp list"><span>リスト4-1</span>views/rest/index.blade.php</p>
```
<x-app-layout>
    <x-slot name="header">
    <form action="/rest/create" method="get">
        <input type="submit" value="新規登録">
    </form>
    </x-slot>

    @if (Route::has('login'))
        <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
            @auth
                <!-- <a href="{{ url('/dashboard') }}" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">登録・編集画面</a> -->
            @else
                <a href="{{ route('login') }}" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>

                @if (Route::has('register'))
                    <a href="{{ route('register') }}" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                @endif
            @endauth
        </div>
    @endif

    <table>
        @foreach($items as $item)
        <!--コンポーネント追記-->
        <x-rest.options :restId="$item->id" :userId="$item->user_id" msg="{{$item->message}}" imgUrl="{{$item->path}}" />
        @endforeach
    </table>

</x-app-layout>
```

<p class="tmp list"><span>リスト4-2</span>Options.php</p>
```
<?php

namespace App\View\Components\Rest;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;


class Options extends Component
{
    private int $restId;
    private int $userId;


    public function __construct(int $restId, int $userId, public string $msg, public string $imgUrl ) {
        $this->restId = $restId;
        $this->userId = $userId;
    }

    public function render() {
        return view('components.rest.options')
            ->with('restId', $this->restId)
            ->with('myRest', \Illuminate\Support\Facades\Auth::id() === $this->userId);

    }
}
```


<p class="tmp list"><span>リスト4-3</span>options.blade.php</p>
```
@if($myRest)
<tr>
    <th>message: </th>
    <td>{{$msg}}</td>
</tr>
<tr>
    <th>url: </th>
    <td>{{$imgUrl}}</td>
</tr>
<tr>
    <th>画像</th>
    <td>
    @if ($imgUrl !=='')
        <img src="{{ \Storage::url($imgUrl) }}" width="25%">
    @else
        <!-- <img src="{{ \Storage::url('items/no_image.png') }}"> -->
    @endif
    </td>
</tr>
<tr>
    <td>
        <form action="/rest/{{{$restId}}}" method="post">
            @csrf
            @method('DELETE')
            <input class="btn-delete" type="submit" value="削除">
        </form>
    </td>
    <td>
        <form action="/rest/{{{$restId}}}/edit" method="get">
            <input class="btn-exit" type="submit" value="編集">
        </form>
    </td>
</tr>
@endif
```

管理一覧では、ログインした人が登録した記事だけ表示されます。
![](upload/tanaka登録記事表示.png "図　tanakaさんが登録した記事一覧"){.photo-border}

![](upload/hiraoが登録した記事一覧.png "図　hiraoさんが登録した記事一覧"){.photo-border}