*[page-title]:06. PHPテンプレートの利用

本格的なWebページを作るためには、HTMLを使ってそのまま表示内容を記述できるような仕組みが必要になります。  
こうした用途のために用意されているのが「<span class="red bold">テンプレート</span>」です。テンプレートは、 Laravelの「<span class="blue bold">ビュー(View)</span>」を担当する重要な部品です。  
先に述べたように、Laravelでは、Model-View-Controller (MVC)というアーキテクチャーに基づいて設計がされています。ビューは、画面表示を担当する部分で、画面の表示に関する部分を簡単にわかりやすい形で作れるようにしています。そのために採用されているのが、テンプレートという考え方です。

テンプレートは、画面表示のベースとなるものです。あるアドレスにアクセスすると、コントローラはそのアドレスで使われるテンプレートを読み込んで表示します。ただし、ただ読み込まれたHTMLのコードがそのまま表示されるわけではありません。


## レンダリングの考え方
テンプレートには、あらかじめ変数や処理などが記述されています。Laravelでは、テンプレートを読み込んだ後、その中に必要な情報などをはめ込むなどして、実際の表示を生成することができます。この作業は「<span class="red bold">レンダリング</span>」と呼ばれます。  
レンダリングにより、テンプレート内に用意されている処理や変数などが実行され、処理結果や変数の値などが実際の表示として組み込まれていくのです。このレンダリングという作業により、コントローラで用意しておいた値や変数などを組み込んだHTMLソースコードが生成されます。  
レンダリングは、「<span class="red bold">テンプレートエンジン</span>」によって行われます。テンプレートエンジンは1つだけではなく、いろいろなものがあります。どのテンプレートエンジンを使うかによって、テンプレートの書き方なども変わってきます。

Laravelでは、大きく2つのテンプレートが用いられます。1つは、「<span class="red">PHPのソースコードをそのままテンプレートとして使う方法</span>」です。そしてもう1つは、Laravelが独自に作成した「<span class="marker-yellow30"><span class="green bold">Blade（プレード）</span></span>」と呼ばれるテンプレートエンジンを使った方法です。 

この2つの方法が使えるようになれば、画面表示についての基本はほぼマスターしたといえるでしょう。

![](upload/template_controller.png "図　テンプレート表示のしくみ")


## PHPテンプレートを作る
では、実際にテンプレートを利用してみることにしましょう。ここでは、前章で作成したHelloControllerを使い、このコントローラに用意されたアクションからテンプレー トを読み込んで利用してみます。  
まずは、テンプレートファイルを作成しましょう。テンプレートファイルは、「**resources**」フォルダ内の「**views**」というフォルダの中に配置します。  
このフォルダを開き、その中に「**hello**」というフォルダを作成して下さい。テンプレートは、各コントローラごとにフォルダを用意し、その中にそのコントローラで使うテンプレートをまとめておくのが一般的です。これは必ずそうしないといけないわけではありませんが、テンプレートをわかりやすく管理するために「そう配置するのが基本」と考えて下さい。  
では、この「hello」フォルダの中に、「**index.php**」という名前でPHPファイルを作成しましょう。

ソースコードは、以下のように記述しておきます。
<p class="tmp list"><span>リスト1</span>resources/views/hello/index.php</p>
```
<html>
<head>
   <title>Hello/Index</title>
</head>
<body>
   <h1>Index</h1>
   <p>This is a sample page with php-template.</p>
</body>
</html>
```

見ればわかるように、PHPといっても、ただHTMLのコードが記述されているだけです。 まずは、ただのHTMLを表示するところから始めることにしましょう。


### ルートの設定でテンプレートを表示する
では、このテンプレートを読み込んで表示してみます。まずは、ルート情報を設定し、 テンプレートをレンダリング表示するようにしてみます。  
web.phpを開き、以下の文を追記します。

<p class="tmp list"><span>リスト2</span>web.php</p>
```
Route::get('helloTemp', function() {
	return view('hello.index'); 
});
```
これで完成です。コントローラは今回は使いません。まずは、ルート情報の設定のところで、直接テンプレートを使ってみます。  
記述したら、/helloTempにWebブラウザからアクセスをして下さい。用意したindex.phpのHTMLソースコードがそのまま読み込まれ、画面に表示されます。

<http://localhost:8000/helloTemp/>

![](upload/helloTemp.png "図　/helloTemp/にアクセス"){.photo-border}


### view メソッドについて
ここでは、第2引数に用意されるクロージャ(無名関数)内で「view」というメソッドを使っています。このviewは、引数にテンプレート名をテキストで指定すると、そのテン プレートを読み込んで返します。viewは、このような形で呼び出します。
<p class="tmp"><span>書式1</span></p>
```
view( 'フォルダ名 . ファイル名・)
```

テンプレートは、「views」フォルダから検索されます。ここでは、<span class="red">'hello.index'</span>という値をviewの引数に指定していますが、これで「**views**」内の「**hello**」フォルダの中にある <span class="red bold">index.php</span>が指定されます。フォルダ内にあるファイルは、このように「フォルダファイル」という形で記述をします。  
単に' hello'だけだと、「views」フォルダ内にあるファイルを検索してしまいます。フォルダを使ってテンプレートを整理している場合は、「どのフォルダ内の何というファイルか」をきちんと指定しなければいけません。

<div class="memo-box" markdown="1">
##### view Response
このviewメソッドの戻り値をreturnすると、そのままテンプレートの内容が表示されます。このことから、「viewは、テンプレートを読み込んでその内容を返すんだ」と思ってしまいがちですが、実はそうではありません。  
<span class="red">view</span>が返すのは、「<span class="red bold">Response</span>」インスタンスなのです。もちろん、このResponseには、指定したテンプレートのレンダリング結果がコンテンツとして設定されています。ですから、テンプレートの内容がきちんと表示されます。結果として「viewの戻り値をそのまま返せばテンプレートの内容が表示される」という点では同じですが、「<span class="marker-green30 red">**viewにより、テ ンプレートのソースコードがそのまま返されるわけではない**</span>」という点は知っておきま しょう。
</div>


## コントローラでテンプレートを使う
では、コントローラでテンプレートを使いましょう。ルート情報のクロージャで使ったviewをそのままアクションメソッド内で利用するだけですから、使い方はすぐにわか ります。  
まず、コントローラを修正しましょう。HelloControllerクラスにphpTempメソッドを追加して下さい。

<p class="tmp list"><span>リスト3</span>helloController.php</p>
```
public function phpTemp() {
    return view('phpTemp.index');
}
```

returnでviewの結果を返している点は先ほどとまったく同じです。修正したら、web.phpに次のコードを追記します。

<p class="tmp list"><span>リスト4</span>web.php</p>
```
Route::get('helloTemp2', 'helloController@phpTemp');
```
これで修正完了です。Webブラウザから/helloTemp2にアクセスすると、先ほどと同様に index.phpテンプレートの内容が表示されます。  
やっていることは、先ほどと同じです。ただ、<span class="marker-yellow30 bold">Route::getでviewする</span>か、<span class="marker-green30 bold">Route::getで呼び出されたアクションメソッド内でviewする</span>かの違いだけです。

<http://localhost:8000/helloTemp2/>

![](upload/helloTemp2.png "図　/helloTemp2/にアクセス"){.photo-border}


## 値をテンプレートに渡す
ただHTMLのソースコードをそのまま表示するだけなら、テンプレートを使う意味がありません。テンプレートでは、必要な値を渡して表示したり、必要な処理を実行して結果を表示したりできるからこそ、役に立つのです。  
では、こうした値の表示を行ってみましょう。index.phpの&lt;body&gt;タグ部分を以下のように書き換えて下さい。
    
<p class="tmp list"><span>リスト5</span>phpTemp/para.php</p>
```
<body>
   <h1>Index</h1>
   <p><?php echo $msg; ?></p>
   <p><?php echo date("Y年n月j日"); ?></p>
</body>
```
参考に、下記はPHPで現在の日付を取得するためによく使う方法です。
```
//現在日時をUNIXタイムスタンプを秒単位で取得する
$now = time();

//現在日時を YYYY/MM/DD hh:mm:ss の書式の文字列で取得する
$now = date('Y/m/d H:i:s');

//現在日時を DateTime クラスのインスタンスで取得する
$now = new DateTime();
```
このように主に**time()**、**date()**と**DateTime()**の三つのメソッドを利用します。
    
参考
: [PHPでの日付取得方法](https://eng-entrance.com/php-date)

今回は、変数$msgと、現在の日付をそれぞれ&lt;p&gt;タグにまとめて表示しています。
index.phpテンプレートは、基本的にはただのPHPスクリプトです。したがって、<?php ?>タグを使ってPHPのスクリプトを記述すれば、そのままスクリプトを実行できます。  
ただし、そのためには、
テンプレートで受け渡された変数を表示させるには、コントローラ側からテンプレート側へ必要な変数などの値を受け渡す方法がわかっていなければいけません。ここでは、$msgを表示していますから、この$msgという変数をテンプレートに渡すように設定します。  
では、コントローラのアクションメソッドを修正しましょう。HelloControllerクラス に以下のメソッドを追加して下さい。
   
<p class="tmp list"><span>リスト6</span>HelloController.php</p>
```
public function paraPhp()
{
   $data = ['msg'=>'これはコントローラから渡されたメッセージです。'];
   return view('phpTemp.para', $data);
}
```

web.phpに次のコードを追記します。

<p class="tmp list"><span>リスト7</span>routes/web.php</p>
```
Route::get('helloPara', [\App\Http\Controllers\HelloController::class,'paraPhp']);
```

修正したら、/helloParaにアクセスしてみましょう。「これはコントローラから渡されたメッセージです」というテキストが表示されます。  
$msgに値を渡し、それが表示されることが確認できました

<http://localhost:8000/helloPara/>
![](upload/helloPara.png){.photo-border}

### テンプレートへの値の受け渡しについて
ここでは、indexアクションのviewメソッドを呼び出しているところで、必要な値をテンプレート側に渡しています。ここでは、viewの呼び出しは以下のように記述しています。

<p class="tmp"><span>書式2</span></p>
```
return view(テンプレート , 配列 );
``` 
第2引数に、配列(連想配列)が渡されています。ここで配列に用意した値が、そのままテンプレート側に変数として用意されるのです。例えば今回の例では、
```
['msg'=>'これはコントローラから渡されたメッセージです。']
```
このような配列が用意されていました。これで、配列の値である「これはコントローラから渡されたメッセージです。」というテキストが、キーである'msg'という名前の変数としてテンプレートに用意されることになります。  
このようにviewの第2引数では、テンプレート側に用意する変数名をキーに指定して、値を用意します。配列ですから、必要があればいくつでも値を用意して渡すことが可能です。

![](upload/php_template04.png "図　コントローラ側で配列として用意した値は、viewでテンプレート側に渡されて使えるようになる。")


## ルートパラメータをテンプレートに渡す
    
値の受け渡しですぐに思い浮かぶのは、「<span class="bold">ルートパラメータ</span>」の利用についてでしょう。 アクセス時のアドレスに記述しておいた値が、そのままテンプレートで表示されるようにするためには、どうするのでしょうか。

これは、2つの部分に切り分けて考えるとよいでしょう。1つは、ルートパラメータを受け取る部分。もう1つは、値をテンプレートに書き出す部分です。   
ルートパラメータを受け取る処理は、既にやりました。アクションの引数に仮引数を用意しておき、Route::getでアドレスにパラメータを追記しておくのでした。  
この方法で、ルートパラメータはコントローラで受け取れます。後は、それをテンプレートに渡して表示するだけです。  
では、実際にやってみましょう。次のテンプレートを追加してください。

<p class="tmp list"><span>リスト7</span>views/phpTemp/rootPara.php</p>
```
<body>
   <h1>Index</h1>
   <p><?php echo $msg; ?></p>
   <p>ID=<?php echo $id; ?></p>
</body>
```
ここでは、$idという変数を追加して表示させています。これがパラメータとして渡される値です。
    
### アクションの修正
では、コントローラのアクションに次のメソッドを追加します。。
    
<p class="tmp list"><span>リスト8</span>HelloController.php</p>
```
public function rootPara($id='zero')
{
   $data = [
       'msg'=>'これはコントローラから渡されたメッセージです。',
       'id'=>$id
   ];
   return view('phpTemp.rootPara', $data);
}
```
ここでは、引数に **$id** を追加しています。引数が省略されることも考え、デフォルト値を用意しておきました。そしてこの引数$idを、配列に **'id'** というキーで追加しておき ます。これで、引数$idの値がそのまま、テンプレートで$idという変数で使えるようになりました。


### ルート情報の修正
最後にルート情報の修正です。web.phpに記述してあった/helloRootParaのルート情報を以下の ように修正して下さい。
    
<p class="tmp list"><span>リスト9</span>web.php</p>
```
Route::get('helloRootPara/{id?}', [\App\Http\Controllers\HelloController::class,'rootPara']);
```   
第1引数のアドレスに、<span class="red bold">{id?}</span> という形でルートパラメータを用意しておきました。この{id?}の値が、コントローラのindexアクションメソッドに引数として渡されることになります。それがそのままテンプレートの <span class="red bold">$id</span> に渡され表示される、というわけです。  
修正ができたら、/helloRootPara/の後に値をつけてアクセスをしてみて下さい。パラメータとしてつけた値が「ID-○○」という形で画面に表示されます。

パラメータに「Daichi」を設定  
<http://localhost:8000/helloRootPara/Daichi>

![](upload/helloRootPara.png "図　 ID=Daichiと表示されます "){.photo-border}


## クエリー文字列の利用
    
アクセスするアドレスの情報を利用して値を渡す方法は、もう1つあります。「<span class="blue bold">クエリー文字列</span>」を使うのです。  
クエリー文字列は、アドレスの後に「?○○=××」といった形式でつけられたテキスト部分のことです。GoogleやAmazonなどのサイトにアクセスすると、アドレスの後に延々と「○○=××&△△=◆◇......」といった暗号のようなものが記述されているのを見たことがあるでしょう。あれがクエリー文字列です。
    
クエリー文字列は、ルートパラメータとは少し受け取り方が違います。これも実際に試しながら使い方を説明しましょう。  
テンプレートは、先ほどのものをそのまま利用することにします。コントローラのアクションとルート情報だけクエリー文字列用に書き換えればよいでしょう。  
まずは、コントローラに次のアクションメソッドを追加して 下さい。
    
<p class="tmp list"><span>リスト10</span>HelloController.php</p>
```
public function queryPara(Request $request)
{
   $data = [
       'msg'=>'これはコントローラから渡されたメッセージです。',
       'id'=>$request->id
   ];
   return view('phpTemp.rootPara', $data);
}
```
ここでは、引数にRequestインスタンスを渡すようにしています。そして、テンプレー トに渡す"id"の値は、「<span class="red">$request->id</span>」 というようにして取り出しています。このidが、クエリー文字列で渡される値です。 続いて、ルート情報を追加します。

<p class="tmp list"><span>リスト11</span>web.php</p>
```
Route::get('helloQueryPara', [\App\Http\Controllers\HelloController::class,'queryPara']);
```

見ればわかるように、アドレスから{id?)が消えています。一般的なルート情報の記述に戻されていることがわかるでしょう。 これで、Webブラウザから、例えば以下のようにアクセスをしてみて下さい。

<http://localhost:8000/helloQueryPara/?id=NTTDATA>

ルートパラメータのときと同じように表示されます。
![](upload/queryPara.png){.photo-border}

このようにクエリー文字列を使って渡された値は、「$request->キー名」というようにして取り出すことができます。ルートパラメータと異なり、ルート情報には何ら特別な 記述は必要ありません。ただアクションでRequestを引数に用意しておくだけでいいのです。
