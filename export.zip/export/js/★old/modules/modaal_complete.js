export function modaal_comp() {

    //Modaal（モーダルウインドウ）
    //画像　Single Image Modal
    $('.image').modaal({
        type: 'image',
        after_open: imageNumber,
        after_image_change: changeNumber
    });

    //画像ギャラリー
    $('.modaal-image').modaal({
        type: 'image'
    });

    // YOUTUBE
    $('.video').modaal({
        type: 'video',
    });

    // AJAX
    $('.modaal-ajax').modaal({
        type: 'ajax'
    });

    //インライン
    $(".inline").modaal();

    //フルスクリーン
    $('.fullscreen').modaal({
        fullscreen: true
    });

    function imageNumber(){
        galleryNum = 0;
        let galleryOrder;

        $('[data-group="gallery"]').each(function(){
            galleryNum++;

            let dataGallery = $(this).attr('data-gallery-active');
            if($(this).attr('data-gallery-active')){
                galleryOrder = galleryNum;
            }
        });

        $('.modaal-container').prepend('<p class="gallery-num">'+galleryOrder+'/'+galleryNum+'</p>');
        $('.modaal-container').append('<p class="gallery-num num-bottom">'+galleryOrder+'/'+galleryNum+'</p>');
    }

    function changeNumber(){
        let galleryOrder;
        let activeCls = $('.is_active.gallery_active_item').attr('class');
        let clsArray = activeCls.split(" ");
        galleryOrder = clsArray[1].replace('gallery-item-','');
        galleryOrder = Number(galleryOrder)+1;

        $('.gallery-num').text(galleryOrder+'/'+galleryNum);
    }
}
