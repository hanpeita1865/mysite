<?php require 'menu.php'; ?>
<p>ログアウトしますか？</p>
<a href="logout-output.php">ログアウト</a>

