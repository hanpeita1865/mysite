$(function () {

    let mokujiHight = 0; //プレビュー用
    
      let simpleBar = null;
    
    //追加
    const current = document.querySelector('#sidebar #menu').dataset.active;
    const items = document.querySelectorAll('.box-item');

    items.forEach(li => {
        
        if (li.querySelector(':scope > ul')) {
            li.classList.add('toggle');
        }
        
        if (li.dataset.name === current) {
            li.classList.add('active');
        
            let parent = li.closest('ul');

            while (parent) {
                const parentLi = parent.closest('li');
                if (!parentLi) break;

                parentLi.classList.add('cate-active', 'toggle');
                parent = parentLi.closest('ul');
            }
        }
    });

    
    function initSimpleBar() {
        const leftColumn = document.getElementById('menu-wrap');
        if (!leftColumn) return;

        if (simpleBar) {
            simpleBar.recalculate();
        } else {
            simpleBar = new SimpleBar(leftColumn);
        }

        // ★ 初期化完了後に表示
        leftColumn.classList.add('is-ready');
    }
    
    // ★ ここで SimpleBar
    initSimpleBar();

    setLayout();

    window.addEventListener('resize', setLayout);

    function setLayout() {
        const headerHeight = $('#header-wrapper').outerHeight();
        const menuHeight = window.innerHeight - headerHeight + 'px';
        $('#menu-wrap').css('height', menuHeight);
    }

    // 現在のパスを取得は
    const pathname = location.pathname;

    // "pages" 以降の相対パスを安全に取得
    const match = pathname.match(/\/pages\/(.+)/);
    const folderPath = match ? match[1].replace(/\/$/, '') : ''; // 後ろの / を除去

    // パスを分解して配列化
    const pathParts = folderPath.split('/');

    // 最後の要素がページフォルダ名
    const markFolder = pathParts.at(-1) || '';

    // "__" が含まれている場合、分割して最後を取得
    const markFile = markFolder.includes('__')
        ? markFolder.split('__').pop()
        : markFolder;

    let pageMokuArray = []; //カテゴリートップ用目次

    //スクロール位置
    let scrollStart = $('#scroll').val();

    $('body,html').animate(
        {
            scrollTop: scrollStart,
        },
        0
    );


    
    // -- メニューのスクロール設定
    // SimpleBar 内部スクロールコンテナ
    const wrapper = $('.simplebar-content-wrapper');
    // アクティブなリスト
    const activeLi = $('#menu li.active');

    if (activeLi.length) {
        let topParentLi = activeLi;

        if (!activeLi.parent().hasClass('side-link')) {
            // side-link が最上位UL
            topParentLi = activeLi.closest('.side-link > li');
        }

        //親要素のスクロール位置
        let firstPos = topParentLi.position().top;
        let activeOffset = activeLi.offset().top; //アクティブメニュー位置
        const menuHeight = $('#menu-wrap').outerHeight(true);

        //アクティブメニューが隠れる場合
        if (activeOffset - firstPos > menuHeight) {
            pos = activeOffset - menuHeight / 2;
        } else {
            pos = firstPos;
        }

        wrapper.animate(
            {
                scrollTop: pos,
            },
            0
        );
    }

    //URLから$bath_pathと同じ値を取得
    const urlPathname = location.pathname;
    const pathAry = urlPathname.split('/');
    const pathPub = pathAry.indexOf('public');
    let bathPath = '';

    for (var i = 1; i < pathPub; i++) {
        bathPath = bathPath + '/' + pathAry[i];
    }

    //jsonファイルの第一階層のメニューオブジェクトを読み込む
    fetch(bathPath + '/public/api/searchMenu')
        .then((response) => response.json())
        .then((data) => {
            const listData = data;
            let menuElm = document.querySelectorAll('#menu > li');

            let firstMenus = Array.from(menuElm).filter(function (e) {
                let list = e.querySelectorAll('li');

                //配下のメニューの数で選定
                if (list.length > 5) {
                    return e;
                }
            });

            let categoryList = [];

            firstMenus.forEach(function (e) {
                let titleVal = e.firstElementChild.getAttribute('title');
                let hrefVal = e.firstElementChild
                    .getAttribute('href')
                    .split('/')
                    .slice(-2)[0];
                let obj = { title: titleVal, folderName: hrefVal };

                categoryList.push(obj);
            });

            if (document.getElementById('search-select') != null) {
                const searchSelect = document.getElementById('search-select');
                searchSelect.innerHTML =
                    '<option value="" selected="">検索対象すべて</option>';

                categoryList.forEach(function (e) {
                    let option = document.createElement('option');
                    option.value = listData[e.folderName];
                    option.textContent = e.title;
                    searchSelect.appendChild(option);
                });
            }
            
            //初期表示でカテゴリーセレクトと本文内を検索チェックを設定
            restoreFormState();            
            
        });



    //配下のページ目次用配列生成、編集ボタンに設定
    $('#menu li.active a').each(function () {
        //ナビリンクからカテゴリフォルダ名と一致したカテゴリーのテキスト名を取得
        let href1 = $(this).attr('href');
        let href2 = href1.split('/');
        let folderName = href2.slice(-2)[0];

        if (markFolder == folderName) {
            let cateText = $(this).text(); //ページ名

            $('#edit').val(cateText); //編集ボタンのinputのvalue値にページ名を設定
            $('#folder').val(markFolder); //編集ボタンのinputのvalue値にフォルダ名を設定
            $('#folderPath').val(folderPath); //編集ボタンのinputのvalue値にフォルダパスを設定

            //配下ページ目次用の配列生成
            $(this)
                .next('ul')
                .find('> li')
                .each(function (e) {
                    let text = $(this).children('a').text();
                    let link = $(this).children('a').attr('href');
                    let subArray = [];

                    pageMokuArray.push({ title: text, link: link });

                    $(this)
                        .children('ul')
                        .children('li')
                        .each(function () {
                            let subtext = $(this).children('a').text();
                            let sublink = $(this).children('a').attr('href');

                            subArray.push({ title: subtext, link: sublink });
                        });
                    //サブページがあれば、配列に追加
                    if (subArray.length) {
                        pageMokuArray[e].sub = subArray;
                    }
                });
        }
    });

    menuConfig();

    function menuConfig() {
        let menuNum = 1;
        $('#menu > li > a').each(function () {
            let menuText = $(this).text();
            $(this).text(menuNum + '. ' + menuText);
            menuNum++;
        });
    }

    markedConfig(); //マークダウン読み込みを最初に実行

    //マークダウン読み込み
    function markedConfig() {
        let t = 0;

        //目次を配列に格納
        let head2Text = [];
        let headNum2 = 0;
        let head3Text = [];
        let headNum3 = 1;
        let headData = [];

        $('#text-markdown h2, #text-markdown h3').each(function () {
            if ($(this).prop('tagName') == 'H2') {
                //H2見出し
                headNum2++;
                let h2Text = $(this).text(); //見出し名取得
                let chap = 'chapter' + headNum2; //見出しidに使う数字
                headNum3 = 1;
                $(this).attr('id', chap); //見出しid名
                head2Text.push(h2Text); //見出しを配列に格納
                headData.push({
                    selector: 'h2',
                    text: h2Text,
                    chapter: chap,
                });
            } else {
                //H3見出し
                let h3Text = $(this).text(); //見出し名取得
                let chap = 'chapter' + headNum2 + '-' + headNum3; //見出しidに使う数字
                $(this).attr('id', chap); //見出しid名
                headData.push({
                    selector: 'h3',
                    text: h3Text,
                    chapter: chap,
                });
                headNum3++;
            }
        });

        let mokujiList;
        const listMax = 20;
        let turmH2 = 20;

        let over = 0;
        Object.keys(headData).forEach(function (key) {
            if (headData[key].selector == 'h2') {
                if (key > headData.length / 2 && over == 0) {
                    //console.log('超えました', key);
                    over = 1;
                    turnH2 = key;
                }
            }
        });

        if (head2Text.length != 0) {
            //h2の見出しがある場合、目次生成
            $('#text-markdown').before('<div id="mokuji"></div>');

            if ($('#mokuji').length) {
                console.log('mokujiあり');
            } else {
                console.log('mokujiなし');
            }

            $('#mokuji').prepend('<h2 class="parts-guide">目次</h2>');

            //リストの数がMAXを超えたら、2列にする。
            if (headData.length > listMax) {
                $('#mokuji').append(
                    '<div class="mokuji-box"><ul id="list-mokuji1"></ul><ul id="list-mokuji2"></ul></div>'
                );

                for (var i = 0; i < turnH2; i++) {
                    if (headData[i].selector == 'h2') {
                        //H2目次リスト
                        $('#list-mokuji1').append(
                            '<li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li>'
                        );
                    } else if (/-1$/.test(headData[i].chapter)) {
                        //H3目次リスト先頭
                        $('#list-mokuji1 > li:last-child').append(
                            '<ul><li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li></ul>'
                        );
                    } else {
                        //H3目次リスト 2番目以降
                        $('#list-mokuji1 > li:last-child ul').append(
                            '<li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li>'
                        );
                    }
                }

                //リスト数がturnH2から2列目のリストに挿入
                for (var i = turnH2; i < headData.length; i++) {
                    if (headData[i].selector == 'h2') {
                        //H2目次リスト
                        $('#list-mokuji2').append(
                            '<li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li>'
                        );
                    } else if (/-1$/.test(headData[i].chapter)) {
                        //H3目次リスト先頭
                        $('#list-mokuji2 > li:last-child').append(
                            '<ul><li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li></ul>'
                        );
                    } else {
                        //H3目次リスト 2番目以降
                        $('#list-mokuji2 > li:last-child ul').append(
                            '<li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li>'
                        );
                    }
                }
            } else {
                $('#mokuji').append(
                    '<ul id="list-mokuji" class="mokuji-list"></ul>'
                );

                for (var i = 0; i < headData.length; i++) {
                    if (headData[i].selector == 'h2') {
                        //H2目次リスト
                        $('#list-mokuji').append(
                            '<li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li>'
                        );
                    } else if (/-1$/.test(headData[i].chapter)) {
                        //H3目次リスト先頭
                        $('#list-mokuji > li:last-child').append(
                            '<ul><li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li></ul>'
                        );
                    } else {
                        //H3目次リスト 2番目以降
                        $('#list-mokuji > li:last-child ul').append(
                            '<li><a href="#' +
                                headData[i].chapter +
                                '">' +
                                headData[i].text +
                                '</a></li>'
                        );
                    }
                }
            }

            // console.log($('#mokuji').outerHeight());
            mokujiHight = $('#mokuji').outerHeight();
        }

        $('#text-markdown a').each(function () {
            //「http」か「https」のとき、target="_blank"を設定
            let href = $(this).attr('href'); //aのhrefの値
            switch (true) {
                case /^http:|^https:/.test(href):
                    $(this).attr('target', '_blank');
                    //外部リンクにアイコンを付ける(任意)「file_icon newtab-icon」のクラスをサイト用のに変更する
                    if (
                        !$(this).children('img').length &&
                        !$(this).find('button').length
                    ) {
                        $(this).addClass('file_icon newtab-icon');
                    }

                    break;
                //ファイルリンクのとき、target="_blank"を設定
                case /.xls$|.xlsx$|.pdf$|.doc$|.zip$|.txt$|.pptx$/.test(href):
                    $(this).attr('target', '_blank');

                    break;
            }

            if ($(this).hasClass('image')) {
                $(this).attr('data-group', 'gallery');
            }
        });

        //配下のページの目次挿入
        if (pageMokuArray.length && $('.auto-mokuji').length) {
            $('.auto-mokuji').html('<ol></ol>');

            pageMokuArray.forEach(function (value) {
                let subHtml = '';

                if (value.sub != undefined) {
                    //サブページがある場合
                    value.sub.forEach(function (e) {
                        subHtml +=
                            '<li><a href="' +
                            e.link +
                            '">' +
                            e.title +
                            '</a></li>';
                    });
                    subHtml = '<ul>' + subHtml + '</ul>';
                }
                //ページに目次挿入
                $('.auto-mokuji ol').append(
                    '<li><a href="' +
                        value.link +
                        '">' +
                        value.title +
                        '</a>' +
                        subHtml +
                        '</li>'
                );
            });
        }
    }

    //ページトップボタン
    //初期は非表示
    $('#parts-pagetop').hide();

    $(window).scroll(function () {
        //140pxスクロールしたら
        if ($(this).scrollTop() > 140) {
            //フェードインで表示
            $('#parts-pagetop').fadeIn();
        } else {
            //フェードアウトで非表示
            $('#parts-pagetop').fadeOut();
        }
    });

    $('#parts-pagetop').click(function () {
        $('body,html').animate(
            {
                scrollTop: 0,
            },
            400
        );
    });

    // //画像にfigureとfigcaptionを設置
    // $('#text-markdown img').each(function (e) {
    //  figureWrap($(this));
    // });

    //画像にfigureとfigcaptionを設置
    $('#text-markdown img').each(function (e) {
        if (!$(this).hasClass('figure-none')) {
            figureWrap($(this));
        }
    });

    $('[data-toggle="tooltip"]').tooltip();
    
    
    //-- タイトル検索 -- //

    var titlePathObj;
    var lockList;

    $.when(
        $.getJSON(
            bathPath + '/public/api/titlePathObj'
        ),

        $.getJSON(
            bathPath + '/public/api/lockList'
        )

    ).done(function (titleData, lockData) {

        // jQueryは [data, status, jqXHR]
        // の配列で返す
        titlePathObj = titleData[0];
        lockList = lockData[0];

        if(lockList.length > 0){
        // if(lockList.length === 0){
            filterLockPage();
        }

    }).fail(function ( jqXHR, textStatus, errorThrown ) {

        console.error(
            '通信エラー:',
            textStatus,
            errorThrown
        );

    });

        
        
    // ロックページ除外処理
    function filterLockPage() {

        titlePathObj = titlePathObj.filter(item => {

            // pages/以下の最初のフォルダ名取得
            const match = item.path.match(/pages\/([^\/]+)/);

            // フォルダ取得できなければ残す
            if (!match) {
                return true;
            }

            const folderName = match[1];

            // lockListと一致確認
            const isLocked = lockList.some(lock => {

                return (
                    lock.page === folderName &&
                    lock.under_dir === 'all'
                );

            });

            // trueなら除外するので反転
            return !isLocked;

        });
    }

        
        
    // 検索ボックス入力時イベント（タイトル用）
    $('#searchBox').on('input', function () {
        var keyword = $(this).val().toLowerCase(); // 小文字で比較
        var searchSelect = '';

        if ($('.searchArea').length > 0) {
            var $searchArea = $('.searchArea');
            searchSelect = $('#search-select').val();
        } else {
            var $searchArea = $('.search-box');
        }

        $searchArea.find('#resultList').remove();
        var pathMatch = true;

        //カテゴリー選択判定
        if (searchSelect !== '') {
            //選択の場合
            var pathKeyword = '/' + searchSelect.split('.')[1] + '/';
            pathMatch = false;
        }

        if (!keyword) return; // 空なら終了

        var results = $.grep(titlePathObj, function (item) {
            var titleMatch =
                item.title.toLowerCase().indexOf(keyword.toLowerCase()) !== -1;

            //カテゴリー選択
            if (searchSelect !== '') {
                //pathにカテゴリのパスが含まれるか判定　含まれていればtrueが返る
                pathMatch = item.path.indexOf(pathKeyword) !== -1;
            }
            //両方がtrueならresultsに格納　検索対象てべての場合、デフォルトでpathMatchはtrue
            return titleMatch && pathMatch;
        });

        if (results.length > 0) {
            var $ul = $('<ul id="resultList"></ul>');

            $.each(results, function (i, item) {
                var $li = $('<li>');
                var $a = $('<a>').attr('href', item.path).text(item.title);
                $li.append($a);
                $ul.append($li);
            });
            $searchArea.append($ul);
        }
        // 結果が空ならulを作らない（上のremoveで削除済み）
    });
    
    
    

    $('#search-select').change(function () {
        $('#searchBox').val('');
        
        if($(this).val()==''){
            $(this).removeClass('is-category');           
        }else{
            $(this).addClass('is-category');
        }

        saveFormState();
    });

    // チェックが変更されたら保存
    $('#fullText').change(function () {
        saveFormState();
    });
    
    
   
    // 開閉ボタンをクリックしたとき
    $('.menu-trigger').on('click', function () {
        // 開閉ボタンがactiveクラスを持っているならば
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');
            $('nav').removeClass('open');
            $('.overlay').removeClass('open');
            // 開閉ボタンがactiveクラスを持っていないならば
        } else {
            $(this).addClass('active');
            $('nav').addClass('open');
            $('.overlay').addClass('open');
        }
    });
    
    // オーバーレイをクリックしたとき
    $('.overlay').on('click', function () {
        // オーバーレイがopenクラスを持っているならば
        if ($(this).hasClass('open')) {
            $(this).removeClass('open');
            $('.menu-trigger').removeClass('active');
            $('nav').removeClass('open');
        }
    });
        
    // //鍵マーク有りのリンクをクリックしたとき
    // $('ul').on('click', 'a.lock', function () {
    //     if (unlock == 0) {
    //         alert('閲覧できません。');
    //         return false;
    //     }
    // });

    // マークダウン用モーダルウィンドウ
    $('a.modal-win').click(function () {
        // body要素の最後にdiv.modal-wrapを追加
        $('body').append('<div class="modal-wrap">');

        // .modal-wrap要素の中にdiv#photoを追加
        $('.modal-wrap').html('<div id="photo">');

        // .modal-wrap要素の中の最後にオーバーレイヤーを設置
        $('.modal-wrap').append('<div class="modal-overlay">');

        // #photoの中にimg要素を追加
        $('#photo').html('<img>');

        // img要素にsrc属性を設定
        $('#photo img').attr('src', $(this).attr('href'));

        // .modal-overlayと#photoをフェードイン
        $('.modal-overlay').fadeIn();
        $('#photo').fadeIn();

        // 背景をクリック
        $('.modal-overlay').click(function () {
            // 背景（自分自身）をフェードアウト、完了したら削除
            $(this).fadeOut(function () {
                $(this).remove();
            });

            // 画像をフェードアウト、完了したら削除
            $('#photo').fadeOut(function () {
                $(this).remove();
                $('.modal-wrap').remove();
            });
        });

        return false;
    });
    
   
    //相互リンクのパスの調整
    async function internalLinkAdjustment() {
        const response = await fetch(bathPath + '/public/api/folderObj');
        const data = await response.json();
        return data;
    }

    (async () => {
        const pathData = await internalLinkAdjustment();
        
        $('.text-markdown a').each(function () {
            let internalPath = $(this).attr('href'); 
            let hasKey = Object.keys(pathData).some(x => x == internalPath);
                        
            if(hasKey){
                $(this).attr('href', pathData[internalPath]['url']);
            }
        });
    })();
    
    
});





//初期表示 セレクトボックスとチェックボックスの設定
function restoreFormState() {
    try {
        const saved = sessionStorage.getItem('filterFormState');
        if (!saved) return; // 保存データなし

        const state = JSON.parse(saved);

        // セレクトボックス
        if (state.category !== undefined && state.category !== null) {
            $('#search-select').val(state.category);
            // $('#search-select').addClass('is-category');
            if($('#search-select').val()==''){
                $('#search-select').removeClass('is-category');           
            }else{
                $('#search-select').addClass('is-category');
            }
        }

        // チェックボックス
        if (typeof state.fullText === 'boolean') {
            $('#fullText').prop('checked', state.fullText);
        }

    } catch (e) {
        console.log(e.message);
    }
}



//「本文内を検索」チェックとカテゴリー選択をセッションストレージに保存
function saveFormState() {
    try {      
        isFullText = $('#fullText').prop('checked');
        const isCategory = $('#search-select').val();

        // sessionStorage に保存
        sessionStorage.setItem(
            'filterFormState',
            JSON.stringify({
                fullText: isFullText,
                category: isCategory,
                time: Date.now()
            })
        );

    } catch (e) {
        console.log(e.message);
    }
}



//画像にfigureとfigcaptionを設置
function figureWrap(e) {
    let clsName = e.closest('div').prop('class');

    if (/^photo/.test(clsName) && e.closest('a').length == 0) {
        if (e.parent()[0].tagName == 'P') {
            e.unwrap();
        }
        e.wrap('<figure>');

        e.attr('');

        if (e.is('[title]')) {
            //title属性がある場合
            let imgTitle = e.attr('title');
            e.after('<figcaption>' + imgTitle + '</figcaption>');
        }
    } else if (/^photo/.test(clsName) && e.closest('a').length > 0) {
        if (e.parents('a').parent()[0].tagName == 'P') {
            e.parents('a').unwrap();
        }
        e.parent('a').wrap('<figure>');

        if (e.is('[title]')) {
            //title属性がある場合
            let imgTitle = e.attr('title');
            e.parent('a').after('<figcaption>' + imgTitle + '</figcaption>');
        }
    } else if (e.closest('a').length == 0) {
        if (e.parent()[0].tagName == 'P') {
            e.unwrap();
        }
        e.wrap('<figure>');

        if (e.is('[title]')) {
            //title属性がある場合
            let imgTitle = e.attr('title');
            e.after('<figcaption>' + imgTitle + '</figcaption>');
        }
    } else if (e.closest('a').length > 0) {
        if (e.parents('a').parent()[0].tagName == 'P') {
            e.parents('a').unwrap();
        }
        //e.wrap('<figure>');
        $(e.closest('a')).wrap('<figure>');

        if (e.is('[title]')) {
            //title属性がある場合
            let imgTitle = e.attr('title');
            //e.after('<figcaption>' + imgTitle + '</figcaption>');
            $(e.closest('a')).after(
                '<figcaption>' + imgTitle + '</figcaption>'
            );
        }
    }
 
}



//replaceAllを独自に作成
function replaceAll(org, search, replace) {
    return org.split(search).join(replace);
}



function imageNumber() {
    galleryNum = 0;
    let galleryOrder;

    $('[data-group="gallery"]').each(function () {
        galleryNum++;

        let dataGallery = $(this).attr('data-gallery-active');
        if ($(this).attr('data-gallery-active')) {
            galleryOrder = galleryNum;
        }
    });

    $('.modaal-container').prepend(
        '<p class="gallery-num">' + galleryOrder + '/' + galleryNum + '</p>'
    );
    $('.modaal-container').append(
        '<p class="gallery-num num-bottom">' +
            galleryOrder +
            '/' +
            galleryNum +
            '</p>'
    );
}

function changeNumber() {
    let galleryOrder;
    let activeCls = $('.is_active.gallery_active_item').attr('class');
    let clsArray = activeCls.split(' ');
    galleryOrder = clsArray[1].replace('gallery-item-', '');
    galleryOrder = Number(galleryOrder) + 1;

    $('.gallery-num').text(galleryOrder + '/' + galleryNum);
}


//ユーザーログインメニュー
document.addEventListener('DOMContentLoaded', () => {
    const menu = document.getElementById('userMenu');
    
    if (document.getElementById('userMenuToggle')) {
        // 要素が存在する場合の処理
        const toggle = document.getElementById('userMenuToggle');
        toggle.addEventListener('click', () => {
            menu.classList.toggle('show');
            toggle.setAttribute('title', 'メニューを閉じる');  
            
        });
        // 外クリックで閉じる
        document.addEventListener('click', (e) => {
          if (!toggle.contains(e.target) && !menu.contains(e.target)) {
            menu.classList.remove('show');
            toggle.setAttribute('title', 'メニューを開く');
          }
        });
    }

});





