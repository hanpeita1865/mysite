<template>
  <div id="app">
    <h1>こんにちは、Vue CLI！</h1>
  </div>
</template>