*[page-title]:カスタム投稿

## カスタム投稿タイプ

参考サイト
: [どこでも簡単！WordPressのカスタム投稿タイプを有効にする方法](https://takayakondo.com/custom-posts/)
: [ちょっと手間取った！WordPressで複数のカスタム投稿タイプを設置する方法](https://takayakondo.com/wordpress-merit/)
: [WordPress自作テーマで投稿を複数作成する方法。関数やコードを実例で解説](https://prograshi.com/wordpress/wp-custom-post/)


<p class="lang">function.php</p>
```

function add_news()
{
	$name = "ニュース";

	$labels = [
		'name' => $name,
		'manu_name' => $name,
		'all_items' => $name . '一覧',
		'add_new' => $name . '追加',
		'singular_name' => $name,
		'not_found' => $name . 'は見つかりませんでした'
	];

	$args = [
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'menu_position' => 5,
		'show_in_rest' => true,//グーテンベルグ使用
	];

	register_post_type('news', $args);
}
add_action('init', 'add_news');


//デフォルトの投稿をブログに変更
function change_menu()
{
	global $menu;
	global $submenu;

	$name = 'ブログ';

	$menu[5][0] = $name;
	$submenu['edit.php'][5][0] = $name . '一覧';
	$submenu['edit.php'][10][0] = $name . '追加';
}
add_action('admin_menu', 'change_menu');

function change_post_page()
{
	global $wp_post_types;
	$name = 'ブログ';

	$labels = &$wp_post_types['post']->labels;

	$labels->add_new = $name . "追加";
	$labels->name = $name;
	$labels->singular_name = $name;
	$labels->add_new = _x($name . 'を追加', $name);
	$labels->add_new_item = $name . 'の新規追加';
	$labels->edit_item = $name . 'の編集';
	$labels->new_item = '新規' . $name;
	$labels->view_item = $name . 'を表示';
	$labels->search_items = $name . 'を検索';
	$labels->not_found = $name . 'が見つかりませんでした';
	$labels->not_found_in_trash = 'ゴミ箱に' . $name . 'は見つかりませんでした';
}
add_action('init', 'change_post_page');
```
1. Gutenbergエディタを使いたい場合は、引数に ‘show_in_rest’ => true, を追記する。
2. has_archiveの値をtrueにすると、静的URLで一覧ページを表示できるようになる。

<p class="result"><span>メニュー表示</span></p>
![](upload/ブログとニュースのメニュー.png)


### labels

管理画面に表示する文字列を指定するプロパティ。

nameで指定した名前が表示されるようになる。singular_nameはnameの単数形を指定する（日本語の場合はnameと同じでOK）。  
他にも主要な項目がある。


|推奨	|項目	|内容	|デフォルト値|
| :--: | -- | -- | --|
|★	|name	|メインの表示名（labelを上書きする）	|投稿|
|☆	|singular_name	|メインの表示名の単数形	|_x( ‘Post Tag’, ‘taxonomy singular name’ )|
|☆	|menu_name	|メニュー内での表示名	|name|
|☆	|all_items	|一覧の表示名	|name|
|☆	|edit_item	|編集画面のタイトル	投稿を編集|
|☆	|new_item	|新規作成画面のタイトル	|新規投稿を追加|
| |view_item	|表示画面のタイトル	|投稿を表示|
| |search_items	|検索ボタンの表示名	|投稿を検索|
| |not_found	|投稿がない時の表示名	|投稿が見つかりませんでした。|
| |not_found_in_trash	|ゴミ箱に投稿がない時の表示名	|ゴミ箱内に投稿が見つかりませんでした。|
| |parent_item_colon	|親の投稿表示名	|親投稿|

★は設定した方がいい項目、☆は推奨項目（私感）。


### public

管理画面上にカスタム投稿タイプを表示し、投稿内容をWEB上で公開する。基本的にはtrueで設定して記述しておくので問題ない。

‘public’ => true にすることで以下の値がtrueに設定される。

![](upload/image-159-1024x416.png)

* show_ui : ユーザーインターフェースを作成する。（管理画面上）
* show_in_nav_menus : ナビゲーションメニュ（グロナビ）で選択可能にする。外観のメニューから設定する。
* show_in_menu :  管理画面にこの投稿タイプを表示する。（show_uiの引数が適用される）
* show_in_admin_bar : 管理画面上部のバーに表示する。 （show_in_menuの引数が適用される）
* publicly_queryable : フロントエンドでpost_typeクエリを実行可能にする。パラメータを（プレビュー機能などに使用）有効化する

なお、‘public’ => false にすると、上記項目がfalseになる。加えて、検索結果から除外するexclude_from_search がtrueになる。