*[page-title]:3-1. イベント関連のディレクティブ

Vue.js（というよりも JavaScript）では、ユーザーの操作ボタンをクリックした、入力値を変更した、 マウスを動かしたなどの操作をトリガー（開始を意味する動作）として、なんらかのコードを実行 するのが一般的です。そして、プログラムが実行されるきっかけとなる出来事のことをイベント、実行されるコードのことをイベントハンドラーと言います。 Vue.js では、イベントハンドラーもまた、ディレクティブを使って設定します。


## 3-1-1 イベントの基本

まずは、イベントを利用した基本的なコードを見てみましょう。以下は、ボタンクリック時に現在時刻を表示するサンプルです。

<p class="tmp list"><span>リスト3-1 / 3-2</span></p>
<iframe height="350" style="width: 100%;" scrolling="no" title="Vue3 リスト3-1、3-2" src="https://codepen.io/hanpeita/embed/ZERzExv?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/ZERzExv">
  Vue3 リスト3-1、3-2</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

http://localhost:7008/chap03/event.html

<p class="tmp"><span>書式</span>v-on ディレクティブ</p>
```
v-on: イベント名="..."
```

リスト 3-1 では構文の「...」の部分にメソッドの名前を指定しており、まずはこれが基本と考えてください。今回の例であれば、ボタンをクリックしたときに呼び出されるべき onclick メソッド(2) を紐付けているわけです。onclick メソッドでは、現在日時を求めたうえで、その値を message プロパティに代入することで、ページに反映させています。

##### 📗<span class="green">別解 イベント処理の記法</span>

リスト 3-1 のclickのコードは、別解として、以下のように表すこともできます。

<span class="bold">a) JavaScript式を直書き </span>
```
<button v-on:click="message = new Date().toLocaleString()">クリック</button>
```

<span class="bold">b) メソッド呼び出し </span>
```
<button v-on:click="onclick()">クリック</button>
```

aは、v-on に JavaScript の式を直書きするパターンです。手軽ですが、テンプレートにコードが混在するため、見通しが悪くなります。動作テストのための暫定的なコードや、ごくシンプルなコードでの利用にとどめ、基本的には独立したメソッドとして切り出しましょう。

bは、元のリスト 3-1 と似ていますが、末尾に「()」が付いている点に注目してください。つまり、元のリスト 3-1 がメソッドの名前を指定しているのに対して、bはメソッド呼び出しの式ということです。

bの構文を利用することで、たとえば
```
v-on:click="onclick('Hoge')"
```
のように、イベントハンドラーになんらかの値を渡すことも可能になります(具体的な例は、後ほど紹介します)。

<div markdown="1" class="note-box">
##### v-on の省略構文 </span>
v-bind と並んで、v-on はよく利用することから、省略構文が用意されています。リスト 3-1 の event.html を省略構文で書き換えると、以下のようになります。
```
<button @click="onclick">クリック</button>
```
どちらを利用しても構いませんが、v-bind のときと同様、アプリの中では記法を揃えることを強くお勧めします。本書では、初学者にも意図を汲み取りやすいよう、本来の「<span class="green bold">v-on: ~</span>」構文を 利用していきます。
</div>

### 3-1-2 Veu.jsで利用できる主なイベント

Vue.js(というよりも JavaScript)で利用できる主なイベントを、以下にまとめておきます。

![](upload/javascriptで利用できる主なイベント.png)

本項ですべてのイベントについて例を挙げることはできませんが、この後、よく利用するものを順に 紹介していきます。

#### マウスの出入りに応じて画像を切り替える
以下は、mouseenter または mouseleave イベントを利用して、画像にマウスポインターが出入りした タイミングで画像を差し替える例です。

<p class="tmp list"><span>リスト3-3 / 3-4</span></p>
<iframe height="450" style="width: 100%;" scrolling="no" title="Vue3 リスト3-3、3-4" src="https://codepen.io/hanpeita/embed/yLEBLdK?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/yLEBLdK">
  Vue3 リスト3-3、3-4</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

http://localhost:7008/chap03/event_mouse.html



#### 補足: mouseenter / mouseleave と mouseover / mouseout の相違点
mouseenter / mouseleave と mouseover / mouseout は、いずれも要素に対してマウスポインターが出入りしたタイミングで発生するイベントですが、その挙動は微妙に異なります。  
具体的な違いは、以下のように、要素が入れ子になる状況で発生します。イベントハンドラーは、外側の要素 (id="outer")に対して設定されているものとします。

<p class="tmp list"><span>リスト3-5 / 3-6</span></p>
<iframe height="450" style="width: 100%;" scrolling="no" title="Vue3 リスト3-5、3-6" src="https://codepen.io/hanpeita/embed/yLEBLmK?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/yLEBLmK">
  Vue3 リスト3-5、3-6</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/event_mouse2.html


`v-on:mouseenter="onmousein" v-on:mouseleave="onmouseout">`の場合  
枠の中を横切ると、「Enter:outer」と「Leave:outer」が表示される。
<p class="result"><span>結果</span></p>
![](upload/Enter_outer_Leave_outer.png)

`v-on:mouseover="onmousein" v-on:mouseout="onmouseout">`の場合  
<http://localhost:7008/chap03/event_mouse2_1.html>  
枠を出る時にも、表示される。
<p class="result"><span>結果</span></p>
![](upload/outer_inner.png)

上の2つを比べてみるとわかるように、mouseenter / mouseleave イベントは対象となる要素の出入りに際してのみ発生しますが、mouseover / mouseout イベントは内側の要素に出入りしたときにも発生します。 思わぬ挙動に悩まないためにも、双方の違いを理解しておきましょう。

#### 画像が読み込めない場合にダミー画像を表示する
以下では、error イベントを利用して、&lt;img&gt;要素で指定の画像が正しく読み込めなかった場合に、代替の画像を表示します。

<p class="tmp list"><span>リスト3-7</span></p>
```
<div id="app">
  <img v-bind:src="path" v-on:error="onerror" />
</div>
```

<p class="tmp list"><span>リスト3-8</span></p>
```
Vue.createApp({
  data() {
    return {
      path: './images/wings.jpg'
    };
  },
  methods: {
    onerror() {
      this.path = './images/noimage.jpg';
    }
  }
}).mount('#app');
```

http://localhost:7008/chap03/event_error.html

![](upload/No_Image.png)

wings.jpg を正しく配置した場合には、本来の画像が表示されることもあわせて確認しましょう。


## 3-1-3 イベントオブジェクト

<span class="green bold">イベントオブジェクト</span>とは、その名のとおり、イベントにかかわる情報を管理するためのオブジェクトで、JavaScript によって自動生成されます。イベントオブジェクトを利用することで、イベントに関する情報(発生したイベントの種類や発生元など)にアクセスしたり、イベントハンドラーの挙動を操作したり(キャンセルなど)、といったことが可能になります。  
イベントハンドラーからイベントオブジェクトを参照するには、イベントハンドラーの第1引数に「e」 や「ev」を設置しておくだけです。たとえば以下は、ボタンクリック時にイベントオブジェクトを口グ出力する例です。

<p class="tmp list"><span>リスト3-9 / 3-10</span></p>
http://localhost:7008/chap03/event_obj.html
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-9、3-10" src="https://codepen.io/hanpeita/embed/bGKbNeo?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/bGKbNeo">
  Vue3 リスト3-9、3-10</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

<p class="result"><span>結果</span>codepenのコンソール表示</p>
![](upload/codepen_click_log.png)

イベントオブジェクトが提供する情報は、元となるイベントの種類によって変化します。次の表に、主なものをまとめておきます。
![](upload/イベントオブジェクトの主なメンバー.png)

### 例:イベント発生時のマウス情報を取得したい
上の表を見てもわかるように、イベントオブジェクトでは、イベント発生時の座標を取得するために 複数の xxxxxX、xxxxxY プロパティを持っています。これらのプロパティは、どこを基点とした座標を返すかが異なります。

![](upload/マウス座標に関するプロパティ.png)


具体的な例でも、座標の違いを確認してみましょう。  
ボックスの中を移動すると、座標が変化します。

<p class="tmp list"><span>3-11 / 3-12</span></p>
http://localhost:7008/chap03/event_point.html

<iframe height="570" style="width: 100%;" scrolling="no" title="Vue3 リスト3-11、3-12" src="https://codepen.io/hanpeita/embed/XWYrJjG?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/XWYrJjG">
  Vue3 リスト3-11、3-12</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>


### イベントハンドラーに任意の引数を渡す
以上、ここまでは標準的な JavaScript と同じなので、JavaScript に慣れている人であれば、迷うとこ ろはないはずです。しかし、イベントハンドラーになんらかの値を引き渡す場合には、どうでしょう。 たとえば以下は、クリック時に引数経由で渡した文字列をログ出力する例です。

<p class="tmp list"><span>リスト3-13 / 3-14</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-13、3-14" src="https://codepen.io/hanpeita/embed/ZERzYBm?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/ZERzYBm">
  Vue3 リスト3-13、3-14</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

http://localhost:7008/chap03/event_args.html

![](upload/event_args_ようこそ!.png)

この状態では、第1引数が他の値で埋められてしまうので、イベントオブジェクトを参照することができません。  
では、どうするのか。呼び出し側で、明示的に $event(イベントオブジェクト)を渡してやります。 $event は Vue.js で決められた名前で、固定です。

<p class="tmp list"><span>リスト3-15 / 3-16</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト3-15、3-16" src="https://codepen.io/hanpeita/embed/LYrPEWE?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/LYrPEWE">
  Vue3 リスト3-15、3-16</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
http://localhost:7008/chap03/event_args2.html

![](upload/event_args2_ようこそ!_isTrusted.png)

これで、第2引数以降でイベントオブジェクトを受け取り、イベントハンドラーの配下でも参照でき るようになります。

<div markdown="1" class="note-box">
##### イベントオブジェクトのさらなる理解のために 
イベント処理において、イベントオブジェクトは肝とも言うべきテーマです。さらに、Vue.js (v-on)ではイベントオブジェクトをより簡単に利用するために、修飾子と呼ばれるしくみを提供しています。これらのテーマは本格的にアプリを開発するうえでは欠かせないものですが、 イベントのより深い理解が前提となるため、3-5 節であらためて解説します。
</div>
