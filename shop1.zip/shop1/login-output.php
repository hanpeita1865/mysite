<?php
unset($_SESSION['user']);
$pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');

$sql=$pdo->prepare('select * from user where user_name=? and password=?');

//パスワードハッシュ化
//$loginPass = hash("sha256", $_REQUEST['password']);

$loginPass =$_POST['password'];

$sql->execute([$_POST['user_name'], $loginPass]);

session_start();

//同じユーザ名でログインされてるか確認
if(isset($_SESSION['user'])){
    if($_SESSION['user']['user_name']==$_POST['user_name'] && $_SESSION['user']['password']==$_POST['password']){
        $_SESSION['flash']['success'] = '既に「'.$_POST['user_name'].'」さんでログインしています。';
        header('Location:index.php');
        exit();  
    }    
}

//セッションにユーザーID、ユーザ名、パスワードを登録
foreach ($sql->fetchAll() as $row) {
    $_SESSION['user']=[
        'id'=>$row['user_id'], 
        'user_name'=>$row['user_name'], 
        'password'=>$row['password']];
}

//ログイン成功時と失敗時の分岐処理
if (isset($_SESSION['user'])) {
    $_SESSION['flash']['success'] = 'ログインに成功しました。';
    session_regenerate_id();//ログイン後にセッションIDの再発行
    header('Location:index.php');
    exit();

} else {
    $_SESSION['flash']['error'] = 'ユーザ名またはパスワードが間違っています。';
    header('Location:login.php');
    exit();
}
?>