<?php
namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Container\ContainerInterface;

require '../admin/basepath.php';

class MemberController {
    // コンテナインスタンス
    private $container;

    // コンストラクタ
    public function __construct(ContainerInterface $container) {
        // 引数のコンテナインスタンスをプロパティに格納。
        $this->container = $container;
    }


    //マークダウン変換
     public function markData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        global $basePath;
        global $folderName;

        //PDOインスタンスをコンテナから取得
        $db = $this->container->get("db");

        $ipAddress = $_SERVER["REMOTE_ADDR"];//取得したIPアドレス
        $folderName = basename($_SERVER['REQUEST_URI']);//フォルダ名


        //URL中のパラメータを取得
        $folder = $args["folderName"];//フォルダ名を取得

        $assign["folder"] = $folder;//配列に格納

        if(empty($_SERVER['HTTP_REFERER'])){
            //echo '未定義';
            $motourl = '../pages/p__base/';
        }else{
            $motourl = $_SERVER['HTTP_REFERER'];//遷移元のURL
        }

        $sql_page = $db->prepare('select * from locklist where page=?');
        $sql_page->execute([$folderName]);

        $countPage=$sql_page->rowCount();

        $sql_ip = $db->prepare('select * from admin_ip where ip_address=?');
        $sql_ip->execute([$ipAddress]);

        $countIp=$sql_ip->rowCount();

        //閲覧不可ページリスト
        $stmt = $db->prepare('select page from locklist');
        $stmt->execute();
        $lockArray = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $assign["lockArray"] = $lockArray;

        $assign["countIp"] = $countIp;

        if($countPage!=0 && $countIp==0 ) {
            header('Location:'. $motourl, true, 307);
            $flag = 0;//閲覧不可
            exit;
        }

        //フォルダ構成をオブジェクトで取得
        $folderObj = $this->container->get("folderComp");

        //マークダウン変換インスタンスをコンテナから取得
        $markData = $this->container->get("mark");

        $htmlData = $markData['html'];//HTMLデータ
        $title = $markData['title'];//タイトル

        $assign["folderObj"] = $folderObj;//フォルダ構成オブジェクト
		$assign["htmlData"] = $htmlData;//記事内容
        $assign["title"] = $title;//タイトル格納
		$assign["pathBase"] = $basePath;

        // Twigインスタンスをコンテナから取得。
        $twig = $this->container->get("view");
        
        // templateのbase.twigからをHTMLを生成。
        $response = $twig->render($response, "base.twig", $assign);

        // レスポンスオブジェクトをリターン。
        return $response;
    }


    //管理画面
    public function adminData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        // Twigインスタンスをコンテナから取得。
        $twig = $this->container->get("view");

        $menuData = file_get_contents('./../templates/layouts/menu_list.twig');

        $assign["menuData"] = $menuData;//メニューリスト
        
        // templateのadmin.twigからを管理画面を生成。
        $response = $twig->render($response, "admin.twig", $assign);     

        return $response;
    }

}