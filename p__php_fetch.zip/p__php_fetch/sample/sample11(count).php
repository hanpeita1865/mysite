<?php

try {

  $pdo = new PDO('sqlite:db/fetch_db.sqlite3');

  /*$stmt = $pdo->prepare('SELECT name FROM users WHERE id = 4');
  $stmt->execute();
  $name = $stmt -> fetch(PDO::FETCH_COLUMN);
  echo $name;*/

  $sql = 'SELECT COUNT(*) FROM users';
  $sth = $pdo -> query($sql);
  $count = $sth -> fetch(PDO::FETCH_COLUMN);
  echo '件数は'.$count.'件です';  
  
} catch (Exception $e) {
    error_log('障害が発生しており、ご迷惑をおかけしています。');
}

?>