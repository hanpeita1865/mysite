const ImageTool = window.ImageTool;

const url = 'data.json';

fetch(url)
.then(function (response) {
	return response.json();
})
.then(function (json) {

	const editor = new EditorJS({
		holder: 'editorjs',
		tools: {

			header: {
				class: Header,
				inlineToolbar: ['marker', 'link'],
				config: {
					placeholder: 'Header'
				},
				shortcut: 'CMD+SHIFT+H'
			},

			// image: SimpleImage,

			image: {
				class: SimpleImage,
				inlineToolbar: ['link']
			},
	
			list: {
				class: List,
				inlineToolbar: true,
				shortcut: 'CMD+SHIFT+L'
			},
	
			checklist: {
				class: Checklist,
				inlineToolbar: true,
			},
	
			quote: {
				class: Quote,
				inlineToolbar: true,
				config: {
					quotePlaceholder: 'Enter a quote',
					captionPlaceholder: 'Quote\'s author',
				},
				shortcut: 'CMD+SHIFT+O'
			},
	
			warning: Warning,
	
			marker: {
				class: Marker,
				shortcut: 'CMD+SHIFT+M'
			},
	
			code: {
				class: CodeTool,
				shortcut: 'CMD+SHIFT+C'
			},
	
			delimiter: Delimiter,
	
			inlineCode: {
				class: InlineCode,
				shortcut: 'CMD+SHIFT+C'
			},
	
			linkTool: LinkTool,
	
			embed: Embed,
	
			table: {
				class: Table,
				inlineToolbar: true,
				shortcut: 'CMD+ALT+T'
			},


			// image: {
			// 	class: ImageTool,
			// 	config: {
			// 		endpoints: {
			// 			// byFile: 'http://localhost:8008/uploadFile', // Your backend file uploader endpoint
			// 			byFile: 'http://localhost:7001/test/editor_js/demo10/images', // Your backend file uploader endpoint
			// 			// byUrl: 'http://localhost:8008/fetchUrl', // Your endpoint that provides uploading by Url
			// 		}
			// 	}
			// }



			// image: {
			// 	class: ImageTool,
			// 	config: {
			// 	  /**
			// 	   * Custom uploader
			// 	   */
			// 	  uploader: {
			// 		/**
			// 		 * Upload file to the server and return an uploaded image data
			// 		 * @param {File} file - file selected from the device or pasted by drag-n-drop
			// 		 * @return {Promise.<{success, file: {url}}>}
			// 		 */
			// 		uploadByFile(file){
			// 		  // your own uploading logic here
			// 		  return MyAjax.upload(file).then(() => {
			// 			return {
			// 			  success: 1,
			// 			  file: {
			// 				url: 'http://localhost:7001/test/editor_js/demo10/images/river.jpg'
			// 				// any other image data you want to store, such as width, height, color, extension, etc
			// 			  }
			// 			};
			// 		  });
			// 		},
		  
			// 		/**
			// 		 * Send URL-string to the server. Backend should load image by this URL and return an uploaded image data
			// 		 * @param {string} url - pasted image URL
			// 		 * @return {Promise.<{success, file: {url}}>}
			// 		 */
			// 		uploadByUrl(url){
			// 		  // your ajax request for uploading
			// 		  return MyAjax.upload(file).then(() => {
			// 			return {
			// 			  success: 1,
			// 			  file: {
			// 				url: 'http://localhost:7001/test/editor_js/demo10/images/flex_imae.png'
			// 				// any other image data you want to store, such as width, height, color, extension, etc
			// 			  }
			// 			}
			// 		  })
			// 		}
			// 	  }
			// 	}
			// }

	
		},
		data :json
	});


	const saveButton = document.getElementById('saveButton');//保存ボタン

	//データ保存
	saveButton.addEventListener('click', function () {
	
		editor.save().then((outputData) => {
			console.log(outputData);
			fetch('save.php', {
				method: 'post',
				body: new URLSearchParams({// 送信する値
					data: JSON.stringify(outputData),//文字列化して送信
				})
			}, { cache: 'no-store' })
				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response;
				})
				.then(response => response.text())
				.then(data => {
					alert('保存しました。')
				})
				.catch(() => {
					console.log('エラー')
				})
	
		}).catch((error) => {
			console.log('Saving failed: ', error)
		});
	
	});

})

