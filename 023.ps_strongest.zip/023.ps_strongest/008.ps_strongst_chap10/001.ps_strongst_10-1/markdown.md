*[page-title]:10-1. フィルターを使ってみよう

## フィルターを適用する ## {.sr-only}
<div markdown="1" class="sr-only"></div>
<div markdown="1" class="photo-capture">
[![](upload/10-01-1.jpg)](upload/10-01-1.jpg){.image}
</div>

## フィルターギャラリー ## {.sr-only}
<div markdown="1" class="sr-only"></div>
<div markdown="1" class="photo-capture">
[![](upload/10-01-2.jpg)](upload/10-01-2.jpg){.image}
</div>