*[page-title]:日時取得・計算 new Date()

参考サイト
: [JavaScript 現在日時を取得するサンプル](https://itsakura.com/js-date)
: [JavaScript 日時の計算のサンプル(加算と減算)](https://itsakura.com/javascript-date)
: [JavaScript 日時の差分を求めるサンプル](https://itsakura.com/javascript-diffdate)
: [JavaScript - 日付/時刻比較、3つの方法](https://codechacha.com/ja/javascript-compare-dates/)
: [Dateオブジェクトのインスタンスを作成する](https://www.javadrive.jp/javascript/date_class/index1.html)
: [【JavaScript入門】toStringで数値を文字列に変換(日付/基数変換)](https://www.sejuku.net/blog/48279)


## 現在日時を個別のメソッドで取得する

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	現在日時を個別のメソッドで取得するサンプルです。
<script async src="//jsfiddle.net/hirao/j0qhzc95/3/embed/js,result/"></script>
</div>

1行目は、曜日の配列です。  
3行目は、Dateオブジェクトを生成しています。  
5～11行目は、個別に値を取得しています。  
5行目のgetMonthは、0から始まります。1月のときは0が返ります。そのため+1しています。  
11行目のgetDayは、曜日が数字で返ってきます。0は日曜日で、6は土曜日です。  
16,17行目は、sliceメソッドで頭ゼロを付与しています。  
18行目は、YYYYMMDDで出力されます。


## 現在日時を取得しtoLocaleStringでフォーマット変換する

<p class="tmp"><span>書式</span>toLocaleString 時分秒をカンマ区切りで取得</p>
```
Dateオブジェクト.toLocaleString()
```

<div class="exp">
	<p class="tmp"><span>例2</span>toLocaleString</p>
	<script async src="//jsfiddle.net/hirao/rg28jkc4/1/embed/js,result/"></script>
</div>

1行目は、Dateオブジェクトを生成しています。  
3行目は、toLocaleStringメソッドで年月日をスラッシュ区切りで、時分秒をカンマ区切りで表示しています。

toLocaleStringメソッドは、サポートされていないブラウザもあります。


## JavaScript 日時の計算のサンプル(加算と減算)

### 年の計算

<div class="exp">
	<p class="tmp"><span>例3</span></p>
	３年前/後を求める
<script async src="//jsfiddle.net/hirao/39tgcjLr/2/embed/js,result/"></script>
</iframe>
</div>

3年前を求める場合は、6行目の+3を-3にマイナスします。

### 月の計算

<div class="exp">
	<p class="tmp"><span>例4</span></p>
	３ヶ月前/後を求める。2017/10の3ヶ月後を求めるサンプルです。
<script async src="//jsfiddle.net/hirao/yutsrL0z/1/embed/js,result/"></script>
</iframe>
</div>

3ヶ月前を求める場合は、6行目の+3を-3にします。

注：2017/1/30のgetMonth + 1は、2017/3/2となります。(2017/2は、2/28までのため)  
日付を指定して月を計算する場合は、月初を求めてからgetMonthメソッドを使用して下さい。

### 日の計算

<div class="exp">
	<p class="tmp"><span>例5</span></p>
	３日前/後を求める。2017/1/2の3日前を求めるサンプルです。
<script async src="//jsfiddle.net/hirao/k34jnwba/2/embed/js,result/"></script>
</iframe>
</div>

3日後を求める場合は、6行目の-3を+3にします。

### 時分秒の計算

<div class="exp">
	<p class="tmp"><span>例6</span></p>
	2017/12/31 22:00の３時間後(+分/秒)を求めるサンプルです。
<script async src="//jsfiddle.net/hirao/47om91c2/1/embed/js,result/"></script>
</iframe>
</div>

## 月初を取得する

<span class="green bold">setDate(1)</span>で月初を取得できます。

<div class="exp">
	<p class="tmp"><span>例7</span></p>
2017年2月22日の月初を表示するサンプルです。
<script async src="//jsfiddle.net/hirao/0Lw2aksz/1/embed/js,result/"></script>
</iframe>
</div>

6行目で、setDateメソッドの引数に1をセットして月初を求めます。

## 月末を取得する

<span class="green bold">setDate(0)</span>で、前月の末日を取得することができます。

<div class="exp">
	<p class="tmp"><span>例8</span></p>
2017年2月22日の月末を表示するサンプルです。
<script async src="//jsfiddle.net/hirao/0687syz2/4/embed/js,result/"></script>
</iframe>
</div>

5行目でsetDate(1)とする理由
: 2017/1/30のgetMonth + 1は、2017/3/2となります。(2017/2は、2/28までのため)  
日付を指定して月を計算する場合は、月初を求めてからgetMonthメソッドを使用します。


## 日時の差分を求める

<div class="exp">
	<p class="tmp"><span>例9</span></p>
日数と時間の差分を求めるサンプルです。2018/1/2から2017/12/31の差分を求めます。
<script async src="//jsfiddle.net/hirao/gtbhc3ky/2/embed/js,result/"></script>
</iframe>
</div>

2行目で、2018,0,2(設定する月は-1にする)をセットしてDateオブジェクトを作成します。  
6行目で、2017,11,31(設定する月は-1にする)をセットしてDateオブジェクトを作成します。  
10行目は、それぞれgetTime()メソッドを使用した値を引いて経過ミリ秒を求めます。  
13行目は、ミリ秒を日に変換しています。floorメソッドは小数点以下を切り捨てます。  
17行目は、ミリ秒を時間に変換しています。floorメソッドは小数点以下を切り捨てます。

## 日付を文字列に変換する方法

日付（Dateオブジェクト）から文字列への変換も、数値の変換と同様に<span class="green bold">toStringメソッド</span>が利用できます。
<p class="tmp list"><span>リスト</span></p>
```
const date = new Date(); // 今日の日付
console.log("今日：" + date.toString());
console.log("今日：" + date.toISOString());
```

<p class="result"><span>実行結果</span></p>
```
> "今日：Tue Apr 10 2018 00:00:00 GMT+0900 (JST)"
> "今日：2018-04-09T15:00:00.000Z" // ISO形式
```

また、ISO規格のフォーマットで出力するための<span class="green bold">toISOStringメソッド</span>も用意されています。


## 日付を比較

### 比較演算子(>、>=、<、<=)で日付/時刻比（Date オブジェクト）
比較演算子で 2 つの Date オブジェクトのサイズを比較できます。ある Date オブジェクトが他のオブジェクトより大きいということは、時間的に前にあるという（未来）意味です。 逆に、サイズが小さいということは、時間的に過去という意味です。


<p class="tmp list"><span>リスト</span></p>
```
const date1 = new Date('2022-05-04');
const date2 = new Date('2022-05-05');

console.log(date1 > date2);//false
console.log(date1 >= date2);//false
console.log(date1 < date2);//true
console.log(date1 <= date2);//true

console.log(date1 == date1)//false  等価演算子は常にfalseを返します
console.log(date1 <= date1)//true  こちら（以上、以下）を使った場合は、trueになる
```

<p class="result"><span>実行結果</span></p>
```
false
false
true
true
false
true
```

### Date.getTime() で日付/時刻比
Date.getTime() は UTC 時間を millisecond として返します。 UTCは「1970/01/01」を0秒でこれまで流した時間を表現したものです。 millisecondなので、比較演算子を使用してサイズを比較することができ、また<span class="red bold">同等演算子で比較することもできます</span>。

<p class="tmp list"><span>リスト</span></p>
```
const date4 = new Date('2022-05-04');
const date5 = new Date('2022-05-05');

console.log(date4.getTime());//1651622400000
console.log(date5.getTime());//1651708800000

console.log(date4.getTime() > date5.getTime());//false
console.log(date4.getTime() >= date5.getTime());//false
console.log(date4.getTime() < date5.getTime());//true
console.log(date4.getTime() <= date5.getTime());//true
console.log(date4.getTime() == date5.getTime());//false
console.log(date4.getTime() == date4.getTime());//true ←同じdate4を比較
```

<p class="result"><span>実行結果</span></p>
```
1651622400000
1651708800000
false
false
true
true
false
true
```


### 同じ日付(年/月/日)か比較する
Dateには日付と時刻の両方の情報があります。時間は無視して日付のみを比較したい場合は、日付情報のみを取得して比較できます。 getFullYear(), getMonth(), getDate() で年/月/日情報を取得できます。この情報のサイズを比較してください。

以下の例は、時間は比較せず、日付のみが同じかどうかを比較する例です。

<p class="tmp list"><span>リスト</span></p>
```
const isSameDate = (date1, date2) => {
  return date1.getFullYear() === date2.getFullYear()
     && date1.getMonth() === date2.getMonth()
     && date1.getDate() === date2.getDate();
}

const date1 = new Date('2022-05-04 12:20:30');
const date2 = new Date('2022-05-04 15:30:40');
const date3 = new Date('2022-05-05 15:30:40');

console.log(isSameDate(date1, date2));//true
console.log(isSameDate(date2, date3));//false
```

<p class="result"><span>実行結果</span></p>
```
true
false
```














