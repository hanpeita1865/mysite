// 管理画面共通データを取得
export function getAdminData() {
    const app = document.getElementById('app');
    const body = document.body;

    const pathBase = body.dataset.pathBase;

    if (app) {
        return {
            pageArea: app.dataset.pageArea,
            adminFull: app.dataset.adminFull
        };
    }

    return {
        pageArea: 'normal',
        adminFull: pathBase + '/public/admin/'
    };
}