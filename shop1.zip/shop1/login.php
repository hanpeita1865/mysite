<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ログイン画面</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php
//セッションの開始
session_start();

//フラッシュメッセージ
if( isset($_SESSION['flash']['error']) ){
	$flash_error = $_SESSION['flash']['error'];
}

unset($_SESSION['flash']);

if (isset($flash_error)){
	echo '<p class="feedback">'.$flash_error.'</p>';
}
?>

<form action="login-output.php" method="post" id="login-form">
	<h1>ログイン</h1>
	<dl>
		<dt>ユーザー名</dt>
		<dd><input type="text" id="user" name="user_name" value=""><span></span></dd>
		<dt>パスワード</dt>
		<dd><input type="password" id="pass" name="password" value=""><span></span></dd>
	</dl>
	<p class="submit"><input type="submit" id="login-button" value="ログイン"></p>
</form>

</body>
</html>