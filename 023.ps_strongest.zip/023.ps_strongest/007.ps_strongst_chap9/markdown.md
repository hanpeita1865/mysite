*[page-title]:第9章 パスとシェイプの操作

### 第9章 目次
<div markdown="1" class="page-mokuji auto-mokuji">
</div>