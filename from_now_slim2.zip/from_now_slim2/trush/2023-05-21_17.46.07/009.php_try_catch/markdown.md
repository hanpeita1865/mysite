*[page-title]:例外処理(try...catch、throw)

参考サイト
: [【PHP入門】エラーと例外処理](https://medium-company.com/php-%E3%82%A8%E3%83%A9%E3%83%BC%E3%81%A8%E4%BE%8B%E5%A4%96%E5%87%A6%E7%90%86/)

![](upload/try-catch.png)

<span class="red bold">正常時の流れ</span>
1. try内の処理を実行
2. finally内の処理を実行（finallyは省略可能なのでfinallyが存在する場合のみ実行）

<span class="purple bold">例外発生時の流れ</span>
1. try内の処理を実行
2. 例外発生（例外が発生した時点でtry内の処理は中断しcatch文へ）
3. catch内の処理を実行
4. finally内の処理を実行（finallyは省略可能なのでfinallyが存在する場合のみ実行）

### try-catchの実装例
それでは、実際にソースコードで try-catch の使用例を紹介します。

PHPでは throw された例外（Exception）しか catch できません。（ただのエラーは catchできない）

[エラーをcatchできないケース]
```
<?php

try {
    // 警告のエラーを発生させる（存在しないファイルを指定）
    $fd = fopen("c:/temp/abc.txt","r");

} catch (Exception $e) {
    echo "例外が発生しました。".$e->getMessage();
}

?>
```

<p class="result"><span>結果</span></p>
```
Warning: fopen(c:/temp/abc.txt): Failed to open stream: No such file or directory in C:\xampp\htdocs\phpSample\lesson22\tryCatchSample.php on line 5
```

例外ではない ただのエラーをcatchするためには、「set_error_handler()」関数を使用します。エラーを「set_error_handler()」関数でハンドリングし、「set_error_handler()」関数内で例外を発生させます。

[try-catchの実装例]
```
<?php

// エラー時に例外をスローするように登録
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno)) {
        return;
    }
    throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
});

try {
    // 警告のエラーを発生させる（存在しないファイルを指定）
    $fd = fopen("c:/temp/abc.txt","r");

} catch (Exception $e) {
    echo "例外が発生しました。".$e->getMessage();
}
?>
```

<p class="result"><span>結果</span></p>
```
例外が発生しました。fopen(c:/temp/abc.txt): Failed to open stream: No such file or directory
```

<span class="green bold">エラー発生時の流れ</span>
1. try内の処理を実行
2. エラー発生（エラーが発生したのでset_error_handler()で登録した関数へ）
3. set_error_handler() で登録した関数の処理を実行（関数内で例外を発生させる。例外が発生したのでcatch文へ）
4. catch内の処理を実行
5.finally内の処理を実行（finallyは省略可能なのでfinallyが存在する場合のみ実行）



## 例外処理を付ける

<p class="tmp"><span>書式1</span>try...catch構文</p>
```
try {
   実行する処理
} catch ( 例外のクラス 変数 ) {
   実行する処理
} finally{
 実行する処理
}
```
* 例外が起こる可能性がある箇所をtryブロックで囲みます。
* 例外が発生しcatchブロックの引数の例外のクラスの型と同じときにcatchブロックの処理が行われます。
* PHP 5.5 以降ではfinallyブロックも指定できます。finallyブロックは例外のあるなしにかかわらず常に実行されます。
* 以下はPHPマニュアルの例外(exceptions)のリンクです。

<https://www.php.net/manual/ja/language.exceptions.php>


<p class="tmp"><span>書式2</span>throw文</p>
```
throw new 例外
```
* 任意の場所で例外を投げることができます。
* 例外は以下である必要があります。
	* Exceptionクラス
	* Exceptionクラスのサブクラス

try...catch構文とthrow文のサンプルです。  
$num2に0を設定すると、例外処理が実行され「エラーです」が付け足されます。
<!--
<iframe src="https://paiza.io/projects/e/gVzMc4SshnEvE6iAhBSzrA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
-->
<iframe src="https://paiza.io/projects/e/76_RguPPjAbu47zIAnWPqg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

* 6行目は、例外が起こる可能性がある関数をtryブロックで囲んでいます。
* 16行目は、throw文で例外を投げています。Javaと違いここでthrowが必要です。
* 9行目は、例外をcatchしメッセージを表示します。「エラーです」
* 12行目は、finallyブロックでメッセージが表示されます。「処理が終了しました」