*[page-title]:Chap2 Veu.jsの基本

サンプル
: http://localhost:7008/chap02/ファイル名

下書き
: 「<span class="green bold">C:\xampp\htdocs\from_now\trunk\pages\p__vue_3_chap2\files</span>」内 <span class="red bold">chap2_下書き.rtf</span>

## 2-1 Vue.jsを利用するための準備
Vue.js を利用するには、CDN (Content Delivery Network") 経由でライブラリをインポートするのが、 最も手軽です。リスト 2-1 は、 Vue.js を利用するための最低限の構成です。
<p class="tmp list"><span>リスト2-1</span>template.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8" />
    <title>Vue.js</title>
</head>
<body>
    <!--ページ本体-->
    <script src="https://cdn.jsdelivr.net/npm/vue@3.2.29/dist/vue.global.js"></script> <!-- (1) -->
    <script src="js/template.js"></script>
</body>
</html>
```

(1)のライブラリ読み込み部分は、 利用するバージョンに応じて替えてください。 ここでは、ver3.2.29にしています。 また、(1)で指定しているアドレスは、デバッグ用のファイルです。 コメントや改行、 タブが含まれているので、コードの可読性には優れますが、 ファイルサイズは大きくなります。  
本番環境で利用する場合は、以下のように置き換えてください。
```
<script src="https://cdn.jsdelivr.net/npm/vue@3.2.29/dist/vue.global.prod.js"></script>
```
vue.global.prod.js は、コメントや改行を除去することでファイルサイズを最小化しただけのもので、 (1)で指定したものと機能に違いはありません。

<div markdown="1" class="note-box">
##### Vue CLI / Vite
より本格的な開発には、アプリの雛形生成からビルドまでを管理するためのコマンドライン ツールとして、Vue CLI / Vite などの利用をお勧めします。  
ただし、こちらは中規模以上の アプリ開発に向いたアプローチで、最初から無理して導入すべきものではありません。
最初は小規模に、必要に応じて Progressive (段階的)に成長させていけばよいのです(公式 サイトでも、初心者による Vue CLI の導入は推奨していません)。  
その前提で最初 はツールなしで学習を進め、 Vue CLI / Vite については第7章「Vue CLI」であらためて解説します。
</div>

<!--
<div markdown="1" class="sr-only"></div>
<div markdown="1" class="photo-capture">
[![](upload/2-1.jpg)](upload/2-1.jpg){.image}
</div>
-->

### 2-1-1 Vue.jsアプリの実行

実際にVue.js経由で「皆さん、こんにちは!」というメッセージを表示してみます。

<p class="codepen" data-height="300" data-default-tab="html,result" data-slug-hash="ZEorMWL" data-user="hanpeita" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/hanpeita/pen/ZEorMWL">
  Vue3 リスト2-2、2-3</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>


<p class="tmp list"><span>リスト2-2</span>hello.html</p>
```
<div id="app">
  <p>{{ message }}</p> <!-- (3) -->
</div>
```
<p class="tmp list"><span>リスト2-3</span>hello.js</p>
```
Vue.createApp({ //-----(1)
  data: function() { //-----(2)
    return {
      message: '皆さん、こんにちは！'
    };
  }
}).mount('#app');
```

##### <span class="marker-yellow50">(1) Vue.jsの核となるのはVueクラス</span> #####

<p class="tmp"><span>書式</span>アプリの起動</p>
```
Vue.createApp({
	name: value,･･･
}).mount(el);
```

<div markdown="1" class="dl-float">
name: 
: オプション名

value: 
: 値

el: 
: Vue.jsを適用する要素
</div>

<span class="green bold">createApp</span> は、<span class="green bold">アプリケーションインスタンス</span>（アプリインスタンス）を生成するためのメソッドです。 アプリインスタンスとは、Vue アプリを管理するためのオブジェクトで、<span class="red">アプリの起動/終了</span>、<span class="red">アプリ構成の定義</span>などの役割を担います。  
この例であれば、mount メソッドで Vue アプリを「id="app" である要素」に紐づけて（=アプリを 起動して）います。これをアプリを<span class="green bold">マウント</span>すると言います。

##### <span class="marker-yellow50">(2) Vue.jsの動作オプション</span> #####

createApp メソッド配下の<span class="red"> {name: value, ...} </span>は、<span class="green bold">ルートコンポーネント</span>の動作オプションです。 コンポーネントは、Vue.js アプリを構成する UI 部品です。ルートコンポーネントは、その最上位（おおもと）に位置するコンポーネントです。利用できるオプションはさまざまありますが、ここでは最低限、data オプションだけを指定しておきましょう。<span class="red"> data オプション</span>は、テンプレート(HTML)から参照できる値を格納したオブジェクトを表します （<span class="green bold">データオブジェクト</span>とも言います）。  
ただし、書き方に少し癖があります。というのも、オブジェクトそのものではなく、「<span class="red">オブジェクト を返す関数</span>」を渡さなければなりません。


##### <span class="marker-yellow50">(3) データオブジェクトにアクセスする</span> #####

テンプレートからデータオブジェクトにアクセスするには、<span class="red">{{ ... }} </span>という構文を利用します。これを <span class="green bold">Mustache（マスターシュ）構文</span>と言います。  
今回のサンプルでは、{{ message }} で、データオブジェクトの message プロパティの値をそのまま 引用しているだけですが、{{...}} には任意の JavaScript 式を与えることも可能です。  
たとえば以下は、いずれも妥当な Mustache 式です。
```
{{ 5 + 3}} // 簡単な演算
{{ value + 2 }} //変数との演算
{{ message.substring(1) }} // メソッド呼び出し
{{ Math.abs(-10) }} // 組み込みオブジェクトの呼び出し
```
{{...}} では、Math、Date など JavaScript の組み込みオブジェクトにもアクセスできる点に注目です。 Vue.js では、これらの組み込みオブジェクトを Mustache 式でも利用できるよう、あらかじめ登録しているからです（よって、Vue.js が明示的に登録していない自前のオブジェクトに、{{...}} からアクセスすることはできません）。

<div markdown="1" class="note-box">
##### {{...}} で利用できるのは式だけ
{{...}} に指定できるのは、あくまで式だけです。 代入や条件分岐などを伴う文を指定するこ とはできません。 以下のコードは、いずれも不可です。
```
{{ let data = 13; }}
{{ if (flag) { return data; } }}
```
{{･･･}} 式で条件付き出力をしたい場合は、以下のように条件演算子を使用するか、もしくは v-if (3-3-1項) で代用してください。
```
{{ flag ? data: '0' }}
```
</div>


## 2-2 Vue.js 理解のための３つの柱

Vue.js アプリの基本のキとも言える「Vue インスタンス」と「{{...}}式」について解説したところで、 本節では、これらの理解を深める以下の3つのしくみについて説明していきます。

* <span class="marker-yellow30">ディレクティブ </span>
* <span class="marker-yellow30">算出プロパティおよびメソッド </span>
* <span class="marker-yellow30">ライフサイクルフック</span>

いずれの項目も、この先の章を進めるうえで欠かせない知識です。ここで、基本的な構文、考え方を おさえておきましょう。


### 2-2-1 ディレクティブ

Vue.js のテンプレートは標準的な HTML を拡張しただけのシンプルなもので、 学ばなければならないことは、さほど多くはありません。テンプレートを構成するしくみとしては、まずは以下の2点をおさえておけばよいでしょう。

* <span class="text-green bold">{{...}} (Mustache構文 )</span>
* <span class="text-green bold">v-xxxxx 属性(ディレクティブ)</span>

<span class="green bold">{{...}}</span> は前節でも見たように、与えられた式の値をテンプレートに埋め込む（=バインドする）基本的な手法です。記法は簡単ですが、その分、できることも限られています。<span class="red">テキスト部分に値を反映させるだけ</span>です。

属性やスタイルの操作、条件分岐、繰り返し処理など、より複雑な機能を組み込みたい場合は、<span class="green bold">ディレクティブ</span>を利用します。Vue.js の<span class="red">テンプレートを学ぶことは、ディレクティブを学ぶこと</span>、と言い換えてもよいでしょう。それだけ膨大な機能が、ここに集約されています。  
ディレクティプは、「<span class="green bold">v-〜</span>」から始まる属性（構文）として表すのが基本です。

![](upload/ディレクティブの基本的な書き方.png)


##### <span class="green">📗文字列をテンプレートに埋め込む - <span class="blue">v-text</span></span>

データオブジェクトにアクセスするのに、{{...}} の代わりに v-text ディレクティブを利用することもできます。以下は、リスト2-2と同じ意味になります。

<p class="tmp list"><span>リスト2-5</span></p>
```
<div id="app">
  <p v-text="message"></p>
</div>
```

##### <span class="green">📗属性値にJavaScript 式を埋め込む -<span class="blue">v-bind</span></span>
属性に対して式の値を埋め込むのには、{{...}} は利用できません。たとえば、以下のコードは {{ url }} にデータが埋め込まれず、正しく動作しません。
```
<a href="{{ url }}">WINGSプロジェクト</a>
```
属性値の操作には、代わりに <span class="green bold">v-bind</span> ディレクティブを利用してください。以下は、.js ファイル側で 用意された URL を.htmlファイルの<a>タグに反映させる例です。

<p class="tmp list"><span>リスト2-7 / 2-8</span></p>
<p class="codepen" data-height="300" data-default-tab="html,result" data-slug-hash="RwyQYBz" data-user="hanpeita" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/hanpeita/pen/RwyQYBz">
  Vue3 リスト2-2、2-3</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>

<span class="red">ディレクティブの引数 </span>
: Vue.js の文法でコロン「<span class="red bold">:</span>」の後方は、<span class="red">ディレクティブの引数</span>です。細かい点ですが、ディレクティブによっては引数を受け取るものがあること、その場合はコロン区切りで表記することを覚えておきましょう。

<span class="red">v-bind 属性の省略構文</span>
: v-bind はよく利用する、という理由から、省略構文も用意されています。リスト 2-7 のaタグ部分は、以下のように表しても同じ意味です。

```
リスト2-7
<a v-bind:href="url">WINGSプロジェクト</a>	→	<a :href="url">WINGSプロジェクト</a>
```

#### 補足:ブール属性の扱い
checked、selected、disabled、そして、multiple など、値がいらない（=属性名を指定するだけで 意味がある）属性のことを論理属性、または<span class="green bold">ブール属性</span>と言います。これらの属性にバインドするには「<span class="red bold"> true値</span>」を用います。

<p class="tmp list"><span>リスト2-9 / 2-10</span>fragがtrueの場合は、ボタンが非活性になります。</p>
<p class="codepen" data-height="300" data-default-tab="html,result" data-slug-hash="ExLQeGp" data-user="hanpeita" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/hanpeita/pen/ExLQeGp">
  Vue3 リスト2-7、2-8</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>

上記のjsのflagをfalse に変えると、ボタンが有効化されます。 false 以外にも、null、 undefined、0 としても同じ意味です。それ以外の値は true と見なされます。


### 2-2-2 算出プロパティ

これまで見てきたように、テンプレートには、<span class="green bold">{{...}} </span>や<span class="green bold"> v-bind</span> を用いることで、任意の JavaScript 式を埋め込むことができます。たとえば以下は、与えられた email プロパティ（メールアドレス）の値 から「@」より前だけを取り出し、小文字に変換する例です。

<p class="tmp list"><span>リスト2-11 / 2-12</span>（悪い例）HTMLに抜き出す処理が記述されており、コードがわかりにくい</p>
<p class="codepen" data-height="300" data-default-tab="html,result" data-slug-hash="eYrVPKx" data-user="hanpeita" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/hanpeita/pen/eYrVPKx">
  Vue3 リスト2-9、2-10</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>

※ toLowerCase() メソッドは、呼び出す文字列の値を小文字に変換して返します。


これは構文的には正しいコードですが、望ましくはありません。複雑な式は、本来見た目を表すべき テンプレートを読みにくくしますし、結果、修正も困難になるからです(複数の箇所で同じ式を記述するならば、なおさらです!)。  
テンプレートでは単純なプロパティの参照にとどめ、演算やメソッドの呼び出しはできるだけコード 側にゆだねるべきです。このような用途で有用なのが、<span class="green bold">算出プロパティ</span>です。

#### 算出プロパティの基本

<p class="tmp list"><span>リスト2-13 / 2-14</span>算出プロパティに書き換えたもの</p>
<p class="codepen" data-height="400" data-default-tab="js,result" data-slug-hash="dyedggM" data-user="hanpeita" style="height: 400px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/hanpeita/pen/dyedggM">
  Vue3 リスト2-11、2-12</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>

算出プロパティとは、言うなれば、既存のプロパティを演算(算出)した結果を取得するためのゲッター(getter) です。<span class="red bold">computed </span>オプション配下に「プロパティ名 : 関数 ,...」形式で定義します<span class="blue bold"> (1)</span>。
算出プロパティの配下では、「this. プロパティ名」でデータオブジェクトにアクセスできます。<span class="blue bold">(2)</span> では email プロパティにアクセスしています)。  
定義済みの算出プロパティをテンプレートから参照するには、データオブジェクトに対するのと同じく、単に「{{ プロパティ名 }}」とするだけです<span class="blue bold">(3)</span>。定義側はメソッドですが、参照側はあくまで プロパティ(変数)として参照できるわけです。

<div markdown="1" class="note-box">
##### 算出プロパティのセッター
算出プロパティでは、値を取得するだけでなく、 値を設定するためのセッター (setter)を設けることもできます。   
ただし、こちらはそれほど頻繁には利用しないため、 5-2-1 項であらためて触れます。
</div>

<!--
![](upload/note_算出プロパティのセッター.png)
-->

#### メソッドによるロジックの切り出し
算出プロパティは、<span class="red">メソッド</span>として表してもほぼ同じ意味になります。たとえば、以下は先ほどの例 をメソッドを使って書き換えています。

「<span class="red bold">computed:</span>」が「<span class="blue bold">methods: </span>」に変わっています。

<p class="tmp list"><span>リスト2-15 / 2-16</span>メソッドに書き換えたもの</p>
<p class="codepen" data-height="400" data-default-tab="js,result" data-slug-hash="qBYxJgO" data-user="hanpeita" style="height: 400px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/hanpeita/pen/qBYxJgO">
  Vue3 リスト2-15、2-16</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>


#### 算出プロパティとメソッドの相違点

算出プロパティとメソッドとは、文脈によっては似たような機能を提供するわけですが、もちろん、双方は異なるものです。具体的な相違点を見てみましょう。

1 <span class="marker-yellow30">算出プロパティは引数を持てない</spsn>
: 算出プロパティは、プロパティという性質上、引数を持てません（『( )』を伴う呼び出しができないからです）。よって、引数を伴うような呼び出しには、メソッドを利用する必要があります。

2 <span class="marker-yellow30">算出プロパティは取得用途</span>
: <span class="red">算出プロパティ</span>の用途は、基本的に既存データの「<span class="red">加工を伴う取得</span>」です。一方、<span class="green bold">メソッド</span>はデータの取得に加え、<span class="green bold">操作や更新にも利用できます</span>。代表的な例としては、マウスクリックなどに対応したイベント処理なども、メソッドの守備範囲です。要は、算出プロパティでできることはメソッドでもできます。  
ただし、引数を伴わない単純な加工や演算なのであれば、算出プロパティを利用したほうがコードの 意図が明確になります。

3 <span class="marker-yellow30">算出プロパティの値はキャッシュされる</span>
: そして、算出プロパティとメソッドとの決定的な違いが、これです。違いを理解するために、もうひとつ、サンプルを見てみましょう。

以下は、それぞれ算出プロパティとメソッドで乱数を表示するためのコードです。また、ボタンクリックのタイミングで現在時刻を表示します。

<p class="tmp list"><span>リスト2-17 / 2-18</span>クリックで現在時刻表示</p>
<iframe height="500" style="width: 100%;" scrolling="no" title="Vue3 リスト2-15、2-16" src="https://codepen.io/hanpeita/embed/eYrVQYw?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/eYrVQYw">
  Vue3 リスト2-15、2-16</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

※ toLocaleString() メソッドは、この数値を表す言語依存の文字列を返します。

この場合、算出プロパティ <span class="red">randomc</span> は、他のプロパティに依存しないので、初回に呼び出された後は、 二度と呼び出されることはありません。再描画のたびにすべての式が評価されるのは無駄なので、取得用途ではまずは<span class="green bold">算出プロパティ</span>を基本とし、値を常に更新したいという意図がある場合に<span class="red bold">メソッド</span>を 使うとよいでしょう。

### 2-2-3 ライフサイクルフック

Vue.js のアプリインスタンスは、最初に生成された後、要素にマウントされて、データの変化に応じてビューを更新させていき、最終的に破棄されます。このような「<span class="red">生成から破棄までの流れ</span>」のことを、<span class="green bold">ライフサイクル</span>と言います。  
Vue.js には、このライフサイクルの変化に応じて呼び出される、さまざまなメソッドが用意されています。このような<span class="red">メソッド</span>のことを、<span class="green bold">ライフサイクルフック</span>(Lifecycle Hooks)と呼びます。ライフサイ クルフックを利用すると、インスタンス生成から表示、破棄と、決められたタイミングでアプリ独自の処理を割り込ませることができます。 以下の図は、主なライフサイクルフックをまとめたものです。

<div markdown="1" class="photo-capture">
[![](upload/主なライフサイクルフック.jpg)](upload/主なライフサイクルフック.jpg){.image}
</div>

<span class="red bold">created</span>、<span class="red bold">beforeMount</span>、<span class="red bold">mounted</span> がフックの代表格なので、まずはこの3つを覚えておくと良いです。


※2-19、2-20のサンプルは、ブラウザで開いてからステップ実行で確認しながらの方がわかりやすいと思います。

http://localhost:7008/chap02/life.html

<p class="tmp list"><span>リスト2-19 / 2-20</span>コンソールに表示</p>
<iframe height="700" style="width: 100%;" scrolling="no" title="Vue3 リスト2-17、2-18" src="https://codepen.io/hanpeita/embed/bGMLQwx?default-tab=js%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/bGMLQwx">
  Vue3 リスト2-17、2-18</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

<span class="green bold">ライフサイクルフック</span>は、メソッドと似ていますが、別物です。methodオプションと同列にcreateAppメソッドの動作オプションとして列記する点を間違えないようにしましょう(1)。   
また、(2)の unmount メソッドは、現在のアプリインスタンスを破棄するためのメソッドです。ライフ ・サイクルという見地からは beforeunmount および unmounted フックの<span class="red">トリガー</span>となります。  
ここでは、データオブジェクトの書き換えは発生していないので、beforeUpdate および updated フックは呼び出されていないことも確認してください。

<div markdown="1" class="note-box">
##### デバッグ/エラー処理用のフック
さきほどのライフサイクルフックの図に登場しないフックとして、以下のようなものもあります。
![](upload/デバッグエラー処理用のフック.jpg)
ただし、これらのフックはそれぞれリアクティブデータ (2-3節)、 <keep-alive> 要素、 エラー 処理(5-4-1節)などのテーマと関わるため、 関連する項で改めるものとします。 まずは、このようなフックもある、 という程度で確認しておきましょう。
</div>


### 2-2-4. 補足 メソッドの簡易構文とアロー関数

モダンなブラウザーでは、オブジェクトリテラル配下のメソッドをよりシンプルに記述できます。具体的には、data / computed / methods などのオプションを、以下のように表せます。以下は、リスト 2-14 を簡易構文で書き換えたものです。

http://localhost:7008/chap02/computed_simple.html


```
<div id="app">
  <p>{{ localEmail }}</p>
</div>
```

<p class="tmp list"><span>リスト2-21</span></p>
```
Vue.createApp({
  data() {
    return {
      email: 'Y-Suzuki@example.com'
    }
  },
  computed: {
    localEmail() { //←ここが変更
      return this.email.split('@')[0].toLowerCase();
    }
  }
}).mount('#app');
```
下記のように、書き方が少しシンプルになっています。
localEmail: function() {　➡　localEmail() {


<p class="tmp"><span>書式</span>アロー関数</p>
```
(arg,...) => {statements}
```
arg: 引数  
statements: 関数の本体


##### 使い方

円の面積を求めるcircle関数は、従来関数リテラルであれば、次のように表せます。
```
const circle = function(radius) {
	return radius * radius * Math.PI;
}
```

アロー関数では、次のように表せます。
```
const circle = (radius) => { //←ここが変わる
	return radius * radius * Math.PI;
}
```

#### (1) 関数本体が1文である場合
関数本体が1文ならば、ブロックを表す{...}は、省略できます。また、本体（式）の値がそのまま関数の戻り値となるため、returnも省略できます。
```
const circle = (radius) => radius * radius * Math.PI;
}
```

さらに、<span class="red">引数が1個</span>の場合には、引数を括る<span class="red">カッコ</span>も省略できます。
```
const circle = radius => radius * radius * Math.PI;
```

ただし、引数がない場合は、カッコも省略できません。
```
const circle = () => radius * radius * Math.PI;
```

##### <span class="green">📗アロー関数の注意点</span>

ただし、アロー関数は「<span class="green bold">this</span>」を定義時のそれで固定する、という性質があります。  
その性質上、<span class="red">data</span>、<span class="red">computed</span>、<span class="red">methods</span>などのオプションで<span class="red bold">アロー関数を利用すべきではありません</span>。（配下のthisがコンポーネントを示さなくなってしまうからです）。
一般的には、data、computed、methodsなどのオプションでは、アロー関数は使わない、と覚えておくのが無難です。


## リアクティブデータ

### 2-3-1 リアクティブシステムの例

<p class="tmp list"><span>リスト2-22 / 2-23</span></p>
<iframe height="450" style="width: 100%;" scrolling="no" title="Vue3 リスト2-22/2-23" src="https://codepen.io/hanpeita/embed/wvjQMYr?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/wvjQMYr">
  Vue3 リスト2-22/2-23</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

setInterval メソッドを経由して 1000 ミリ秒間隔で current プロパティの値を現在日時に置き換えています。このようなタイマー設定では、created フックを利用するのが定石です。

![](upload/note_createdとbeforeUnmounted.jpg)

さて、サンプルを実行してみると、確かに current プロパティの変化に反応して、ページ(テンプレー ト)の側も変化しているのが確認できます。これが<span class="green bold">リアクティブ</span>であることの意味です。  
Vue.js では、「<span class="bold">data オプションにデータを登録すると</span>、その<span class="red">すべてのプロパティを監視対象として登録します</span>。そして、その<span class="red">変更を検知すると、自動的にビューに反映する</span>」わけです。

![](upload/リアクティブデータのしくみ.jpg)


##### <span class="green">📗補足:renderTracked / renderTriggered ライフサイクルフック</span>

2-2-3 項で保留にしておいた renderTracked / renderTriggered フックについて補足しておきます。   
renderxxxxx フックはリアクティブデータの変化を追跡するためのフックで、主にデバッグ用途で利用 します。  
試しに、リスト 2-23 にこれらのフックを追加してみましょう。


～保留 よくわからない～

### 2-3-2 ビューの非同期更新を理解する（$nextTickメソッド）

初歩的な開発ではあまり意識することはありませんが、実は、リアクティブシステムによるページ (ビュー)の更新は、<span class="red">非同期</span>です。  
Vue.js では、データの変更を検知しても、これをすぐにビューに反映するわけではありません。連動して発生するすべての変更をプールしたうえで、最終的な結果をビューに反映させるわけです。描画の オーバーヘッドを最小にとどめる、Vue.js の知恵です。 その性質上、以下のようなコードは正しく動作しません。

コンソールには、「false」が表示されます。
<p class="tmp list"><span>リスト2-25 2-26</span></p>
<iframe height="400" style="width: 100%;" scrolling="no" title="Vue3 リスト2-25/2-26" src="https://codepen.io/hanpeita/embed/JjveByM?default-tab=js%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/JjveByM">
  Vue3 リスト2-25/2-26</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
<!--
<p class="tmp list"><span>リスト2-25</span></p>
```
<div id="app">
  <p>{{ message }}</p>
</div>
```

<p class="tmp list"><span>リスト2-26</span></p>
```
Vue.createApp({
  data() {
    return {
      message: 'こんにちは、世界！'
    };
  },
  mounted() {
    this.message = 'はじめまして、Vue.js！';
    console.log(this.$el.textContent.includes(this.message));//-----(1)

    /*this.$nextTick(() => {
      console.log(this.$el.textContent.includes(this.message));
    });*/
  }
}).mount('#app');
```
-->

$el プロパティは、アプリインスタンスで管理された要素を Element オブジェクトとして返します (1)。ここでは、そのテキスト（textContent） が message プロパティの値を含んでいるか（includes）を確認しているわけです。  
データオブジェクトの内容が同期的にビューに反映されるならば、この結果は true となるはずです。 しかし、ログを見てみると結果は false。データオブジェクトへの更新が、即座には反映されていないことが確認できました。

そこでビューへの反映を待つには、以下のように<span class="green bold"> $nextTick メソッド</span>を利用します。
```
this.$nextTick(() => {
	//ビューへの反映を待ってから確認
	console.log(this.$el.textContent.includes(this.message));
});
```

コンソールには、「true」が表示されます。
<iframe height="400" style="width: 100%;" scrolling="no" title="Vue3 リスト2-25/2-26(nextTick使用)" src="https://codepen.io/hanpeita/embed/abGQjWL?default-tab=js%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/abGQjWL">
  Vue3 リスト2-25/2-26(nextTick使用)</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

<span class="green bold">$nextTickメソッド</span>は、<span class="red">Vue.jsによるビューの更新を待って、その後で指定された処理を実行</span>します。

<p class="tmp"><span>書式</span> $nextTickメソッド</p>
```
$nextTick(callback)
```
callback: 更新後に実行すべき処理

※Vue.jsでは、アプリ固有のプロパティ/メソッドと区別するために、Vueのメンバーには接頭辞[<span class="red bold">$</span>]を付与しています。

Vue.jsでは、まずはリアクティブシステム（データオブジェクト）経由でビューを更新するのが基本なので、文書ツリーにアクセスすることは、ほとんどありません。また、すべきではありません。$nextTickメソッドを利用する場合には、文書ツリーからでなければ得られない情報なのかを再確認してください。

<span class="red">文書ツリーとは、DOMツリーのこと??</span>


### 2-3-3 ウォッチャーによる明示的な監視（watch オプション、$watch メソッド）

![](upload/オートコンプリート機能の例.png)

入力値はどんどん変化しているのに、都度、リスト取得のための問い合わせが発生するのは無駄です（そして、リモートでの問い合わせはたいがい、内部的な演算よりもはるかに重い処理です）。  
このような場合には、入力の切れ目（=入力の間隔が空いたとき）にだけ処理を実施するようにすることで、アプリの負荷を軽減できます。そして、そのような細かな制御は標準的なリアクティブシステムだけでは対応できないので、Vue.js ではより原始的な <span class="green bold">watch オプション（ウォッチャー）</span>を提供して います。watch オプションを利用することで、「<span class="red">データオブジェクトの特定のプロパティが変化したとき に任意の処理を実行</span>」できます。


<p class="tmp"><span>書式</span>watchオプション</p>
```
watch: {
	prop(newValue, oldValue) {
	 ...statements...
	}
},
...
}
```

<div markdown="1" class="list-none">
* <span class="bold"> prop</span>:  監視すべきプロパティ名
* <span class="bold">newValue</span>:  プロパティの変化後の値
* <span class="bold">oldValue</span>:  プロパティの変化前の値
* <span class="bold">statements</span>:  プロパティ変化時の実行すべき処理
</div>

例）下記は、nameプロパティの値が変化する時に、「古い値 => 新しい値」の形式でログを出力しなさい、という意味になります。
```
watch: {
	name(newValue, oldValue) {
		console.log('${oldValue} => ${newValue}'); 
	}
	}
}
```

##### 📗<span class="green">ウォッチャーの具体的な例</span>

ウォッチャーの役割をイメージしやすいよう、もう少し具体的な例を挙げてみましょう。以下は、テキストボックスに入力した値を大文字に変換したうえで、ページ下部に反映させる例です。ただし、値 の反映は（入力中に都度ではなく）<span class="red">入力が区切れた入力が 2000ミリ秒空いた</span>――ところで行うようにします。

※本節の内容は、v-model ディレクティブを理解していることが前提となります。まずはコードの意図だけを説明しておくので、3-2 節を学習した後、再度読み解くことをお勧めします。

<p class="tmp list"><span>リスト2-27 / リスト2-28</span></p>
<iframe height="600" style="width: 100%;" scrolling="no" title="テスト" src="https://codepen.io/hanpeita/embed/oNqORwe?default-tab=js%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/oNqORwe">
  テスト</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>


https://cdn.jsdelivr.net/npm/lodash@4.17.21/lodash.min.js を読み込ませるのを忘れずに。  
（配列やオブジェクト操作を中心とした、Javascriptコーディングでの便利機能を提供する軽量なユーティリティです。）

_.debounce ～ Lodashライブラリーにある関数の一種で、遅延関数を生成します。


<p class="tmp"><span>書式</span>_.debounce</p>
```
_.debounce(func, wait)
```
func: 遅延実行すべき処理  
wait: 遅延時間（ミリ秒）


![](upload/debounceメソッド.png)


##### 📗<span class="green">補足　ウォッチャーのさまざまな定義方法</span>

###### （1）入れ子となったプロパティを監視する


<p class="tmp list"><span>リスト2-29</span></p>
新規タブ: http://localhost:7008/chap02/watcher_nest.html  
コンソールに表示されます。
<iframe height="500" style="width: 100%;" scrolling="no" title="Vue3 リスト2-34" src="https://codepen.io/hanpeita/embed/qBYxvQX?default-tab=js%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/qBYxvQX">
  Vue3 リスト2-34</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>


<span class="green bold">${newValue}</span>→新しく入力した時の値  
<span class="blue bold">${oldValue}</span>→前の入力した時の値


<p class="result"><span>結果</span>（青:前の入力値　緑:新しい入力値）</p>
![](upload/表示結果匿名青緑.png)


###### （2）文字列、配列も渡すこともできる

<p class="tmp list"><span>リスト2-30</span></p>
<iframe height="550" style="width: 100%;" scrolling="no" title="Vue3 リスト2-29" src="https://codepen.io/hanpeita/embed/vYjdMLV?default-tab=js%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/vYjdMLV">
  Vue3 リスト2-29</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

###### (3)動作オプションを定義する

「キー名:オブジェクト , ...」形式で、ウォッチャーのオプションを定義することもできます。


<p class="tmp list"><span>リスト2-31</span></p>
新規タブ: <http://localhost:7008/chap02/watcher_option.html><br>
下に入力値が表示されます。
<iframe height="500" style="width: 100%;" scrolling="no" title="Vue3 リスト2-30" src="https://codepen.io/hanpeita/embed/zYjRXBd?default-tab=js%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/zYjRXBd">
  Vue3 リスト2-30</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

それぞれのオプションの意味は、以下の表のとおりです。オプションを指定する際には、ウォッチャー 本体も handler オプションで表す必要があります。

![](upload/ウォッチャーの動作オプション.png)

flush オプションの pre / post は、いずれも値の変更をストックし、最終的にまとめて処理を実行 します(これは対象のプロパティが複数回変更された場合も同じです)。これによって Vue.js ではデー タの整合性を維持すると共に、パフォーマンスを向上させているわけです。
ただし、このアドバンテージは sync 値を指定することで失われます(最終的なレンダリングを待たずに即座に処理を実行してしまうからです)。特別な理由がない限り、sync を利用すべきではありません。

###### (4) $watch メソッドを利用する

ウォッチャーは、watch オプション以外に、$watch メソッドで定義することもできます。

<p class="tmp list"><span>リスト2-32</span></p>
<iframe height="450" style="width: 100%;" scrolling="no" title="Vue3 リスト2-32" src="https://codepen.io/hanpeita/embed/eYrVoRR?default-tab=js%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/eYrVoRR">
  Vue3 リスト2-32</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

https://cdn.jsdelivr.net/npm/lodash@4.17.21/lodash.min.jsを読み込む


##### 複数のプロパティを監視する
$watch メソッドの第1引数には関数を渡すこともできます。たとえば、以下は num1、num2 が変化したときに処理を実行します。num1を変更した場合、num1値がそのままコンソールに表示されます。num2を変更した場合は、num1値とnum2値を足した値をコンソールに表示させています。


<p class="tmp list"><span>リスト2-33</span></p>
<iframe height="300" style="width: 100%;" scrolling="no" title="Vue3 リスト2-32" src="https://codepen.io/hanpeita/embed/ExLQJvo?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/hanpeita/pen/ExLQJvo">
  Vue3 リスト2-32</a> by hanpeita (<a href="https://codepen.io/hanpeita">@hanpeita</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>


