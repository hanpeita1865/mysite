*[page-title]:CentOS

Slim参考書で設置方法を記載している「CentOS8」は、2021年度にサポートが切れてしまいました。  
そのため、ここではCentOS7をインストールします。ただ、このバージョンも2024年度でサポートが切れる予定です。

参考サイト
: [CentOS 8 と CentOS 7 の違い、yum やミドルウェアにも要注意](https://xn--o9j8h1c9hb5756dt0ua226amc1a.com/?p=3991)