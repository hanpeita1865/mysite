---
title: (移動済)foreach文
taxonomy:
    category:
        - docs
visible: true
---

* [foreachループの使い方](#p1)
* [スキップと強制終了の方法](#p2)
* [foreachで配列の最初と最後に処理を追加する](#p3)

foreach構文は、配列やオブジェクトを反復処理するための便利な制御構造です。  
配列の全ての要素に特定の同様の処理を行いたいときに使用します。

## foreachループの使い方 ##{#p1}

foreachには、2種類の構文があります

<p class="tmp"><span>書式1</span></p>
```
foreach (配列 as 変数) {
	変数を使った処理
}
```
<!--
<iframe src="https://paiza.io/projects/e/CNcmGKg7nZboYAkmivvYrw?theme=twilight" width="100%" height="650" scrolling="no" seamless="seamless"></iframe>
-->
<div class="box-example">
<h3 class="h-example">例1</h3>
配列$arrayの値をforeachを使って表示させています。
</div>
<iframe src="https://paiza.io/projects/e/WPz0zlVZBNsd1L3rU6DQKQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>



<p class="tmp"><span>書式2</span>連想配列のキーと値を取り出す</p>
```
foreach (配列 as キーの変数 => 値の変数) {
	キーの変数と値の変数を使った処理
}
```
<!--
<iframe src="https://paiza.io/projects/e/m_dSKIhJl0S3DWwAuO1PMg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
-->
<div class="box-example">
<h3 class="h-example">例2</h3>
連想配列$storeのキーと値をforeachを使って、selectボックスのoptionとして表示させています。
</div>
<iframe src="https://paiza.io/projects/e/lL6x7FCyz9rrsCrbzDh4rA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

##### 生成したselectボックスのHTMLコード
```
<select>
    <option value="101">新宿</option>
    <option value="102">秋葉原</option>
    <option value="103">上野</option>
</select>
```


## スキップと強制終了の方法 ##{#p2}
* continue文 ～ 特定の値をスキップする
* break文 ～ ループ処理を終了させる

<iframe src="https://paiza.io/projects/e/0F9Oy3dO5CAP60eOyE96SQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## foreachで配列の最初と最後に処理を追加する ##{#p3}
PHP 7.3 以上

<iframe src="https://paiza.io/projects/e/uyVGG4v56eU-Be7lTe6uBQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

#### 補足: 配列から最初と最後の値だけ取り出したい場合
```
echo "{$items[array_key_first($items)]} is first" . PHP_EOL;
echo "{$items[array_key_last($items)]} is last" . PHP_EOL;
```

## 参考サイト

* [PHPのcontinueとbreakでループをスキップ、終了する方法](https://www.flatflag.nir87.com/continue-466)