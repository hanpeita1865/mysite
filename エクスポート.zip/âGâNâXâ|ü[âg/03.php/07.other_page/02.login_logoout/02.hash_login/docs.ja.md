---
title: 暗号化認証画面
taxonomy:
    category:
        - docs
media_order: 'ユーザー情報登録画面.png,認証画面.png,パスワードをテーブルに登録.png'
---

## 認証画面作成

参考サイト
: <https://qiita.com/MasaKu_n/items/51552aa0331f3ae90dae>

<p class="tmp list"><span>リスト</span>ユーザー情報登録画面（sample_login/index.html）</p>
[新規タブ](../../../../sample/php/password/sample_login/index.html?target=_blank)
```
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ユーザ情報の登録画面</title>
</head>
<body>

<p>ユーザ情報</p>
<form action="create_user_info.php" method="post">
ID:<input type="text" name="id"><br>
PASS:<input type="text" name="pass">
<input type="submit" value="送信">
</form>

</body>
</html>
```
![%E3%83%A6%E3%83%BC%E3%82%B6%E3%83%BC%E6%83%85%E5%A0%B1%E7%99%BB%E9%8C%B2%E7%94%BB%E9%9D%A2](%E3%83%A6%E3%83%BC%E3%82%B6%E3%83%BC%E6%83%85%E5%A0%B1%E7%99%BB%E9%8C%B2%E7%94%BB%E9%9D%A2.png "%E3%83%A6%E3%83%BC%E3%82%B6%E3%83%BC%E6%83%85%E5%A0%B1%E7%99%BB%E9%8C%B2%E7%94%BB%E9%9D%A2")

<p class="tmp list"><span>リスト</span>ユーザー情報登録画面（sample_login/create_user_info.php）</p>
```
<?php
//パスワードの暗号化
$hash_pass = password_hash($_POST['pass'], PASSWORD_DEFAULT);

try {
    // データベースへの接続開始
    $dbh = new PDO( 'sqlite:../password.db' );//SQLiteに接続

    // bindParamを利用したSQL文の実行
    $sql = 'INSERT INTO password (id, pass) VALUES(:id, :pass);';
    $sth = $dbh->prepare($sql);
    $sth->bindParam(':id', $_POST['id']);
    $sth->bindParam(':pass', $hash_pass);
    $sth->execute();

    print('登録しました');

    // データベースへの接続に失敗した場合
} catch (PDOException $e) {
    print('接続失敗:' . $e->getMessage());
    die();
}
?>
```
ユーザー情報の登録に成功すると、「登録しました」と表示され、以下のようにデータベースのpasswordテーブルに追加されます。

![%E3%83%91%E3%82%B9%E3%83%AF%E3%83%BC%E3%83%89%E3%82%92%E3%83%86%E3%83%BC%E3%83%96%E3%83%AB%E3%81%AB%E7%99%BB%E9%8C%B2](%E3%83%91%E3%82%B9%E3%83%AF%E3%83%BC%E3%83%89%E3%82%92%E3%83%86%E3%83%BC%E3%83%96%E3%83%AB%E3%81%AB%E7%99%BB%E9%8C%B2.png "%E3%83%91%E3%82%B9%E3%83%AF%E3%83%BC%E3%83%89%E3%82%92%E3%83%86%E3%83%BC%E3%83%96%E3%83%AB%E3%81%AB%E7%99%BB%E9%8C%B2")


<p class="tmp list"><span>リスト</span>認証画面（sample_login/pass_check.html）</p>
[新規タブ](../../../../sample/php/password/sample_login/pass_check.html?target=_blank)
```
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ログイン画面</title>
</head>
<body>

<form action="pass_check.php" method="post">
ID:<input type="text" name="id"><br>
PASS:<input type="text" name="pass">
<input type="submit" value="ログイン">
</form>

</body>
</html>
```
![%E8%AA%8D%E8%A8%BC%E7%94%BB%E9%9D%A2](%E8%AA%8D%E8%A8%BC%E7%94%BB%E9%9D%A2.png "%E8%AA%8D%E8%A8%BC%E7%94%BB%E9%9D%A2")


<p class="tmp list"><span>リスト</span>認証チェック（sample_login/pass_check.php）</p>
```
<?php

try {
    // データベースへの接続開始
    $dbh = new PDO( 'sqlite:../password.db' );//SQLiteに接続

    // bindParamを利用したSQL文の実行
    $sql = 'SELECT pass FROM password WHERE id = :id;';
    $sth = $dbh->prepare($sql);
    $sth->bindParam(':id', $_POST['id']);
    $sth->execute();
    $pass = $sth->fetch();

    //認証処理
    if(!$pass){
        print '認証失敗 ID値がありません。';
    } elseif (password_verify($_POST['pass'], $pass['pass'] )){
        print '認証成功';
    } else {
        print '認証失敗 パスワードが一致しません。';
    }

    // データベースへの接続に失敗した場合
} catch (PDOException $e) {
    print('接続失敗:' . $e->getMessage());
    die();
}

?>
```
認証に成功すると、「認証成功」と表示されます。

