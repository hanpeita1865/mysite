---
title: '02. 変数の付け方'
taxonomy:
    category:
        - docs
visible: true
---

変数とは，文字や数字などのデータを格納しておく「箱」のようなものです．  
変数には名前を付けることができ，中身を自由に変えることができます．

---

プログラミングで変数を使うには，まず変数を宣言しておく必要があります．  
次のように宣言します．
<p class="tmp"><span>書式1</span>変数を宣言</p>
<iframe width="100%" height="150" src="//jsfiddle.net/a32gfe1b/18/embedded/js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

* 1行目は，変数を1つだけ宣言しています．
* 2行目は，複数の変数を一括で宣言しています．
* 3行目は，変数を宣言すると同時に値を指定しています．「=」は代入という意味です．

---

変数名は自由に付けることができますが、下記のような決まりがあります．

* 変数名には半角英数字やアンダーバー「_ 」を用いることができます．
* 変数名の一文字目は英文字でなければいけません．
* 命令文（予約語）に出てくるような変数名は使えません．以下のリンク先に予約語が載っています．  
[予約語 - JavaScript | MDN](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Reserved_Words)
* JavaScriptでは大文字と小文字は別なものとされます．例えば「hello」，「Hello」は別の変数となります．一般的には変数名の先頭文字は小文字とします．
* その変数が何のデータを保存しているか一目でわかるような変数名を付けるようにしましょう．  
例えば，  
    * 合計金額を保存する変数なら　⇒　total、sum  
    * 電話番号なら　⇒　tel、phone  
    * 住所なら　⇒　address  
* 複数の英単語をつける場合は，一つ目の単語を小文字にして、二つ目以降の単語の頭文字を大文字にします．  
    * myPhone
    * myAdress
    * addressBook
* 下記のような一文字の変数名は理由がない限り使わないようにしましょう．  
    * var a = 1;
    * var b = 2;

---

主な変数の型
    * 数値型
    * 文字列型
    * 論理型（true、false）

など，これ以外にもあります．

型の判定には，typeofという演算子を使います．  
基本的な書き方は下記のように，typeofの後ろに型を判定したい値を記述するだけです．

<p class="tmp"><span>書式2</span>変数の型の判定</p>

```
typeof 判定したい値
```
