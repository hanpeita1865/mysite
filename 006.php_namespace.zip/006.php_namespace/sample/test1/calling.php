<?php
function hello() {
    return 'もしもし';
}