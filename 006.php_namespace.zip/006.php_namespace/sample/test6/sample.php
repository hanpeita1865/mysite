<?php
require_once 'calling.php';
use function Asia\Japan\Hokkaido\Hokkaido\Sapporo\hello;

echo hello(); // 出力結果：もしもし

