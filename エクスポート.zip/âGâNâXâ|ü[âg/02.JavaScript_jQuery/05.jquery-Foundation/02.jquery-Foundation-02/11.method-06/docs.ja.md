---
title: '11. 要素の幅や高さや位置を取得や設定<br>（width、height、offset..）'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .mb-0 {margin-bottom: 0;}
    .mt-5rem {margin-top: 5rem;}
    .my-0 {margin-bottom:0; margin-top: 0; }
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .smp-box {
         margin: 2rem 0 3rem;
    }
    .smp {
        display: inline-block;
        margin-top: 2rem;
        margin-bottom: 0;
        background: #bc495b;
        color: #fff;
        font-size: .75rem;
        font-weight: bold;
        letter-spacing: .3rem;
        padding: .2rem .5rem;
    }
    .tmp {
        background: #026ca2;
        color: #fff;
        font-size: .87rem;
        letter-spacing: .3rem;
        padding: .2rem 1rem;
        white-space: nowrap;
    }
    .dcn {
     font-weight: bold;   
    }
    w-500 {
     	width: 500px;
        display: inline-block;
    }
</style>

<h2 class="h-type2">メソッドによる要素の幅や高さの取得方法</h2>


| メソッド | padding | border | margin |
|:-----------|:------------:|:------------:|:------------:|
| **width( )** | × | × | × |
| **height( )**| × | × | × |
|       |         |          |         |
| **innerWidth( )**| 〇 | × | × |
| **innerHeight( )**| 〇 | × | × |
|   |     |       |         |
| **outerWidth( )**| 〇 | 〇 | × |
| **outerHeight( )**| 〇 | 〇 | × |
| | |  |         |
| **outerWidth(true)**| 〇 | 〇 | 〇 |
| **outerHeight(true)**| 〇 | 〇 | 〇 |


<div class="box-example mt-5rem">
    <h3 class="h-example">例1</h3>
    赤のボックス（#box）があり、外側の灰色の領域はボックスのマージンになります。<br>
    上記の表にあるメソッドを使って、高さと横幅を取得しコンソールで表示しています。<br>
    ※要素は、box-sizing: border-box（パディングとボーダーを含む）で設定しています。
</div>

<pre>
<p class="red bold my-0">赤のボックスのスタイル</p>
#box {
  background-color: red;
  width: 350px;
  height: 200px;
  padding: 30px;
  margin: 50px;
  border: 5px solid #000;
  position: relative;
  box-sizing: border-box;
}
</pre>

<iframe id="exp-1" width="100%" height="700" src="//jsfiddle.net/sh0u9bgf/1/embedded/result,html,css,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

####ボックスの横幅を確認
<pre>
<strong>width()</strong> ⇒ 350px - 30px（padding）× 2 - 5px（border）× 2 = <span class="bold">280px</span> 

<strong>innerWidth()</strong> ⇒ 350px - 5px（border）× 2 = <span class="bold">340px</span>

<strong>outerWidth()</strong> ⇒ <span class="bold">350px</span>

<strong>outerWidth(true)</strong> ⇒ 350px + 50px（margin） × 2 = <span class="bold">450px</span>

</pre>

<h2 class="h-type2">要素の位置の取得や設定（offset、position）</h2>


#####**offsetメソッド** ～ document（ページ全体）を基準として要素の位置の取得や設定を行います。

#####**positionメソッド** ～ 親要素を基準として要素の位置の取得や設定を行います。
※positionメソッドは、親要素のcssでpositionを指定してなかったりstaticを指定している場合は、offsetと同じ値が取得されます。

###offsetメソッド

<p class="mb-05"><span class="tmp">書式1</span></p>
<pre>
位置のオブジェクト
$('セレクタ').<span class="bold">offset()</span>

トップからの縦位置
$('セレクタ').<span class="bold">offset().top</span>

左端からの位置
$('セレクタ').<span class="bold">offset().left</span>


位置の設定
$('セレクタ').<span class="bold">offset({ top: 値, left: 値 })</span>
</pre>

<div class="box-example">
    <h3 class="h-example">例2</h3>
    <strong>offset()で位置を取得</strong><br>
    ボタンをクリックすると、赤のボックスの位置をoffset()メソッドで取得した値をコンソールで表示します。<br>
    offset()メソッドでは、documentの左上の位置を基準とした絶対座標を取得しています。<br>
</div>

<iframe id="exp-1" width="100%" height="500" src="//jsfiddle.net/by2xq0hw/embedded/result,html,css,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<div class="box-example">
    <h3 class="h-example">例3</h3>
    ボタンをクリックすると、offset()メソッドで設定した位置に赤のボックスが移動します。<br>
     $('#box').<strong>offset({ top: 100, left: 300 })</strong> 　<span class="bold">⇒　上から100px　左端から300pxの位置に移動</span>
</div>
<iframe id="exp-1" width="100%" height="400" src="//jsfiddle.net/v7b0xf1a/embedded/result,html,css,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

###positionメソッド

<div class="box-example">
    <h3 class="h-example">例4</h3>
    <strong>position()で位置を取得</strong><br>
    ボタンをクリックすると、赤のボックスをposition()メソッドで取得した位置をコンソールで表示します。<br>
    position()メソッドでは、灰色の要素を基準とした相対座標を取得しています。この場合、灰色の要素には、position: relative、赤の要素にはposition: absoluteを設定しています。
</div>

<iframe id="exp-1" width="100%" height="550" src="//jsfiddle.net/ru9k7mvg/embedded/result,html,css,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<h2 class="h-type2">スクロール位置を取得（scrollTop）</h2>

スクロールの垂直位置を取得したり、設定をします。 <br>
この数値はスクロール領域に隠れた長さと同じになります。 また、スクロールが一番上にあるかスクロール領域がない場合、値は「0」になります。 


<p class="mb-05"><span class="tmp">書式2</span> </p>
<pre>
スクロール位置の取得
$('セレクタ').<span class="bold">scrollTop()</span>

※セレクタに「<span class="red">window</span>」を入れると、<span class="red">画面のスクロール位置</span>を取得します

スクロール位置の設定
$('セレクタ').<span class="bold">scrollTop(値)</span>
</pre>

<div class="box-example">
    <h3 class="h-example">例5</h3>
    <strong>$(document).height()</strong> ⇒ ページ全体の高さ、　<strong>$(window).height()</strong> ⇒ 画面（ブラウザ）の高さ、　<strong>$(window).scrollTop() </strong>⇒ スクロール位置<br>
    から値を取得し、スクロールや画面の高さ（Jsfiddle上だとリサイズできないので500pxのまま）を変えるごとに値を変更させています。<br>
    <br>

</div>

スクロールをしてみてください。scrollTopの値が変化します。



 別画面で開くと、画面高さの変化もわかります。　<a href="method-06/index.html" target="_blank">scrollTopサンプル</a>（別ウインドウで開きます）

<iframe id="exp-1" width="100%" height="550" src="//jsfiddle.net/4okv0c86/embedded/result,html,css,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<p class="mt-5rem mb-0">画面から上部の隠れているページの部分の高さがscrollTop()の値になります。<br>
そのため一番下までスクロールしたときには<br>
<span class="bold">ページ全体の高さ = 画面（ブラウザ）の高さ + スクロール位置（scrollTop()の値）</span><br>
となります。 <br>
図で表すと下記のようになります。</p>
  
  
 ![scrollTop](scrollTop.png)

####画面とページ全体用のメソッド

#####$(window).height(); ～ 画面（ブラウザ）の高さ
#####$(window).width(); ～ 画面（ブラウザ）の横幅

#####$(document).height(); ～ ページ全体の高さ
#####$(document).widtht(); ～ ページ全体の横幅

 

