*[page-title]:配列を結合する array_merge、implode


参考サイト
: [【PHP入門】配列を結合するさまざまな方法まとめ！](https://www.sejuku.net/blog/21685)

## array_merge

<span class="green bold">array_merge関数</span>を使用すると、配列の後ろに配列を追加（結合）することができます。

<p class="tmp"><span>書式</span></p>
```
array array_marge(最初の配列名, 追加する配列1,  (, 追加する配列2, …)
```
引数：
: 第一引数には最初の配列を指定します。
: 第一引数以降は追加していく配列を1つ、または複数指定します。

返り値：
: 結合した結果の配列を返します。

<div class="exp">
	<p class="tmp"><span>例1-1</span></p>
<iframe src="https://paiza.io/projects/e/Ud0mlrsSIlFqp3ZxWvpJRA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


## implode
<span class="green bold">implode関数</span>は、配列の値を文字列で結合するときに使用します。

<p class="tmp"><span>書式</span></p>
```
string  implode('結合する文字列', 配列名)
```
<p class="tmp"><span>書式</span></p>
```
string  implode(配列名)
```
引数：
: 結合する文字列は配列の要素を指定した文字列で連結したいときに使用します。  
デフォルトは空文字列となります。

implode関数に関しては、引数をどちらの順番でも指定することができます。（歴史的な理由とのことです）  
しかし、混乱を避けるためにマニュアルやドキュメントに記載された順番で、使用するのが望ましいと言えます。

返り値：
: 配列の要素間に結合する文字列ではさんで1つの文字列にした値を返します。

<div class="exp">
	<p class="tmp"><span>例2-1</span></p>
<iframe src="https://paiza.io/projects/e/QzHMgXTLJ7QNWWFqQQSSwg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>
