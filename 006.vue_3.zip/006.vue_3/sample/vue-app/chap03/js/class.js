Vue.createApp({
  data() {
    return {
      color: true,
      isChange: true,
    };
  }
}).mount('#app');