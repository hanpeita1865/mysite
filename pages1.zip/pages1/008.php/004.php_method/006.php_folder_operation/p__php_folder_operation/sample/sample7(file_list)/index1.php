<h2>フォルダ内のファイル名をすべて表示</h2>
 <?php
    foreach (glob('upload/*.*') as $file) {
        $file_name = basename($file);//ファイル名だけを抜き出す
        echo '<li><span class="filename">'.$file_name.'</span></li>';
    }
?>

<h2>拡張子を指定</h2>
<?php
	foreach(glob('upload/{*.docx,*.pdf}',GLOB_BRACE) as $file){
        $file_name = basename($file);//ファイル名だけを抜き出す
        echo '<li><span class="filename">'.$file_name.'</span></li>';
	}
?>



<h2>フォルダ内にあるフォルダ名だけを表示</h2>
<?php
	$dir = 'upload/';

	$folder = glob('upload/*', GLOB_ONLYDIR);

	foreach ($folder as $dir) {
		echo '<li><span class="filename">'.$dir.'</span></li>';
	}
?>

<h2>指定したディレクトリ配下のファイル名をすべて表示</h2>
<p></p>
<?php
	function globAll($folder) {
		// 指定されたディレクトリ内の一覧を取得
		$files = glob($folder.'/*');

		// フォルダ内ループ
		foreach ($files as $file) {
			// ファイルかどうか判定
			if (is_file($file)) {
				// ファイルならそのまま出力
				echo $file . "<br />";

			} else {//フォルダの場合、再度glob関数で中身を取得
				globAll($file);
			}
		}
	}

	// 最初にディレクトリを指定する
	globAll('upload');
