*[page-title]:10-6. 遠近感のある画像を合成しよう

## 遠近感のある面をコピーする ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-06-1.jpg)](upload/10-06-1.jpg){.image}
</div>

## 遠近面に画像をマッピングする ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-06-2.jpg)](upload/10-06-2.jpg){.image}
</div>

