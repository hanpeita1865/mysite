//--Cookieの履歴設定--//

let histArray = [];//履歴まとめ
const histelem = document.getElementById('history');
const cookiePath = 'Path=/test/sample11(cookie_history)';//有効範囲
const cookieMaxage = 'max-age=604800'//有効期限（秒単位）

cookieSetting();

//cookieに値を格納
function cookieSetting(){
	let pageUrl = location.href;
	pageUrl = pageUrl.replace('index.html','');//index.html削除
	pageUrl = pageUrl.replace(/#(.*)$/, "");//ページ内リンク削除
	console.log('ハッシュ '+location.hash);
	console.log('クエリー情報 '+location.search);
	let hash = location.hash;
	let query = location.search

	histArray = cookieGet();

	histArray.map(function( value ) {
		histelem.insertAdjacentHTML('afterbegin','<li><a href="'+value.url+'">'+value.title+'</a></li>');
	});

	//Cookieに同じURLのデータが存在するか判定
	let hasUrl = histArray.some(value => {
		return value.url === pageUrl;
	});

	if(hasUrl==false){
		const date1 = new Date();
		const date2 = ("00" + (date1.getMonth() + 1)).slice(-2)  + 
					("00" + (date1.getDate())).slice(-2) +
					("00" + (date1.getSeconds() + 1)).slice(-2) +
					("00" + (date1.getMilliseconds() + 1)).slice(-2);
	
		let pageTitle = document.title;
		let dateTime = date1.toLocaleString();//表記 2020/2/1 20:49:28
	
		document.cookie = 'url' + date2 + '='+ 'url=' + pageUrl + '&title=' + pageTitle + '&datetime=' + dateTime + ';' + cookieMaxage + ';'+cookiePath;

		histelem.insertAdjacentHTML('afterbegin','<li><a href="'+pageUrl+'">'+pageTitle+'</a></li>');

		alert('cookieにURLを格納しました。');

	}else{
		//alert('cookieに同じURLの履歴があります。');
	}
}


//cookieの値を削除
function cookieDelete(){
	let cookieArray = document.cookie.split(';');
	let urlList = cookieArray.filter(value => value.split('=')[0].match(/url/));
	let urlKey;

	urlList.map(function( value ) {
		urlKey = value.split('=')[0].trim();
		document.cookie = urlKey+'=; max-age=0'+ ';' + cookiePath;
	});

	histelem.innerHTML = '';

	alert('cookieの値を削除しました。');
}


//cookieの値を取得
function cookieGet() {
	//データを1つずつに分ける
	let cookieArray = document.cookie.split(';');
	//urlが付くキーのデータだけ抜き取る
	let urlList = cookieArray.filter(value => value.split('=')[0].match(/url/));

	let data,data1,data2,data3,data4,data5;

	urlList.map(function( value ) {
		let objData = {};//オブジェクト
		data = value.split('=');
		urlKey = data[0].trim();
		data1 = value.replace(data[0]+'=','');

		let data4 = data1.split('&');

		objData['name'] = urlKey;

		data4.filter( function( value ) {
			data2 = value.split('=');
			key = data2[0];
			objData[key] = data2[1];
		});

		histArray.push(objData);
	});

	return histArray;
}

/*function hasCookie() {
	let cookieArray = document.cookie.split(';');
	let urlList = cookieArray.filter(value => value.split('=')[0].match(/url/));
	console.log(urlList);

	let pattern = 'http://localhost:7000/test/sample11(cookie_history)/';

	let hasUrl = urlList.some(value => value.split('=')[1] === pattern);

	console.log(hasUrl);

}*/

