<?php
namespace SocymSlim\SlimMiddle\middlewares;

use PDO;
use PDOException;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;

class CheckIPAddressBefore implements MiddlewareInterface
{
    private $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;

    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        global $db;

        //PDOインスタンスをコンテナから取得
        $db = $this->container->get("db");

        $serverParams = $request->getServerParams();
        $ipAddress = $serverParams["REMOTE_ADDR"]; //取得したIPアドレス
        $folderName = basename($_SERVER['REQUEST_URI']); //フォルダ名

        if (empty($_SERVER['HTTP_REFERER'])) {
            //echo '未定義';
            $motourl = '../pages/pulic/guide';
        } else {
            $motourl = $_SERVER['HTTP_REFERER']; //遷移元のURL
        }

        //アクセスしたページが、locklistテーブルにページが存在するかチェック
        $sql_page = $db->prepare('select * from locklist where page=?');
        $sql_page->execute([$folderName]);
            $countPage = $sql_page->rowCount(); //0は、誰でも閲覧可能

        //admin_ipにIPアドレスが存在するかチェック
        $sql_ip = $db->prepare('select * from admin_ip where ip_address=?');
        $sql_ip->execute([$ipAddress]);
        $countIp = $sql_ip->rowCount(); //「1」は、ロックしたページでも閲覧可能

        //ロックしたページでかつユーザーのIPがadmin_ipテーブルにない場合、閲覧不可にする処理
        if ($countPage != 0 && $countIp == 0) {

            $lockPage = $sql_page->fetch(PDO::FETCH_ASSOC); 
            $underDir = $lockPage['under_dir'];

            if($underDir=='all'){
                //allの場合は閲覧不可でメニューに表示なし
                header('Location:' . $motourl, true, 307);
                exit;

            }elseif($underDir=='only'){
                //onlyの場合は閲覧不可でメニューに表示はあり
            }

            $viewFlag = 0; //閲覧不可

        }else{
            $viewFlag = 1; //閲覧可
        }

        $request = $request->withAttribute('flag', $viewFlag);//アクセスしたページが閲覧不可かの判定値（0は閲覧不可、1は閲覧可能）
        $request = $request->withAttribute('moto', $motourl);
        $request = $request->withAttribute('countIp', $countIp);//管理者か判定値（1は管理者、0は管理者以外）
        $request = $request->withAttribute('folderName', $folderName);

        $response = $handler->handle($request);
        return $response;
    }
}