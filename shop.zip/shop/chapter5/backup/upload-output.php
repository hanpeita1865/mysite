<?php require '../header.php'; ?>
<?php
if (is_uploaded_file($_FILES['file']['tmp_name'])) {　//入力画面からアップロードされたファイルかどうか調べる
	if (!file_exists('upload')) {　//フォルダが存在するか調べる。「!」は否定の意味
		mkdir('upload');　//フォルダを作成する。
	}
	$file='upload/'.basename($_FILES['file']['name']);//保存先のファイルのパスを変数に取得。
	if (move_uploaded_file($_FILES['file']['tmp_name'], $file)) {　//一時的なファイルを保存先のフォルダに保存する。
		echo $file, 'のアップロードに成功しました。';
		echo '<p><img src="', $file, '"></p>';
	} else {
		echo 'アップロードに失敗しました。';
	}
} else {
	echo 'ファイルを選択してください。';
}
?>
<?php require '../footer.php'; ?>
