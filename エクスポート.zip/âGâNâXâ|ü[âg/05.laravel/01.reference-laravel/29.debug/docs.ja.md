---
title: デバッグ方法
media_order: tinker1.png
taxonomy:
    category:
        - docs
---

## Tinker

Tinker を使ってDB の処理の内容を確認する方法もあります。  
これを使うとコマンドラインからデータベースに直接働きかけることができます。  
正確なシンタックスを覚えていないメソッドをテストしたいときはよく利用します。

まず、artisanコマンドで tinker を起動します。  
（※tinker は Laravel に標準で入っています）

<p class="tmp cmd"><span>コマンド</span>tinkerのartisanコマンド</p>
```
php artisan tinker
```
このあとは、コントローラに書くようなモデルなどの操作を書き、Enter を押すとその場で実行されます。  
以下は Eloquentリレーションを Tinker で確認したケースです。

例1)

自分カルテLaravelのフォルダにディレクトリを移動し、　\App\Models\SkillLvCategory::all();を入力してエンターキーを押すと、SkillLvCategoryモデルのデータが出力される

![](tinker1.png)

### 参考サイト

* [Laravel学習帳 Laravelでのデバッグ作業　まとめ](https://laraweb.net/practice/4298/)