---
title: 管理ツールを使おう
media_order: 'password1.png,login1.png,admin1.png,Friends1.png,Friends2.png,Friends5.png,Friends6.png,changePassword.png,changePass2.png,changepass3.png'
taxonomy:
    category:
        - docs
visible: true
---

<style>
span.tmp {
	letter-spacing: -0.03rem;
    padding: .2rem .5rem .2rem .4rem;
    margin-right: .5rem;
}
span.tmp.list {
	background-color: #008000;
}

</style>



Djangoにはデータベースの管理ツールが用意されていて、それを使ってWeb上でテーブルなどの編集が行えるようになっています。


<p class="mb-05"><span class="tmp">書式</span><span class="bold">管理者の作成コマンド</span></p>

	python manage.py createsuperuser


コマンドを実行すると、次々と管理者権限を尋ねてくるので、順に入力していきます。

**{c:red}※GRAVを公開する時は、下記のメールアドレスとパスワードは変更する{/c}**

| 入力項目 | 内容| 
| -------- | -------- |
| Username     | 管理者名を入力します。　ryouma     | 
| Email address    | メールアドレスを入力します。 ryouma@test.ne.jp     | 
| Password     | パスワードを入力します。8文字以上	12345678　→表示はされないが入力されている     | 
| Password(Again)    | パスワードをもう一度入力します。	12435678     | 

※これらは管理ツールへのログイン時に必要となるので、メモして忘れないようにしましょう。

![](password1.png?classes=caption "図 createsuperuserコマンドで管理者を作成する。")

パスワード等を入力し、yを入力してEnterキーで「Superuser created successfully.」が表示されたら、パスワード設定が完了です。

パスワードを変更するには、以下を使用します。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">パスワード再設定コマンド</span></p>
	python manage.py changepassword

※一度使用したパスワードを入力するとエラーになります。


## Friendを登録する

次に行うのは、Frindモデルを管理ツールで利用できるように登録する作業です。  
管理ツールは、すべてのモデルを編集できるわけではありません。  
あらかじめ「このモデルは管理ツールで利用できる」というように登録されたものだけがツールで編集できるのです。  
これらは、「hello」フォルダ内の**admin.py**というファイルで行います。



<p class="mb-05"><span class="tmp list">リスト3-7</span><span class="bold">admin.pyデフォルト</span></p>

    from django.contrib import admin

    # Register your models here.


django.contribのadminというものをimportしています。  
このadminを使って、モデルの登録を行うようになっています。

下記リスト3-8のようにadminを書き換えます。

<p class="mb-05"><span class="tmp list">リスト3-8</span><span class="bold">admin.py書き換え</span></p>

	from django.contrib import admin
    from .models import Friend

    admin.site.register(Friend)


admin.site.registerというのが、登録するメソッドです。  
これに登録するモデルクラスを指定すれば、そのクラスが管理ツールで編集できるようになります。


## 管理ツールにログインする

管理ツールを使ってみます。管理ツールは、DjangoのWebアプリとして用意されています。  
利用するには、まずサーバーでDjangoプロジェクトを実行する必要があります。

ターミナルから「**python manage.py runserver**」を実行します。  
（既定のポート番号（80）を使用されてれば、別のポート番号を入れて実行 → **python manage.py runserver 8080**）

Webブラウザから下記のアドレスにアクセスしてください。

**http://localhost:8000/admin**  
（別のポート番号を入れてアクセスの場合 → **http://localhost:8080/admin**）  
※これが管理ツールのアドレスになります。  

アクセスすると、下記のようにログインページにリダイレクトされます。

![](login1.png?classes=caption "図　ログイン画面")

ここで先ほど管理者登録したユーザー名とパスワードを入力してください。  
そして「LOG IN」ボタンをクリックすれば、管理ツールにログインできます。


## 管理ツール画面について

ログインすると、管理画面が現れます。  
ここでは、利用可能なモデル（テーブル）が表示されています。

![](admin1.png?classes=caption "図　管理画面")

上部のリスト
: 「AUTHEENTICATION AND AUTHORIZATION」と表示されているリストです。
これは、管理ツールであるadminアプリケーションが使用しているモデルです。
「Groups」と「Users」というモデルが用意されています。

下部のリスト
: 「HELLO」と表示されているところが、helloアプリケーションに用意されているモデルです。
「Friends」だけが表示されています。これが、先ほどマイグレーションで作ったFriendモデルのテーブルです。

右側のリンク
: 「Recent Actions」というところには、最近移動したページへのリンクが表示されます。  
「前に操作したページに戻りたい」といったときに素早く移動できます。
まだ何も操作してなければ、None availableと表示されます。



<h3 class="h-type3">Friendsテーブルを見てみる</h3>

HELLOのところにある「Friends」の項目をクリックしてみます。
下記のようなFriendsテーブルの編集ページに移動します。
（まだ最初はレコードがないので、何も表示されていません。）

![](Friends1.png?classes=caption "図　Friendsテーブルの編集ページ")

### レコードを作成する。

右側にある「ADD FRIEMD +」というボタンをクリックしてみます。
すると、下記のようなレコードの作成ページに移動します。

![](Friends2.png?classes=caption "図　Friendsの作成ページ。項目を記入し、「SAVE」ボタンを押す。")

レコードを追加すると、レコードのリスト部分に<Friend:id=1, hirao(48)>という形でレコードの内容が表示されます。  
これは&#95;&#95;str&#95;&#95;メソッドで用意した表示の形式です。  
Friendインスタンスを{{}}で表示すると、このように&#95;&#95;str&#95;&#95;で出力した形になるのが確認できます。

![](Friends5.png?classes=caption "図　追加したレコードが表示されます")

### レコードを作成する。

管理ツールのトップページにもどり（パンくずのHomeをクリック）、「Users」のリンクをクリックすると、Userの管理ページに移動します。

![](Friends6.png?classes=caption "図　Userの管理ページ")

<h3 class="h-type3">Usersページの機能</h3>

検索フィールド
: 上部にある入力フィールドは、レコードを検索するためのものです。
ここで利用者名を記入し、「Search」ボタンを押すと、その名前の利用者レコードを検索し下に表示します。

Action
: これは、Friendsでも（レコードを登録すれば）表示されます。
プルダウンメニューは、選択したレコードを操作するためのものです。
標準では、選択したレコードを削除るためのメニュー項目だけが用意されています。

Filter
: ウィンドウの右側には、フィルター機能のリンクがまとめてあります。
ここにあるリンクをクリックすることで、管理者（superuser）だけを表示したり、スタッフ（staff）だけを表示したりできます。


### レコードを作成する。

「ADD USER+」ボタンをクリックして、利用者を追加してみます。  
ボタンをクリックすると、利用者登録のページに移動し、ここで適当に項目を記入します。

図　利用者の登録ページ

| |  | 
| -------- | -------- | 
| Username    | 利用者の名前     | 
| Password    | パスワード（8文字以上）     |
| Password Contirmation     | パスワードの確認用。     |


これらを記入して「SAVE」ボタンをクリックします。


### 追加の設定を行う

「SAVE」ボタンを押すと、追加の設定を行うページに移動します。  
このページは、利用者の作成だけでなく、既にある利用者の設定を変更する際にも表示されます。

Change user
: 登録されている利用者名とパスワードが表示されています。
パスワードは変更できませんが、利用者名は変更できます。

Personal info
: 利用者の個人情報を入力します。氏名、メールアドレスなどの項目があります。


Permissions
: これはパーミッション（アクセス権）に関するものです。
これは非常に多くの項目が用意されています。

|||
| -------- | -- |
|Active|　アクティブ（利用中）か否か。|
|Staff status|　スタッフ権限を持っているかどうか。|
|Superuser status|　管理者権限を持っているかどうか|
|Groups　|グループ（複数の利用者をまとめたもの）の所属の設定。|
|User permissions|　利用者に割り当てる権限のリスト。管理者の権限や、登録してあるモデル（Friendなど）の作成や削除などの権限を個別に割り当てられる。|
|Important dates|　この利用者を追加した日時と、最後にログインした日時が設定されています。これらは変更することもできます。|


<h3 class="h-type3">パスワードを変更するには</h3>

UsersのChangeリンクをクリックし、Change Userのページに移動します。
下記の画像の赤線を引いているPasswordの所に小さく「this form」というリンクがあるので、それをクリックします。


![](changepass3.png?classes=caption "図　「this form」リンク")

そうするとパスワード変更画面に移動するので、そこで古いパスと新しいパスを入力して変更します。

![](changePass2.png?classes=caption "図　パスワード変更画面")




