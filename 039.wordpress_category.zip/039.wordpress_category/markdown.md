*[page-title]:Categoryページの作成

複数のカテゴリーページを作成する場合は、「category-〇〇〇」のテンプレートを複数作成して「function.php」にそれぞれの「〇〇〇」用のコードを追加します。

<http://localhost:7001/wordpress/category/custom1/>  
<http://localhost:7001/wordpress/category/custom2/>


<p class="tmp list"><span>リスト</span>category-cuntom1.php（テンプレート）</p>
```
<?php get_header(); ?>
<!-- 上記が追記するコード -->
<p>category-cuntom1.php</p>
<section id="content">
	<div id="content-wrap" class="container">
		<div id="main" class="col-md-9">
			<h1>
			<?php $cat_info = get_category( $cat );?>
			<?php echo wp_specialchars( $cat_info->name ); ?>
			</h1>
		</div>

		<div id="sidebar" class="col-md-3">
			<?php get_sidebar(); ?>
			<!-- 上記が追記するコード -->
		</div>
	</div>
</section>
<!-- 下記が追記するコード -->
<?php get_footer(); ?>
```

<p class="tmp list"><span>リスト</span>category-cuntom2.php（テンプレート）</p>
```
<?php get_header(); ?>
<!-- 上記が追記するコード -->
<p>category-cuntom2.php</p>
<section id="content">
	<div id="content-wrap" class="container">
		<div id="main" class="col-md-9">
			<h1>
			<?php $cat_info = get_category( $cat );?>
			<?php echo wp_specialchars( $cat_info->name ); ?>
			</h1>
		</div>

		<div id="sidebar" class="col-md-3">
			<?php get_sidebar(); ?>
			<!-- 上記が追記するコード -->
		</div>
	</div>
</section>
<!-- 下記が追記するコード -->
<?php get_footer(); ?>
```


<p class="tmp list"><span>リスト</span>function.php</p>
```
add_action('init', 'create_post_type');

function create_post_type()
{
	//カスタム投稿タイプ１（ここから）
	register_post_type(
		'custom1',
		array(
			'labels' => array(
				'name' => __('カスタム投稿タイプ１'),
				'singular_name' => __('カスタム投稿タイプ１'),
			),
			'public' => true,
			'menu_position' => 5,
		)
	);

	//カスタム投稿タイプ２（ここから）
	register_post_type(
		'custom2',
		array(
			'labels' => array(
				'name' => __('カスタム投稿タイプ２'),
				'singular_name' => __('カスタム投稿タイプ２'),
			),
			'public' => true,
			'menu_position' => 5,
		)
	);
}
```
