<?php require '../header.php'; ?>
<?php
echo '<img src="item', rand(0, 2), '.png">';
?>
<?php require '../footer.php'; ?>
