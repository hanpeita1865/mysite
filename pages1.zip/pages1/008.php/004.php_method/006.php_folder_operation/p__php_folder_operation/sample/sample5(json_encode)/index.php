<?php
	//配列を作成
	$fruits_array = ['apple'=>'りんご',
					 'orange'=>'オレンジ',
					 'melon'=>'メロン',
					 'pineapple'=>'パイナップル'
					];

	//配列をJSON形式に変換
	$jsonstr =  json_encode($fruits_array, JSON_UNESCAPED_UNICODE);

	echo $jsonstr;
?>