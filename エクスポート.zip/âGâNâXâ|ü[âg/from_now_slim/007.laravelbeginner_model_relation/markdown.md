*[page-title]:モデルのリレーション

複数のテーブルが関連しながら動くプログラムでは、モデルの「<span class="green bold marker-yellow50">リレーション</span>」と呼ばれる機能を使い、テーブルを関連付けて操作します。このリレーションの使い方をここで説明しましょう。

## モデルのリレーションとは？

データベースを利用するアプリケーションでは、1つのテーブルだけで全てが完結する、ということはあまりありません。それよりも、複数のテーブルを組み合わせて利用することのほうが多いでしょう。 そのような場合に重要となってくるのが、「<span class="red">テーブルの関連付け</span>」です。 

例えば、掲示板のアプリケーションを考えてみましょう。  
掲示板にはさまざまなメッセージを投稿します。ですから、「メッセージを管理するテーブルが必要だ」ということは誰でも思いつくでしょう。  
が、それだけでは掲示板としては不完全です。そのメッセージを投稿したのは誰か？ ということもわからないといけません。そこで、利用者のテーブルを用意し、それを元にログインしてメッセージを投稿するような仕組みを考えることになるでしょう。  
このとき、メッセージのテーブルでは、「どの利用者がそのメッセージを投稿したか」 がわかるような仕掛けが必要になります。例えば、投稿した利用者のIDをメッセージに 保管し、それを元に利用者情報が得られるようにする、という具合です。

しかし、メッセージをずらっと一覧表示したとき、1つ1つのメッセージについて、投稿者のIDを元に利用者テーブルからレコードを検索して名前を取り出して表示して...... といったことを繰り返していくのは非常に面倒です。それに一覧リストを表示するために一体どれだけデータベースにアクセスしないといけないか、を考えると非常に無駄な やり方といえます。

SQLデータベースには、「<span class="bold red">あるテーブルのレコードが別のテーブルのレコードに関連付けられる</span>」といったことを設定する仕組みが用意されています。これを元に効率的に関連レコードを取得できれば、無駄なデータベースアクセスもなくなり、複数のテーブルにまたがった情報をまとめて取り出せるようになります。  
このようなテーブルどうしの関連付けを、「<span class="green bold marker-yellow50">リレーション</span>」と呼びます。<span class="bold red">Eloquentには、リレーションを簡単に実装するための仕組みが用意されています</span>。その基本を覚え、複数のテーブル情報をスムーズに利用できるようにしましょう。  

![](upload/relation_howto.png "図　掲示板を考えたとき、投稿メッセージに投稿者のIDを保管し、それを元に利用者を取得する。このような関連付けが「リレーション」です。")



### boardsテーブルを利用する
では、テーブルの関連付け（リレーション）について説明をしていきましょう。が、その前に、実際にリレーションの動作を確認できるよう、テーブルをもう1つ用意することにしましょう。  
既に、customersというテーブルを作成して、ユーザーの基本情報を保存できるようにしてあります。これに関連付けるものとして、簡単なメッセージを管理する「boards」というテーブルを作成することにしましょう。 このテーブルには、以下のようなフィールドを用意します。

<p class="tb-caption"><span>表　boardsテーブル</span></p>
|フィールド|用途|
|--|--|
|id|レコードに割り振られるIDです。|
|customer_id|関連するcustomersテーブルのレコードIDを保管します。|
|title|投稿メッセージのタイトルです。|
|massage|投稿したメッセージです。|
|created at| 制作日時です。|
|updated_at|更新日時です。|


最後のcreated_at / updated_atは、マイグレーションを使ってテーブルを作成すると自動生成されるものでした。今回もマイグレーションを利用してテーブルを作成することにしましょう。  
なお、「SQLコマンドを使って自分でテーブルを作っておきたい」という人のために、SQLクエリ文を掲載してきましょう。以下のようにSQLコマンドを実行します。

<p class="tmp list"><span>リスト1-1</span>SQL文参考</p>
```
CREATE TABLE `boards` (
  `id` int(10) UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `customer_id`  int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
)
```

boardsテーブルが作成されました。
![](upload/boardsテーブル作成.png){.photo-border}

※マイグレーションの作成をする場合、SQLでのテーブル作成は必要ありません。

### マイグレーションの作成
では、boardsテーブルを利用するための準備を整えていきましょう。まず、boardsテーブルを作成するためのマイグレーションファイルを用意します。既に、直接SQLクエリー を実行してテーブルを作成している場合は必要ありませんが、そうでない人は、マイグレーションファイルを作成し、それを利用してテーブルを生成して下さい。

マイグレーションファイルは、artisanコマンドで作成できました。コマンドプロンプトあるいはターミナルでプロジェクトのフォルダ（laravelapp」フォルダ）内に移動し、 以下のようにコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>「boards」テーブルのマイグレーションの作成</p>
```
php artisan make:migration create_boards_table
```

![](upload/boardsテーブル作成コマンドプロンプト.png)

これで、「database」内の「migrations」フォルダの中に「xxxx_create_boards_table.php」（xxxxは任意の日時）というマイグレーションファイルが作成されます。ここに、テーブル生成と削除の処理を用意すればいいのです。

![](upload/boardsマイグレーションファイル作成.png){.photo-border}


#### マイグレーション処理の記述
作成されたマイグレーションファイル（xxxx_create_boards_table.php）を開き、マイグレーションの処理を記述しましょう。デフォルトの「up()メソッド」のコードを書き換えてください。

<p class="tmp list"><span>リスト1-2</span></p>
```
<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBoardsTable extends Migration
{

   public function up(): void
   {
       Schema::create('boards', function (Blueprint $table) {
           $table->increments('id');
           $table->integer('customer_id');
           $table->string('title');
           $table->string('message');
           $table->timestamps();
       });
   }

   public function down()
   {
       Schema::dropIfExists('boards');
   }
}
```

ここでは、upメソッドにテーブル生成の処理を、downメソッドにテーブル削除の処理をそれぞれ用意しました。  
テーブルの生成は、Schema::createメソッドを利用しました。第1引数には、テーブル名('boards)を指定します。第2引数のクロージャでは、以下のようにテーブルのフィー ルドを設定しています。

```
$table->increments('id');
```

プライマリキー「id」の指定です。オートインクリメントを指定して設定します。
```
$table->integer('customer_id');
```

customer_idフィールドです。これは、関連するcustomersテーブルのレコードIDを保管するためのものです。関連するレコードは1つなので、customers_idではなく、単数形のcustomer_idという名前にしておきます。

```
$table->string('title'); $table->string('message');
```

その他のフィールド設定です。titleとmessageというフィールドを追加設定します。 いずれもstringメソッドで用意しておきます。
```
$table->timestamps();
```

作成日時と更新日時を保管する<span class="red">created_at</span>と<span class="red">updated_at</span>フィールドを追加します。これらはLarabelにより自動生成されるフィールドで、値の保存も自動で行ってくれます。


#### マイグレーションの実行
では、ファイルを保存したら、コマンドプロンプトからマイグレーションを実行します。

<p class="tmp cmd"><span>コマンド</span>マイグレーションの実行</p>
```
php artisan migrate
```

これで、create_boards_tableが実行され、boardsテーブルが用意されます。データベースを確認すると、boardsというテーブルが作成されていることがわかるでしょう。

![](upload/マイグレーションで作成されたテーブル.png "図　マイグレーションで作成されたテーブル"){.photo-border}



## モデルの作成

これでテーブルの用意はできました。続いて、モデルを作成します。これもコマンド でスクリプトファイルを生成できました。コマンドプロンプトから以下のように実行して下さい。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:model Board
```

これで、「app」内に「<span class="red">Board.php</span>」という名前でモデルのファイルが作成されます。

![](upload/モデルBoard.php作成.png "図　モデルのファイル「Board.php」作成"){.photo-border}


モデルは、このように単数形の名前で作成をします。テーブルが<span class="blue bold">boards</span>でしたから、モデルは「<span class="red bold">Board</span>」となります。



### スクリプトの作成
では、作成された「Board.php」ファイルを開き、スクリプトを完成させましょう。以下のように内容を書き換えて下さい。

<p class="tmp list"><span>リスト2-1</span>Models/Board.php</p>
```
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Board extends Model
{
    protected $guarded = array('id');

    public static $rules = array(
       'customer_id' => 'required',
       'title' => 'required',
       'message' => 'required'
   );

   public function getData() {
       return $this->id . ': ' . $this->title;
   }
}
```

ここでは、基本的なバリデーションの設定情報と、データの内容をテキストで返す getDataメソッドを用意しておきました。これらは、既に説明済みのものです。



## BoardControllerの作成

続いて、コントローラを作成しましょう。コマンドプロンプトまたはターミナルから、 以下のようにコマンドを実行して下さい。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:controller BoardController
```


これで、「Http」内の「Controllers」フォルダに「<span class="red">BoardController.php</span>」が作成されます。

![](upload/BoardController.php作成.png "図 「BoardController.php」作成"){.photo-border}

このファイルを開いて、ソースコードを記述しましょう。ここでは、レコードを一覧表示するindexと、新規投稿のためのadd/createといったメソッドを用意しておくことにします。

<p class="tmp list"><span>リスト3-1</span>BoardController.php（デフォルト）</p>
```
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BoardController extends Controller
{
    //
}
```

<p class="tmp list"><span>リスト3-2</span>BoardController.php</p>
```
<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Board;
use Illuminate\Http\Request;

class BoardController extends Controller
{
    //レコード一覧表示
    public function index(Request $request)
    {
        $items = Board::all();
        return view('board.index', ['items' => $items]);
    }

	//新規投稿
    public function add(Request $request)
    {
        return view('board.add');
    }

    public function create(Request $request)
    {
        $this->validate($request, Board::$rules);
        $board = new Board;
        $form = $request->all();
        unset($form['_token']);
        $board->fill($form)->save();
        return redirect('/board');
    }
}
```

indexでは、<span class="red bold">Board::all</span> で全レコードを呼び出し、これを<span class="red bold"> $items</span> という変数に渡しています。

addは特に何も処理はしておらず、<span class="blue bold">create</span>でフォーム送信された値を元に<span class="red bold">new Board</span>を作成し、<span class="red bold">save</span>で保存をしています。いずれも処理の基本は既に説明済みですから、改めて補足することはないでしょう。



## テンプレートの作成

コントローラで「index」と「add/createアクション」を用意したので、これらのテンプレート も用意しておく必要があります。  
「views」内に「<span class="red">board</span>」という名前でフォルダを用意し、 その中に「<span class="red">index.blade.php</span>」「<span class="red">add.blade.php</span>」という2つのテンプレートファイルを用意しましょう。


index.blade.phpは、以下のように記述しておきます。

<p class="tmp list"><span>リスト4-1</span>board/index.blade.php </p>
```
@extends('layouts.helloapp')

@section('title', 'Board.index')

@section('menubar')
   @parent
   ボード・ページ
@endsection

@section('content')
   <table>
   <tr><th>Data</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->getData()}}</td>
       </tr>
   @endforeach
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```

テーブルを利用し、@foreach ($items as $item)で$itemsから順に値を取り出し表示していきます。内容の表示は、{( $item->getData()}}というようにgetDataを利用しておきました。ここでは、どんなレコードが得られているかがわかればいいので、これで十分でしょう。


続いて、add.blade.phpです。こちらは投稿をするためのフォームを用意しておきます。 以下のように内容を記述して下さい。

<p class="tmp list"><span>リスト4-2</span>board/add.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Board.Add')

@section('menubar')
   @parent
   投稿ページ
@endsection

@section('content')
   <table>
   <form action="/board/add" method="post">
      {{ csrf_field() }}
      <tr><th>customer id: </th><td><input type="number" 
         name="customer_id"></td></tr>
      <tr><th>title: </th><td><input type="text" 
         name="title"></td></tr>
      <tr><th>message: </th><td><input type="text" 
         name="message"></td></tr>
      <tr><th></th><td><input type="submit" 
         value="send"></td></tr>
   </form>
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```

ここでは、customer_id、title、messageといった名前のコントロールを持ったフォーム を用意しておきました。これらに入力して送信すれば、Boardモデルを保存し、boardsテー ブルにレコードが追加されるようになる、というわけです。


#### ルート情報の記述
最後に、ルート情報を記述しましょう。web.phpを開き、以下のようにルート情報を追記して下さい。

<p class="tmp list"><span>リスト4-3</span>web.php</p>
```
Route::get('board', [\App\Http\Controllers\CustomerController::class,'index']);
Route::get('board/add', [\App\Http\Controllers\CustomerController::class,'add']);
Route::get('board/add', [\App\Http\Controllers\CustomerController::class,'create']);
```

これで、「/board/add」にアクセスし、フォームに値を記入して送信すればレコードが保存されます。

![](upload/board_addフォーム入力.png "図　データを記入して送信"){.photo-border}
<span class="arrow-down ml-5"></span>
<div markdown="1" class="d-flex align-items-end flex-nowrap">
![](upload/boardテーブルにデータが追加.png "図　boardテーブルにデータが追加"){.photo-border}
![](upload/boardテーブルにレコード追加.png "図　データベースのboardテーブル"){.photo-border .ml-3}
</div>


また、「/board」にアクセスすると、投稿したboardsテーブルの一覧が表示されるようになります。初期状態では何もレコードがないので表示はされませんので、「/ board/add」にアクセスしていくつか投稿をしてから表示を確認するとよいでしょう。



## has Oneについて

これでようやく、複数レコードのリレーションをチェックする環境が整いました。では、リレーションの働きについて説明していくことにしましょう。  
リレーションを考える場合、まず「2つのテーブルの関係」について理解をしておかないといけません。リレーションの関係があるテーブルでは、一方に「外部キー」と呼ばれる項目が用意されています。外部キーというのは、関連するもう1つのテーブルのレコードIDを保管しておくフィールドのことです。ここでは、boardsテーブル側に、customer_id という外部キーが用意されていました。

2つのテーブルの関係を考えるとき、外部キーを持たない側のテーブルが主テーブル（中心となるテーブル）、外部キーによって主テーブルの関連情報を保管している側のテーブルが従テーブル（主テーブルにしたがって扱われるテーブル）となります。今回の例でいえば、customersテーブルが主テーブルであり、customersテーブルのIDを保管しているboardsテーブルが従テーブルとなります。  
リレーションを考えるとき、「どちら側のテーブルにどんなものが用意されるか」をよく理解していないといけません。そのためにも、「主テーブルと従テーブル」の関係をよく頭に入れておいて下さい。

![](upload/relation_main_table.png "図　他のテーブルから参照される側のテーブルが主テーブル、主テーブルのID情報を保管している側が従テーブルとなる。")


### has One結合

リレーションには、いくつかの種類があります。もっともシンプルなのは、「<span class="green bold marker-yellow50">has One</span>」と呼ばれるリレーションです。  
「has One」は、2つのテーブルが「<span class="bold">1対1</span>」の関係で関連付けられているものをいいます。 このhas Oneの関連付けは、主テーブル側にそのための設定を用意しておきます。つまり、 has Oneは、「主テーブルから、それに関連する従テーブルを取得する」ための機能といってよいでしょう。

![](upload/has_one_table1.png "図　主テーブル側から、関連する従テーブルの1つのレコードを結びつけて取り出せるようにするのがhas Oneのリレーション。")


#### Customer モデルの修正
では、実際にhas Oneの動作を確かめてみましょう。 has Oneの機能を利用できるようにするためには、主テーブル側（ここではCustomerモデル）に、そのためのコードを追記しておく必要があります。 Customer.phpを開いて、Customerクラスに以下のメソッドを追加して下さい。

<p class="tmp list"><span>リスト5-1</span>Customer.php</p>
```
public function board()
{
   return $this->hasOne('App\Models\Board');
}
```


ここでは、「board」という名前のメソッドを定義してあります。このメソッドの中では、$thisの「hasOne」メソッドが呼び出されています。引数には、has Oneで関連付けられるモデルを指定します。そしてhasOneの戻り値をそのままreturnで返しています。  

このように、リレーションは、モデルクラスの中にちょっとしたメソッドを追加するだけです。メソッド名は、リレーションで関連付けるモデル名（ただし、1対1で1つしか 取り出されないので、単数形の名前にしてあります）。そしてその内部で実行しているのは、「hasOne」という名前のメソッドです。　　
hasOneは、モデルから引数に指定したモデルへの関連付けを設定します。これにより、<span class="marker-yellow50 bold">このcustomersテーブルのレコードに関連付けを行ったboardsテーブルのレコードが取り出せるようになる</span>のです。

#### テンプレートの修正
続いて、リレーションによって取り出された関連テーブルの情報を表示するようにテンプレートを作成しましょう。  
ここでは、customers側のindexHasone.blade.php （board側ではないので注意!）を追加しましょう。 @section('content')ディレクトリ部分を以下のように修正して下さい。

<p class="tmp list"><span>リスト5-2</span>customer/indexHasone.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Customer.index')

@section('menubar')
   @parent
   インデックスページ
@endsection

@section('content')
   <table>
   <tr><th>Customer</th><th>Board</th></tr>
   @foreach ($items as $item) 
       <tr>
           <td>{{$item->getData()}}</td>
           <td>@if ($item->board != null)
                   {{$item->board->getData()}}
               @endif
           </td>
       </tr>
   @endforeach
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```

コントローラーとルート情報に追加します。

<p class="tmp list"><span>リスト5-3</span>CustomerController.php</p>
```
public function indexHasone(Request $request)
{
    $items = Customer::all();
    return view('customer.indexHasone', ['items' => $items]);
}
```

<p class="tmp list"><span>リスト5-4</span>web.php</p>
```
Route::get('customerHasone', [\App\Http\Controllers\CustomerController::class,'indexHasone']);
```

「/customerHasone」にアクセスすると、各利用者ごとに、投稿を行っていた場合はその中から1つを取得し、その内容を出力しています。
![](upload/customerHasoneテーブル.png){.photo-border}

ここでは、<span class="red">$item->getData()</span>でcustomerの情報を表示し、更にその後に、以下のような形で関連するboardsテーブルのgetData()を出力しています。
```
{{$item->board->getData()}}
```

先ほど、Customerモデルに「board」というメソッドを追加したことを思い出して下さい。 メソッドですから、本来は <span class="red">$item->board() </span>となるはずです。が、リレーションの設定を行った場合、このように <span class="red bold">$item->board</span> という<span class="marker-yellow50 bold">プロパティ</span>として扱えるようになります。  
このboardプロパティには、関連付けられたBoardモデルのインスタンスが入っています。そこから必要な情報を取り出して利用できるのです。


## has Many結合

has Oneは、1対1の関係でした。が、例えば利用者と掲示板データの場合、1人の利用者がいくつも投稿をすることもあります。このような場合には、「<span class="red bold">has Many（1対多）</span>」 結合と呼ばれるリレーションが使われます。  
has Manyは、has Oneと同様、主テーブル側に用意するリレーションです。これにより、主テーブルのレコードと関連する、複数の従テーブルレコードに関連付けを行うことができます。

![](upload/has_many1.png "図　主テーブルから、複数の従テーブルのレコードに関連付けるのがhas Many結合")

### Customer モデルの修正
では、これも試してみましょう。先ほど、Customerモデルに「 boardMany」メソッドを以下のように追加して下さい。

<p class="tmp list"><span>リスト6-1</span>Customer.php</p>
```
public function boards()
{
   return $this->hasMany('App\Models\Board');
}
```

今回は、複数のレコードと関連付けられるので、メソッド名は「<span class="red">boards</span>」と複数形にしました。そしてその内部では、<span class="red">$this->hasMany</span>の戻り値をそのままreturnしています。 これで、Customer内のboardsプロパティで、関連する複数のBoardインスタンスが取り出せるようになります。

### index.blade.php
では、テンプレートも修正をしましょう。customer側のindex.blade.php（customer/index.blade.php）を以下のように修正して下さい。

<p class="tmp list"><span>リスト6-2</span>customer/indexHasmany.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Customer.index')

@section('menubar')
   @parent
   インデックスページ
@endsection

@section('content')
   <table>
   <tr><th>Customer</th><th>Board</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->getData()}}</td>
           <td>
           @if ($item->boards != null)
               <table width="100%">
               @foreach ($item->boards as $obj)
                   <tr><td>{{$obj->getData()}}</td></tr>
               @endforeach
               </table>
           @endif
           </td>
       </tr>
   @endforeach
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```

コントローラーとルート情報に追加します。
<p class="tmp list"><span>リスト6-3</span>CustomerController.php</p>
```
    public function indexHasmany(Request $request)
    {
        $items = Customer::all();
        return view('customer.indexHasmany', ['items' => $items]);
    }
```

<p class="tmp list"><span>リスト6-4</span>web.php</p>
```
Route::get('customerHasmany', [\App\Http\Controllers\CustomerController::class,'indexHasmany']);
```

boardsテーブルに試しに、customer_idが同じレコードをboard/addの画面から追加して、以下のようにしておきます。

![](upload/boardsテーブル1.png "図　boardsテーブル"){.photo-border}


修正したら、「/customerHasmany」にアクセスしてみましょう。それぞれの利用者のところに、投稿したテキストのタイトルがすべて表示されるようになります。 

![](upload/Hasmany表示.png "図　それぞれの利用者の投稿がすべてまとめて表示される"){.photo-border}

ここでは、$item->boardsがnullでなければ、以下のように繰り返し処理を行っています。
```
@foreach ($item->boards as $obj)
	<tr><td>{{$obj->getData()}}</td></tr> 
@endforeach
```
$item->boardsから順に値を$objに取り出し、そこからgetDataの内容を出力しています。こうすることで、boardsに関連付けられたすべてのレコードの値を表示しています。



## belongsTo結合

has Oneやhas Manyは、主テーブル側から関連する従テーブルを取り出すものでした。 が、逆に「従テーブル側から、関連付けている主テーブルのレコードを取り出す」というものも必要です。これが「<span class="green bold marker-yellow50">belongsTo</span>」です。  
belongsToは、従テーブルに用意されている外部キーで関連付けられている主テーブ ルのレコードを取り出すものです。これは、基本的に1つのレコードだけが取り出されます。  
たとえば、サンプルで考えるなら、掲示板の投稿データには、投稿者のレコードIDが 設定されています。投稿者からは複数の投稿が関連付けられています（has Many）が、投稿側からは、投稿者は常に一人です。ですから、belongsToで得られるのは常に1つのレコードだけです。

![](upload/belongs_to.png "図　従テーブル側から、関連する主テーブルを取り出すのがbelongsTo結合です。")


### Board モデルの修正
では、サンプルで試してみましょう。今度は、Boardモデルクラス側を修正します。 Boardクラス内にcustomerメソッドを追記し、getDataメソッドを修正して下さい。

<p class="tmp list"><span>リスト7-1</span>Board.php</p>
```
// 新たにメソッドを追加
public function customer()
{
   return $this->belongsTo('App\Customer');
}

// 既にあるメソッドを修正して追加
public function getData2()
{
    return $this->id . ': ' . $this->title . ' (' 
        . $this->customer->name . ')';
}
```

コントローラーとルート情報にも追記します。

<p class="tmp list"><span>リスト7-2</span>BoardController.php</p>
```
public function index2(Request $request)
{
    $items = Board::all();
    return view('board.index2', ['items' => $items]);
}
```

<p class="tmp list"><span>リスト7-3</span>web.php</p>
```
Route::get('board2', [\App\Http\Controllers\BoardController::class,'index2']);
```

修正したら、/board2にアクセスしてみましょう。投稿したメッセージのタイトルと投稿者の名前が一覧表示されます。

![](upload/belongsto表示.png "図 「/board2」にアクセスすると、投稿のタイトルと投稿者の名前が表示される。"){.photo-border}

メッセージには、投稿者の情報は含まれていません。ですから、これはCustomerから取り出していることになります。getData2メソッドを見ると、<span class="red">$this->customer->name</span>というようにして投稿者の名前を取り出していることがわかります。belongsToにより、このようにしてCustomerの情報が取り出せるようになっているのです。



## 関連レコードの有無 

Boardモデルは、投稿者のレコードとなるCustomerモデルに必ず関連付けられています。 つまり、Customerと関連性を持たないBoardは存在しないわけです。    
が、Customerは違います。利用者の中には頻繁に投稿する人もあれば、全くしないで見ているだけの人もいます。つまり、Customerは、関連するBoardを複数保つ場合もあれば、まったく持たない場合もあるわけです。  

このような場合、「<span class="bold">関連するBoardを持っているCustomerのみ</span>」を取り出すようなことができれば、ずいぶんと便利です。逆に「<span class="bold">Boardを持たないCustomer</span>」だけを取り出せてもいろいろ役に立ちそうです。  
こうした関連付けの有無は、モデルにある「has」「doesntHave」といったメソッドを使って簡単に取り出すことができます。これらは、whereメソッドと同様にビルダを返すメソッドです。ですから、これらを呼び出した後、getやfirstを使ってモデルを取得します。

<p class="tmp"><span>書式1</span>指定のリレーションの値を持つ</p>
```
モデル ::has( リレーション名 )->get();
```

<p class="tmp"><span>書式2</span>指定のリレーションの値を持たない</p>
```
モデル ::doesntHave(リレーション名 )->get();
```

### 投稿を持つ・持たないを分ける
では、実際に利用してみましょう。/customerのアクションを修正し、投稿（Board）を持つものと持たないものを別々に表示させてみましょう。 まず、CustomerControllerの修正です。indexメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト8-1</span>CustomerController.php</p>
```
//投稿を持つ・持たないを分ける
public function indexHas(Request $request) {
    $hasItems = Customer::has('boards')->get();
    $noItems = Customer::doesntHave('boards')->get();
    $param = ['hasItems' => $hasItems, 'noItems' => $noItems];
    return view('customer.indexHas', $param);
}
```

ここでは、Customer::has('boards')とCustomer::doesntHave('boards')をそれぞれ、getで取り出しています。これで、Boardを持つものと持たないものをそれぞれ変数に取り出せました。  
では、これらを画面に表示するようにindex.blade.php（「customer」内にあるもの）の @section('content')ディレクティブ部分を修正しましょう。

<p class="tmp list"><span>リスト8-2</span>customer/index.php</p>
```
@section('content')
   <table>
   <tr><th>Customer</th><th>Board</th></tr>
   @foreach ($hasItems as $item)<!--boardを持つ(投稿している人)-->
       <tr>
           <td>{{$item->getData()}}</td>
           <td>
               <table width="100%">
               @foreach ($item->boards as $obj)
                   <tr><td>{{$obj->getData()}}</td></tr>
               @endforeach
               </table>
           </td>
       </tr>
   @endforeach
   </table>
   <div style="margin:10px;"></div>
   <table>
   <tr><th>Customer</th></tr>
   @foreach ($noItems as $item)<!--boardを持たない(投稿していない人)-->
       <tr>
           <td>{{$item->getData()}}</td>
       </tr>
   @endforeach
   </table>
@endsection
```

ルート情報に追加しします。
<p class="tmp list"><span>リスト8-3</span>web.php</p>
```
Route::get('customerHas', [\App\Http\Controllers\CustomerController::class,'indexHas']);
```

「/customerHas」にアクセスしてみて下さい。関連するBoardを持つ人が一覧表示され、その下にBoardを持たない人の一覧が表示されます。

![](upload/customer_hasテーブル表示.png "図　投稿している人としていない人をそれぞれ別々にリスト表示する。"){.photo-border}



## withによるEagerローディング

リレーションは大変便利ですが、しかしこれまで説明したやり方は、コード的には省エネコーディングできましたが、データベースの側からすると実はあまり省エネにはなっていません。  
例えば、「<span class="red">Customer::all</span>」で全Customerを取得する場合を考えてみましょう。リレーションによるレコードの取得は、実は内部的には「<span class="bold">まずCustomerを全部取り出し、そこから1つ1つ のCustomerに関連付けられているBoardを取り出す</span>」といったやり方をしています。

投稿されたBoardが10個あったとすると、Board全体を取得するのに1回、それから10個のBoardそれぞれで関連するCustomerを取得するのに10回、計11回もデータベースに問い合わせをしているのです。  
これは、一般に「N+1問題」と呼ばれています。N個のレコードがあった場合、1回レコードの取得を実行しただけでN+1回もデータベースアクセスを行うことになるのです。
もっとデータベースアクセスの回数を減らすことはできないのか。実は、できます。 それには「<span class="red bold">with</span>」というメソッドを利用するのです。

<p class="tmp"><span>書式3</span>with関数</p>
```
モデル ::with(リレーション名 )->get();
```
このような形で実行すればいいのです。このwithを使うと何が違うのか。それはレコードの取得の仕方が違うのです。例えば、withを使ってBoardを取得すると、

① まず、Boardだけを取得します。   
② 得られたBoardのcustomer_idの値をまとめ、それらのIDのCustomerを取得します。

このように、たった2回のデータベースアクセスですべてを取得できてしまうのです。データベースアクセスの省エネ化としては、実に大幅なアクセス減を実現できま
す。

### withで Board を取得する
では、実際に試してみましょう。BoardControllerクラスのindexを以下のように修正してみて下さい。

<p class="tmp list"><span>リスト9-1</span>BoardController.php</p>
```
public function index3(Request $request)
{
   $items = Board::with('customer')->get();//Boardのcustomer_idの値をまとめ、それらのIDのCustomerを取得
   return view('board.index3', ['items' => $items]);
}
```

これでOKなんですが、withを使っても関連するCustomerが正しく得られていることを確認する意味で、index.blade.php(「board」内のもの)の@section('content')ディレクティブを少し修正して、index3.blade.phpを追加してください。

<p class="tmp list"><span>リスト9-2</span>board/index3.blade.php</p>
```
@section('content')
   <table>
   <tr><th>Message</th><th>Name</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->message}}</td>
           <td>{{$item->customer->name}}</td>
       </tr>
   @endforeach
   </table>
@endsection
```

ルート情報にも追記します。
<p class="tmp list"><span>リスト9-3</span>web.php</p>
```
Route::get('board3', [\App\Http\Controllers\BoardController::class,'index3']);
```

これで、取得したBoardのmessageと、そのcustomer内にあるnameを一覧表示します。 実際に「/board3」にアクセスして表示を確認しましょう。問題なくリレーションのレコード まで取り出せていることがわかるでしょう。

![](upload/boad3に接続.png "図　問題なくCustomerのnameも取り出せているのがわかります。messageはboardsテーブル、nameはcustomersテーブル。")


このwithのようなやり方を、「<span class="green bold marker-yellow50">Eagerローディング</span>」と呼びます。  
これは、<span class="marker-yellow50 bold">レコード数 が多くなり、1回のallメソッドで膨大なアクセスを行うようになったとき、劇的な効果を得ることができます</span>。  
特にクラウドなどを利用してアプリケーションを公開する場合、データベースのアクセス数の増加はそのまま料金に跳ね返ってきます。少しでもアクセス回数を減らせれば、 コスト減にも役立つでしょう。

