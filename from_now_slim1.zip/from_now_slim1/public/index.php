<?php
use Slim\Factory\AppFactory;

// require_once("../php/Parsedown.php");
// require_once("../php/ParsedownExtra.php");

require_once($_SERVER["DOCUMENT_ROOT"]."/from_now_slim1/php/Parsedown.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/from_now_slim1/php/ParsedownExtra.php");

require_once($_SERVER["DOCUMENT_ROOT"]."/from_now_slim1/vendor/autoload.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/from_now_slim1/containerSetups.php");
$app = AppFactory::create();
require_once($_SERVER["DOCUMENT_ROOT"]."/from_now_slim1/routes.php");


$app->run();



