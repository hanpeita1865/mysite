---
title: JavaScript基礎編
taxonomy:
    category:
        - docs
child_type: docs
---
<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:12px 0 12px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
</style>

# JavaScript基礎編
<!--
JavaScript（ジャバスクリプト）とは、プログラミング言語のひとつである。<br>
Javaと名前が似ているが、全く異なるプログラミング言語である（略）<br>
ウェブブラウザ上で動作し動的なウェブサイト構築やリッチインターネットアプリケーションの開発に用いられる。（[ウィキペディア](https://ja.wikipedia.org/wiki/JavaScript)より）<br><br>
JavaScriptを用いて、プログラムの基礎を学習しましょう。
-->
## 目次

1. 概略
2. 変数の付け方
3. 算術演算子、小数点切り捨て、乱数
4. 日時の表示
5. 条件式 if文 switch文
6. 繰り返し　for文、while文
7. 配列
8. オブジェクト
9. ファンクションの書き方
10. デバッグ方法
11. ステップ実行でデバッグする