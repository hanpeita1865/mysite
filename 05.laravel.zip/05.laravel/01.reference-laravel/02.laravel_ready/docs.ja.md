---
title: 02.Laravelを準備する
media_order: 'composer5.png,composer7.png,composer8.png,composer2.png,composer4.png,composer9.png,laravel_install2.png,windows_system.png,windows_system1.png,windows_system0.png,windows_system2.png'
taxonomy:
    category:
        - docs
---

## Laravelのサイト
このLaravelは、Webサイトで公開されています。アドレスは以下のようになります。 本家は英語ですが、日本語サイトで主なドキュメントは見られますから、こちらを利用するのがよいでしょう。

■Laravelサイト
: <https://laravel.com/>

■日本語サイト
: <http://laravel.jp/>


ここで、Laravelに関する必要な情報は手に入るでしょう。ただし、Laravelのソフトウェアは、ここからダウンロードするわけではありません。インストールには別の方法をとります(詳細は後ほど)。

## Composerについて
では、Laravel利用のための準備を整えましょう。 Laravelは、一般的なアプリケーションのように、「プログラムをダウンロードしてインストールする」といったやり方はしません。ではどうするのかというと、「*Composer*」というプログラムを利用します。
Composerは、PHPのパッケージ管理プログラムです。これは、以下のアドレスで公開されています。

<https://getcomposer.org/>


## Windows のインストール
Windowsの場合、いくつかのインストール方法がありますが、もっともわかりやすい のは、インストーラをダウンロードしてインストールする方法でしょう。以下のアドレスにアクセスして下さい。

<https://getcomposer.org/download/>

![](composer2.png)


このページの上の辺りに、上図のように「**Composer-Setup.exe**」というリンクがあるので、これをクリックして下さい。これでインストーラがダウンロードされます。ダウンロードが完了したら、これをダブルクリックして起動して下さい。

### ① Composer Setup
起動すると、最初に「Composer Setup」画面が現れます。これは、そのまま「Next」ボタンで次に進みます。

![](composer4.png)

### ② Settings Check
使用するPHPを設定します。プルダウンリストに、インストール済みのPHPが一覧表示されるはずですので、ここから利用したいPHPプログラムを選択して次に進んで下さい。
![](composer5.png)


### ③ Proxy Settings 
プロキシーサーバーを使っている場合は、その設定を行います。使っていない場合は 不要ですので、そのまま次に進みます。

#### （プロキシを設定する場合）

「Proxy Settings」は「Use a proxy～」と「Ignore～」にチェックを入れ、「Enter proxy url」に下記形式のURLを入力する。

http://***Uxxxxxx:PASSWORD***@127.0.0.1:8080



![](composer7.png)

### ④ Ready to Install
インストールの準備ができました。内容を確認し、「Install」ボタンでインストールを 開始しましょう。
![](composer8.png)

### ⑤ Completing Composer Setup
インストールが完了すると、このような画面になります。後は「Finish」ボタンを押して終了するだけです。
![](composer9.png)

PCを再起動した後、下記のcomposerのバージョン確認コマンドでバージョンが表示されればOKです。
```
composer -V
```

## Laravelをインストールする
Composerが準備できたら、次はLaravelのインストールです。これも、コマンドを使って行います。Windowsならばコマンドプロンプトを起動して下さい。そして、以下のように実行をします。
```
composer global require "laravel/installer=1.1"
```
これで、Laravelがインストールされます。インストールには少し時間がかかりますが、 再び入力できる状態になったら作業終了です。
![](laravel_install2.png)

### 環境変数 PATHの設定
これでLaravelはインストールできましたが、環境変数PATHにインストール場所のパスを追記していないとLaravelのコマンドが使えません。PATHの設定を行っておきましょ
う。

■Windowsの場合
: 「システム」コントロールパネルを開き、「詳細設定」タブの「環境変数」ボタンをクリックします。  
: （スタートボタン横の検索窓にコントロールパネルと入力すればアイコンが表示されるのでそれをクリックすれば、コントロールパネルが開きます）

: ![](windows_system.png?classes=w-75)

: 現れたウインドウで、「システム環境変数」のリストから「Path」を探して選択し、「編集...」ボタンをクリックします。
: ![](windows_system0.png)

現れたウインドウで、以下のパスを追加します。なお「利用者名」の部分にはそれぞれの利用者の名前が当てはまります。
```
C:\Users\利用者名\AppData\Roaming\Composer\vendor\bin
```
Pathの編集ウインドウがリストになっている場合は、「新規」ボタンを押して、リストに項目が追加されたら上記のパスを記述します。  
テキストを直接編集するようになっていたら、Pathのテキストの一番前に上記のパスを記述し、最後にセミコロン()をつけます(セミコロンの後に、それまでのパスのテキストが続くようにする)。
![](windows_system2.png)

自分は、このようになりました。
![](windows_system1.png?classes=w-75)

