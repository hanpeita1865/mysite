const kokuchiPath = 'files//sample1.txt';

//ファイルのテキスト挿入
//fetch(kokuchiPath)
fetch(kokuchiPath,{cache: "no-store"}) //キャッシュクリア
.then((response) => {
	if (!response.ok) {
		throw new Error();
	}
	return response;
})
.then(response => response.text())
.then(data => { // 告知のtextがある
	if(data.trim()!==''){
		console.log(data);
	}
})
.catch(() => {
	//非表示にする
	console.log('ファイルがありません。')
})