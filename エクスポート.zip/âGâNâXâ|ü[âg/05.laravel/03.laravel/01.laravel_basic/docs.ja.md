---
title: Laravelの基本
media_order: 'laravel_folder.png,welcome.png,hello.png'
taxonomy:
    category:
        - docs
---

<style>
    table tr th:nth-child(1) {width: 10em;}
    /*table {font-size: .95rem;}
    .t-caption {font-size: 1.2rem!important;}*/
</style>

## Laravelの特徴

Laravelは、一般的にフルスタックフレームワークと言われています。  
フルスタックフレームワークというのは、データベースからのデータの取得処理やログイン認証処理などの自動化といった、およそPHPのWebシステム開発に必要な機能がほぼすべて含まれているフレームワークのことです。  
CakePHPやSymfonyもフルスタックフレームワークです。  
フルスタックフレームワークは機能が豊富な反面、学習コストが高いことが多いです。  
一方、Laravelは、学習コストが低く、コードが書きやすいことをうたったフレームワークです。


##### Laravelの主な機能 ##### {.t-caption} 
|項目|内容|
|:-------------------------------:|------------|
|ルーティング| 	URLと対応する処理を紐づけているのがルーティングです。このルーティング機能があるおかげで、.phpで終わるURLのようなphpファイルを連想するURLを避けることができ、処理をひとつのファイルやクラスにまとめることが可能となります。|
|Blade|	Laravelはテンプレートエンジンを内包しています。それが*Blade*です。|
|ミドルウェア|URLに対応したある処理を行う際、その前後に処理を付加することができます。これを*ミドルウェア*と言います。|
|エラーハンドラ|	例外やエラーが発生した際、そのパターンに応じて、例えば障害発生の画面を表示したりなどの処理を行うことができます。|
|DI	|システム開発を行っていくと、クラスのインスタンス同士がさまざまに依存しあうようになります。この依存度を極力下げて、実行時に外部から与えてもらえるようにした仕組みがDI（Dependency Injection: 依存性注入）です。Laravelは、このDIを実現する方法として、サービスコンテナというのを用いています。|
|バリデーション	|システム開発を行う際、入力値のチェック、つまりバリデーションのコーディングというのは、煩わしいものです。Laravelは、このバリデーションを設定のみで自動的に行ってくれる機能があります。|
|データベース連携|	Webシステムにおいて、データベースを使わないものは少ないでしょう。そのデータベースとPHPを連携させる場合、定型処理が含まれ、それなりに煩わしいものです。そういった定型処理を行う機能がLaravelにはあります。|
|認証の自動化	|Webシステムでは、そのシステムへのログイン処理が含まれることが多々あります。また、そういったシステムでは、ログインしていないと使ってはいけない処理も含まれています。そういったログイン処理、ログインしているかどうかのチェック処理、つまりは認証を自動化してくれる機能がLaravelにはあります。|


## プロジェクトの作成

1. ディレクトリを移動する。Xamppに設置する場合は、Xamppのドキュメントルートまで移動してください。
2. laravel newを実行する。laravelコマンドは、「laravel new プロジェクト名」という形で実行すると、その名前でプロジェクトを作成します。「laravelapp」という名前で作成してみます。以下のようにコマンドを実行してください。

```
laravel new laravelapp
```

Composerのコマンドを利用しても作成できます。以下のコマンドを実行してください。

```
composer create-project --prefer-dist laravel/laravel laravelapp
```

または、

```
composer create-project laravel/laravel laravelapp --prefer-dist
```


上記を書式にすると

<p class="tmp"><span>書式1</span></p>
```
composer create-project ベンダー/パッケージ 対象ディレクトリ
```

そうすると、数分かけてインストールされ、最後下記が表示されれば完了です。

```
[32mPackage manifest generated successfully.[39m
> @php artisan key:generate --ansi
[32mApplication key set successfully.[39m

```



指定したルートに、下記の「laravelapp」フォルダが作成されます。

![](laravel_folder.png?classes=caption "Lalavelプロジェクト内一覧")

Xamppのhtdocsに設置して、<http://localhost/laravelapp/public/>にアクセスすると、以下の画像のようなサイトが表示されます。

![](welcome.png?classes=caption "Lalavel初期画面")


## LaravelでHello World!の表示

routesディレクトリの中のweb.phpというファイルを開きます。

以下のコードがあらかじめ記述されています。(コメントは省略しています)

```
<?php
Route::get('/', function () {
	return view('welcome');
});
```

このコードの下に以下のコードを追加してください。

```
Route::get("/hello", function () {
	print("<h1>Hello World!</h1>");
	return null;
});
```

そして、<http://localhost/laravelapp/public/hello>にアクセスすると、下記が表示されます。

![](hello.png)
