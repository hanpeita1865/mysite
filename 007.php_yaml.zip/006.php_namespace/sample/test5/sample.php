<?php
require_once 'greeting.php';
use Asia\Japan\Kanto\Tokyo\hoge;

$a = new hoge;
echo $a->hello(); // 出力結果：こんにちは