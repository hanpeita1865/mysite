---
title: 配列の結合
---

様々な方法がありますが、添字配列と連想配列で動作が異なったりするので要注意です。

array_merge()

<iframe src="https://paiza.io/projects/e/zhS1X--oX6fxPDvv70cXVg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

### 連想配列
キーが同じ配列を結合しようとすると、後ろの配列に上書きされてしまいます。異なるキーであれば上書きはされません。


## 参考サイト

<https://qiita.com/yukibe/items/242e55a9a69a4a7fa3db>