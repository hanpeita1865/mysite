<?php
$pdo=new PDO('mysql:host=localhost;dbname=join_test;charset=utf8', 'root', '');

    
$query =
    'UPDATE fruits
        INNER JOIN
            price
            ON fruits.id=price.fruit_id
        SET
            fruits.name = ?,
            price.price = ?
        WHERE
            fruits.id = ?';

$sql=$pdo->prepare($query);

$dataUp[] = '柿';
$dataUp[] = '80';
$dataUp[] = '2';

$sql->execute($dataUp);

echo '更新しました';

?>

