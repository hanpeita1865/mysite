---
title: '16. DBクラスの利用'
media_order: 'dbclass_use1.png,dbclass_use2.png,dbclass_use3.png,dbclass_use4.png,dbclass_use5.png,customer_table.png,customer_table_id3.png,customer_form.png,customer_insert.png,customer_update1.png,customer_update2.png,customer_update3.png,customer_del1.png,customer_del2.png,customer_del3.png'
taxonomy:
    category:
        - docs
---

* [DBクラスとは?](#p1)
* [パラメータ結合の利用](#p2)
* [DB::insertによるレコード作成](#p3)
* [DB::updateによる更新](#p4)
* [DB::deleteによる削除](#p5)
* [SQLクエリがすべて?](#p6)

データベースを利用するもっとも簡単な方法は、「DB」クラスを使うことです。ここでは、このクラスの基本的なメソッドを覚え、データベースを利用してみましょう。

## DBクラスとは? ##{#p1}
では、実際にデータベースにアクセスしてみることにしましょう。Laravelに用意され ている、もっともシンプルなデータベースアクセス機能は「DB」クラスです。

このDBクラスには、データベースを利用するためのさまざまな機能が用意されています。中でも、もっともシンプルなのは、SQLのクエリを直接実行するメソッドでしょう。 これを覚えれば、とりあえず大抵のデータベースアクセスは可能になります。   では、このDBクラスを使って、作成したpeopleテーブルにアクセスをしてみましょう。

### コントローラの修正
まずは、コントローラに用意するアクションメソッドを変更します。今回も、これまで利用してきたHelloControllerを利用することにしましょう。クラスに用意されている indexアクションメソッドを以下のように変更して下さい。

<p class="tmp list"><span>リスト1</span>app/Http/Controllers/HelloController.php</p>
```
// use Illuminate\Support\Facades\DB;　を追加(データベースに接続できないので、応急的に記述 )

class HelloController extends Controller
{
   public function index(Request $request)
   {
       $items = DB::select('select * from customer');
       return view('hello.index', ['items' => $items]);
   }
}
```

### テンプレートの修正
内容については後で説明するとして、続いてテンプレートを修正してアクションを完成させてしまいましょう。  
「views」内の「hello」フォルダ内にある「index.blade.php」を開き、@section('content') ディレクティブを以下のように変更しましょう。

<p class="tmp list"><span>リスト2</span>resources/views/hello/index.blade.php</p>
```
@section('content')
   <table>
   <tr><th>id</th><th>name</th><th>address</th><th>login</th><th>password</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->id}}</td>
           <td>{{$item->name}}</td>
           <td>{{$item->address}}</td>
           <td>{{$item->login}}</td>
           <td>{{$item->password}}</td>
       </tr>
   @endforeach
   </table>
@endsection
```
これでテンプレートは完成ですが、スタイルシートにテーブル関係の設定を用意していなかったので、追記しておきましょう。  
「layouts」内のhelloapp.blade.phpを開き、 &lt;header&gt;の&lt;style&gt;タグ内に、以下の設定を追記して下さい。
    
<p class="tmp list"><span>リスト3</span>resources/views/layouts/helloapp.blade.php</p>
```
th {background-color:#999; color:fff; padding:5px 10px; }
td {border: solid 1px #aaa; color:#999; padding:5px 10px; }
```

これで修正は完了です。  
終わったら、/helloにアクセスして下さい。 customerテーブルのダミーレコードがテーブルに一覧表示されます。

![](customer_table.png?classes=caption "図 customerテーブル")

### DB:selectの利用

では、データベースにアクセスしている部分を見てみましょう。今回は、以下のような文を実行しているのがわかります。
```
$items = DB::select('select * from shop');
```
ここで使っている「DB::select」というのが、データベースからレコードのデータを取り出すための処理です。DB::selectは、DBクラスにある静的メソッドで、以下のように呼び出します。
<p class="tmp"><span>書式1</span>レコードのデータ取り出し文</p>
```
$変数 = DB::select( 実行する SQL文);
```
このDB::selectは、SQLクエリを実行し、結果となるレコードを取得するものです。  
メソッド名から想像がつくように、これはselect文を実行するものだ、と考えて下さい。 引数には、実行するSQLのクエリ文を文字列として用意しておきます。  
select文は、レコードを取得するためのものです。このselectメソッドも、実行すると レコードの情報が戻り値として返されます。

### テンプレートの処理

selectの戻り値は、それぞれのレコードの値をオブジェクトにまとめた配列になっています。ここから順にオブジェクトを取り出し、値を利用すればいいのです。  
テンプレートの@selectionを見てみると、以下のような形で処理されていることがわかります。
```
@foreach ($items as $item)
.....レコード内容の表示..... 
@endforeach
```

$items から順にオブジェクトを$item に取り出していきます。後は繰り返し部分で、 この$item から各フィールドの値を取り出していけばいいのです。用意されている処理 を見てみると、{{$item->name}} というようにして値を出力しているのがわかります。 これで、取り出したレコードのnameフィールドの値が出力されています。

SQLのselect文を使ってレコードを取得する処理は、このようにDB::selectでレコード を配列にして取得し、後はそれをテンプレートで繰り返し処理していくことで簡単に作 れます。取り出すレコードの内容や検索条件なども、要は「実行するSOL文をどうするか」 がすべてです。PHPのフレームワークらしくないやり方ですが、SQLさえしっかりわかっていれば、一番簡単な方法といえるでしょう。

## パラメータ結合の利用 ##{#p2}
ただし、複雑な検索になると、SQL文の作成が面倒臭くなってくるのは確かでしょう。 このような場合は、「パラメータ結合」と呼ばれる機能を利用すると簡単にSQLを作成できます。  
パラメータ結合とは、文字列とパラメータ配列を組み合わせてSQL文を作成する方法 です。先ほどのサンプルを修正して、パラメータ結合を使ってみましょう。   HelloControllerクラスのindexアクションメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト4</span></p>
```
public function index(Request $request)
{
   if (isset($request->id))
   {
	  $param = ['id' => $request->id];
	  $items = DB::select('select * from customer where id = :id',
		 $param);
   } else {
	  $items = DB::select('select * from customer');
   }
   return view('hello.index', ['items' => $items]);
}
```
修正したら、再び/helloにアクセスしてみましょう。「/hello?id=番号」というようにクエリ文字列を使ってidというパラメータの値を指定してアクセスをして下さい。すると、 そのID番号のレコードを検索して表示します。パラメータを付けず、今まで通り/hello とアクセスすると全レコードを表示します。

##### /hello?id=3 で指定した場合
![](customer_table_id3.png?classes=caption "図 パラメータでレコードを指定")

### パラメータ結合の働き

では、selectを実行している部分を見てみましょう。issetでクエリ文字列にidというパラメータが送られてきたかチェックし、これがあれば、以下のようにパラメータ用の配列を作成しておきます。
```
$param = ['id' => $request->id];
```
<p>ここでは、['id' => パラメータ]という配列を用意してあります。これをSQL文と一緒 にselectメソッドに渡して実行します。</p>
```
$items = DB::select('select * from customer where id = :id', $param);
```

SQL文を見ると、「where id = :id」と書かれているのがわかります。この「:id」というのは、 パラメータの値をはめ込むプレースホルダ(値を確保しておく場所のこと)です。SQL文 では、このように「名前」という形でプレースホルダを用意しておくことで、その後の引数にある配列から値を指定の場所にはめ込んでSQL文を完成させるのです。

ここでは、:idのところに、第2引数の$param配列から"id"の値を取り出して、はめ込んでいたのです。
このパラメータ結合は、いくつでもパラメータを用意して組み込むことができます。 プレースホルダを多用することで、多くの要素を変数や入力値から取得してSQL文を完 成させなければならないときも、比較的簡単に組み立てることができるでしょう。

## DB::insertによるレコード作成 ##{#p3}

DB::selectは、基本的にSQLのselect文によるレコード取得に用いるものです。それ以外の操作を行う場合は、別のメソッドを利用する必要があります。それらについても一 通り説明しましょう。

まずは、レコードの追加を行うinsert文を実行する場合です。これは、DBクラスの 「insert」メソッドを利用します。これも基本的な使い方はDB::selectと同様で、引数に SQLのクエリ文の文字列(必要に応じて、第2引数にパラメータの配列)を用意して呼び出します。

<p class="tmp"><span>書式2</span></p>
```
DB::insert(クエリ文 , パラメータ配列 );
```
このような形です。DB::insertは、レコードなどを取得するものではないので、戻り値を取得する必要はありません。では、これも利用例を挙げておきましょう。/hello/addというアクションを用意し、 フォームを送信してレコードを保存できるようにしてみます。

### add.blade.phpの作成

まずは、テンプレートです。今回は、新しいテンプレートファイルを作成しましょう。 「views」内の「hello」フォルダの中に、新たに「add.blade.php」というファイルを作成して下さい。そして以下のようにソースコードを記述しておきましょう。

<p class="tmp list"><span>リスト5</span>add.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Add')

@section('menubar')
   @parent
   新規作成ページ
@endsection

@section('content')
   <table>
   <form action="/hello/add" method="post">
      {{ csrf_field() }}
      <tr><th>name: </th><td><input type="text" name="name"></td></tr>
      <tr><th>age: </th><td><input type="text" name="age"></td></tr>
      <tr><th>address: </th><td><input type="text" name="address"></td></tr>
      <tr><th>login: </th><td><input type="text" name="login"></td></tr>
      <tr><th>password: </th><td><input type="text" name="password"></td></tr>
      <tr><th></th><td><input type="submit" value="send"></td></tr>
   </form>
   </table>
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```

ここでは、@selectionにフォームを用意してあります。これを/hello/addに送信してレコードの新規作成の処理をしています。

### HelloControllerの修正
では、HelloControllerクラスを修正しましょう。先ほどのindexとpostはそのまま残し、新たにaddとcreateメソッドを追加することにします。わかりやすいように、クラス全体のソースコードを掲載しておきます。

<p class="tmp list"><span>リスト6</span>app/Http/Controllers/HelloController.php</p>
```
public function post(Request $request)
{
   $items = DB::select('select * from customer');
   return view('hello.index', ['items' => $items]);
}

public function add(Request $request)
{
   return view('hello.add');
}

public function create(Request $request)
{
   $param = [
	   'name' => $request->name,
       'age' => $request->age,
	   'address' => $request->address,
	   'login' => $request->login,
	   'password' => $request->password,
   ];
   DB::insert('insert into customer (name, age, address, login, password) values (:name, :age, :address, :login, :password)', $param);
   return redirect('/hello');
}
```

処理をシンプルにするため、パリデーションなどの処理は省略してあります。 ここでは、createアクションメソッドで、送信されたフォームの内容を元にレコードの作成を行っています。まず、$paramに送信フォームの値を保管します。
```
$param = [
   'name' => $request->name,
   'age' => $request->age,
   'address' => $request->address,
   'login' => $request->login,
   'password' => $request->password,
];
```
後は、この配列をパラメータ引数にして、DB::insertを呼び出し実行するだけです。
```
DB::insert('insert into customer (name, age, address, login, password) values (:name, :age, :address, :login, :password)', $param);
```
後半に、「values (:name, :address, :login, :password)」という記述があります。ここで、パラメータ配列$paramから3つの値をはめ込むようにしてあります。これで送信されたフォームの値を元にinsert文を実行する、という処理ができました。 後は、$helloにリダイレクトして移動するだけです。
```
return redirect('/hello');
```
リダイレクトは、「redirect」というメソッドで実行します。これにより、/helloに移動させることができます。  
このように、レコードの新規作成は、「**フォームの値の取得**」「**DB::insertの実行**」「**トップへのリダイレクト**」といった作業をセットで実行して完了となります。

### ルート情報の追加

最後に、/hello/addのルート情報を追加しておきましょう。web.phpを開き、その末尾に以下の文を追記して下さい。
<p class="tmp list"><span>リスト7</span>routes/web.php</p>
```
Route::get('hello/add', 'HelloController@add');
Route::post('hello/add', 'HelloController@create');
```

これで完成です。/hello/addにアクセスし、フォームに入力して送信すると、その内容が新しいレコードとしてテーブルに保存されます。そのまま/helloにリダイレクトされるので、表示されるレコードの一覧をチェックし、新しくレコードが保存されていることを確認しましょう。

![](customer_form.png?classes=caption "図 customerテーブルに新規レコード追加用フォーム")

上図のようにデータを記入して、送信するとcustomerテーブルにデータが追加されています。
![](customer_insert.png)

## DB::updateによる更新 ##{#p4}

続いて、レコードの更新です。これは、updateというSQLクエリ文を使って行います。  
この更新処理を行うのに用意されているのが、DBクラスの「update」メソッドです。
<p class="tmp"><span>書式3</span></p>
```
DB::update(クエリ文 , パラメータ配列 );
```
このように利用します。基本的にDB::insertなどと使い方は同じです。用意するクエリ文が違うだけ、と考えて下さい。  
では、これも実際に作ってみましょう。今回は、/hello/editというアクションに処理を用意することにします。

### edit.blade.php の作成

まずテンプレートを用意しましょう。「views」内の「hello」フォルダ内に、新たに「edit.blade.php」というファイルを作成して下さい。ソースコードは以下のようにしておきます。

<p class="tmp list"><span>リスト8</span></p>
```
@extends('layouts.helloapp')

@section('title', 'Edit')

@section('menubar')
   @parent
   更新ページ
@endsection

@section('content')
   <table>
   <form action="/hello/edit" method="post">
      {{ csrf_field() }}
      <input type="hidden" name="id" value="{{$form->id}}">
      <tr><th>name: </th><td><input type="text" name="name" 
         value="{{$form->name}}"></td></tr>
      <tr><th>mail: </th><td><input type="text" name="mail" 
         value="{{$form->mail}}"></td></tr>
      <tr><th>age: </th><td><input type="text" name="age" 
         value="{{$form->age}}"></td></tr>
      <tr><th></th><td><input type="submit" 
         value="send"></td></tr>
   </form>
   </table>
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```

更新用のフォームを用意しておきました。フォームのコントロール類は、valueに $formの値を設定しています。これで、$formに更新するレコードの値を設定しておけば、 その値が表示されるようになります。  
また、非表示フィールドを使い、IDの値をフォームに保管しておくようにしてありま す。この部分になります。
```
<input type="hidden" name="id" value="{{$form->id}}">
```
更新処理では、送信された情報から、まず更新するレコードを取得しないといけません。そのために、レコードのIDを必ず保管しておきます。

### edit および update アクションの追加
続いて、HelloControllerにアクションメソッドを追加します。今回は、editとupdate という2つのアクションメソッドをクラスに追加することにしましょう。

<p class="tmp list"><span>リスト9</span></p>
```
public function edit(Request $request)
{
   $param = ['id' => $request->id];
   $item = DB::select('select * from customer where id = :id', $param);
   return view('hello.edit', ['form' => $item[0]]);
}

public function update(Request $request)
{
   $param = [
	   'id' => $request->id,
	   'name' => $request->name,
       'age' => $request->age,
	   'address' => $request->address,
	   'login' => $request->login,
	   'password' => $request->password,
   ];
   DB::update('update customer set name =:name, age =:age, address = :address, login = :login, password = :password where id = :id', $param);
   return redirect('/hello');
}
```

editでは、クエリ文字列を使い、idの値を渡すようにしてあります。これで受け取ったIDのレコードをDB::selectで検索し、それをformという名前でテンプレートに渡します。 なお、idがない場合のエラー処理などは今回省略してあります。 ここでは、以下のような形でクエリ文を用意しています。
```
update shop set name =:name, age =:age, address = :address, login = :login, password = :password 
	where id = :id
```
update文は、setの後に項目と値を記述していきます。whereで、設定するレコードの 条件を指定しています。これで、指定したIDのレコードの値が更新できます。

### /hello/editを試す

これで更新の処理そのものは用意できました。最後にweb.phpにルート情報を以下のように記述しておきましょう。

<p class="tmp list"><span>リスト10</span></p>
```
Route::get('hello/edit', 'HelloController@edit');
Route::post('hello/edit', 'HelloController@update');
```

一通りの修正ができたら、/hello/editにIDの値を付けてアクセスしてみて下さい。例えば、/hello/edit?id=10でアクセスすると下図のようにIDが10のレコードが表示されます。 そのまま内容を書き換えてフォームを送信すれば、そのレコードの値が更新されます。

![](customer_update1.png)

赤枠欄のテキストを変更して送信しました。
![](customer_update2.png)

データレコードの名前と住所が書き換わりました。
![](customer_update3.png)

## DB::deleteによる削除 ##{#p5}

残るは、レコードの削除です。これはDBクラスの「delete」というメソッドで行います。 使い方はこれまでのメソッドとまったく同じです。
<p class="tmp"><span>書式3</span></p>
```
DB::deleter クエリ文 , パラメータ配列 );
```
このdeleteメソッドは、SQLのdelete文を実行するものです。「delete from テーブル where ～」という形で検索するテーブルと検索条件を指定し、それに合致するレコード を削除します。 では、これもサンプルを作ってみましょう。

### del.blade.php の作成

まずはテンプレートからです。「views」内の「hello」フォルダ内に「del.blade.php」という名前でファイルを作成しましょう。そして以下のように記述しておきます。

<p class="tmp list"><span>リスト11</span></p>
```
@extends('layouts.helloapp')

@section('title', 'Delete')

@section('menubar')
   @parent
   削除ページ
@endsection

@section('content')
   <table>
   <form action="/hello/del" method="post">
      {{ csrf_field() }}
      <input type="hidden" name="id" value="{{$form->id}}">
      <tr><th>name: </th><td>{{$form->name}}</td></tr>
      <tr><th>address: </th><td>{{$form->address}}</td></tr>
      <tr><th>login: </th><td>{{$form->login}}</td></tr>
	  <tr><th>password: </th><td>{{$form->password}}</td></tr>
      <tr><th></th><td><input type="submit" value="send"></td></tr>
   </form>
   </table>
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```

ここではフォームを用意していますが、送信するのは非表示フィールドのID値のみで す。削除するレコードのIDさえわかれば、削除処理は行えますから。その代わりに、削 除するレコードの内容をテーブルにまとめて表示しています。これで内容を確認し、削除していいと思ったらボタンを押して送信する、というわけです。

### del および remove アクションの追加
続いて、コントローラへのアクションメソッドの追加です。今回は、delとremoveと いうメソッドとして追加することにしましょう。

<p class="tmp list"><span>リスト12</span></p>
```
//delete処理
public function del(Request $request)
{
   $param = ['id' => $request->id];
   $item = DB::select('select * from customer where id = :id', $param);
   return view('hello.del', ['form' => $item[0]]);
}

public function remove(Request $request)
{
   $param = ['id' => $request->id];
   DB::delete('delete from customer where id = :id', $param);
   return redirect('/hello');
}
```
delでの処理は、先ほどの更新処理で作ったeditとほぼ同じです。クエリ文字列で渡されたIDパラメータの値を使ってレコードを取得し、それをformに設定して表示しています。  
削除の処理は、removeで行っています。ここで実行しているSQLクエリ文は以下のようになります。
```
delete from people where id = :id
```
whereを使い、指定したIDのレコードをdelete fromで削除しています。削除は、送信されたID番号さえわかれば行えるので、更新などよりかなり簡単です。  
最後に、web.phpにルーティングの情報を追記して完成です。

<p class="tmp list"><span>リスト13</span></p>
```
Route::get('hello/del', 'HelloController@del');
Route::post('hello/del', 'HelloController@remove');
```

/hello/delアクションに、idパラメータを付けてアクセスしてみて下さい(/hello/del?id=10といった具合)。そのレコードの内容が表示されます。そのまま送信ボタンを押せば、そのレコードが削除されます。

![](customer_del1.png?classes=caption "図 ID番号10のレコード")

![](customer_del2.png?classes=caption "図 削除前のレコード")
送信ボタンを押すと、ID番号10のレコードが削除されています。
![](customer_del3.png?classes=caption "図 削除後のレコード")

## SQLクエリがすべて? ##{#p6}

これで、データベース操作の基本であるCRUD(Create、Read、Update、Delete)の実 装ができました。ここまで説明したことがわかれば、データベースを使ったアプリは作れるようになります。  
ただし、説明を見ればわかるように、これらは基本的に全て「SQLクエリ文を書いて実行する」というやり方です。これで確かに動きはしますが、正直いってスマートなやり方とは思えませんね。もっとPHPらしいやり方はできないのか?と思うでしょう。 もちろん、そうした方法も用意されています。それは、「***クエリビルダ***」を利用するの
です。











