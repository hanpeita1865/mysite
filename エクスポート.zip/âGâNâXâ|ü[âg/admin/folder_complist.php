<?php

require 'database_pass.php';
require 'basepath.php';

$pdo=new PDO('mysql:host=localhost:3306;dbname='.$database.';charset=utf8',$user, $password);

$stmt = $pdo->prepare('select page from locklist');
$stmt->execute();
$lockData = $stmt->fetchAll(PDO::FETCH_COLUMN);
$error_mg = [];//エラーメッセージ(テスト)

$basePath = $basePath.'/public/';
$menuCode = '';
$boxNum = 1;


globAll('../pages');

function globAll($folder) {

    global $lockData;
    global $error_mg;
    global $basePath;
    global $menuCode;
    global $boxNum;

    if (!is_file($folder)) {

        $res = glob($folder . '/*'); 

        foreach ($res as $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {

                $path = str_replace('../pages/','', $f).'/';//リストのパス

                $pathRe = preg_replace('/^\d{3}./','',$path);
                $pathRe = preg_replace('/\/\d{3}./','/',$pathRe);

                if(file_exists($f.'/markdown.md')){

                    $md = file_get_contents($f.'/markdown.md'); //マークダウンの内容を変数に格納
                    if(preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle)){
                        $title = $ArrayTitle[1];
                    }
    
                    $lastDir = preg_replace('/^\d{3}./', '',$lastDir);
    
                    if(in_array($lastDir, $lockData)) {
                        //ロックあり
                        $menuCode = $menuCode.'<li id="item'.$boxNum.'" class="box-item"><a href="'.$basePath.'pages/'.$pathRe.'" class="lock">'.$title.'</a>';
                        // echo '<li id="item" class="box-item"><a href="'.$basePath.'pages/'.$pathRe.'" class="lock">'.$title.'</a>';
                    }else{
                        //ロックなし
                        $menuCode = $menuCode.'<li id="item'.$boxNum.'" class="box-item"><a href="'.$basePath.'pages/'.$pathRe.'">'.$title.'</a>';
                        // echo '<li id="item" class="box-item"><a href="'.$basePath.'pages/'.$pathRe.'">'.$title.'</a>';
                    }
                    
                    $boxNum = $boxNum +1;
                
                }else{
                    array_push($error_mg, $f.'に「markdown.md」がありません。');//テスト JSに返す方法がまだ
                }

                //ディレクトリ($f)内に「〇〇〇.フォルダ」があるか判定
                $res1 = glob($f . '/*');
                $pBool = false;
                foreach ($res1 as $f1) {
                    $dirArray1 = explode('/', $f1);
                    $lastDir1 = end($dirArray1);
                    if (preg_match('/^\d{3}./', $lastDir1)) {
                        $pBool = true;
                    }
                }

                if($pBool){
                    $menuCode = $menuCode."\r\n".'<ul class="sub-menu">'."\r\n";
                    // echo "\r\n".'<ul class="sub-menu">'."\r\n";
                }

                globAll($f);

                if($pBool){
                    $menuCode = $menuCode.'</ul>'."\r\n";
                    // echo '</ul>'."\r\n";
                }

                $menuCode = $menuCode.'</li>'."\r\n";
                // echo '</li>'."\r\n";
            }
        }
    }
}

file_put_contents("../templates/layouts/menu_list.twig", $menuCode);
?>