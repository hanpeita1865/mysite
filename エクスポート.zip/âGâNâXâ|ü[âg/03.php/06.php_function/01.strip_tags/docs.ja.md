---
title: (移動済)タグを除く（strip_tags）
taxonomy:
    category:
        - docs
---

指定した文字列からHTMLタグを取り除く関数 strip_tags()の紹介です。

## strip_tags関数の使い方

<p class="tmp"><span>書式</span>strip_tags関数</p>
```
strip_tags( 文字列 )
```

<iframe src="https://paiza.io/projects/e/LahSSizkE1AN74VhiMF9LQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## 取り除かないタグを指定する場合

<p class="tmp"><span>書式</span>strip_tags関数～ 取り除かないタグを指定</p>
```
strip_tags( 文字列, タグ )
```
pタグだけ残す処理です。
<iframe src="https://paiza.io/projects/e/iYtmJ06eo6s4bRiEe7UQ7A?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## 参考サイト

* [文字列からHTMLタグを取り除く - strip_tags](https://webkaru.net/php/function-strip-tags/)
* [strip_tags - 文字列から HTML および PHP タグを取り除く](https://phpspot.net/php/man/php/function.strip-tags.html)