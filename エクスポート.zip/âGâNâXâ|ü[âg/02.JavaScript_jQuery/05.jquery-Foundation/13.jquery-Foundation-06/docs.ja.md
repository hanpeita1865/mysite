---
title: '13. カルーセル'
media_order: navButton.png
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-0 {margin-bottom:0rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .black {color: #000;}
    .red {color: red;}
    .blue {color:blue;}
    .smp-box {
        margin: 2rem 0 3rem;
    }
    .smp {
        display: inline-block;
        margin-top: 2rem;
        margin-bottom: 0;
        background: #bc495b;
        color: #fff;
        font-size: .75rem;
        font-weight: bold;
        letter-spacing: .3rem;
        padding: .2rem .5rem;
    }
    .tmp {
        background: #026ca2;
        color: #fff;
        font-size: .87rem;
        letter-spacing: .3rem;
        padding: .2rem 1rem;
        white-space: nowrap;
    }
    .dcn {
     	font-weight: bold;   
    }
    .exp {
     	border-bottom: 3px solid #14ff00;
        font-weight: bold;
        font-size: 2rem;
    }
    .num {
      font-size: 1.35rem;
      color: red;
      display: inline-block;
      margin-right: 0.3rem;
    }
    .comment {
      font-style: italic;
      /*color: #555;*/
      color: green;
      font-size: 1rem;
    }
</style>



<h3>カルーセルサンプル</h3>
<a href="jquery-foundation-06/sample_fade/index.html" target="_blank">カルーセルサンプル</a>
<p>シンプルなカルーセルになります。<br>
	変数intervalの値で画像の切り替わる間隔を設定しています。</p>
<iframe width="100%" height="650" src="jquery-foundation-06/sample_fade/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<iframe width="100%" height="650" src="//jsfiddle.net/gjzm839d/embedded/html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<p>まず最初は一枚目の画像以外は、<strong>hideメソッド</strong>で非表示にしておきます。</p>
    
<pre>
<span class="comment">// 1番目の写真以外は非表示</span>
$("#carousel-inner li:not(:first-child)").hide();
</pre>
        
####ナビボタンの設置
![absolute](navButton.png)
<p>変数count（画像の枚数）の数値分だけfor文で処理を繰り返し、ボタンを1つずつ設置していきます。<br>
ここで使用されている<strong>append()</strong>は、要素内の一番後ろに指定したHTMLやエレメントを挿入します。<br>
ボタンを設置したら、初期状態として先頭のボタンにtargetというクラスをつけて色をかえてやります。
    
<pre>
var count = $("#carousel-inner li").length;<span class="comment">//画像の枚数</span>

<span class="comment">//ボタン設置</span>
for ( var i = 1 ; i <= count ; i++ ){
    $(&quot;#btn-navbox&quot;).append('&lt;button value=&quot;'+i+'&quot;&gt;&lt;span class=&quot;sr-only&quot;>'+i+'枚目&lt;/span&gt;&lt;/button&gt;');   
}

$(&quot;#btn-navbox button:first-child&quot;).addClass('target');<span class="comment">//先頭のボタンの色を変える</span>
</pre>
    
<p>そうして設置されたボタンのHTMLが下記の赤のコードになります。</p>
    
<pre>
&lt;div id="btn-navbox"&gt;
     <span class="red bold">&lt;button value="1" class="target"&gt;&lt;span class="sr-only"&gt;1枚目&lt;/span>&lt;/button>
     &lt;button value="2"&gt;&lt;span class="sr-only"&gt;2枚目&lt;/span&gt;&lt;/button&gt;
     &lt;button value="3"&gt;&lt;span class="sr-only"&gt;3枚目&lt;/span&gt;&lt;/button&gt;
     &lt;button value="4"&gt;&lt;span class="sr-only"&gt;4枚目&lt;/span&gt;&lt;/button&gt;</span>
&lt;/div&gt;
</pre>

<h4>画像切り替えのタイマーを作成 </h4>
<p>関数名は<strong>slideTimer()</strong>とし、その関数が実行されるたびに現在表示されている画像が非表示になり、同時に次の画像が表示になります。<br>
それぞれ<strong>fadeOutメソッド</strong>（非表示にする）、<strong>fadeInメソッド</strong>(表示させる)を使用します。<br>
例えば、現在の画像を非表示にして、同時に次の画像を表示させるには、下記のように書きます</p>
  
<pre class="mb-05">
$("#carousel-inner li:nth-child(" + current + ")").fadeOut(); <span class="comment">//現在の画像を非表示</span>
$("#carousel-inner li:nth-child(" + next + ")").fadeIn(); <span class="comment">//次の画像を表示</span>
</pre>
※ 初期値は、current（現在表示中の画像の番号）=1 , next（次に表示される画像の番号）=2 です。<br><br>

<p><strong>slideTimer()</strong>が実行されるごとにnextの値に1が足され、その値が画像の枚数（変数count）を超えた場合、nextの値を1に戻します。<br>
画像が切り替わるたびに、buttonに「.target」クラスを再設定することでbuttonのカレントも移動します。</p> 

<pre>
<span class="comment">// slideTimer関数</span>
function slideTimer(){
	$('#carousel').addClass('btnOff');<span class="comment">// ナビボタンを無効にする</span>
    
	<span class="comment">// 画像の表示・非表示切り替え</span>
    $("#carousel-inner li:nth-child(+" + current + ")").removeClass('active');
    $("#carousel-inner li:nth-child(+" + next + ")").addClass('active');
    $("#carousel-inner li:nth-child(+" + current + ")").fadeOut('slow');
    $("#carousel-inner li:nth-child(+" + next + ")").fadeIn('slow',function(){
        $('#carousel').removeClass('btnOff');<span class="comment">// ナビボタンを有効に戻す</span>
    });

    current = next;  <span class="comment">// nextの変数値をcurrentの変数に格納</span>
    next = ++next;  <span class="comment">// nextの値に1を足す</span>

    if(next > count){  <span class="comment">// next値が画像の枚数より大きくなったら、1枚目に戻るように判定</span>
        next = 1;
    }
    
	<span class="comment">// buttonのカレントも移動</span>
    $("#btn-navbox button").removeClass("target");
    $("#btn-navbox button:nth-child("+ current +")").addClass("target");
}
</pre>





 <p>このslideTimer()を一定時間ごとに実行するには、<strong>setInterval()</strong>を使用します。</p>
 
 <p class="mb-05"><span class="tmp">書式1</span>　<span class="bold">時間ごとの繰り返し処理を設定する</span></p>
 <pre>
 	<span class="bold black">setInterval</span>(function(){
        ～ここに処理を記載～
    },間隔時間（ミリ秒）);
    
    または
    
    <span class="bold black">setInterval</span>( 関数名 , 間隔時間（ミリ秒））
</pre>

<p class="mb-05">これを使って変数<span class="blue">interval</span>の時間ごとに<span class="red">slideTimer()</span>の処理を繰り返します</span><br>
変数<strong>timer</strong>には、<span class="bold black">setInterval()</span>の戻り値を格納しておきます。<br>
これは、このあと使う<span class="bold black">clearInterval()</span>の引数に<span class="bold black">setInterval()</span>の戻り値を渡す必要があるからです。<br>
もし、<span class="bold black">setInterval()</span>の戻り値をどこにも格納しておかなかったら、処理を停止できません。


<pre>
<strong>timer</strong> = <span class="bold black">setInterval</span>(<span class="red">slideTimer</span>, <span class="blue">interval</span>);
</pre>

<h4>ナビボタンを押した時や画像をマウスオーバー時の処理</h4>

※タイマーを停止させるには、<strong>clearIterval()</strong>を使います。
 <p class="mb-05"><span class="tmp">書式2</span>　<span class="bold">setInterval()で設定した処理を解除する</span></p>
 <pre>
    <span class="bold black">clearIterval</span>( 戻り値を格納した変数）
</pre>

ナビボタンを押した時の動作は、下記のコードで行われます。
    
<pre>
<span class="comment">// ナビボタンをクリック</span>
$("#btn-navbox button").click(function(){
    if (!$(this).hasClass('target')){
        next = $(this).val();<span class="comment"> // クリックしたボタン内のvalue値（画像の順番）を変数nextに格納</span>
        clearInterval(timer); <span class="comment"> //タイマーを停止</span>
        timer = setInterval(slideTimer, interval); <span class="comment"> //タイマーを再設定し再開</span>
        slideTimer();
    }
});
</pre>

画像をマウスオーバーした時、停止させるコードは下記になります。
<pre>
<span class="comment">//画像にマウスオーバー時は、表示切り替えを停止させる</span>
$('#carousel-inner').hover(function() {
    clearInterval(timer);
}, function() {
    timer = setInterval(slideTimer, interval);
});
</pre>
     



<h3>スライダー</h3>
<iframe width="100%" height="650" src="jquery-foundation-06/sample/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<iframe width="100%" height="650" src="//jsfiddle.net/hkdb7vsq/1/embedded/html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

Prevボタン（前のページに移動）,Nextボタン（次のページに移動）を押したときの動作処理のために変数dirを設定し、「-1」は正方向、それ以外の値は逆方向になるようにしてます。<br>
新しく変数prevを追加しています。<br>
「.btnOff」クラスが#slide要素に設定されている間は、ナビボタンもPrev、Nextボタンも効かないように設定しており、これはスライドしている間に新たにslideTimer()の処理を実行させないためで、<strong>setTimeout</strong>(countup, 600) も同じ用途で設置しています<br>

 <p class="mb-05"><span class="tmp">書式2</span>　<span class="bold">指定した時間後に1回だけ処理をする。</span></p>
 <pre>
 	<span class="bold black">setTimeout</span>(function(){
        ～ここに処理を記載～
    },時間（ミリ秒）);
    
    または
    
    <span class="bold black">setTimeout</span>( 関数名 , 時間（ミリ秒））
</pre>



<pre>
<span class="comment">// slideTimer関数</span>
function slideTimer(){

    $('#slide').addClass('<span class="bold red">btnOff</span>');

    if(dir === -1){ <span class="comment">//正方向</span>
        $("#slide-inner li:nth-child(" + current + "),#slide-inner li:nth-child(" + next + ")" ).addClass('left');
        setTimeout(<span class="bold blue">countup</span>, 600);
        $("#btn-navbox button").removeClass("target");
        $("#btn-navbox button:nth-child("+ next +")").addClass("target");
    }else{ <span class="comment">//逆方向</span>
        $("#slide-inner li:nth-child(" + current + "),#slide-inner li:nth-child(" + prev + ")" ).addClass('right');
        setTimeout(<span class="bold blue">countup</span>, 600);
        $("#btn-navbox button").removeClass("target");
        $("#btn-navbox button:nth-child("+ prev +")").addClass("target");
    }
}
</pre>

<pre>
var <span class="bold blue">countup</span> = function(){
    if(dir === -1){<span class="comment">//正方向</span>
        $("#slide-inner li:nth-child(" + current + ")").removeClass('active left');
        $("#slide-inner li:nth-child(" + next + ")").addClass('active');
        $("#slide-inner li:nth-child(" + next + ")").removeClass('left');

        prev = current;
        current = next;
        next = ++next;

        if(next > count){
            next = 1;
        }			
    }else{ <span class="comment">//逆方向</span>
        $("#slide-inner li:nth-child(" + current + ")").removeClass('active right');
        $("#slide-inner li:nth-child(" + prev + ")").addClass('active');
        $("#slide-inner li:nth-child(" + prev + ")").removeClass('right');

        next = current;
        current = prev;
        prev = --prev;

        if(prev < 1){
            prev = count;
        }
    }

    $('#slide').removeClass('<span class="bold red">btnOff</span>');
    dir= -1; <span class="comment">//正方向に戻す</span>
} 
</pre>

<h5>今回画像をスライド移動させるのに、cssの「<span class="bold">keyframes</span>」を使用しています。<br>
「.left」、「.right」、「.active」の3つのクラスによって、スライドの方向や
開始位置を変えています。
</h5>

<p class="bold mb-0">（CSS）</p>
<pre>
#slide-inner li {
    position: absolute;
    display: none;
    top: 0;
    align-items: center;
    width: 100%;
    overflow: hidden;
    transform: translateX(100%);
}

#slide-inner li.active {
    position: relative;
    display: block;
    transform: translateX(0);
    z-index: 10;
}

#slide-inner li.right { <span class="comment">//右へ「-100%」から「0%」に移動</span>
    display: block;
    <span class="bold">animation: <span class="red">moveR1</span> .6s ease 1</span>; 
    z-index: 11;
}

#slide-inner li.active.right { <span class="comment">//右へ「0%」から「100%」に移動</span>
    display: block;
    <span class="bold">animation: <span class="red">moveR2</span> .6s ease 1</span>; 
    z-index: 9;
}

#slide-inner li.left {<span class="comment">//左へ「100%」から「0%」に移動</span>
    display: block;
    <span class="bold">animation: <span class="blue">moveL1</span> .6s ease 1</span>; 
    z-index: 11;
}

#slide-inner li.active.left {<span class="comment">//左へ「0%」から「-100%」に移動</span>
    display: block;
    <span class="bold">animation: <span class="blue">moveL2</span> .6s ease 1</span>;
    z-index: 9;
}

@keyframes <span class="red bold">moveR1</span> {
    from {transform: translateX(-100%);}
    to {transform: translateX(0%);}
}

@keyframes <span class="red bold">moveR2</span> {
    from {transform: translateX(0%);}
    to {transform: translateX(100%);}
}

@keyframes <span class="blue bold">moveL1</span> {
    from {transform: translateX(100%);}
    to {transform: translateX(0%);}
}

@keyframes <span class="blue bold">moveL2</span> {
    from {transform: translateX(0%);}
    to {transform: translateX(-100%);}
}
</pre>