*[page-title]:10-19. ピクセル値をずらした効果を与えてみよう

## カスタムフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-19-1.jpg)](upload/10-19-1.jpg){.image}
</div>


## スクロールフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-19-2.jpg)](upload/10-19-2.jpg){.image}
</div>