---
title: '07. Bladeテンプレートを使う'
media_order: 'blade_01.png,blade_02.png,blade_03.png'
taxonomy:
    category:
        - docs
---

Laravelには、「Blade」という独自のテンプレートエンジンが用意されています。このテンプレートの基本的な書き方を覚えましょう。そしてフォーム送信などの基本的な処理が行えるようになりましょう。

## Bladeを使う
PHPスクリプトファイルをそのままテンプレートとして使うのは、わかりやすくていいのですが、記述が煩雑になってしまうきらいがあります。ちょっと値を表示するだけでも、**<?php echo 00; ?>**などと書かなければならないのですから。 また、PHPタグが&lt;&gt;を使っており、一般的なHTMLのタグと同じ形式になっているため、HTMLの作成ツールなどを使うとタグの構造が崩れたりしてしまいますし、ページをいくつかに分割してまとめてレイアウトするような機能もありません。全部、HTMLとPHPで手作業でレイアウトしていくしかないのです。  
Laravelに独自に用意されている「***Blade(ブレード)***」というテンプレートエンジンは、非常に効率的にレイアウトを作成していくための機能を持っています。テンプレートを 継承して新たなテンプレートを定義したり、レイアウトの一部をセクションとしてはめ込むなどしてレイアウトを作っていくことができます。Laravelを利用しているなら、ぜひBladeを使ってテンプレート作成をできるようになりたいところです。

### テンプレートを作る
では、実際にBladeテンプレートを作って利用してみることにしましょう。Bladeテン プレートも、PHPテンプレートと同様、「**resources**」内の「**veiws**」フォルダの中に配置し ます。  
「views」内に作成した「hello」フォルダの中に、「index.blade.php」という名前でファイルを作成してください。これがBladeのテンプレートファイルです。Bladeは、このように「**○○.blade.php**」という名前でファイルを用意します。 作成したindex.blade.phpには、以下のようにソースコードを記述しておきましょう。

<p class="tmp list"><span>リスト1</span>index.blade.php</p> 
```
<html>
<head>
   <title>Hello/Index</title>
   <style>
   body {font-size:16pt; color:#999; }
   h1 { font-size:50pt; text-align:right; color:#f6f6f6;
       margin:-20px 0px -30px 0px; letter-spacing:-4pt; }
   </style>
</head>
<body>
   <h1>Blade/Index</h1>
   <p>{{$msg}}</p>
</body>
</html>
```
基本的な部分は、普通のHTMLそのままです。ただし、よく見ると、&lt;p&gt;タグの部分に、 **{{$msg}}**が用意されています。これは、変数**$msg**を埋め込んだものです。Bladeでは、**{{$ 変数}}**というようにして変数をテンプレート内に埋め込むことができます。


### アクションの修正
では、続いてコントローラのアクションメソッドを修正しましょう。 indexアクショ ンメソッドを以下のように書き換えて下さい。
<p class="tmp list"><span>リスト2</span>HelloController.php</p>
```
public function index()
{
   $data = [
       'msg'=>'これはBladeを利用したサンプルです。',
   ];
   return view('hello.index', $data);
}
```

これで完成です。/helloにアクセスすると、index.blade.phpテンプレートを使って画面が表示されます。  

![](blade_01.png)

<div class="gray-box" markdown="1">
#### メモ　 index.phpとindex.blade.php、どっちを使うの?
index.blade.phpを使ってページの表示ができましたが、ちょっと考えてみて下さい。 ここでは、「Bladeテンプレートを使う」といった設定は一切行っていません。そして、こ れまで使っていたindex.phpもそのままになっています。それなのに、view('hello.index' ~ ) と実行すると、index.blade.phpを使って画面の表示がされました。
Laravelでは、Bladeテンプレートがあると、それが優先して読み込まれます。テンプレート名を'index'と指定してあるなら、index.phpではなく、**index.blade.php**が使われるのです。このファイルがない場合には、**index.php**が使われます。このため、同名のファイル「○○.php]「○○.blade.php」があれば、「○○.blade.php」が使われます。
</div>

## フォームを利用する
基本的なWebページの表示ができるようになったところで、次は「フォーム送信」を行ってみましょう。フォームは、ユーザーからの入力を受けて処理をする際の基本となるものです。  
これも実際にサンプルを作りながら説明しましょう。まずは、テンプレート側からです。index.blade.phpの&lt;body&gt;タグ部分を以下のように修正して下さい。

<p class="tmp list"><span>リスト3</span>index.blade.php</p>
```
<body>
   <h1>Blade/Index</h1>
   <p>{{$msg}}</p>
   <form method="POST" action="/hello">
       {{ csrf_field() }}
       <input type="text" name="msg">
       <input type="submit">
   </form>
</body>
```
ここでは、**&lt;form method="POST" action="/hello"&gt;**という形でフォームを用意して あります。/helloにPOST送信されたときの処理を用意すれば、そこで送られたフォームを処理できるようになります。 ここでの最大のポイントは、&lt;form&gt;タグの次にある文です。
```
{{ csrf_field() }}
```
*csrf_field* を呼び出しています。これは「**ヘルパ関数**」と呼ばれ、テンプレートで必要になるコードの生成を手助けしてくれるものです。
    
## CSRF対策について
<p>csrf_fieldは、CSRF対策のために用意されたヘルパ関数です。 CSRFは、「Cross Site Request Forgery」と呼ばれる、Webサイト攻撃の一つです。スクリプトなどを使い、外部からフォームを送信するもので、フォームに大量のコンテンツを送りつけたりするのに用いられています。<br>
    csrf_fieldは、「<strong>トークン</strong>」と呼ばれるランダムな文字列を非表示フィールドとして追加します。そして、このトークンの値が正しいフォームだけを受け付けるようにします。 こうすることで、用意されたフォームからの送信かどうか見分けることができるようになり、フォーム以外からの送信を受け付けないようにします。<br> 
Laravelでは、CSRF対策がなされていないフォームの送信は、例外が発生して受け付けられないようになっています。したがって、フォームを利用する際には、必ずcsrf_ fieldをフォーム内に用意しておく必要があります。</p>

![](blade_02.png?classes=caption "図 CSRFは、外部からプログラムなどによってフォームを送信する攻撃。用意されたフォームかど うか見分ける工夫が必要になる。")


##アクションの用意
では、コントローラにアクションを用意しましょう。今回は、/helloにアクセスしたときの表示と、フォームを送信したときの処理の2つのアクションが必要となります。  
HelloController.phpを開き、HelloControllerクラスを以下のように修正して下さい (namespace、useは省略)。
    
<p class="tmp list"><span>リスト4</span>HelloController.php</p>
```
class HelloController extends Controller
{
  
   public function index()
   {
       $data = [
           'msg'=>'お名前を入力下さい。',
       ];
       return view('hello.index', $data);
   }

   public function post(Request $request)
   {
       $msg = $request->msg;
       $data = [
           'msg'=>'こんにちは、' . $msg . 'さん！',
       ];
       return view('hello.index', $data);
   }

}
```
![](blade_03.png?classes=caption "図　リスト5のPOSTのルート設定をすると、フォームに名前を入力して送信したら、「こんにちは、○○さん!」と表示される。")
    
indexメソッドは、/helloにアクセスした際の処理です。これは、これまでと同じよう な内容ですから説明は不要でしょう。  
postメソッドが、/helloにPOST送信されたときの処理です。ここではRequestインス タンスを引数に用意してあります。そして、以下のようにフォームの内容を取り出して
います。
```
$msg = $request->msg;
```
リスト3で**name="msg"**を指定してあったフィールドの値は、このように**$request->msg**で取り出すことができます。フォームで送信された値は、すべてnameのプロパティとして取り出せるようになっているのです。
    
## POSTのルート設定
残るは、ルート情報の追記です。web.phpに以下の文を追記して下さい。なお、既にある/helloにアクセスするためのRoute::get文はそのままにしておきましょう。削除した りはしないでください。
    <p class="tmp list"><span>リスト5</span></p>
```
Route::post('hello', 'HelloController@post');
```

web.phpの内容は今このようになっています。
```
Route::get('hello', 'HelloController@index');
Route::post('hello', 'HelloController@post');
```
注意
:Helloのサイトに接続するのに「http://localhost/laravelapp/public/hello」ではPOSTされません。  
「http://localhost:8030/hello」のようにURLを設定しておく必要があります。


POST送信は、**Route::post**というメソッドで設定します。メソッド名が違うだけで、 使い方はRoute::getと同じです。割り当てるアドレスと、呼び出すアクションをそれぞれ 引数に指定します。  
ここでは、/helloにHelloControllerクラスのpostメソッドを割り当ててあります。同じアドレスでも、GETとPOSTというようにアクセスするメソッドの種類が違えば両方共に 使うことができます。

<div class="gray-box" markdown="1">
#### ChromeにおけるToken MismatchExceptionの問題
{ csrf_field() }} をつけておけばCSRF対策に引っかからずにフォーム送信ができる........ はずなのですが、実際にやってみると、きちんと{{ csrf_field() }} を書いてあるのに、送信 するとTokenMismatchException(CSRF対策のトークンという値が合わないエラー)が出 ることがあります。  
これは、**Chromeブラウザ**で特に顕著で、何度送信してもTokenMismatchExceptionに なってしまい、ほとんど正常に送れなくなってしまう現象が確認できています。 もし、この問題が発生したなら、開発中は、とりあえず他のWebブラウザを利用してください。例えばMicrosoft Edgeではこうした問題は確認されていません。  
あるいは、開発中はCSRF対策の機能をOFFにしておく、ということもできます。 CSRF対策を行っているのはVerifyCsrfTokenというミドルウェアで、これを使われないように設定しておけばよいのです。4-4節の「CSRF対策とVerifyCsrfToken」にその方法をま とめてありますので、そちらを参考にして下さい。
</div>



