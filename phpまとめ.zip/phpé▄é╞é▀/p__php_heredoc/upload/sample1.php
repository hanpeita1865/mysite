<?php
$str_name = "太郎";
echo <<<ABC
ヒアドキュメント<br>
です。<br>
こんにちは。$str_name だよ。
ABC;
?>