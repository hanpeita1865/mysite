let pos = $("#c4").position();

$(".scroll").scrollTop(pos.top + 1);

$(".jump").click(function () {
	let target = "#" + $(this).html();//ID値を取得
	let th = $(target).position();//ID値の要素の位置を取得
	let sh = $(".scroll").scrollTop();
	let pos = th.top + sh + 1;

	$(".scroll").animate({
		scrollTop: pos
	}, "slow", "swing");
});