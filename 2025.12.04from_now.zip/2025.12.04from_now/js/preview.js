document.addEventListener("DOMContentLoaded", () => {
    hljs.initHighlightingOnLoad();

    requestAnimationFrame(() => {
        // ✅ レイアウト確定後
        nextProcess();
    });
});


function nextProcess(){
    // 初期表示（前回のスクロール位置を復元）
    const headingVal = document.querySelector('h1')?.textContent ?? '';

    // localStorageからデータを取得
    const savedData = JSON.parse(localStorage.getItem('previewScrollData') || '{}');

    if (savedData.title === headingVal) {
        // 一致 → スクロール復元
        window.scrollBy({
            top: savedData.scroll,
            behavior: 'instant'
        });
    } else {
        // ページタイトルが違う → データ削除
        localStorage.removeItem('previewScrollData');
    }

    // ------------------------------------
    // スクロール時に保存
    // ------------------------------------
    window.addEventListener('scroll', () => {

        try {      
            const scrollPos = window.scrollY;           

            // localStorage に保存
            localStorage.setItem(
                'previewScrollData',
                JSON.stringify({
                    scroll: scrollPos,
                    title: headingVal,
                    time: Date.now()
                })
            );

        } catch (e) {
            console.log(e.message);
        }
    });
}

