function test1(){
    //処理1ですよこここ。
}
function test2(){
    //処理2
}
function test3(){
    //処理3
}