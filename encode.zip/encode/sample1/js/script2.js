//$(document).ready(doit);
  
/*function doit() {
  var run = document.getElementById('run');
  run.removeAttribute('disabled');
  run.addEventListener('click', function() {
    //run.disabled = true;
    convert();
  }, false);
}*/

const filename = 'encoding-sjis.txt';
const encodingName = 'SJIS';

convert();


function convert() {
    return readFile(filename).then(function (data) {
        //appendTitle('Open ', filename);

        //appendText(encodingName + ' Array', Array.prototype.slice.call(data).toString());
        //appendText(encodingName + ' String', Encoding.codeToString(data));

        var detected = Encoding.detect(data);
        //appendText('Encoding.detect(' + encodingName + ' Array)', detected);
        console.log(detected);//SJIS

        var encoded = Encoding.urlEncode(data);
        //appendText('Encoding.urlEncode(' + encodingName + ' Array)', encoded);

        var decoded = Encoding.urlDecode(encoded);
        //appendText('Encoding.urlDecode()', decoded.toString());

        // Convert to Unicode.
        var unicode = Encoding.convert(data, {
            to: 'UNICODE',
            from: 'AUTO'
        });

        console.log(Encoding.codeToString(unicode));

        //appendText(encodingName + ' Array => UNICODE Array', unicode.toString());
        //appendText('UNICODE Array => UNICODE String', Encoding.codeToString(unicode));
    }, function (err) {
        appendTitle('Open ', filename);
        appendText('Error', err);
        console.error(err);
        throw err;
    });
}

function readFile(url) {
    var d = $.Deferred();
    var req = new XMLHttpRequest();
    req.open('GET', url, true);
    req.responseType = 'arraybuffer';

    req.onload = function (ev) {
        if (req.readyState === 4) {
            if (req.status === 200) {
                var buffer = req.response;
                if (buffer) {
                    var data = new Uint8Array(buffer);
                    //d.resolve(data);
                } else {
                    d.reject(req.statusText);
                }
            } else {
                d.reject(req.statusText);
            }
        }
    };

    req.onerror = function (ev) {
        d.reject(req.statusText);
    };

    req.send(null);

    return d;
}