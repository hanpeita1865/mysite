<?php
echo 'いらっしゃいませ';
?>
