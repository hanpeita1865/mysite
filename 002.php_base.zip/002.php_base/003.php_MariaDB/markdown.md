*[page-title]:MariaDBとphpMyAdminのインストール


## MariaDBのインストール

参考サイト
: [MariaDBのダウンロードとインストール](https://www.javadrive.jp/mariadb/install/index1.html)
: [【MariaDB】インストール](https://www.kemmy-it.com/2024/12/30/mariadb_install/)

下記の公式サイトからインストーラー（最新の安定版）をダウンロードし、実行してインストールします。

MariaDB 公式サイト
: https://mariadb.org/

「Download」ボタンをクリックします。
![](upload/mariadb公式サイト.png){.photo-border}

ダウンロードページが開かれます。
![](upload/mariadbのダウンロードページ.png){.photo-border}

ここでは「mariadb-11.7.2-winx64.msi」をダウンロードしました。これをダブルクリックしてインストールを実行していきます。
![](upload/mariadb_11.7.2.png){.photo-border}


「Next」をクリックします。
![](upload/MariaDBインストール1.png){.photo-border}

ライセンスが表示されます。よく読んでいただき同意できる場合には「I accept the terms in the License Agreement」にチェックをしてください。そのあとで「Next」をクリックしてください。
![](upload/MariaDBインストール2.png){.photo-border}

そのまま「Next」をクリックします。
![](upload/MariaDBインストール3.png){.photo-border}

デフォルトでは「C:\program files」に、インストール場所はなっています。今回は、ApacheとPHPを設定した「C:\site」フォルダに設定します。
![](upload/MariaDBインストール4.png){.photo-border}

![](upload/MariaDBインストール5.png){.photo-border}

パスワードを設定します。ここでは、「password」にしました。Nextボタンをクリックします。
![](upload/MariaDBインストール6.png){.photo-border}

![](upload/MariaDBインストール7.png){.photo-border}
そのままNextボタンをクリックすると、次のようなメッセージが表示されます。すでにポートが使用されているというメッセージです。Xamppで3306が設定されているので、それと被ったということが原因になります。
![](upload/ポートは既に使用メッセージ.png){.photo-border}

なので「3316」にポートを変更して、Nextをクリックします。
![](upload/ポートを3316に変更.png){.photo-border}

インストールボタンをクリックします。
![](upload/インストールボタンをクリック.png){.photo-border}

インストールが開始されます。
![](upload/MariaDBインストール開始.png){.photo-border}

インストールが終了しました。
![](upload/MariDBインストール終了.png){.photo-border}

siteフォルダ内に「MariaDB 11.7」フォルダが設置されているのが確認できます。
![](upload/MariaDBインストールフォルダ.png){.photo-border}


Windowsサービスとして登録されているかを確認してみます。

MariaDB をインストールするときに「Install as service」をチェックをしていた場合、 MariaDB は Windows サービスに登録されています。
![](upload/MariaDBがサービスに登録されてるか確認.png){.photo-border}

<div markdown="1" class="memo-box">
サービス画面を開くには、デスクトップ左下にあるスタートメニューを右クリックし、表示されたメニューの中から「コンピュータの管理」をクリックして下さい。  
画面が開いたら、左メニューのサービスをクリックします。
</div>


### MariaDBを起動する

スタートボタンボタンをクリックして、アプリのメニューの中からMariaDBのフォルダを探します。一番下にある「MySQL Client(～)」をクリックします。
![](upload/メニューからMariaDBを探す.png){.photo-border}

インストール時に設定したパスワードを入力します。
![](upload/MySQL_Clienrtパスワード入力.png)

パスワードが一致すると次の画面が表示され、SQL文を記入することができるようになります。（SQL文は1行ずつ記入してエンターキーを押します）
![](upload/MySQLパスワード一致.png)

## phpMyAdminのインストール

参考サイト
: [phpMyAdminのインストール](https://www.javadrive.jp/phpmyadmin/install/)

phpMyAdmin公式サイト
: https://www.phpmyadmin.net/

公式サイトの上部の「Download」をクリックします。
![](upload/phpMyAdmin公式サイト.png){.photo-border}

ダウンロードページが開かれます。「phpMyAdmin-5.2.2-all-languages.zip」をダウンロードします。
![](upload/phpMyAdminダウンロードページ.png){.photo-border}

ファイルをWebサーバへ設置する

 ダウンロードしたzipファイルを解凍して、中のフォルダをApache のドキュメントルート内に配置します。フォルダ名はphpMydminに変更しておきます。
![](upload/phpMyAdmin設置.png){.photo-border}

Apache および MySQL が起動している状態でブラウザから次の URL へアクセスして下さい。（ポートを設定している場合は、localhostのあとにポート番号を付けてください）

<http://localhost/phpMyAdmin/index.php>

おそらく最初は次のようなエラーが表示されるてると思います。
![](upload/mysqliがありませんのエラーメッセージ.png){.photo-border}

これは PHP の設定で 「<span class="red">mysqli</span>」 および 「<span class="red">openssl</span>」 の拡張モジュールが有効になっていないためです。 PHP の設定ファイルである php.ini ファイルをテキストエディタで開いて下さい。  
下記赤線のコードのコメントアウトをとってやります。（ 「mbstring」も使うのに必要な拡張モジュールになります）
![](upload/mysqliとopenssl.png)

コマンドプロンプトで`php -v`を実行してやり、PHPのバージョンを確認します。  
現在新しく組み込んだPHPのバージョンと一致していなければ、環境変数のシステムを開いてください。  

開き方は、スタートボタンを右クリックし、システムをクリックしてシステム設定を「システムの詳細設定」をクリックします。「環境変数」のボタンをクリックして、システム環境変数の「Path」にPHPのパスを追加してやります。
![](upload/システム環境変数のpath.png)
PHPのパスを追加しました。
![](upload/PHPのパスを環境変数に追加.png){.photo-border}

config.inc.phpを作成しておきます。

phpMyAdminディレクトリに「config.sample.inc.php」がデフォルトであるので、それをコピーして「config.inc.php」にリネームします。  
3316のポート設定を追加します。
![](upload/config.inc.php.png)

これでApacheを再起動します。

<http://localhost/phpMyAdmin/index.php>にアクセスします。「root」とインストール時に設定した「パスワード」を入力します。
![](upload/phpMyAdminログイン画面.png){.photo-border}

phpMyAdminの画面が表示されます。
![](upload/phpMyAdmin表示.png){.photo-border}



### cookie認証の秘密鍵を指定する

phpMyAdminにログイン直後のページの最下部には、以下の様なメッセージが出ています。これに対処します。
![](upload/クッキー暗号化のために.png)

config.inc.phpには、以下の様な記述があります。
![](upload/blowfish_secrret.png)

この設定は、phpMyAdminでcookieベースの認証を使用するために必要な設定です。  
具体的には、ユーザーのログイン情報を安全に保持するためにcookieを暗号化する際に使用される秘密鍵（シークレット）を指定するためのものです。  

以下の様に、32バイトのランダムな文字列を指定します。実際には自由な文字列をご入力ください。下記では「nK0i3LSF4XTf0jA2feLpYYklmJ7Mev7r」を記入しています。
![](upload/blowfish_secrretにランダムな値記入.png)
※起動しているときに上記を追加した場合、一度ログアウトする必要があります。

### 環境保管領域を作る

以下の様なメッセージも出ていると思います。
![](upload/環境保管領域メッセージ.png)
ここで挙げられている環境保管領域とは、phpMyAdminのいくつかの高度な機能（例えば、お気に入りSQLクエリの保存、リレーションの追跡、ユーザーの設定など）をサポートするための特別なデータベース設定を指します。

では、環境保管領域～のメッセージを消していきます。

上記メッセージ内にある「理由についてはこちら」というリンクをクリックすると、以下の様になります。
![](upload/環境保管領域メッセージのこちら.png){.photo-border}

上記赤枠の「データベース」リンクをクリックします。下記のようにいろいろ表示されますが、これでちゃんと実行されています。
![](upload/環境保管領域データベースリンクをクリック.png)

再度phpMyAdminのトップに戻ると、メッセージが消えていることが確認できます。




