*[page-title]:position: stickeyの使い方

参考サイト
: [【CSS】position: sticky; の使い方と効かない場合の対処法を解説](https://zero-plus.io/media/use-sticky-to-fix-elements/)

<div class="exp">
	<p class="tmp"><span>例</span></p>
	ZeroPlus Mediaという見出しがスクロールに追従して動き、それぞれの枠の中で追従が終了しているのが確認できます。
ZeroPlus Mediaという見出しが、点線で囲った枠の中だけで追従していることに注目してください。下記のコードでは、この見出し部分にposition: sticky;が適用されています。
<iframe height="600" style="width: 100%;" scrolling="no" title="sticky" src="https://codepen.io/zeroplus-programming/embed/vYWEBwz?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/zeroplus-programming/pen/vYWEBwz">
  sticky</a> by ZeroPlus (<a href="https://codepen.io/zeroplus-programming">@zeroplus-programming</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
</div>

