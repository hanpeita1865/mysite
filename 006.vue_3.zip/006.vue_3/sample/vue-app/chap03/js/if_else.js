Vue.createApp({
  data() {
    return {
      holiday: ''
    };
  }
}).mount('#app');