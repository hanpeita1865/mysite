*[page-title]:Nuxt3

### YouTube
[プログラミング教室 Kikuチャンネル](https://www.youtube.com/channel/UC1Haqzy2vGofLBMjt8ICl2Q)

Nuxt3 入門①Nuxtとは
: https://www.youtube.com/watch?v=ZI_PQw9IiH0

Nuxt3 入門②新規プロジェクトの作成について
: https://www.youtube.com/watch?v=Ewo0Vp_Ix2c

Nuxt3 入門⓷NuxtLinkを使ったページ遷移
: https://www.youtube.com/watch?v=BC9jNx62tM4

入門④タイトルやmeta情報などの追加の方法について
: https://www.youtube.com/watch?v=P2T92HV_gcw&t=7s

入門⑤componentsディレクトリについて
: https://www.youtube.com/watch?v=5kyKDF8m51U

入門5.5　NOT FOUN
: https://www.youtube.com/watch?v=kpyQPfWX0yQ

入門⑥layoutsディレクトリについて
: https://www.youtube.com/watch?v=LQA0xPPPYHs&t=737s

入門⑦動的ルーティングについて
: https://www.youtube.com/watch?v=juulAqJJukM

入門⑧Composablesディレクトリの説明の前に、Vue3のComposable関数の説明
: https://www.youtube.com/watch?v=QxXIVi5MLCo

入門⑨Composablesディレクトリの説明と状態管理のuseStateのちょっとした内容
: https://www.youtube.com/watch?v=z7rPlGjEd9k