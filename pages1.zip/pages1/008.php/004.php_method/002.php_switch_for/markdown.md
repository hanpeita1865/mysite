*[page-title]:switch文、for文、if文

## switch文
<p class="tmp"><span>書式1-1</span></p>
※javascriptと書き方は同じ

```
switch ( 式 ) {
//式が値と合致したときに処理を行い、どれにも合致しなかった場合defaultの処理を行う。
case 値1 :
	処理;
	break;
case 値2 :
	処理;
	break;
default :
	処理;
	break;
}
```

<div class="exp">
	<p class="tmp"><span>例1-1</span></p>
	実行すると、「文系の学部」が表示されます。
	<iframe src="https://paiza.io/projects/e/6pbgbwq3qmfG-_0zrmcQIA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例1-2</span>breakを付けずに OR条件での分岐</p>
	該当したcaseから、次のbreakまでは処理が実行される性質を利用し、いずれかに該当した場合といった条件分岐もできます。
<iframe src="https://paiza.io/projects/e/pTiN9H-yQyI8XIKUvWdYfg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


## for文

<p class="tmp"><span>書式2-1</span>for文</p>
```
for (初期化式; 条件式; 変化式){
  実行する処理1;
}
```

実行される処理が1つだけの場合はブロックを省略して次のように記述しても構いません。
<p class="tmp"><span>書式2-2</span></p>
```
for (初期化式; 条件式; 変化式)
  実行する処理;
```

<div class="exp">
	<p class="tmp"><span>例2-1</span></p>
	$iが0から始まり、5になるまで処理を繰り返す。
	<iframe src="https://paiza.io/projects/e/BwN2YzyA15GCOf0SWbVv4g?theme=twilight" width="100%" height="300" scrolling="no" seamless="seamless"></iframe>
</div>

### break処理

<div class="exp">
	<p class="tmp"><span>例2-2</span></p>
	$1が3になったら、処理を終了させます。
	<iframe src="https://paiza.io/projects/e/j9Eut6nRhmfRvhC1x6IqaQ?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>
</div>


### break処理のネストでの動作結果

* break 1;または、break;→第三階層のループのみ終了
* break 2;→第二階層のループが終了
* break 3;→第一階層のループが終了

<div class="exp">
	<p class="tmp"><span>例2-3</span></p>
	<iframe src="https://paiza.io/projects/e/n6Q6hWLnBC34ozuC2z8zSw?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>
</div>


## if文
	
PHPにおけるもっとも基本的なif文の書き方は、次の通りです。

<p class="tmp"><span>書式3-1</span>if文基本</p>
```
if ($flag == true) {
  // 任意の処理を記述
}
```

このif文ですが、同じ内容のif文を次のように書くことも出来ます。

<p class="tmp"><span>書式3-2</span>if文「{}」なし）</p>
```
if ($flag == true) : # 波括弧を使わない省略記法
  // 任意の処理を記述
endif;
```
最初に示したif文は波括弧でくくられた箇所に処理を記述するタイプでしたが、こちらはコロンからendifまでの間に処理を記述するタイプのif文です。
この書き方も時折見かける機会がありますので、覚えておくとよいです。

### else文の作成・使用方法

else文を使ったif文のコードを次のようになります。

<p class="tmp"><span>書式3-3</span>if～else文</p>
```
if ($flag == true) {  // もし〇〇なら
  // 任意の処理を記述
} else {  // もし〇〇でなければ（否定の条件分岐）
  // 任意の処理を記述
}
```

### elseif文の作成・使用方法

コードは以下のように書きます。
<p class="tmp"><span>書式3-4</span>if～elseif～</p>
```
if ($number > 100) {  // もし〇〇なら
  // 任意の処理を記述
} elseif ($number > 50) {  // もし〇〇ではなく、◇◇なら
  // 任意の処理を記述
} else { // もしどれも当てはまらなければ
  // 任意の処理を記述
}
```

## 参考サイト

* [for文](https://www.javadrive.jp/php/for/index6.html)
* [PHPでif文を使いこなす](https://techplay.jp/column/479)
* [【PHP入門】ループをbreakで終了する(foreach, for, while)](https://www.sejuku.net/blog/22128)