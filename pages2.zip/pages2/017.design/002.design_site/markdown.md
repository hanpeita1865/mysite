*[page-title]:サイト参考

「Microsoft Store」のサイトです。
* カルーセルが変わっていていい。
* トップ無料アプリのボックスもいい。
* サイドバーがなくてすっきりしている。
![](upload/MicrosoftStore.png "Microsoft Storeキャプチャ")


他の記事のページを参考用にボックス
![](upload/次の記事を参考にのボックスデザイン.png)
<https://www.yutaka-note.com/entry/pandas_multiind_set>