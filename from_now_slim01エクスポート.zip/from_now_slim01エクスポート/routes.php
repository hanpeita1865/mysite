<?php

use SocymSlim\SlimMiddle\controllers\SlimMiddleController;
use SocymSlim\SlimMiddle\controllers\AdminController;
use SocymSlim\SlimMiddle\controllers\EditController;
use SocymSlim\SlimMiddle\controllers\SearchController;
use SocymSlim\SlimMiddle\middlewares\UserCheck;
use SocymSlim\SlimMiddle\controllers\PreviewController;
use SocymSlim\SlimMiddle\middlewares\EventLog;
use SocymSlim\SlimMiddle\middlewares\CheckIPAddressBefore;
use SocymSlim\SlimMiddle\middlewares\FolderCount;
use SocymSlim\SlimMiddle\middlewares\FolderSortCheck;
use SocymSlim\SlimMiddle\middlewares\CheckIPAddress;
//テスト
use SocymSlim\SlimMiddle\controllers\AuthController;
use SocymSlim\SlimMiddle\middlewares\BaseAuth;


require 'admin/basepath.php';

$app->setBasePath($basePath."/public");

//各ページ
$app->any('/pages[/{params:.*}]', EditController::class . ':markData')
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\CheckIPAddressBefore::class));
    
    
//テスト　folderObjの値をJSに引き渡し
$app->get('/api/folderObj', EditController::class.":folderObjGet");

//テスト　titlePathObjの値をJSに引き渡し
$app->get('/api/titlePathObj', EditController::class.":titlePathObjGet");



//プレビュー
$app->any("/preview1.php", PreviewController::class.":previewData");


//管理画面
$app->any("/admin", AdminController::class.":adminData")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\FolderCount::class))
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\CheckIPAddressBefore::class));


//編集画面
$app->any("/edit", EditController::class.":editData");


//編集保存
$app->any("/markdown-upload", EditController::class.":markdownUpload");


//ファイル保存
$app->any("/file_save", EditController::class.":fileSave");


//ファイル削除
$app->any("/file_delete", EditController::class.":fileDelete");


//フォルダ新規作成
$app->any("/folder_create", AdminController::class.":folder_create")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));

//メニュー名変更
$app->any("/file_rename", AdminController::class.":file_rename")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));

//フォルダ名変更
$app->any("/folder_rename", AdminController::class.":folder_rename")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));

//locklistテーブル変更
$app->any("/lockdata_edit", AdminController::class.":lockdata_edit")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));


//ロック設定
$app->any("/page_lock", AdminController::class.":page_lock")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));


//ロック解除
$app->any("/page_unlock", AdminController::class.":page_unlock")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));


//フォルダのリスト取得
$app->any("/folder_list", AdminController::class.":folder_list")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));


//lockデータ削除
$app->any("/lockdata_del", AdminController::class.":lockdata_del")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));
    

//削除したフォルダをゴミ箱(trush)に移動
$app->any("/trush", AdminController::class.":trush")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));

//フォルダ削除
$app->any("/folderDelOnly", AdminController::class.":folderDelOnly")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));


//配下のフォルダも削除
$app->any("/del_allfolder", AdminController::class.":del_allfolder")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));



//並べ替え確定
$app->any("/sort_confirm", AdminController::class.":sort_confirm")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\EventLog::class));



//検索結果
$app->any("/search", SearchController::class.":searchResult")
    ->add($container->get(\SocymSlim\SlimMiddle\middlewares\CheckIPAddressBefore::class));


//フォルダ使用中かチェック
$app->any("/folderUseCheck", AdminController::class.":folderUseCheck");


//pages内のディレクトリを配列で取得
$app->any("/pagesDirGet", AdminController::class.":pagesDirGet");


//番号修正
$app->any("/num_replace", AdminController::class.":num_replace");


// //サービステスト
// $app->any("/constructor/helloWithContainer", EditController::class.":helloWithContainer");


// // ログイン関連（ミドルウェアなし）
// $app->get('/login', [AuthController::class, 'showLoginForm']);
// $app->post('/login', [AuthController::class, 'login']);
// $app->get('/logout', [AuthController::class, 'logout']);

// //サービステスト
$app->any("/constructor/helloWithContainer", EditController::class.":helloWithContainer")->add(BaseAuth::class);