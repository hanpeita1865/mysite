---
title: '07. 要素の表示、非表示<br>（show、hide、toggle）'
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">要素の表示</h2>

.show()というjQueryメソッドを使って，要素の表示ができます．

<p class="tmp"><span>書式1</span>要素を表示する</p>
```
対象要素.show(期間，関数);

期間はミリ秒で記述します．
```

<div class="box-example">
<h3 class="h-example">例1</h3>
ボタンをクリックし，非表示になっている要素を表示する．
</div>

<iframe width="100%" height="200" src="//jsfiddle.net/5unfwb3k/2/embedded/html,css,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLとCSSを見てみましょう．  
buttonが設置され，高さ100px，幅100pxで背景色が赤色の＃boxがdisplay:none;で非表示になっています．

ではJavaScriptのコードを見てみましょう．  
buttonをクリックすると＃boxが表示されます．  
また，今回は期間・関数は記入していません．

結果を確認します．  
buttonをクリックすると赤い＃boxが表示されるはずです．  
<font color="Red">.show()はブロック要素の場合，.css('display', 'block')と同じ意味になります．</font>

---

<h2 class="h-type2">要素の非表示</h2>

.hide()というjQueryメソッドを使って，要素の非表示ができます．

<p class="tmp"><span>書式2</span>要素を非表示にする</p>
```
対象要素.hide(期間，関数);

期間はミリ秒で記述します．
```

<div class="box-example">
<h3 class="h-example">例2</h3>
ボタンをクリックし，要素を非表示にする．
</div>

<iframe width="100%" height="200" src="//jsfiddle.net/5unfwb3k/3/embedded/html,css,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLとCSSを見てみましょう．  
buttonが設置され，高さ100px，幅100pxで背景色が赤色の＃boxが表示されています．

ではJavaScriptのコードを見てみましょう．  
buttonをクリックすると＃boxが非表示にされます．  
また，今回も期間・関数は記入していません．

結果を確認します．  
buttonをクリックすると赤い＃boxが非表示となるはずです．  
<font color="Red">.hide()は，.css('display', 'none')と同じ意味になります．</font>

---

<h2 class="h-type2">要素の表示・非表示の切り替え</h2>

.toggle()というjQueryメソッドを使って、要素の表示と非表示を交互に切り替えることができます．

<p class="tmp"><span>書式3</span>要素の表示と非表示を切り替える</p>
```
対象要素.toggle(期間，関数);

期間はミリ秒で記述します．
```
<p class="tmp"><span>引数</span></p>
trueを指定した場合は.show()，falseを指定した場合は.hide()が実行されます．

<div class="box-example">
<h3 class="h-example">例3</h3>
ボタンをクリックし，要素の表示と非表示を切り替える．
</div>

<iframe width="100%" height="200" src="//jsfiddle.net/5unfwb3k/4/embedded/html,css,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLとCSSを見てみましょう．  
同じようにbuttonが設置され，高さ100px，幅100pxで背景色が赤色の＃boxが表示されています．

ではJavaScriptのコードを見てみましょう．  
buttonをクリックすると＃boxの表示と非表示を交互に切り替えられます．  
また，今回も期間・関数は記入していません．

結果を確認します．  
buttonをクリックすると赤い＃boxが表示されたり，非表示になるはずです．