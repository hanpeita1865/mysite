---
title: 商品一覧を表示
taxonomy:
    category:
        - docs
---

## PHPからのselect文の実行

PHPスクリプト内でSQLのselect文を実行しているのが、以下の部分です。
```
$pdo->query('select * from product')
```
PDOのインスタンスを代入した変数$pdoを指定することで、PDOクラスに用意された機能が利用可能になります。  
ここでは、PDOクラスのqueryメソッドを呼び出しています。  
メソッドを呼び出すには、「変数->メソッド」のように「->」を使って記述します。  
queryメソッドは、引数に指定したSQL文をデータベースに対して実行します。  
この例のようにselect文を実行すると、接続したデータベース内の指定したテーブルについて、全ての列を取得できます。

<p class="tmp"><span>書式</span>SQL文の実行</p>
```
PDOの変数 ->query('SQL文')
```

## 取得したデータを1行ずつ処理する

通常、データベースから取得したデータは複数行にわたります。  
ここでも、productテーブルを指定してselect文を実行すると複数行の商品データが返ってきます。  
複数行のデータを順に処理するには、foreachループのような、繰り返し構文を使う必要があります。  
queryメソッドとforeachループを組み合わせると、複数行のデータを簡単に処理することができます。  
サンプルスクリプトでは、次のように記述しています。

```
foreach ($pdo->query('select from product') as $row) {
	・・・
}
```



## 商品一覧を表示する


<http://localhost/php/shop/chapter6/all3.php>

##### all3.php
```
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
foreach ($pdo->query('select * from product') as $row) {
	echo "<p>$row['id']:$row['name']:$row['price']</p>";
}
?>
```
下記のように変数を「:」でつなげて、シンプルに記述しています。
```php
echo "<p>$row['id']:$row['name']:$row['price']</p>";
```

### 文字列内に変数の値を展開する

PHPで文字列を記述するには、**シングルクォート**(')で囲む方法 と、**ダブルクォート** (")で囲む方法があります。
このうちダブルクォートを使った文字列には、文字列内に変数の値を組み込む機能があります。  

通常、配列の添字に文字列を指定するときには、
```
$row['name']
```
のように添字をシングルクォートで囲む必要があります。
一方、ダブルクォートを用いた文字列の 内部では、添字に文字列を指定するときに、
```
"$row[name]"
```
のように、添字をシングルクォートで囲みません。  
ダブルクォートの文字列を使うと、スクリプトが簡潔になる場合があります。




### テーブルで表示

productテーブルに登録された商品の一覧を、HTMLの表(テーブル)を使って、見やすく表示してみます。

<http://localhost/php/shop/chapter6/all4.php>

##### all4.php
```
<table>
<tr><th>商品番号</th><th>商品名</th><th>価格</th></tr>
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');//データベースに接続
foreach ($pdo->query('select * from product') as $row) {
	echo '<tr>';
	echo '<td>', $row['id'], '</td>';
	echo '<td>', $row['name'], '</td>';
	echo '<td>', $row['price'], '</td>';
	echo '</tr>';
	echo "\n";
}
?>
</table>
```

### より安全にデータを表示する

##### all5.php

```
<table>
<tr><th>商品番号</th><th>商品名</th><th>価格</th></tr>
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
foreach ($pdo->query('select * from product') as $row) {
	echo '<tr>';
	echo '<td>', htmlspecialchars($row['id']), '</td>';
	echo '<td>', htmlspecialchars($row['name']), '</td>';
	echo '<td>', htmlspecialchars($row['price']), '</td>';
	echo '</tr>';
	echo "\n";
}
?>
</table>
```

データベースから取得したデータを出力する際に、HTMLにおいて特別な働きを持つ文字が含ま れていると、ブラウザ上の表示が乱れる可能性があります。表示の乱れを防ぐためには、**htmlspecialchars関数**を用いて、データを加工してから表示し ます。  
データに「<」や「>」といった、HTMLにおいて特別な働きを持つ文字を無効化にして、ブラウザにおける表示が乱れを防止します。

```
htmlspecialchars($row['name'])
```

htmlspecialchars関数は、HTMLにおいて特別な働きを持つ文字について、特別な働きを失わせる 関数です。例えば「<」を「&lt;」に、「>」を「&rt;」に変換し、ブラウザがこれらの文字をそのまま画面に表示できるようにします。  
データベースに登録されているデータに、HTMLにおいて特別な働きを持つ文字(く、>、&、"、) が含まれていないことが確実ならば、htmlspecialchars関数を省略することもできます。これらの文字が含まれている可能性があるならば、htmlspecialchars関数 を使うとよいでしょう。






