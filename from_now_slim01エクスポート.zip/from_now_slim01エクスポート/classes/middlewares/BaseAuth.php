<?php
// namespace SocymSlim\SlimMiddle\middlewares;

// use Psr\Http\Server\MiddlewareInterface;
// use Psr\Http\Server\RequestHandlerInterface;
// use Psr\Http\Message\ResponseInterface;
// use Psr\Http\Message\ServerRequestInterface;
// use Psr\Container\ContainerInterface;

// class BaseAuth implements MiddlewareInterface
// {
//     // コンテナインスタンス
//     private $container;

//     // コンストラクタ
//     public function __construct(ContainerInterface $container)
//     {
//         // 引数のコンテナインスタンスをプロパティに格納。
//         $this->container = $container;
//     }

//     public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
//     {
//         // セッションの開始
//         session_start();

//         // //フラッシュメッセージ
//         // if( isset($_SESSION['flash']) ){
//         //     $flash_success = $_SESSION['flash']['success'];
//         // }

//         // unset($_SESSION['flash']);

//         // if (isset($flash_success)){
//         //     foreach ((array)$flash_success as $message){
//         //         echo '<p class="feedback">'.$message.'</p>';
//         //     }
//         // }

//        $Url = (string)$request->getUri();

//        $severParams = $request->getServerParams();
//        $path = $severParams["REQUEST_URI"];
//        $arrayPath = explode('/', $path);
//        $lastkey = array_key_last($arrayPath);
//        $pathLast = $arrayPath[$lastkey];

//        $pathData = mb_split("[?#]", $pathLast);

//     //    if($pathData[0] == 'login'){
//     //         //ログイン画面の場合スルー
//     //         echo 'ログイン画面';

//     //    } elseif (!isset($_SESSION['fromUser'])) {
//     //         //ログイン画面に移動
//     //         // header('Location:login');
//     //         header('Location:login?url='.$Url);

//     //         exit();
//     //     }


//         //ログインしているか確認
//         if (!isset($_SESSION['fromUser'])) {
//             //ログイン画面に移動
//             // header('Location:login');
//             header('Location:login?url='.$Url);

//             exit();
//         }

//         $response = $handler->handle($request);

//         return $response;
//     }
// }



//ChatGPTより
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;
use Slim\Psr7\Response;

class BaseAuth implements MiddlewareInterface {
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {
        // セッション開始（まだの場合のみ）
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // 現在のリクエストパス
        $path = $request->getUri()->getPath();

        // ログインページは認証不要
        if (preg_match('#/login$#', $path)) {
            return $handler->handle($request);
        }

        // 認証チェック
        if (!isset($_SESSION['fromUser'])) {
            $redirectUrl = '/login?url=' . urlencode($request->getUri()->__toString());

            $response = new Response();
            return $response
                ->withHeader('Location', $redirectUrl)
                ->withStatus(302);
        }

        // 認証済みなら次の処理へ
        return $handler->handle($request);
    }
}