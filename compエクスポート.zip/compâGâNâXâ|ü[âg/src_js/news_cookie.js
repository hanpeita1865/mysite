const filterElem = document.getElementById('news_filter');//セレクトボックス
const optionElem = document.querySelectorAll('#news_filter option');//セレクトボックスリスト
const optionArray = Array.prototype.slice.call(optionElem);//配列に変換
const period = 8; //Cookieを保存する期間を指定

let filterNum = 0;//selectbox optionのvalue値（0は「すべて」）
let filter = 'すべて';//cookieに保存なしの場合
let slcArray = [];//cookieから取得した値を格納用
//let pageNum = 1;//初期値（ページ番号）
let cookieSelArray = {};//セレクトボックスとページ番号のcookie格納用


//最初にcookieのselectの値を取得してから実行
cookieGet();


//cookieの保存データを取得し、ページ生成
function cookieGet() {
    //データを1つずつに分ける
    let cookieArray = document.cookie.split(';');

    //cookieにselectデータがある場合
    if (cookieArray.some(value => value.split('=')[0].match(/select/))) {

        selectCookie = cookieArray.find(value => value.split('=')[0].match(/select/)).split('=');
        slcArray=JSON.parse(selectCookie[1]);//配列にcookieの値を格納
        filter = slcArray.category;//カテゴリー名
        filterNum = slcArray.num;//value値
        pageNum = slcArray.page;//ページ番号

        filterElem.options[filterNum].selected = true//selectboxカテゴリ選択

        htmlGeneration();

    } else {
        htmlGeneration();
    }
}


//csvを読み込んで、HTML生成
function htmlGeneration(){
    fetch('files/news/news.csv') 
	//fetch('files/news/news_sample.csv') 
    .then(response => response.text()) 
    .then(data => { 

		let csletr = [];
        let lines = data.split(/\r\n|\n/);

        // 1行ごとに処理
        for (let i = 0; i < lines.length; ++i) {
            let cells = lines[i].split(",");
            if (cells.length != 1) {
                csletr.push(cells);
            }
        }

        //csvファイルをHTMLに変換して挿入
        //view_news_list(filter, data);
		view_news_list(filter, csletr);
    
        redraw_elements = document.querySelectorAll('#csv > li');
    
        //const current_step_update= 1;//初期値 １ページ目に設定（仮）
    
        create_page_counter(redraw_elements);//ページャー生成
        split_page(pageNum);//表示するページを設定
    
        //ページを移動
        document.querySelectorAll('.page_number').forEach((element, index) => {
            element.addEventListener('click', function(e) {
                //console.log('ページ移動');
                current_step = Number(element.getAttribute('data-counter-id'));
                page_counter_change(current_step);
                split_page(current_step, redraw_elements);

                for (i = 0; i < optionArray.length; i++) {
                    if (optionArray[i].selected == true) {
                        filter = optionArray[i].textContent
                        filterNum = optionArray[i].getAttribute('value');
                    }
                }
        
                pageNum = current_step;//ページ番号

                //cookieに保存
                setArrayCookie('select');
            })
        });

        //cookieに保存
        setArrayCookie('select');
    });
}



//セレクトボックス選択（セレクトボックスが切り替わったら発動）
filterElem.addEventListener('change', function() {
    for (i = 0; i < optionArray.length; i++) {
        if (optionArray[i].selected == true) {
            filter = optionArray[i].textContent
            filterNum = optionArray[i].getAttribute('value');
        }
    }

    pageNum = 1;

    //cookieに保存
    setArrayCookie();

    //お知らせ項目の表示再生成
    htmlGeneration(filter);

}, false);


//selectboxの値を配列でcookieに保存
function setArrayCookie (){

    cookieSelArray = {
        category: filter,//カテゴリー名（企画、インフラなどのテキスト）
        num: filterNum,//value値（0、1、2、3、...）
        page: pageNum//ページ番号
    };

    let cookies = 'select =' + JSON.stringify(cookieSelArray) + ';';
    let expire = new Date();

    expire.setTime(expire.getTime() + 1000 * 3600 * 24 * period);
    expire.toUTCString();//日付を文字列に変換
    cookies += 'expires=' + expire + ';';

    //Cookieに保存する
    document.cookie = cookies;
};