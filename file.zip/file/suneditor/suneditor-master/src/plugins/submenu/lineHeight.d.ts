import { SubmenuPlugin } from '../SubmenuPlugin';

declare const lineHeight: SubmenuPlugin;

export default lineHeight;