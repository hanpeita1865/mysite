function getTotal(price) {
    let tax = price * 0.08;

    return price + tax;
}

let total = getTotal(1000);

document.getElementById("result").textContent = "税込み価格：" + total + "円";