<template>
  <div>
    <p class="highlight">よろしくお願いします。</p>
  </div>
</template>

<script>
export default {
  name: 'MyChild'
}
</script>

<style scoped>
</style>