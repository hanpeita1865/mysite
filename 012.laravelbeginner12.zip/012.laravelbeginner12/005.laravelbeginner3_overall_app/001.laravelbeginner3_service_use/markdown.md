*[page-title]:サービスの利用

作業環境
: C:\xampp\htdocs\laravel_3rdherd


## サービスとサービスプロバイダー

Laravelには、必要に応じて機能を組み込み拡張できる「<span class="bold green marker">サービス</span>」と、それを管理する「<span class="bold green marker">サービスコンテナ</span>」があり、アプリ全体に影響する機能を提供します。

### サービスプロバイダー

Laravelでは、機能を追加する「サービス」を登録・管理するために「<span class="bold green marker">サービスプロバイダー</span>」を使います。  
サービスプロバイダーを設定ファイルで登録するだけでアプリに組み込め、Laravelの多くの機能もこの仕組みで作られています。


## ビューコンポーザーについて

Laravelの「<span class="bold green marker">ビューコンポーザー</span>」は、ビュー用の処理をテンプレートやコントローラーに直接書かず、専用の場所に分離して管理する仕組みで、ビューに必要なロジックを適切に配置できる機能です。

### ビューのビジネスロジック

ビューコンポーザーは、ビューを表示する時に自動で実行される処理をまとめたものです。  
関数やクラスで作成し、アプリに登録すると、ビューを表示するときに必要なデータを自動でテンプレートに渡せます。  
これにより、ページ表示に必要な情報を自動で用意できる仕組みです。

![](upload/ビューコンポーザーの仕組み図.png)


### サービスプロバイダーの働き

ビューコンポーザーは、サービスプロバイダーによってコントローラーに結びつけられます。  
サービスプロバイダーにビューコンポーザーの処理を記述し、それをアプリに登録すると、自動的にビューコンポーザーが実行される仕組みです。

![](upload/サービスプロバイダとビューコンポーザ.png "図　ビューコンポーザーはサービスプロバイダー内から利用される。サービスプロバイダーは自動的にアプリケーションに組み込まれ利用できるようになる")


### サービスプロバイダーの定義について

サービスプロバイダーは、クラスとして定義されます。その基本的な形をまとめると以下のようになります。

<p class="tmp"><span>書式</span>サービスプロバイダーの基本形</p>
```
use IlluminateSupportFacades\View;
use IlluminateSupportServiceProvider;

class プロバイダークラス extends ServiceProvider
{

	public function register()
	{
		// コンポーザーの設定
	}

	public function boot()
	{
		// コンポーザーの設定
	}
}
```

サービスプロバイダーはServiceProviderクラスを継承して作成し、registerメソッドでサービス登録を行い、bootメソッドで起動時の処理を実装します。  
ビューコンポーザーはbootメソッド内で設定し、ビューのレンダリング時に自動的に呼び出されます。


## HelloServiceProviderを作成する

Laravelでサービスプロバイダーを作成するには、プロジェクト（例：laravelapp）をVSCodeで開き、ターミナルで
<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:provider HelloServiceProvider
```
を実行します。これで指定名のサービスプロバイダーが自動生成されます。
![](upload/Helloサービス作成.png)

![](upload/ServiceProviderファイル作成.png)

### HelloServiceProvider.phpをチェックする

作成されたサービスプロバイダーは、app/providers フォルダーにあり、HelloServiceProvider.php を開いてコードを確認します。

<p class="tmp list"><span>リスト5-1</span>HelloServiceProvider.php（デフォルト）</p>
```
<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class HelloServiceProvider extends ServiceProvider
{
  public function register()
  {
     //
  }
	
  public function boot()
  {
     //
  }
}
```

自動生成された HelloServiceProvider クラスは ServiceProvider を継承し、boot と register メソッドを持ちます。  
register はサービス登録用ですが今回は使用しません。


## クロージャでコンポーザー処理を作る

ビューコンポーザーの作成方法は、①専用クラスを作成して boot で設定する方法と、②boot 内に無名クラスで直接処理を書く方法があります。  
今回は②の方法で簡単な値をビューに追加します。

<p class="tmp list"><span>リスト5-2</span>HelloServiceProvider.php</p>
```
<?php
namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class HelloServiceProvider extends ServiceProvider
{
  public function boot()
  {
    View::composer(
      'hello.index', function($view){
        $view->with('view_message', 'composer message!');
      }
    );
  }

}
```

ここでは、/hello の index ビューに、view_message という値を設定する処理を作成しています。

### View :: composerについて


View::composer はビューコンポーザーを設定するメソッドで、ビューと処理（クロージャまたはクラス）を関連付けます。  
<p class="tmp"><span>書式</span>ビューコンポーザー設定メソッド</p>
```
View::composer( ビューの指定, 関数またはクラス);
```


ここでは $view->with('view_message', 'composer message!') を使い、ビューに変数を追加しています。
```
function($view){
	$view->with('view_message', 'composer message!');
}
```
<p class="tmp"><span>書式</span>ビューに変数追加</p>
```
$view->with(変数名, 值);
```

## サービスプロバイダーの登録

HelloServiceProviderが完成したら、利用するためにアプリケーションへ登録します。  
登録は、bootstrap/providers.php ファイルで行います。

<p class="tmp list"><span>リスト5-3</span>bootstrap/providers.php</p>
```php
<?php
return [
  App\Providers\AppServiceProvider::class,
  App\Providers\HelloServiceProvider::class,
];
```

providers.php の配列は登録済みプロバイダー一覧で、ここに追記すると起動時に利用可能になります。  
HelloServiceProviderはartisanコマンド作成時に<span class="bold red">自動登録</span>されています。


## ビューコンポーザーを利用する

「hello/index.blade.php」で$messageと$view_messageを表示し、$view_messageはビューコンポーザーで設定、$messageはコントローラーで用意します。

<p class="tmp list"><span>リスト5-4</span>hello/index.blade.php</p>
```
@section('content')
  <p>ここが本文のコンテンツです。</p>
  <p>Controller value<br>'message' = {{$message}}</p>
  <p>ViewComposer value<br>'view_message' = {{$view_message}}</p>
@endsection
```

では、HelloControllerクラスのindexアクションメソッドを以下のように修正しておきましょう。
<p class="tmp list"><span>リスト5-5</span>HelloController.php</p>
```
public function index()
{
  return view('hello.index', ['message'=>'Hello!']);
}
```

これで修正完了です。/helloにアクセスして表示を確認しましょう。

messageとview_messageのいずれも正しく値が表示されます。コントローラーとビューコンポーザーのそれぞれで用意した変数がどちらもちゃんとテンプレートで受け取れたことが確認できます。

![](upload/ビューコンポーザ使用Helloアクセス表示.png){.photo-border}

indexで実行しているview関数では、messageの値しかありません。view_messageの値は用意されていません。それでも問題なく値をテンプレートで扱うことができます。   

ビューコンポーザーが必要な値を用意してくれるのが確認できました。


## ビューコンポーザークラスの作成

サービスプロバイダーとビューコンポーザーの理解を深めるため、独立したビューコンポーザーのクラスを作成します。  
配置場所は特に決まっていませんが、今回は「**Http**」フォルダー内に「**<span class="marker-yellow50">Composers</span>**」フォルダーを作り、その中に「HelloComposer.php」を作成します。

<p class="tmp list"><span>リスト5-6</span>Http/Composers/HelloComposer.php</p>
```
<?php
namespace App\Http\Composers;

use Illuminate\View\View;

class HelloComposer
{
  
  public function compose(View $view)
  {
    $view->with('view_message', 'this view is "'.$view->getName() . '"!!');
  }
}
```
ビューコンポーザークラスは通常のPHPクラスで、特に継承は使いません。  
重要なのは「compose」メソッドで、Viewインスタンスを引数に取り、サービスプロバイダーのbootから呼び出されます。このメソッド内で、ビューの名前を取得し「view_message」に設定しています。

### HelloServiceProviderの修正

では、HelloComposerをビューコンポーザーとして利用するように、HelloServiceProviderクラスを以下のように書き換えてください。

<p class="tmp list"><span>リスト5-7</span>HelloServiceProvider.php</p>
```
class HelloServiceProvider extends ServiceProvider
{
  public function boot()
  {
    View::composer(
      'hello.index', 'App\Http\Composers\HelloComposer'
    );
  }

}
```

ビューコンポーザークラスを使うには、View::composerの第2引数にクラス名の文字列を指定します。  
修正後、/helloにアクセスするとview_messageに「this view is "hello.index" !!」と表示され、ビューコンポーザーが正しく動作していることが確認できます。
![](upload/this_view_is_helloindex.png){.photo-border}

