<?php
//新規登録に成功　セッション削除
unset($_SESSION['name']);
unset($_SESSION['local']);
unset($_SESSION['price']);
unset($_SESSION['image']);//追加
?>