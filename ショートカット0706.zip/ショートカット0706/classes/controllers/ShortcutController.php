<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MenuService,
    MarkdownService,
    ShortcutService,
};
use SocymSlim\SlimMiddle\Config\AppConfig;



class ShortcutController
{
    private EditService $editService;
    private FolderService $folderService;
    private AppConfig $config;
    private MenuService $menuService;
    private MarkdownService $markdownService;
    private ShortcutService $shortcutService;

    public function __construct(
        EditService $editService,
        FolderService $folderService,
        AppConfig $config,
        MenuService $menuService,
        MarkdownService $markdownService,
        ShortcutService $shortcutService,
    ) {
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->config = $config;
        $this->menuService = $menuService;
        $this->markdownService = $markdownService;
        $this->shortcutService = $shortcutService;
    }
    
    public function shortcutList(Request $request, Response $response, array $args): Response
    {
        $basePath = $this->config->basePath;
        $siteName = $this->config->siteName;
        $viewFlag = $request->getAttribute('viewFlag');
        
        try {

            $path = rtrim($request->getUri()->getPath(), '/');
            $folderName = basename($path);
            
            $folderObj = $this->folderService->getFolderCompCached();
            
            $searchMenu = $this->menuService->buildSearchMenu();//サービス（検索カテゴリーリスト取得）
            
            $json_searchMenu = json_encode($searchMenu, JSON_UNESCAPED_UNICODE);
            file_put_contents('../common/search/search_menu.json', $json_searchMenu);
                                                
            $menuData = $this->menuService->buildMenuCached('../pages');//サービス（メニュー生成）
            
            $markData = $this->markdownService->getMarkdownData($folderObj, $folderName, $viewFlag);//サービス（マークダウン変換）
            
            if (!$markData['success']) {
                $assign["errorMsg"] = $markData['message'];
                $templatePath = "error.twig";

                $twig = $this->editService->view();
                return $twig->render($response, $templatePath, $assign);
            }

            $htmlData = $markData['html'];
            $title = $markData['title'];
                        
            $text = strip_tags($htmlData);
            $text = preg_replace('/\s+/u', '', $text);
            
            $folderPath = str_replace('..', '', $folderObj[$folderName]);
                        
            $titlePathObj = $this->folderService->getTitlePathList($folderObj[$folderName] ?? null);

            $shortcutLists = [
                'windows' => [
                    'title' => 'Windows',
                    'items' => $this->shortcutService->getList( $folderPath, 'windows'),
                ],
                'vscode' => [
                    'title' => 'VSCODE',
                    'items' => $this->shortcutService->getList($folderPath, 'vscode'),
                ],
                'browser' => [
                    'title' => 'ブラウザ',
                    'items' => $this->shortcutService->getList($folderPath, 'browser'),
                ],
                'excel' => [
                    'title' => 'EXCEL',
                    'items' => $this->shortcutService->getList($folderPath, 'excel'),
                ],
            ];

            $assign["shortcutLists"] = $shortcutLists;
            $assign["useShortcutJs"] = true;

            
            $assign["isLogin"] = $request->getAttribute('isLogin');
            $assign["canView"] = $request->getAttribute('canView');
            $assign["canEdit"] = $request->getAttribute('canEdit');
            $assign["isAdmin"] = $request->getAttribute('isAdmin');
            $assign["isEditor"] = $request->getAttribute('isEditor');
            $assign["userName"] = $request->getAttribute('userName');
            $assign["isDraft"] = $request->getAttribute('isDraft');
            
            $assign["menuData"] = $menuData;
            $assign["folderObj"] = $folderObj;
            $assign["htmlData"] = $htmlData;
            $assign["title"] = $title;
            $assign["titlePathObj"] = $titlePathObj;
            
            $templatePath = "shortcutPage.twig";
            $assign["folderDir"] = $folderObj[$folderName] ?? null;
            $assign["folderName"] = $folderName;
            $assign['draftBadgeClass'] = $request->getAttribute('isDraft')
                    ? ($request->getAttribute('canEdit') ? 'success' : 'warning')
                    : null;
        }

        catch (PDOException $ex) {
            $assign["errorMsg"] = "データベース処理に失敗しました。もう一度始めからやり直してください。";
            $templatePath = "error.twig";
        }       

        $assign["pathBase"] = $basePath;
        $assign["siteName"] = $siteName;
        $assign["redirect"] = $path;

        $twig = $this->editService->view();
        
        $response = $twig->render($response, $templatePath, $assign);
        
        return $response;
    }




    public function shortcutApi( Request $request, Response $response ): Response {
        
        $queryParams = $request->getQueryParams();

        $type = $queryParams['type'] ?? 'windows';
        $folderName = $queryParams['folderName'] ?? '';
        

        
        $folderObj = $this->folderService->getFolderCompCached();
        
        $folderPath = str_replace('..', '', $folderObj[$folderName]);
        

        $shortcuts = $this->shortcutService->getList($folderPath, $type);

        $response
            ->getBody()
            ->write(
                json_encode(
                    $shortcuts,
                    JSON_UNESCAPED_UNICODE
                )
            );

        return $response->withHeader(
                'Content-Type',
                'application/json'
            );
    }
    
    
    //-------------------------------------
    // 詳細用マークダウン
    //-------------------------------------
    
    public function detail( Request $request, Response $response, array $args ): Response {

        $queryParams = $request->getQueryParams();

        $folderName = $queryParams['folderName'] ?? '';
        
        $folderObj = $this->folderService->getFolderCompCached();
            
        $folderPath = str_replace('..', '', $folderObj[$folderName]);


        $id = $args['id'];

        // $html = $this->shortcutService->getShortcutDetail($id);
        $html = $this->shortcutService->getShortcutDetail($id, $folderPath);

        $response->getBody()->write(json_encode([
            'html' => $html
        ]));

        return $response
            ->withHeader('Content-Type', 'application/json');
    }
}