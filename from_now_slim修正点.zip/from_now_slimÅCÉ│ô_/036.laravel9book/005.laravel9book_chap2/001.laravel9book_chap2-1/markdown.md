*[page-title]:Chap2-1 データベースからつぶやきを取得する（example-app5）

<span class="bold green">Chap2-1 完成品</span>
* \\wsl.localhost\Ubuntu-24.04\root\example-app5
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>

## コントローラの作成

ここではまず、LaravelでのWebアプリケーション構築の基本をおさえつつデータベースからつぶやきのデータを取得する仕組みを作成していきます。
<p class="tmp cmd"><span>コマンド</span>IndexControllerファイル作成</p>
```
sail artisan make:controller Sample/IndexController
```
![](upload/IndexControllerファイル作成.png)

Sampleフォルダとindexcontrollerファイルが作成されています。
![](upload/Sampleフォルダとindexcontrollerファイルが作成.png){.photo-border}

<p class="lang">IndexController.php （デフォルトコード）</p>
```
<?php
namespace App\Http\Controllers\Sample;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    //
}
```

新しく「class IndexController extends Controller」内にコードを追加します。

<p class="tmp list"><span>リスト1-1</span>sample/IndexController.php </p>
```
public function show()
{
		return 'Hello';
}
```

showメソッドを作成し、Helloという文字列を返すように設定します。  
routes/web.phpに下記のコードを追加しましょう。

<p class="tmp list"><span>リスト1-2</span>routes/web.php</p>
```
Route::get('/sample', [\App\Http\Controllers\Sample\IndexController::class,'show']);
```

これで、<http://localhost/sample> にアクセスすると、次のように「Hello」が表示されます。

![](upload/アクセスしてHelloが表示.png){.photo-border}

次に、URLからの値を取得します。  
※reyturnの$idは「<span class="red bold">"</span>」で囲む必要があるようです。「<span class="blue bold">'</span>」だと$idのまま表示されてしまいます。
<p class="tmp list"><span>リスト1-3</span>IndexController.php</p>
```
public function showId($id) {
    return "Hello {$id}";
}
```


ルーティングも追加します。
<p class="tmp list"><span>リスト1-4</span>routes/web.php</p>
```
Route::get('/sample/{id}', [\App\Http\Controllers\Sample\IndexController::class,'showId']);
```

そして、<http://localhost/sample/125>でアクセスすると「Hello 125」と表示されます。
![](upload/Hello125表示.png){.photo-border}


### シングルアクションコントローラ

シングルアクションコントローラとは、一つのコントローラに一つのエンドポイントしかルーティングされていない状態を指します。 先ほど紹介したコント ローラでメソッドを一つだけにすることもできますが、 複数人で開発する場合 そのルールが守られるとは限りません。  

次に紹介するコマンドでは、「<span class="red">'_invoke'</span>」いうPHPのマジックメソッドを利用して一つのコントローラクラスに一つのメソッドしかルーティングできないという制約を生み出します。

それでは、ここからは実際につぶやきアプリケーションの制作を進めていきます。 まず、次のArtisanコマンドを利用してシングルアクションコントローラ を作成しましょう。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:controller Tweet/IndexController --invokable
```
![](upload/artisan_make_controller.png)

Tweetフォルダと中にIndexController.phpファイルが作成されました。
![](upload/Tweetフォルダと中にIndexController.phpファイルが作成.png){.photo-border}


<p class="tmp list"><span>リスト1-5</span>Tweet/IndexContoroller.php （デフォルトのコード）</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function __invoke(Request $request)
    {
        //
    }
}
```

__invokeメソッドが定義された状態で作成されました。  
メソッドは、ひとまず次のようにも文字列を返すようにしましょう
<p class="tmp list"><span>リスト1-6</span>Tweet/IndexContoroller.php</p>
```
public function __invoke(Request $request)
{
    return 'Single Action!';
}
```

ルーティングを追加します。

<p class="tmp list"><span>リスト1-7</span>routes/web.php</p>
```
Route::get('/tweet', \App\Http\Controllers\Tweet\IndexController::class);
```

<http://localhost/tweet>にアクセスしてみましょう。次のように表示されます。
![](upload/singleActtion.png){.photo-border}

このようにシングルアクションコントローラは__invokeというマジックメソッドを利用するため、 重複して同名のメソッド名で定義するとエラーとなり一つのコントローラに一つのメソッドを強制することができます。



## HTMLを表示する

テンプレートエンジン「Blade」に変数などを埋め込むときに使う「<span class="red">{{}}</span>」はXSS攻撃を防ぐために<span class="bold">htmlspecialchars関数</span>を通して出力されます。

また、実際にはJavaScriptを実行したい場合があるかもしれません。その際には、「<span class="red">{!! !!}</span>」を利用することでhtmlspecialchars関数によるエスケープをせずに出力できます。

### コントローラからHTMLテンプレートを呼び出す

resources/viewsに「tweet」ディレクトリを新規作成して、そこにindex.blade.phpファイルを新規作成します。

<p class="tmp list"><span>リスト2-1</span>resources/views/tweet/index.blade.php</p>
```
<!doctype html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>つぶやきアプリ</title>
</head>
<body>
    <h1>つぶやきアプリ</h1>
    <p>{{ $name }}</p>
</body>
</html>
```

続いてTweet//IndexControllerを次のように変更しましょう。

<p class="tmp list"><span>リスト2-2</span>app/Http/Controllers/Tweet/IndexController.php</p>
```
public function __invoke(Request $request)
{
    return view('tweet.index', ['name' => 'laravel']);
}
```

<http://localhost/tweet>にアクセスすると、次のように表示されます。

![](upload/つぶやきアプリ.png){.photo-border}


### Viewの呼び出し方

viewヘルパー関数以外にもViewを呼び出す方法があります。

<p class="tmp list"><span>リスト2-3</span>Facadeで呼び出す</p>
```
use Illuminate\Support\Facades\View;

class IndexController extends Controller
{
    public function __invoke(Request $request)
    {
        return View::make('tweet.index', ['name' => 'laravel']);
    }
}
```

<p class="tmp list"><span>リスト2-4</span>Factoryをインジェクションして呼び出す</p>
```
use Illuminate\View\Factory;

class IndexController extends Controller
{
    public function __invoke(Request $request, Factory $factory)
    {
        return $factory->make('tweet.index', ['name' => 'laravel']);
    }
}
```

これらは呼び方は異なりますがviewヘルパー関数も Facadeも内部的に はView\Factroryを呼び出しているので結果的には同じ動作になります。フ レームワークが簡易的に呼び出す方法を提供しているだけですのでお好きな 方法を利用するとよいかと思います。  
またテンプレートへの変数の渡し方にも別の方法があります。

```
return view('tweet.index')->with('name', 'laravel');
```

第2引数に配列で渡すのではなく、 with 関数を利用して第1引数に変数名、第2引数に変数の値を指定することが可能です。

```
return view('tweet.index')
            ->with('name', 'laravel')
            ->with('version', '8');
```

with関数はメソッドチェーンで何度も呼び出しが可能なので、続けて呼び出すことで別の変数を宣言することができます。




## つぶやき一覧の表示機能を実装する

つぶやき一覧画面を表示できる画面を作成するため、以下について学んでいきます。

1. アプリケーションのデータベースを作成
2. データベースのテーブル定義を作成
3. シーディングで開発用のデータを一括挿入
4. アプリケーションとデータベースを接続してつぶやき一覧を表示


### データベースを作成する

ここでは、Laravel Sailに同梱されているMySQLのデータベースを利用します。
それではMySQLにログインしてみましょう。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail mysql
```

<p class="tmp cmd"><span>コマンド</span>MySQLのバージョン確認</p>
```
select version();
```
![](upload/select_version.png)

Laravel Sailではアプリケーションと同名のデータベースが作成されます。  
コマンドで確認すると、次の通りexample_appというデータベースが作成されていることがわかります。

<p class="tmp cmd"><span>コマンド</span>データベース表示</p>
```
show databases;
```

![](upload/show_databasses.png)

このデータベースを利用して開発します。
テーブルはまだありません。

<p class="tmp cmd"><span>コマンド</span>テーブル表示</p>
```
show tables from example_app;
```

### テーブルを作成する

<p class="tmp cmd"><span>コマンド</span>テーブル作成</p>
```
sail artisan make:migration create_tweets_table
```
![](upload/tweetsテーブル作成.png)

database/migrationsの中にファイルが作成されています。
![](upload/tweetsテーブル作成フォルダ確認.png)


<p class="tmp list"><span>リスト3-1</span>database/migrations/2023_07_15_031614_create_tweets_table.php（デフォルト）</p>
```
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tweets', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tweets');
    }
};
```

このファイルを拡張して好きなようにスキーマを定義していきます。  
マイグレーションクラスにはupとdownの2つのメソッドがあり、upメソッドでは新規に追加するテーブルや拡張するカラムなどのスキーマを指定し、downメソッドではupメソッドとは反対に戻す際の処理を記述します。

<span class="bold">upメソッドを変更　</span>
<p class="tmp list"><span>リスト3-2</span>database/migrations/2023_07_15_031614_create_tweets_table.php</p>
```
public function up(): void
{
    Schema::create('tweets', function (Blueprint $table) {
        $table->id();
        $table->string('content');//追加
        $table->timestamps();
    });
}
```
<div markdown="1" class="memo-box">
カラムの指定には様々なメソッドが用意されていますので、公式ドキュメントで参照できます。
[https://laravel.com/docs/9.x/migrations#available-column-types](https://laravel.com/docs/9.x/migrations#available-column-typess)
</div>

Artisanコマンドからマイグレーションを実行します。

<p class="tmp cmd"><span>コマンド</span>マイグレーション実行</p>
```
sail artisan migrate
```
![](upload/artisan_migration.png)

※create_users_table、create_password_resets_table、create_failed_jobs_table、create_personal_access_tokens_tableはフレームワークが最初から持っているマイグレーションです。

MySQLにログインしてテーブルを確認してみましょう。

<p class="tmp cmd"><span>コマンド</span>テーブル確認</p>
```
sail mysql
mysql>show tables from example_app;
```
![](upload/mysqlにログインしてテーブル再確認.png)

次のコマンドで、twwetsテーブルが作成されていることが、確認できます。
<p class="tmp cmd"><span>コマンド</span></p>
```
show columns from tweets;
```
![](upload/colmns_from_tweetts.png)

phpMyAdminで確認すれば、exampleデータベース内のテーブルは一目でわかります。
![](upload/example_app_phpmyadmin.png "図　phpMyadmin")


### シーディングを利用して開発用のデータを一括挿入

シーティングとは、初期状態でいくつかダミーのレコード を用意しておく機能です。

参考サイト
: [シーダーについて（基本）](https://laraweb.net/knowledge/2302/)

<div markdown="1" class="memo-box">
Laravel においてシーダーとはデータベースにテストデータを一斉に挿入する処理を指します。  
シーダー(Seeder)とは英語で「種をまく人」という意味になります。  
DB に種をまくイメージです。
</div>  

では、シーディングを行うためのシーダーを作成します。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:seeder TweetsSeeder
```
![](upload/seeder_TweetsSeeder.png)


database/seederディレクトリにTweetsSeederクラスが作成されます。

ファイルは次のようになっています。

<p class="tmp list"><span>リスト3-3</span>database/seeders/TweetsSeeder.php（デフォルト）</p>
```
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TweetsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
    }
}
```

runメソッドに追加したいデータを記述します。
<p class="tmp list"><span>リスト3-4</span>database/seeders/TweetsSeeder.php</p>
```
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;//追加
use Illuminate\Support\Str; //追加


class TweetsSeeder extends Seeder
{
    public function run(): void
    {
			DB::table('tweets')->insert([ //追加
				'content' => Str::random(100),
				'created_at' => now(),
				'updated_at' => now(),
			]);
    }
}
```

作成したシーダーはメインとなるdatabase/seederにあるDatabaseSeederのrunメソッドに追加します。

<p class="tmp list"><span>リスト3-5</span>database/seeders/DatabaseSeeder.php</p>
```
public function run(): void
{
    $this->call([TweetsSeeder::class]);//追加
}
```

シーダーを実行します。
<p class="tmp cmd"><span>コマンド</span>シーダー実行</p>
```
sail artisan db:seed
```
![](upload/arrtissan_db_seeed.png)

また、個別のシーダーを呼び出す際には、<span class="red">--classオプション</span>を利用できます。

<p class="tmp cmd"><span>コマンド</span>個別のシーダー呼び出し</p>
```
sail artisan db:seed --class=TweetsSeeder
```

シーダー実行後の、データベースの中身を見てみましょう。

<p class="tmp cmd"><span>コマンド</span>tweetsデータベース中身の確認</p>
```
sail mysql

mysql>use example_app;

mysql>select * from tweets;
```
![](upload/select_froM_tweets.png)

ダミーデータが挿入されていることが確認できます。    
phpMyAdminで確認すると、次のようになっています。
![](upload/phpMyAdminシーダー実行後のtweetテーブル.png "図　phpMyAdmin シーダー実行後のtweetテーブル"){.photo-border}

シーダーは、次に紹介するEloquentモデルとFactoryを利用することで、開発時により実用的なダミーデータを生成することが容易になります。  
現在のデータは不要なので、「sail mysql」を実行してから次のコマンドを実行してテーブルを初期化しておきましょう。

<p class="tmp cmd"><span>コマンド</span>テーブル初期化</p>
```
mysql>truncate table tweets;
```
![](upload/tweets.テーブル初期化png.png)


## Eloquentモデルを作成する

Laravelでは、Eloquent ORMを利用してデータベースとコードを結びつけることができます。  
このような仕組みを「<span class="green bold">オブジェクトリレーショナルマッパー (ORM) </span>」と呼びます。

Eloquentモデルクラスを作成し、そのクラスがデータベースのレコードと対の関係となります。  
PHPコードからはEloquentモデルを利用してデータの<span class="red">取得・追加・変更・ 削除</span>を行うことができます。  
Eloquentモデルの作成も<span class="red">Artisanコマンド</span>から行うことができます。

<p class="tmp cmd"><span>コマンド</span>Eloquentモデルの作成</p>
```
sail artisan make:model Tweet
```
![](upload/sail_artisan_make_model_Tweet.png)
コマンドを実行すると、app/Modelsディレクトリ内にTweetクラスが作成されます。
![](upload/app_Modelsディレクトリ内にTweetクラスが作成.png){.photo-border}

make:modelコマンドにはいくつかのオプションが用意されています。  
下記はマイグレーションファイルも一緒に生成します。先ほどの手順を同時に行うことができます。
 ```
sail artisan make:model Tweet --migration
sail artisan make:model Tweet -m
```
下記はモデルファクトリーを一緒に生成します。 モデルファクトリーはテスト の際にテストデータを生成するために利用します。
```
sail artisan make:model Tweet --factory
sail artisan make:model Tweet -f
```
下記はシーダーも一緒に生成します。 シーダーは開発時向けなどに一括で データを挿入する場合に利用します。
```
sail artisan make:model Tweet --seed
sail artisan make:model Tweet -s
```
下記はコントローラも一緒に生成します。
```
sail artisan make:model Tweet --controller
sail artisan make:model Tweet -c
```
下記はモデル・モデルファクトリー・シーダー・コントローラを生成します。
```
sail artisan make:model Tweet -mfsc
sail artisan make:model Tweet --all
```
下記はピボットモデルを生成します。 ピボットモデルは交差テーブル(P.223)
と対応するモデルです。
```
sail artisan make:model Tweet --pivot
```


それでは作成されたモデルを見てみます。
<p class="tmp list"><span>リスト4-1</span>app/Models/Tweet.php（デフォルト）</p>
```
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tweet extends Model
{
    use HasFactory;
}
```

モデルファクトリーのためのトレイトのHasFactory以外には記述はありませんが、基本的にはこれだけでORMとして機能します。  
ここでは現在の状態で問題なく機能しますが、場合によってはモデルとテーブルが対応されない場合があります。

Eloquentモデルでは、テーブル名の指定がない場合は対応するテーブルはクラス名のスネークケース (小文字で単語間を _でつなぐ命名形式) かつ 複数形のテーブルとマッピングします。 つまりTweetモデルは tweetsテーブルに対応します。 もし、テーブル名が tweetの場合は明示的にひも付けをしてあげる必要があります 

<p class="tmp list"><span>リスト4-2</span>app/Models/Tweet.php（クラス名とテーブル名を明示的にひも付け）</p>
```
class Tweet extends Model
{
    use HasFactory;
    protected $table = 'tweets';//追加
}
```
※上記のテーブル名「tweets」を参考書のように「tweet」にすると、「sail artisan db:seed」を実行した時にエラーが出る。


このように、モデルとしてデフォルトで対応する名前とは別のデータベース定義を行っている場合は、 モデル側に対応する名前を宣言してあげる必要が
あります。  
その他にも、たとえば主キーの名前がidではなくtweet_idだった場合は次のように変更する必要があります。

主キーの名前がidではなくtweet_idだった場合
```
protected $primaryKey = 'tweet_id';
```
また、Eloquentモデルでは主キーは増分整数値 (auto increment) で あると想定しています。  
昨今は主キーにUUIDを利用するケースも増えてきているので、こういった 場合は 次のように増分整数ではないことを宣言します。

主キーが増分整数ではないことを宣言
```
public $incrementing = false;
```

主キーが整数でない場合は次のように指定します。

主キーが整数でない場合
```
protected $keyType = 'string';
```
そして、Eloquentモデルではコンポジット主キー(複合主キー) をサポート していません。その場合は別のユニークキーとなるカラムを追加する必要があります。  
Eloquentモデルではマイグレーションで指定した$table->timestamps() を前提としています。 データベース定義として created_at、 updated_at が 不要な場合は 次のように指定します。

created_at updated_atが不要な場合の指定
```
public $timestamps = false;
```
もしくはカラム名にcreated_atやupdated_atとは異なる名前を利用し たい場合もあるかもしれません。 その場合は次のように対応するカラム名 を指定することができます。

対応するカラム名を指定
```
const CREATED_AT = 'creation_date';
const UPDATED_AT = 'updated_date';
```

## Factoryを作成する

<div markdown="1" class="memo-box">
ファクトリーとは、シーダーの１種で、同テーブルに一度に大量のデータを投入したいときに利用する仕組みです。
ファクトリーを利用するには、eloquentクラスが必要になります。
</div>

Eloquentモデルが作成できたので、続いてFactoryを作成します。
こちらもArtisanコマンドから作成が可能です。
<p class="tmp cmd"><span>コマンド</span>Factory作成</p>
```
sail artisan make:factory TweetFactory --model=Tweet
```
![](upload/model_Tweet.png)

database/factoriesディレクトリ内にTweetFactoryファイルが作成されています。
![](upload/TweetFactoryファイル作成.png)

デフォルトのコードは次のようになっています。

<p class="tmp list"><span>リスト5-1</span>database/factories/TweetFactory.php（デフォルト）</p>
```
<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Tweet>
 */
class TweetFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            //
        ];
    }
}
```

definitionメソッドに生成したいデータを記述します。
<p class="tmp list"><span>リスト5-2</span>database/factories/TweetFactory.php</p>
```
public function definition(): array
{
    return [
        'content' => $this->faker->realText(100)//追加
    ];
}
```
「<span class="red">$this->faker</span>」は、ダミーのテキストを生成してくれるライブラリです。
Fakerを呼び出すことができます。

デフォルトでは英語のダミーテキストになるので、プロジェクトディレクトリのconfig/app.phpのfaker_localeをja_JPに変更しましょう。
<p class="tmp list"><span>リスト5-3</span>config/app.php（112行目）</p>
```
    // 'faker_locale' => 'en_US',
    'faker_locale' => 'ja_JP', //追加
```

### Factoryを利用してシーディングを行う

それでは再度シーダーファイルを編集し、作成したEloquentモデル、Factoryを利用してデータを挿入してみましょう。

<p class="tmp list"><span>リスト5-4</span>database/seeders/TweetsSeeder.php</p>
```
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Tweet;//追加


class TweetsSeeder extends Seeder
{
    public function run()
    {
        Tweet::factory()->count(10)->create();//追加
    }
}
```

runメソッドでTweetのEloquentモデルを呼び出し、factoryメソッドからcountメソッドをチェーンし、createメソッドを実行します。

factoryメソッドはその名の通り作成したFactoryクラスが利用されます。  
<span class="red">countメソッドの引数</span>で挿入するデータの個数を指定できます。ここでは10としているので、10レコード作成されます。  
最後にcreateメソッドを呼び出してデータを挿入します。

では、シーダーを実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan db:seed
```

挿入されたデータを確認してみましょう。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail mysql

mysql>use example_app;

mysql>select * from tweets;
```

ダミーの10個のデータが挿入されたことが確認できます
![](upload/tweetsテーブルに10個のデータpng.png)


phpMyAdminで確認してみます。
![](upload/tweet_dummydata.png "図　phpMyAdminダミーデータ10件"){.photo-border}

上記のように、Fakerによってダミーのテキストが日本語で挿入されていることが確認できます。  
続いて、このデータをアプリケーションで表示してみましょう。


## データベースを接続してつぶやき一覧を表示

まずはEloquentモデルを利用してデータを取得してみましょう。

<p class="tmp list"><span>リスト6-1</span>app/Http/Controllers/Tweet/IndexController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use App\Models\Tweet;//追加
use Illuminate\Http\Request;

class IndexController extends Controller
{

    public function __invoke(Request $request)
    {
        $tweets = Tweet::all();//追加
        dd($tweets);//追加
        return view('tweet.index')
            ->with('name', 'laravel')
            ->with('version', '8');
    }
}
```
Tweetモデルからallメソッドを用いてデータを全件取得します。  
取得したデータを「<span class="bold">dd</span>」というLaravel独自のヘルパー関数に入れています。   
「<span class="bold">dd</span>」はdump, dieの頭文字で、<span class="marker-yellow50">その場で処理を中断して変数の内容などを出力してくれるため、開発時に便利に利用できる関数</span>です。

<http://localhost/tweet>にアクセスすると、次のように表示されます。  
※array10をクリックすると、データが表示されます。
![](upload/ddでデータ表示.png "図　dd関数の表示例")

Tweet::all() から取得したデータはEloquent/Collection クラスとしてitemsの中に複数のデータが入っていることが確認できます。  
app/Http/Controllers/Tweet/IndexControllerの invokeのメソッドを次のように変更し、blade テンプレートに$tweetsを渡します。

<p class="tmp list"><span>リスト6-2</span>app/Http/Controllers/Tweet/IndexController</p>
```
$tweets = Tweet::all();
return view('tweet.index')
    ->with('tweets', $tweets);
```

Bradeテンプレート側は、&lt;body&gt;を次のように変更しました。
<p class="tmp list"><span>リスト6-3</span>resources/views/tweet/index.blade.php</p>
```
･･･省略･･･
<body>
    <h1>つぶやきアプリ</h1>
    <div>
    @foreach($tweets as $tweet)
        <p>{{ $tweet->content }}</p>
    @endforeach
    </div>
</body>
･･･省略･･･
```

再度、<http://localhost/tweet>にアクセスすると、次のように表示されます。
![](upload/つぶやきアプリBlade表示.png){.photo-border}

<div markdown="1" class="memo-box">
Bladeの公式ドキュメント
: https://laravel.com/docs/10.x/blade
</div>

