---
title: upsert
---

## upsertとは？
upsertとは、update + insertのことで、**データの更新**(update)と**データの挿入**(insert)の両方の機能を併せ持っています。

upsertは、***対象のレコードがあればそのレコードを更新し、レコードがなければレコードの新規追加をする***という場合に便利な機能なのです。


upsertを使わない処理では、
1. まずselect文で対象のデータがあるかを探す
2. 対象データが見つかった場合は、updateをして情報を更新する
3. 対象データが見つからなかった場合は、insertで新しくレコードを追加する

このように、1で対象のデータを探した後に、if文を使って2、3の処理を分岐させていくことになります。

ちょっと面倒だし、場合によっては結構長くなりそうです。  
このような時にupsertを使うとスッキリと書くことができます！

Laravelでupsertを使用するには

<div class="gray-box d-block" markdown="1">
* [Eloquentで、updateOrCreateを使用する方法](#p1)
* [クエリビルダで、updateOrInsertを使用する方法](#p2)
</div>

の方法があります。

## EloquentのupdateOrCreate()の使い方 ##{#p1}

<p class="tmp"><span>書式1</span></p>
```
updateOrCreate(第1引数, 第2引数);
```
第1引数：一致したかどうかの判定を行いたい変数（連想配列の形式）  
第2引数：insertまたはupdateしたいデータを持つ変数（連想配列の形式）

### 使用例1
以下のように、ユーザIDが1001のユーザを検索し、見つかった場合は、名前を’Takeru’へ、歳を33にupdateします。  
もしユーザが見つからない場合は、名前を’Takeru’へ、歳を33のユーザが新規に作成されます。

<p class="tmp list"><span>リスト1</span>updateOrCreate()</p>
```
User::updateOrCreate(
    ['user_id' => 1001],
    ['name' => 'Takeru', 'age' => 33]
);
```

### 使用例2

ちなみに、第一引数や第二引数を複数指定したい場合も連想配列へ追加するだけです。  
こちらは、検索値が複数の場合の例です。

ユーザIDが1001かつメールアドレスがtest@test.com**ユーザを検索**し、見つかった場合は、名前を’Takeru’へ、歳を33に**update**します。  
もし**ユーザが見つからない場合**は、名前を’Takeru’へ、歳を33のユーザが新規に作成されます。

<p class="tmp list"><span>リスト2</span>updateOrCreate()～検索値が複数の場合～</p>
```
User::updateOrCreate(
    ['user_id' => 1001, 'email' => 'test@test.com'],
    ['name' => 'Takeru', 'age' => 33]
);
```


## クエリビルダのupdateOrInsertを使用する ##{#p2}

<p class="tmp"><span>書式2</span></p>
```
bool updateOrInsert(第一引数, 第二引数)
```

### 使用例
こちらは、Eloquentで示した例と同様に、ユーザIDが1001かつメールアドレスがtest@test.com**ユーザを検索**し、見つかった場合は、名前を’Takeru’へ、歳を33に**update**します。

もし**ユーザが見つからない場合**は、名前を’Takeru’へ、歳を33の**ユーザが新規に作成**されます。

<p class="tmp list"><span>リスト3</span>updateOrInsert()</p>
```
DB::table('users')
    ->updateOrInsert(
        ['user_id' => 1001, 'email' => 'test@test.com'],
        ['name' => 'Takeru', 'age' => 33]
    );
```



