---
title: '（移動済）文字列操作(split,slice,trim,join)'
taxonomy:
    category:
        - docs
---

* [split()～文字列を分割](#p1)
* [slice()、substr()～先頭・末尾から任意の文字数を取得・削除する方法](#p1-2)
* [trim()～文字列の空白スペースを削除](#p2)
* [join()～配列を連結](#p3)



## split()～文字列を分割 ##{#p1}

引数に文字や正規表現を入れ、文字列を分割します。

<div class="box-example">
    <h3 class="h-example">例1</h3>
</div>
<iframe width="100%" height="300" src="//jsfiddle.net/hirao/teuw4L5z/14/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<div class="box-example">
    <h3 class="h-example">例2</h3>
<p>一文字ずつ分割します。<br>
    1文字ずつに区切る場合は、第一引数に"空文字"を指定してください。</p>
</div>

<iframe width="100%" height="200" src="//jsfiddle.net/9xmrwe5z/1/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

## slice()、substr()～先頭・末尾から任意の文字数を取得・削除する方法 ##{#p1-2}

<div class="box-example">
    <h3 class="h-example">例</h3>
<p>先頭・末尾から5文字を取得</p>
</div>

<iframe width="100%" height="350" src="//jsfiddle.net/he1mdoju/3/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<div class="box-example">
    <h3 class="h-example">例</h3>
<p>先頭・末尾から3文字を削除</p>
</div>
<iframe width="100%" height="350" src="//jsfiddle.net/he1mdoju/4/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>




<div class="box-example">
    <h3 class="h-example">例3</h3>
<p>一文字ずつバウンドさせる。<br>
    CSSは、SCSSで記述してます。</p>
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/xof52jt3/5/embedded/html,result,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<div class="box-example">
    <h3 class="h-example">例4</h3>
    <p>一回だけバウンドさせる。</p>
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/vs1moz9x/4/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<div class="box-example">
    <h3 class="h-example">例5</h3>
    <p>上からふわっと現れながら、下りてくる。</p>
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/62zv7dja/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## trim()～文字列の空白スペースを削除 ##{#p2}

### trimとは

そもそもtrimとは、JavaScriptのメソッド（関数）の一つで、削除したい対象文字列の前後の空白を削除する機能を持っています。また"空白"とは、スペースやタブ、改行などが対象となります。基本的な構文は以下の通りです。

***※trim()はブラウザによっては効かないので、正規表現を使う。***

<p class="tmp"><span>書式</span></p>
```
"空白を除去したい文字列".trim()
```
<div class="box-example">
    <h3 class="h-example">例6</h3>
    <p>文字列の前後と間の空白を削除</p>
</div>
<iframe width="100%" height="300" src="//jsfiddle.net/73hkn9jz/2/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## join()～配列を連結する ##{#p3}

「join」メソッドは「Arrayオブジェクト」の組み込みメソッドとして標準で用意されており、配列の要素を繋げて文字列に変換することができる便利なメソッドです。
これにより、配列データから特定の文字列を生成したり、置換メソッドと同等の機能を実現できたりします。

<p class="tmp"><span>書式</span>join()の基本的な構文</p>
```
var array = 配列; 
array.join( separator );
 ```
「join」メソッドの引数に指定できる「separator」というのは、配列の各要素を繋げるときに任意の文字列を挿入できる仕組みになります。

<div class="box-example">
    <h3 class="h-example">例7</h3>
    <p></p>
</div>
<iframe width="100%" height="300" src="//jsfiddle.net/6jcpw4xt/3/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>





## 参考サイト ##{#p100}

* [【JavaScript入門】trimで前後の空白スペースを削除する方法](https://www.sejuku.net/blog/24562)
* [【JavaScript入門】joinで配列を連結する方法(改行/置換)](https://www.sejuku.net/blog/23137)
