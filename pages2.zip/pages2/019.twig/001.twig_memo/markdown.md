*[page-title]:Twigメモ

## includeやextendに変数を継承

例
```
{% include 'layouts/page_html.twig' with {'basePath': '/from_now-slim1/public'} %}
```