<?php
// ファイルのデータを取得
$file_path = 'original/seabird-400x266.jpg';
$data = file_get_contents($file_path);

// データをbase64にエンコード
$base64data = base64_encode($data);

echo $base64data;

// base64デコード
$data = base64_decode($base64data);

// finfo_bufferでMIMEタイプを取得
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime_type = finfo_buffer($finfo, $data);

//MIMEタイプをキーとした拡張子の配列
$extensions = [
    'image/gif' => 'gif',
    'image/jpeg' => 'jpg',
    'image/png' => 'png'
];

//MIMEタイプから拡張子を選択してファイル名を作成
$filename = 'image.' . $extensions[$mime_type];

// 画像ファイルの保存
file_put_contents($filename, $data);
