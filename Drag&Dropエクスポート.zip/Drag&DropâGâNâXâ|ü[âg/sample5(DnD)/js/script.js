$('#box').on('dragstart', onDragStart);//ドラッグを開始したときに、onDragStart関数を行う

$('#box').on('drag', onDrag);//ドラッグ中

$('#box').on('dragover', onDragOver);//ドラッグオーバー

$('#box').on('drop', onDrop);//ドロップ

$('#box').on('dragend', onDragEnd);//ドラッグ終わり

objx;
objy;

//ドラッグスタート
function onDragStart(e) {
	console.log('dragstart');
	//始点の移置を取得
	x = e.pageX - this.offsetLeft;
	y = e.pageY - this.offsetTop;
}

//ドラッグ中
function onDrag(e) {
	//console.log('ドラッグ中');
	let drag = document.getElementsByClassName("drag")[0];

	//要素の位置をインラインスタイルで設定
	objx = e.pageY - y + "px";
	objy = e.pageX - x + "px";

	console.log(objx);

	drag.style.top = objx;
	drag.style.left = objy;

	drag.addEventListener("mouseup", mup, false);
}

function onDragOver(e) {
	console.log('ドラッグオーバー')
	e.preventDefault();
}

function onDrop(e) {
	console.log('ドロップ')
	console.log(objx);
}

//ドラッグ終わり
function onDragEnd(e) {
	console.log('ドラッグ終わり');
	console.log(objx);
	drag.style.top = objx;
	drag.style.left = objy;
}
