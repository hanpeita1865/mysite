---
title: 09.(移動済)tablesorter
taxonomy:
    category:
        - docs
---

### <span>Demo1</span>tablesorter basic demo (includes widgets) ###{.demo}

[新規タブ](../../../sample/sample1(tablesorter)/index.html?target=_blank)
<script async src="//jsfiddle.net/Mottie/bbxxomhx/embed/result,html,css,js,resources"></script>

### <span>Demo2</span>tablesorter basic demo with pager plugin ###{.demo}

[新規タブ](../../../sample/sample2(tablesorter)/index.html?target=_blank)
<script async src="//jsfiddle.net/Mottie/wty134u7/embed/result,html,css,js,resources"></script>


### <span>Demo3</span>tablesorter LESS theme ###{.demo}

[新規タブ](../../../sample/sample3(tablesorter)/index.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/sample3(tablesorter)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

### <span>Demo4</span>Tablesorter Bootstrap LESS theme ###{.demo}

[新規タブ](../../../sample/sample4(tablesorter)/index.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/sample4(tablesorter)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


### <span>Demo5</span>Tablesorter Metro LESS theme ###{.demo}

[新規タブ](../../../sample/sample5(tablesorter)/index.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/sample5(tablesorter)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

### </span>Demo6</span>Tablesorter SCSS theme ###{.demo}

[新規タブ](../../../sample/sample6(tablesorter)/index.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/sample6(tablesorter)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>