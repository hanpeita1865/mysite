<?php
//セッションに入力データを登録
$_SESSION['name'] = $_POST['name'];
$_SESSION['local'] = $_POST['local'];
$_SESSION['price'] = $_POST['price'];
?>