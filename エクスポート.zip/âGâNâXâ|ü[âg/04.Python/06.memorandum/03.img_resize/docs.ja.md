---
title: 画像のリサイズなど
media_order: 'pip_install.jpg,pip install_pilllow.jpg,test_resize.jpg,test_resize_error.jpg,test_resize_jpg.jpg,test_resize_all1.jpg,test_resize_all2.jpg'
taxonomy:
    category:
        - docs
---

## Pillowとは

PillowとはPythonで画像を扱うためのライブラリです。Pillowを使えば、

* 画像の読み込み
* カラー画像からモノクロ画像への変換
* 画像の保存
* 回転
* リサイズ
など実に様々な処理ができます。

画像の枚数が数枚であれば手作業で処理してしまっても問題ないかと思いますが、画像の枚数が多い時にはPillowを使って画像を処理していくと作業の効率化ができて良いでしょう。

Pillowで画像をリサイズするのは非常に簡単です。  
リサイズにはPillowのImageモジュールにある**resize()**という関数を用います。引数には (画像の横サイズ, 画像の縦サイズ) という形でタプルを指定します。

## Pillowのインストール

下記のように、仮想環境のターミナルを開きます。

![](pip_install.jpg)

pipコマンドでPillowをインストールする。

![](pip%20install_pilllow.jpg)

では、実際に画像をリサイズするコードを書いてみます。

<p class="tmp list"><span>リスト1</span></p>

```python
from PIL import Image

im = Image.open('test_resize/view.png')

#画像のサイズを表示
print(im.format, im.size, im.mode)

#画像のサイズを指定してリサイズ
#small_view = im.resize((2000, 3000))

#画像のサイズを半分にリサイズ
small_view = im.resize((int(im.width / 2), int(im.height / 2)))

#リサイズした画像を名前をつけて保存
small_view.save("test_resize/small_view.png")
```

実行すると、フォルダにリサイズされたsmall_view.pngが作成されます。
![](test_resize.jpg)

コードのファイル名をjpgに書き換えて、jpgファイルをリサイズすると、エラーが出て変換できません。
![](test_resize_error.jpg)

jpg用に下記の画像をRGBに変換するコードを追記してやります:
<p class="tmp list"><span>リスト2</span></p>
```
if im.mode != 'RGB':
    im = im.convert('RGB')
```
実行すると、うまく変換されました。
![](test_resize_jpg.jpg)

## まとめて変換

次は、フォルダ内にある画像ファイルをまとめて、変換します。  
まとめて変換するには、globモジュールを使います。

### glob.glob() による取得
フォルダ内のファイルの一覧を取得するのに簡単なのは、**globモジュール**を利用することです。 次の例のように、glob モジュールの glob メソッドで簡単にファイル名の配列を取得することができます。 次の例では ./tmp ディレクトリ内のファイルの一覧を取得しています。 「*」は、「全て」を表します。

<p class="tmp list"><span>リスト3</span></p>
```
import glob

files = glob.glob("./tmp/*")
for file in files:
    print(file)
```
実行すると、以下のフォルダ内のファイル名のリストが表示されます。
```
./tmp/aaa.txt
./tmp/bbb.txt
./tmp/ccc.txt
./tmp/ddd.html
./tmp/eee.html
```

では、指定したファルダ内の画像ファイルをリサイズします。  
「test_resize」のフォルダにある画像ファイルを全てリサイズして、「small_test_resize」フォルダに保存します。

<p class="tmp list"><span>リスト4</span></p>
```
from PIL import Image

import glob

files = glob.glob("test_resize/*")
for file in files:

    im = Image.open(file)
    
    if im.mode != 'RGB':
        im = im.convert('RGB')
    
    small_view = im.resize((int(im.width / 2), int(im.height / 2)))
    
    #リサイズした画像を別のフォルダに保存
    small_view.save('small_' + file)
```

画像サイズが変換されたのが確認できるでしょう。
![](test_resize_all1.jpg?classes=caption "図　test_resizeフォルダ")

![](test_resize_all2.jpg?classes=caption "図　small_test_resizeフォルダ")
