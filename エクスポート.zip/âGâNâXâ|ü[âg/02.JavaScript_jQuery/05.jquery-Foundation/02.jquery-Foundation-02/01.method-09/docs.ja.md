---
title: '01. イベント処理<br>（click、hover、on）'
taxonomy:
    category:
        - docs
visible: true
---

jQueryでは，ユーザが特定の操作をした時に実行される処理を記述することができます．  

<h2 class="h-type2">要素がクリックされた時に処理を実行する（click）</h2>

<div class="box-example">
    <h3 class="h-example">例１</h3>
    P要素がクリックされた時、スライドアップする．
</div>
※サンプル内の$(this)は、「イベントが発生した要素」です．  

<iframe width="100%" height="300" src="//jsfiddle.net/ookiki/0b2ptxfz/12/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずはHTMLを見てください．  
P要素が4つとボタンが表示されるようになっています．

次はJavaScriptを見てください．  
全てのP要素に対して、クリックされた時に実行される処理を記述します．  
ここでは、クリックされたP要素がスライドアップ（下から上に消えていくイメージの効果で非表示）します．  
おまけで、「P要素初期化」ボタンがクリックされた時に、全てのP要素を表示する処理を記述します．

Resultを見て、結果を確認します．  
P要素をクリックするとスライドアップされます．  
また、「P要素初期化」ボタンをクリックするとスライドアップで非表示になったP要素が、再表示されます．

---

<h2 class="h-type2">要素にマウスホバーされた時に処理を実行する（hover）</h2>

<div class="box-example">
    <h3 class="h-example">例２</h3>
    リスト要素にマウスホバーされた時、SPAN要素を表示する．
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/ookiki/6ktrphu7/12/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずはHTMLを見てください．  
SPAN要素を含むリスト4つが表示されるようになっています．

次はJavaScriptを見てください．  
全てのリスト内のSPAN要素を非表示にする処理を記述します．  
全てのリストに対して、マウスホバーされた時に実行される処理を記述します．  
ここでは、リスト要素にマウスカーソルが当たった時にSPAN要素を表示して、マウスカーソルが外れた時に非表示にする処理を記述します．  

Resultを見て、結果を確認します．  
リストにマウスカーソルが当たった時、右側にSPAN要素の内容が表示されます．  
マウスカーソルが外れた時、SPAN要素が消えます．

---

<h2 class="h-type2">おまけ - 任意のイベント処理を記述する（on）</h2>

<div class="box-example">
    <h3 class="h-example">例３</h3>
    例１の内容をon()メソッドに置き換える．
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/ookiki/0b2ptxfz/14/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

clickやhoverなど特定のイベントではなく、任意のイベントを指定して処理を記述するのがonメソッドの特徴です．  
ただ普通に使う分には余り有用ではありませんので、onメソッドってのもある程度の認識で良いと思います．

onメソッドで使えるイベントを下記に記述します。

参考サイト
: <https://0017.org/971.html>

|イベント|挙動|
|::|:-----------|
|blur|要素がフォーカスを失った時に発生|
|focus|要素がフォーカスを得た時に発生|
|load|ドキュメント内の全リソースの読み込みが完了したときに発生|
|resize|windowの大きさが変更された時に発生|
|scroll|ドキュメントがスクロールした時に発生|
|click|クリックされた時|
|dblclick|ダブルクリックされた時|
|mousedown|要素上でマウスが押された時に発生|
|mouseup|要素上でマウスが押され、上がった時に発生|
|mousemove|要素上でマウスが移動している時に発生|
|mouseover|マウスが要素に入った時に発生。子要素でも発生|
|mouseout|マウスが要素から外れた時に発生。子要素でも発生|
|mouseenter|マウスが要素に入った時に発生。子孫要素に入った時には発生しない|
|mouseleave|マウスが要素から外れた時に発生。子孫要素から外れた時には発生しない|
|change|要素がフォーカスを得て値の修正が完了した時に発生|
|select|type属性値が”text”のinput要素、textarea要素のテキストが選択された時に発生|
|submit|フォームが送信された時に発生|
|keydown|キーが押し下げられた時に発生|
|keypress|キーが押された時に発生|
|keyup|キーが上がった時に発生|
|error|javascriptのエラーが発生した時に発生|
