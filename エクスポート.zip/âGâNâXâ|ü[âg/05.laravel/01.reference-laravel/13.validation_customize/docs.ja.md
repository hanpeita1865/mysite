---
title: '13. バリデーションをカスタマイズ'
media_order: 'validator_customize01.png,validator_customize02.png,validator_customize03.png,validator_customize04.png,validator_customize05.png,validator_customize06.png,validator_customize07.png,validator_customize08.png,validator_customize09.png'
taxonomy:
    category:
        - docs
---

* [フォームリクエストについて](#p1)
* [フォームリクエストの作成](#p2)
* [HelloReauestクラスの基本コード](#p3)
* [メッセージのカスタマイズ](#p4)
* [バリデータを作成する](#p5)
* [クエリー文字列にバリデータを適用する](#p6)
* [エラーメッセージのカスタマイズ](#p7)
* [条件に応じてルールを追加する](#p8)
* [オリジナル・バリデータの作成](#p9)
* [Hello Validatorを作成する](#p10)
* [HelloValidatorのルールを使用する](#p11)
* [Validator::extendを利用する](#p12)

バリデーションは、使い方を独自に定義していくことができます。ここでは「フォー ムリクエスト」と「カスタムバリデーション」を作成してバリデーションをカスタマイズ する方法を説明しましょう。

## フォームリクエストについて ##{#p1}
validateメソッドを使ったバリデーションは、比較的簡単にバリデーション機能を組み込むことができます。が、このやり方には問題もないわけではありません。  
コントローラのアクション内に手作業でバリデーションの処理を書かなければいけません。アクションの処理をあれこれと編集するような場合は誤って書き換えてしまう危険があります。また、自分でバリデーションのメソッドを呼び出して処理するというの もあまりクールなやり方とは思えないでしょう。  
コントローラは、それぞれのアクションで実行すべきビジネスロジックなどを実行することになるため、「入力された値のチェック」などはできれば他に切り離したいところです。そこでLaravelでは、「***フォームリクエスト***」と呼ばれる機能を考えました。

### フォーム用拡張リクエスト
フォームリクエストは、リクエストをフォーム利用のために拡張したものです。 Laravelでは、クライアントからのリクエストは、Requestクラスのインスタンスとして送られてきます。このRequestを継承して作成されたのが「**FormRequest**」です。これを利用することで、フォームに関する機能をリクエストに組み込むことができます。  
送信されたフォームの内容をチェックするというのは、コントローラにあるより、「リクエストの内部で勝手に処理してくれる」というほうが圧倒的にスマートでしょう。  
またフォームリクエストにはバリデーション関係の機能が組み込まれており、このクラスを継承してカスタマイズすることできめ細かな操作が行えるようになります。例えば、英語だったメッセージを日本語に変更することも可能です。

![](validator_customize01.png?classes=caption "図 一般的なバリデーションはコントローラ内で実行されるが、フォームリクエストを使うとリクエスト内にバリデーション機能をもたせることができる。")

## フォームリクエストの作成 ##{#p2}
では、実際にフォームリクエストを作成してみましょう。これも**artisanコマンド**を使って作成できます。
フォームリクエストは、「artisan make:request」というコマンドを使って作成します。 では、コマンドプロンプトまたはターミナルから以下のようにコマンドを実行して下さい。
```
php artisan make:request HelloRequest
```
![](validator_customize02.png?classes=caption "artisan make:requestで、HelloRequestというフォームリクエストを作成する。")



これで「HelloRequest」というフォームリクエストが作成されます。このスクリプトファイルは、「**Http**」内に作成される「**Requests**」というフォルダの中に、「**HelloRequest.php**」というファイル名で作成されます。  
フォームリクエストは、基本的にすべてこの 「Requests」フォルダ内に配置します。

## HelloReauestクラスの基本コード ##{#p3}
では、作成されたHelloRequest.phpがどのようになっているのか、ソースコードを確認してみましょう。デフォルトでは以下のようなコードが作成されています(コメント類は省略してあります)。

<p class="tmp list"><span>リスト1</span>HelloRequest.php</p>
```
<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class HelloRequest extends FormRequest
{
   public function authorize()
   {
       return false;
   }

   public function rules()
   {
       return [
           //
       ];
   }
}
```

フォームリクエストは、**FormRequestクラス**を継承して作成されます。これはRequestを継承して作られており、リクエストの機能をベースにして更にバリデーションなどの フォームの処理に関する機能が追加されています。 このFormRequestには、以下の2つのメソッドが用意されています。

authorize
: このフォームリクエストを利用するアクションで、*フォームリクエストの利用が許可されているかどうか*を示すものです。戻り値としてtrueを返せば許可され、falseを返す と不許可になり、HttpExceptionという例外が発生してフォーム処理が行えなくなります。

rules 
: *適用されるバリデーションの検証ルールを設定*します。これは、先にコントローラで validateメソッドを呼び出す際に第2引数に指定した、検証ルールの配列と同じものを用意し、returnします。ここでreturnされた検証ルールを元に、FormRequestでバリデーションチェックが実行されます。

この2つのメソッドを用意すれば、フォームリクエストは使えるようになります。では、 実際にHelloRequestを修正してみましょう。

### HelloRequest を修正する
ここでは、先にvalidateメソッドを使ってバリデーションを行ったときと同じ検証ルー ルを適用することにしましょう。HelloRequestクラスを以下のように修正して下さい。

<p class="tmp list"><span>リスト2</span>HelloRequest.php</p>
```
class HelloRequest extends FormRequest
{
   public function authorize()
   {
       if ($this->path() ==  'hello')
       {
           return true;
       } else {
           return false;
       }
   }

   public function rules()
   {
       return [
           'name' => 'required',
           'mail' => 'email',
           'age' => 'numeric|between:0,150',
       ];
   }
}
```
ここでは、まず**authorizeメソッド**で、$this->pathでアクセスしたパスをチェックして います。パスがhelloだった場合はtrueを、そうでない場合はfalseを返しています。  これで、 hello以外から利用できないようにしているのです。

**rulesメソッド**では、先にvalidateメソッドのときに使ったのと同じ検証ルールの配列を用意し、returnしています。これでname、mail、ageの各フィールドにルールが適用 されます。

### アクションを修正する
後は、POST送信時の処理を行うコントローラのアクションを修正しておきましょう。 HelloControllerクラスのpostメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト3</span>HelloController.php</p>
```
// use App\Http\Requests\HelloRequest;　を追加しておく

public function post(HelloRequest $request)
{
   return view('hello.index', ['msg'=>'正しく入力されました！']);
}

```
先に用意したバリデーションに関する部分をすべて削除し、単にviewでテンプレートとmsg変数を返すだけのものに変更しました。コントローラだけを見れば、バリデーショ ンに関する処理は見当たりません。

が、実はちゃんとそのための仕掛けがしてあるのです。  
メソッドの引数を見て下さい。「HelloRequest $request」となっていますね?  
渡される引数が、RequestからHelloRequestに変更されています。これで、HelloRequestに設定した内容を元にバリデーションが実行されるようになります。

では、/helloにアクセスして実際に動作を確かめてみましょう。先程と同様にバリデーションがきちんと機能するのがわかります。

![](validator_customize03.png?classes=caption "図 フォームを送信すると、バリデーションが機能しているのがわかる。")

## メッセージのカスタマイズ ##{#p4}
フォームリクエストがわかったところで、もう少しカスタマイズをしてみましょう。これまでのエラーメッセージはすべて英語でした。日本語で表示させるには、 FormRequestの「**messages**」というメソッドをオーバーライドします。 HelloRequestクラスに、以下のようにメソッドを追加して下さい。

<p class="tmp list"><span>リスト4</span>HelloRequest.php</p>
```
public function messages()
{
   return [
       'name.required' => '名前は必ず入力して下さい。',
       'mail.email'  => 'メールアドレスが必要です。',
       'age.numeric' => '年齢を整数で記入下さい。',
       'age.between' => '年齢は0～150の間で入力下さい。',
   ];
}
```

追記したら、再度フォームを送信してみましょう。すると、エラーメッセージが日本語で表示されるようになります。

![](validator_customize04.png?classes=caption "図　フォームを送信すると、日本語でメッセージが表示される。")


このmessagesは、FormRequestのバリデーション機能がエラーメッセージを必要とした時に呼び出されるメソッドです。ここではメッセージの情報を配列にまとめています。値を見てみると、
```
'name.required' => '名前は必ず入力して下さい。
```
このように、「項目名.ルール名' => 'メッセージ」という形でメッセージ情報を記述します。メッセージ情報は、それぞれのフィールドに用意した1つ1つのルールごとに用意します。複数のルールを設定してある場合は、それぞれのメッセージを用意する必要があります。記述していないルールがあった場合は、デフォルトのメッセージ(英語)がそのまま使われます。

## バリデータを作成する ##{#p5}
バリデーション機能では、FormRequestに用意されている「validate」メソッドを使って バリデーションが行われます。このvalidateでは、Requestインスタンスと検証ルールの引数を渡すことで自動的にフォームの値のチェックを行い、問題があればGETのページにリダイレクトしてフォームの再表示を行います。  
これは大変便利なのですが、場合によっては「エラーがあったらフォームページにリダイレクトせず、別の処理を行わせたい」と思うこともあるでしょう。またフォームの 値以外でバリデーションチェックを行わせたいこともあるはずです。  
このような場合は、バリデータを独自に用意して処理することもできます。バリデータというのは、バリデーションを行う機能のことで、Laravelでは「Validator」というクラスとして用意されています。  
*コントローラのvalidateメソッドを呼び出さず、このValidatorクラスのインスタンス を作成して処理することで、バリデーションの処理をカスタマイズすることができます。* では、やってみましょう。

### バリデータを使ってみる
まずは、validateメソッドと同じ処理をバリデータで作成してみましょう。バリデータは、送信されたフォームを受け取ったアクション内で作成し、利用します。今回の例でいえば、HelloControllerクラスのpostメソッドで実行します。 では、postメソッドを以下のように書き換えて下さい。

<p class="tmp list"><span>リスト5</span>HelloController.php</p>
```
// use Validator;　を追記しておく

public function post(Request $request)
{
   $validator = Validator::make($request->all(), [
       'name' => 'required',
       'mail' => 'email',
       'age' => 'numeric|between:0,150',
   ]);
   if ($validator->fails()) {
       return redirect('/hello')
                   ->withErrors($validator)
                   ->withInput();
   }
   return view('hello.index', ['msg'=>'正しく入力されました！']);
}
```

![](validator_customize05.png?classes=caption "図 フォームを送信するとメッセージが表示される。再び英語に戻った。")

修正したら、またフォームを送信してみましょう。独自のバリデータを使ってチェックが行われます。今回、エラーメッセージの設定などはまだ行っていないため、表示は 再び英語に戻っています。

### バリデータ利用の基本
では、バリデータをどのように使っているのか、その基本をまとめておきましょう。 バリデータは、Validatorインスタンスを作成するだけで使えるようになります。が、こ れは「**make**」というメソッドを使って作成する必要があります。
<p class="tmp"><span>書式1</span></p>
```
validator = Validator::make( 値の配列 , ルールの配列 );
```
第1引数には、チェックする値をまとめた配列を用意します。これは、フォームをそのままチェックするのであれば、Srequest->all)を指定しておけばよいでしょう。  
第2引数には、バリデータで使用する検証ルールの情報を配列にまとめたものが指定されます。これは、今まで何度も作成してきましたから改めて説明するまでもないでしょ う。  
これでインスタンスが作成できました。後はエラーが起きたかチェックし、それに応じた処理を用意すればよいのです。エラーのチェックは、以下のように行います。

<p class="tmp"><span>書式2</span></p>
```
if ($validator->fails()) { ......エラー時の処理...)
```
「**fails**」は、Validatorクラスにあるメソッドで、*バリデーションチェックに失敗した(途中でエラーが発生した)かどうかを調べるものです*。戻り値がtrueならば、エラーが発生しています。これがtrueならば、エラー時の処理を用意すればよいのです。  
同じように、チェックの結果を調べるメソッドとして「**passes**」というものもあります。 こちらは、問題なくバリデーションをパスしていたらtrue、そうでないならfalseになります。

### 入力フォームへのリダイレクト
ここでは、エラーが発生したらGETのページ(/hello)にリダイレクトしています。ただし、普通にリダイレクトするだけでは、エラーメッセージやフォームの値などを受け渡すことができません。そこで、以下のように実行しています。
```
return redirect('/hello')
    ->withErrors($validator) 
    ->withInput();
```
リダイレクトは、Controllerの「**redirect**」メソッドで行います。ただ、指定のアドレスに移動させるだけなら、このredirectだけでよいのです。  
今回は、更にエラーメッセージとフォームの入力情報をリダイレクトの際に追加しています。それが「withErrors」と「withInput」です。  
**withErrors**では、*引数にValidatorインスタンスを渡しています*。これにより、この Validatorで発生したエラーメッセージをリダイレクト先まで引き継ぐことができます。  **withInput**は、*送信されたフォームの値をそのまま引き継ぎます*。

<div class="gray-box" markdown="1">
#### validateのリダイレクトを使うには?
Controllerでvalidateメソッドを呼び出してバリデーションを行わせると、自動的にリダイレクトし、フォームページに戻りました。この機能を利用したい場合はどうすれば よいのでしょうか。  
これは、簡単です。Validatorのvalidateメソッドを呼び出せばいいのです。これにより 再度バリデーションチェックが行われ、エラーがあればフォームページにリダイレクトされます。  
ただし、この方法は、例えばこの後に説明する「フォーム以外の値をバリデーションで チェックする」場合には正しく機能しません。もともとフォームからPOST送信されていないのですから当たり前ですね。このような場合は、サイトのトップページにリダイレ クトされます。
</div>


## クエリー文字列にバリデータを適用する ##{#p6}
バリデータを用意するやり方は、フォーム以外の値をチェックするのにも使えます。 例として、クエリー文字列で渡された値をチェックするバリデータを作ってみましょう。  
今回は、/helloにGETアクセスした時にチェックを行わせてみます。HelloControllerクラスのindexメソッドを修正しましょう。

<p class="tmp list"><span>リスト6</span>HelloController.php</p>
```
public function index(Request $request)
{
   $validator = Validator::make($request->query(), [
       'id' => 'required',
       'pass' => 'required',
   ]);
   if ($validator->fails()) {
       $msg = 'クエリーに問題があります。';
   } else {
       $msg = 'ID/PASSを受け付けました。フォームを入力下さい。';
   }
   return view('hello.index', ['msg'=>$msg, ]);
}
```
![](validator_customize06.png?classes=caption "図 /helloとアクセすると「クエリーに問題があります」と表示される。/hello?id=300&pass=○○ という形でアクセスすると「ID/PASSを受け付けました」と表示される。")

/helloにそのままアクセスしてみましょう。すると、「クエリーに問題があります。」と 表示されます。それを確認したら、今度は/hello?id=xxx&pass=xxx という形式でアクセスしてみて下さい(xxxの部分は任意のテキストに変更して構いません)。すると今度は 「ID/PASSを受け付けました。」と表示されます。 ここでは、Validator.makeメソッドの引数に、以下のような値を指定しています。


##### ■第1引数 
```
$request->query()
```
Requestのqueryメソッドは、送信されたクエリー文字列を配列の形にまとめたものを返します。例えば、こんな具合です。
```
/hello?id=taro&pass=yamada
```
　　↓
```
[ 'id' => 'taro', 'pass' => 'yamda' ]
```
このように連想配列の形でまとめられたものをqueryの第1引数に指定すれば、それをバリデーションでチェックさせることができます。

##### ■第2引数
```
[
    'id' => 'required',
    'pass' => 'required',
]
```
第2引数には検証ルールの情報を配列にまとめたものを用意します。ここでは、クエリー文字列でidとpassというキーが渡されますから、それぞれにrequiredを設定しています。もちろん、その他のルールを設定してもまったく構いません。  
後は、$validator->failsをチェックして、表示するメッセージを設定するだけです。 「***チェックする項目と値を連想配列にしてValidator:makeに渡す***」という点さえわかれば、 どんな値でもバリデーションでチェックさせることが可能になります。

## エラーメッセージのカスタマイズ ##{#p7}
バリデータを作成して利用する場合、エラーメッセージのカスタマイズはどうすればよいのでしょうか。  
これは、実は**Validator::make**を呼び出す際に指定できます。以下のような形でメソッ ドを呼び出せばいいのです。
```
validator = Validator::maket 値の配列 , ルール配列 , メッセージ配列 );
```
第3引数に、エラーメッセージの配列を指定します。これは、フォームリクエストの messagesでreturnしたのと同じ形式のものを用意すればよいでしょう。  
では、これも試してみましょう。今回は、わかりやすいようにPOST送信されたとき の処理(postメソッド)にメッセージ表示を付け加えることにします。postメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト7</span>HelloController.php</p>
```
public function post(Request $request)
{
   $rules = [
       'name' => 'required',
       'mail' => 'email',
       'age' => 'numeric|between:0,150',
   ];
   $messages = [
       'name.required' => '名前は必ず入力して下さい。',
       'mail.email'  => 'メールアドレスが必要です。',
       'age.numeric' => '年齢を整数で記入下さい。',
       'age.between' => '年齢は０～150の間で入力下さい。',
   ];
   $validator = Validator::make($request->all(), $rules, $messages);
   if ($validator->fails()) {
       return redirect('/hello')
           ->withErrors($validator)
           ->withInput();
   }
   return view('hello.index', ['msg'=>'正しく入力されました！']);
}
```

![](validator_customize07.png?classes=caption "図 フォーム送信すると、日本語でエラーメッセージが表示されるようになった。")

修正したら、/helloにアクセスしてフォームを送信しましょう。今回は、ちゃんとエラーメッセージが日本語で表示されるようになっています。 ここでは、以下のようにしてエラーメッセージの情報を配列にまとめています。

```
$messages = [
    'name.required' => '名前は必ず入力して下さい。', 
    'mail.email' => 'メールアドレスが必要です。', 
    'age.numeric' => '年齢を整数で記入下さい。', 
    'age.between' => '年齢は0~150の間で入力下さい。',
]
```
この**$messages**を、Validator:makeを呼び出す際に第3引数に指定すれば、エラーメッセージが全て日本語に変わります。

## 条件に応じてルールを追加する ##{#p8}
検証ルールは、常に同じものが設定されるとは限りません。状況に応じて新たにルー ルを追加する、というようなことが必要となる場合もあるかも知れません。  
例えば、連絡先のラジオボタンに「メールアドレス」「電話番号」が用意されていて、その後のフィールドに連絡先の情報を記入する、というようなフォームを考えてみましょう。この場合、「メールアドレス」ボタンが選択されていれば、次のフィールドはメールアドレスでなければいけません。「電話番号」ボタンなら、電話番号になります。どちらが選択されているかによって、次のフィールドに設定すべきルールが変わってくるわけです。  
このように、必要に応じてルールを追加したい場合、Validatorクラスの「**sometimes**」 というメソッドを利用することができます。  
sometimesは、*処理を実行した結果によって新たにルールを追加する*ことができます。 これは以下のように記述します。
<p class="tmp"><span>書式3</span></p>
```
$validator->sometimes( 項目名 , ルール名 , クロージャ );
```
項目名とルール名はわかるでしょう。問題は、第3引数の**クロージャ**です。これが、ルー ルを追加すべきかどうかを決定するものです。このクロージャは、以下のような形をし ています。
<p class="tmp"><span>書式4</span></p>
```
function($input) {
    ......処理を実行...... 
    return 真偽値 ;
}
```
引数**$input**には、入力された値をまとめたものが渡されます。ここから、**$input->name**といった具合にしてフォームの値を取り出すことができます。  
戻り値は、ルールを追加すべきかどうかを指定する真偽値になります。trueの場合は 何もしませんが、falseの場合はsometimesで指定したルールを指定の項目に追加します。

### ルールの追加を行う
では、これも実際に試してみましょう。HelloControllerクラスのpostメソッドを以下 のように修正して下さい。
<p class="tmp list"><span>リスト8</span>HelloController.php</p>
```
public function post(Request $request)
{
   $rules = [
       'name' => 'required',
       'mail' => 'email',
       'age' => 'numeric',
   ];
   $messages = [
       'name.required' => '名前は必ず入力して下さい。',
       'mail.email'  => 'メールアドレスが必要です。',
       'age.numeric' => '年齢は整数で記入下さい。',
       'age.min' => '年齢はゼロ歳以上で記入下さい。',
       'age.max' => '年齢は200歳以下で記入下さい。',
   ];
   $validator = Validator::make($request->all(), $rules, $messages);

   $validator->sometimes('age', 'min:0', function($input){
       return !is_int($input->age);
   });
   $validator->sometimes('age', 'max:200', function($input){
       return !is_int($input->age);
   });

   if ($validator->fails()) {
       return redirect('/hello')
           ->withErrors($validator)
           ->withInput();
   }
   return view('hello.index', ['msg'=>'正しく入力されました！']);
}
```

![](validator_customize08.png?classes=caption "図  ageに整数値が入力されると、min、maxのルールが追加される。")

修正したらフォームを送信してみましょう。今回、修正したのはageのフィールドです。 ageには、「**'age' => 'numeric'**というルールだけが設定されています。が、整数の値が入力されていると、minとmaxのルールが追加され、0より小さい値や200より大きい値は エラーになります。  
では、例としてminルールを追加している処理を見てみましょう。このように記述されていますね。
```
$validator->sometimes('age', 'min:0', function($input){
	return !is_int($input->age); });
```
ここでは、第3引数のクロージャで、**!is_int(Sinput->age)**の値を返しています。これにより、Sinput->ageの値が整数の場合はfalseが返され、'min:0'のルールが'age'に追加されます。

## オリジナル・バリデータの作成 ##{#p9}
バリデーションは、用意されているルールを指定して各種の検証を行います。ルール の設定はいろいろなやり方で行えますが、ではこのルールそのものを新たに定義したい 場合はどうするのでしょう。  
これは、「バリデータ」そのものを作成し、そこで独自に処理を定義する方法が一番でしょう。バリデータは、Illuminate\Validation\Validatorクラスを継承したクラスとして作成します。このクラスを作り、その中にバリデーションの処理を行うメソッドを用意すれば、それがバリデーションのルールとして利用できるようになります。  
バリデーションクラスの基本形を整理すると以下のようになります。
<p class="tmp"><span>書式5</span></p>
```
use Illuminate\Validation\Validator;

class クラス名 extends Validator
{
    public function validate 〇〇 ($attribute, $value, $parameters)
    {
    ......バリデーションの処理...... 
    return 真偽値;
    }
}
```
バリデータは、Validatorクラスを継承して作成します。その中には、「validate○○」 という名前のメソッドを用意します。これが、バリデーションで使われるルールとして 認識されます。例えば、「validateAbc」という名前でメソッドを用意すれば、それは 'abc' というルールとして扱われるようになるのです。  
検証用のメソッドには、3つの引数が用意されます。第1引数は属性(設定したコントロール名など)、第2引数にチェックする値、そして第3引数にはルールに渡されるパラメータとなります。  
これらの値を元にバリデーションの処理を行い、真偽値を返します。falseを返せばバリデーション時にエラーが発生したことを示します。trueの場合は問題ないことを示し ます。

## Hello Validatorを作成する ##{#p10}
では、実際に簡単なバリデータクラスを作成してみましょう。バリデータクラスには、 コードを生成する機能などは特にありません。したがって、手作業でスクリプトファイルを作成していく必要があります。  
ここでは、「**Http**」フォルダ内に、新たに「**Validators**」というフォルダを作成し、その中にスクリプトを用意することにしましょう。バリデータのファイル名は「**HelloValidator.php**」という名前にしておきます。 ファイルを作成したら、以下のようにスクリプトを記述して下さい。

<p class="tmp list"><span>リスト9</span>HelloValidator.php</p>
```
<?php
namespace App\Http\Validators;

use Illuminate\Validation\Validator;

class HelloValidator extends Validator
{
   public function validateHello($attribute, $value, $parameters)
   {
       return $value % 2 == 0;
   }

}
```

今回は、「HelloValidator」という名前でクラスを作成しています。この中には、 「validateHello」というメソッドを用意してあります。これは、'hello' という名前のルールを定義するものです。  
ここでは、$value % 2 == 0 の値を返しています。すなわち、入力された値が偶数なら許可、奇数なら不許可となるバリデーションルールです。ごく単純なものですから、 内容は説明するまでもないでしょう。

### HelloValidator を組み込む
では、作成したHelloValidatorを組み込みましょう。これには、サービスプロバイダを 利用します。  
以前、「HelloServiceProvider」というサービスプロバイダを作成しましたので、これを再利用しましょう。「providers」フォルダの中のHelloServiceProvider.phpを開き、その中にあるbootメソッドを以下のように書き換えて下さい。

<p class="tmp list"><span>リスト10</span>providers/HelloServiceProvider.php</p>
```
// use Validator;　追加する
// use App\Http\Validators\HelloValidator;　追加する

public function boot()
{
   $validator = $this->app['validator'];
   $validator->resolver(function($translator, $data, 
          $rules, $messages) {
       return new HelloValidator($translator, $data, 
             $rules, $messages);
   });
}
```

バリデータは、$this->app['validator']というところに保管されています。この resolverというメソッドで、リゾルブ(バリデーションの処理を行う)の処理を設定できます。引数には、以下のようなクロージャを指定します。

```
function($translator, $data, $rules, $messages) {
	return (Validator);
```
この関数では、Validatorのインスタンスをreturnします。ここでは、HelloValidatorクラスのインスタンスをreturnすることで、このクラスをバリデーションの処理として設定しています。new HelloValidatorの引数には、resolverで渡された4つの引数をそのまま指定します。  
これで、HelloValidatorのメソッドがバリデーションの検証ルールとして追加されました。後は、追加したルールを実際に利用してみるだけです。

## HelloValidatorのルールを使用する ##{#p11}
では、HelloControllerクラスのpostメソッドを書き換えて、ageフィールドに HelloValidatorのvalidateHelloメソッドのルール(ルール名は" hello)を組み込んでみましょう。  
今回は、HelloRequestを利用することにしましょう。HelloRequestクラスを以下のように修正して下さい。

<p class="tmp list"><span>リスト11</span>HelloRequest.php</p>
```
class HelloRequest extends FormRequest
{
   public function authorize()
   {
       if ($this->path() ==  'hello')
       {
           return true;
       } else {
           return false;
       }
   }

   public function rules()
   {
       return [
           'name' => 'required',
           'mail' => 'email',
           'age' => 'numeric|hello',
       ];
   }

   public function messages()
   {
       return [
           'name.required' => '名前は必ず入力して下さい。',
           'mail.email'  => 'メールアドレスが必要です。',
           'age.numeric' => '年齢を整数で記入下さい。',
           'age.hello' => 'Hello! 入力は偶数のみ受け付けます。',
       ];
   }

}
```
age に 'numerichello' という形で検証ルールを設定しました。このhelloは、 HelloValidatorに用意したvalidateHelloメソッドで処理されるルールです。エラーメッセージは、age.helloを指定して設定しています。標準で用意されているルールと使い方 はまったく同じです。  
では、コントローラを修正しましょう。HelloControllerクラスを以下のように変更して下さい。

<p class="tmp list"><span>リスト12</span>HelloController.php</p>
```
class HelloController extends Controller
{
  
   public function index(Request $request)
   {
       return view('hello.index', ['msg'=>'フォームを入力下さい。']);
   }

   public function post(HelloRequest $request)
   {
       return view('hello.index', ['msg'=>'正しく入力されました！']);
   }

}
```

![](validator_customize09.png?classes=caption "図 奇数をageに入力すると、「Hello! 入力は偶数のみ受け付けます」と表示される。")

修正したらフォームを使って動作を確認しましょう。ageの入力数字が奇数だと、「Hello! 入力は偶数のみ受け付けます」とエラーメッセージが表示されます。  
このように、オリジナルの検証ルールをValiadtorクラスで作成して組み込めば、入力のチェックを拡張していくことができます。

## Validator::extendを利用する ##{#p12}
独自のバリデータクラスを定義して組み込むのは、きちんとしたバリデータ処理を作成して汎用的に使えるようにする場合は有効なやり方です。が、「このフォームでだけ、 ちょっとカスタマイズしたルールを使いたい」というような場合は、もっと簡単な方法があります。それは、Validatorクラスの「**extend**」メソッドを利用するのです。 これは、以下のような形で実行します。
<p class="tmp"><span>書式6</span></p>
```
Validator::extend(名前クロージャ );
```
これで、第1引数に指定した名前で第2引数のクロージャをルールとして追加します。 第2引数の関数は、以下のような形で定義します。
<p class="tmp"><span>書式7</span></p>
```
function($attribute, $value, $parameters, $validator) {
    ......パリデーションの処理...... 
    return 真偽値;
}
```
引数には、先にバリデータクラスを作成したときに定義したメソッドの引数 ($attribute, $value, $parameters)に、更にバリデータのインスタンスを付け加えた4つの値が用意されます。これらを使って処理を行い、最後にtrueを返せば問題なし、false を返せばエラーが発生したことを示します。  
例えば、先ほどのHelloValidatorのvalidateHelloの処理を、Validator::extendを使って記述するとどうなるかやってみましょう。HelloServiceProviderクラスのbootメソッドを 以下のように書き換えて下さい。

<p class="tmp list"><span>リスト13</span>HelloServiceProvider.php</p>
```
public function boot()
{
   Validator::extend('hello', function($attribute, $value,
           $parameters, $validator) {
       return $value % 2 == 0;
   });
}
```
これで、'hello'というルール名が追加されました。基本的な働きは、HelloValidatorを 使った場合とまったく同じです。  
Validator::extendを使ったやり方は非常に手軽ですが、汎用性は、あまりありません。 1つのコントローラだけでしか使わないようなルールはこれで作り、いくつものコントローラで利用するような場合はバリデータクラスを作って組み込む、というように使い分けるとよいでしょう。











