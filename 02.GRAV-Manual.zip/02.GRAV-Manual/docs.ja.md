---
title: GRAV取説
media_order: wheelchair.png
taxonomy:
    category:
        - docs
visible: true
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:12px 0 12px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
    ol li a {color:#555; text-decoration: underline;}
</style>

## 目次

1. [GRAVについて](infomation)
1. [最初からGRAV本体を設置する](grav_core)
1. [テンプレートからGRAVを設置](start)
1. [スタイル設定について](style-01)
1. [フォルダやページの追加/削除](operation)
1. [マークダウン記法について](markdown-00)
1. [プラグイン](plugin)


