<?php
	//配列を作成
	$fruits_array = ['apple'=>'fruits1',
					 'orange'=>'fruits2',
					 'melon'=>'fruits3',
					 'pineapple'=>'fruits4'
					];

	//配列をJSON形式に変換
	$jsonstr =  json_encode($fruits_array);

	echo $jsonstr;
?>