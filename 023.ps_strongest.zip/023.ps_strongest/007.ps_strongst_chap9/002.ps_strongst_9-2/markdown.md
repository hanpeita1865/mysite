*[page-title]:9-2. ペンツールの使い方

## ペンツールで直線による閉じた図形を描こう ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-02-1.jpg)](upload/9-02-1.jpg){.image}
</div>

## ペンツールで曲線を描こう ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-02-2.jpg)](upload/9-02-2.jpg){.image}
</div>

## 曲線から直線を描く ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-02-3.jpg)](upload/9-02-3.jpg){.image}
</div>

## 直線から曲線を描く ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-02-4.jpg)](upload/9-02-4.jpg){.image}
</div>

## 曲線ペンツールでパスやシェイプを描こう ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-02-5.jpg)](upload/9-02-5.jpg){.image}
</div>

## フリーハンドでパス・シェイプを描こう ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-02-6.jpg)](upload/9-02-6.jpg){.image}
</div>

