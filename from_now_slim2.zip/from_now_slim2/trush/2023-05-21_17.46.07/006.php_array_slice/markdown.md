*[page-title]:配列を切り取る（array_slice）

## 配列を切り取る（array_slice）

<p class="tmp"><span>書式4</span>array_slice()</p>
```
array_slice($array, $offset [,$length = NULL [,$preserve_keys = false]]);
```
※[]内は省略可能な引数

|<div style="width:5rem"> </div>|<div style="width:9rem"> </div>|	|
|:--:|:--:|:--|
|第一引数	|array(必須)	|処理を行う配列です。|
|第二引数	|offset(必須)	|切り取る配列の0から数えた開始位置です。0を選んだ場合、先頭から切り取ります。-2など負数の場合は、配列の最後から数えた位置になります。|
|第三引数	|length(任意)	|切り取る件数を指定します。初期値はNULLで、省略した場合、offsetで選んだ位置から末尾まですべての要素を返します。負数の場合は、配列の末尾から数えた位置まで取得します。(0から数えないので注意)|
|第四引数	|preserve_keys(任意)	|取得した配列のキーを0からの連番にするか、元のキーを参照するかを指定します。デフォルトはfalseで、元のキーは破棄され連番となります。|


<div class="exp">
	<p class="tmp"><span>例</span>先頭から5件の配列を取得する</p>
</div>
<iframe src="https://paiza.io/projects/e/X3-Q8PNvOw2JEvItHDiM7Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


<div class="exp">
	<p class="tmp"><span>例</span>0から数えて4つ目の位置から、2件の配列を取得する</p>
</div>
<iframe src="https://paiza.io/projects/e/vLRKnXVVw9K_Ft0pX7Ehfg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<div class="exp">
	<p class="tmp"><span>例</span>0から数えて3つ目の位置から、末尾までの配列を取得する</p>
</div>
<iframe src="https://paiza.io/projects/e/5ty8TltMzJYnITBMTbuuvQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


<div class="exp">
	<p class="tmp"><span>例</span>0から数えて5つ目の位置から、3件の配列を取得し、元のキーを維持する</p>
</div>

<iframe src="https://paiza.io/projects/e/0OK4IBMX5PD8oEeJkCZrTA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

