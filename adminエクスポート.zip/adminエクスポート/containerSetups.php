<?php

use DI\Container;
use Slim\Factory\AppFactory;
use Slim\Views\Twig;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Formatter\LineFormatter; // <-- LineFormatterを使う

require 'admin/basepath.php';

$container = new Container();



//-------------------//
// 　　 共 通        //
//------------------//

$container->set(
    "view",
    function () {
        global $basePath;
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"] . $basePath . "/templates");
        return $twig;
    }
);

$container->set(
    "logger",
    function () {
        global $basePath;

        // $logger = new Logger("slimmiddle");
        // $fileHandler = new StreamHandler($_SERVER["DOCUMENT_ROOT"].$basePath."/logs/app.log");
        // $logger->pushHandler($fileHandler);

        //日本時間にセット
        date_default_timezone_set('Asia/Tokyo');

        $logger = new Logger('logger');
        $custom_handler = new StreamHandler($_SERVER["DOCUMENT_ROOT"] . $basePath . "/logs/app.log", Logger::INFO);

        // 時間表示のフォーマット設定
        $date_format = 'Y-n-d H:i:s';

        // ログのフォーマットを設定
        $format = '[%datetime%] %level_name%: %message%' . PHP_EOL;

        // 第三引数は「ログ内のインライン改行を有効にするかどうか」の設定
        // 今回は意味は無いが、有効にしておいた方が使いやすいのでtrueに
        $formatter = new LineFormatter($format, $date_format, true);

        $custom_handler->setFormatter($formatter);

        $logger->pushHandler($custom_handler);
        return $logger;
    }
);

//PDOインスタンスを生成する処理
$container->set(
    "db",
    function () {
        //DB接続情報を表す変数
        $database = 'from_now';
        $dbUsername = "staff";
        $dbPassword = "password";

        //PDOインスタンスを生成。DB接続
        $db = new PDO('mysql:host=localhost:3306;dbname=' . $database . ';charset=utf8', $dbUsername, $dbPassword); //MySQLに接続

        //PDOエラー表示モードを例外モードに設定
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //プリペアドステートメントを有効に設定
        $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        //フェッチモードをカラム名のみの結果セットに設定
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        //PDOインスタンスをリターン
        return $db;
    }
);


$folderObj = []; //ディレクトリ格納用オブジェクト
$folderArray = []; //ページディレクトリ配列

//フォルダ構成をセット
$container->set(
    "folderComp",
    function () {
        global $folderObj;
        globAll('../pages');
        return $folderObj;
    }
);





//-------------------//
// 　  ページ用      //
//-----------------//


//マークダウン変換
$container->set(
    "mark",
    function () {
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        global $basePath;
        global $folderObj;
        global $folderName;

        if (!empty($folderObj[$folderName])) {

            $folderPath = $folderObj[$folderName];
            $folderPath1 = str_replace('..', '', $folderPath); //「..」を削除　例)/pages/001.js/001.js_base/002.js_cls_obj_lecture

            $Extra = new ParsedownExtra();

            //マークダウンファイル取得
            $md = file_get_contents($_SERVER["DOCUMENT_ROOT"] . $basePath . '/pages/' . $folderPath . '/markdown.md');


            //ページタイトル取得
            preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
            $title = $ArrayTitle[1]; //ページタイトル

            //HTMLに変換
            $htmlData = $Extra->text($md);

            //画像のパスを変換
            $htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);
            //ファイルリンクのパスを変換
            $htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);

            //sampleのパスを変換
            $htmlData = preg_replace('/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="' . $basePath . $folderPath1 . '/sample/$2" target="_blank">$4</a>', $htmlData);

            //iframeのパスを変換
            $htmlData = preg_replace('/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i', '<iframe$1src="' . $basePath . $folderPath1 . '/sample/$2"$3></iframe>', $htmlData);

            $markArray = ['html' => $htmlData, 'title' => $title];
        } else {
            $markArray = ['html' => 'ページが存在しません。', 'title' => ''];
        }
        return $markArray;
    }
);


//メニュー生成
$boxNum = 1;
$container->set(
    "menuComp",
    function () {
        global $menuCode;
        global $lockData;
        global $db;
        global $countIp;
        global $folderName;
        global $lockArray;
        global $onlyArray;//追加

        globMenu('../pages');

        return $menuCode;
    }
);


//メニュー生成　管理画面用
$container->set(
    "menuCompAdmin",
    function () {
        global $menuCode;
        global $lockData;
        global $db;
        global $countIp;
        global $folderName;
        global $lockArray;

        $stmt = $db->prepare('select page, under_dir from locklist');
        $stmt->execute();
        $lockData = $stmt -> fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_GROUP);

        globMenu('../pages');

        return $menuCode;
    }
);



//プレビュー用
$container->set(
    "preview",
    function () {
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        $Extra = new ParsedownExtra();

        global $basePath;
        global $folderObj;


        $md = $_REQUEST['report-p']; //記事原文
        $title = $_REQUEST['pagename-p']; //タイトル
        $folderPath = $_REQUEST['folderPath-p']; //パス
        $folderName = $_REQUEST['folder-p']; //フォルダ名

        $folderPath = $folderObj[$folderName];
        $folderPath1 = str_replace('..', '', $folderPath);

        $htmlData = $Extra->text($md);

        //画像のパスを変換
        $htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);
        //ファイルリンクのパスを変換
        $htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);

        //sampleのパスを変換
        $htmlData = preg_replace('/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="' . $basePath . $folderPath1 . '/sample/$2" target="_blank">$4</a>', $htmlData);

        //iframeのパスを変換
        $htmlData = preg_replace('/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i', '<iframe$1src="' . $basePath . $folderPath1 . '/sample/$2"$3></iframe>', $htmlData);


        $markArray = ['html' => $htmlData, 'title' => $title];

        return $markArray;
    }
);


//ファイルアイコン設定（テスト）
$container->set(
    "fileIcon",
    function () {
        //更新日付順表示
        $sort_by_lastmod = function ($a, $b) {
            return  filemtime($a) - filemtime($b);
        };

        //フォルダ構成をオブジェクトで取得
        // $folderObj = $this->container->get("folderComp");

        $folderObj = fileGlobe();
        $folderDir = $folderObj[$_REQUEST['folder']];
        $totalList = '';

        $files = glob($folderDir . '/upload/*');
        usort($files, $sort_by_lastmod);

        if (empty($files)) {
            $fileList = '';
        } else {
            foreach ($files as $item) {
                $file_name = basename($item); //ファイル名だけを抜き出す
                $fileClass = '';
                $photo = false;

                switch (1) {
                        //エクセル
                    case preg_match('/.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/', $file_name):
                        $fileClass = 'file_icon excel-icon';
                        break;
                        //テキスト
                    case preg_match('/.txt$/', $file_name):
                        $fileClass = 'file_icon text-icon';
                        break;
                        //ワード
                    case preg_match('/.doc$|.docm$|.docx$|.dot$|.dotx$/', $file_name):
                        $fileClass = 'file_icon word-icon';
                        break;
                        //パワーポイント
                    case preg_match('/.pptx$/', $file_name):
                        $fileClass = 'file_icon pptx-icon';
                        break;
                        //zipファイル
                    case preg_match('/.zip$/', $file_name):
                        $fileClass = 'file_icon zip-icon';
                        break;
                        //PDFファイル
                    case preg_match('/.pdf$/', $file_name):
                        $fileClass = 'file_icon pdf-icon';
                        break;
                        //画像
                    case preg_match('/.png$|.PNG$|.jpg$|.jpeg$|.JPG$|.JPEG$|..svg$|.svgz$|.gif$|.webp$/', $file_name):
                        $fileClass = 'file_icon pdf-icon';
                        $photo = true;
                        break;
                }

                if (!$photo == true) {
                    $fileList = '<li class="file-list"><span class="filename ' . $fileClass . '">' . $file_name . '</span><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                } else {
                    $fileList = '<li class="photo-list"><span class="filename">' . $file_name . '</span><img src="' . $folderDir . '/upload/' . $file_name . '" alt=""><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                }

                $totalList = $totalList . $fileList;
            }
        }

        // return $fileList;
        return $totalList;
    }
);




//-------------------//
// 　  管理画面用    //
//-----------------//

//フォルダオブジェクト取得
$container->set(
    "folderObjGet",
    function () {
        $folderObj = fileGlobe();
        return $folderObj;
    }
);


//対象フォルダを中身ごとまとめて削除
$container->set(
    "del_allfolder",
    function () {
        global $delFolder;

        //trushにバックアップ
        trush_backup($delFolder);
        //フォルダ中身ごと削除
        remove_directory($delFolder);

        $delAry = explode('/', $delFolder);// 「/」で区切って配列化
        array_pop($delAry);
        $parent = implode('/', $delAry);//例) ../pages
        numberReset($parent);//番号を再設定
    }
);


//pagesバックアップ
$container->set(
    "pages_backup",
    function () {
        copy_pages('../pages');
    }
);



//中のページのフォルダを上の階層に移動する
$container->set(
    "subpage_move",
    function () {
        global $delFolder;//例)../pages/042.aaa
        $delAry = explode('/', $delFolder);// 「/」で区切って配列化
        $delFd = end($delAry);//例)042.aaa　配列の最後の値を取得
        $num = explode('.', $delFd)[0];//例)042

        array_pop($delAry);//配列の最後の要素（例 042.aaa）を削除
        $parent = implode('/', $delAry);//配列を「/」で結合　例) ../pages

        move_sabpages($delFolder, $delFd, $num, $parent);
    }
);




//フォルダのリスト生成
$container->set(
    "folderList",
    function () {
        global $folderList;
        globList('../pages');
        return $folderList;
    }
);


//フラットなフォルダ構成作成
$container->set(
    "frat_create",
    function () {
        global $folder;
        global $sourcePath;

        globFlat($sourcePath, '../pages_copy/');
        return $folder;
    }
);


//フォルダ構成再生成
$container->set(
    "create",
    function () {
        global $folder;
        globAllRe('../pages_copy');
        return $folder;
    }
);


//フラットなフォルダ構成作成
$container->set(
    "frat_create_test",
    function () {
        global $sourcePath;
        global $res_merge;
        global $sourceDir;

        foreach($res_merge as $sourceDir){
            globFlat_test($sourceDir , '../pages_copy/');
        }
    }
);



//-------------------//
// 　    関 数       //
//-----------------//

function globAll($folder)
{
    global $folderObj;
    global $folderArray;

    if (!is_file($folder)) {
        $res = glob($folder . '/*');

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {
                $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
                $folderObj[$folderNoNum] = $f; //「〇〇.」ディレクトリをオブジェクトに格納
                $folderArray[] = $f; //ページフォルダのディレクトリを配列に格納

                globAll($f);
            }
        }
    }
}



//メニュー生成関数
function globMenu($folder)
{
    global $basePath;
    global $menuCode;
    global $boxNum;
    // global $lockData;
    global $countIp;
    global $folderName;
    // global $lockArray;
    // global $onlyArray;//追加


    if (!is_file($folder)) {
        $res = glob($folder . '/*');

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {

                $path = str_replace('../pages/', '', $f) . '/'; //リストのパス
                $pathRe = preg_replace('/^\d{3}./', '', $path);
                $pathRe = preg_replace('/\/\d{3}./', '/', $pathRe);


                if (file_exists($f . '/data.json')) {
                    //社員用
                    $json = file_get_contents($f . '/data.json'); 
                    $data = json_decode($json, true);
                    $title = $data['name'];

                    if(isset($data['photo'])){
                        $photoPath = $basePath.'/pages/'.$path.'upload/'.$data['photo'];
                    }else{
                        $photoPath = $basePath.'/images/staff_dummy.jpg';
                    }

                    $lastDir = preg_replace('/^\d{3}./', '', $lastDir);
                    // $menuCode = $menuCode . '<li id="item'.$boxNum.'" class="box-item"><a href="'.$basePath.'/public/pages/'.$pathRe.'">'.$title.'</a><img src="/from_now_admin/images/staff_dummy.jpg" class="staff-photo">';   

                    $menuCode = $menuCode . '<li id="item'.$boxNum.'" class="box-item"><a href="'.$basePath.'/public/pages/'.$pathRe.'">'.$title.'</a><img src="'.$photoPath.'" class="staff-photo">';                 
            
                    $boxNum = $boxNum + 1;

                }else{
                    //グループ・チーム用
                    $json = file_get_contents($f . '/box.json'); 
                    $data = json_decode($json, true);
                    $title = $data['name'];

                    $lastDir = preg_replace('/^\d{3}./', '', $lastDir);
                    $menuCode = $menuCode . '<li id="item' . $boxNum . '" class="box-item"><a href="' . $basePath . '/public/pages/' . $pathRe . '">' . $title . '</a>';                 
                    $boxNum = $boxNum + 1;                    
                }

                //ディレクトリ($f)内に「〇〇〇.フォルダ」があるか判定
                $res1 = glob($f . '/*');
                $pBool = false;
                foreach ($res1 as $f1) {
                    $dirArray1 = explode('/', $f1);
                    $lastDir1 = end($dirArray1);
                    if (preg_match('/^\d{3}./', $lastDir1)) {
                        $pBool = true;
                    }
                }

                if ($pBool) {
                    $menuCode = $menuCode . "\r\n" . '<ul class="sub-menu">' . "\r\n";
                }

                globMenu($f);

                if ($pBool) {
                    $menuCode = $menuCode . '</ul>' . "\r\n";
                }

                $menuCode = $menuCode . '</li>' . "\r\n";
            }
        }
    }
}


//フォルダのリスト生成
function globList($folder)
{
    global $folderList;
    $res = glob($folder . '/*');

    foreach ($res as $key => $f) {
        $dirArray = explode('/', $f);
        $lastDir = end($dirArray); //配列の最後の値

        //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
        if (preg_match('/^\d{3}./', $lastDir)) {
            $folderList = $folderList . '<li>' . $lastDir . '</li>';
            globList($f);
        }
    }
}





//フラットなフォルダ構成作成
function globFlat($folder, $copyFolder)
{
    //「pages」フォルダが存在するか判定
    if (!is_file($folder)) {

        $res = glob($folder . '/*'); //「/」があるディレクトリを配列に格納

        foreach ($res as $f) {
            $dirArray = explode('/', $f); //「/」で分割して配列化
            $lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {

                //フォルダ直下に「markdown.md」がある
                if (file_exists($f . '/markdown.md')) {
                    $md = file_get_contents($f . '/markdown.md'); //マークダウンの内容を変数に格納
                    preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle); //ページ名を取得
                }

                //移動
                $path1 = $f;
                $path2 = $copyFolder. $lastDir;

                //ディレクトリ($f)内に〇〇.フォルダがあるか判定
                $res1 = glob($f . '/*');

                $numBool = false;
                foreach ($res1 as $f1) {
                    $dirArray1 = explode('/', $f1);
                    $lastDir1 = end($dirArray1);
                    if (preg_match('/^\d{3}./', $lastDir1)) { //フォルダ名に〇〇.が先頭に付いてるか判定
                        $numBool = true;
                    }
                }

                if (!$numBool) {
                    //フォルダ内に〇〇.フォルダがない → pages_copyフォルダに移動
                    if (file_exists($path1)) {
                        // echo $path1."\n";
                        // echo $path2."\n";
                        // echo $folder."\n";
                        if (rename($path1, $path2)) {
                            // echo "OK";
                            globFlat($folder,$copyFolder);
                        } else {
                            // echo "移動エラー";
                        }
                    }
                } else {
                    //フォルダ内に〇〇.フォルダがある → 再帰処理
                    globFlat($f, $copyFolder);
                }
            }
        }
    }
}



//フォルダ構成再生成
function globAllRe($folder)
{

    $menuArray = json_decode($_POST['list']); //メニューのリスト構成

    if (!is_file($folder)) {
        $res = glob($folder . '/*');

        foreach ($menuArray as $item) {
            $listExplode = explode('/', $item);
            $lastList = end($listExplode);

            //メニューのフォルダ名を抽出
            list($listNum, $listName) = explode(".", $lastList);

            //メニューと一致したpages_copy内のフォルダ名取得
            foreach ($res as $key => $f) {
                $dirArray = explode('/', $f);
                $lastDir = end($dirArray); //配列の最後の値

                //番号を取ってフォルダ名のみを抽出（pages_copy内）
                list($dirNum, $dirName) = explode(".", $lastDir);

                if ($dirName == $listName) {
                    //フォルダをpages_copyからpagesに移動
                    if (rename($f, '../pages/' . $item)) {
                        //echo "OK";
                        // echo $key;
                    } else {
                        //echo "エラー";
                    }
                    break;
                }
            }
        }
    }
}




//削除フォルダをtrushにバックアップ
function trush_backup($delFolder) {
    global $dateTime;

    date_default_timezone_set('Asia/Tokyo');//日本時間にセット
    $dateTime = date('Y-m-d_H.i.s');

    mkdir('../trush/'.$dateTime);//削除日時フォルダをtrushフォルダに作成

    $delDir = str_replace('pages', 'trush/'.$dateTime, $delFolder);
    mkdir($delDir);
    copy_directory($delFolder, $dateTime);
}




// 再帰的にディレクトリを削除する関数
function remove_directory($dir) {
    $files = array_diff(scandir($dir), array('.','..'));
    foreach ($files as $file) {
        // ファイルかディレクトリによって処理を分ける
        if (is_dir("$dir/$file")) {
            // 頭に数字のないディレクトリなら再度同じ関数を呼び出す
            remove_directory("$dir/$file");
        } else {
            // ファイルなら削除
            unlink("$dir/$file");
        }
    }
    // 指定したディレクトリを削除→中身が空になって最後に実行される
    return rmdir($dir);
}


//再帰的にディレクトリをtrushにコピーする関数（中のディレクトリも一括して）　テスト
function copy_directory($ptn,$dateTime) {

    // 指定されたディレクトリ内の一覧を取得
    $res = glob($ptn.'/*');

    // 一覧をループ
    foreach ($res as $f) {
        //is_file() を使ってファイルかどうかを判定
        $fcopy = str_replace('pages','trush/'.$dateTime, $f);

        //ファイルか判定
        if (!is_file($f)) {
            if(!file_exists($fcopy)){
                mkdir($fcopy);
            }
            copy_directory($f,$dateTime);
        }else{
            //ファイルの場合、コピー
            copy($f,$fcopy);
        }
    }
}




// 再帰的にディレクトリをtrushに移動する関数 テスト
function move_trush($folder, $copyFolder)
{
    $res = glob($folder . '/*'); //「/」があるディレクトリを配列に格納
    $files = array_diff(scandir($folder), array('.','..'));

    foreach ($res as $f) {
        $dirArray = explode('/', $f); //「/」で分割して配列化
        $lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）

        //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
        if (preg_match('/^\d{3}./', $lastDir)) {

            //フォルダ直下に「markdown.md」がある
            // if (file_exists($f . '/markdown.md')) {
                // $md = file_get_contents($f . '/markdown.md'); //マークダウンの内容を変数に格納
                // preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle); //ページ名を取得
            // }

            //移動
            $path1 = $f;
            $path2 = $copyFolder. $lastDir;

            //ディレクトリ($f)内に〇〇.フォルダがあるか判定
            $res1 = glob($f . '/*');

            $numBool = false;
            foreach ($res1 as $f1) {
                $dirArray1 = explode('/', $f1);
                $lastDir1 = end($dirArray1);
                if (preg_match('/^\d{3}./', $lastDir1)) { //フォルダ名に〇〇.が先頭に付いてるか判定
                    $numBool = true;
                }
            }

            if (!$numBool) {
                //フォルダ内に〇〇.フォルダがない → trushフォルダに移動
                if (file_exists($path1)) {
                    // echo $path1."\n";
                    // echo $path2."\n";
                    if (rename($path1, $path2)) {
                        // echo "OK";
                        move_trush($folder, $copyFolder);
                    } else {
                        // echo "移動エラー";
                    }
                }
            } else {
                //フォルダ内に〇〇.フォルダがある → 再帰処理
                move_trush($f, $copyFolder);
            }
        }
    }
}



//再帰的にpagesをtempにコピーする関数
function copy_pages($ptn) {
    // 指定されたディレクトリ内の一覧を取得
    $res = glob($ptn.'/*');

    // 一覧をループ
    foreach ($res as $f) {
        $fcopy = str_replace('pages','temp', $f);

        //ファイルか判定
        if (!is_file($f)) {
            if(!file_exists($fcopy)){
                mkdir($fcopy);
            }
            copy_pages($f,'temp');
        }else{
            //ファイルの場合、コピー
            copy($f,$fcopy);
        }
    }
}



//中の番号付きのフォルダを上の階層に移動して、番号を再設定。
function move_sabpages($delDir, $delFd, $num, $parent){
    $res = glob($delDir.'/*');
    $subNum = 1;

    foreach ($res as $f) {
        $dirArray = explode('/', $f); //「/」で分割して配列化
        $lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）例)001.bbb、markdown.md

        //配列の最後の頭の値が数字「〇〇.」の場合
        if (preg_match('/^\d{3}./', $lastDir)) {

            $path1 = $f;
            $path2 = preg_replace('/'.$delFd.'\/\d{3}./', $num.'-'.$subNum.'.', $f);

            //上の階層に移動
            if (rename($path1, $path2)) {
                // echo "OK";
            } else {
                // echo "移動エラー";
            }
        }

        $subNum++;
    }

    //対象フォルダをtrushにバックアップ
    trush_backup($delDir);
    //対象のフォルダを削除
    remove_directory($delDir);
    //フォルダ番号再設定
    numberReset($parent);
}

//フォルダ番号再設定関数
function numberReset($parent){

    $parentAry = glob($parent.'/*');//削除するフォルダの同じ階層のフォルダらを配列化

    $num = 1;

    foreach($parentAry as $val){
        $valAry = explode('/', $val);
        $lastData = end($valAry);

        if (preg_match('/^\d{3}./', $lastData)) {
            $name = explode('.',$lastData)[1];//番号を除いた名前
            $fdNum = $num;//1から順番の数字を格納
            $fdNum = sprintf('%03d', $fdNum);//3桁に変換
            $fdName = $fdNum.'.'.$name;
        
            array_pop($valAry);//最後の配列要素を削除
            array_push($valAry, $fdName);//新しいフォルダ名を追加
            $newDir = implode('/', $valAry);//ディレクトリ作成
            rename($val, $newDir);//フォルダ名を変更（番号部分だけ）
            $num++;
        }
    }  
}




//フラットなフォルダ構成作成 差分のみ式用 テスト
function globFlatSabun($folder, $copyFolder)
{
    //「pages」フォルダが存在するか判定
    if (!is_file($folder)) {

        $res = glob($folder . '/*'); //「/」があるディレクトリを配列に格納

        foreach ($res as $f) {
            $dirArray = explode('/', $f); //「/」で分割して配列化
            $lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {

                //フォルダ直下に「markdown.md」がある
                if (file_exists($f . '/markdown.md')) {
                    $md = file_get_contents($f . '/markdown.md'); //マークダウンの内容を変数に格納
                    preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle); //ページ名を取得
                }

                //移動
                $path1 = $f;
                $path2 = $copyFolder. $lastDir;

                //ディレクトリ($f)内に〇〇.フォルダがあるか判定
                $res1 = glob($f . '/*');

                $numBool = false;
                foreach ($res1 as $f1) {
                    $dirArray1 = explode('/', $f1);
                    $lastDir1 = end($dirArray1);
                    if (preg_match('/^\d{3}./', $lastDir1)) { //フォルダ名に〇〇.が先頭に付いてるか判定
                        $numBool = true;
                    }
                }

                if (!$numBool) {
                    //フォルダ内に〇〇.フォルダがない → pages_copyフォルダに移動
                    if (file_exists($path1)) {
                        // echo $path1."\n";
                        // echo $path2."\n";
                        if (rename($path1, $path2)) {
                            // echo "OK";
                            globFlat($folder,$copyFolder);
                        } else {
                            // echo "移動エラー";
                        }
                    }
                } else {
                    //フォルダ内に〇〇.フォルダがある → 再帰処理
                    globFlat($f, $copyFolder);
                }
            }
        }
    }
}






//フォルダ構成再生成（差分のみ移動したpages_copyのフォルダをpagesへ戻す）テスト
function globRe_sabun($sabunMenu)
{

    // $menuArray = json_decode($_POST['list']); //メニューのリスト構成
    $folder = '../pages_copy';

    if (!is_file($folder)) {
        $res = glob($folder . '/*');//pages_copy内のディレクトリ配列化

        foreach ($sabunMenu as $item) {
            $listExplode = explode('/', $item);
            $lastList = end($listExplode);

            //メニューのフォルダ名を抽出
            list($listNum, $listName) = explode(".", $lastList);

            //メニューと一致したpages_copy内のフォルダ名取得
            foreach ($res as $key => $f) {
                $dirArray = explode('/', $f);
                $lastDir = end($dirArray); //配列の最後の値

                //番号を取ってフォルダ名のみを抽出（pages_copy内）
                list($dirNum, $dirName) = explode(".", $lastDir);

                if ($dirName == $listName) {
                    //フォルダをpages_copyからpagesに移動
                    if (rename($f, '../pages/' . $item)) {
                        //echo "OK";
                        // echo $key;
                    } else {
                        //echo "エラー";
                    }
                    break;
                }
            }
        }
    }
}





function globFlat_test($folder, $copyFolder){
	
	global $sourcePath;
    global $sourceDir;

	//指定したフォルダが存在するか判定
	if (file_exists($folder)) {

		$lists = glob($folder . '/[0-9][0-9][0-9].*'); //直下の「〇〇〇.」のフォルダのみ抽出

		if(!empty(($lists))){
			foreach ($lists as $f) {
				$checkList = glob($f . '/[0-9][0-9][0-9].*');
				//フォルダ内に〇〇.フォルダがない → pages_copyフォルダに移動
				if(empty($checkList)){
					$dirArray = explode('/', $f); //「/」で分割して配列化
					$lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）
					$path2 = $copyFolder.$lastDir;//「pages_copy/フォルダ名」

					if (file_exists($f)) {
						if (rename($f, $path2)) {
							// echo "OK";
							globFlat_test($folder,$copyFolder);
						} else {
							// echo "移動エラー";
						}
					}
	
				} else {
					//フォルダ内に〇〇.フォルダがある → 再帰処理
					globFlat_test($f, $copyFolder);
				}
			}

		}else{
			$dirArray = explode('/', $folder); //「/」で分割して配列化
			$lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）
			$path2 = $copyFolder.$lastDir;//「pages_copy/フォルダ名」

            if (rename($folder, $path2)) {
				// echo "OK";
				array_pop($dirArray);//配列の最後のフォルダ名削除

				$folder = implode('/', $dirArray);//結合してディレクトリ作成

                //移動元ディレクトリより上の階層では再帰処理なし
				if(strpos($folder,$sourceDir) !== false){
					globFlat_test($folder,$copyFolder);
				}

			} else {
				// echo "移動エラー";
			}
		}
	}
}



//マークダウン変換
function md2html($md)
{
    $Extra = new ParsedownExtra();
    $html = $Extra->text($md);

    return $html;
}



//pagesフォルダ内のディレクトリを配列に格納
function fileGlobe()
{
    global $folderObj;
    globAll('../pages');
    return $folderObj;
}



//-------------------//
// 　  試作中用      //
//-----------------//


//削除フォルダをtrushにバックアップ テスト
$container->set(
    "del_trush",
    function () {
        global $delFolder;
        global $dateTime;

        $delDir = str_replace('pages', 'trush/'.$dateTime, $delFolder);
        mkdir($delDir);
        copy_directory($delFolder, $dateTime);
    }
);


//フォルダ構成再生成 差分のみ式用　テスト
$container->set(
    "copysabun_return",
    function () {
        global $sabunMenu;

        globRe_sabun($sabunMenu);
    }
);

AppFactory::setContainer($container);




