---
title: ★名前空間
taxonomy:
    category:
        - docs
media_order: 'No1名前空間2つ記述する方法.png,No.2 波括弧で囲む方法.png'
---

## namespaceとは ##{#p1}
namespaceは名前空間とも呼ばれ、項目をカプセル化するときに使用します。

名前空間とは、例えば通常同じファイルに同じクラスや関数名、定数名が存在することはできませんが、名前空間を使用することにより、関連するクラスや、インターフェイス、関数、定数などをグループ化することが可能です。

そのため、名前空間を指定しておけば自分が作ったクラスが、サードパーティのクラスや関数などと名前が衝突することを防ぐことができます。

namespaceは以下のように記述します。
<p class="tmp"><span>書式</span></p>
```
namespace 名前空間名;
```
名前空間はソースコードの1番先頭で宣言する必要があります。  
「クラス」「インターフェイス」「関数」「定数」が名前空間の影響を受けます。

～時間ある時に記入～

## useとは

useとは名前空間の拡張機能で、外部のエイリアスやその一部を参照したり、クラス・関数・定数などをインポートするときに使用します。

useキーワードは、WindowsのショートカットやUnix系のシンボリックリンクを作成する機能に似ています。

useキーワードを使用して、エイリアスを定義するためには以下のように記述します。

<p class="tmp"><span>書式</span></p>
```
use [名前空間または一部・クラス・関数・定数など] as 別名称
```
useキーワードを使用すれば、名前空間などのフルパスを短縮して、別の名称で定義することが可能です。

～時間ある時に記入～

## 使い方

実際に名前空間を利用してみます。  
sato.php と suzuki.php で名前空間を定義してみましょう。  
sato.php に namespace sato; を追記します。

<p class="tmp">sato.php</p>
```
<?php
namespace sato;

function getGreeting() {
    return 'おはよう';
}
```
<p class="tmp">suzuki.php</p>
```
<?php
namespace suzuki;

function getGreeting() {
    return 'こんばんは';
}
```
<p class="tmp">call.php</p>
call.php では sato\getGreeting(); として関数を利用します。
```
<?php
require_once 'sato.php';
require_once 'suzuki.php';

echo sato\getGreeting();
```

<div class="box-example" markdown="1">
### 表示結果 ### {.h-example}
これで、satoという名前空間にあるgetGreeting()関数が呼ばれ おはよう と表示されます。  
sato\getGreeting(); を、suzuki\getGreeting(); に変更すれば、こんばんは と表示されます。

[新規タブ](../../../sample/php/other_page/name_space/sample1/call.php/index.html?target=_blank)
</div>

今回、名前空間名をファイル名と同じく命名しましたが、名前空間名は任意で決められますので、ファイル名と関係ない名前空間名にすることも可能です。  
ただ、全く関係がない名前空間名にするとわかりにくいので、ファイル名と同じくするなどわかりやすい名前空間名にしてください。

### 一つのファイルに複数の名前空間を記述する

先ほどは、一つのファイルに一つの名前空間を定義しましたが、一つのファイルに複数の名前空間を定義することが可能です。  
複数の名前空間を定義するには、2つの方法があります。  
それぞれの方法を確認しましょう。

#### No.1 名前空間を続けて記述する方法

<p class="tmp list"><span>リスト</span>function.php</p>
```
<?php

namespace takahashi;

function getGreeting() {
    return 'ごきげんよう';
}

namespace tanaka;

function getGreeting() {
    return 'Hello';
}
```
namespaceで名前空間を宣言した後に記述した関数などは、その名前空間に属します。  
その後にまた namespace で名前空間を宣言すれば、その名前空間に属します。  
先ほどの記述は、下記のような名前空間になります。
![No1%E5%90%8D%E5%89%8D%E7%A9%BA%E9%96%932%E3%81%A4%E8%A8%98%E8%BF%B0%E3%81%99%E3%82%8B%E6%96%B9%E6%B3%95](No1%E5%90%8D%E5%89%8D%E7%A9%BA%E9%96%932%E3%81%A4%E8%A8%98%E8%BF%B0%E3%81%99%E3%82%8B%E6%96%B9%E6%B3%95.png "No1%E5%90%8D%E5%89%8D%E7%A9%BA%E9%96%932%E3%81%A4%E8%A8%98%E8%BF%B0%E3%81%99%E3%82%8B%E6%96%B9%E6%B3%95")

<p class="tmp list">call.php</p>
```
<?php
require_once 'function.php';

echo takahashi\getGreeting();
echo tanaka\getGreeting();
```

<div class="box-example" markdown="1">
### 表示結果 ### {.h-example}
実行すると ごきげんよう と Hello が表示されます。  
名前空間を続けて記述する方法を紹介しましたが、この方法は、どこまでがどの名前空間かわかりにくいので推奨されません。
もう一つの方法も見ていきましょう。

[新規タブ](../../../sample/php/other_page/name_space/sample2/call.php/index.html?target=_blank)
</div>

### No.2 波括弧で囲む方法

波括弧で囲むことで名前空間を定義することが可能です。  
波括弧内に記述した関数などは、その名前空間に属します

<p class="tmp">function</p>
```
<?php

namespace takahashi {
    function getGreeting() {
        return 'ごきげんよう';
    }
}

namespace tanaka {
    function getGreeting() {
        return 'Hello';
    }
}
```
下記のような名前空間になります。
![No.2%20%E6%B3%A2%E6%8B%AC%E5%BC%A7%E3%81%A7%E5%9B%B2%E3%82%80%E6%96%B9%E6%B3%95](No.2%20%E6%B3%A2%E6%8B%AC%E5%BC%A7%E3%81%A7%E5%9B%B2%E3%82%80%E6%96%B9%E6%B3%95.png "No.2%20%E6%B3%A2%E6%8B%AC%E5%BC%A7%E3%81%A7%E5%9B%B2%E3%82%80%E6%96%B9%E6%B3%95")

先ほどと同様に call.php で名前空間を含めて関数を記述すれば、それぞれの関数を呼ぶことができます。

<p class="tmp">call.php</p>
```
<?php
require_once 'function.php';

echo takahashi\getGreeting();
echo tanaka\getGreeting();
```

<div class="box-example" markdown="1">
### 表示結果 ### {.h-example}
実行すると ごきげんよう と Hello が表示されます。  
波括弧を使って複数の名前空間を定義する方法を紹介しました。
先ほどの方法より、わかりやすくなっていますが、なるべく一つのファイルでは一つの名前空間にするのがわかりやすいです。

[新規タブ](../../../sample/php/other_page/name_space/sample3/call.php/index.html?target=_blank)
</div>

～続きは時間ある時に記入～
<https://qiita.com/7968/items/1e5c61128fa495358c1f>より

## 参考サイト

* [【PHP入門】名前空間(namespace/use)の使い方をわかりやすく解説！](https://www.sejuku.net/blog/23555)
* [【PHP超入門】名前空間（namespace・use）について](https://qiita.com/7968/items/1e5c61128fa495358c1f)