*[page-title]:PHPでデータベース操作


作業フォルダ
: C:\xampp\htdocs\php\shop1

## データベースへの接続


<div markdown="1" class="tmp-box">
MySQLのデータベースに接続します。

<p class="tmp"><span>書式</span>PDOで接続</p>
```
$pdo=new PDO('mysql:host=localhost;dbname=データベース名;charset=utf8', 'ユーザー名', 'パスワード');
```

※ユーザー名、パスワードをデータベースに設定してない場合は、ユーザー名を「<span class="red bold">root</span>」にしてパスワードは<span class="blue bold">空</span>にします。
```
$pdo=new PDO('mysql:host=localhost;dbname=データベース名;charset=utf8', 'root', '');
```

</div>
では、「MySQL操作」ページで作成したデータベース「shop1」に接続して、データを表示してみます。  
![](upload/productsテーブル3件レコード.png "図　productsテーブル"){.photo-border}

phpファイルに下記のコードを記述します。  
foreach()を使うことで、複数のデータを表示できます。
<p class="tmp list"><span>リスト</span>shop-list.php</p>
```
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop1;charset=utf8', 'staff', 'password');

foreach ($pdo->query('select * from products') as $row) {
	echo '<p>';
	echo $row['id'], ':';
	echo $row['name'], ':';
	echo $row['price'];
	echo '</p>';
}
?>
```

上記を次のように制御構造について簡略化した形式で記述することもできます。
<p class="tmp list"><span>リスト</span>shop-list.php</p>
```
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop1;charset=utf8', 'staff', 'password');

//簡略化した形式
foreach ($pdo->query('select * from products') as $row): ?>
<p><?= $row['id'] ?>:<?= $row['name'] ?>:<?= $row['price'] ?></p>
<?php endforeach ?>
```

「～/shop-list.php」にアクセスすると、次のように表示されます。
<p class="result"><span>表示結果</span></p>
```php
1:りんご:100

2:みかん:80

3:すいか:250
```



<div markdown="1" class="memo-box">
##### <span class="blue">SQLインジェクション</span>
SQLインジェクションとはDB操作を実行するSQL文に入力値を絡めるときに悪意あるコードを埋め込まれてDBのデータを不正に操作されてしまう攻撃です。
注意すべきことは入力値をそのままSQL文に組み込まないということです。  
SQLインジェクションの対策はDB操作にPDOを使っていると楽です。

##### <span class="green">PDO(PHP Data Objects)とは</span>
「データベース抽象型レイヤ」の１つです。データベース抽象型レイヤとはDB操作を1つのオブジェクトとして扱い、種類がたくさんあるDBの差異を吸収し共通したコードで操作できるようになります。  
つまり異なるDBに変更されてもコードを変えなくても使えるようにするのがPDOの役割です。

SQL文に入力値を入れ込む場合は、PDOの機能：プレイスホルダを使うと便利です。  
プレイスホルダとは値を入れ込むところを一旦別の文字にしておき、後から挿入する場所のことを指します。

PDOではプレイスホルダが「?」と「:名称(例:name)」の２パターンの方法が用意されています。  
このプレイスホルダを使うことで使用した入力値に対して自動でエスケープ処理を施してくれます。
</div>


## レコード検索

### 商品名で検索

<p class="tmp list"><span>リスト</span>search-input.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>検索</title>
</head>
<body>
    商品名を入力してください。
    <form action="search-output.php" method="post">
    <input type="text" name="keyword">
    <input type="submit" value="検索">
    </form>
</body>
</html>
```

「～/search-input.php」にアクセスすると、次のフォームが表示されます。
![](upload/商品名を入力してください.png "図　検索入力フォーム"){.photo-border}


<p class="tmp list"><span>リスト</span>search-output</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>検索結果</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
        <?php
        $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
        $sql = $pdo->prepare('select * from products where name=?');
        $sql->execute([$_POST['keyword']]);
        ?>
    <table>
        <tr>
            <th>商品番号</th>
            <th>商品名</th>
						<th>生産地</th>
            <th>商品価格</th>
        </tr>
        <?php foreach ($sql->fetchAll() as $row): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['local'] ?></td>
            <td><?= $row['price'] ?></td>
        </tr> 
        <?php endforeach ?>
    </table>
</body>
</html>
```

<div markdown="1" class="memo-box">
パラメータ部分を示す記号「?」のことをプレースホルダと呼び、そこへ実際の値を割り当てることを「バインドする」と呼びます。
</div>

<p class="tmp list"><span>リスト</span>css/style.css</p>
```
@charset "UTF-8";

table {
    border: 1px solid #eaeaea;
    table-layout: auto;
    border-collapse: collapse;
    border-spacing: 0;
    table-layout: fixed;
    margin: 1rem 0;
    width: auto;
}

table th, table td {
    padding: .45rem .5rem;
    border: 1px solid #aaa;
    font-weight: 700;
    font-size: .9rem;
    line-height: 1.2;
}
```

![](upload/productsレコード7件.png "図　productsテーブル"){.photo-border}

りんごを入力して検索ボタンを押すと、商品名がりんごのレコードが抽出されます。
![](upload/りんごを記入して検索.png){.figure-none .d-block .border .mt-3}
　↓
![](upload/りんごで検索結果.png "図　りんごのレコード抽出"){.photo-border}


### 商品名と生産地で検索

商品名と生産地で検索できるようにしてみます。

<p class="tmp list"><span>リスト</span>search-input2</p>
```
・・・
<body>
    <form action="search-output.php" method="post">
        <label for="goods">商品名</label>
        <input id="goods" type="text" name="goods">
        <label for="local">生産地</label>
        <input id="local" type="text" name="local">
        <input type="submit" value="検索">
    </form>
</body>
・・・
```

<p class="tmp list"><span>リスト</span>css/style.css</p>
```
・・・
form {
    width: 300px;
    display: flex;
    flex-direction: column;
    border: 1.5px solid #aaa;
    padding: 10px;
}

input {
    display: block;
    margin-bottom: 5px;
}

input[type="submit"]{
    margin-left: auto;
    margin-top: 5px;
}
```

<p class="tmp list"><span>リスト</span>search-output2.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>検索結果2</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <table>
        <tr>
            <th>商品番号</th>
            <th>商品名</th>
            <th>生産地</th>
            <th>商品価格</th>
        </tr>
        <?php
        $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');

        $sql = $pdo->prepare('select * from products where name=? and local=?');
        $sql->execute([$_POST['goods'], $_POST['local']]);
        ?>

        <?php foreach ($sql->fetchAll() as $row): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['local'] ?></td>
            <td><?= $row['price'] ?></td>
        </tr> 
        <?php endforeach ?>
    </table>
</body>
</html>
```

商品名「りんご」と生産地「長野」で検索すると、その二つに当てはまるレコードが抽出されます。

![](upload/りんごと長野で検索.png){.figure-none .d-block .border .mt-3}
　↓
![](upload/りんごと長野のレコード抽出.png "図　りんごと長野のレコード抽出")


### htmlspecialchars関数

入力したデータにはhtmlspecialchars関数を設定しておきます。

※htmlspecialchars関数は、 HTMLタグ(例：「&」、「”」、「’、「<」、「>」)などに使われる特殊文字をエンティティに変換します。<span class="marker-yellow50">XSS等による攻撃</span>を防ぐためにhtmlspecialchars関数はよく使われます。

<p class="tmp list"><span>リスト</span>search-output2.php</p>
```
・・・
$sql = $pdo->prepare('select * from products where name=? and local=?');

$goods = htmlspecialchars($_POST['goods'], ENT_QUOTES, 'UTF-8');
$local = htmlspecialchars($_POST['local'], ENT_QUOTES, 'UTF-8');
$sql->execute([$goods, $local]);
・・・
```

### bindvalue()関数

bindvalue()関数は、プリペアドステートメントで使用するSQL文の中でプレースホルダーに値をバインドするための関数のことです。

#### 擬似プレースホルダーの場合

<p class="tmp list"><span>リスト</span>search-output2.php</p>
```
・・・
// プリペアドステートメントで SQLをあらかじめ用意しておく
$sql = $pdo->prepare('select * from products where name = ? and local = ?');
        
// 値をバインド
$sql->bindValue(1, $_POST['goods']);
$sql->bindValue(2, $_POST['local']);
        
// executeでクエリを実行
$sql->execute();
・・・
```

#### 名前付きプレースホルダー

プレースホルダを任意の文字列にして可読性を高める方式もあります。

<p class="tmp list"><span>リスト</span>search-output2.php</p>
```
・・・
// プリペアドステートメントで SQLをあらかじめ用意しておく
$sql = $pdo->prepare('select * from products where name = :name and local = :local');
// 値をバインド
$goods = $_POST['goods'];
$local = $_POST['local'];
$sql->bindValue(':name', $goods);
$sql->bindValue(':local', $local);

// executeでクエリを実行
$sql->execute();
・・・
```


## レコードを追加する

商品名と生産地を入力して新規追加するフォームを作成します。

<p class="tmp list"><span>リスト</span>insert-input.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <form action="search-output2.php" method="post">
        <label for="goods">商品名</label>
        <input id="goods" type="text" name="goods">
        <label for="local">生産地</label>
        <input id="local" type="text" name="local">
        <input type="submit" value="新規追加">
    </form>
</body>
</html>
```

送信されたデータをデータベースに追加する処理を作成します。

<p class="tmp list"><span>リスト</span>insert-outout.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加完了</title>
</head>
<body>
    <?php
    $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
    $sql=$pdo->prepare('insert into products values(null, :name, :local, :price)');

    $goods = htmlspecialchars($_POST['goods'], ENT_QUOTES, 'UTF-8');
    $local = htmlspecialchars($_POST['local'], ENT_QUOTES, 'UTF-8');
    $price = htmlspecialchars($_POST['price'], ENT_QUOTES, 'UTF-8');

    $sql->bindValue(':name', $goods);
    $sql->bindValue(':local', $local);
    $sql->bindValue(':price', $price);

    if ($sql->execute()) {
        echo '追加に成功しました。';
    } else {
        echo '追加に失敗しました。';
    }
    ?>
</body>
</html>
```

入力して新規追加ボタンを押します。
![](upload/マスカット新規登録.png){.figure-none .d-block}
　↓  
 成功するとデータベースに新規登録され「追加に成功しました。」と表示されます。  
　↓
 ![](upload/マスカットDB登録.png "図　DBにレコード追加完了"){.photo-border}
 
 ただこのページの状態でブラウザを更新すると、次のように同じデータがデータベースに追加されてしまいます。
 ![](upload/ブラウザ更新のたびに追加される.png){.photo-border}
 
 この事象を「F5問題」といいます。対策としては、トークン方式とリダイレクト方式があります。
 参考サイト
 : [【Formの二重送信防止方法】PHPページでF5を押すとフォームが二重送信されてしまう](https://comment-out.net/2023/01/03/1482.html)
 
 リダイレクト方式を使うには、登録が完了後に一覧ページへ戻るようにするといいです。
 
 では、shop-list.phpのファイルを元にindex.phpファイルを新規作成して、商品一覧ページの修正を行います。
 
<p class="tmp list"><span>リスト</span> index.php</p>
 ```
 <!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>商品一覧</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<?php
	$pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8', 'staff', 'password');
	?>
	<form action="insert-input.php" method="post">
		<input type="submit" value="新規登録">
	</form>
	<table>
		<caption>商品一覧</caption>
		<thead>
			<tr>
				<th>商品名</th>
				<th>生産地</th>
				<th>価格</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($pdo->query('select * from products') as $row): ?>
			<tr>
				<td><?= $row['name'] ?></td>
				<td><?= $row['local'] ?></td>
				<td><?= $row['price'] ?></td>
			</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</body>
</html>
 ```
 
 新規登録完了後に一覧ページにリダイレクトされるように設定します。
 
<p class="tmp list"><span>リスト</span> insert-output.php</p>
 ```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加完了</title>
</head>
<body>
    <?php
    $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
    $sql=$pdo->prepare('insert into products values(null, :name, :local, :price)');

    $goods = htmlspecialchars($_POST['goods'], ENT_QUOTES, 'UTF-8');
    $local = htmlspecialchars($_POST['local'], ENT_QUOTES, 'UTF-8');
    $price = htmlspecialchars($_POST['price'], ENT_QUOTES, 'UTF-8');

    $sql->bindValue(':name', $goods);
    $sql->bindValue(':local', $local);
    $sql->bindValue(':price', $price);

    if ($sql->execute()) {
        header('Location:index.php');//一覧ページにリダイレクト
        exit();
    } else {
        echo '追加に失敗しました。';
        echo '<a href="index.php">一覧に戻る</a>';
    }
    ?>
</body>
</html>
 ```
 

 「めろん、北海道、1100」を入力して新規追加ボタンを押します。
![](upload/めろん入力.png){.figure-none .d-block}
　　　　↓  
新規登録 完了後、一覧ページにリダイレクトされ、めろんが登録されているのが確認できます。  
 ![](upload/めろん登録完了.png)
 
 
 ### トークンを設定する
 
 参考ページ
 : [トークン](/from_now_slim/public/pages/php/php_other/php_token/php_token_memo1/)
 : [【PHP】セキュリティを強化する、csrf対策トークンの実装](https://qiita.com/Takahiro_Nago/items/43422dc46a4a0646c89e)
 
 セッションにトークンを保存して、入力フォームにトークンを追加します。
 
<p class="tmp list"><span>リスト</span> insert-input.php</p>
```
<?php
// セッションの開始
session_start();

// ワンタイムトークンの生成
$toke_byte = random_bytes(16);
$token = bin2hex($toke_byte);

// トークンをセッションに保存
$_SESSION['token'] = $token;
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <p><a href="index.php">一覧に戻る</a></p>
    <form class="form-box" action="insert-output.php" method="post">
        <input type="hidden" name="token" value="<?= $token; ?>"><!-- hiddenで生成したトークンを埋め込む -->
        <label for="name">商品名</label>
        <input id="name" type="text" name="name">
        <label for="local">生産地</label>
        <input id="local" type="text" name="local">
        <label for="price">価格</label>
        <input id="local" type="text" name="price">
        <input type="submit" value="新規追加">
    </form>
</body>
</html>
```

送信されたデータ処理で、トークンの判定をします。トークンが存在しなかったり、セッションのトークンと送信されたトークンの値が一致しない場合は、処理を停止します。
<p class="tmp list"><span>リスト</span>insert-output.php</p>
```
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加完了</title>
</head>
<body>
<?php
session_start();

//トークンが存在しないか、セッションのトークンと送信されたトークンの値が一致しない場合は、処理停止。
if (!isset($_POST["token"]) || $_POST["token"] != $_SESSION['token']) {
  echo "<p>不正なリクエストです</p>";
  echo '<p><a href="index.php">一覧に戻る</a></p>';
  exit();
}

// 以下、処理続行

    $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
    $sql=$pdo->prepare('insert into products values(null, :name, :local, :price)');

    $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
    $local = htmlspecialchars($_POST['local'], ENT_QUOTES, 'UTF-8');
    $price = htmlspecialchars($_POST['price'], ENT_QUOTES, 'UTF-8');

    $sql->bindValue(':name', $name);
    $sql->bindValue(':local', $local);
    $sql->bindValue(':price', $price);

    if ($sql->execute()) {
        // echo '追加に成功しました。';
        header('Location:index.php');
        exit();
    } else {
        echo '<p>追加に失敗しました。</p>';
        echo '<p><a href="index.php">一覧に戻る</a></p>';
    }
    ?>
</body>
</html>
```

テストで、フォームへ次のようにトークンの値を任意に設定して送信すると、セッションのトークン値と送信されたトークン値が一致しないので
```
<input type="hidden" name="token" value="12345">
```
次のように表示されます。
![](upload/不正なリクエストです.png){.photo-border}
 
 
 
 ## レコードを編集する
 
一覧ページに編集ボタンを設置します。
 
<p class="tmp list"><span>リスト</span>index.html</p>
```
・・・
	<table>
		<caption>商品一覧</caption>
		<thead>
			<tr>
				<th>商品名</th>
				<th>生産地</th>
				<th>価格</th>
				<th></th><!-- 追加 -->
			</tr>
		</thead>
		<tbody>
			<?php foreach ($pdo->query('select * from products') as $row): ?>
			<tr>
				<td><?= $row['name'] ?></td>
				<td><?= $row['local'] ?></td>
				<td><?= $row['price'] ?></td>
				<td>
					<form action="update-input.php" method="get">
						<input type="hidden" name="id" value="<?= $row['id'] ?>">
						<input type="submit" value="編集">
					</form>
				</td>
			</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</body>
</html>
```


<p class="tmp list"><span>リスト</span>update-input.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>編集フォーム</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php 
    $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
    ?>
	<h1>商品編集</h1>
    <table>
		<thead>
			<tr>
				<th>商品名</th>
				<th>生産地</th>
				<th>価格</th>
                <th></th>
			</tr>
		</thead>
		<tbody>
			<?php 
            $sql=$pdo->prepare('select * from products where id=?');
            $sql->execute([$_GET['id']]);
            
            foreach ($sql->fetchAll() as $row): ?>
                <form action="update-output.php" method="post">
                    <input type="hidden" name="id" value="', $row['id'], '">
                    <td><input type="text" name="name" value="<?= $row['name'] ?>"></td>
                    <td><input type="text" name="local" value="<?= $row['local'] ?>"></td>
                    <td><input type="text" name="price" value="<?= $row['price'] ?>"></td>
                    <td><input type="submit" value="更新"></td>
                </form>
			<?php endforeach ?>
		</tbody>
	</table>
</body>
</html>
```
 
 
<p class="tmp list"><span>リスト</span>update-output</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>更新完了</title>
</head>
<body>
<?php
session_start();

//トークンが存在しないか、セッションのトークンと送信されたトークンの値が一致しない場合は、処理停止。
if (!isset($_POST["token"]) || $_POST["token"] != $_SESSION['token']) {
  echo "<p>不正なリクエストです</p>";
  echo '<p><a href="index.php">一覧に戻る</a></p>';
  exit();
}

$pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
$sql=$pdo->prepare('update products set name=?, local=?, price=? where id=?');

if (!preg_match('/[0-9]+/', $_POST['price'])) {
	// echo '<p>商品価格を整数で入力してください。</p>';
    // echo '<p><a href="index.php">一覧に戻る</a></p>';
    header('Location:update-input.php');
    exit();

} elseif ($sql->execute([$_POST['name'], $_POST['local'], $_POST['price'], $_POST['id']])) {
	//更新に成功 リダイレクト
    header('Location:index.php');
    exit();
} else {
	echo '<p>更新に失敗しました。</p>';
    echo '<p><a href="index.php">一覧に戻る</a></p>';
}
?>
</body>
</html>
```
 
![](upload/編集商品一覧.png){.figure-none .d-block .mb-3 .border}
　↓　りんごの価格を400に変更
![](upload/りんご400変更.png){.figure-none .d-block .mb-3 .border}
　↓　価格が変更されました
![](upload/りんごprice400に変更されました.png){.figure-none .d-block .border}