export function pagetop() {

    $('#top').click(function () {
        // セレクタにはbodyとhtmlの両方を指定
        $('body, html').animate({
          scrollTop: 0	// 縦スクロールの位置をページ一番上に変化させる
        }, 500);	// 戻るスピード
          return false;
    });


	//ページトップボタン
	//初期は非表示
	$("#parts-pagetop").hide();

	$(window).scroll(function () {
		//140pxスクロールしたら
		if ($(this).scrollTop() > 140) {
			//フェードインで表示
			$('#parts-pagetop').fadeIn();
		} else {
			//フェードアウトで非表示
			$('#parts-pagetop').fadeOut();
		}
	});
}