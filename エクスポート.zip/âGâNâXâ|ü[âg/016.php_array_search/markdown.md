*[page-title]:配列に指定した値が存在するかチェック


配列に指定した値が存在するかチェックする方法です。

## in_array関数

参考サイト
: [【PHP入門】配列の値を検索するarray_searchと他4つの関数](https://www.sejuku.net/blog/22098#index_id1)

PHPのin_array関数は、配列の中に指定した値が存在するかチェックする関数です。

<p class="tmp"><span>書式</span>in_array()</p>
```
in_array(検索する値, 検索対象の配列, [型の比較を行うか])
```
第三引数にtrueを指定すると、型の比較も行います。省略可能。

<p class="exp"><span>例1-1</span></p>
<iframe src="https://paiza.io/projects/e/eUONR95SgMYZ7b8OvEEUMw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## isset関数

参考サイト
: [PHP | 配列・連想配列のキー名が存在するか確認する方法](https://1-notes.com/php-existence-check-for-variables-and-arrays/)
: [【PHP入門】isset関数で変数がセットされているか確認する方法](https://www.sejuku.net/blog/27735)

isset関数は、連想配列のキー名が存在するか確認します。  
連想配列の場合も同様にisset()でキー名の存在をチェックする事ができる関数です。

<p class="tmp"><span>書式</span></p>
```
bool isset($変数名1 [, $変数名2 ...])
```

引数：
: 引数には1つまたは複数の変数名を指定します。  
変数名を指定することで、その変数がセットされているか、NULLではないかを調べます。

返り値：
: 値が設定されていたらTRUEを返し、設定されていなかったらFALSEを返します。

※複数の変数を指定した場合は、<span class="red">全ての変数に値がセットされている場合のみTRUE</span>を返します。

<div class="exp">
	<p class="tmp"><span>例2-1</span></p>
	<iframe src="https://paiza.io/projects/e/7wMO3C-mBE_M5patEQUQvQ?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>
</div>

※確認してから処理を実行する事で「Undefined array key ～」エラーや「Undefined variable ～」などのエラーを回避できます。


## array_search

配列の値を検索するのに使われる基本的な関数array_searchは、検索した要素がある場合、in_arrayと違って<span class="red bold">要素番号</span>を返してくれます。（最初の値のインデックスキーのみを返します。）

<p class="tmp"><span>書式</span>array_search</p>
```
array_search(検索する値, 検索対象の配列, [型の比較を行うか])
```

第一引数には、検索したい要素(値)を指定します。  
第二引数ではどの配列から検索したいか、検索する配列名を指定します。  
第三引数にtrueを指定すると型の比較も行います。省略可能。

検索する値が見つかった場合は、値のインデックスキー(要素番号)を返し、その他の場合はfalseを返します。

<div class="exp">
	<p class="tmp"><span>例3-1</span></p>
	$array配列のPythonのインデックス番号の「2」を返しています。
	</div>
<iframe src="https://paiza.io/projects/e/mPX-Lcd0umpDHkP9t_kLeA?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

※検索する値が文字列の場合、大文字小文字は区別して比較が行われます。

<div class="exp">
	<p class="tmp"><span>例3-2</span></p>
	検索文字を小文字で「python」にすると、falseを返します。
	</div>
<iframe src="https://paiza.io/projects/e/zokDu3GwdIxSI0gcXBUa7A?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

第三引数を指定しない場合、型の比較は行いません。  
今回は検索する要素の型も見るためvar_dumpで出力していますが、結果がfalseなので真偽値型のboolが出力されています。  
要素の型の比較まで行う場合には、第三引数にtrueを指定します。

## array_keys関数

参考サイト
: [【PHP入門】array_keys関数で配列や連想配列のキーを取得する](https://www.sejuku.net/blog/22704)

検索する値が配列に複数ある場合でも、array_search関数は最初の値のインデックスキーのみを返しました。  
全てのインデックスキーを取得したい場合は、<span class="green bold">array_keys関数</span>を使います。

<p class="tmp"><span>書式</span>array_keys関数</p>
```
array_keys(検索対象の配列, 検索する値, [要素の型])
```
第一引数に検索する配列の配列名を指定します。  
第二引数に検索する値を指定します。省略可能。  
第三引数のbool(真偽値)にTureを指定した場合は、要素の型の比較 (===)を行うことができます。デフォルト値はFalseに設定されています。省略可能。

array_search関数やin_array関数と引数の順番が違う点に注意してください。array_search関数は検索して見つかった全てのインデックスキーを配列にして返してくれます。

第二引数を省略した場合は配列すべてのインデックスキーが返されます。

<div class="exp">
	<p class="tmp"><span>例4-1</span></p>
	文字列型の300を検索しています。
	<iframe src="https://paiza.io/projects/e/8hRsY7DFVu_PIbpk1PsPew?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

## 名前を行で分けて、セレクトボックス生成

<p class="exp"><span>例4</span></p>
<p>配列の文字列をあ行、か行...と分けて、セレクトボックスを作成する。<br>
行に名前がない場合、その行は表示しないようになっています。</p>
<iframe src="https://paiza.io/projects/e/bI7DZsBGWEpOpixuu9iIrg?theme=twilight" width="100%" height="800" scrolling="no" seamless="seamless"></iframe>

以前作成したコード（不完全）
https://paiza.io/projects/e/VF35TaD26an-4OrEniuUVQ?theme=twilight

<p class="exp"><span>例5</span></p>
<p>役職のセレクトボックスを作成する</p>
<iframe src="https://paiza.io/projects/e/gix3IVNmr2UsSJopHY0s6Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>



