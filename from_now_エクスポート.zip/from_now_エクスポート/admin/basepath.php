<?php
    $basePath = '/from_now_slim';
    $siteName = 'Collect Note';
?>