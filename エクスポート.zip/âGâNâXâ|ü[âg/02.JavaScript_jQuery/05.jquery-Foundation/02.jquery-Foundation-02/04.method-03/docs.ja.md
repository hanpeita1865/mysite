---
title: '04. 要素の選択<br>（children、parent、siblings、closest）'
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">子要素の取得（children）</h2>

childrenを使用すると、現在マッチしている要素の子要素を取得できます。  
また、引数を指定すれば子要素を更にフィルタリングすることが可能です。  
<font color="Red">注：引数を指定した場合は直下の子要素のみ対象です！子孫要素も対象にするには**find**を使用してください。</font>

<dl class="dl-methodDetail">
    <dt><span>書式</span></dt>
    <dd>$('セレクタ').children(['引数']);</dd>
    <dt><span>引数</span></dt>
    <dd>更にマッチさせる要素をセレクタで指定</dd>
</dl>
<div class="box-example">
    <h3 class="h-example">例1</h3>
    第2階層のリストの文字を赤くし、その中でselectedクラスが付いた子要素だけ青背景にする。
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/ucawtpj1/4/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLでは入れ子で第3階層までリストを並べています。  
第2階層のA,Bと第3階層の1,2,3にクラスselectedを付けています。  

ではJavaScriptのコードを見てみましょう。  
まずlevel-2の子孫要素をすべてcssメソッドで赤文字にしています。  
次にlevel-2の子要素の中でクラスselectedが付いたものを青背景にしています。  
第3階層にもselectedが付いていますが引数指定のときは子要素のみ対象になります。

---

<h2 class="h-type2">親要素の取得（parent）</h2>

parentを使用すると、現在マッチしている要素の親要素を取得できます。  
また、引数を指定すれば親要素を更にフィルタリングすることが可能です。  
<font color="Red">注：直上の親要素のみ対象です！先祖要素も対象にするには**parents**を使用してください。</font>  

<dl class="dl-methodDetail">
    <dt><span>書式</span></dt>
    <dd>$('セレクタ').parent(['引数']);</dd>
    <dt><span>引数</span></dt>
    <dd>更にマッチさせる要素をセレクタで指定</dd>
</dl>
<div class="box-example">
    <h3 class="h-example">例2</h3>
    ボタン1を押すとspan要素「jQuery」の親要素に赤い枠線を引く。ボタン2を押すとspan要素「jQuery」の親でp要素のみ背景色を緑に。
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/ucawtpj1/5/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLにはdiv要素が2つあります。  
下のdiv要素内にはspan要素しかありませんが、上のdiv要素にはp要素が追加され入れ子構造になっています。  
その下にボタンを2つ用意しています。

ではJavaScriptのコードを見てみましょう。  
ボタン1を押すと、span要素の親要素は上のdiv要素ではp要素、下のdiv要素ではdiv要素となり、それぞれ赤枠が付きます。  
ボタン2を押すと、上のdiv要素内にあるp要素だけが選択されます。下のdiv要素ではspan要素の親要素がdiv要素でありp要素ではないので選択されません。  

---

<h2 class="h-type2">兄弟要素の取得（siblings）</h2>

siblingsを使用すると、現在マッチしている要素の兄弟要素（自分は含まない）を取得できます。  
また、引数を指定すれば兄弟要素を更にフィルタリングすることが可能です。  
<font color="Red">注：兄弟要素すべてが対象です！自分の前の兄弟要素のみ対象にするには**prev**、自分の後の兄弟要素のみ対象にするには**next**を使用してください。</font>  

<dl class="dl-methodDetail">
    <dt><span>書式</span></dt>
    <dd>$('セレクタ').siblings(['引数']);</dd>
    <dt><span>引数</span></dt>
    <dd>更にマッチさせる要素をセレクタで指定</dd>
</dl>
<div class="box-example">
    <h3 class="h-example">例3</h3>
    左のリストをクリックすると兄弟要素の文字を赤くする。右のリストをクリックすると兄弟要素でクラスselectedの文字を赤くする。
</div>
<iframe width="100%" height="400" src="//jsfiddle.net/b2m0j4e6/1/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLではul#1とul#2、二つのリストを準備しています。ul#2では一部のリストにクラスselectedをつけています。  

ではJavaScriptのコードを見てみましょう。  
左のリストul#1のli要素をクリックすると、自分以外のすべての兄弟要素をcssメソッドで操作しています。  
右のリストul#2のli要素をクリックすると、自分以外の兄弟要素でクラスselectedのものだけcssメソッドで操作しています。  

---

<h2 class="h-type2">直近の祖先要素のみ取得（closest）</h2>

closestを使用すると、マッチする祖先要素すべてを返すparentsとは違い、マッチする直近の祖先要素のみを取得できます。  
parentsとは違い、検索対象には自分も含みます。  
引数の指定は必須になります。  

<dl class="dl-methodDetail">
    <dt><span>書式</span></dt>
    <dd>$('セレクタ').closest('引数');</dd>
    <dt><span>引数</span></dt>
    <dd>取得する直近の要素をセレクタで指定</dd>
</dl>

要素の数を返すlengthプロパティと組み合わせることで、要素判定で処理を変えるなどの使用法があります。  

<div class="box-example">
    <h3 class="h-example">例4</h3>
    ボタンを押すとクリック回数を表示。ボタン以外を押すと0回にリセットする。
</div>
<iframe width="100%" height="300" src="//jsfiddle.net/3enf0mvq/1/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLでは、まず#counterに0回と表示しておきます。  
その下にボタンを用意しています。

ではJavaScriptのコードを見てみましょう。  
まず変数countを用意します。  
次に、クリックイベントが発生したときclosestメソッドでその要素がbuttonかどうかを判定します。  
buttonなら変数countをカウントアップ、それ以外なら0にリセットします。  
最後にhtmlを書き換えます。