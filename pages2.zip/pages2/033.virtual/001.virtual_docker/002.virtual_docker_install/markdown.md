*[page-title]:Dockerインストール

参考サイト
: [Laravel 9.x インストール](https://readouble.com/laravel/9.x/ja/installation.html)
: [Laravel Sailで開発環境構築【Vite対応】](https://chigusa-web.com/blog/laravel-sail/)


## Dockerのインストール

Laravel Sailはローカル環境のDockerコンテナ上でLaravel を動作させます。  
そのため、ローカルマシンにはDockerをインストールする必要があります。 DockerはDocker社が開発しているコンテナ型の仮想環境を作成、配布、 実行するためのプラットフォームです。

公式サイト
: <https://www.docker.com/products/docker-desktop/>

![](upload/Docker公式サイトダウンロード画面.png "図　Docker公式サイトダウンロード画面")


1. インストールが済んだら、次にMicrosoft storeから「<span class="green bold">Ubults</span>」をインストールします。  
ユーザ名: hirao　パスワード: ryouma  ※rootではなくなりました。その場合、Xamppと競合しなくなるはずです。
インストール完了後、Docker デスクトップの左上部の歯車（設定）をクリックし、WSL integrationをクリックします。
![](upload/DockerResourcesメニュー.png)
1. Ubuntu-20.04にチェックを入れます。
![](upload/Ubumtuチェック.png)
1. Power Shellを起動し、「Ubuntu」にログインします。
![](upload/Ubumtuログイン.png)
ログインしました。
![](upload/Ubumtuログイン完了.png)
1. 最初の設定では、最新の状態にアップデートしておきます。
<p class="tmp cmd"><span>コマンド</span></p>
```
sudo apt update && sudo apt upgrade -y
```
アップデートが完了しました。
![](upload/Ubumtuアップデート完了.png)
1. dos2unixを導入して改行コードを一括置換します。
<p class="tmp cmd"><span>コマンド</span></p>
```
sudo apt-get install -y dos2unix
find . -type f -print0 | xargs -0 dos2unix
```


## 新規で開発環境を作成する

Ubuntuにログインして、作業ディレクトリに移動して以下のコマンドを実行します。  
（8分くらいかかります。）
<p class="tmp cmd"><span>コマンド</span></p>
```
curl -s "https://laravel.build/example-app?php=81" | bash
```
Laravelのプロジェクト作成の実行が開始されれば成功です。
![](upload/Laravelインストール完了.png)
作成された「example-app」のフォルダの場所は以下になります。
![](upload/Linux作成フォルダ場所1.png)
※もし、「Docker is not running」と表示されたら、Docker Desktop を再起動してみてください。
![](upload/DockerRestartボタン.png)
再起動後に「Apply & Restart」が活性になってたら、ボタンを押します。
![](upload/DockerApplyRestartボタン.png)
![](upload/Linux作成フォルダ場所2.png)
プロジェクトの作成が完了したら、作成されたディレクトリに移動してLaravel Sailを起動します。
<p class="tmp cmd"><span>コマンド</span></p>
```
cd example-app//ディレクトリ移動

./vendor/bin/sail up　//Laravel Sailを起動
```
![](upload/LaravelSail起動.png)
http://localhost にアクセスすると、次の画面が表示されLaravelアプリケーションにアクセスできます。  
※アクセスできない場合は、XamppなどとMySQLのポートが競合している可能性があります。
![](upload/localhostに接続.png "図　localhostに接続（Laravelアプリケーション画面）")

上記で、  
「The stream or file "/var/www/html/storage/logs/laravel.log" could not be opened in append mode: Failed to open stream: Permission denied The exception occurred while attempting to log: The stream or file "/var/www/html/storage/logs/laravel.log" could not be opened in」  
のエラーが表示されます。  
これを解消するには、Laravelディレクトリの所有者を変更するとよいです。

参考サイト
: [Laravel Sail permission denied の解決方法](https://www.jinmusoftware.com/laravel-sail-permission-denied/)

```
cd example-app//ディレクトリ移動
sail up -d//デーモン起動
sail root-shell//コンテナ側にルートでログインします。
chown sail:sail . -R//ファイル所有者をsailに変更します。「-R」オプションは再帰的に実行します
exit
```

所有者を変更後、再度「<http://localhost>」にアクセスするとエラーが無くなったことが確認できます。
![](upload/localhostに接続(エラー修正後).png)

## Laravel Sailの便利なコマンド

一旦、CTRL+Cを押して、Sailを終了します。次の表示になります。
![](upload/sailupをexitで終了する.png)

### コマンドを省略する

次のコマンドを実行して、シェルの設定ファイルを開きます。
<p class="tmp cmd"><span>コマンド</span></p>
```
vi ~/.profile
```
![](upload/profileコマンド.png)
iキーを押してインサイドモードにし、次のエイリアスを入力します。
<p class="tmp cmd"><span>コマンド</span></p>
```
alias sail='[ -f sail ] && bash sail || bash vendor/bin/sail'
```

完了したらescキーを押してインサイドモードを終了し、「:wq」と入力することで保存して終了します。  
次のコマンドで設定ファイルを再読み込みして、変更を反映させましょう。
<p class="tmp cmd"><span>コマンド</span></p>
```
source ~/.profile
```

これで次回から「<span class="red bold">sail up</span>」とすることで起動できるようになります。

以前は下記のコマンドでした。
```
./vendor/bin/sail up
```


### デーモン起動する

sail upコマンドではターミナルでアプリケーションが起動した状態が確認できます。  
しかし、他のコマンドを入力することができません。 アプリケーションを起動したままの状態にして別のコマンドを受け入れられるようにしたいことがある と思います。  
このような「あるプロセスがバックグラウンドで起動した状態」 をデーモン起動と呼びます。  
Laravel Sail では以下のコマンドでデーモン起動することができます。
<p class="tmp cmd"><span>コマンド</span>デーモン起動</p>
```
sail up -d
```
![](upload/sailupをデーモン起動.png)
デーモン起動しているアプリケーションコンテナを停止する場合は以下のコマンドを利用します。
<p class="tmp cmd"><span>コマンド</span>デーモン停止</p>
```
sail down
```
ですので、開発を開始する際にsail up -dを行い、開発が終了した際には、sail downを行うルーティンが良いかと思います。

### アプリケーションコンテナにログインする

起動しているアプリケーションコンテナの内部にログインする場合は以下のコマンドが利用できます。
<p class="tmp cmd"><span>コマンド</span>コンテナ内にログイン</p>
```
sail shell
```
アプリケーションコンテナからログアウトする場合はexitコマンドでローカ ルに戻ることができます。  
Laravel Sailでは開発に必要なコマンドが一通り揃っていますのでアプ リケーションコンテナにログインするケースはあまりありませんが、 アプリケー ションがコンテナ内にどのように配置しているかを確認することができます。

以下はデーモン起動して、「sail shell」コマンドを実行しています。
![](upload/sail_shellコマンド.png)

「ls -la」で内部のファイルを表示します。
![](upload/ls-laコマンド.png)
アプリケーションコンテナ内でローカルに配置しているファイルが同期されていることが確認できます。   
終了する際は 「exit」と入力します。



### MySQLにログインする

<p class="tmp cmd"><span>コマンド</spanMySQLログイン></p>
```
sail mysql
```
MySQLにログインすることでSQLを実行することができます。  
終了する際は「exit」と入力します。


### artisanコマンドの実行

artisanコマンドを実行するにはまず、次のようにコンテナ内にログインします。
```
sail shell
```
![](upload/sailup_html.png)

その後、次のように入力します。

<p class="tmp"><span>書式</span>コマンド</p>
```
php artisan {command}
```
例えば、php artisan -V と入力してみます。
![](upload/phpartisan-V.png)

また、コンテナにログインしなくても、次のように入力すれば実行できます。
<p class="tmp"><span>書式</span>コマンド</p>
```
sail artisan {command}
```
試しにLaravelのバージョンをartisanコマンドから確認してみましょう。
![](upload/sailartisan_Laravelバージョン確認.png)
※artisanコマンドは、Laravelが提供しているコマンドラインインターフェースです。

### PHPコマンドの実行

phpコマンドも以下のショートカットが用意されています。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail php -v
```
![](upload/sail_php-v.png)


### Composer コマンドの実行

ComposerコマンドもSailから実行できます。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail composer -V
```
![](upload/sail_comoser-v.png)


### Node.jsの実行

Node.jsもインストールされているのでsailコマンドから実行できます。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail node -v
```
![](upload/sail_node-v.png)

Node.jsのモジュールを管理するパッケージマネージャであるnpmも利用できます。  
JavaScriptのライブラリの導入やビルドなどをこのコマンドを通して利用します。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail npm -v
```
![](upload/sail_npm-v.png)

### Sail環境を独自にカスタマイズする

Sailはdocker-composerを利用してDockerコンテナを起動し、開発環境を立ち上げています。  
DockerコンテナはDockerfileによって設定が記述されています。  
独自にカスタマイズすることで開発環境の設定を変更することが可能です。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan sail:publish
```
![](upload/sail_artisan_sail_publish2.png)
sail:publishを実行するとアプリケーションルートにdockerというディレクトリが作られます。  
また、docker-compose-ymlディレクトリ内にあるDockerfileが利用されるようになるため、独自にカスタマイズした内容が反映できるようになります。

example-appフォルダに「docker」フォルダが追加されているのが確認できます。
![](upload/dockerフォルダ作成.png)

dockerフォルダ内は以下のようにPHPバージョン別になっています。
![](upload/dockerフォルダ内8.0-8.2.png)

example-app/docker-compose.ymlを開くと、8.2が使用されているのがわかります。  
もしPHP8.0の環境で動作させたい場合は、ここを8.0に書き換えればいいです。
![](upload/docker--coomposeコード.png)

少し以下のDockerfileを覗いてみましょう。
![](upload/docker8.2_Dockerfile.png)

docker/8.2/Dockerfile
![](upload/docker8.2_Dockerfile_ENV.png)

このDockerfile のベースイメージはUbuntuであることがわかります。 
ですので開発環境はUbuntuの上でLaravelが実行されることを意味しています。
メンテナーラベルにはLaravelの作者であるTaylor Otwell氏の名前が記
載されています。
ENVTZ=UTCとなっているので、タイムゾーンがUTCであることも確認できます。
日本で開発を行う場合はJSTになっている方が親切なのでここを書き換えてみましょう。

```
ENV TZ='Asia/Tokyo'
```

Dockerfileを変更したらDockerイメージを再ビルドする必要があるので以下のコマンドを実行します。
<p class="tmp cmd"><span>コマンド</span>再ビルド</p>
```
sail build --no-cache
```
再ビルドにはしばらく時間がかかります。 完了後はsail up-dで起動して sail shell でログインして日付を確認してみましょう。
![](upload/sail_shell_date.png)

JSTとなっていることが確認できます。 このようにDockerfile を変更することで開発環境を独自にカスタマイズすることができます。  

PHPの新しいバージョンがリリースされた場合もこの Dockerfile を変更することで対応することが可能です。  
また、Sailではdocker-composeが利用されているため、アプリケーショ ンのルートディレクトリにあるdocker-compose.ymlを変更することで開発環境をより大幅にカスタマイズすることもできます。

今回見てきたDockerfile ではアプリケーションが動作する環境をカスタマイズしましたが、docker-compose.ymlを変更することで、たとえば全文検索エンジンであるElasticsearchのコンテナを追加してアプリケーションと接続させることも可能です。  
アプリケーションのシステム要件に応じて開発環境を独自にカスタマイズすることで多様な開発環境に対応できますので、ご自身の環境に合わせて設定しましょう。  
ここではdocker-composeに関する詳細は説明しませんので、別途要件に合わせて学習してください。

### MySQLの文字コードを変更する

日本語で開発する際に正しい文字コードでない場合、 適切に表示すること ができないため事前に設定しておく必要があります。
docker/8.2 ディレクトリに my.cnfファイルを作成し、次のようにします。

<p class="tmp list"><span>リスト</span>my.cnf</p>
```
[mysqld]
character-set-server = utf8mb4 
collation-server = utf8mb4_bin

[client]
default-character-set = utf8mb4
```

これはMySQLの設定ファイルとして、MySQLコンテナの/etc/に配置するようにdocker-compose.ymlに追記します。
mysqlのvolumesに
```
'./docker/8.2/my.cnf:/etc/my.cnf'
```
を追加しましょう。  
（※元あった/vendor/laravel/～はコメントアウトする。）
![](upload/volumesに追加.png "図「docker-compose.yml」のvolumesに追加")


それでは一旦sail downでコンテナを停止させ、再度「sail up -d」で起動して文字コードを確認してみましょう。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail up -d
sail mysql
mysql>show variables like '%char%';
```
![](upload/テーブルのutf8に変わってるか確認.png "図　utf8系に変わっている")

デフォルトは次のようになっていました。
![](upload/テーブルのデフォルトのValue.png "図　デフォルトのValue値")

## 複数人で開発するために

～保留～

