---
title: Python
taxonomy:
    category:
        - docs
child_type: docs
---

### Lesson 5

# Python

