fileIcon();

//ファイルアイコン設置
function fileIcon() {

    let linkElm = 'main a';

    let iconAry = [{
        text: 'Excelファイルへリンク',
        class: 'fa-file-excel'
      },
      {
        text: 'PDFファイルへリンク',
        class: 'fa-file-pdf'
      },
      {
        text: 'Wordファイルへリンク',
        class: 'fa-file-word'
      },
      {
        text: 'PowerPointファイルへリンク',
        class: 'fa-file-powerpoint'
      },
      {
        text: 'zipファイルへリンク',
        class: 'fa-file-zipper'
      },
      {
        text: 'メールアドレスへリンク',
        class: 'fa-envelope'
      },
      {
        text: '外部サイトへ移動します',
        class: 'fa-arrow-up-right-from-square'
      }
    ]

    iconAry.forEach(function (value, i) {
        iconAry[i].code = '<span class="fa-solid ' + value.class + ' fa-lg" aria-hidden="true"></span><span class="visually-hidden">' + value.text + '</span>';
    });

    let elm_a = document.querySelectorAll(linkElm);

    elm_a.forEach(e => {

        let href = e.getAttribute('href');
        let target = e.getAttribute('target');

        if (e.querySelector('img') == null && e.querySelector('button') == null) {

            switch (true) {
                //EXCELのとき
                case /.xls$|.xlsx$/.test(href):
                    e.insertAdjacentHTML('afterend', iconAry[0].code)
                    break;
                //PDFのとき
                case /.pdf$/.test(href):
                    e.insertAdjacentHTML('afterend', iconAry[1].code)
                    break;
                //WORDのとき
                case /.doc$|.docx$/.test(href):
                    e.insertAdjacentHTML('afterend', iconAry[2].code)
                    break;
                //パワーポイントのとき
                case /.ppt$|.pptx$/.test(href):
                    e.insertAdjacentHTML('afterend', iconAry[3].code)
                    break;
                //圧縮ファイルのとき
                case /.rar$|.7z$|.gz$|.tar$|.bz2$|.lzh$|.cab$/.test(href):
                    e.insertAdjacentHTML('afterend', iconAry[4].code)
                    break;
                //メールリンクのとき
                case /^mailto/.test(href):
                    console.log(href)
                    e.insertAdjacentHTML('afterend', iconAry[5].code)
                    break;

                //テキストファイル系のときはアイコンなし
                case /.txt$|.json$|.csv$/.test(href):
                    break;

                //target="_blank"があるとき	
                case /_blank/.test(target):
                    e.insertAdjacentHTML('afterend', iconAry[6].code)
                    break;
            }
        }
    })
}
