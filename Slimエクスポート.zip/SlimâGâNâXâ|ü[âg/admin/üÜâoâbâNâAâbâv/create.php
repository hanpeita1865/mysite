<?php
globAllRe('../pages_copy');

function globAllRe($folder) {

    $menuArray = json_decode($_POST['list']);//メニューのリスト構成

    // print_r($menuArray);

    if (!is_file($folder)) {
        $res = glob($folder . '/*'); 

        foreach ($menuArray as $item){
            $listExplode = explode('/', $item);
            $lastList = end($listExplode);
            list($listNum, $listName) = explode(".", $lastList);

            //メニューと一致したpages_copy内のフォルダ名取得
            foreach ($res as $key => $f) {
                $dirArray = explode('/', $f);
                $lastDir = end($dirArray); //配列の最後の値

                list($dirNum, $dirName) = explode(".", $lastDir);

                if($dirName == $listName){

                    if (rename($f, '../pages/'.$item)) {
                        //echo "OK";
                    } else {
                        //echo "エラー";
                    }
                    break;
                }
            }
        }
    }
}

// require 'folder_complist.php';
// file_put_contents("../templates/layouts/menu_list.twig", $menuCode);
?>
