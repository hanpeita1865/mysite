---
title: （移動済）map()による配列操作【JS】
taxonomy:
    category:
        - docs
---

* [forEach文との違いについて](#p1)
* [mapメソッドとfilterメソッドの違い](#p2)
* [読み込んだファイルの行数をmapメソッドで取得](#p3)
* [参考サイト](#p4)



配列データを便利に操作する「map」メソッドについてです。  
配列の全てのデータに対して指定した処理をおこない、新しい配列を作ることができます。


<p><span class="smp">例1</span>　数値データを格納した配列に対して、「map」メソッドを使った例です。
<script async src="//jsfiddle.net/kLn4gc2s/1/embed/js,result/"></script>
</p>

「for文」や「while文」などを使ってループ処理を書くこともできますが、このように「map()」を使うと非常にシンプルなプログラムになります。


## forEach文との違いについて ##{#p1}
同じように配列を操作できる「forEach文」とよく似ていますが、「forEach」は単純に実行するだけのメソッドなのに対して、「map」は実行後の結果を配列データとして返してくれるという点が違います。

<p><span class="smp">例2</span>　「forEach文」と「map」メソッドを使って処理結果を比較した例です。
    
<iframe width="100%" height="350" src="//jsfiddle.net/w0hqv6dt/1/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</p>

forEach文の場合は、実行結果の返り値が***undifind***になるのに対して、「map」の場合は実行結果が「返り値」として***配列データ***を取得できています。  
つまり、「forEach」は実行するだけで「返り値」は存在しないのに対して、「map」は「返り値」が存在するのです。


## mapメソッドとfilterメソッドの違い ##{#p2}

map()によく似た類似メソッドに**filter()** というのがあります。  
map()では、全ての値に「指定した処理」を行った値を格納した新しい配列を作成します。filter()では、全ての値から「指定した条件」に合致する値を格納した新しい配列を作成します。filter()を使用した例を見てみます。

<p><span class="smp">例3</span>　filter()を使った処理
<script async src="//jsfiddle.net/nhqcdL8w/embed/js,result/"></script>
</p>

この例では、数値が格納された配列データに対してfilter()を使い、5よりも小さい数値だけを抽出しています。filterメソッド内の関数にreturnで条件式の結果を返すことで、該当するデータだけを新規の配列に格納していくわけです。


## 読み込んだファイルの行数をmapメソッドで取得 ##{#p3}

非同期などで読み込んだファイルの行数をmapメソッドを使って、配列を再編成することで取得することが出来ます。
##### (方法)
1. data に渡される テキストデータを改行コードで分割
2. 行のデータを 半角スペースで分割しつつ結果を得る。

##### JS
```
//行番号を調べる(dataは非同期で読み込んだデータ)
var lines = data.split(/\r?\n/);
//var rslt = lines.map( line => line.split(" ") );//アロー関数はIE非対応のため、functionに変更
var rslt = lines.map( function(line){
	line.split(" ");
});
```

## 参考サイト ##{#p4}
* [【JavaScript入門】配列処理をするmap()の使い方とMapオブジェクトの解説！](https://www.sejuku.net/blog/21812)
* [JavaScriptのmapメソッドの使い方を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/26939)
* [javascriptでテキストファイルを一行ずつ読み込む方法](https://teratail.com/questions/230987)