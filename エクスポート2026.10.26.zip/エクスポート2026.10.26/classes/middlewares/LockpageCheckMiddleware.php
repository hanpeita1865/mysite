<?php
namespace SocymSlim\SlimMiddle\middlewares;

use PDO;
use PDOException;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use SocymSlim\SlimMiddle\Services\EditService;

class LockpageCheckMiddleware implements MiddlewareInterface
{
    private EditService $editService;

    public function __construct(EditService $editService)
    {
        $this->editService = $editService;
    }
    

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {

        $folderName = basename(
            $request->getUri()->getPath()
        );

        $motourl = $_SERVER['HTTP_REFERER'] ?? '../pages/public/guide';

        // 初期値
        $viewFlag = true;
        $lockPages = [];

        try {

            $db = $this->editService->db();

            // DB更新日時取得
            $pageArea = $request->getAttribute('pageArea');

            $stmt = $db->prepare(
                "SELECT updated_at
                FROM locklist_meta
                WHERE page_area = ?"
            );

            $stmt->execute([$pageArea]);

            $dbUpdatedAt = $stmt->fetchColumn();            

            // セッションにキャッシュが無い or 更新されている
            
            $lockUpdatedAtKey = 'lock_updated_at_' . $pageArea;
            $lockPagesKey = 'lock_pages_' . $pageArea;
            
            if (
                !isset($_SESSION[$lockUpdatedAtKey]) ||
                $_SESSION[$lockUpdatedAtKey] !== $dbUpdatedAt
            ) {
                $stmt = $db->prepare(
                    "SELECT page
                    FROM locklist
                    WHERE page_area = ?"
                );

                $stmt->execute([$pageArea]);

                $_SESSION[$lockPagesKey] = $stmt->fetchAll(PDO::FETCH_COLUMN);
                $_SESSION[$lockUpdatedAtKey] = $dbUpdatedAt;
            }

            $lockPages = $_SESSION[$lockPagesKey] ?? [];

        } catch (\Throwable $e) {

            error_log(
                '[LockpageCheckMiddleware] '
                . $e->getMessage()
            );

            // 前回sessionキャッシュを使用
            $lockPages = $_SESSION['lock_pages'] ?? [];
        }

        // 判定（try-catch外）
        $isLocked = in_array( $folderName, $lockPages, true);

        $role = $_SESSION['auth_user']['role'] ?? null;

        $isAllowed = in_array( $role, ['admin', 'editor'], true);

        // lockページのみ非表示
        $viewFlag = !($isLocked && !$isAllowed);
        

        // sessionもDBも死んでる時
        // 判定不能なら安全側
        if (
            empty($lockPages)
            && !isset($_SESSION['lock_pages'])
        ) {
            $viewFlag = true;
        }

        $request = $request
            ->withAttribute(
                'viewFlag',
                $viewFlag
            )
            ->withAttribute(
                'moto',
                $motourl
            )
            ->withAttribute(
                'folderName',
                $folderName
            );

        return $handler->handle($request);
    }
}