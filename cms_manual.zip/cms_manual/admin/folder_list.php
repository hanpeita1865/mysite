<?php
$folder_dir = glob('../p_*', GLOB_ONLYDIR); 
$folder = str_replace('../', '', $folder_dir);
