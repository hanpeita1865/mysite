*[page-title]:その他

## YouTube動画を埋め込む方法

挿入する位置を指定して、ツールバーの<img src="upload/movie.png" class="figure-none">をクリックします。

YouTube動画のURLをコピーして入力欄に貼り付け、<kbd class="border">Enter</kbd>キーを押すか、<img src="upload/チェックボタン.png" class="figure-none">ボタンをクリックします。
![](upload/URL入力.png "図　YouTube動画のURLをコピー&ペーストします")

動画が挿入されました。ただ、編集画面では再生できません。確認画面に移動すると再生することができます。  
デフォルトでは、画面サイズ 700px、中央寄せに設定しています。  
左上の<img src="upload/上にカーソル挿入.png" class="figure-none">ボタンをクリックすると、動画の上にカーソルが表示され、右下の<img src="upload/下にカーソル挿入.png" class="figure-none">ボタンをクリックすると、動画の下にカーソルが表示されます。  
![](upload/動画挿入.png)


埋め込み動画のサイズや横位置を変更したい場合は、ツールに画像の時のような機能はないので、HTMLに直接コードを追加します。  
<img src="upload/source.png" class="figure-none">ボタンをクリックし、HTMLコード表示に切り替えます。
![](upload/HTMLコード表示に切り替え.png "図　HTMLコード表示に切り替え")

その動画埋め込みコード全体を<kbd class="border">&lt;div class="～"&gt;～&lt;/div&gt;</kbd>で囲います。

左寄せにする場合は、<kbd class="border">&lt;div class="m-left"&gt;～&lt;/div&gt;</kbd>
![](upload/左寄せコード.png "図　左寄せコード")

![](upload/動画挿入左寄せ.png "図　埋め込み動画を左寄せ")

右寄せにする場合は、<kbd class="border">&lt;div class="m-right"&gt;～&lt;/div&gt;</kbd>
![](upload/右寄せコード.png "図　右寄せコード")

![](upload/動画挿入右寄せ.png "図　埋め込み動画を右寄せ")