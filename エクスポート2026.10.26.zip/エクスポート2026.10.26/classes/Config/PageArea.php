<?php

namespace SocymSlim\SlimMiddle\Config;

final class PageArea
{
    public const NORMAL = 'normal';
    public const MANUAL = 'manual';
    
    
    public static function getPageDir(string $pageArea): string
    {
        if ($pageArea === self::MANUAL) {
            return '../manual/pages';
        }

        return '../pages';
    }
    
    
    //URLのベースを取得
    public static function getUrlBase(string $pageArea, string $basePath): string
    {
        if ($pageArea === self::MANUAL) {
            return $basePath . '/public/manual/pages/';
        }

        return $basePath . '/public/pages/';
    }
    
    
    //$folderからPageAreaを取得
    public static function fromPageDir(string $pageDir): string
    {
        if ($pageDir === '../manual/pages') {
            return self::MANUAL;
        }

        return self::NORMAL;
    }
    
    //キャッシュプレフィックス取得
    public static function getMenuCachePrefix(string $pageArea): string
    {
        if ($pageArea === self::MANUAL) {
            return 'menu_manual_';
        }

        return 'menu_';
    }
    
    //管理操作系
    public static function getAdminDir(string $pageArea): string
    {
        if ($pageArea === self::MANUAL) {
            return '/public/manual/admin/';
        }

        return '/public/admin/';
    }
    

    //ページエリアの表示名を取得
    public static function getDisplayName(string $pageArea): string
    {
        if ($pageArea === self::MANUAL) {
            return 'マニュアル';
        }

        return 'メニュー';
    }

}