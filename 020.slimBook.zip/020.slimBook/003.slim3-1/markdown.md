*[page-title]:第3章Slimアプリと動作原理

サンプル資材置き場
: 「C:\xampp\htdocs\template_sample\★php\Slim\slimサンプルダウンロード\参考書」

firstslim完成品ファイル
: C:\xampp\htdocs\template_sample\★php\Slim\slim_study\trunk\firstslim

firstslim完成品サイト
: http://localhost:9810/firstslim/public/hello

<div markdown="1" class="green-box">
* Slimプロジェクトでは、プロジェクトフォルダ内にWebに公開されるpublicフォルダを作成する。
* Slimプロジェクトでは、Composer の requierre コマンドを使って、slimベンダーのslimパッケージとpsr7パッケージを配置する。
* publicフォルダ内に、.htaccessファイルとindex.phpファイルを作成する。
* index.phpには、autoload.phpの読み込み、Appインスタンスの生成、各種設定、run()メソッドの実行を記述する。
</div>

## 3-1 Slim プロジェクトを作成する

<p class="tmp"><span>書式1</span>Composerによるパッケージの登録・ダウンロード</p>
```
composer require ベンダー/パッケージ
```

まず、htdocs直下に「firstslim」フォルダを作成します。

コマンドプロンプトのディレクトリをfirstslimに移動して、下記のコマンド1を実行します。

<p class="tmp cmd"><span>コマンド1</span>Slimのパッケージダウンロード</p>
```
composer require slim/slim
```
そうすると、赤枠内のフォルダとファイルだけダウンロードされるので、  
firstslim直下に「public」フォルダを追加してやります。
![](upload/slim原本ファイルリスト1.jpg)

<p class="tmp"><span>書式2</span>バージョンを指定してダウンロードする場合</p>
```
composer require slim/slim=〇.〇
```
バージョン4.8を指定する場合は、次のように入力します。
```
composer require slim/slim=4.8
```

<p class="tmp cmd"><span>コマンド2</span>PSR-7のダウンロード</p>
```
composer require slim/psr7
```

次に、.htaccessとindex.phpを作成します。  
.htaccessファイルは、ディレクトリ単位でApacheの設定が行えるファイルになります。

<p class="tmp list"><span>リスト3-1</span>public/.htaccess</p>
```
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^ index.php [QSA,L]
```

<p class="tmp list"><span>リスト3-2</span>public/index.php</p>
```
<?php
use Slim\Factory\AppFactory;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;

require_once($_SERVER["DOCUMENT_ROOT"]."/firstslim/vendor/autoload.php");//---(1)

$app = AppFactory::create();//---(2)

//(3)
$app->get("/firstslim/public/hello",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface { //---(3-2)
		print("Hello World!"); //---(3-3)
		return $response; //---(3-4)
	}
);

$app->run();//---(4)
```


<http://localhost:9810/firstslim/public/hello>にアクセスすると、「Hello World!」と表示されます。

現状では、publicフォルダ以外のファイルもWebに公開されてしまいます。  
publicフォルダのみがWebに公開されるように、ドキュメントルートの変更は、第10章でおこないます。

**リスト3-2**で基本となるのが<span class="bold green">(2)</span> `$app = AppFactory::create();`と<span class="green bold">(4)</span> `$app->run();`です。  
Slimアプリのすべての処理の中心となるのは、Slimの本体である \Slim\<span class="green bold">App</span>クラスです。  
ということは、このAppクラスのインスタンスを用意する必要があり、その処理を担うのが \Slim\Factory\<span class="bold green">AppFactory</span> クラスです。このクラスのstaticメソッドである <span class="red bold">create() </span>を実行することで\Slim\Appクラスのインスタンスを生成してくれます。それが**リスト3-2**の<span class="green bold">(2)</span>です。

このようにして生成されたAppインスタンスに対して、そのメソッドを使いながらさまざまな設定を行っていきます。**リスト3-2**では<span class="green bold">(3)</span>でgetメソッドを実行しています。この処理は、<span class="green bold">ルーティング登録</span>と呼ばれ、Slimの一番核となる機能です。

一通り設定が行われたのち、<span class="red bold">run()メソッド</span>を実行し、実際にSlimとしての処理を走らせます。それが**リスト3-2**の<span class="green bold">(4)</span>です。

### クラスファイルを自動で読み込む autoload.php
PHPによるWebアプリケーションを作成する場合、今ではクラスを利用しないことの方がまれです。ましてやフレームワークを利用するならばなおさらです。Slimを利用する場合も同様に、さまざまなクラスを使います。これらのクラスは、通常は名前空間が付与されており、名前空間付きクラスを利用する場合は、ファイルの上部で<span class="red bold">use宣言</span>を記述します。さらに、それらのクラスが記述されたファイル類を自動で読み込むための<span class="red bold">オートロード</span>を利用します。


Composerを利用した場合、そのようなオートロードするためのファイルを自動で作成してくれます。それが、vendorフォルダ直下に作成された <span class="green bold">autoload.php</span> です。ですので、Composerを利用したプロジェクトでは、まずこのautoload.phpをrequire once() するコードを記述することになります。

それが、**リスト3-2**の<span class="green bold">(1)</span>「`require_once(･･･/firstslim/vendor/autoload.php");`」です。  
<span class="green bold">(1)</span>では、この autoload.php を確実にreqire_once()するための工夫として、PHPの定義済み変数である <span class="green bold">$_SERVER</span> を利用し、
```
$_SERVER["DOCUMENT_ROOT"]
```
としてドキュメントルートを取得しています。さらにドキュメントルートからの絶対パスとして
```
/firstslim/vendor/autoload.php
```
を記述することで、サーバー環境が変わっても確実にautoload.phpを読み込むようにしています。  
この「ドキュメントルート+そこから絶対パス」の表記方法は、パスの指定方法として利便性が高いです。


## 3-3 Slimの動作原理

<div markdown="1" class="green-box">
* Slimで、あるURLに対応した処理をさせるには、APPインスタンスのrunメソッド実行前にルーティング登録を行う必要がある
* ルーティング登録では、ルーティングパターンとコールバック関数を指定する。
* コールバック関数内に、対応するURLで行う処理を記述する。
</div>

Slimを使ったアプリケーションでは、htaccessの設定によってどのURLもindex.phpが実行される仕組みとなっています。しかし、アプリケーションの挙動としては、URLごとに処理内容が変わらないとダメです。あるURLとそれに対応した処理を関連付けることを<span class="green bold">ルーティング</span>といい、Slimでは、このルーティング登録を行うことでURLごとに処理内容を変えられるようになっています。

ルーティング登録のソースコードは、Appクラスのインスタンスを取得し、runメソッドを実行する間に記述することになっています。つまり、リスト3-2では<span class="green bold">(3)</span>「`$app->get("/firstslim/public/hello",･･･);`」が該当し、そのコードは次の書式になります。

<p class="tmp"><span>書式3</span>ルーティング登録</p>
```
$app->get(ルーティングパターン, 対応するコールバック関数);
```
(3)では、ルーティングパターンとして「`/firstslim/public/hello`」を登録しています。  
このURLへアクセスがあった場合に、続くコールバック関数が実行される仕組みとなっています。

### ルーティングコールバック関数

**リスト3-2**では <span class="green bold">(3-2)</span> が該当し、無名関数として記述しています。コールバック関数のシグネチャは、次の書式になります。

<p class="tmp"><span>書式4</span>ルーティングコールバック関数</p>
```
function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
```

このコールバック関数内の処理は、<span class="green bold">(3-3)</span>と<span class="green bold">(3-4)</span>  の2行です。(3-4)は戻り値です。先の書式にあるように、コールバック関数は <span class="red bold">ResponseInterface </span>を戻り値として返す必要があります。そこで、ここでは、引数として渡される同じ <span class="red bold">ResponseInterface</span> の <span class="red bold">$response </span>をそのままリターンしています。このコールバック関数の処理の中心は<span class="green bold"> (3-3) </span>です。コードを見れば分かるように、「**Hello World!**」と表示されるようになっています。

## 3-4 Composerの動作と使い方

<div markdown="1" class="green-box">
* composer.jsonには、そのプロジェクトで必要なパッケージを、requireキーとして記述する。
* パッケージの指定は、「ベンダー/パッケージ:バージョン」の書式となる。
* バージョンには、セマンティックバージョニングの記述方法を採用する。
* 既存の composer.json を利用する場合は、installコマンドを実行する。
</div>

先述でcomposer require によって自動生成されたファイルのひとつとして、composer.json があります。このファイルは、Composerを利用する際に一番中心となるファイルであり、そのプロジェクトで必要なパッケージを記述します。このcomposer.json の内容は次のようになっています。
<p class="tmp list"><span>リスト</span>composer.json</p>
```
{
    "require": {
        "slim/slim": "^4.8",
        "slim/psr7": "^1.4"
    }
}
```
記述中の4.8と1.4は、composer require コマンドをそれぞれ実行した時点でのバージョン番号になります。

もし、composer.json を手入力した場合、あるいは、手入力しなくても、既存のcomposer.jsonを利用する場合は、次のコマンドを実行します。

<p class="tmp"><span>書式5</span>Composerによる利用パッケージのダウンロード</p>
```
composer install
```

### Composerのその他のコマンド

ここまでで、requireとinstallとComposerコマンドをふたつ紹介しました。このふたつを含めて、主なコマンドを表3-4にまとめています。

<p class="tb-caption"><span>表3-4</span>Composer のその他のコマンド一覧</p>
| コマンド | 引数 | 内容 |
| -------- | -------- | -------- |
|  require   | パッケージ     | 引数に該当するパッケージをcomposer.jsonに追記し、そのパッケージをダウンロード|
|  install   | なし     | composer.jsonに記述されたそのパッケージをダウンロード。     |
| outdated    | なし     | 現在インストールされているパッケージのうち、更新可能なものがあるかどうかを表示。     |
| update    | なし     |  現在インストールされているパッケージを最新のものに更新。    |
| remove    | パッケージ     | 限定されたパッケージを削除。     |
| create-project    | パッケージ、  対象ディレクトリ     | GitHubなどで公開されているプロジェクトの雛形を使ってプロジェクトを作成。     |
| dump-autoload    | なし     | オートロードファイルを再構築。     |
| show    | なし     | インストール済みのパッケージを表示。     |
| help    | なし     | Composer自体の使い方リファレンスを表示。     |
| selfupdate    | なし     | Composer本体をアップデート。     |








