<template>
  <div class="container-fluid">
    <h1>Second Page</h1>
    <NuxtLink to="/">Homeへ</NuxtLink>
  </div>
</template>