---
title: ビューの使い方
media_order: 'hello_blade.png,daichi_taro.png,daichi_date.png,tanaka_ichiro.png,loop.png'
taxonomy:
    category:
        - docs
---

## テンプレートエンジンとは

HTMLコードを記述したファイルを別に用意しておきます。  
このファイルのことを「***テンプレート***」と呼びます。  
一方で、PHP側でそのテンプレートに埋め込むデータを用意しておきます。  
テンプレートエンジンは、それらを統合してHTMLレスポンスを生成する仕組みです

テンプレートエンジンを利用することで、PHP処理が書かれたファイルとHTMLコードが書かれたファイルを分離でき、PHPコード、HTMLコードそれぞれの可読性が向上します。  
さらに、HTMLコードの再利用が可能になります。

PHP言語に限定するならば、現在主流で使われているものは3個あります。

まず、なんと言っても老舗は「**Smarty**」です。さらに、Symfonyプロジェクトの1つとして作られた「**Twig**」があります。
それから、今回紹介するLaravelに同梱されている「***Blade***」です。


## Bladeの使い方の基本

### 基本はファイルの用意とreturn view()

LaravelでBladeを利用する手順は以下の通りです。

1. テンプレートファイルを*resources/viewsディレクトリ*に作成する。
2. ルーティング登録のコールバック関数で*view()関数*（の戻り値）を*return*する。


まず、手順1です。ここでは、テンプレートファイルをresources/viewsディレクトリに作成します。  
その際、拡張子は「**.blade.php**」とします。拡張子は.phpですが、内容は通常のHTMLファイルと同じように作成します。  
「**hello.blade.php**」のファイルを作成し、下記のコードを記述してみます。

```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>Bladeによるこんにちは</title>
</head>
	<body>
		<h1>こんにちは! Blade!</h1>
	</body>
</html>
```

このテンプレートを表示させるルーティングを登録します。  
ここでは、**/helloBlade**というルーティングパターンで登録するとします。  
*routes/web.php*に下記を追加します。
```
Route::get("/helloBlade", function() {
	return view("hello");
});
```

<http://localhost/laravelapp/public/helloBlade>にアクセスすると、下記の画像が表示されます。  
このサイトのコードは、hello.blade.phpに記述したHTMLのコードになります。

![](hello_blade.png)
 

## テンプレートにデータを渡すには

これで、無事テンプレートが使えるようになりました。  
とはいえ、これでは、単に静的なHTMLを表示させているのと変わりません。PHPから渡されたデータを埋め込んでこそのテンプレートエンジンです。  
そのためには、view()関数の第2引数を活用します。*routes/web.php* に以下のコードを記述します。
```
Route::get("/helloBladeWithData", function() {
	$data["name"] = "大地太郎";
	return view("helloWithData", $data);
});
```

テンプレートのresources/views/*helloWithData.blade.php* には、以下を記述します。
```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>データを埋め込んだテンプレート</title>
</head>
	<body>
		<h1>こんにちは! {{$name}}さん!</h1>
	</body>
</html>
```

h1タグの**{{$～}}**という記述が受け取ったデータを表示させている部分です。
この{{$～}}にview()の第2引数で渡された連想配列のキーを記述することで、その値が表示される仕組みです。


(*～/public/helloBladeWithData*)でアクセスすると、下記の画像のように表示されます。


![](daichi_taro.png)


なお、この{{～}}は<?= … ?>と同じだと考えてください。
ということは、この中に、簡単なPHPコードを記述できます。例えば、以下のようなものです。


<p>現在の値: {{$num + 1}}</p>

さらに、以下のように関数も記述できます。  
<p>現在の日時: {{date("Y/m/d H:i:s")}}を追記します。</p>
<http://localhost/laravelapp/public/helloBladeWithData>にアクセスすると、このように現在の日時も表示されるようになります。
![](daichi_date.png)


なお、この{{}}による表示の場合、**htmlspecialchars()関数**による**HTMLエスケープ**が自動で施されていますので、注意してください。



## viewディレクトリ内の階層構造への対応

実際のアプリ開発では、何十枚というHTML画面が使われるのが普通です。  
となると、viewディレクトリ内にサブディレクトリを作成して、階層構造でテンプレートを管理したくなります。  
その場合のview()メソッドの第1引数はどのようになるのでしょうか。例えば、テンプレートファイルが以下のファイルパスだとします。

**resources/views/chap3/hello.blade.php** 

##### hello.blade.php
```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>データを埋め込んだテンプレート</title>
</head>
	<body>
		<h1>こんばんは! {{$name}}さん!</h1>
	</body>
</html>
```

このテンプレートを利用する*routes/web.php*のルーティング登録コードは、以下のコードのようになります。  
（1）のように、viewフォルダ内の階層構造をそのまま「.」（ドット）でつなぐだけでいいです。

```
Route::get("/chap3/helloToSomeone", function() {
	$data["name"] = "田中一郎";
	return view("chap3.hello", $data);  // (1)
});
```

<http://localhost/laravelapp/public/chap3/helloToSomeone>にアクセスすると、下記のように表示されます。

![](tanaka_ichiro.png)

### 

<div class="gray-box d-block" markdown="1">

【補足】
: テンプレートファイル内にコメントを記述するには以下の書式を使います。

<p class="tmp"><span>書式</span>テンプレート内のコメント</p>
```
{{-- コメント --}}
```

</div>



## 条件分岐の基本の「if～elseif～else」の記述方法

Bladeで条件分岐などの制御構文を記述するには「***@***」を使います。

##### ifStatement.blade.php
```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>テンプレート中のif</title>
</head>
	<body>
		<p>
		@if($rand === 1)
			大吉です!<br>
			おめでとうございます!
		@elseif($rand === 2)
			中吉です!
		@else
			凶です!
		@endif
		</p>
	</body>
</html>
```

このテンプレートを表示するルーティング登録コードとして、*routes/web.php* にコードを記述します。
```
Route::get("/chap3/if", function() {
	$data["rand"] = rand(1, 3);
	return view("chap3.ifStatement", $data);
});
```

<http://localhost/laravelapp/public/chap3/if>にアクセスするごとにランダムで、「大吉です! おめでとうございます!」「中吉です!」「凶です!」と表示されます。

条件分岐には、通常のPHPコードの**if～elseif～else**の前に、***@***が付与された記述となっています。  
この@から始める記述を「**ディレクティブ**」と呼びます。

条件部分も通常のPHPコードと同じように()を使って記述します。  
ただし、条件に合致する場合の処理の範囲を表す{}は不要です。  
その代わり、@から次の@までがその条件に合致する場合に表示する範囲を表し、終端を表す**@endif**を必ず記述するようにします。


## switchによる分岐

テンプレートでの分岐には**switch文**も使えます。pタグ内を、switchを使って書き換えると以下のようになります。  
*resources/views/chap3/*内に、*switchStatement.blade.php* ファイルを作成し、コードを記述します。

##### switchStatement.blade.php
```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>テンプレート中のswitch</title>
</head>
	<body>
		<p>
		@switch($rand)
		@case(1)
			大吉です!<br>
			おめでとうございます!
			@break
		@case(2)
			中吉です!
			@break
		@default
			凶です!
		@endswitch
		</p>
	</body>
</html>
```

if～elseif～elseと同じようにswitchも通常のPHPコードの前に@がついたような形になっています。  
注意するべきなのは、caseで値を記述するところに**()**が必要なところと、**@endswitch**が必要なところです。
また、通常のPHPコード同様に**@break**の記述忘れにも注意してください。


そして、*routes/web.php* にルーティング登録コードを記述します。
```
Route::get("/chap3/switch", function() {
	$data["rand"] = rand(1, 3);
	return view("chap3.switchStatement", $data);
});
```

<http://localhost/laravelapp/public/chap3/switch>にアクセスすると、if文と同じようにランダムに大吉、中吉、凶と表示されます。


## その他便利な条件分岐の記法

Bladeにはさらに便利な条件分岐の記述が用意されています。  
否定の条件を記述する場合には、**@unlessディレクティブ**が使えます。例えば、以下の記述です。

```php
@unless($isFinished)
<p>isFinishedはfalseです。</p>
@endunless
```

ここで*$isFinished*は、*true/false*を表す変数です。この記述は以下の記述と同じ意味です。

```php
@if(!$isFinished)
<p>isFinishedはfalseです。</p>
@endif
```
@unlessディレクティブを使うと、条件を否定する「***!***」を記述する必要がなくなります。

また、変数が渡されてきた場合のみ表示するディレクティブとして**@issetディレクティブ**があります。例えば、以下の記述です。

```php
@isset($isFinished)
<p>isFinished変数は存在します。</p>
@endisset
```

これは、PHPの関数「**isset()**」と同じなので、使い方としては以下の記述と同じです
```
@if(isset($isFinished))
```

同様に、empty()関数と同じ使い方ができる**@emptyディレクティブ**もあります。使い方としては以下の記述になります。

```php
@empty($resultList)
<p>resultListは空です。</p>
@endempty
```


## ループの記述方法

ループの記述も条件分岐同様、通常のPHPコードの前に@を付与したディレクティブを使います。例えば、**forループ**は以下の記述になります。

```
<ol>
	@for($i = 1; $i <= 5; $i++)
	<li>{{$i}}個目</li>
	@endfor
</ol>
```

**@endfor**の記述を忘れなければ、forの()内の記述は通常のPHPコードと同じです。

同じように**foreach**も使えます。ここでは、ルーティング登録のコールバック関数内で、例えば、以下の連想配列をテンプレートに渡すとします。
```
$data["resultList"] = ["A"=>"田中", "B"=>"中野", "C"=>"野村"];
```

この連想配列をforeachでループさせながら表示する記述は、以下のようになります。
```
<ul>
	@foreach($resultList as $key => $value)
	<li>{{$key}}は{{$value}}です</li>
	@endforeach
</ul>
```

foreachでも()内の記述は通常のPHPコードと同じです。  
さらに、**whileループ**も使えます。例えば、以下のコードです。
```
@while(true)
<p>無限ループ</p>
@endwhile
```
このコードは、無限ループになってしまいます。


## ループ中の変数$loop

Bladeでループディレクティブを使う場合、ループ内だけ「**$loop**」という特殊な変数が使えます。  
この変数を使うと、現在のループに関するさまざまな値を取り出すことができます。  
表にどのような値が取り出せるかまとめておきます。

##### $loopでの取得値 {.t-caption}
|記述|取得できる値	|
|--|--|
|$loop->iteration| 	現在の繰り返し回数（1始まり）。|
|$loop->index|  	いわゆるインデックス値。0始まりの値で、繰り返し回数を-1したもの。|
|$loop->remaining| 	残りの繰り返し回数。|
|$loop->count|  	ループ対象の配列の要素数。|
|$loop->first| 	最初の繰り返しかどうか。|
|$loop->last| 	最後の繰り返しかどうか。|
|$loop->depth|  	ループの入れ子（ネスト）の階層数。|
|$loop->parent| 	ループが入れ子になっている場合、親ループの$loop変数。|


これらの変数を使って、例えば下記のように記述することが可能です。  
*resources/views/chap3/*フォルダに、*loopVariables.blade.php* を作成し、記述してみます。

##### loopVariables.blade.php
```
～省略～
<ul>
	@foreach($resultList as $key => $value)
	<li>
		@if($loop->first)
		ループの始まりです。<br>
		@endif
		{{$loop->iteration}}回目: {{$key}}は{{$value}}です。
		@if($loop->last)
		<br>ループの終わりです。
		@endif
	</li>
	@endforeach
</ul>
～省略～
```


このテンプレートに対してルーティングコールバック関数で以下の連想配列を渡してあげるとします。
*routes/web.php*に以下を追記します。
```
Route::get("/chap3/loop", function() {
	$data["resultList"] = ["A"=>"田中", "B"=>"中野", "C"=>"野村", "D"=>"村井", "E"=>"井田"];
	return view("chap3.loopStatement", $data);
});
```

<http://localhost/laravelapp/public/chap3/loop>にアクセスすると、以下のように表示されます。

![](loop.png)

