*[page-title]:配列同士で重複する値があるか確認する

参考サイト
: [きるこの日記帳　配列同士で重複する値があるか確認する](https://www.dkrk-blog.net/javascript/duplicate_an_array)
: [配列同士の比較し中身が一致するか判定](https://shanabrian.com/web/javascript/is-array-equal.php)

## 重複を確認

### filterを使う

確認するだけなら<span class="bold red"> filter</span> でできる。

2 つの配列を 1 つにまとめて、filter で配列その 1 とその 2 どちらにも含まれる値だけを抽出する。  
重複する値がないと空の配列になるので、length と合わせて 0 かどうか判定する。

<iframe src="https://paiza.io/projects/e/u7xqkhaLuqJx8IDy1dTUjA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## 重複のみ取りだす


<iframe src="https://paiza.io/projects/e/9FPtOd_jlm7DYLTY-DURvQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<span class="bold green marker">Set</span>

集合。 配列などの iterable オブジェクトを渡すと、重複しない値のコレクションをオブジェクトとして返す。
```
console.log(duplicatedArr) // [ 'apple', 'pen', 'apple', 'pen' ]
```
これを配列にして出せば終わり。

```
console.log([...new Set(duplicatedArr)]) // [ 'apple', 'pen' ]
```

