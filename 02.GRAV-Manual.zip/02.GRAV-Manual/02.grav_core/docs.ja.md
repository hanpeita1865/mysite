---
title: 最初からGRAV本体を設置する
media_order: 'grav_core_admin.png,grav_first_account.png,dashborde.png,theme_add_btn_.png,theme_list.png,theme_direct_install.png,theme_active_haywire_.png,theme_download_haywire.png,haywire_demo.png,haywire_page.png,daichi_accout.png,lang_ja.png'
taxonomy:
    category:
        - docs
---

## GRAV本体設置

ローカルにGRAVを設置するには、まず**{c:red}XAMPP{/c}**をインストールする必要があります。  
勉強会で作成した下記のサイトを参考にインストールしてみてください。

勉強会XAMPPリンク

GRAV本体と管理画面がセットになっているファイルをまずはダウンロードします。

![](grav_core_admin.png)

ダウンロードして解凍したファイル（grav-admin）を　**C: / XAMPP / htdocsフォルダ**　に設置してください。 

それでは設置したサイトをローカルで表示してみます。  
**http://localhost/grav-admin/**

他の人も見れるようにするには、localhostの箇所を自身のIPアドレスに変えてください。  
**http://IPアドレス/grav-admin/**

XAMPPでポート番号を設定してる場合は、IPアドレスのあとにポート番号をつけてください。  
**http://IPアドレス:ポート番号/grav-admin/**

サイトを開く前に、ユーザーのアカウント設定画面が出ます。

![](grav_first_account.png)

それぞれを入力し、「ユーザーを作成」ボタンをクリックしてください。  
ただし、パスワードは、少なくとも1つの数字、小文字、大文字を含む8文字以上で設定する必要があります。

そうすると、最初に管理画面のダッシュボードが表示されます。  

![](dashborde.png)

{c:blue}青枠{/c}で囲っている箇所をクリックすると、サイトが別ウィンドウで表示されます。

{c:green}緑枠{/c}で囲っている「テーマ」をクリックすると、登録しているテーマが表示されます。  
デフォルトでは、テーマは「Quark」のみになっています。

上図で{c:red}赤枠{/c}で囲っている左上のロゴ、ユーザー名、タイトルがある箇所をクリックすると、ユーザーページが開き、先ほど設定したアカウントが確認できます。  

#### ユーザーページ #### {.mb-0} 
**{c:red}管理画面の言語変更{/c}**  
言語を「日本語」に変更します。
![](daichi_accout.png?classes=mt-0)

#### 設定 - サイトページ #### {.mb-0} 
**{c:red}lang属性の言語変更{/c}**  
設定→サイト→規定の言語で「ja」を入力します。
![](lang_ja.png?classes=mt-0)


## テーマ追加

テーマ設定画面を開きます。  
右上の「追加ボタン」![](theme_add_btn_.png?classes=d-inline,my-0)をクリックすると、テーマのリストが表示され、「インストールボタン」を押すと、そのテーマがインストールされます。  
![](theme_list.png)

ただ、**{c:red}シンクラだと通信に制限がかかるのでテーマのリストは表示されません。{/c}**テーマリストの箇所は真っ白になっているはずです。  
ですので、下記のGRAV公式サイトからテーマを直接ダウンロードし、 インストールしてやります。

[GRAV公式サイトテーマダウンロードページ](https://getgrav.org/downloads/themes?target=_blank&classes=my-0)


試しに、「Haywire」をダウンロードしたとします。
![](theme_download_haywire.png)

robbinworks-haywire-grav-0.4.4-0-g1e666b3.zip　がダウンロードされたら、「ツール」-「Direct install」のページを開き、下図の緑枠内にあるファイルの選択でテーマのzipファイルを選択し、「Upload and Install」ボタンをクリックします。　
![](theme_direct_install.png)
画面上部に「インストールが成功しました。」の文字が表示されたら、インストールは完了です。

テーマ設定画面を開きなおすと、「Haywire」のテーマが新しく登録されていると思います。  
「Haywire」の画像下の「アクティベート」ボタンをクリックすると切り替え確認画面が出ます。  
「続ける」をクリックすると、そのテーマがアクティブに切り替わります。  
（**/user/config/system.yaml**　のファイルの27行目あたりの **theme: Haywire**　に変更されます。ここでもテーマを切り替えられます。）
![](theme_active_haywire_.png)

サイトを開きなおすと、表示が少し変わったのがわかると思います。

今は / user /pageフォルダにあるmdファイルなどは、「Quark」テーマ用のものなので、「Haywire」用のデモページに変更します。    
/ user / themes / **{c:blue}haywire{/c}** / _demo / **pages** のフォルダを今ある　/ user / **pages** と差し替えてやります。
そうしてサイトを更新すると、下の画像のようなサイトが表示されます。
![](haywire_demo.png)

ページを編集するには、「ページの管理」画面を開き、個々のページのリンクをクリックすると、そのページの編集画面が表示されるのでその画面で編集を行います。

![](haywire_page.png)


ページの追加や編集などについては、下記のページを見てください。

* [フォルダやページの追加/削除](../operation)
* [マークダウン記法について](../markdown-00)









