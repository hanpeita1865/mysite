---
title: 特定の要素があるか判定
taxonomy:
    category:
        - docs
---


```
<div class="hoge"></div>
```
.hogeが存在するかどうかを試してみます。

```// パターン1
if(document.getElementsByClassName('hoge').length) {
    console.log("document.getElementsByClassName('hoge').length の結果: true");
} else {
    console.log("document.getElementsByClassName('hoge').length の結果: false");
}
 
// パターン2
if(document.querySelector('.hoge')) {
    console.log("document.querySelector('.hoge') の結果: true");
} else {
    console.log("document.querySelector('.hoge') の結果: false");
}
 
$(function() {
    // パターン3
    if($('.hoge')[0]) {
        console.log("$('.hoge')[0] の結果: true");
    } else {
        console.log("$('.hoge')[0] の結果: false");
    }
 
    // パターン4
    if($('.hoge').length) {
        console.log("$('.hoge').length の結果: true");
    } else {
        console.log("$('.hoge').length の結果: false");
    }
});
```

## 参考サイト

* [要素が存在するかどうか調べる](https://cly7796.net/blog/javascript/check-if-an-element-exists/)
* [jQueryで特定の要素が存在するかどうかを判別する処理【.length】](http://black-flag.net/jquery/20150324-5622.html)