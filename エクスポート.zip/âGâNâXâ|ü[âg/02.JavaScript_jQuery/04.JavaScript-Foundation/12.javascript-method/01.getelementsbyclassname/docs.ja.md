---
title: （移動済）getElementsByClassName
taxonomy:
    category:
        - docs
---

「getElementsByClassName()」は、対象となるクラス名が設定されているHTML要素をすべて取得できるメソッドになります。


## 「getElementsByClassName()」の使い方

<p class="tmp"><span>書式1</span></p>
```
document.getElementsByClassName( クラス名 );
```

<p class="tmp exp"><span>例1</span></p>
<iframe width="100%" height="450" src="//jsfiddle.net/t3L8bqsn/3/embedded/js,html,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


・・・途中・・・

## 参考サイト

* [getElementsByClassName()でクラス名からHTML要素を複数取得する方法](https://www.sejuku.net/blog/68588)