<h3>フォルダ直下内のファイル名をすべて表示</h3>
 <?php
    foreach (glob('upload/*.*') as $file) {
        $file_name = basename($file);//ファイル名だけを抜き出す
        echo '<li><span class="filename">'.$file_name.'</span></li>';
    }
?>

<h3>拡張子を指定</h3>
<?php
	foreach(glob('upload/{*.docx,*.pdf}',GLOB_BRACE) as $file){
        $file_name = basename($file);//ファイル名だけを抜き出す
        echo '<li><span class="filename">'.$file_name.'</span></li>';
	}
?>



<h3>フォルダ内にある直下のフォルダ名だけを表示</h3>
<?php
	//$dir = 'upload/';
	$folder = glob('upload/*', GLOB_ONLYDIR);

	foreach ($folder as $dir) {
		echo '<li><span class="filename">'.$dir.'</span></li>';
	}
?>

<h3>指定したディレクトリ配下のファイル名をすべて表示</h3>
<?php
	function globAll($folder) {
		// 指定されたディレクトリ内の一覧を取得
		$files = glob($folder.'/*');

		// フォルダ内ループ
		foreach ($files as $file) {
			// ファイルかどうか判定
			if (is_file($file)) {
				// ファイルならそのまま出力
				echo $file . "<br />";

			} else {//フォルダの場合、再度glob関数で中身を取得
				globAll($file);
			}
		}
	}

	// 最初にディレクトリを指定する
	globAll('upload');
?>

<h3>scandir()でで指定したディレクトリ内のファイル・ディレクトリ一覧を取得する</h3>
<?php
	$dir = 'upload';
	$files = scandir($dir);

	var_dump($files);
?>