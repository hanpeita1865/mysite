<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MarkdownService,
};
use SocymSlim\SlimMiddle\Config\AppConfig;
use SocymSlim\SlimMiddle\Factory\ParsedownFactory;
use SocymSlim\SlimMiddle\Services\Markdown\HtmlSanitizer;
use SocymSlim\SlimMiddle\Services\Markdown\HtmlPathRewriter;
use SocymSlim\SlimMiddle\Config\PageArea;//追加



class DraftController extends BaseController
{
    private EditService $editService;
    private FolderService $folderService;
    private MarkdownService $markdownService;
    private AppConfig $config;
    private ParsedownFactory $parserFactory;
    private HtmlSanitizer $sanitizer;
    private HtmlPathRewriter $pathRewriter;
    
    public function __construct(
        EditService $editService, 
        FolderService $folderService,
        MarkdownService $markdownService, 
        AppConfig $config,
        ParsedownFactory $parserFactory,
        HtmlSanitizer $sanitizer,
        HtmlPathRewriter $pathRewriter        
    ) 
    {
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->markdownService = $markdownService;
        $this->config = $config;
        $this->parserFactory = $parserFactory;
        $this->sanitizer     = $sanitizer;
        $this->pathRewriter  = $pathRewriter;        
    }
    
   

    //-----------------------------
    // 下書き設定　temporaryにコピー
    //-----------------------------

    public function draft_set(Request $request, Response $response, array $args): Response
    {
        $folderObj = $this->folderService->getFolderComp();
        $parsedBody = $request->getParsedBody();

        
        if (
            empty($parsedBody['csrf_token']) ||
            empty($_SESSION['csrf_token']) ||
            !hash_equals($_SESSION['csrf_token'], $parsedBody['csrf_token'])
        ) {
            $payload = [
                'success' => false,
                'message' => 'CSRFエラー'
            ];

            $response->getBody()->write(
                json_encode($payload)
            );

            return $response
                ->withHeader('Content-Type', 'application/json')
                ->withStatus(403);
        }
        
        $fdName = $parsedBody['folderName'] ?? '';
        $title = $parsedBody['title'] ?? '';
               
        if (empty($fdName) || !isset($folderObj[$fdName])) {

            return $this->json($response, [
                "success" => false,
                "message" => "フォルダが存在しません",
            ]);
        }
        
        $folderDir = $folderObj[$fdName];
        
        $tempDir = '../temporary/'.$fdName;
        
        // ログインユーザーID
        $createdBy = $_SESSION['auth_user']['user_id'] ?? null;
        
        
        try {

            $result = $this->folderService->createDraft(
                $folderDir,
                $tempDir,
                $fdName,
                $title,
                $createdBy
            );

            return $this->json($response, $result);

        } catch (\Throwable $e) {

            return $this->json($response, [
                "success" => false,
                "message" => "下書き作成に失敗しました",
            ]);
        }
    }

    

    //---------------------
    // 下書き一覧画面
    //---------------------

    public function draftList(Request $request, Response $response, array $args): Response
    {
        $basePath = $this->config->basePath;
        $twig = $this->editService->view();              
        
        $role = $_SESSION['auth_user']['role'] ?? 'guest';
        
        $userId = $_SESSION['auth_user']['user_id'] ?? null;      
        
        $db = $db = $this->editService->db();
        
        $sql = '
            SELECT *
            FROM draft_list AS dl
            JOIN users AS u
                ON dl.created_by = u.user_id
        ';

        $params = [];

        // editorは自分の下書きのみ
        if ($role === 'editor') {
            $sql .= ' WHERE dl.created_by = ?';
            $params[] = $userId;
        }

        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        $draftList = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        
        $folderName = basename($request->getUri()->getPath());
        
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        
        $success = $_SESSION['success'] ?? null;
        unset($_SESSION['success']);
        
        $pageArea = $request->getAttribute('pageArea');//追加
        $pageAreaName = PageArea::getDisplayName($pageArea);//追加
        
        $assign = [
            'isUser' => isset($_SESSION['auth_user']),
            'pathBase' => $basePath,
            'drafts' => $draftList,
            'csrf' => $_SESSION['csrf'],
            'success' => $success,
            'folderName' => $folderName,
            'role' => $role,
            'pageArea' => $pageArea,//追加
            'pageAreaName' => $pageAreaName,//追加
        ];

        $response = $twig->render($response, "draft_list.twig", $assign);

        return $response;        
    }
    
    

    //---------------------
    // 下書き削除
    //---------------------
        
    public function draftDelete(Request $request, Response $response, array $args)
    {
        $basePath = $this->config->basePath;
        
        $data = $request->getParsedBody();
        $fdName = $data['fdName'] ?? '';
        $title = $data['title'] ?? '';
        $csrf = $data['csrf'] ?? '';
        
        $errors = [];
        
        
        // CSRFチェック（使い捨て）
        if (!isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $csrf)) {
            $errors[] = '不正なリクエストです';
        }
        
        unset($_SESSION['csrf']);
        
        // フォルダ名チェック　追加
        if ($fdName === '') {
            $errors[] = 'フォルダ名が不正です';
        }

        if ($errors) {
            $_SESSION['errors'] = $errors;

            return $response
                ->withHeader('Location', $basePath . '/public/admin/draft_list')
                ->withStatus(302);
        }
        
        $db = $this->editService->db();
        
        try {
            //対象のフォルダを削除
            
            $db->beginTransaction();

            // 対象フォルダ
            $targetDir = '../temporary/' . $fdName;

            // ディレクトリ削除
            if (is_dir($targetDir)) {

                $result = $this->folderService
                    ->removeDirectory($targetDir);

                if (!$result) {
                    throw new \RuntimeException(
                        'ディレクトリ削除失敗'
                    );
                }
            }

            // draft_list 削除
            $sql = " DELETE FROM draft_list WHERE folder_name = :folder_name ";

            $stmt = $db->prepare($sql);

            $stmt->execute([
                ':folder_name' => $fdName
            ]);

            // user_page_permissions 削除
            $sql = " DELETE FROM user_page_permissions WHERE page_folder = :page_folder ";

            $stmt = $db->prepare($sql);

            $stmt->execute([
                ':page_folder' => $fdName
            ]);

            $db->commit();
            
        } catch (\Throwable $e) {

            if ($db->inTransaction()) {
                $db->rollBack();
            }

            $_SESSION['errors'] = ['削除に失敗しました'];

            // 開発中だけ推奨
            error_log($e->getMessage());

            return $response
                ->withHeader(
                    'Location',
                    $basePath . '/public/admin/draft_list'
                )
                ->withStatus(302);
        }

        $_SESSION['flash']
            = '「' . $title . '」ページの下書きを削除しました';

        return $response
            ->withHeader(
                'Location',
                $basePath . '/public/admin/draft_list'
            )
            ->withStatus(302);
    }
    


    //---------------------
    // 下書きページ表示
    //---------------------

    public function draftMarkData(Request $request, Response $response, array $args): Response
    {
        $basePath = $this->config->basePath;
        $siteName = $this->config->siteName;

        try {

            $path = rtrim($request->getUri()->getPath(), '/');
            $folderName = basename($path);
            
            $folderPathObj = $this->folderService->getFolderPathComp('../pages', $basePath);//追加
            
            $baseDir = realpath($this->config->rootPath . '/temporary');
            $targetDir = realpath($baseDir . '/' . $folderName);
            
            // パストラバーサル対策 + 存在チェック
            if ($targetDir === false || strpos($targetDir, $baseDir) !== 0) {
                $assign["errorMsg"] = "存在しないページです。";
                $templatePath = "error.twig";

                $twig = $this->editService->view();
                return $twig->render($response, $templatePath, $assign);
            }
            
            $markdownFile = $this->config->rootPath .'/temporary/'. $folderName . '/markdown.md';

            $md = file_get_contents($markdownFile);
            
            // ページタイトルを抽出
            preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
            $title = $ArrayTitle[1] ?? '';
            
            //customの存在チェック 追加
            $folderPath = '/temporary/'. $folderName;
            $assign['folderPath'] = $folderPath;

            $customJsPath = $this->config->rootPath .'/temporary/'. $folderName . '/js/custom.js';
            $customCssPath = $this->config->rootPath .'/temporary/'. $folderName . '/css/custom.css';

            if(file_exists(($customJsPath))){
                $assign['customJs'] = true; 
            }

            if(file_exists(($customCssPath))){
                $assign['customCss'] = true; 
            }

            // 更新日　追加
            $updateDay = '';

            if (preg_match("/^\*\[update-day\]:\s*(.+)/m", $md, $ArrayDay)) {
                $updateDay = trim($ArrayDay[1]) ?? '';
            }

            $date = \DateTime::createFromFormat('Y-m-d', $updateDay);

            if ($date === false || $date->format('Y-m-d') !== $updateDay) {
                $updateDay = '';
            }            
            
            
            $parser = $this->parserFactory->create();
            
            // HTML変換
            $htmlData = $parser->text($md);
            //スクリプトタグなど除去
            $htmlData = $this->sanitizer->sanitize($htmlData);
            //src、hrefのパスを生成
            $htmlData = $this->pathRewriter->rewrite($htmlData, '/temporary/'. $folderName);            
                        
            $text = strip_tags($htmlData);
            $text = preg_replace('/\s+/u', '', $text);
            
            $assign["htmlData"] = $htmlData;
            $assign["title"] = $title;
            $assign["updateDay"] = $updateDay;//追加
            $assign["pathBase"] = $basePath;
            $assign["siteName"] = $siteName;
            $templatePath = "draft_page.twig";
            $assign["redirect"] = $path;
            $assign["folderName"] = $folderName;
            $assign["folderDir"] = '../temporary/'.$folderName;
            $assign["isLogin"] = $request->getAttribute('isLogin');
            $assign["canEdit"] = $request->getAttribute('canEdit');
            $assign["userName"] = $request->getAttribute('userName');
            $assign["canView"] = $request->getAttribute('canView');
            $assign["pageDir"] = $folderPathObj[$folderName]['url'] ?? null;//元ページ
        }

        catch (PDOException $ex) {
            $assign["errorMsg"] = "表示できません。";
            $templatePath = "error.twig";
        }       

        $twig = $this->editService->view();
        
        $response = $twig->render($response, $templatePath, $assign);
        
        return $response;
    }    
    
    
    
    //---------------------
    // 下書き編集画面表示
    //---------------------

    public function draftEdit(Request $request, Response $response, array $args): Response
    {
        $basePath = $this->config->basePath;  
        
        $data = $request->getQueryParams() ?? [];
        $redirect = $data['redirect'] ?? null;        
        $folder = $request->getAttribute('folder') ?? null;
        
        
        try {

            $mkData = file_get_contents('../temporary/'. $folder . '/markdown.md');
            $twig = $this->editService->view();           
            $filelist = $this->folderService->uploadList('../temporary/'. $folder);
            
            $assign["pathBase"] = $basePath;
            $assign["mkData"] = $mkData;
            $assign["edit"] = $data['edit'];
            $assign["folder"] = $folder;
            $assign["folderPath"] = $data['folderPath'];
            $assign["scroll"] = $data['scroll'];
            $assign["motourl"] = $redirect;
            $assign["fileList"] = $filelist;
            $assign["folderDir"] = '../temporary/'. $folder;

            $response = $twig->render($response, "draft_edit.twig", $assign);
            
        } catch (Exception $ex) {
            echo $ex->getMessage();
            exit;
        }
            
        return $response;
    }
    
    
    //---------------------
    // 下書きをサイトに反映
    //---------------------

    public function draftReflected(
        Request $request,
        Response $response,
        array $args
    ): Response
    {
        $basePath = $this->config->basePath;
        $folderObj = $this->folderService->getFolderComp();
        $parsedBody = $request->getParsedBody();

        $fdName = trim($parsedBody['fdName'] ?? '');
        $title = $parsedBody['title'] ?? '';

        // バリデーション
        if ($fdName === '') {
            throw new \InvalidArgumentException(
                'フォルダ名未指定'
            );
        }

        if (
            !preg_match(
                '/^[a-zA-Z0-9_\-]+$/',
                $fdName
            )
        ) {
            throw new \InvalidArgumentException(
                '不正なフォルダ名'
            );
        }

        if (!isset($folderObj[$fdName])) {
            throw new \InvalidArgumentException(
                'フォルダが存在しません'
            );
        }

        // ディレクトリ

        // pages側
        $targetDir = $folderObj[$fdName];

        // temporary側
        $tempDir = '../temporary/' . $fdName;

        // backup側
        $backupDir = '../backup/'
            . $fdName
            . '_'
            . date('YmdHis');

        // history側
        $historyDir = '../history/'
            . $fdName
            . '_'
            . date('YmdHis');


        // ディレクトリ存在確認
        if (!is_dir($targetDir)) {
            throw new \RuntimeException(
                'コピー先ディレクトリが存在しません'
            );
        }

        if (!is_dir($tempDir)) {
            throw new \RuntimeException(
                '下書きディレクトリが存在しません'
            );
        }

        if (!is_writable($targetDir)) {
            throw new \RuntimeException(
                '書き込み不可'
            );
        }


        $db = $this->editService->db();

        try {

            $db->beginTransaction();

            // pages側バックアップ
            $this->folderService->copyDir(
                $targetDir,
                $backupDir
            );

            // temporary → newコピー
            $newDir = $targetDir . '_new';

            $this->folderService->copyDir(
                $tempDir,
                $newDir
            );

            // pages削除
            $this->folderService->deleteDir(
                $targetDir
            );

            // new → pagesへ差し替え
            if (!rename($newDir, $targetDir)) {

                throw new \RuntimeException(
                    '差し替え失敗'
                );
            }
            

            // page_list 更新　追加
            $markdownFile = $targetDir . '/markdown.md';

            if (!file_exists($markdownFile)) {

                throw new \RuntimeException(
                    'markdown.md が存在しません'
                );
            }

            $md = file_get_contents($markdownFile);

            if ($md === false) {

                throw new \RuntimeException(
                    'markdown.md の読み込みに失敗しました'
                );
            }
            
            $this->markdownService->updatePageText($db, $fdName, $md);
                     
 
            // temporary → historyへ移動
            if (!rename($tempDir, $historyDir)) {

                throw new \RuntimeException(
                    '履歴保存に失敗'
                );
            }

            // draft_list 削除
            $sql = "
                DELETE FROM draft_list
                WHERE folder_name = :folder_name
            ";

            $stmt = $db->prepare($sql);

            $stmt->execute([
                ':folder_name' => $fdName
            ]);

            // user_page_permissions 削除
            $sql = "
                DELETE FROM user_page_permissions
                WHERE page_folder = :page_folder
            ";

            $stmt = $db->prepare($sql);

            $stmt->execute([
                ':page_folder' => $fdName
            ]);

            // commit
            $db->commit();

            // backup削除
            if (is_dir($backupDir)) {

                $this->folderService->deleteDir(
                    $backupDir
                );
            }

        } catch (\Throwable $e) {

            // rollback
            if ($db->inTransaction()) {
                $db->rollBack();
            }

            // pages復元
            if (is_dir($backupDir)) {

                if (is_dir($targetDir)) {

                    $this->folderService->deleteDir(
                        $targetDir
                    );
                }

                rename($backupDir, $targetDir);
            }

            // newDir削除
            if (
                isset($newDir) &&
                is_dir($newDir)
            ) {

                $this->folderService->deleteDir(
                    $newDir
                );
            }

            // ログ
            error_log($e->getMessage());

            // ユーザー通知
            $_SESSION['errors']
                = ['反映に失敗しました'];

            return $response
                ->withHeader(
                    'Location',
                    $basePath . '/public/admin/draft_list'
                )
                ->withStatus(302);
        }

        // 完了
        $_SESSION['success']
            = '「' . $title . '」ページをサイトに反映しました';

        return $response
            ->withHeader(
                'Location',
                $basePath . '/public/admin/draft_list'
            )
            ->withStatus(302);
    }

}