<?php
namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Container\ContainerInterface;

$basePath = '/from_now_slim1';

class MemberController {
    // コンテナインスタンス
    private $container;

    // コンストラクタ
    public function __construct(ContainerInterface $container) {
        // 引数のコンテナインスタンスをプロパティに格納。
        $this->container = $container;
    }


    //マークダウン変換
     public function markData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        global $basePath;

        //PDOインスタンスをコンテナから取得
        $db = $this->container->get("db");

        $ipAddress = $_SERVER["REMOTE_ADDR"];//取得したIPアドレス
        $folderName = basename($_SERVER['REQUEST_URI']);//フォルダ名

        //URL中のパラメータを取得
        $folder = $args["folderName"];

        $assign["folder"] = $folder;

        if(empty($_SERVER['HTTP_REFERER'])){
            //echo '未定義';
            $motourl = '../pages/p__base/';
        }else{
            $motourl = $_SERVER['HTTP_REFERER'];//遷移元のURL
        }

        $sql_page = $db->prepare('select * from locklist where page=?');
        $sql_page->execute([$folderName]);

        $countPage=$sql_page->rowCount();

        $sql_ip = $db->prepare('select * from admin_ip where ip_address=?');
        $sql_ip->execute([$ipAddress]);

        $countIp=$sql_ip->rowCount();

        //閲覧不可ページリスト
        $stmt = $db->prepare('select page from locklist');
        $stmt->execute();
        $lockArray = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $assign["lockArray"] = $lockArray;

        $assign["countIp"] = $countIp;

        if($countPage!=0 && $countIp==0 ) {
            header('Location:'. $motourl, true, 307);
            $flag = 0;//閲覧不可
            exit;
        }

        //フォルダ構成をオブジェクトで取得
        $folderObj = $this->container->get("folderComp");

        //マークダウン変換インスタンスをコンテナから取得
        $markData = $this->container->get("mark");

        $htmlData = $markData['html'];//HTMLデータ

        $title = $markData['title'];//タイトル

        $assign["folderObj"] = $folderObj;//フォルダ構成オブジェクト
		$assign["htmlData"] = $htmlData;
		// $assign["pathBase"] = "/from_now_slim1/public/";
		$assign["pathBase"] = $basePath;
        $assign["title"] = $title;//タイトル格納

        //$assign["flg"] = 0;//テスト

        // Twigインスタンスをコンテナから取得。
        $twig = $this->container->get("view");
        // memberAdd.htmlをもとにしたレスポンスオブジェクトを生成。
        $response = $twig->render($response, "base.twig", $assign);
        //$response = $twig->render($response, "test1.twig", $assign);//連想配列受け渡しテスト

        // レスポンスオブジェクトをリターン。
        return $response;
    }

}