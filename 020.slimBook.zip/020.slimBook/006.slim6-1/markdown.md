*[page-title]:第6章コンテナとDI1

5章では、Slimとテンプレートエンジン Twig を連携させる方法から、Twigの使い方まで扱いました。その際、まずTwigインスタンスを取得する必要があることを紹介しました。このようにSlimを利用していくと、外部クラスのインスタンスを取得する場面が多々出てきます。そのようなインスタンスの生成処理をまとめておけるものとして、<span class="green bold">コンテナ</span>というものがあります。6章では、コンテナを扱うことのメリットとその使い方を紹介します。

## 6-1. コンテナとその使い方の基本

<div markdown="1" class="green-box">
* コンテナは、インスタンスの生成処理関数をまとめるための仕組み。（コンテナを導入することで、インスタンス生成処理関数をまとめたファイルを別に作成する必要がなくなります。）
* Slimでコンテナを利用するには、別パッケージとしてPHP-DIを導入する。
* Slimでコンテナを利用するには、Appインスタンス生成の前にContainer クラスをnewし、AppFactory::setContainer()メソッドに渡す。
* PHP-Diにインスタンス生成処理を登録するには、set()メソッドを使う。
* コンテナからインスタンスを取得するには、get()メソッドを使う。
</div>

### コンテナとは
SlimでTwigを利用しようとした場合、毎回 Twigクラスのインスタンスを生成する必要があります。その際、引数としてテンプレートファイルフォルダパスを渡す必要があります。また、必要に応じて第2引数として環境設定を連想配列として渡します。となると、ルーティングコールバック関数にボイラープレートコースをリターンする関数をどこかに作成する方法もあります。

では、こういったインスタンスを生成する関数は、どこに生成すればいいのでしょうか。例えば、インスタンス生成の関数をまとめたファイルを作成する方法もあるでしょう。あるいは、ひとつの static メソッドの形でまとめてしまう方法もあります。

一方、コンテナを導入する方法もあります。<span class="green bold">コンテナ</span>は、このようなインスタンスの生成処理関数をまとめるための仕組みです。コンテナを導入することで、インスタンス生成処理関数をまとめたファイルを別に作成する必要がなくなります。

さらに、それだけではなく、このコンテナを使うことで、クラス間の依存の問題の解決にもつながっていきます。こちらについては6-5節で解説します。

### サンプルプロジェクトの作成

slimcontainerフォルダを作成し、そのディレクトリで、composer require コマンドを実行し、下記のパッケージを配置します。

* slim/slim
* slim/psr7
* slim/twig-view

まず、publicフォルダ内に前項と同じ「.htaccess」を設置します。

次に、public内にindex.phpを配置し、下記のコードを記述します。
<p class="tmp list"><span>リスト6-1</span>index.php</p>
```
<?php
use Slim\Factory\AppFactory;
require_once($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/vendor/autoload.php");
$app = AppFactory::create();
require_once($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/routes.php");
$app->run();
```

slimcontainer直下に routes.phpを配置し、下記のコードを記述します。
<p class="tmp list"><span>リスト6-2</span>routes.php</p>
```
<?php
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;

$app->setBasePath("/slimcontainer/public");
```

### コンテナの利用に必要なパッケージ

Slimにはコンテナ機能は標準では含まれていません。コンテナそのものは外部パッケージを利用するようになっています。利用するパッケージは**<span class="text-green"> PHP-DI</span>** です。  
これをプロジェクトに追加する必要があります。「slimContainer」フォルダで次のコマンドを実行してください。

<p class="tmp cmd"><span>コマンド</span> PHP-DIを導入</p>
```
composer require php-di/php-di
```
そうするとなぜかエラーがでてしまいます。
![](upload/php-di_error.png)

エラー文を翻訳すると、以下になります。

php-di / php-di [6.3.0、...、6.3.4]にはpsr / container ^ 1.0が必要です-> psr / container [1.0.0、1.1.0、1.1.1]が見つかりましたが、パッケージは修正されています 部分更新により2.0.1（ロックファイルバージョン）になり、そのバージョンが一致しません。 必ずupdateコマンドの引数としてリストしてください。
     -ルートcomposer.jsonにはphp-di / php-di ^ 6.3が必要です-> php-di / php-di [6.3.0、...、6.3.4]で満足できます。

オプション--with-all-dependencies（-W）を使用して、現在特定のバージョンにロックされているパッケージのアップグレード、ダウングレード、および削除を許可します。


この場合、次のコマンドを実行します。
```
composer require php-di/php-di --with-all-dependencies
```
成功すると以下のように表示され、comporser.json にはphp-di が追記されます。
![](upload/php-di_success.png)

<p class="tmp">comporser.json</p>
```
{
    "require": {
        "slim/slim": "^4.8",
        "slim/psr7": "^1.4",
        "slim/twig-view": "^3.2",
        "php-di/php-di": "^6.3" //追加される
				
    }
}
```
これで、PHP-DI が利用できるようになりました。

<p class="fz-08"><span class="green bold">注）</span>Slimのバージョン3まではコンテナ機能が含まれていましたが、バージョン4で切り離し、外部パッケージを利用する方法に変わっています。</p>
### Slim でコンテナを利用する方法

Slimでコンテナを利用するコードは、APPインスタンスの生成処理の前に記述することになっています。これは、index.phpに対して、オートロードファイルの読み込みと AppFactory::create() の間に記述することを意味します。  
index.phpに記述しても動作しますが、index.phpのコードが肥大化してしまうので、別ファイルとして記述し、index.phpではそれを読み込むことにします。

index.phpにその読み込みコードとして、リスト6-3の1行を追記します。&#x1f600;

<p class="tmp list"><span>リスト6-3</span>public/index.php</p>
```
<?php
use Slim\Factory\AppFactory;
require_once($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/vendor/autoload.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/containerSetups.php"); //←これを追記する
$app = AppFactory::create();
～省略～
```

<p class="tmp list" id="6-4"><span>リスト6-4</span>containerSetups.php</p>
```
<?php
use DI\Container;
use Slim\Factory\AppFactory;
use Slim\Views\Twig;

$container = new Container();  //･･･(1) インスタンス生成
$container->set("view",  //･･･(2) インスタンス生成処理関数の登録処理
    function() {
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/templates");  //･･･(3) 
        return $twig;  //･･･(3) 
    }
);
AppFactory::setContainer($container);  //･･･(4) インスタンスを登録
```
リスト6-4の(1)と(2)がコンテナを利用するためにまず必要な処理です。  
(1)はコンテナ本体クラスである\DI\<span class="green bold">Container</span> インスタンスを生成しています。このクラスこそ、まさにPHP-DI で用意されたクラスです。

そして、そのインスタンスを、コンテナとしてSlimで利用するために登録します。その処理が (4) であり、Slimの本体である Appインスタンスを生成するクラスであるAppFactoryのstaticメソッドである <span class="green bold">setContainer()</span> を利用します。このように、

<span class="red bold">コンテナ本体のインスタンス生成</span> ➡ <span class="red bold">Slimへのそのインスタンスを登録</span>

という処理を経ることで、Slim内でコンテナを利用できるようになります。  
書式としてまとめると、次のようになります。
<p class="tmp"><span>書式1</span>Slimでコンテナを利用する方法</p>
```
$container = new Container();
～省略～
AppFactory::setContainer($container);

```

### コンテナへの登録方法

リスト6-4 (2)の「$container->set("view",～」では、インスタンス生成処理関数の登録処理を行っています。  
書式としては、以下になります。
<p class="tmp"><span>書式2</span>PHP-DIのコンテナにインスタンス生成処理を登録</p>
```
$container->set("インスタンス名", インスタンス生成処理関数);
```
リスト6-4では、第1引数のインスタンス名には「view」としています。  コンテナからインスタンスを取得する際にこのインスタンス名を使います。  
第2引数には、インスタンス生成処理関数として無名関数を使用しています。

これで、コンテナからインスタンスを取得する準備が整いました。


### コンテナからインスタンスを取得する方法

コンテナからインスタンスを取得する準備が整ったところで、実際に取得してみます。  
これは、Twigインスタンスを利用する場面での、ルーティングコールバック関数内の記述となります。  
routes.phpに下記コードを追記して下さい。

<p class="tmp list" id="6-5"><span>リスト6-5</span>routes.php</p>
```
<?php
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;

$app->setBasePath("/slimcontainer/public");

$app->any("/helloWithContainer",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$assign["name"] = "コンテナ";
        $twig = $this->get("view"); //･･･(1)
		$response = $twig->render($response, "helloWithVals.html", $assign);
		return $response;
	}
);
```
リスト6-5のコードは、前頁の[リスト5-7](../p__slim5-1/#list5-7)のroutes.phpとほぼ同じコードです。違いはルーティングパターンやテンプレート変数、そして(1)です。
helloWithVals.htmlのテンプレートは、slimviewで使ったのと同じコードになります。（[リスト5-6](../p__slim5-1/#list5-6)）  
templatesフォルダを作成し、その中にそのままhelloWithVals.htmlファイルごとコピーして設置してください。

<p class="tmp list"><span>リスト</span>templates/helloWithVals.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>テンプレート変数</title>
</head>
    <body>
        <h1>こんにちは! {{name}}さん!</h1>
    </body>
</html>
```
http://localhost:9810/slimcontainer/public/helloWithContainer にアクセスして動作を確認してください。  
以下のように表示されれば、OKです。

![](upload/helloWithContainer.png)


リスト6-5のroutes.phpで、前項のリスト5-7と一番違うのは、`$twig = $this->get("view");` の部分です。  
リスト5-7では、Twigインスタンスを取得するために、Twigクラスのcreate()メソッドを実行するコードを以下のように直接記述していました。  
```
$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimview/templates");
```
リスト6-5の(1)では、コンテナから取得し、それを変数 $twig としています。  
この(1)のように、コンテナからインスタンスを取得するには、コールバック関数内で次の書式を記述します。

<p class="tmp"><span>書式3</span>コンテナからインスタンスを取得</p>
```
$this->get("インスタンス名")
```

get() メソッドの引数として渡すのは、set()メソッドの第1引数として指定したインスタンス名です。  
リスト6-4の(2)では viewというインスタンス名で登録したので、リスト6-5の(1)では同じviewを指定しています。

補足で、このコールバック関数内に記述した$this という変数は、コンテナそのものを指します。つまり、先の書式は、コンテナのメソッド get()を呼び出すことで、指定したインスタンスを取得していることになります。

## 6-2. Slimとコンテナの関係

ここでは、コンテナというものをもう少し掘り下げ、Slimとコンテナとの関係の種明かしをしていきます。

<div markdown="1" class="green-box">
* コンテナに関する仕様は、PSR-11 として定義されている。
* PHP-DI の Container クラスはPSR-11のContainerInterface インターフェースを実装したクラスである。
* Slimでは、PSR-11 を実装したコンテナならばどれでも利用できるが、PHP-DIを推奨している。
</div>


### get()メソッドの正体

コンテナを利用するために[リスト6-4](#6-4)で new している Container クラスというのは、PHP-DIで用意されたクラスです。

となると、リスト6-5 のコールバック関数内で利用しているコンテナ本体を表す $this というのは、その実態は PHP-DI で用意された Container インスタンスということになり、[リスト6-5](#6-5)の(1)で実行している getメソッド   
` $twig = $this->get("view");`　というのは Containerクラスのメソッドといえます。

実は、get()メソッドがContainer クラスのメソッドである、というのは半分が正しく、半分が間違っています。というのは、このContainer クラスというのは、\Psr\Container\<span class="green bold">ContainerInterface</span> インターフェースを実装しているからです。

get() メソッドというのは、ContainerInterface インターフェースに定義されたメソッドであり、Container クラスというのは、そのインターフェースを実装したにすぎません。

この \Psr\Container\ <span class="text-green text-bold">ContainerInterface</span> インターフェースというのは、4-2項で紹介したPHPの標準化団体 PHP-FIG でPSR-11 として定義されたインターフェースです。PSRでは、NO.11としてこのようなインスタンス生成を管理するコンテナに関するインターフェースが定義されています。

このインターフェースには、表6-1のメソッドが2個定義されています。


<p class="tb-caption"><span>表6-1</span>ContainerInterfaceに定義されたメソッド</p>
| メソッド | 内容 | 
| -------- | -------- |
| get()     | 引数で渡されたインスタンス識別子でインスタンスを返すメソッド     |
| has() | 引数で渡されたインスタンス識別子が存在するかどうかを返すメソッド|

このことから、必要に応じて、例えば次のように「インスタンス取得が可能かどうか」を事前に確認するコードを記述することができます。

```
if($this->has("view")) {
```

### Slimが連携するコンテナは PSR-11

Slimと連携できるコンテナは、PSR-11を実装している必要があります。  
PSR-11を実装していれば、PHP-DI以外のコンテナを利用することも可能になりますが、Slimでは、PHP-DIを利用することを推奨しています。

## 6-3. コンテナを経由した引数

コンテナはインスタンス生成処理をまとめておけるものです。このインスタンスを生成するときの引数について、もう少し話を掘り下げていきます。

<div markdown="1" class="green-box">
* インスタンス生成処理関数が外部から値を受け取るには、引数を記述する。
* 引数が記述されたインスタンス生成処理関数は、\DI\value() で囲む必要がある。
* コンテナ経由で引数が記述されたインスタンス生成処理関数に、引数を渡すには call()メソッドを利用する。
* call()メソッドの第2引数に、配列の形で引数に渡す値を記述する。
</div>

### インスタンス生成処理関数に引数を設定する

コンテナ内でインスタンスを生成する際、リスト6-4の(3)  
`$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/templates");`のように引数を渡すことが多々あります。リスト6-4の(3)では create()メソッドの引数ですが、new によるインスタンス生成でも次のように引数を渡すことが考えられます。

```
$note = new Note("中田");
```

リスト6-4の(3)のように、この引数がインスタンス生成処理関数内で用意できる場合は、set() メソッドによる登録と get() メソッドによるインスタンス取得の組み合わせで問題ありません。しかし、インスタンス生成するクラスの作り方によっては、インスタンス生成処理関数内では引数の値が用意できず、ルーティングコールバック関数内で渡す必要があるものも出てきます。その場合は、set() によるインスタンス生成処理関数の登録方法が少し変わってきます。

コードで確認しておきましょう。  
まず、コンストラクタが記述されたクラスサンプルとして、次のリスト6-6のNoteクラスを用意します。
<p class="tmp list"><span>リスト6-6</span>slimcontainer/Note.php</p>
```
<?php
class Note
{
    public function __construct(string $name)
    {
        print("引数".$name."でNoteクラスのインスタンスが生成されました。");
    }
}
```
コンストラクタに引数が設定されているので、このNoteクラスをnewする際は引数を渡す必要があります。その前提でNoteクラスインスタンスを生成する処理をコンテナに登録しましょう。リスト6-7のコードをcontainerSetups.phpに追記して下さい。  
なお、Noteクラスをuseさせずにクラスファイルを直接require_once()しているのは、リスト5-10と同じ理由で、現段階ではこの方法を使ってるだけで、独自に作成したクラスのオートロードの方法は第7章で扱います。

<p class="tmp list"><span>リスト6-7</span>slimcontainer/containerSetups.php</p>
```
～省略～
require_once($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/Note.php");
$container->set("note", 
    \DI\value(function(string $name) { //･･･(1)
        $note = new Note($name); //･･･(2)
        return $note;
    })
);
AppFactory::setContainer($container);  //･･･ インスタンスを登録
```

リスト6-7の(2)ではNoteクラスをnewする際に引数を渡しています。ただし、その引数はインスタンス生成処理関数内で用意するのではなく、リスト6-7の(1)にあるようにインスタンス生成処理関数の引数として定義し、そのまま渡すようにしています。このように、インスタンス生成処理関数に引数を設定しておけば、外部から値をもらうことができるようになります。ただし、ひとつおまじないが必要です。それが、インスタンス生成処理関数そのものを引数として受け取っている \DI\value() 関数です。

これはおまじないとしておいても問題ないですが、少し補足しておきます。PHP-DIでは、set()メソッドを設定するインスタンス生成処理関数は、自動的にPHP-DIのファクトリ機能を利用したものへと解釈し直されてしまう仕組みがあります。ファクトリ機能を利用すると、関数に定義された引数が利用できなくなります。このファクトリへと変換しないようにする関数が、\DI\value() なのです。

ですので、<span class="red bold">インスタンス生成処理関数に引数を定義する場合は、関数全体を \DI\value() で囲む</span>と思っておいてください。  
書式は次のようになります。
<p class="tmp"><span>書式</span>インスタンス生成処理関数に引数を定義する場合</p>
```
$container->set("インスタンス名", \DI\value(インスタンス生成処理関数));
```

### コンテナ経由で引数を渡すメソッド call()

次は、コンテナ経由でインスタンスを取得する際に引数を渡す方法です。  
この場合、先に説明したget()メソッドは使えず、代わりに、<span class="green bold">call() </span>メソッドを次の書式で利用します。

<p class="tmp"><span>書式4</span>コンテナ経由で引数を渡しながらインスタンスを取得</p>
```
$this->call("インスタンス名", 引数が格納された配列);
```
route.phpに次のリスト6-8のコードを追記して下さい。

<p class="tmp list"><span>リスト6-8</span>routes.php</p>
```
～省略～
$app->any("/newNote",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$name = "中田";
		$note = $this->call("note", [$name]); //･･･(1)
		return $response;
	}
);
```
追記したら、  
http://localhost:9810/slimcontainer/public/newNote にアクセスして動作確認を行ってください。

「引数中田でNoteクラスのインスタンスが生成されました。」と表示されると思います。

リスト6-8では、(1)が実際に<span class="green bold">call() </span>を利用しているコードです。事前に「中田」という値で用意した変数$name を格納しています。

### call() の第2引数は必ず配列

リスト6-7のインスタンス生成処理関数の引数はひとつでしたが、もちろん次のように複数記述できます。
```
$container->set("note", 
    \DI\value(function(string $name, int $vols) {
        :
	})
);
```
このインスタンスを利用する場合、call()メソッドの第2引数には、インスタンス生成処理関数の引数の順番通りに引数を格納します。例えば、次のようなコードとなります。 <span class="red bold">うまく設定できなかった。どう書けばいいかわからない。</span>
```
$note = $this->call("note", ["竹倉", 5]);
```
このように記述すると、インスタンス生成処理関数の第1引数 $name には「竹倉」が、第2引数 $vols には5が渡されます。

このように、複数の引数にも対応するように call()メソッドの第2引数は配列となっているのです。

なお、たとえ引数がひとつだとしても、リスト6-8の(1)のように必ず配列の形で渡す必要があります。もし、これを次のように配列以外の記述にするとエラーとなるので注意してください。
```
$note = $this->call("note", $name);
```

## 6-4. Slimでログを扱う方法

ここまで紹介してきたコンテナですが、インスタンス生成をまとめておくことによってさらなる利点があります。それについて、ログの利用方法を題材に紹介したいと思います。そのために、まず、Slimでログを扱う方法について先に紹介します。

<div markdown="1" class="green-box">
* Slimで詳細なログ編書き出しを行うには Monolog を利用する。
* Monologを利用するには、Loggerインスタンスを生成、ハンドラインスタンスを生成。
* Loggerインスタンスにハンドラを設定の3ステップで行う。
* ログへの書き出しは、それぞれのログレベルに対応したメソッドを使う。
</div>

### SlimではMonolog利用する

実運用を想定したWebアプリケーションではログへの書き出しは必須です。すべての不具合、障害はログを通じてでないと原因究明がほぼ不可能だからです。そのログへの書き出し機能として、Slimには簡単なものしか含まれていません。より詳細なログへの書き出しを行いたい場合、別ライブラリを利用します。Slimで推奨しているのは、<span class="green bold">Monolog</span>の利用です。実際に、slimcontainerでMonologを利用できるようにしていきましょう。
<p class="tmp cmd"><span>コマンド</span>Monologパッケージ追加</p>
```
composer require monolog/monolog
```

<p class="tmp list"><span>リスト6-9</span>slimcontainer/containerSetups.php</p>
```
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
～省略～
$container->set("logger",
	function() {
		$logger = new Logger("slimcontainer"); //･･･(3)
		$fileHandler = new StreamHandler($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/logs/app.log"); //･･･(4)
		$logger->pushHandler($fileHandler); //･･･(5)
		return $logger;
	}
);

AppFactory::setContainer($container);//このコードの前に記入
```
<p class="tmp list"><span>リスト6-10</span>routes.php</p>
```
$app->any("/writeToLog",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$logger = $this->get("logger");
		$logger->info("ログに書き出しました。"); 
		$content = "ログへの書き出し実験";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
);
```

-----------------------------------------------------------------
追記が終了したら、次のURLにアクセスしてください。

http://localhost:9810/slimcontainer/public/writeToLog

ただし、念のためにあらかじめ slimcontainer フォルダ内にlogsフォルダを作成しておきましょう。

URLにアクセスすると、「ログへの書き出し実験」と表示されます。

さらにlogsフォルダ内にapp.logが生成されてるはずです。そのファイルには、次のように記述されていれば、成功です。
```
[2021-10-11T00:28:15.030683+02:00] slimcontainer.INFO: ログに書き出しました。 [] []
```

### Monologの準備3ステップ

1. <span class="green bold">Loggerインスタンスの生成</span>　～　下記のリスト6-9の(3)が該当します。
```
$logger = new Logger("slimcontainer");
```
Monologの本体クラスは、\Monolog\Loggerです。このクラスをnewすることでインスタンスを生成できます。その際、引数としてログで記述内容を識別するため文字列を渡します。  
リスト6-9では、アプリ名である「slimcontainer」を渡しています。
2. <span class="green bold">ハンドラインスタンスの生成</span>　～　
ステップ1でインスタンスを生成した\Monolog\Loggerクラス自身は、ログへの書き出し機能が含まれていません。ログへの書き出し機能はそれ専用のクラス（これをハンドラといいます）に任せます。つまり分業です。  
そのハンドラクラスのうち、ファイルへの書き出しを行ってくれるクラスが\Monolog\Handler\StreamHandlerクラスです。そのStreamHamdlerクラスをnewしているのがリスト6-9の(4)の次のコードです。
```
$fileHandler = new StreamHandler($_SERVER["DOCUMENT_ROOT"]."/slimcontainer/logs/app.log");
```
<p class="tb-caption"><span>表6-2</span>Monologの主なハンドクラス</p>
～記入まだ。時間のある時に記入～

3. <span class="green bold">Loggerへのハンドラの設定</span>

次のコードが該当します。
```
$logger->pushHandler($fileHandler);
```
Monolog本体であるLoggerクラスにハンドラクラスを登録するには、<span class="green bold">pushHandler()</span>メソッドを利用します。  
なお、このpushHandler()メソッドは複数回記述することができます。つまり、複数のハンドラを登録することができるようになります。  
例えば、リスト6-9で利用しているStreamHandlerと表6-2にもあるNativeMailerHandlerの2個を登録しておくことで、ログファイルに記録すると同時に、メールを送信する、といったことが可能となります。これは、Loggerクラスとハンドラクラスを分業させていることによるもうひとつのメリットといえます。

### ログに書き出す際はログレベルを意識する

～時間ある時に記入～

### Monologの標準ログフォーマット

～時間ある時に記入～

次のMonologの公式ドキュメントに詳細が記載されています。
https://github.com/Seldaek/monolog/blob/main/doc/01-usage.md


## 6-5.コンテナの本当の役割

<div markdown="1" class="green-box">
* コンテナの最大の利点は、クラス間依存関係を実行時までずらすことができること。
* 依存関係を実行時までずらすことを、依存性注入、英語でDependency Injection（DI）という。
</div>

### クラスを直接newすることの問題点

前節で紹介したログは実運用では必須の機能です。ですので、アプリの様々な箇所にログへの書き出しコードを埋めていきます。特に例外処理でのcatchブロックなどでは必須といえます。  
ここで、例えば、リスト6-10の(1)の段階でコンテナからインスタンスを取得するのではなく、次のようにLoggerをnewする処理を直接記述したとします。

```
$logger = new Logger("slimcontainer");
$fileHandler = new StreamHandler(･･･);
$logger -> pushHandler($fileHandler);
```
そして、この$loggerを使ってログへの書き出し処理を記述していたとします。実運用ではこの記述でとりあえず問題ありません。  
一方、テスト段階、特に個々のメソッドが想定通りに動作するかをチェックする単体テスト（ユニットテスト）では、ログへの書き出し機能は不要となります。むしろ、ログファイルが肥大化し、そちらのメンテナンスが大変になります。ところが、先の例のようにLoggerクラスをnewするコードを直接記述していると、本運用では使用するが、テストでは使用しないという切り替えができなくなります。

これは、何もLoggerクラスに限ったことではありません。5章で導入したTwigクラスもそうです。ルーティングコールバック関数内であるクラスをnewするということは、その時点でそのクラスに<span class="green bold">依存</span>することになるのです。そして、そのクラスに依存する限り、本運用とテストで処理を切り替えるということが簡単にできなくなります。


### コンテナと依存性注入

このような依存の問題解決するのに都合がいい仕組みが、本章で紹介してきたコンテナなのです。例えば、リスト6-10でLoggerインスタンスを取得するコードは次のものでした。
```
$Logger = $this->get("logger");
```
この記述では、コンテナへの登録処理コードがLoggerクラスをnewしてリターンしているのをしっているだけに、確かに$loggerはMonologのloggerインスタンスを表すと思えます。しかし、ここでもし、登録処理のコードを次のように差し替えたとします。
```
$container->set("logger", 
	function() {
		$logger = new DummyLogger();
		return $logger;
	}
};
```

ここで登場したDummyloggerクラスは、

～時間ある時に記入～








