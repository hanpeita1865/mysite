Vue.createApp({
  methods: {
    onclick(message) {
      console.log(message);
    }
  }
}).mount('#app');