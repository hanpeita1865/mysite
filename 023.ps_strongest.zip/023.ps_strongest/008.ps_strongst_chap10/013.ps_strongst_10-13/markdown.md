*[page-title]:10-13. モザイクや水晶などピクセル状にしてみよう

## カラーハーフトーンフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-13-1.jpg)](upload/10-13-1.jpg){.image}
</div>


## その他のフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-13-2.jpg)](upload/10-13-2.jpg){.image}
</div>