Vue.createApp({
  data() {
    return {
      os: ['Windows', 'macOS']
    };
  }
}).mount('#app');