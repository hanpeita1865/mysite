*[page-title]:pandas Multiindex

参考サイト
: [pandas Multiindex図解で解説｜基本構造・変更・追加・解除・並べ替え](https://www.yutaka-note.com/entry/pandas_multiind_set)

## はじめに

pandasでは、インデックス列を階層構造にしてMultiindexとして扱うことができます。

MultiindexのDataFrame, Seriesはデータの階層構造が視覚的にも把握しやすく、データの集計・分析が効率的に行える場合があります。

一方で、Multiindexでは次のような問題に直面することも…

* 普段使わないからMultiindexの中身がよくわからない
* どうやってMultiindexを設定・解除するの？
* インデックスを変更、入れ替え、ソートする方法は？

この記事では、これらの問題を解決するためにMultiindexの基本構造、設定・解除方法、変更・入れ替え・ソートについてわかりやすく図解付きで解説していきます。

## Multiindexの基本構造

まずはMultiindexの構造を整理していきましょう。  
Multiindexは、次のようにインデックスまたはカラムが複数設定されているものです。

![](upload/Multiindexの例インデックスが2つの場合.png)

Multiindexは、公式ドキュメントではHierarchical indexing（階層的インデックス）とも呼ばれています。  
外側のインデックスが最上位階層で大枠的なグルーピング、内側に行くほど細かなグルーピングになっていくわけですね。  
サンプルコードでMultiindexのDataFrameを生成してみましょう。

<p class="tmp list"><span>リスト</span></p>
```
import pandas as pd
import numpy as np

# インデックスがMultiindexの例
mult_index = pd.MultiIndex.from_product([["Apple", "Banana", "Carrot"], ["ShopA", "ShopB"]],
                                        names=["Item", "Shop"])

df = pd.DataFrame({2020:[1,2,3,4,5,6], 2021:[10,20,30,40,50,60]},
                  index=mult_index)
#               2020  2021
# Item   Shop             
# Apple  ShopA     1    10
#        ShopB     2    20
# Banana ShopA     3    30
#        ShopB     4    40
# Carrot ShopA     5    50
#        ShopB     6    60
```
<p class="result"><span>結果</span></p>
![](upload/リスト1のNotebook結果表示.png)

df.Tで実行すると、次のようにカラムがMultiidexになります。
![](upload/リスト1dfTのNotebook結果表示.png)

この記事内では、インデックスがMultiindexの例を取り上げますが、カラムの場合もほぼ同様です。


## Multiindexの構成要素

まずはMultiindexの重要な構成要素を確認していきましょう。

Multiindexの各インデックスは、levelと呼ばれる連番が振られています。

一番外側からlevel = 0, 1, 2,…　または  
一番内側からlevel = -1, -2, -3,…  
通常は、level=0,1,2を使うことが多いと思います。

また、各インデックスにはインデックス名を設定することも可能です。

![](upload/Multiindexの構成要素図.png)

Multiindexの操作をする際は、基本的にlevelかインデックス名を指定することになります。

【参考】階層ごとにデータを集計する.groupby()については、次の記事を参考にして下さい。  
[pandas groupbyでグループ化｜図解でわかりやすく解説](https://www.yutaka-note.com/entry/pandas_groupby)

## Multiindexを設定

DataFrameやSeriesにMultiindexを設定する方法を紹介します。

主に次の３パターンで設定することができます。

1. ファイル読み込み時に設定
2. 既存DataFrameをMultiindex化
3. DataFrame生成時にMultiindex化

以下では、各パターンについて順番に紹介していきます。

### ファイル読み込み時に設定

実務レベルでは、ファイル読み込み時にMultiindex化することが多いと思います。

CSV, Excel読み込み時、引数index_colをリスト等で指定すると、Multiindex化できます。

* index_col = ["列番号１", "列番号２", …]　または
* index_col = ["ラベル名１", "ラベル名２", …]　（←こちらは.read_csv()のみ）

.read_csv(), .read_excel()メソッドの細かい使用方法は次の記事を参考にしてください。

* [pandas | read_csv() 図解でわかりやすく解説！](https://www.yutaka-note.com/entry/pandas_read_csv)
* [pandas | read_excel() 図解でわかりやすく解説！](https://www.yutaka-note.com/entry/pandas_read_excel_1)

以下では次のサンプルファイルで、Multiindex関連の挙動を確認してみます。
![](upload/sampleMultiData.png)

まずは、index_col="インデックス名"で、シングルインデックスを設定してみましょう。
<p class="tmp list"><span>リスト</span>Singleindexの例</p>
```
import pandas as pd

df_single = pd.read_csv("SampleData.csv", index_col="Item")
#          Shop  2020  2021
# Item                     
# Apple   ShopA     1    10
# Apple   ShopB     2    20
# Banana  ShopA     3    30
# Banana  ShopB     4    40
# Carrot  ShopA     5    50
# Carrot  ShopB     6    60
```
<p class="result"><span>結果</span></p>
![](upload/SampleData取得.png)
![](upload/SingleIndexの例.png)

次にindex_col=["インデックス名"のリスト]で、Multiindex化して読み込みます。

<p class="tmp list"><span>リスト</span>Multiindexの例</p>
```
import pandas as pd

df_multi = pd.read_csv("SampleData.csv", index_col=["Item", "Shop"])
#               2020  2021
# Item   Shop             
# Apple  ShopA     1    10
#        ShopB     2    20
# Banana ShopA     3    30
#        ShopB     4    40
# Carrot ShopA     5    50
#        ShopB     6    60
```

<p class="result"><span>結果</span></p>
![](upload/SampleData取得shop.png)
![](upload/Multiindxの例.png)

インデックスの順番は、index_col = ["ラベル名１", "ラベル名２", …]に与えたラベル名順番で設定されます。  
今度は順序を変えて、["Shop", "Item"]の順番で読み込んでみましょう。

<p class="tmp list"><span>リスト</span>Multiindexの例2</p>
```
df_multi = pd.read_csv("SampleData.csv", index_col=["Shop", "Item"])
#               2020  2021
# Shop  Item              
# ShopA Apple      1    10
# ShopB Apple      2    20
# ShopA Banana     3    30
# ShopB Banana     4    40
# ShopA Carrot     5    50
# ShopB Carrot     6    60
```

<p class="result"><span>結果</span></p>
![](upload/Multiindxの例2.png)

<span class="red bold">表のShopとitemの並び順が前のリストと同じまま。なぜ・・</span>


.read_excel()でのMultiindex化も同様です。  
ただし、read_excel()は、ラベル名を指定できないので、0から始まる列番号で指定しましょう。
<p class="tmp list"><span>リスト</span>Multiindex Excel取得</p>
```
df_multi = pd.read_excel("SampleData.xlsx", index_col=[0, 1])
# NG: df_multi = pd.read_excel("SampleData.xlsx", index_col=["Item", "Shop"])

#               2020  2021
# Item   Shop             
# Apple  ShopA     1    10
#        ShopB     2    20
# Banana ShopA     3    30
#        ShopB     4    40
# Carrot ShopA     5    50
#        ShopB     6    60
```

<p class="result"><span>結果</span></p>
![](upload/SampleData取得Excel.png)
![](upload/Multiindex_Excel.png)

### 既存dfをMultiindex化

既存dfをMultiindex化する場合は、.set_index()で複数のカラム名を指定します。

既存のインデックスにインデックスを追加する場合は、append=Trueを指定します。

* 既存インデックスを置き換え → .set_index(["カラム名"のリスト])
* 既存インデックスに追加　　 → .set_index("カラム名", append=True)

次のサンプルdfで挙動を確認してみます。
<p class="tmp list"><span>リスト</span>サンプルDataFrame</p>
```
df = pd.DataFrame({"Item": ["Apple", "Apple", "Banana", "Banana", "Carrot", "Carrot"], 
                   "Shop": ["ShopA", "ShopB", "ShopA", "ShopB", "ShopA", "ShopB"],
                   2020:[1,2,3,4,5,6],
                   2021:[10,20,30,40,50,60]})

#      Item   Shop  2020  2021
# 0   Apple  ShopA     1    10
# 1   Apple  ShopB     2    20
# 2  Banana  ShopA     3    30
# 3  Banana  ShopB     4    40
# 4  Carrot  ShopA     5    50
# 5  Carrot  ShopB     6    60
```

<p class="result"><span>結果</span></p>
![](upload/サンプルDataFrame.png)

次にappend=Trueを指定して、既存インデックスに追加してみます。

<p class="tmp list"><span>リスト</span>Multiindex化 append=True</p>
```
df.set_index(["Item", "Shop"], append=True)
#                 2020  2021
#   Item   Shop             
# 0 Apple  ShopA     1    10
# 1 Apple  ShopB     2    20
# 2 Banana ShopA     3    30
# 3 Banana ShopB     4    40
# 4 Carrot ShopA     5    50
# 5 Carrot ShopB     6    60
```

<p class="result"><span>結果</span></p>
![](upload/Multiindex_append=True.png)

既存インデックスの内側にインデックスが追加されていますね。

【参考】通常のインデックスの設定について、次の記事を参考にしてください。

[ pandas インデックス名の設定・変更｜パターン別にわかりやすく解説](https://www.yutaka-note.com/entry/pandas_index_setting)


## 新規df生成時にMultiindex化

Multiindexオブジェクトを自前で作成して、DataFrameをMultiindex化することも可能です。

次の手順でDataFrame生成時にMultiindexを適用しましょう。

1. multi_index=pd.Multiindex.各種関数()
2. pd.DataFrame(データ, index=multi_index)

Multiindexを生成する関数は次のとおりです

|生成方法	|関数名	|引数例|
| :--: | :--: | :--: |
|インデックス要素のタプル |	.from_tuples()|	from_tuple引数例 リスト～|
|インデックス要素の配列	| .from_arrays()|	from_array引数例 リスト～|
|複数配列の全ての組合せ	| .from_product()|	from_product引数例 リスト～|
|既存dfの要素	| .from_frame()|	from_dataframe引数例 リスト～|

インデックス名を設定するには、引数namesで指定します。

names=["インデックス名のリスト"]

各種関数の使用例を見てみましょう。

.from_tuples()で、各データ行ごとのインデックスの組合せをタプルで指定する例です。

<p class="tmp list"><span>リスト</span>.from_tuples()でMultiindex作成</p>
```
mult_index = pd.MultiIndex.from_tuples([("Apple", "ShopA"), ("Apple",  "ShopB"),
                                        ("Banana","ShopA"), ("Banana", "ShopB"),
                                        ("Carott","ShopA"), ("Carott", "ShopB")],
                                        names=["Item", "Shop"])
df = pd.DataFrame(
    {2020:[1,2,3,4,5,6], 2021:[10,20,30,40,50,60]} ,index=mult_index)
#               2020  2021
# Apple  ShopA     1    10
#        ShopB     2    20
# Banana ShopA     3    30
#        ShopB     4    40
# Carott ShopA     5    50
#        ShopB     6    60
```

<p class="result"><span>結果</span></p>
![](upload/from_tuplesでMultiindex結果.png)

.from_array()で、各インデックス要素を配列形式で指定する例です。

<p class="tmp list"><span>リスト</span>.from_array()でMultiindex化</p>
```
mult_index = pd.MultiIndex.from_arrays([["Apple", "Apple", "Banana", "Banana", "Carrot", "Carrot"],
                                        ["ShopA", "ShopB",  "ShopA",  "ShopB",  "ShopA",  "ShopB", ]])
df = pd.DataFrame(
    {2020:[1,2,3,4,5,6], 2021:[10,20,30,40,50,60]}
    ,index=mult_index)
#               2020  2021
# Apple  ShopA     1    10
#        ShopB     2    20
# Banana ShopA     3    30
#        ShopB     4    40
# Carott ShopA     5    50
#        ShopB     6    60
```

<p class="result"><span>結果</span></p>
![](upload/from_arrayでMultiindex結果.png)

.from_product()で、複数配列を渡してその組合せからMultiindexを設定する例です。

<p class="tmp list"><span>リスト</span>.from_product()でMultiindex化</p>
```
mult_index = pd.MultiIndex.from_product([["Apple", "Banana", "Carrot"],
                                         ["ShopA", "ShopB"]], 
                                         names=["Item", "Shop"])
df = pd.DataFrame(
    {2020:[1,2,3,4,5,6], 2021:[10,20,30,40,50,60]}, index=mult_index)
#               2020  2021
# Apple  ShopA     1    10
#        ShopB     2    20
# Banana ShopA     3    30
#        ShopB     4    40
# Carott ShopA     5    50
#        ShopB     6    60
```

<p class="result"><span>結果</span></p>
![](upload/from_productでMultiindex結果.png)