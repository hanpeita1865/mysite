---
title: その他参考になるサイト
taxonomy:
    category:
        - docs
---

[注意！IE11で使えない最新JavaScritコード（ES6）](https://blog.capilano-fw.com/?p=1273)

[非同期通信のまとめ($.ajax,fetch,axiosなど)](https://skill-up-engineering.com/2020/06/20/%E9%9D%9E%E5%90%8C%E6%9C%9F%E9%80%9A%E4%BF%A1%E3%81%AE%E3%81%BE%E3%81%A8%E3%82%81-ajaxfetchaxios%E3%81%AA%E3%81%A9/)

[Promiseを使う](https://developer.mozilla.org/ja/docs/Web/JavaScript/Guide/Using_promises)

[IE11でJavaScriptエラー「Promiseが定義されていません」が出た時の対処法](https://naoya-ono.com/blog/ie11-promise-error/)

[JavaScript イベントハンドラ一覧](https://web-designer.cman.jp/javascript_ref/event_list/)

[JavaScript Array.forEachとjQuery.eachの違い](https://qiita.com/PianoScoreJP/items/07491c4c8a4714679f32)

[【JavaScript】親要素・親ノードを取得する【parentElement・parentNode】](https://into-the-program.com/get-parent-element/)

[クラス名（class属性の値）の存在を判定](https://shanabrian.com/web/javascript/has-class.php#:~:text=%E3%83%84%E3%82%A4%E3%83%BC%E3%83%88-,%E3%82%AF%E3%83%A9%E3%82%B9%E5%90%8D%EF%BC%88class%E5%B1%9E%E6%80%A7%E3%81%AE%E5%80%A4%EF%BC%89%E3%81%AE%E5%AD%98%E5%9C%A8%E3%82%92%E5%88%A4%E5%AE%9A,%E3%83%A1%E3%82%BD%E3%83%83%E3%83%89%E3%82%92%E4%BD%BF%E7%94%A8%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)


[jQueryで子要素のイベントを親要素に伝えないようにする方法](https://pisuke-code.com/jquery-stop-event-spread/)  
<https://codepen.io/pisuke-code/pen/jvmKRV>