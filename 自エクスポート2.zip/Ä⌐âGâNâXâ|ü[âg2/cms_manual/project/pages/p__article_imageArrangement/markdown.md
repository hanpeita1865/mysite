*[page-title]:画像の配置

## デフォルトの配置とインラインでの配置

画像を挿入したとき、デフォルトでは中央寄せになっています。
![](upload/デフォルト配置.png "図　デフォルトの配置")

画像をクリックすると、青い枠と画像専用のツールバーが表示されます。  
左から3つ目のアイコンをクリックすると、左寄せになります。この状態は、ブロックレベルではなく<span class="green bold">インライン</span>としての配置になります。  
なので、画像の横並びなどが可能です。
<div markdown="1" class="figure-mb-0">
![](upload/左寄せクラスなし.png "図　画像左寄せ（インライン）")
</div>

<details markdown="1"><summary>コード</summary>
```
<p>
    <img src="/notices/webdir/29/sample_06.jpg">
</p>
```
</details>

画像のサイズが小さければ次のように横並びにすることができます。  
その場合は、先に挿入した画像をインラインに変更して、カーソルを横に表示させた後、次の画像を挿入します。  
それから、画像サイズを調整します。
![](upload/インラインカーソル位置.png "図　カーソルを画像の横に表示させる")
次の画像を挿入する。
![](upload/インライン横並び.png "図　画像の横並び")


## 左右、中央の配置
真ん中付近にあるアイコンをクリックすると、「左寄せ」、「中央寄せ」、「右寄せ」と選択できます。  
（ここでは、テキストの回り込みはできません。）
<div markdown="1" class="figure-mb-0">
![](upload/左寄せbreak-text.png)
</div>

<details markdown="1"><summary>コード</summary>
```
<!--left-->
<figure class="image image-style-block-align-left">
    <img src="/notices/webdir/29/sample_06.jpg">
</figure>

<!--center-->
<figure class="image">
    <img src="/notices/webdir/29/sample_06.jpg">
</figure>

<!--right-->
<figure class="image image-style-block-align-right">
    <img src="/notices/webdir/29/sample_06.jpg">
</figure>
```
</details>

カーソルを上や下に表示させてテキストを記入するときは、左上と右下にある矢印のアイコンをクリックすると、カーソールが表示されます。

<div markdown="1" class="d-flex justify-content-start align-items-center">
![](upload/テキストインサートアイコン左上.png "図　画像左上のアイコン")
<p class="d-flex flex-column align-items-center mx-3">クリック<span class="fz-16">➡</span></p>
![](upload/テキストインサートアイコン左上クリック.png "図　画像の上側にカーソルが表示される")
</div>

<div markdown="1" class="d-flex justify-content-start align-items-center">
![](upload/テキストインサートアイコン右下.png "図　画像右下のアイコン")
<p class="d-flex flex-column align-items-center mx-3">クリック<span class="fz-16">➡</span></p>
![](upload/テキストインサートアイコン右下クリック.png "図　画像の下側にカーソルが表示される")
</div>


## テキストの回り込み

画像の右側や左側にテキストを回り込ませる方法です。  
まず、画像の下にテキストを記入します。
![](upload/回り込みテキスト下に配置.png "図　テキストを画像の下に記入")

画像をクリックし、画像ツールバーの左から4つ目のアイコンをクリックすると、「右に回り込み」「左に回り込み」が選択できます。
![](upload/回り込みテキストツールバー表示.png "図　テキスト回り込みアイコン選択")

<p class="d-flex flex-column align-items-center"><span class="fz-16 rotate90">➡</span></p>

<span class="blue bold">右側</span>に回り込みを選択すると次のようになります。
![](upload/回り込みテキスト右に回り込み.png "図　テキスト右側に回り込み")

また、<span class="purple bold">左側</span>に回り込みを選択すると次のようになります。
![](upload/回り込みテキスト左に回り込み.png "図　テキスト左側に回り込み")

📝こちらの方法は画像は原寸大で表示されるので、テキスト部分が狭い場合は画像のサイズ調整が必要になります。


### Side imageアイコン

もう一つは、右から2つ目のアイコンで、これをクリックすると、テキストが左側に回り込み、画像のサイズはデフォルトで「<span class="blue
bold">max50%</span>」に設定されています。
![](upload/回り込みテキストside-imageアイコン.png "図　side imageアイコン")

上記のアイコンをクリックすると、次のように「テキスト50%　画像50%」で表示されます。
![](upload/回り込みテキストside-image表示.png "図 「テキスト50%　画像50%」で表示")

※ 画像のサイズは、同じように調整できます。


## 画像にタイトルを設置

画像ツールバーの赤枠で示したアイコンをクリックします。
![](upload/画像にタイトル設置アイコン.png "図　タイトル設置アイコン")

そうすると、画像の下にタイトルを記入する欄が表示されます。
![](upload/画像タイトル記入欄表示.png)

その欄にタイトルを記入します。
![](upload/画像タイトル記入欄に記入.png)

## 画像の均等横並び

画像を均等のサイズで横並びにする方法です。

カーソルを挿入したい位置に合わせ、<kbd class="border">本文内に挿入</kbd>ボタンをクリックして、１枚目の画像を挿入した後、<img src="upload/上にカーソル挿入.png" class="figure-none">ボタンをクリックしてから、再度<kbd class="border">本文内に挿入</kbd>ボタンをクリックし次の画像を挿入します。

<img src="upload/source.png" class="figure-none">ボタンをクリックし、HTMLコード表示に切り替えてください。
![](upload/HTMLコード表示に切り替え.png "図　HTMLコード表示に切り替え")

次に、挿入した画像コード全体を<kbd class="border">&lt;div class="photo-col2"&gt;～&lt;/div&gt;</kbd>要素で囲います。

![](upload/photo-col2コード.png "図　画像2枚横並びコード追加")

<img src="upload/Source2.png" class="figure-none">をクリックして通常の表示に戻すと、2枚横並びになっています。（2枚より多くても横並びになります。）
![](upload/画像2枚横並び.png "図　画像2枚横並び表示")

クラスを「photo-col3」にすると、3枚横並びになります。
![](upload/画像3枚横並び.png "図　画像3枚横並び表示")

<div class="gray-box" markdown="1">
📌 注意することとして、上記の<kbd class="border">&lt;div class="～"&gt;～&lt;/div&gt;</kbd>を追記した後に、カーソル挿入ボタン<img src="upload/上にカーソル挿入.png" class="figure-none">をクリックしてテキストなどを記入すると、次のように<span class="red">作成した<kbd>&lt;div&gt;</kbd>の内側に記入されます。
![](upload/矢印クリック内側挿入.png)
なので<span class="red"><kbd>&lt;div&gt;</kbd>要素を追記した後は、<img src="upload/上にカーソル挿入.png" class="figure-none">ボタンは使用しないでください。</span>  
後からテキストを記入する場合は、HTMLに直接空タグの<kbd>&lt;p&gt;&lt;/p&gt;</kbd>を挿入してください。
</div>