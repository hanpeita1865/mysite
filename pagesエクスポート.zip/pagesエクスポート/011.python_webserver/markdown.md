*[page-title]:WebServer


わかるPython参考書ダウンロード資材
: D:\template_sample\★Python\★ダウンロード\Python3_sample5\sample


## PythonのWebサーバーの起動

フォルダ構成は下記のようになっています。
<div markdown="1" class="d-flex">
![](upload/WakaruPython_sample1.png){.photo-border}
![](upload/WakaruPython_sample1_cgi.png){.photo-border}
</div>

<p class="tmp list"><span>リスト</span>index.html</p>
```
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Python Web Programming</title>
</head>
<body>
    <p>
        <img src="daikon_happy.png" alt="大根"> このページが表示されたら、Webサーバのテストは成功だよ！
    </p>
    <p>
        <img src="ninjin_happy.png" alt="人参"> コマンド１つでWebサーバが使えるなんて、とても簡単だね！
    </p>
</body>
</html>
```

<p class="tmp cmd"><span>コマンド</span>http.server</p>
```
python -m http.server --cgi 
```
※-mはモジュールを指定するオプションです。ここではWebサーバーのモジュール（http.server）を指定します。  
※--cgiはCGIプログラムを有効にするオプションです。

コマンドを実行してみます。
![](upload/http.server実行.png)

<http://localhost:8000/>にアクセスして次のように表示されればOKです。
![](upload/大根人参ページにアクセス.png){.photo-border}

cgi-binフォルダ内のtest.pyとchat.pyも表示してみます。
<p class="tmp list"><span>リスト</span>cgi-bin/test.py</p>
```
#!/usr/bin/env python3
import codecs
import sys

sys.stdout = codecs.getwriter('utf_8')(sys.stdout.detach())

# buffer = sys.stdout.detach()
# writer = codecs.getwriter('utf_8')
# sys.stdout = writer(buffer)

print('Content-type: text/html; charset=UTF-8')

print('''
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Python Web Programming</title>
</head>
<body>

<p>
<img src="/daikon_happy.png" alt="大根">
このページが表示されたら、無事にCGIプログラムが動いているよ！
</p>

<p>
<img src="/ninjin_happy.png" alt="人参">
CGIプログラムを使うと、色々な処理をするWebサイトが作れるよ！
</p>

</body>
</html>
''')
```


<http://localhost:8000/cgi-bin/test.py>にアクセスします。  
先ほどのtest.htmlと同じように表示されればOKです。
![](upload/cgi-bin_test.py表示.png "図　test.pyの表示"){.photo-border}


<p class="tmp list"><span>リスト</span>cgi-bin/chat.py</p>
```
#!/usr/bin/env python3
import cgi
import codecs
import json
import sys

sys.stdout = codecs.getwriter('utf_8')(sys.stdout.detach())

try:
    with open('chat.txt', 'r') as file:
        chat = json.load(file)
except IOError:
    chat = []

form = cgi.FieldStorage()
image = form.getfirst('image')
text = form.getfirst('text')
if image and text:
    chat.append({'image': image, 'text': text})
    with open('chat.txt', 'w') as file:
        json.dump(chat, file, indent=4)

print('Content-type: text/html; charset=UTF-8')

print('''
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Python Web Programming</title>
</head>
<body>
<h2>根菜チャット</h2>
<form action="chat.py" method="post">
<select name="image">
<option value="daikon">大根</option>
<option value="ninjin">人参</option>
</select>
<input type="text" name="text">
<input type="submit" value="発言">
</form>
<hr>
''')

for line in chat:
    print('<p><img src="/{0}.png" alt="image" width="100">{1}</p>'.format(
        line['image'], line['text']))

print('''
</body>
</html>
''')
```

<p class="tmp list"><span>リスト</span>chat.txt</p>
```
[
    {
        "image": "ninjin",
        "text": "\u4e94\u6708"
    }
]
```

次は<http://localhost:8000/cgi-bin/chat.py>にアクセスしてみます。 
下記のように表示されていればOKです。
![](upload/cgi-bin_chat.pyの表示.png "図　chat.pyの表示"){.photo-border}