---
title: '03. フィルタリング'
taxonomy:
    category:
        - docs
visible: true
---

<p>絞り込み項目のボタンをクリックすると、その条件を満たす要素だけが抽出表示されます。</p>

<iframe width="100%" height="650" src="jquery-foundation-12/sample/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
<script async src="//jsfiddle.net/4vshtqxz/embed/html,css,js"></script>
 <dl>
    <dt>解説</dt>
    <dd>clickメソッドとattrメソッドを使用して、クリックされたボタンのvalue属性の値を取得します。<br>
        取得した<span class="bold">value属性の値</span>は、<span class="bold">変数target</span>に代入しておきます。<br>
        この<span class="bold">変数target</span>が、フィルタリングの条件になります。<br>
        条件を満たしているかどうかの判定は、eachメソッドを使用して全てのli要素を調べることによって実現します。<br>
        animateメソッドと組み合わせて不透明度のopacityプロパティを0にしてから、hideメソッドで非表示にします。<br>
        次にif文を使って、条件を満たすものだけを再表示させる処理を行います。条件は「<strong>変数targetと同じ値をクラスにもっているかどうか</strong>」です。<br>
        クラスを持っているかの判定は、hasClassメソッドで行います。          
    </dd>
</dl>

####参考

<p>以前やったびわ湖あさがおネットという案件では、button ⇒ selectボックス、each() ⇒ for文 にして作られています。<br>
並べ替えは出来ませんが、こういったようにフィルタリングは、セレクトボックスを使ってのデータの抽出にも利用できます。</p>
    
<a href="https://www.biwako-asagao.net/institutions/kohoku/" target="_blank">https://www.biwako-asagao.net/institutions/kohoku/</a>（別ウィンドウで開きます）




