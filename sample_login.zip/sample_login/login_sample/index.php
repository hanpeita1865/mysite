<?php
session_start();
$pdo = new PDO( 'sqlite:../database/shop.db' );//SQLite用

if (isset($_SESSION['customer'])){
    echo 'ログインしています。';
    echo '<p><a href="logout-output.php">ログアウト</a></p>';
}else{
    echo 'ログインしていません。';
    echo '<a href="login-input.php">ログイン画面</a>';
}

