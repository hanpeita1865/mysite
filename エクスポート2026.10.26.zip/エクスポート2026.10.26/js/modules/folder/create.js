import { Api } from '../api.js';
import { hide } from '../modalManager.js';
import { getAdminData } from '../adminData.js';

export async function createFolder(newName) {

    const fd = new FormData();
    fd.append('post_newFolder', newName);
    fd.append('eventName', 'フォルダ新規作成');

    const { adminFull } = getAdminData();

    const text = await Api.postText(adminFull + 'folder_create', fd);

    if (text.match(/エラー/)) {
        throw new Error(text);
    }

    hide('folderModal');

    return 'フォルダを新規作成しました。';
}