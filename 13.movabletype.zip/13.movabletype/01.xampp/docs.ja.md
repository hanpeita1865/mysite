---
title: XAMPPに設定
media_order: 'activePerl1.png,activePerl2.png,PM4.png,PM6.png,database.png,mt00.png,mt_setting.png,mt_setting1.png,mt_setting2.png,mt_install.png,sign_in.png'
visible: true
---

## XAMPPで使用できるよう設定する

[https://www.movabletype.jp/](https://www.movabletype.jp/)

のサイト右上の個人無償版ダウンロードボタンから、MovableType本体を入手し、そのファイル「MT7-R～」をXAMPPのhtdocs直下に設置します。

### ActivePerlをダウンロード
下記のサイトから、**ActivePerl-5.24.3.24**をダウンロードします。  
[https://docs.activestate.com/](https://docs.activestate.com/)  
5.24をダウンロードしてください。他の新しいversionのだとPerl Package Managerが使えないためです。（ver5.26以降Package Managerは廃止になりました。）

1. インストーラを起動してインストールを進めます。  
Next → 同意Nextで  
Choose Setup Typeでは**Custom**を選択してください。
![](activePerl1.png)

1. ActivePerlを入れる場所を聞かれるので、Cドライブ直下に**{c:red}usr{/c}**のフォルダを作成し、Browseボタンを選択してNext。  
これはMovableTypeのcgiファイルに、#!/**{c:red}usr{/c}**/bin/perl -wと記述されているので、それにあわせるためです。
![](activePerl2.png)

1. 次のChoose optional setup actions.はそのままNextで、Installは完了です。

### 「DBI」と「DBD:mysql」をActivePerlにインストール

1. ActivePerlのインストールが完了したら、Windowsの検索欄にperlと入力し、Perl Package Managerを起動させます。  
そのPackage Managerから「DBI」と「DBD:mysql」というパッケージをインストールします。

1. メニュー左上の箱が並んでるところで、いちばん左の箱（View all packages）を選択してパッケージ一覧を表示します。  
ます検索窓に「DBI」と入力し、DBIを表示させます。

1. インストールのやり方は、インストールしたいパッケージを選択して、メニュー右上の緑丸がついてる箱（Mark for install）をクリックしてマークをつけます。  
その２つ右にある右矢印マーク（Run marked actions）を押すとインストールされます。
![](PM4.png)

1. DBD:mysqlをインストールする場合、検索窓に「DBD」と入力し、先ほどと同じようにしてインストールします。
インストールができたかどうかは、メニュー左上の左から２番めの箱（View installed packages）で確認できます。
![](PM6.png)

## XAMPPのMySQLにデータベースを作成する

データベース名は「mt」、照合順序は「utf8_general_ci」とし、作成をクリックします。
![](database.png)


これで、[http://localhost/MT7-R4706](http://localhost/MT7-R4706) に接続すると下記の画面が表示されます。 
サインインすると、Movable Typeの設定画面が表示されるので記入していきます。

<div class="dl-photo" markdown="1"> 
![](mt00.png)
: 図　インストール確認画面
</div>

mt-wizard.cgiに飛んで、セットアップウィザードが始まれば、Perlがちゃんと動いてます！

日本語を選んで開始を押します。  
データベース設定では、XAMPPで作成したMySQLの情報を入力します。

![](mt_setting.png)

アカウント作成画面では、ローカル環境なので適当なユーザーを作れば大丈夫です。  
のちほどこのユーザーでMTにログインします。

![](mt_setting1.png)

入力できたらインストールをクリックします。

この時、「Failed to execute INSERT INTO mt_asset_meta～」のエラー画面が表示されたら、XAMPPのC:\xampp\mysql\binにある「my.ini」ファイルの37行目の
```
max_allowed_packet=1M　→　max_allowed_packet=16M に変更
```
XAMPPコントロールパネルのMySLを再起動します。

そして、再度インストールし直すと、下記画面が表示されインストールされます。

![](mt_install.png)


インストール完了したらMovable Typeにサインインをクリック。  
さっき作ったアカウントのユーザー名（hirao）とパスワード（ryouma0203）入力してログインします。

![](sign_in.png)

![](mt_setting2.png)

