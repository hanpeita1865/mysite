*[page-title]:10-4. ゆがみフィルターで画像をゆがませよう

## 「ゆがみ」ダイアログボックス ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-04-1.jpg)](upload/10-04-1.jpg){.image}
</div>


## マスクを作ってから適用する ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-04-2.jpg)](upload/10-04-2.jpg){.image}
</div>

