###style.scss

'''
@charset "utf-8";

// base
@import "base/breakpoint";
@import "base/base";

// layout
@import "layout/header";
@import "layout/wrapper";
@import "layout/main";
@import "layout/footer";

// module
@import "module/parts";
//@import "module/heading";
//@import "module/list";
//@import "module/link";
@import "module/text";
//@import "module/ruby";
//@import "module/alert";
//@import "module/hidden";
//@import "module/box";
//@import "module/section";
@import "module/form";
@import "module/button";
@import "module/icon";



'''

###form.scss

'''
@charset "UTF-8";

//色設定
$blue: #2364AC;
$dark-blue: #248;
$light-blue: #359ACC;
$dark-gray: gray;
$gray: #DEDFDE;
$light-gray: #EFEFEF;
$purple: #A34796;
$dark-green: #337F90; 
$wine-red: #BF4A9A;
$green: #278747;
$skyblue: #EEF9FF;
$red: #ce202d;
$yellow: #FAE852;

body {
	font-family: -apple-system, blinkMacSystemFont, "Helvetica Neue", "Segoe UI", "Hiragino Kaku Gothic ProN", Meiryo, sans-serif;
	color: #333;
	font-size: 1rem;
	//letter-spacing: 0.1rem;
	line-height: 1.5;
}

#contents {
    width: 33rem;
	border: 1px solid;
	padding: 20px;
	margin: 0 auto;
	position: relative;
	
	&.output {
		margin: 5% auto;
		width: 300px;
	}
	
	&.wide {
		margin-top: 0;
		width: 840px;
	}
	
	&.mark-form {
		#caption-area {
			display: none;
		}
		#list-update textarea {
			display: none;
		}
		#list-update {
			display: flex;
			flex-wrap: wrap;

			.flex-box {
				margin: 1rem;
			}
		}
	}
	
	&.def-form .def-box {
		img {
			width: 200px;
		}
	}
}


h1 {
	font-size: 150%;
	text-align: center;
	margin-top: 0;
}

button, input, optgroup, select, textarea {
	font-size: .8rem;
}

label {
	font-size: 0.9rem;
	display: inline-block;
}

p {
	margin-top: 0;
	margin-bottom: 0.5rem;
	
	strong {
	  color: #cc0000;
	}
}

textarea {
	font-size: .9rem;
	width: 100%;
	height: 20rem;
}

input[type="submit"],
input[type="button"],
input[type="file"] {
	cursor: pointer;
}

input[type="file"] {
	margin-bottom: 0.5em;
}

input[type="text"] {
	width: 34em;
}

input[name="keyword"] {
	width: 15em;
	margin-bottom: 0;
}

/**** マップ投稿入力画面 ****/

h2.tourism {
	color: #359acc;
}

h2.restaurant {
	color: #ea4335;
}

h2.hotel {
	color: #278747;
}

h2.other {
	color: #278747;
}


/**** エディターマークダウン用スタイル ****/

.mark-box {

	h2 {
		font-size: 1.4rem;
		font-weight: bold;
		padding: 0.5em;
		margin-top: 7rem;
		margin-bottom: 3rem;
		background: aliceblue;
		box-shadow: 0 0 4px rgba(0, 0, 0, 0.23);
		border-left: solid 5px #278747;/*左線*/
	}
	
	h2:nth-of-type(1) {
		margin-top: 2rem;
	}
	
	h3 {
		font-size: 1.3rem;
		font-weight: bold;
		padding: 3px 8px 8px 10px;
		margin-top: 4rem;
		margin-bottom: 2.5rem;
		position: relative;
		border: none;
		background-image: linear-gradient(90deg, #278747 0%,#278747 80%,transparent 100%);
		background-size: 80% 2px;
		background-repeat: no-repeat;
		background-position: bottom left;
		color: #000;
	}
	
	h4 {
		font-size: 1.25rem;
		font-weight: bold;
		margin-top: 3rem;
		margin-bottom: 2rem;
	}

	&.life-tool {
		
		h2 {
			border-color: #f60;
		}
		
		h3 {
			background-image: linear-gradient(90deg, #f60 0%,#f60 80%,transparent 100%);
		}
	}
	
	ul {
		list-style-type: disc;
		padding-left: 40px;
	}
	
	ol {
		padding-left: 40px;
	}
	
	/* 引用 */
	blockquote {
		position: relative;
		padding: 10px 15px 10px 60px;
		box-sizing: border-box;
		font-style: italic;
		background: #f5f5f5;
		color: #777777;
		border-left: 4px solid #9dd4ff;
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.14);
	}

	blockquote:before{
		display: inline-block;
		position: absolute;
		top: 15px;
		left: 15px;
		content: "\f10d";
		font-family: FontAwesome;
		color: #9dd4ff;
		font-size: 25px;
		line-height: 1;
		font-weight: 900;
	}

	blockquote p {
		padding: 0;
		margin: 7px 0;
		line-height: 1.7;
	}

	blockquote cite {
		display: block;
		text-align: right;
		color: #888888;
		font-size: 0.9em;
	}

	img {
		//width: auto;
		max-width: 100%;
	}
	
	/*** 書式 ***/
	p.tmp {
		margin-bottom: 0.5rem;
		font-weight: bold;
	}

	p.tmp span {
		background: #026ca2;
		color: #fff;
		font-size: .8rem;
		letter-spacing: .3rem;
		padding: .2rem 0.3rem .2rem .7rem;
		white-space: nowrap;
		font-weight: normal;
		margin-right: 1rem;
	}

	p.tmp+pre {
		margin-top: 0.5rem;
	}
}



.mark-box,
.def-box {
	display: none;
}

.mark-box strong {
	color: #000;
}

form .caution {
	display: none;
}

/* マークダウン用エディター高さ */
.CodeMirror-scroll {
	min-height: 500px!important;
}





	
.chat-area {
	text-align: right;
}
#chat {
	display: inline;
}

#reset,#reset-top {
	margin-left: 0.5rem;
}

.chat-area label {
	cursor: pointer;
}

.btn-return,
.btn-load {
	text-decoration: none;
	padding: 0.4em 0.5em;
	color: #000;
	border: 1px solid #aaa;
	background: #e8e8e8;
	font-size: 80%;
	cursor: pointer;
	text-align: center;
}

.btn-return:hover,
.btn-load:hover {
	background-color: #cfd7fc;
	border-color: #2626ff;
}
/*プレビュー、ページ戻るボタンのエリア*/
.btn-return-preview {
	display: flex;
	/*flex-direction: column;*/
	position: absolute;
	bottom: 20px;
	left: 20px;	
}
/*プレビューボタン*/
#form-preview {
	position: relative;
}

#btn-preview {
    font-size: 90%;
	color: #24d;
	font-weight: bold;
	margin-left: 0.5em;
    /*padding: 0.3em 1em;*/
	padding: 5px 10px;
	width: 120px;
	text-align: left;
	border: 1px solid #24d;
	cursor: pointer;
	background: #fff;
	
	&:hover {
		background-color: #24d;
		color: #fff;
	}
}



/*新規ウインドウアイコン（プレビューボタン用）*/
.extlink::after {
    display: inline-block;
    content: "";
	position: absolute;
	top: 25%;
	right: 5px;
	width: 6px;
	height: 6px;
    width: 15px;
    height: 15px;
    margin-left: 0.3rem;
    margin-right: 0.3rem;
    background: url(../images/icon_new_win.svg) no-repeat;
    background-size: contain;
}

.btn-updateArea {
	z-index: 5;
}

.extlink:hover::after {
    background: url(../images/icon_new_win_ov.svg) no-repeat;	
}


/*大きい削除ボタン*/
.btn-delete {
    font-size: 100%;
    font-weight: bold;
	min-width: 120px;
    padding: 0.3em 1em;
    background-color: #a30000;
    color: #fff;
    border-style: none;
	cursor: pointer;
	
	&:hover {
		background-color: #d60101;
		color: #fff;
	}
}



/*大きいアップロードボタン*/
.btn-upload {
    font-size: 100%;
    font-weight: bold;
	min-width: 120px;
	margin-top: 20px;
    padding: 7px 10px;
    background-color: #248;
    color: #fff;
    border-style: none;
	cursor: pointer;
	
	&:hover {
		background-color: #24d;
		color: #fff;
	}
}



//投稿者インプットボックス
input[name="writer"] {
	width: 14em;
}

p.address {
	text-align: right;
	
	label {
		margin-right: 0.3em;
		font-size: 95%;
	}

	input[name="ip"] {
		width: 10em;
		padding-left: 0.2em;
		font-size: 95%;
	}

	input[type="button"] {
		margin-left: 0.3em;
		cursor: pointer;
	}

	input[type="button"] {
		width: 5em;
		text-align: center;
	}
}


//編集画面用
label.btn-update {
	display: block;
	color: #fff;
	background-color: green;
	font-size: 0.8rem;
	padding: 0.2rem 0.6rem;
	margin-bottom: 0.2rem;
	border: 1px solid #aaa;
	cursor: pointer;
	
	> input { /*画像アップボタン*/
		display:none;	/* アップロードボタンのスタイルを無効にする */
	}
}
.btn-updateDel {
	display: block;
	background: #d60101;
	color: #fff;
	font-size: 0.8rem;
	padding: 0.2rem 0.6rem;
	border: 1px solid #aaa;
	cursor: pointer;
}
.btn-updateArea {
	padding: 0 0.4rem 0.2rem 0.2rem;
}


//マークダウンと標準切り替えパーツ類
.report-select {
	display: flex;
	justify-content: flex-end;
	
	button {
		cursor: pointer;
		margin: 0 0.2rem;
		min-width: 5rem;
		text-align: center;
		
		&:hover {
			font-weight: bold;
		}
		
		&.active {
			cursor: auto;
			background: green;
			border: 1px solid green;
			font-weight: bold;
			color: #fff;
			pointer-events: none;
		}
	}
	
	#btn-def {
		letter-spacing: .5rem;
		padding-left: 1rem;
	}
}





@media screen and (-webkit-min-device-pixel-ratio:0) {/*Chromeのみ適用*/
	textarea {
		font-size: 1.1rem;
	}
}

@-moz-document url-prefix() {/*FIREFOXのみ適用*/
	textarea {
		font-size: .9rem;
	}
}


textarea[name^="caption"] {
	height: 4em;
}

#caption-area {
	margin-bottom: 1em;
}

div[id^="caption"] {
	margin-bottom: 0.7rem;
}

.caption-title {
	font-weight: bold;
	margin-bottom: 0.5rem;
}


/*削除画面*/
.other-list {
	display: flex;
	flex-wrap: wrap;
	margin-bottom: 1em;
}

.other-list img {
	margin-right: 5px;
	margin-bottom: 5px;
}

.thumb {
	height: 75px;
	width: auto;
	margin: 0;
}

#list-top,
#list {
	display: flex;
	flex-wrap: wrap;
	margin-bottom: 10px;
	/*min-height: 25px;*/
}
#list-top figure {
	display: flex;
	align-items: center;
	margin: 5px 5px 5px 0;
}
#list figure {
	display: flex;
	flex-direction: column;
	margin: 5px 5px 5px 0;
}
#list-top figcaption {
	text-align: center;
	margin-top: 0;
	font-size: 0.9rem;
	margin-left: 10px;
}
#list figcaption {
	text-align: center;
	margin-top: 0;
	font-size: 0.9rem;
}

#list-update {
	
	figure {
		margin: 0 5px 5px 0;
		line-height: 1;
		min-width: 80px;
	}
	figcaption {
		/*text-align: center;*/
		margin-top: 0;
		font-size: 0.8rem;
	}
	textarea {
		height: auto;
		width: 100%;
		margin-bottom: 1em;
	}
}



.gray-box {
	display: inline-block;
	border: 1px solid $gray;
    padding: 10px 25px;
    margin: 5px 5px 10px;
	
	p {
		font-size: .9rem;
	}
}

input[type="radio"]:not(:first-child) {
	margin-left: 1rem;
}


input[type="radio"] + label {
	cursor: pointer;
}

.markdown-guide {
	text-decoration: underline;
	color: $dark-blue;
	display: none;
}

/**** ドラッグ&ドロップ ****/
#file-area {
	display: none;
}

#DnDBox {
	padding:50px;
	text-align : center;
	font-size: 1.5em;
	border: 2px dotted rgb(11, 133, 161);
	width: 100%;
}

#DnDBox:hover {
    background: #d8f4ff;
    cursor: pointer;
}

#waitingList {
	margin-top: 10px;
}

#waitingList li {
	display: flex;
	justify-content: space-between;
	list-style: none;
	border-bottom: 1px solid #A9CCD1;
	width: 700px;
	padding: 10px 10px 7px 10px;
	vertical-align: top;
}

#waitingList li:first-child {
	border-top: 1px solid #A9CCD1;
}

#waitingList li span.filename {
	display: inline-block;
	vertical-align: top;
	min-width: 350px;
}

button.fileDelete,
button.fileDelete-update {
	display: inline-block;
	background: #d60101;
	color: #fff;
	font-size: 0.8rem;
	padding: 0.2rem 0.6rem;
	border: 1px solid #aaa;
	cursor: pointer;
}


/**** マージン調整　****/
.mb-0 {
	margin-bottom: 0 !important;
}
.mt-0 {
	margin-top: 0 !important;
}
.mt-1 {
	margin-top: 1em !important;
}
.mb-03 {
	margin-bottom: 0.3rem;
}
.mb-1 {
	margin-bottom: 1rem;
}
/* インデント */
.att {
	margin-left: 1em;
	text-indent: -1em;
}

.att-6 {
	text-indent: -6em;
	margin-left: 6em;
}

/**** 文字位置　****/
.text-right {
	text-align: right;
}

/**** 文字サイズ　****/
.fontSize-09 {
	font-size: 0.9rem;
}

/**** 文字色 ****/

.text-bold {
	font-weight: bold;
}

.text-blue {
	color: blue;
}

.text-green {
	color: green;
}

/**** 文字位置 ****/
.text-center {
	text-align: center;
}

/**** ブロック　****/
.d-block {
	display: block!important;
}
.d-inline {
	display: inline!important;
}

/**** フレックスボックス　****/
.flex-box {
	display: flex;
}
.flex-between {
	display: flex;
	justify-content: space-between;
}
.flex-end {
	display: flex;
	justify-content:flex-end; 
}


/**** メディアクエリー　****/
@media ( max-width : 649px ) {
	#contents {
		width: 90%;
		padding: 20px;
		margin: 20px auto;
	}
 	input[type="text"] {
		width: 100%;
	}
	textarea {
		width: 100%;
	}
	.btn-return-preview {
		flex-direction: column;
	}
	p {
		font-size: 80%;
	}
}
'''

###_box.scss

'''
@charset "utf-8";
//-----------------------------------------------------//
// @mixin 基本ボックス
//-----------------------------------------------------//
@mixin baseBox {
	background: rgba(255,255,255,.8);
	border-radius: 5px;
	box-shadow: 2px 2px 11px -1px #969696;
	margin-bottom: 10px;
	padding: 20px 10px;
	@content;
}

/* =============================================== */
/*
#overview
Box

ボックス関連のスタイル
*/
/* =============================================== */

/* =============================================== */
/*
#styleguide
・テキストボックス

```
<div class="textBox">テキストボックス</div>
```
*/
/* =============================================== */
.textBox {
	@include baseBox;
	@include media ( md ) {
		margin-right: auto;
		margin-left: auto;
		padding: 20px;
		width: 80%;
	}
	@include media ( lg ) {
		margin-bottom: 20px;
		padding: 30px;
		width: 70%;
	}
	@include media ( xl ) {
		padding: 40px;
		width: 55%;
	}
}

/* =============================================== */
/*
#styleguide
・回答ボックス

```
<div class="answerBox">回答ボックス</div>
```
*/
/* =============================================== */
.answerBox {
	@include baseBox;
	@include media ( sm ) {
		margin-right: auto;
		margin-left: auto;
		width: 85%;
	}
	@include media ( md ) {
		padding: 20px;
		width: 80%;
	}
	@include media ( lg ) {
		margin-bottom: 20px;
		padding: 30px;
		width: 70%;
	}
	@include media ( xl ) {
		padding: 40px;
		width: 60%;
	}
}
'''

###_button.scss

'''
@charset "utf-8";

/* ======================================================
ボタン
====================================================== */

//投稿ボタン
.button4 {
    font-size: 1.4rem;
    font-weight: bold;
    padding: 10px 30px;
    background-color: $dark-blue;
    color: #fff;
    border-style: none;
    cursor: pointer;
	
	&:hover {
		background-color: #24d;
		color: #fff;
	}
}

//パスワード送信ボタン
.btn-pass {
    float: right;
    text-decoration: none;
    margin: 0.2em 0.5em 0;
    padding: 0.4em 0.8em;
    color: #000;
    border: 1px solid #aaa;
    background: #e8e8e8;
    font-size: 90%;
    cursor: pointer;
}

//いいねボタン
.btn-good {
	//font-size: 1.4rem;
}


.btn-good {
	border: none;
	 border: 1px solid #000;
	font-size: 1.4rem;
	font-weight: bold;
	cursor: pointer;
	margin-right: 0.5em;
	text-align: right;
	
	&:hover {
		//background: $blue;
		//color: #fff;
		color: $blue;
		border: 1px solid $blue;
	}
}

.btn-good.read[disabled] {
	color: #898989;
	font-size: 1.4rem;
	cursor: auto;
	border: 1px solid $dark-gray;
	font-weight: normal;
	//background-image: url(../images/icon-read.png);
}

		
//サイドボックス抽出ボタン
.btn-filter {
	display: inline-block;
	font-size: 1.3rem;
	padding: 0.3em 0.5em;
	background: light-gray;
	color: #000;
	border: 1px solid $dark-gray;
	text-decoration: none;
	margin: 0 auto;
	cursor: pointer;
	text-align: center;

	&:hover {
		background-color: #3569B2;
		color: #fff;
	}

	&.active {
		background-color: #3569B2;
		pointer-events : none;
		color: #fff;
	}
	
	&[value="all"] {
		letter-spacing: 1em;
		padding: 0.4em 0 0.4em 1em;
		font-size: 1.4rem;		
	}
}














/********* メディアクエリー *********/

@include media ( lg ) { //1199px以下


}
@include media (md ) { //991px以下

}
@include media ( sm ) { //767px以下


}
@include media ( xs ) { //575px以下


}

'''

###_form.scss

'''
@charset "utf-8";

/* ======================================================
フォーム
====================================================== */

input[type="submit"], input[type="button"] {
    cursor: pointer;
}

//編集、削除ボタン
.button5,
.button6 {
    font-size: 1.2rem;
    padding: 3px 4px;
    margin: 0.3em;
    border: 1px solid #ccc;
	background-color: #fff;
    color: #000;
    cursor: pointer;
}
//編集ボタン
.button5:hover { 
    background-color: #3407f2;
    color: #fff;
}

.button6:hover { 
    background-color: #be0202;
    color: #fff;
}

.tb-none {
    border-top: none;
    border-bottom: none;
}

.continue {
	text-align: right;
	
	input[type="submit"] {
		border: none;
		color: $blue;
		background: transparent;
		text-decoration: underline;
		
		&:hover {
			text-decoration: none;
		}
	}
	
}

//いいねボタン
span.good-count {
    font-size: 1.7rem;
    color: blue;
    font-weight: bold;
	margin-left: .8rem;
}



/********* メディアクエリー *********/

@include media ( lg ) { //1199px以下


}
@include media (md ) { //991px以下

}
@include media ( sm ) { //767px以下


}
@include media ( xs ) { //575px以下


}
'''

###_icon.scss

'''
@charset "utf-8";

/* ======================================================
アイコン
====================================================== */

.file_icon {
	display: inline-block;
	padding-right: 23px;
	position: relative;
}

.file_icon::after {
	bottom: 0;
	content: "";
	height: 20px;
	width: 20px;
	margin-left: 4px;
	margin-bottom: 4px;
	position: absolute;
}

.file_icon.pdf-icon::after {
	background: url(../images/icon-pdf.svg) no-repeat;
	background-size: auto 100%;
}

.file_icon.excel-icon::after {
	background: url(../images/icon-excel.svg) no-repeat;
	background-size: auto 100%;
}

.file_icon.word-icon::after {
	background: url(../images/icon-word.svg) no-repeat;
	background-size: auto 100%;
}
.file_icon.newtab-icon {
	padding-right: 22px;
}
.file_icon.newtab-icon::after {
	background: url(../images/icon-newtab.svg) no-repeat;
	background-size: auto 100%;
	height: 15px;
	width: 15px;
	margin-left: 3px;

}

'''

###_parts.scss

'''
@charset "utf-8";

/* ======================================================
パーツ
====================================================== */


/*** 見出し ***/

h1[class^="heading2"] {
	position: relative;
	display: flex;
	flex-wrap: wrap;
	//justify-content: space-between;
	align-items: center;
	font-size: 2.5rem;
	padding: 0.3rem 1rem 0.3rem 4rem;
	margin-bottom: 2rem;
	background: linear-gradient(#fff 60%, #dedede 100%);
	
	span.sub {
		font-size: 2rem;
		margin-left: 2rem;
		
	}
	
	&:before {
		content: "";
		display: inline-block;
		position: absolute;
		//background-color: #5c9ee7;
		top: 50%;
		left: 0;
		transform: translateY(-50%);
		width: 32px;
		height: 32px;
		background-size: 90% 90%;
		background-position: center;
	}
}




.heading2-1 {
	border-bottom: 3px solid $dark-blue;
	
	&:before {
		background: url(../images/h2_blue.svg) no-repeat;
	}
}

.heading2-2 {
	border-bottom: 3px solid $green;

	&:before {
		background: url(../images/h2_green.svg) no-repeat;
	}
}

.heading2-3 {
	border-bottom: 3px solid $orange;
	
	&:before {
		background: url(../images/h2_orange.svg) no-repeat;
	}
}

.heading2-4 {
	border-bottom: 3px solid $red;
	
	&:before {
		background: url(../images/h2_red.svg) no-repeat;
	}
}





/*** ハンバーガーメニュー ***/

button.navbar-toggler {
	background: #fff;
	color: $blue;
	border-radius: 0rem;
	width: 78px;
	height: 78px;
}

.three {
	padding: 0;
	height: 50px;
	width: 50px;
	box-sizing: border-box;
	background-color: $blue;
	color: #fff;
	background: #fff;
	color: black;
	text-align: center;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
}

.hamburger .line {
	width: 30px;
	height: 3px;
	background: $blue;
	display: block;
	margin: 8px auto;
	-webkit-transition: all 0.3s ease-in-out;
	-o-transition: all 0.3s ease-in-out;
	transition: all 0.3s ease-in-out;
}

.hamburger:hover {
	cursor: pointer;
}

span.menu-txt {
	//font-size: 0.75rem;
	font-size: 1.2rem;//追加
	display: block;
	color: $blue;
}

#hamburger-1.is-active .line:nth-child(2) {
	opacity: 0;
}

#hamburger-1.is-active .line:nth-child(1) {
	transform: translateY(10px) rotate(45deg);
}

#hamburger-1.is-active .line:nth-child(3) {
	transform: translateY(-12px) rotate(-45deg);
}


@keyframes smallbig{
	0%, 100%{
		transform: scale(1);
	}

	50%{
		transform: scale(0);
	}
}




/******** イメージボックス（トップページ）********/

a.image-box {
	display: flex;
	justify-content: center;
	align-items: center;
	width: 47.5%;
	height: 245px;
	border: none;
	text-decoration: none;
	margin-bottom: 3rem;
	background-size: contain;
	background-position: center center;
	background-repeat: no-repeat;
	transition: opacity 0.2s ease-in;
	
	.text-area {
		color: #000;
		font-size: 2rem;
		font-weight: bold;
		text-align: center;
		line-height: 1.3;
		padding: .5rem 1.5rem;
		width: 100%;
		background: rgba(255, 255, 255, 0.5);
		text-shadow: 1px 1px 0.5px #fff, -1px 1px 0.5px #fff, 1px -1px 0.5px #fff, -1px -1px 0.5px #fff;

		.sub {
			display: block;
		}
	}
	
	&.photo1 {
		background-image: url(../images/categopry-transport.jpg);
	}
	
	&.photo2 {
		background-image: url(../images/categopry-sigoto.jpg);
	}
	
	&.photo3 {
		background-image: url(../images/categopry-seikatu.jpg);
		position: relative;
		display: block;
		
		.text-area {
			position: absolute;
			bottom: 10%;
		}

	}
	
	&.photo4 {
		background-image: url(../images/categopry-question.jpg);
	}
	
	&:hover,
	&:focus {
		opacity: .7;
	}
}

/*** 投稿日時、投稿者名 ***/
.dtime {
	font-size: 1.4rem;
	letter-spacing: 0.1rem;
	color: #4e4e4e;
	
	span {
		margin-left: 1.5rem;
	}
}

/************* 記事まとめページ *************/

.tool-info {
	
	h1[class^="heading2"] {
		justify-content: flex-start;
		
		form {
			margin-left: auto;
		}
	}
  
	article {
		margin-bottom: 3rem;
		padding: 1rem 1.5rem 0;
		border: 1px solid $gray;
		
		h2 {
			position: relative;
			display: flex;
			align-items: center;
			padding-right: 5rem;
			
			&::after {
				position: absolute;
				right: 0;
				top: 0;
				display: inline-block;
				//margin: 0 0.5em 0.2em;
				padding: 0.1em 0.3em;
				color: #fff;
				font-size: 11px; 
			}
		}
		
		&.desk {
			h2::after {
				content: 'デスク';
				background: $blue;
			}
		}
		
		&.soft {
			h2::after {
				content: 'SOFT・WEB';
				background: $green;
			}
		}
		
		&.other {
			h2::after {
				content: 'その他';
				background: $purple;
			}
		}
		
		&.living {
			h2::after {
				content: '生活用';
				background: $orange;
			}
		}
		
		&.food {
			h2::after {
				content: '飲食用';
				background: $dark-blue;
			}
		}
		
		&.outdoor {
			h2::after {
				content: '外出用';
				background: $green;
			}
		}

		p {
			margin-bottom: 0;
		}

		.more-link {
		  float: right;
		  margin-top: 15px;
		}

  }
	//記事内容
	.report {
		margin: 0 auto 10px;
		display: flex;

		figure {
				//width: calc(30% - 20px);
				margin-right: 20px;
				width: 218px;
				height: 163px;
				text-align: center;

			img {
				max-width: 100%;
				max-height: 100%;
				width: auto;
				height: auto;
			}

			figcaption {
				text-align: center;
				color: rgb(128, 128, 128);
			}
		}

		.description {
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			width: 70%;

			.text {
				height: 150px;
				margin-bottom: 1rem;
				overflow: hidden;
			}
			.more {
				align-self: flex-end;
			}
			
		/***** マークダウン記事のスタイル(見出しは今の所ランクは変えない) *****/
			
			[id^="text-markdown"] {
			
				h2 {
					font-size: 2.0rem;
					padding: 0.5em;
					margin-top: 2.5rem;
					margin-bottom: 4rem;
					background: aliceblue;
					box-shadow: 0 0 4px rgba(0, 0, 0, 0.23);
					border-left: solid 5px #278747;/*左線*/
				}

				h2::after {
					content: none;
				}

				h2:first-of-type {
					margin-top: 2rem;
				}

				h3 {
					font-size: 1.9rem;
					font-weight: bold;
					padding: 3px 8px 8px 10px;
					margin-top: 4rem;
					margin-bottom: 2.5rem;
					position: relative;
					border: none;
					background-image: linear-gradient(90deg, #278747 0%,#278747 80%,transparent 100%);
					background-size: 80% 2px;
					background-repeat: no-repeat;
					background-position: bottom left;
					color: #000;
				}

				h4 {
					font-size: 1.8rem;
					font-weight: bold;
					margin-top: 3rem;
					margin-bottom: 2rem;
				}

				ul {
					list-style-type: disc;
					padding-left: 40px;
				}

				ol {
					padding-left: 40px;
				}
				
				pre {
					padding: 1rem;
					//margin: 2rem 0;
					border: 1px solid #ddd;
					border-radius: 2px;
					line-height: 1.15;
				}
				
				/*** 書式 ***/
				p.tmp {
					margin-bottom: 0.5rem;
					font-weight: bold;
				}

				p.tmp span {
					background: #026ca2;
					color: #fff;
					font-size: 1.25rem;
					letter-spacing: .3rem;
					padding: .2rem 0.3rem .2rem .7rem;
					white-space: nowrap;
					font-weight: normal;
					margin-right: 1rem;
				}

				p.tmp+pre {
					margin-top: 0.5rem;
				}

			}
			
			&.life-tool {
				
				[id^="text-markdown"] {
					h2 {
						border-color: #f60;
					}

					h3 {
						background-image: linear-gradient(90deg, #f60 0%,#f60 80%,transparent 100%);
					}
				}
			}

			/***** マークダウン記事のスタイル(ここまで) *****/
			
		}
	}
	
}


/************* 詳細記事ページ *************/
.detail+#side-bar .btn-filter {
	display: none;
}

.info-detail {
	
	h1[class^="heading2"] {
		padding-right: 5rem;
		
		form {
			margin-left: auto;
		}
	}
	
	h1::after {
		position: absolute;
		right: 3px;
		display: inline-block;
		padding: 0.1em 0.3em;
		color: #fff;
		font-size: 11px; 
	}
	
	&.desk {
		h1::after {
			content: 'デスク';
			background: $blue;
		}
	}

	&.soft {
		h1::after {
			content: 'SOFT・WEB';
			background: $green;
		}
	}

	&.other {
		h1::after {
			content: 'その他';
			background: $purple;
		}
	}

	&.living {
		h1::after {
			content: '生活用';
			background: $orange;
		}
	}

	&.food {
		h1::after {
			content: '飲食用';
			background: $dark-blue;
		}
	}

	&.outdoor {
		h1::after {
			content: '外出用';
			background: $green;
		}
	}
	
	/***** マークダウン記事のスタイル *****/
	
	#text-markdown {

		h2 {
			font-size: 2.0rem;
			padding: 0.5em;
			margin-top: 7rem;
			margin-bottom: 3rem;
			background: aliceblue;
			box-shadow: 0 0 4px rgba(0, 0, 0, 0.23);
			border-left: solid 5px #278747;/*左線*/
		}
		
		h2:first-of-type {
			margin-top: 2rem;
		}

		h3 {
			font-size: 1.9rem;
			font-weight: bold;
			padding: 3px 8px 8px 10px;
			margin-top: 4rem;
			margin-bottom: 2.5rem;
			position: relative;
			border: none;
			background-image: linear-gradient(90deg, #278747 0%,#278747 80%,transparent 100%);
			background-size: 80% 2px;
			background-repeat: no-repeat;
			background-position: bottom left;
			color: #000;
		}

		h4 {
			font-size: 1.8rem;
			font-weight: bold;
			margin-top: 3rem;
			margin-bottom: 2rem;
		}


		ul {
			list-style-type: disc;
			padding-left: 40px;
		}

		ol {
			padding-left: 40px;
		}

		/*テーブル*/
		th {
			border: 1px solid #ddd;
			padding: 5px;
		}

		td {
			border: 1px solid #ddd;
			padding: 5px;
		}
		
		/* 引用 */
		blockquote {
			position: relative;
			padding: 10px 15px 10px 60px;
			box-sizing: border-box;
			font-style: italic;
			background: #f5f5f5;
			color: #777777;
			border-left: 4px solid #9dd4ff;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.14);
		}

		blockquote:before{
			display: inline-block;
			position: absolute;
			top: 15px;
			left: 15px;
			content: "\f10d";
			font-family: FontAwesome;
			color: #9dd4ff;
			font-size: 25px;
			line-height: 1;
			font-weight: 900;
		}

		blockquote p {
			padding: 0;
			margin: 7px 0;
			line-height: 1.7;
		}

		blockquote cite {
			display: block;
			text-align: right;
			color: #888888;
			font-size: 0.9em;
		}
		
		/* コード挿入 */
		pre {
			padding: 1rem;
			margin: 2rem 0;
			//background: #f6f6f6;
			border: 1px solid #ddd;
			border-radius: 2px;
			line-height: 1.15;
			//font-size: 1rem;
		}
		
		img {
			max-width: 100%;
		}
		
		/*** 書式 ***/
		p.tmp {
			margin-bottom: 0.5rem;
			font-weight: bold;
		}

		p.tmp span {
			background: #026ca2;
			color: #fff;
			font-size: 1.25rem;
			letter-spacing: .3rem;
			padding: .2rem 0.3rem .2rem .7rem;
			white-space: nowrap;
			font-weight: normal;
			margin-right: 1rem;
		}

		p.tmp+pre {
			margin-top: 0.5rem;
		}

	}
	
	&.life-tool #text-markdown {

		h2 {
			//border-color: #f60;
			border-left: solid 5px #f60;
		}

		h3 {
			background-image: linear-gradient(90deg, #f60 0%,#f60 80%,transparent 100%);
		}
	}
	
	/***** マークダウン記事のスタイル(ここまで) *****/

	
	.dtime {
		text-align: right;
		margin-bottom: 1.5rem;
	}
	
	#img-other {
		display: flex;
		flex-wrap: wrap;
		
		figure {
			margin: 0.3rem 0.7rem 0.15rem 0.7rem;
		}
	}

	figure.photo-area {//トップ画像
		//display: flex;
		//flex-direction: column;
		//align-items: center;
		position: relative;
		width: 850px;
		//height: 500px; //削除
		max-height: 650px;//追加
		padding: 10px 0; //追加
		border: 1px solid $dark-gray;

		figcaption {
			//margin-top: .5rem; 削除
			text-align: center;
			
			span {
				margin: 0 2.5rem;
				display: inline-block;
			}
		}
		
		img {
			display: block;//追加
			max-width: 100%;
			//max-height: 100%;
			max-height: 600px;//追加
			width: auto;
			height: auto;
			margin: auto;
		}
	}
		
	img.other-photo {//その他画像
		width: 250px;
	}
	
	.text-area {
		font-size: 1.6rem;
		padding: 0 1.3rem;
		line-height: 1.5;
		
		figure {
			display: table;
			margin: 0.3rem 0.3rem 0.15rem 0.25rem;
			
			figcaption {
				position: relative;
				display: table-caption;
				caption-side: bottom;
				text-align: center;
				color: rgb(128, 128, 128);
				font-size: 1.3rem;
				line-height: 1.2;
				margin-top: 0.3rem;
				word-wrap: break-word;
				
				span {
					display: inline-block;
					text-align: left;
				}
			}
		}
	}
	
	.btn-area {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0 1.8rem;
		
		span.good-count {
			font-size: 1.6rem;
			color: blue;
			font-weight: bold;
		}

	}
	
	& + #side-bar {
		
		.btn-filter {
			display: none;
		}
		
	}
}

/* モーダルウィンドウ */

.modal-box {
    position: fixed;
    display: none;
    z-index: 10;
    margin: 10px;
    padding: 10px;
    background: #fff;
}

.modal-close {
    position: absolute;
    top: 2px;
    right: 5px;
	cursor: pointer;
}

.modal-overlay {
    //z-index: 9;
	z-index: 8;
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,.5);
}

.modal-box input[name="keyword"] {
    width: 20em;
    margin: 0.5em;
}

img.modal-origin {//追加
    max-height: 800px;
    max-width: 90%;
}

.modal-origin {//追加
    position: fixed;
    display: none;
    z-index: 10;
    margin: 10px;
    padding: 10px;
    /* border-radius: 20px; */
    background: #fff;
}

.modal-open {
	cursor: pointer;//追加
}



/***** Prev,Nextボタン （追加7.01）*****/

.slick-arrow {
    /*display: none;*/
    opacity: 0.01;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 6.5625%;
	max-width: 53px;
    height: 0;
	min-width: 40px;
    min-height: 60px;
    padding-top: 11.25%;
    overflow: hidden;
    font-size: 0;
	background: none center center no-repeat rgba(0,0,0,0);
    background-size: 30.95%;
	border: none;
    z-index: 20;
}

.slick-prev {
    left: 10px;
    background-image: url(../images/prev.png);
    border-radius: 0 6px 6px 0;
}

.slick-next {
    right: 10px;
    background-image: url(../images/next.png);
    border-radius: 6px 0 0 6px;
}

.modal-origin:hover > .slick-arrow,
.modal-origin:focus > .slick-arrow {
    /*display: block;*/
    opacity: 1;
	background-color: rgba(0,0,0,.45);
}

.slick-arrow:hover,
.slick-arrow:focus {
    cursor: pointer;
    opacity: 1;
    background-color: rgba(0,0,0,.45);
}

.slick-arrow:hover {
    outline: none;
}

.modal-origin.photo-first .slick-prev {
	display: none;
}

.modal-origin.photo-last .slick-next {
	display: none;
}


/******** バリアフリーマップ ********/

/*** 新着情報 ***/

.local #news h2 {
	background-color: #6699CC;
	color: #fff;
	
	&:before {//追加
		background-image: url(../images/icon-info-local.svg);
	}
}


/***** 地図 *****/

#map-area {
	position: relative;
	padding: 2% 19% 10% 2%;
	margin-top: 2rem;
	margin-bottom: 5rem;
	background: linear-gradient(to bottom, #B8D0E8 10%, #DBE7F3);
	
	img {
		width: 100%;
	}
	
	h3 {
		position: absolute;
		top: 1%;
		left: 1%;
		font-size: 2rem;
		color: #515700;
		background: #FFC000;
		padding: 1rem 2rem;	
	}
	
	a.all-local {
		position: absolute;
		display: inline-block;
		top: 13%;
		left: 30%;
		font-size: 1.8rem;
		color: #fff;
		background: #1A73E8;
		padding: 1rem 3rem;
		//text-decoration: none;
		letter-spacing: .5rem;
		
		&:hover {
			background: $blue;
		}
	}
	
	.map-box {
		display: inline-block;
		position: absolute;
		border: 1px solid $dark-gray;
		background: #fff;
		max-width: 23%;
		
		p {
			text-align: center;
			font-weight: bold;
			padding: 0.4rem;
			font-size: 1.6rem;
		}
		
		ul {
			display: flex;
			flex-wrap: wrap;
			padding: 5px 5px 5px 5px;
			
			
			li {
				margin: 0.5rem;
				width: calc(33.33% - 1rem);
				text-align: center;
			}
		}
		
		ul.half {
			li {
				width: calc(50% - 1rem);
			}
		}
		
		&#tohoku-area {
			top: 20%;
			right: 1%;
			p {
				background-color: #52bbd1;
			}
		}
		
		&#kanto-area {
			top: 45%;
			right: 3%;
			max-width: 19%;
			p {
				background-color: #71D5CB;
			}
		}
		
		&#chubu-area {
			bottom: 2%;
			right: 14%;
			p {
				background-color: #C0C743;
			}
		}
		
		&#kinki-area {
			bottom: -6%;
			right: 41%;
			max-width: 19%;
			p {
				background-color: #EFB838;
			}
		}
		
		&#chugoku-area {
			top: 31%;
			left: 21%;
			p {
				background-color: #F58C3F;
			}
		}
		
		&#shikoku-area {
			bottom: 2%;
			left: 18%;
			max-width: 18%;
			p {
				background-color: #F1A296;
			}
		}
		
		
		&#kyushu-area {	
			top: 23%;
			left: 1%;
			max-width: 19%;
			p {
				background-color: #E77A72;
			}
		}
		
	}
	
}

/******** バリアフリー都道府県別 ********/

.local-site {
	
	h1[class^="heading2"] {
		justify-content: flex-start;
		
		.btn-local-filter {
			display: inline-block;
			font-size: 1.9rem;
			margin: .2rem;
			padding: 0.3em 0.5em;
			background: light-gray; 
			color: #000;
			border: 1px solid $dark-gray;
			text-decoration: none;
			cursor: pointer;

			&:hover {
				color: #fff;
				
				&[value="tourism"] {
					background-color: $light-blue;
				}
				
				&[value="restaurant"] {
					background-color: #EA4335;
				}
				
				&[value="hotel"] {
					background-color: $green;
				}

				&[value="other"] {
					background-color: $purple;
				}
			}
			
			&.active {
				pointer-events : none;
				color: #fff;
				outline: none;
				
				&[value="tourism"] {
					background-color: $light-blue;
					border: 1px solid $light-blue;
				}
				
				&[value="restaurant"] {
					background-color: #EA4335;
					border: 1px solid #EA4335;
				}
				
				&[value="hotel"] {
					background-color: $green;
					border: 1px solid $green;
				}

				&[value="other"] {
					background-color: $purple;
					border: 1px solid $purple;
				}
			}
			
		}
		
	}
	
	h3 {
		display: flex;
		//position: relative;
		flex-wrap: wrap;
		justify-content: space-between;
		align-items: center;

		span {
			position: relative;
			display: inline-block;
			background: #f1f8ff;
			min-width: 300px;
			padding: 0.3rem 3rem 0.3rem 5rem;
			letter-spacing: 1.5rem;
			margin-top: 1rem;
			border-bottom: 2px solid #5c9ee7;
			
			&:before {
				content:"";
				display: inline-block;
				position: absolute;
				background-image: url(../images/icon-tour.svg);
				background-color: #5c9ee7;
				background-repeat: no-repeat;
				top: 0;
				left: 0;
				width: 32px;
				height: 32px;
				background-size: 90%;
				//background-size: 100% 100%;
				background-position: center;
			}

			&.tourism {
				border-color: $light-blue;

				&:before {
					background-image: url(../images/icon-tour.svg);
					background-color: $light-blue;
				}
			}
					
			&.restaurant {
				border-color: #EA4335;

				&:before {
					background-image: url(../images/icon-restaurant.svg);
					background-color: #EA4335;
				}
			}
			
			&.hotel {
				border-color: $green;

				&:before {
					background-image: url(../images/icon-hotel.svg);
					background-color: $green;
				}
			}
			
			&.other {
				border-color: $purple;

				&:before {
					background-image: url(../images/icon-access.svg);
					background-color: $purple;
				}
			}
		}
	}

	
	ul {
		margin: 2rem 0rem 2rem 1rem;
		
		li {
			margin-bottom: 2.5rem;

			.link-title {
				font-size: 2rem;
			}
			
			a {
				
				figure {
					margin-right: 1rem;
					width: 200px;

					span {
						display: block;
						overflow: hidden;

						img {
							width: 100%;
							transition: all 0.3s ease-out;
						}
					}
				}
				
				
				&:hover span,
				&:focus span,
				&.active span {
					outline: 1.5px solid #248;
				}

				&:hover img, 
				&:focus img {
					transform: scale(1.1);
					opacity: 0.8;
				}
			}

			.map-report {
				flex-grow: 1;
				margin-top: -1.5rem;

				h5 {
					margin: 0 1rem 0.5rem 1rem;
					font-size: 1.5rem;
				}
				ul.feeling {
					border: 1px solid $dark-gray;
					border-radius: 0.7rem;
					margin: 0 0 1.5rem;
					padding: 1rem .5rem 1rem 3rem;
					min-height: 130px;

					li {
						list-style: disc;
						font-size: 1.2rem;
						margin-bottom: .5rem;
					}
				}
			}

		}
	}

}

/*フレックスボックス（便利ツール詳細ページ画像並べ用）*/
.flex-box-wrap {
	display: flex;
	flex-wrap: wrap;
	justify-content: space-around;
}

/*シンタックスハイライト*/
pre code {
	padding-left: 1rem;
}



/********* メディアクエリー *********/

@include media ( lg ) { //1199px以下
  
	a.image-box {
		height: 220px;
	  margin-bottom: 2rem;
	}
	
	#map-area {
		.map-box {
			
			p {
				font-size: 1.4rem;
			}
			
			ul {
				padding: 0px;
				li {
					margin: 0.5rem;
					width: calc(50% - 1rem);
					font-size: 1.3rem;
				}
			}
			
			&#tohoku-area {
				max-width: 21%;
				top: 20%;
				right: 2%;
			}

			&#kanto-area {
				top: 50%;
				right: 2%;
				max-width: 21%;
			}

			&#chubu-area {
				bottom: -11%;
				right: 14%;
			}

			&#kinki-area {
				bottom: -11%;
				right: 39%;
				max-width: 21%;	
			}

			&#chugoku-area {
				top: 25%;
				left: 23%;
				max-width: 21%;
			}

			&#shikoku-area {
				bottom: -1%;
				left: 20%;
			}


			&#kyushu-area {
				top: 20%;
				left: 1%;
				max-width: 21%;
			}
		}
	}

}
@include media (md ) { //991px以下
	
	.info-detail figure.photo-area {
		max-width: 100%;
		//max-height: 300px;
		width: auto;
		height: auto;
		padding: 0;//追加
	}
	
	#map-area {
		margin-bottom: 10rem;
		
		.map-box {
			
			p {
				font-size: 1.4rem;
			}
			
			ul {
				padding: 0px;
				li {
					margin: 0.5rem;
					width: calc(50% - 1rem);
					font-size: 1.3rem;
				}
			}
			
			&#tohoku-area {
				max-width: 21%;
				top: 20%;
				right: 2%;
			}

			&#kanto-area {
				top: 50%;
				right: 2%;
				max-width: 21%;
			}

			&#chubu-area {
				bottom: -11%;
				right: 14%;
			}

			&#kinki-area {
				bottom: -11%;
				right: 39%;
				max-width: 21%;
			}

			&#chugoku-area {
				top: 25%;
				left: 23%;
			}

			&#shikoku-area {
				bottom: -1%;
				left: 20%;
			}


			&#kyushu-area {
				top: 20%;
				left: 1%;
				max-width: 21%;
			}
		}
	}
	
}


@include media ( sm ) { //767px以下
	
	h2[class^="heading2"] {
		font-size: 2rem;

		span {
			font-size: 1.8rem;
		}
	}
  
	a.image-box {
		height: 160px;
		margin-bottom: 1rem;
	}
	
	
	.report {
		display: block;

		figure {
			width: 100%;
			margin-right: 0;
		}

		.description {
			width: 100%;
		}
	}

	#map-area {
		display: flex;
		flex-wrap: wrap;
		margin-bottom: 2rem;
		padding: 6rem 0.5rem;
		//background: #B8D0E8;
		background: linear-gradient(to bottom, #B8D0E8 60%, #FFF);
		
		img {
			display: none;
		}
		
		h3 {
			top: 1%;
			left: 50%;
			transform: translateX(-50%);
		}
		
		a.all-local {
			top: 2%;
			left: 74%;
			font-size: 1.5rem;
			padding: 0.8rem 1.5rem;
			letter-spacing: 0.2rem;
		}

		.map-box {
			position: static;
			margin: 0.5rem;
			width: calc(33.33% - 1rem) !important;
			max-width: none !important;
			
			p {
				font-size: 1.6rem;
			}
			
			ul {
				padding: 0px;
				li {
					margin: 0.5rem;
					width: calc(50% - 1rem);
					font-size: 1.4rem;
					text-align: center;
				}
			}
		}
	}
	
	.local-site {
		h2[class^="heading2"] {
			
			.btn-local-filter {
				font-size: 1.5rem;
			}
		}
	}
	
	.info-detail figure.photo-area {//追加
		display: block;
	}

}
@include media ( xs ) { //575px以下
	
	h2[class^="heading2"] {
		font-size: 1.8rem;

		span {
			font-size: 1.9rem;
		}
	}
	
	a.image-box {
		width: calc(100% - 4rem);
		margin: 1rem 2rem;
		height: 200px;

		.text-area {

		}

	}

	#map-area {
		
		.map-box {
			margin: 0.5rem;
			width: calc(50% - 1rem) !important;
			max-width: none !important;
			
			p {
				font-size: 1.7rem;
			}
			
			ul {
				padding: 0px;
				li {
					margin: 0.5rem;
					width: calc(33.33% - 1rem);
					font-size: 1.4rem;
					text-align: center;
				}
			}
		}
	}

	.local-site {
		h2[class^="heading2"] {
			flex-direction: column-reverse;
			align-items: flex-start;
			
			.btn-local-filter {
				font-size: 1.3rem;
			}
			
			&:before {
				top: 65%;
			}
		}
		
		h3 span {
			min-width: auto;
		}
	}
	
}

@media ( max-width : 450px ) { //450px以下 独自に設置
	#map-area {

		.map-box {
		
			p {
				font-size: 1.55rem;
			}
			
			ul {
				li {
					width: calc(50% - 1rem);
					font-size: 1.4rem;
				}
			}
		}
	}
}

@media only screen and (min-width: 991px) and (max-width: 1199px)  {/*追加*/
	.info-detail figure.photo-area { 
		width: 100%;
	}
}












'''

###_text.scss

'''
@charset "utf-8";

.text-bold {
	font-weight: bold;
}

.text-blue {
	color: blue;
}

.text-green {
	color: green;
}


'''

###_header.scss

'''
@charset "utf-8";
/* ======================================================
ヘッダー
====================================================== */


#header {
	width: 100%;

	.johosite-nav {
		display: flex;
		flex-wrap: nowrap;
		flex-direction: column;
		border-left: none;
		border-right: none;
		margin-bottom: 0;
		padding: 0;
		background-color: #fff;

		.header-inner {
			position: relative;
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 0 auto;
			width: 1170px;
			height: 100px;

			a.logo-top {
				display: flex;
				align-items: center;
				text-decoration: none;
				
				&:hover,
				&:focus {
					opacity: 0.7;
				}
				
				span {
					font-weight: bold;
					color: $red;
					font-size: 2.5rem;
					display: inline-block;
					margin-top: .5rem;
				}
			}
			
			form.search {
				label {
					display: block;
				}
			
				input[type="text"] {
					width: 14em;
					font-size: 1.3rem;
					padding: 0.3em 0.5em;
					border: solid 1px $gray;
				}
			}

		}
		
	/************* グローバルナビ ***************/
		#Navber {
			//border-top: 1px solid $blue;
			border-top: 1px solid $light-gray;
			//padding-top: 7px;
			//padding-bottom: 7px;
			width: 100%;
			background-color: $skyblue;

			ul.navbar-nav {
				justify-content: space-around;
				width: 1200px;
				margin: 0 auto;
				padding-left: 15px;
				padding-right: 15px;

				 li.nav-item {
					position: relative;
					padding: 0.6rem 0.5rem;
					text-align: center;
					 width: 24%;



					a.nav-link {
						font-size: 1.8rem;
						letter-spacing: 0.1rem;
						padding: 3rem 1.8rem .5rem;
						text-align: center;
						background:linear-gradient(#fff 0%, $skyblue 100%);
						color: #353535;
						font-weight: bold;
						min-width: 20rem;
						box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.16), 0 0 0 1px rgba(0, 0, 0, 0.08);
						transition: box-shadow 200ms cubic-bezier(0.4, 0, 0.2, 1);
						
						&:hover {
							background:linear-gradient(#fff 0%, #c8ebfd 100%);
							box-shadow: 0 3px 8px 0 rgba(0, 0, 0, 0.2), 0 0 0 1px rgba(0, 0, 0, 0.08);
						}
						
						span.sub {
							display: block;
							font-size: 1.4rem;
						}
						
						&::after {
							content: "";
							position: absolute;
							top: 0;
							right: 25%;
							width: 30%;
							height: 40%;
							background-repeat: no-repeat;
							z-index: 5;
						}
						
						&.blue::after {
							background-image: url(../images/nav-flag-blue.svg);
						}

						&.green::after {
							background-image: url(../images/nav-flag-green.svg);
						}

						&.orange::after {
							background-image: url(../images/nav-flag-orange.svg);
						}

						&.red::after {
							background-image: url(../images/nav-flag-red.svg);
						}
						
					}

					/*サブメニュー(追加9.29)*/
					ul.sub-menu {
						//display: block;
						display: none;
						position: absolute;
						opacity: 0;
						//transform: translateY(10px);
						transition: all .5s;
						background: #2364ac;
						top: 100%;
						left: -10%;
						z-index: 1000;
						min-width: 14rem;
						padding: .5rem .5rem .75rem;
						margin: .125rem 0 0;
						font-size: 1rem;
						color: #212529;
						text-align: left;
						width: 120%;
						border-radius: 5px;
						
						li {
							padding: 0.25rem 0;
							border-bottom: 1px solid #fff;
							text-align: left;
							list-style: none;

							a {
								display: block;
								color: #fff;
								font-size: 1.4rem;
								padding: 0.25rem 0.2rem 0.25rem 0.75rem;
								text-decoration: none;
								
								&:hover {
									background: #013d80;
								}
							}
						}
						
						&::before {
							content: " ";
							position: absolute;
							width: 0;
							height: 0;
							bottom: 100%;
							left: 45%;
							border-bottom: 8px solid #2364ac;
							border-right: 12px solid transparent;
							border-top: 8px solid transparent;
							border-left: 12px solid transparent;
						}
						
						//サブメニュー表示
						&.open { //ホバー時
							opacity: 1;
							transform: translateY(-6px);
						}

						&.opened {
							display: block;
						}

						&.focused { //フォーカス時
							opacity: 1;
						}
					}
					//ここまで(追加9.29) 
				}
				


				li.nav-item:last-child {
					border-right: none;
				}

				li a {
					text-decoration: none;
				}

			}
		}
	}

	/**** キービジュアル ****/
	#keyvisual {

		img {
			width: 100%;
		}
	}
	
	/******** メディアクエリー ********/
	@include media ( lg ) { //1199px以下
		.johosite-nav {
			.header-inner {
				width: 100%;
			}
			#Navber ul.navbar-nav {
				width: 100%;
			}
		}

	}
	@include media (md ) { //991px以下
		
		height: auto;
		min-height: 200px;
		padding-top: 78px;

		.johosite-nav {
			flex-wrap: wrap;
			flex-direction: row;
			position: absolute;
			width: 100%;
			top: 0;
			left: 0;
			.header-inner {
				height: 78px;
				background: transparent;
				position: relative;
				
				a.logo-top {
					display: flex;
					align-items: center;
					width: calc(40% - 1rem);
					margin-left: 1rem;
					
					img {
						height: 78px;
					}
					
					span {
						font-size: 1.7rem;
					}
				}
				
				&::before,
				&::after {
					content: none;
				}
			}
			
			#Navber {
				z-index: 10;
				
				ul.navbar-nav {
					display: block;
					padding: 0;
					li.nav-item {
						border-bottom: 1px solid #fff;
						padding: 0;
						margin: 0;
						width: auto;

						a.nav-link {
							width: 100%;
							padding: 0.85rem 0.5rem;
							text-align: left;
							color: #fff;
							background: $blue;
							font-size: 1.4rem;
							text-align: center;
							box-shadow: none;
							
							&:hover,
							&:focus {
								color: $blue;
							}

							&::after { //スマホでは旗を非表示
								content: none;
							}
						}
						& ul.sub-menu {
							display: block;
							position: static;
							padding: 0 10px;
							opacity: 1;
							background: #3a65ef;
							width: 100%;
							border-radius: 0;
							&::before {
								content: none;
							}
							&.open {
								transform: translateY(0);
							}
							li {
								text-align: center;	
								
								a {
									padding: 1rem;
								}
							}
						}
					}
				}
			}

		}
	}

	@include media ( sm ) { //767px以下
		.johosite-nav .header-inner a.logo-top span {
			font-size: 1.6rem;
		}
	}
	@include media ( xs ) { //575px以下
		.johosite-nav .header-inner {
			a.logo-top {
				width: calc(60% - 1rem);
				margin-left: 0;
				

				img {
					min-width: 78px;
				}
				span {
					font-size: 1.3rem;
				}
			}
			
			form.search {
				text-align: right;
				
				input[type="text"] {
					font-size: 1rem;
				}
				
				input[type="submit"] {
					font-size: 1rem;
				}
			}
		}

	}
	
	@media only screen and (max-width: 991px) and (min-width: 576px) {
		.johosite-nav .header-inner a.logo-top img {
			max-width: 78px;
		}
	}
}


@media only screen and (max-width: 991px) {/*追加*/
	.detail #header {
		min-height: auto;
	}
}




'''

###_wrapper.scss

'''
@charset "utf-8";
/* ======================================================
ラッパー
====================================================== */
#wrapper {
	display: flex;
	flex-direction: column;
	min-height: 100vh;
}
'''

###_main.scss

'''
@charset "utf-8";
/* ======================================================
メイン
====================================================== */

main {
	padding: 0;
	flex: 1 0 auto;
	display: flex;
	flex-direction: column;
	position: relative;
	padding-bottom: 3rem;
	
	
	/* パンくず */
	ol.breadcrumb-list {
		display: flex;
		flex-wrap: wrap;
		padding: 0;
		margin-top: .5rem;
		margin-bottom: 0;
		
		li {
			position: relative;
			list-style-type: none;
			font-size: 1.5rem;
			min-height: 38px;
			margin-bottom: 0;
			padding-left: 0;
			
			&:not(:first-child)::before {
				content: '＞';
				margin: 0 0.5rem;
				color: #2341A0;
				font-weight: bold;
				font-size: 0.8rem;
			}
		}
		
	}

	
	#news {
		border: 1px solid $light-gray;
		
		h2 {
			position: relative;//追加
			background-color: $yellow;
			color: #652f00;
			padding: .8rem .8rem .8rem 5.7rem;
			margin: 0;
			font-size: 2rem;
			
			&:before {//追加
				content: "";
				position: absolute;
				top: 50%;
				-webkit-transform: translateY(-35%);
				transform: translateY(-43%);
				left: 10px;
				width: 22px;
				height: 22px;
				background-image: url(../images/icon-info.svg);
				background-size: cover;
			}
			
			.info_num {//追加
				position: absolute;
				top: 43%;
				left: 32px;
				border-radius: 100px;
				font-weight: 100;
				background-color: #e52222;
				min-width: 24px;
				height: 15px;
				font-size: 11px;
				display: flex;
				justify-content: center;
				line-height: 15px;
				color: #fff;
				-webkit-transform: translateY(-100%);
				transform: translateY(-100%);
				//padding: 0 0.5rem;
				letter-spacing: 0.01rem;
				
				&:after {//追加
					content: " ";
					width: 0px;
					border-top: 6px solid #e52222;
					border-left: 2px solid transparent;
					border-right: 4px solid transparent;
					position: absolute;
					left: 50%;
					margin-left: -13px;
					top: 13px;
					transform: rotate(34deg);
				}
			}
		}
		
		ul.news-list {
			padding: 1rem;
			height: 205px;
			overflow-y: scroll;
			
			li {
				display: flex;
				list-style: none;
				padding: .2rem 0 .3rem 0;
				border-bottom: 1px solid $light-gray;
				
				span {
					&.work-tool,
					&.life-tool {
						color: #fff;
						//padding: .2rem;
						min-width: 80px;
						height: 22px;
						line-height: 22px;
						display: inline-block;
						text-align: center;
						font-weight: bold;
					}

					&.work-tool {
						background-color: $green;
					}

					&.life-tool {
						background-color: $orange;
					}					
				}
				

				
				.news-text {
					display: flex;
					align-items: center;
					flex-wrap: wrap;				
				
					a {
						//color: #2F2F2F;
						text-decoration: underline;
						margin-left: 1.5rem;

						&:hover {
							color: #8054A9;
							text-decoration: none;
						}
					}

					span.new-red {
						display: inline-block;
						margin: 0 0.5em 0.2em;
						padding: 0.1em 0.3em;
						color: #fff;
						background: #c70000;
						font-size: 10px;
					}
					
					input[type="submit"] {
						border: none;
						background: transparent;
						color: #2341a0;
						text-decoration: underline;
					}
				}

			}
		}
	}
	
	#category {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
	}
	
	#side-bar {
		display: flex;
		flex-direction: column;
		padding-top: 9rem;
		
		.side-box {
			background-color: $light-gray;
			border: 1px solid gray;
			padding-bottom: 1rem;
			margin-bottom: 2.5rem;

			h2 {
				font-size: 1.37rem;
				color: #fff;
				padding: .8rem;
				margin: 0 0 1rem;
				background-color: $light-blue;
			}

			section {
				padding: 1rem 1rem 1rem 2rem;
			}

			h3 {
				font-size: 1.37rem;
				border-left: 5px solid $light-blue;
				padding: .5rem;
			}

			a {
				color: #000;
			}

			ul,p {
				margin-left: 1rem;
			}
			
			ul {
				padding: 1rem 1rem 1rem 2rem;

				li {
					margin-bottom: 1rem;
				}
				
				&.ranking {
					padding-top: 0;
					padding-left: 1rem;//追加
					
					li {
						display: flex;
						padding-left: 1rem;//追加
						padding-top: .2rem;
						padding-bottom: .2rem;
						margin-bottom: .5rem;
						
						a {
							display: block;
							width: 83%;
							padding-right: .5rem;
							overflow: hidden;
						}
						span {
							display: block;
							width: 17%;
							text-align: center;
							
							&.count {
								font-size: 1.4rem;
							}
						}
										
						&.good {
							justify-content: flex-end;
							font-size: 1.2rem;
    						font-weight: bold;
							
							span {
								width: 20%;
							}
							
						}
						
						&.match {//追加
							border: 1.5px solid $green;
							border-radius: .5rem;
							//padding-top: .5rem;
							//padding-bottom: .5rem;
							
							a,span {
								font-weight: bold;
								pointer-events: none;
								text-decoration: none;
							}
						}
					}
					
				}
			}

			&.top-side,
			&.map-side {
				ul {
					padding: 0;
				}
			}

		}
	}
	

	
	.banner-area {
		display: flex;
		flex-direction: column;
		align-content: center;
		margin-top: .5rem;
		text-align: center;
		
		.box {
			width: 100%;
			max-width: 260px;
			margin-bottom: 1.5rem;
			
			a {
				display: block;
				width: 100%;
				
				img {
					width: 100%;
				}
				
				&:hover {
					opacity: 0.8;
				}
			}
		}
	}
	
	/********* メディアクエリー *********/
	
	@include media ( lg ) { //1199px以下

	}
	@include media (md ) { //991px以下
		
		#side-bar {
			margin-top: 1.5rem;
			padding-top: 0rem;
		}
		
		.banner-area {
			margin-top: .5rem;
			    display: flex;
				flex-wrap: wrap;
				justify-content: space-between;
			.box {
				margin: 0.5rem 1rem 0.5rem 0.5rem;
				display: flex;
				flex-direction: column;
			}
		}
	}
	@include media ( sm ) { //767px以下
		
	}
	@include media ( xs ) { //575px以下
		
		ol.breadcrumb-list li {
			font-size: 1.3rem;
		}

		#news ul.news-list {
			font-size: 1.3rem;
		}

	}
}


/**** キーフレーム ****/

/*サイドバーのいいねカウント*/
.good-mark {
  animation-name: smallbig;
  animation-duration: .5s;
  //animation-duration: 0s;
}

@keyframes smallbig{
	0%, 100%{
		transform: scale(1);
	}

	50%{
		transform: scale(2);
	}
}

/**** モーダルウィンドウ ****/

.modal-origin {
    position: fixed;
    display: none;
    top:0;
    left: 0;
    z-index: 10;
    font-size: 0;
    margin: 10px;
    padding: 10px;
    background: #fff;
    max-width: 90%;
    max-height: 90Vh;
}

.modal-origin img {
    max-width: 100%;
    max-height: 83vh;
}

.modal-photo-close {
    position: absolute;
    background: url(../images/close.png) no-repeat;
    background-position: center;
    height: 20px;
    width: 20px;
    top: 0;
    right: 0;
    border: none;
    cursor: pointer;
    background-color: #fff;
}

.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    overflow: hidden;
    clip: rect(0,0,0,0);
    white-space: nowrap;
    border: 0;
}

.modal-overlay {
    z-index: 9;
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,.5);
}


//===========================================
//	暮らしの情報スタイル
//===========================================

#wrapper.living-info {
	
	#keyvisual {
		position: relative;
		.key-title-01 {
			position: absolute;
			top: 15%;
			left: 7%;
			//font-size: 3rem;
			font-size: 2rem;
			font-weight: bold;
			color: #442F2F;
			white-space: nowrap;
			letter-spacing: .5rem;
			text-shadow: #fff 3px 0px 1px, #fff -3px 0px 1px, #fff 0px -3px 1px, #fff 0px 3px 1px, #fff 3px 3px 1px, #fff -3px 3px 1px, #fff 3px -3px 1px, #fff -3px -3px 1px, #fff 1px 3px 1px, #fff -1px 3px 1px, #fff 1px -3px 1px, #fff -1px -3px 1px, #fff 3px 1px 1px, #fff -3px 1px, #fff 3px -1px 1px, #fff -3px -1px 1px;
			
			&.key-top {
				top: 27%;
				left: 50%;
				transform: translate(-50%);
				//font-size: 4rem;
				font-size: 2.5rem;
				letter-spacing: 1.8rem;
			}
		}

		img {
			width: 100%;
			//max-width: 1200px;
			max-width: 1150px;
			margin: 0 auto;
		}
	}
	
	.category-wrap {
		display: flex;
		flex-wrap: wrap;
		//margin: 0 -1.5rem;
		
		section {
			display: flex;
			width: calc(100% - 1rem);
			margin: 1.5rem auto;
			
			> a {
				display: flex;
				flex-direction: column;
				flex: 1 0 auto;
				word-wrap: break-word;
				background-color: #fff;
				/*outline: 1px solid #2364ac;*/
				border: 2px solid #776446;
				border-radius: 6px;
				color: #000;
				width: 100%;
				min-height: 200px;
				text-decoration: none;
				padding: .5rem 1rem;
				transition: all .2s;
				
				h2 {
					font-size: 2rem;
					color: #5d5344;					
					margin-bottom: 0;
					background-size: auto auto;
					background-position: 0% 40%;
					background-repeat: no-repeat;
					background-image: url(../images/icon-test.svg);
					padding: 0.8rem 0rem 0.8rem 3.6rem;
				}

				&.text {
					margin: 0.5rem 1rem 0.3rem;
					font-size: 0.86rem;
					letter-spacing: 0.03rem;
				}
				
				&:hover,
				&:focus {
					//outline: 5px solid yellow;
					outline: 5px solid rgba(255, 255, 0, 0.6);
					transform: scale(1.02);
				}
				
			}
			&.hearty-box {
				position: relative;
				
				> a {

				}

				ul {
					position: absolute;
					display: flex;
					flex-wrap: wrap;
					justify-content: space-between;
					bottom: 0;
					left: 50%;
					transform: translate(-50%);
					z-index: 10;
					width: 90%;
					padding: .5rem 1rem 0;
					
					li {
						list-style: none;
						a {
							border: none;
							padding: 0.5rem;
							background: none;
							white-space: nowrap;
						}						
					}

				}
			}
		}

	}
}


@media (min-width: 768px) {
	#wrapper.living-info {
		#keyvisual {
			.key-title-01 {
				font-size: 3rem;
				&.key-top {
					font-size: 4rem;
				}
			}
		}
		.category-wrap {
			margin: 0 -1rem;	
			section {
				width: calc(50% - 2rem);
				margin: 1rem;
				&.hearty-box {
					ul {
						width: 100%;				
						li {

							a {
								border: none;
								padding: 0.5rem;
								background: none;
								white-space: nowrap;
							}						
						}

					}
				}
			}			
		} 
		
	}	
}

@media (min-width: 992px) {
	#wrapper.living-info {
		.category-wrap{
			section {
				//width: calc(33.333% - 3rem);
				//margin: 1.5rem;
			}			
		}
		
	}	
}


@media (min-width: 1200px) {
	#wrapper.living-info {
		.category-wrap{
			section {
				width: calc(33.333% - 3rem);
				margin: 1.5rem;
				&.hearty-box {
					ul {
						width: 90%;				
					}
				}
			}			
		}		
	}	
}






'''

###_footer.scss

'''
@charset "utf-8";
/* ======================================================
フッター
====================================================== */


#footer {
	width: 100%;
	background: #fff;
	padding-top: 6rem;
	flex-shrink: 0;
	background: url(../images/bg-footer.svg) no-repeat;
	background-size: cover;
	
	.footer-inner {
		display: flex;
		justify-content: space-between;
		align-items: flex-end;
		flex-flow: row-reverse;
		font-size: 1.5rem;
		
		address {
			color: #fff;
			//white-space: nowrap;
			margin-left: 1.5rem;
			width: 65%;

			dl {
				dt {
					padding: 5px 1em 5px 0;
					float: left;
				}
				dd {
					padding: 5px 0 5px 6.5em;
				}
			}
			a {color: #3b00ff;}
		}

		.footer-nav {
			display: flex;
			justify-content: center;
			margin-bottom: 1rem;
			padding: 5rem 0 0 5rem;
			width: 35%;

			p.home {
				margin-right: 2rem;

				a {
					color: #fff;
					//font-size: 1.6rem;
					white-space: nowrap;
					text-decoration: underline;

					&:hover,
					&:focus {
						text-decoration: none;
					}
				}
			}

			ul {
				display: flex;
				flex-wrap: wrap;
				//padding: 5rem 0 0 5rem;

				li {
					font-size: 1.6rem;
					color: #fff;
					padding: .2rem 2rem;
					list-style: none;
					margin-bottom: 1rem;

					a {
						font-size: 1.6rem;
						color: #fff;
						//text-decoration: none;
						white-space: nowrap;

						&:hover,
						&:focus {
							//text-decoration: underline;
							text-decoration: none;
						}
					}

					ul {
						flex-direction: column;
						margin-top: 1rem;
						padding: 0;

						li {
							list-style:disc;
							color: #fff;
							padding: .2rem 0;
							margin: 0 0 0 2rem;
						}
					}
				}
			}
		}
	}
	
	 p.copy {
		color: #fff;
		letter-spacing: 0.1rem;
		text-align: center;
		padding: 0.4rem 0;
		margin-bottom: 0;

		small {
			font-size: 1.6rem;
		}
	}
	
	/********* メディアクエリー *********/
	
	@include media ( lg ) { //1199px以下

	}
	@include media (md ) { //991px以下
		.footer-inner {
			flex-direction: column;
			margin-top: 8rem;
			
			.footer-nav {
				width: 100%;
				padding: 0;
				justify-content: flex-start;
			}
			address {
				width: 100%;
			}
		}
	}
	@include media ( sm ) { //767px以下
		
	}
	@include media ( xs ) { //575px以下
		
		.footer-inner {
			font-size: 1.1rem;
			
			.footer-nav {
				p.home a {
					font-size: 1.1rem;
				}

				ul {
					flex-wrap: wrap;
					justify-content: flex-start;
					padding: 0;

					li {
						font-size: 1.1rem;
						margin-bottom: 1rem;

						a {
							font-size: 1.1rem;
						}

						ul {
							margin-top: 0;

							li{
								padding: 0;
							}
						}
					}
				}
			}
			
			address {
				width: 100%;
			}
		}
		

		

		p.copy small {
			font-size: 1rem;
		}



	}

}


'''

###_base.scss

'''
@charset "utf-8";
/* ======================================================
ベース
====================================================== */
//色設定
$blue: #2364AC;
$dark-blue: #248;
$light-blue: #359ACC;
$dark-gray: gray;
$gray: #DEDFDE;
$light-gray: #EFEFEF;
$purple: #A34796;
$dark-green: #337F90; 
$wine-red: #BF4A9A;
$green: #278747;
$skyblue: #EEF9FF;
$red: #ce202d;
$yellow: #ffc000;
$orange: #ff6600;



html {
	font-size: 62.5%;
	box-sizing: border-box;
}
body {
	font-family: -apple-system, blinkMacSystemFont,	/* Macの欧文はSan Francisco (OS X 10.11以降) */
				'Helvetica Neue',					/* Macの欧文 (OS X 10.10以前) */
				'Segoe UI',							/* Windowsの欧文 */
				'Hiragino Kaku Gothic ProN',		/* Macのヒラギノ */
				Meiryo,								/* Windowsのメイリオ */
				sans-serif;
	color: #333;
	font-size: 1.4rem;
	letter-spacing: .2rem;
	line-height: 1.5;
	//background: url(../images/bg-02.jpg) no-repeat;削除
	background-size: cover;
	background-position: center;
	@include media ( md ) {
		font-size: 1.5rem;
	}
}
body {
	display: flex;
	flex-direction: column;
	min-height: 100vh;
}
/*
*::before,
*::after {
	content: "";
}
*/
.clearfix:after{
	visibility:hidden;
	height:0;
	display: block;
	font-size: 0;
	content: " ";
	clear: both;
}

/**************** 見出し ******************/

h1,h2, h3, h4, h5, h6 {
	font-weight: bold;
}

h1 {
	font-size: 3rem;
}


h2 {
	font-size: 2.5rem;
	text-align: left;
	margin: 0.5rem 0 1.5rem;
	letter-spacing: 0.1rem;
}

h3 {
	font-size: 2rem;
}

h4 {
	font-size: 1.5rem;
}

h5 {
	font-size: 1.2rem;
}

h6 {
	font-size: 1rem;
}

/*********** リンク *************/

a {
	color: #2341A0;
	text-decoration: underline;
}

a:hover,
a:focus {
	color: #8054A9;
	text-decoration: none;
}


/*** 画像 ***/
img {
	border: 0;
}

/**** リスト ****/
ul {
	list-style: none;
	padding-left: 0;
}

main ul li,
main ol li {
	margin-bottom: 0.5rem;
}

.list-none {
	list-style:none;
}

ul.list-disc {
	padding-left: 1rem;
	list-style: none;
}

ul.list-disc li {
	padding-left: 1em;
	text-indent: -1em;
}

ul.list-disc li::before {
	content: '\2022';
	color: #2341A0;
	padding: 0 8px 0 0;
}

/*
ol {
	padding-left: 1rem;
}

ol li {
	font-size: 0.93rem;
	list-style-type: none;
	counter-increment: number;
	padding-left: 1.5em;
	text-indent: -1.5em;
}

ol li::before{
  content: counter(number) ".";
  margin-right: 5px;
  color: #2341A0;
}
*/

dt {
	margin-bottom: 0.5rem;
}


button, input, select, textarea {
	//border: 1px solid #000;
}



@media (min-width: 1200px) {
	.container {
		max-width: 1170px;
	}
}
'''

###_breakpoint.scss

'''
@charset "utf-8";
//-----------------------------------------------------//
// @mixin メディアクエリ
//-----------------------------------------------------//
$bp-lg: 1199px;
$bp-md: 991px;
$bp-sm: 767px;
$bp-xs: 575px;

@mixin media($media-width)
{
	@if $media-width == lg { //1199px以下
		@media only screen and (max-width: $bp-lg) {
			@content;
		}
	}
	@else if $media-width == md { //991px以下
		@media only screen and (max-width: $bp-md) {
			@content;
		}
	}
	@else if $media-width == sm { //767px以下
		@media only screen and (max-width: $bp-sm) {
			@content;
		}
	}
	@else if $media-width == xs { //575px以下
		@media only screen and (max-width: $bp-xs) {
			@content;
		}
	}
}
'''

