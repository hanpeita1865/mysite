---
title: 09.ジェネレータ式
taxonomy:
    category:
        - docs
visible: true
---

内包表記に似た記法で、<span class="red bold">ジェネレータ式</span>という記法があります。リストの内包表記は、すべての内容を一度に生成してリストに格納するのに対して、ジェネレータ式は、
すべての内容を一度に生成することはせずに、<span class="red bold">要求に応じて一つずつ結果を生成します。</span>

<p class="tmp"><span>書式1</span>ジェネレータ式</p>
<pre>
(式 for 変数 in イテラブル)
</pre>
イテラブルから値を取り出し、値を変数に代入し、式を評価した結果を出力する、という処理を繰り返します。

<p class="indent-01">※イテラブルとは～for文で繰り返せるオブジェクトまたはそのクラスのこと。<br>
例えば range, リスト, タプル, 集合, 辞書, 文字列は、イテラブルです。 もう少しちゃんと言えば、for 文の in に書き込めるオブジェクトです。</p>

<p class="tmp"><span>書式2</span>ジェネレータ式とif</p>
<pre>
(式 for 変数 in イテラブル if 条件)
</pre>
イテラブルから値を取り出し、条件を評価します。条件がTrueの場合だけ、値を変数に代入し、式を評価した結果を出力します。以上の処理を繰り返します。

※リストの内包表記は<span class="red">各括弧[]</span>で囲みますが、ジェネレータ式は<span class="red">丸括弧()</span>で囲みます。

<p class="editpre"><span>テキストエディタ</span>内包表記のプログラム</p>
<pre>
number = <span class="bold red">[</span>x for x in range(10000000)<span class="bold red">]</span><span class="comment">  # 内包表記は角括弧で囲む</span>
for n in number:
    print(n)
</pre>

<p class="indent-01">※内包表記のプログラムは、<span class="red bold">一度にすべての整数を生成する</span>ため処理に非常に時間がかかります。<br>
　環境にもよりますが、メモリ不足に陥って、正しく動作しない場合があります。</p>

<p class="editpre"><span>テキストエディタ</span>ジェネレータ式のプログラム</p>
<pre>
number = <span class="bold red">(</span>x for x in range(10000000)<span class="bold red">)</span> <span class="comment">  # ジェネレータ式は丸括弧で囲む</span>
for n in number:
    print(n)
</pre>

<p class="indent-01">※ジェネレータ式のプログラムは、<span class="red bold">要求に応じて整数を一つずつ生成する</span>ため、処理時間がかかることもメモリ不足に陥ることもありません。</p>

ジェネレータ式の方のプログラムを実行してみます。
<pre>
<span class="bold blue">実行結果</span>
0
1
2
3
4
…<span class="comment">  # 以下、整数の出力が続く（CTRL + Cキーで止まる）</span>
</pre>



<h3 class="h-type3">ジェネレータとyield文</h3>

ジェネレータ式に関連する機能に「<span class="red bold">ジェネレータ</span>」という機能があります。<br>
ジェネレータは関数に似ていますが、関数がreturn文を使って戻り値を返すのに対して、ジェネレータは<span class="red bold">yield文を使って、複数の値を順番に生成します。</span>

<p class="inpre"><span>インタプリタ</span>return文を使ったプログラム</p>
<pre>
def do_return():
…    <span class="blue bold">return 1</span>
…    return 2
…    return 'Fizz'
…    return 4
…    return 'Buzz'
…
do_return()
<span class="bold">1</span>
do_return()
<span class="bold">1</span>
do_return()
<span class="bold">1</span>
do_return()
<span class="bold">1</span>
</pre>

<p class="indent-01">※このプログラムの場合、最初の「<span class="blue bold">return 1</span>」で関数の実行を終了し、関数の続きは実行しないので、何度呼び出しても「1」しか返ってきません。</p>

<p class="tmp"><span>書式3</span>yield文</p>
<pre>
yield 値
</pre>

<p class="inpre"><span>インタプリタ</span>yield文を使ったプログラム</p>
<pre>
>>> def do_yield():
...     yield 1
...     yield 2
...     yield 'Fizz'
...     yield 4
...     yield 'Buzz'
...
>>> do_yield()
&lt;generator object do_yield at 0x0000026E6BBA8B88&gt;
</pre>

<p class="indent-01">※&lt;generator object …&gt;が返ってきましたが、これがジェネレータと呼ばれるものです。<br>
関数の定義において<span class="red bold">yield文</span>を使うと、通常の関数ではなく、<span class="red bold">ジェネレータを返す関数</span>になります。
ジェネレータは、<span class="red bold">複数の値を順番に生成するための仕組み</span>です。働きはジェネレータ式に似ていますが、ジェネレータは通常の関数と同様に変数への代入や制御構文などを使って記述できるので、ジェネレータ式に比べて<span class="red bold">複雑なプログラムが書きやすく</span>なっています</p>

<p class="inpre"><span>インタプリタ</span>for文と組み合わせて使用</p>
<pre>
<span class="comment"># do_yield()は、前述で定義済み</span>

>>> for i in do_yield():
...     print(i)
...
1
2
Fizz
4
Buzz
</pre>

<p class="inpre"><span>インタプリタ</span>list関数と組み合わせると、ジェネレータが生成した値のリストを作ることができます。</p>
<pre>
>>> list(do_yield())
[1, 2, 'Fizz', 4, 'Buzz']
</pre>

<div class="box-example">
    <h3 class="h-example">例1</h3>
	ジェネレータを使って、より本格的なFizz Buzzゲームのプログラムを作ってみます。    
</div>
<p class="editpre"><span>テキストエディタ</span></p>
<pre>
def fizzbuzz(n):
    for x in range(1, n):
        if x % 15 == 0:<span class="comment">  # xが15で割り切れたら</span>
            yield 'FizzBuzz'
        if x % 5 == 0:<span class="comment">  # xが5で割り切れたら</span>
            yield 'Buzz'
        if x % 3 == 0:<span class="comment">  # xが3で割り切れたら</span>
            yield 'Fizz'
        else:　 　　　<span class="comment">  # それ以外の場合</span>
            yield x
            
print(list(fizzbuzz(16)))
</pre>

<pre>
<span class="bold blue">実行結果</span>

[1, 2, 'Fizz', 4, 'Buzz', 5, 'Fizz', 7, 8, 'Fizz', 'Buzz', 10, 11, 'Fizz', 13, 14, 'FizzBuzz', 'Buzz', 'Fizz']
</pre>


<h2 class="h-type2">データ構造のまとめ</h2>

<dl>
    <dt>タプル</dt>
    <dd>複数の要素をまとめるイミュータブルなデータ構造です。丸括弧()で囲んて作成します。<br>パックやアンパックを使って、要素の格納や取り出しができます。</dd>
    <dt>集合</dt>
    <dd>重複する要素を持たないデータ構造です。波括弧{}で囲んで作成します。<br>指定した要素の有無を早く調べたり、集合間で特別な演算をしたりできます。</dd>
    <dt>辞書</dt>
    <dd>キーと値のペアを格納するデータ構造です。波括弧{}でキーと値のペアを囲んで作成します。<br>指定したキーに対応する値を素早く取り出すことができます。</dd>
    <dt>内包表記</dt>
    <dd>リストなどのデータ構造を定義するプログラムを簡潔に書くための仕組みです。</dd>
    <dt>ジェネレータ式</dt>
    <dd>記法は内包表記に似ていますが、要求に応じて一つずつ結果を生成します。</dd>
</dl>

※イミュータブルとは～作成後にその状態を変えることのできないことをいいます。
