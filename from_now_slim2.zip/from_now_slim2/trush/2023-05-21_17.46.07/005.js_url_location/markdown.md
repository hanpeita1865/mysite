*[page-title]:URLを取得（location）

## locationのプロパティとメソッド一覧

| プロパティ名 | 内容 |
|: -------- | -------- |
|location.<span class="green bold">href</span>	| 指定したURLに画面遷移する|
|location.<span class="green bold">protocol</span>	| 現在のプロトコル情報(http:など)を取得する|
|location.<span class="green bold">host</span>	| プロトコル情報を除外したURLを取得する(port情報あり)|
|location.<span class="green bold">hostname</span>	| プロトコル情報を除外したURLを取得する(port情報なし)|
|location.**port**	| ポート番号を取得・設定する|
|location.**pathname**	| URLでパスの部分を取得・設定する|
|location.**search**	| URL内のクエリ情報を抽出して取得する|
|location.**hash**	| URL内のハッシュ情報を抽出して取得する|
|location.**origin**	| プロトコルやポートを含めたURLを取得する|

####  参考例

```
//対象URL
url.href = 'https://developer.mozilla.org:8080/en-US/search?q=URL#search-results-close-container';

console.log(url.href); //https://developer.mozilla.org:8080/en-US/search?q=URL#search-results-close-container
console.log(url.protocol); //https:
console.log(url.host); //developer.mozilla.org:8080
console.log(url.hostname); //developer.mozilla.org
console.log(url.port); //8080
console.log(url.pathname); ///en-US/search
console.log(url.search); //?q=URL
console.log(url.hash); //#search-results-close-container
console.log(url.origin); //https://developer.mozilla.org:8080
```

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	「★★★[abcdefg.... 」をsplitを使って、"["の箇所で区切って、先頭の文字をコンソールに表示する。
	<script async src="//jsfiddle.net/4wmag291/embed/js,result/"></script>
</div>


<div class="exp">
	<p class="tmp"><span>例2</span></p>
    ①「https://github.com/sshono1210/gitLesson」を「/」で区切って、一番最後と最後から2番目の文字をコンソールに表示する。<br>
    ②「http://www.sample.com/img/sample.jpg」を「/」で区切って、一番最後の文字をコンソールに表示する。	
		<script async src="//jsfiddle.net/7jLokmn3/1/embed/js,result/"></script>
</div>
