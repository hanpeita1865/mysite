*[page-title]:フォルダやファイルを開く


## フォルダやファイルを開く

参考サイト
: [【Python】エクスプローラーの起動：指定したフォルダ・ファイルを開く（subprocessモジュール）](https://office54.net/python/app/subprocess-explorer-folder)


作業フォルダ
: C:\xampp\htdocs\test\python\sample1

<p class="tmp list"><span>リスト</span>test2.py</p>
```
import subprocess

path = r"C:\xampp\htdocs"
subprocess.Popen(['explorer', path], shell=True)
```

ターミナルで実行
![](upload/test2.pyターミナルで実行.png)

htdocsのフォルダが開かれました。
![](upload/htdocsが開かれた.png){.photo-border}

また、pathにファイル名を追加すれば、指定したファイルを開くことができます。


<div markdown="1" class="note-box">
次のように、フォルダを開く処理を追記して指定したURLにアクセスすると、path のフォルダ（C:\xampp\htdocs）が開かれます。  

<p class="tmp list"><span>リスト</span>test/python/flask/testapp/views.py</p>
<pre><code class="hljs python"><span class="hljs-keyword">from</span> testapp <span class="hljs-keyword">import</span> app
<span class="marker-yellow"><span class="hljs-keyword">import</span> subprocess</span>

<span class="hljs-meta">@app.route('/')</span>
<span class="hljs-function"><span class="hljs-keyword">def</span> <span class="hljs-title">index</span><span class="hljs-params">()</span>:</span>
    <span class="marker-yellow">path = <span class="hljs-string">r"C:\xampp\htdocs"</span></span>
    <span class="marker-yellow">subprocess.Popen([<span class="hljs-string">'explorer'</span>, path], shell=<span class="hljs-literal">True</span>)</span>
    <span class="hljs-keyword">return</span> <span class="hljs-string">'Hellow World!!'</span>

<span class="hljs-meta">@app.route('/test')</span>
<span class="hljs-function"><span class="hljs-keyword">def</span> <span class="hljs-title">other1</span><span class="hljs-params">()</span>:</span>
    <span class="hljs-keyword">return</span> <span class="hljs-string">"テストページです！"</span></code></pre>
</div>


## WEBページを開く

参考サイト
: [【Python】ファイル・フォルダ・Webページを開く方法【自動化】](https://www.y-shinno.com/python-file-open/)

<p class="tmp list"><span>リスト</span>test4.py</p>
```
import webbrowser

# Webページを開く
webbrowser.open("https://www.nikkansports.com/")
```

実行すると、指定したWEBページが開かれます。
![](upload/日刊スポーツ開く.png){.photo-border}

## OneNoteを開く

WEBページを開くときと同じように、webbrowser.open("パス")を使います。  

<p class="tmp list"><span>リスト</span>test5.py</p>
```
import webbrowser

# OneNoteページを開く
webbrowser.open("onenote:///E:\書類(バックアップ)\OneNote%20ノートブック\佳也%20さんのノートブック2016.1.21\DevTool.one#section-id={66A19CE5-8310-423E-9884-C4EA53756C3D}&end")
```

OneNoteのパスを記入して実行すると、OneNoteのページが開かれます。
![](upload/OneNoteのDevToolページ.png){.photo-border}

