<?php
use Psr\Http\Message\ServerRequestInterface;//テスト
use Psr\Http\Message\ResponseInterface;//テスト

use SocymSlim\SlimMiddle\controllers\SlimMiddleController;

use SocymSlim\SlimMiddle\controllers\MemberController;
use SocymSlim\SlimMiddle\controllers\SearchController;
use SocymSlim\SlimMiddle\middlewares\UserCheck;

use SocymSlim\SlimMiddle\controllers\PreviewController;

require 'admin/basepath.php';

// $app->setBasePath("/from_now_slim/public");
$app->setBasePath($basePath."/public");


$app->any("/pages/{folderName}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/", MemberController::class.":markData");//from_now マークダウン変換


//プレビューテスト
// $app->any("/common/update/preview1.php", MemberController::class.":preview");

// $app->any("/preview1.php", 
//     function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
//         $content = "プレビューテストです!";
//         $responseBody = $response->getBody();
//         $responseBody->write($content);
//         return $response;
//     }
// );

//プレビューテスト
$app->any("/preview1.php", PreviewController::class.":previewData");

// $app->any("/preview1.php", MemberController::class.":preview");
