<?php

	$photo = 'test.jpg';
    list($width, $hight) = getimagesize($photo); // 元の画像名を指定してサイズを取得

	$ratio = $hight/$width;//縦横比

	// echo $ratio;

	if($ratio > 1.05) { //縦長画像
		$reHight = 250;
		$reWidth = $width*$reHight/$hight;
		
	}else{//横長画像
		$reWidth = 300;
		$reHight = $hight*$reWidth/$width;
	}

	// $baseImage = imagecreatefromjpeg($photo);

	// echo $baseImage;

	$ext = 'jpg';

	switch($ext) {
		case 'jpg':
		case 'jpeg':
			$baseImage = imagecreatefromjpeg($photo); // 元の画像から新しい画像を作る準備(jpg用)

			/*if($ratio > 1.05) { //縦長画像野場合、pngも作成
				$baseImage_vertical = imagecreatefromjpeg($photo);//変更
			}*/
			break;
			
		case 'png':
			$baseImage = imagecreatefrompng($photo); // 元の画像から新しい画像を作る準備(png用)
			break;
			
		case 'gif':
			$baseImage = imagecreatefromgif($photo); // 元の画像から新しい画像を作る準備(gif用)
			break;
	}


    $image = imagecreatetruecolor($reWidth, $reHight); // サイズを指定して新しい画像のキャンバスを作成

	//ベース画像の背景色-透過処理
	$bg_color = imagecolorallocatealpha($image, 255, 255, 255, 100);
	imagealphablending($image, true);
	imagesavealpha($image, true);
	imagefill($image, 0, 0, $bg_color);
    
    // 画像のコピーと伸縮
    imagecopyresampled($image, $baseImage, 0, 0, 0, 0, $reWidth, $reHight, $width, $hight);
    
    // コピーした画像を出力する
	switch($ext) {
		case 'jpg':
		case 'jpeg':
			imagejpeg($image , $photo);
			imagepng($image , 'output/image.png');//追加
			break;
			
		case 'png':
			imagepng($image , $photo);
			imagejpeg($image , 'output/image.jpg');//追加
			break;
			
		case 'gif':
			imagegif($image , $photo);
			break;
	}
?>
