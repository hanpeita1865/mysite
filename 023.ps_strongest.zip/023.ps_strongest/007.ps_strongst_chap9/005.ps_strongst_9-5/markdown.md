*[page-title]:9-5. パスの選択範囲作成と塗りつぶし


## 描いたパスから選択範囲を作る ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-05-1.jpg)](upload/9-05-1.jpg){.image}
</div>

## 描いたパスの選択範囲を塗りつぶす ##{.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-05-2.jpg)](upload/9-05-2.jpg){.image}
</div>