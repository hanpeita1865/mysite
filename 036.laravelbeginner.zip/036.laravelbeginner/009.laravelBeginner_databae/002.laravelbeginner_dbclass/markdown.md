*[page-title]:DBクラスの利用



## DBクラスを使ってアクセス

では、実際にデータベースにアクセスしてみることにしましょう。Laravelに用意されている、もっともシンプルなデータベースアクセス機能は「<span class="red bold">DB</span>」クラスです。

このDBクラスには、データベースを利用するためのさまざまな機能が用意されています。中でも、もっともシンプルなのは、SQLのクエリを直接実行するメソッドでしょう。 これを覚えれば、とりあえず大抵のデータベースアクセスは可能になります。 では、このDBクラスを使って、作成したshopデータベースのcustomerテーブルにアクセスをしてみましょう。

#### コントローラーの作成

<p class="tmp list"><span>リスト1-1</span>app/Http/Controllers/HelloDBController.php</p>
```
<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;//を追加(データベースに接続できないので、応急的に記述 )

class HelloDBController extends Controller
{
   public function index(Request $request)
   {
       $items = DB::select('select * from customer');
       return view('hello10.index', ['items' => $items]);
   }
}
```

#### テンプレート作成
「views」内の「hello」フォルダ内にある「index.blade.php」を開き、次のように記入してください。（なければ新規に作成してから記入してください。）

<p class="tmp list"><span>リスト1-2</span>hello10/index.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'customerデータテーブル')

@section('menubar')
   @parent
   customerデータテーブル
@endsection

@section('content')
   <table>
   <tr><th>id</th><th>name</th><th>address</th><th>login</th><th>password</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->id}}</td>
           <td>{{$item->name}}</td>
           <td>{{$item->address}}</td>
           <td>{{$item->login}}</td>
           <td>{{$item->password}}</td>
       </tr>
   @endforeach
   </table>
@endsection
```

「views/layouts/helloapp.blade.php」にテーブルのスタイルを追加しておきます。
<p class="tmp list"><span>リスト1-3</span>layouts/helloapp.blade.php</p>
```
th {background-color:#999; color:fff; padding:5px 10px; }
td {border: solid 1px #aaa; color:#999; padding:5px 10px; }
```

最後にルート情報を追加します。
<p class="tmp list"><span>リスト1-4</span>web.ohp</p>
```
Route::get('helloDB', [\App\Http\Controllers\HelloDBController::class,'index']);
```

<http://localhost:8000/helloDB> に接続すると、次のようにcustomerテーブルのデータが表示されます

![](upload/customerデータ全表示.png "図　customerデータ全表示"){.mt-3 .photo-border}

### パラメータ結合の利用

ただし、複雑な検索になると、SQL文の作成が面倒臭くなってくるのは確かでしょう。 このような場合は、「パラメータ結合」と呼ばれる機能を利用すると簡単にSQLを作成できます。  
パラメータ結合とは、文字列とパラメータ配列を組み合わせてSQL文を作成する方法です。先ほどのサンプルを修正して、パラメータ結合を使ってみましょう。 HelloControllerクラスに以下のjoinアクションメソッドを追加して下さい。

<p class="tmp list"><span>リスト1-5</span>app/Http/Controllers/HelloDBController.php</p>
```
public function join(Request $request)
{
   if (isset($request->id))
   {
      $param = ['id' => $request->id];
      $items = DB::select('select * from customer where id = :id', $param);
   } else {
      $items = DB::select('select * from customer');
   }
   return view('hello.index', ['items' => $items]);
}
```

ルート情報に追加します。
<p class="tmp list"><span>リスト1-6</span>web.ohp</p>
```
Route::get('helloDBJoin', [\App\Http\Controllers\HelloDBController::class,'join']);
```

修正したら、「/helloDBJoin」にアクセスしてみましょう。「/helloDBJoin?id=番号」というようにクエリ文字列を使ってidというパラメータの値を指定してアクセスをして下さい。すると、 そのID番号のレコードを検索して表示します。パラメータを付けず、今まで通り「/helloDB」 とアクセスすると全レコードを表示します。

http://localhost:8000/helloDBJoin?id=6

![](upload/helloDBJoin表示.png "図　id=6のデータを表示"){.mt-3 .photo-border}


### パラメータ結合の働き

では、selectを実行している部分を見てみましょう。issetでクエリ文字列にidというパラメータが送られてきたかチェックし、これがあれば、以下のようにパラメータ用の配列を作成しておきます。
```
$param = ['id' => $request->id];
```

ここでは、['id' => パラメータ]という配列を用意してあります。これをSQL文と一緒 にselectメソッドに渡して実行します。
```
$items = DB::select('select * from customer where id = :id', $param);
```

SQL文を見ると、「<span class="red">where id = :id</span>」と書かれているのがわかります。この「<span class="red">:id</span>」というのは、 パラメータの値をはめ込むプレースホルダ(値を確保しておく場所のこと)です。SQL文 では、このように「名前」という形でプレースホルダを用意しておくことで、その後の引数にある配列から値を指定の場所にはめ込んでSQL文を完成させるのです。

ここでは、:idのところに、第2引数の$param配列から"id"の値を取り出して、はめ込んでいたのです。
このパラメータ結合は、いくつでもパラメータを用意して組み込むことができます。 プレースホルダを多用することで、多くの要素を変数や入力値から取得してSQL文を完成させなければならないときも、比較的簡単に組み立てることができるでしょう。


## DB::insertによるレコード作成

「<span class="green bold marker-yellow50">DB::select</span>」は、基本的にSQLのselect文によるレコード取得に用いるものです。それ以外の操作を行う場合は、別のメソッドを利用する必要があります。それらについても一 通り説明しましょう。

まずは、レコードの追加を行うinsert文を実行する場合です。これは、DBクラスの 「<span class="red">insert</span>」メソッドを利用します。これも基本的な使い方はDB::selectと同様で、引数に SQLのクエリ文の文字列(必要に応じて、第2引数にパラメータの配列)を用意して呼び出します。

<p class="tmp"><span>書式1</span>DB::select</p>
```
DB::insert(クエリ文 , パラメータ配列 );
```
このような形です。DB::insertは、レコードなどを取得するものではないので、戻り値を取得する必要はありません。では、これも利用例を挙げておきましょう。/hello10/addというアクションを用意し、 フォームを送信してレコードを保存できるようにしてみます。

### add.blade.phpの作成

まずは、テンプレートです。今回は、新しいテンプレートファイルを作成しましょう。 「views」内の「hello10」フォルダの中に、新たに「add.blade.php」というファイルを作成して下さい。そして以下のようにソースコードを記述しておきましょう。

<p class="tmp list"><span>リスト2-1</span>hello10/add.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Add')

@section('menubar')
@parent
新規作成ページ
@endsection

@section('content')
<table>
    <form action="/helloDB/add" method="post">
        {{ csrf_field() }}
        <tr>
            <th>name: </th>
            <td><input type="text" name="name"></td>
        </tr>
        <tr>
            <th>address: </th>
            <td><input type="text" name="address"></td>
        </tr>
        <tr>
            <th>login: </th>
            <td><input type="text" name="login"></td>
        </tr>
        <tr>
            <th>password: </th>
            <td><input type="text" name="password"></td>
        </tr>
        <tr>
            <th></th>
            <td><input type="submit" value="send"></td>
        </tr>
    </form>
</table>
@endsection

@section('footer')
copyright 2023
@endsection
```

ここでは、@selectionにフォームを用意してあります。これを「/helloDB/add」に送信してレコードの新規作成の処理をしています。

### HelloDBControllerの修正
では、HelloDBControllerクラスを修正しましょう。先ほどのindexとpostはそのまま残し、新たにaddとcreateメソッドを追加することにします。

<p class="tmp list"><span>リスト2-2</span>app/Http/Controllers/HelloDBController.php</p>
```
public function post(Request $request)
{
    $items = DB::select('select * from customer');
    return view('hello10.index', ['items' => $items]);
}

public function add(Request $request)
{
    return view('hello10.add');
}

public function create(Request $request)
{
    $param = [
        'name' => $request->name,
        'age' => $request->age,
        'address' => $request->address,
        'login' => $request->login,
        'password' => $request->password,
    ];
    DB::insert('insert into customer (name, age, address, login, password) values (:name, :age, :address, :login, :password)', $param);
    return redirect('/helloDB');
}
```

処理をシンプルにするため、パリデーションなどの処理は省略してあります。 ここでは、createアクションメソッドで、送信されたフォームの内容を元にレコードの作成を行っています。まず、$paramに送信フォームの値を保管します。

```
$param = [
   'name' => $request->name,
   'age' => $request->age,
   'address' => $request->address,
   'login' => $request->login,
   'password' => $request->password,
];
```
後は、この配列をパラメータ引数にして、DB::insertを呼び出し実行するだけです。
```
DB::insert('insert into customer (name, age, address, login, password) values (:name, :age, :address, :login, :password)', $param);
```
後半に、「values (:name, :address, :login, :password)」という記述があります。ここで、パラメータ配列$paramから3つの値をはめ込むようにしてあります。これで送信されたフォームの値を元にinsert文を実行する、という処理ができました。 後は、$helloにリダイレクトして移動するだけです。
```
return redirect('/helloDB');
```
リダイレクトは、「redirect」というメソッドで実行します。これにより、/helloに移動させることができます。  
このように、レコードの新規作成は、「<span class="red bold">フォームの値の取得</span>」「<span class="red bold">DB::insertの実行</span>」「<span class="red bold">トップへのリダイレクト</span>」といった作業をセットで実行して完了となります。

### ルート情報の追加

最後に、「/helloDB/add」のルート情報を追加しておきましょう。web.phpを開き、その末尾に以下の文を追記して下さい。
<p class="tmp list"><span>リスト2-3</span>routes/web.php</p>
```
Route::get('helloDB/add', 'HelloDBController@add');
Route::post('helloDB/add', 'HelloDBController@create');
```

これで完成です。「/helloDB/add」にアクセスし、フォームに入力して送信すると、その内容が新しいレコードとしてテーブルに保存されます。

<http://localhost:8000/helloDB/add>

![](upload/helloDBadd.png "図 「/hello10/add」を表示"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/helloDBadd入力.png "図　データを入力して送信"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/helloDBadd登録表示.png "図　登録されてテーブル表示"){.photo-border}


リダイレクトされるので、新しくレコードが保存されていることが確認できます。
データを記入して、送信するとcustomerテーブルにデータが追加されます。


## DB::updateによる更新

続いて、レコードの更新です。これは、updateというSQLクエリ文を使って行います。  
この更新処理を行うのに用意されているのが、DBクラスの「<span class="green bold marker-yellow50">update</span>」メソッドです。

<p class="tmp"><span>書式2</span></p>
```
DB::update(クエリ文 , パラメータ配列 );
```

このように利用します。基本的にDB::insertなどと使い方は同じです。用意するクエリ文が違うだけ、と考えて下さい。  
では、これも実際に作ってみましょう。今回は、「/hello10/edit」というアクションに処理を用意することにします。

### edit.blade.php の作成

まずテンプレートを用意しましょう。「views」内の「hello10」フォルダ内に、新たに「<span class="red">edit.blade.php</span>」というファイルを作成して下さい。ソースコードは以下のようにしておきます。

<p class="tmp list"><span>リスト3-1</span>hello10/edit.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Edit')

@section('menubar')
@parent
更新ページ
@endsection

@section('content')
<table>
    <form action="/helloDB/edit" method="post">
        {{ csrf_field() }}
        <input type="hidden" name="id" value="{{$form->id}}">
        <tr>
            <th>name: </th>
            <td><input type="text" name="name" value="{{$form->name}}"></td>
        </tr>
        <tr>
            <th>address: </th>
            <td><input type="text" name="address" value="{{$form->address}}"></td>
        </tr>
        <tr>
            <th>login: </th>
            <td><input type="text" name="login" value="{{$form->login}}"></td>
        </tr>
        <tr>
            <th>password: </th>
            <td><input type="text" name="password" value="{{$form->password}}"></td>
        </tr>        <tr>
            <th></th>
            <td><input type="submit" value="send"></td>
        </tr>
    </form>
</table>
@endsection

@section('footer')
copyright 2023
@endsection
```

更新用のフォームを用意しておきました。フォームのコントロール類は、valueに $formの値を設定しています。これで、$formに更新するレコードの値を設定しておけば、 その値が表示されるようになります。  
また、非表示フィールドを使い、IDの値をフォームに保管しておくようにしてありま す。この部分になります。

```
<input type="hidden" name="id" value="{{$form->id}}">
```

更新処理では、送信された情報から、まず更新するレコードを取得しないといけません。そのために、レコードのIDを必ず保管しておきます。

### edit および update アクションの追加
続いて、HelloControllerにアクションメソッドを追加します。今回は、editとupdate という2つのアクションメソッドをクラスに追加することにしましょう。

<p class="tmp list"><span>リスト3-2</span>Controllers/HelloDBController.php</p>
```
public function edit(Request $request)
{
    $param = ['id' => $request->id];
    $item = DB::select('select * from customer where id = :id', $param);
    return view('/hello10.edit', ['form' => $item[0]]);
}

public function update(Request $request)
{
    $param = [
        'id' => $request->id,
        'name' => $request->name,
        'address' => $request->address,
        'login' => $request->login,
        'password' => $request->password,
    ];
    DB::update('update customer set name =:name, address = :address, login = :login, password = :password where id = :id', $param);
    return redirect('/helloDB');
}
```

editでは、クエリ文字列を使い、idの値を渡すようにしてあります。これで受け取ったIDのレコードをDB::selectで検索し、それをformという名前でテンプレートに渡します。 なお、idがない場合のエラー処理などは今回省略してあります。 ここでは、以下のような形でクエリ文を用意しています。
```
update customer set name =:name, address = :address, login = :login, password = :password where id = :id
```
update文は、setの後に項目と値を記述していきます。whereで、設定するレコードの 条件を指定しています。これで、指定したIDのレコードの値が更新できます。

### /hello10/editを試す

これで更新の処理そのものは用意できました。最後にweb.phpにルート情報を以下のように記述しておきましょう。

<p class="tmp list"><span>リスト3-3</span></p>
```
Route::get('helloDB/edit', [\App\Http\Controllers\HelloDBController::class,'edit']);
Route::post('helloDB/edit', [\App\Http\Controllers\HelloDBController::class,'update']);
```

一通りの修正ができたら、/helloDB/editにIDの値を付けてアクセスしてみて下さい。例えば、「/hello/edit?id=10」でアクセスすると下図のようにIDが10のレコードが表示されます。 そのまま内容を書き換えてフォームを送信すれば、そのレコードの値が更新されます。

<http://localhost:8000/helloDB/edit>

![](upload/edit_id=10.png "図 「/hello/edit?id=10」でアクセスした表示"){.phpto-border}

<p class="d-flex align-items-center"><span class="arrow-down ml-5 mr-3"></span>赤線のpasswordの値を「0916」に変更して送信しました。</p>

![](upload/edit_0916に変更.png "図　passwordを変更して送信"){.phpto-border}

<p class="d-flex align-items-center"><span class="arrow-down ml-5 mr-3"></span>データレコードのpasswordが書き換わりました。</p>

![](upload/edit_0916に変更テーブル表示.png "図　passwordか変更されました"){.phpto-border}


## DB::deleteによる削除

残るは、レコードの削除です。これはDBクラスの「<span class="green bold marker-yellow50">delete</span>」というメソッドで行います。 使い方はこれまでのメソッドとまったく同じです。

<p class="tmp"><span>書式4</span></p>
```
DB::deleter クエリ文 , パラメータ配列 );
```

このdeleteメソッドは、SQLのdelete文を実行するものです。「delete from テーブル where ～」という形で検索するテーブルと検索条件を指定し、それに合致するレコード を削除します。 では、これもサンプルを作ってみましょう。

### del.blade.php の作成

まずはテンプレートからです。「<span class="bold">views</span>」内の「<span class="bold">hello10</span>」フォルダ内に「<span class="red">del.blade.php</span>」という名前でファイルを作成しましょう。そして以下のように記述しておきます。

<p class="tmp list"><span>リスト4-1</span></p>
```
@extends('layouts.helloapp')

@section('title', 'Delete')

@section('menubar')
   @parent
   削除ページ
@endsection

@section('content')
   <table>
   <form action="/hello/del" method="post">
      {{ csrf_field() }}
      <input type="hidden" name="id" value="{{$form->id}}">
      <tr><th>name: </th><td>{{$form->name}}</td></tr>
      <tr><th>address: </th><td>{{$form->address}}</td></tr>
      <tr><th>login: </th><td>{{$form->login}}</td></tr>
	  <tr><th>password: </th><td>{{$form->password}}</td></tr>
      <tr><th></th><td><input type="submit" value="send"></td></tr>
   </form>
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```

ここではフォームを用意していますが、送信するのは非表示フィールドのID値のみで す。削除するレコードのIDさえわかれば、削除処理は行えますから。その代わりに、削除するレコードの内容をテーブルにまとめて表示しています。これで内容を確認し、削除していいと思ったらボタンを押して送信する、というわけです。

### del および remove アクションの追加
続いて、コントローラへのアクションメソッドの追加です。今回は、delとremoveと いうメソッドとして追加することにしましょう。

<p class="tmp list"><span>リスト4-2</span></p>
```
//delete処理
public function del(Request $request)
{
   $param = ['id' => $request->id];
   $item = DB::select('select * from customer where id = :id', $param);
   return view('hello.del', ['form' => $item[0]]);
}

public function remove(Request $request)
{
   $param = ['id' => $request->id];
   DB::delete('delete from customer where id = :id', $param);
   return redirect('/hello');
}
```
delでの処理は、先ほどの更新処理で作ったeditとほぼ同じです。クエリ文字列で渡されたIDパラメータの値を使ってレコードを取得し、それをformに設定して表示しています。  
削除の処理は、removeで行っています。ここで実行しているSQLクエリ文は以下のようになります。
```
delete from people where id = :id
```
whereを使い、指定したIDのレコードをdelete fromで削除しています。削除は、送信されたID番号さえわかれば行えるので、更新などよりかなり簡単です。  
最後に、web.phpにルーティングの情報を追記して完成です。

<p class="tmp list"><span>リスト4-3</span></p>
```
Route::get('hello/del', 'HelloController@del');
Route::post('hello/del', 'HelloController@remove');
```

/helloDB/delアクションに、idパラメータを付けてアクセスしてみて下さい(/hello/del?id=10といった具合)。そのレコードの内容が表示されます。そのまま送信ボタンを押せば、そのレコードが削除されます。

![](upload/削除前のレコード.png "図　削除前のレコード"){.photo-border}

<http://localhost:8000/helloDB/del?id=10>

<p class="d-flex align-items-center"><span class="arrow-down ml-5 mr-3"></span>「/helloDB/del?id=10」にアクセスし送信ボタンを押すと、</p>
![](upload/del_id=10.png "図　「/helloDB/del?id=10」にアクセス"){.photo-border}

<span class="arrow-down ml-5 mr-3"></span>

ID番号10のレコードが削除されます。
![](upload/del_id=10が削除される.png "図　ID番号10のレコードが削除")

## SQLクエリがすべて?

これで、データベース操作の基本であるCRUD（Create、Read、Update、Delete）の実装ができました。ここまで説明したことがわかれば、データベースを使ったアプリは作れるようになります。  
ただし、説明を見ればわかるように、これらは基本的に全て「SQLクエリ文を書いて実行する」というやり方です。これで確かに動きはしますが、正直いってスマートなやり方ではありません。もっとPHPらしいやり方はできないのか?と思うでしょう。 もちろん、そうした方法も用意されています。それは、「<span class="red bold">クエリビルダ</span>」を利用するのです。









