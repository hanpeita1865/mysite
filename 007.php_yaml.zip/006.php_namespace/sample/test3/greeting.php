<?php
namespace Asia\Japan\Kanto\Tokyo;
function hello() {
        return 'こんにちは';
}
