---
title: 部分一致したクラスを削除
---

<div class="box-example">
    <h3 class="h-example">例1</h3>
    ボタンを押すと「start」から始まるクラスだけ削除します<br>
    ※動作は、デベロッパーツールのElementsで確認ください。
</div>
<iframe width="100%" height="250" src="//jsfiddle.net/hirao/15uztq6j/4/embedded/js,html,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

「/\bstart\S+/g」  
ここの正規表現の部分をいろいろと変えると、思い通りのクラスを削除することができます。

<p class="tmp">HTML</p>
```
<div id="test" class="tttaa startTest tttstart startTtt aaa">ここのクラスの一部削除</div>
```
「startTest」と「 startTtt」が削除されます。
```
<div id="test" class="tttaa tttstart aaa">ここのクラスの一部削除</div>
```




<div class="box-example">
    <h3 class="h-example">例2</h3>
    同じく、ボタンを押すと「start」から始まるクラスだけ削除します。RegExpで正規表現を設定<br>
    ※動作は、デベロッパーツールのElementsで確認ください。
</div>
<iframe width="100%" height="250" src="//jsfiddle.net/hirao/yt90rfqc/3/embedded/js,html,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

### 参考サイト

* [jQueryのremoveClass()で部分一致のclassを削除する](https://cly7796.net/blog/javascript/remove-broad-match-class-with-removeclass/)
* [【javaScript・jQuery】正規表現を使って、要素から特定のクラスを削除する。](https://programming.sincoston.com/remove-class-regex/)