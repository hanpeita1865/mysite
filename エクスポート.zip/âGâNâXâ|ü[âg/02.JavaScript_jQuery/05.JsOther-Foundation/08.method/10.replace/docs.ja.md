---
title: 置換操作（replace）
taxonomy:
    category:
        - docs
media_order: replace-1-2.png
---

* [正規表現で置換する方法](#p1)
* [「split() / join()」の組み合わせ例](#p2)
* [タグを取り除く](#p3)
* [独自関数](#p4)
* [エスケープ処理で変数を使った置換をする](#p5)
* [$～を使った置換](#p6)
* [正規表現を使って特定文字をハイライト](#p6)


「replace()」は、任意の文字列を別の文字列に置き換える（置換）ことができるメソッドになります。

<p class="tmp"><span>書式1</span>replace()</p>
```
var str = 文字列

str.replace( 対象の文字, 置換する文字 );
```
文字列を用意して、「_（アンダーバー）」を「-（ハイフン）」に置換してみます。

<iframe width="100%" height="300" src="//jsfiddle.net/8twd1xLq/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## 正規表現で置換する方法 ##{#p1}

文字列オブジェクトに含まれているreplaceメソッドを用いて文字列内部の任意の文字列を別の文字列に置換することができます。正規表現を用いなくても文字の置換を行うことはできますが、正規表現を用いたほうがより広範な文字列置換を実装できます。

<p class="tmp"><span>書式2</span></p>
```
置換対象の文字列.replace("正規表現","置換後の文字列")
```

【 /正規表現/g 】のように正規表現のあとに「g」をつけると、複数の文字を置換します。「i」も一緒につけると、大文字と小文字の区別なく置換してくれます。

<iframe width="100%" height="200" src="//jsfiddle.net/tnoqybjc/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## 「split() / join()」の組み合わせ例 ##{#p2}

「replace()」メソッドを使って置換の処理を行ってきましたが、実は配列処理を上手く応用することで、同じように「置換」を実現することが可能です！  
利用するのは、文字列を分割して配列データに変換する「split」と、配列データを1つに繋ぎ合わせる「join」の2つです！

<iframe width="100%" height="200" src="//jsfiddle.net/2u5xacg8/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

## タグを取り除く ##{#p3}

&lt;span class="letter show"&gt;G&lt;/span&gt; から &lt;span&gt;タグを取り除く。

<iframe width="100%" height="200" src="//jsfiddle.net/54rbqyng/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## 独自関数 ##{#p4}
replaceAllはIEで効かないので、独自に関数を作成する。

<iframe width="100%" height="250" src="//jsfiddle.net/smyoaveu/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

## エスケープ処理で変数を使った置換をする ##{#p5}

<iframe width="100%" height="450" src="//jsfiddle.net/1bx20p6L/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

## $～を使った置換 ##{#p6}

<iframe width="100%" height="400" src="//jsfiddle.net/Lxd32eyo/8/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

このカッコ()がポイントです。このカッコ内の条件が前から順に$1,$2…と使われます。

![](replace-1-2.png)

phpの[文字列の置換](../../../../php/php_function/string-manipulation)ページでも似た内容のを記載しています。

## 正規表現を使って特定文字をハイライト ##{#p7}

「[表示文章中の、指定の単語だけを動的に強調表示(ハイライト)する方法](https://www.nishishi.com/javascript-tips/auto-word-highlighter.html#auto-word-highlighter0)」のサイトに掲載されていたサンプルです。

<div class="box-example" markdown="1">
### サンプル ### {.h-example}
緑色の文章枠の下にある「ハイライトON/OFF」ボタンを押してみて下さい。押す度に、ハイライトONとハイライトOFFが切り替わります。
[新規タブ](../../../../sample/javascript/sample(hightlight)/index.html?target=_blank)
<iframe width="100%" height="300" src="../../../sample/javascript/sample(hightlight)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

##### JS
```
// ▼①元のHTMLソースを保持しておく変数
var backupOriginal = "";
// ▼②文字列を検索してハイライト用要素を加える処理
function replacer( str, word , att  ) {
    var SearchString = '(' + word + ')';
    var RegularExp = new RegExp( SearchString, "ig" );//iを追加して大文字小文字を区別なしにしています。(平尾)
    var ReplaceString = '<span class="' + att + '">$1</span>';
    var ResString = str.replace( RegularExp , ReplaceString );
    return ResString;
}
// ▼③ハイライトを加える処理
function addhighlight() {
    backupOriginal = document.getElementById("targetspace").innerHTML;
    var forShow = backupOriginal;
    forShow = replacer( forShow, "ハイライト", "mark1" );
    forShow = replacer( forShow, "文章", "mark2" );
    forShow = replacer( forShow, "表示", "mark3" );
	forShow = replacer( forShow, "javascript", "mark3" );
    document.getElementById("targetspace").innerHTML = forShow;
}
// ▼④ハイライトを消す処理
function clearhighlight() {
    document.getElementById("targetspace").innerHTML = backupOriginal;  // バックアップから書き戻す
    backupOriginal = "";    // バックアップを消す
}
// ▼⑤ハイライトを加えるか消すかを判断
function highlightcheck() {
    if( backupOriginal.length == 0 ) {
        // 何もバックアップされていなければ（未ハイライトなので）ハイライトを加える
        addhighlight();
    }
    else {
        // 何かバックアップされていれば（ハイライト済みなので）ハイライトを消す
        clearhighlight();
    }
}
// ▼⑥ボタンクリックイベントに、上記の関数を割り当てる
document.getElementById("btn-onoff").onclick  = highlightcheck;
```

特定の文字を大文字小文字区別せずに強調表示をする。

<iframe width="100%" height="550" src="//jsfiddle.net/7ma0fge8/3/embedded/js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

