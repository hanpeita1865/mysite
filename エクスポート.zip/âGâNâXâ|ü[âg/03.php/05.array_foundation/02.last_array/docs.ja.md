---
title: 配列の最後を取得する
taxonomy:
    category:
        - docs
---

## end関数の使い方

end関数の構文は非常にシンプルで、以下のようになります。  
引数に配列名を指定すれば関数が機能します。

<p class="tmp"><span>書式1</span></p>
```
end($配列名)
```
下記のコードを実行すると、「France」と出力されます。配列の一番後ろの要素が取得されました。

<iframe src="https://paiza.io/projects/e/E3Nk7ctnxPZri1uAt9k21A?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


同様に**reset関数**を使用すると配列の先頭の要素を取得できます。下記のコードを実行すると、「America」と出力されます。
<iframe src="https://paiza.io/projects/e/bLxl4YrF8UwLFQ2aYpm7pw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## foreach文で配列の最後の要素を取得する

foreach文では、end関数を使用するのと同様に配列の最後の要素を取得できます。  
下記のコードを実行すると、「最後の値：France」と出力されます。

※count()は配列の要素の数を数え、それを数値として返す関数です。

<iframe src="https://paiza.io/projects/e/p6Ziq4KUUPuB09UrL_uFdA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## array_key_last()

配列の最後のキーを取得する関数array_key_last()を用います。

array_key_last()の戻り値はキーなので、最後の要素を取得する為には配列にセットしなければいけません。

end()に比べると1ステップ増えますが、内部ポインタが思わぬ挙動をする危険を回避できる事を考えると、より安全な方法と言えるでしょう。

<iframe src="https://paiza.io/projects/e/ecpxr5F3X7mYDFf3u3ff2A?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## 後ろから2番目の値を取得

配列の要素数をcount関数で取得して、そこから「2」を引いた順番の要素で得ることが出来ます。  
他にいい方法があるかも・・・

```
<?php
$countries = ['America', 'Brazil', 'Canada', 'Dominica', 'Ecuador', 'France'];

$order = count($countries)-2;
echo $countries[$order];//Ecuador
?>
```


## 参考サイト
* <https://arma-search.jp/article/php-end#end>
* [PHPで配列の最後の要素を取得する方法を解説！](https://qumeru.com/magazine/81)










