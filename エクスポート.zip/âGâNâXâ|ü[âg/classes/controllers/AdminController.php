<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Container\ContainerInterface;

require '../admin/basepath.php';

class AdminController
{
    // コンテナインスタンス
    private $container;

    // コンストラクタ
    public function __construct(ContainerInterface $container)
    {
        // 引数のコンテナインスタンスをプロパティに格納。
        $this->container = $container;
    }


    //管理画面
    public function adminData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        global $db;
        global $countIp;
        global $folderName;

        $countIp = $request->getAttribute('countIp');
        $folderName = $request->getAttribute('folderName');
        
        //PDOインスタンスをコンテナから取得
        $db = $this->container->get("db");

        //閲覧不可ページリスト テスト
        $stmt = $db->prepare('select page from locklist');
        $stmt->execute();
        $lockArray = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // Twigインスタンスをコンテナから取得。
        $twig = $this->container->get("view");

        // $menuData = file_get_contents('./../templates/layouts/menu_list.twig');
        $menuData = $this->container->get("menuComp");

        $assign["menuData"] = $menuData; //メニューリスト

        $pagesObj = $this->container->get("folderComp"); //pagesオブジェクト
        $folderCnt = count($pagesObj);
        $assign["folderCnt"] = $folderCnt; //フォルダ数取得

        // templateのadmin.twigからを管理画面を生成。
        $response = $twig->render($response, "admin.twig", $assign);

        $pagesObj2 = $this->container->get("folderComp"); //pagesオブジェクト
        $folderCnt2 = count($pagesObj2);
        $_SESSION['count2'] = $folderCnt2;//セッションにフォルダ数登録
        echo "フォルダ数は".$_SESSION['count2']."です。";

        return $response;
    }



    //テスト
    public function testData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
         $content = "レスポンスボディに文字列を格納";
        $responseBody = $response->getBody();
        $responseBody->write($content);

        return $response;
    }


    //フォルダ新規作成
    public function folder_create(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        global $basePath;
        $newFolder = $_POST['post_newFolder'];
        // $basePath = $basePath . '/public/';
        $menuCode = '';
        global $db;

        //半角英数字記号かを判定
        if (preg_match("/^[!-~]+$/", $newFolder)) {
            $pagesGlob = glob('../pages/*');

            foreach ($pagesGlob as  $val) {
                $dirAry = explode('/', $val);
                $fdName = end($dirAry);

                list($fdNum, $name) = explode(".", $fdName);

                $fdNum = (int)$fdNum; //数字型に変換
            }

            $num = sprintf('%03d', $fdNum + 1); //3桁の番号に変換

            mkdir('../pages/' . $num . '.' . $newFolder);
            mkdir('../pages/' . $num . '.' . $newFolder . '/upload');
            file_put_contents('../pages/' . $num . '.' . $newFolder . '/markdown.md', '*[page-title]:メニュー名');

        } else {
            echo '半角英数字記号で入力してください。';
        }

        return $response;
    }


    //メニュー名変更
    public function file_rename(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        global $basePath;
        $post_menu = $_POST['post_menu']; //変更前のメニュー名
        $post_reMenu = $_POST['post_reName']; //変更後のメニュー名
        $post_dir = $_POST['post_dir']; //パス 例) {{basePath}}pages/winKey111/
        $post_dirName = $_POST['post_dirName']; //パス（番号付き）例) 02.winKey111

        $basePath = $basePath . '/public/';

        //「menu_list.twig」のメニュー名の変更処理
        $menu = file_get_contents('../templates/layouts/menu_list.twig');

        $post_dir_re = str_replace($basePath, '', $post_dir);
        $post_dir_esc = preg_quote($post_dir, '/'); //エスケープ処理
        $post_menu = preg_quote($post_menu); //エスケープ処理

        $menuRe = preg_replace('/(.*)' . $post_dir_esc . '(.*)' . $post_menu . '(.*)/i',  '$1' . $post_dir . '$2' . $post_reMenu . '$3', $menu);

        file_put_contents('../templates/layouts/menu_list.twig', $menuRe);

        // //「markdown.md」のtitle値の変更処理
        $md = file_get_contents('../pages/' . $post_dirName . '/markdown.md'); //マークダウンの内容を変数に格納

        preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle); //マークダウン内のタイトル名を配列に格納

        if (!empty($ArrayTitle[1])) {
            $md = preg_replace("/^\*\[page-title\]:\s*(.+)/", '*[page-title]:' . $post_reMenu, $md); //タイトル名を変換
            file_put_contents('../pages/' . $post_dirName . '/markdown.md', $md); //マークダウンを保存
        } else {
            //マークダウン内にtitleがない場合、新規に追加
            file_put_contents('../pages/' . $post_dirName . '/markdown.md', '*[page-title]:' . $post_reMenu . "\n\n" . $md);
        }

        echo 'メニュー名を「' . $post_reMenu . '」に変更しました。';

        return $response;
    }


    //フォルダ名変更
    public function folder_rename(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        $post_dir = $_POST['post_dir'];
        $post_redir = $_POST['post_redir'];
        $post_name = $_POST['post_folderName'];
        $post_rename = $_POST['post_folderReName'];
        $content = '';

        //半角英数字記号かを判定
        if (preg_match("/^[!-~]+$/", $post_redir)) {
            //フォルダ名変更
            rename('../pages/' . $post_dir, '../pages/' . $post_redir);
            //メニューのフォルダ名変更
            $menu = file_get_contents('../templates/layouts/menu_list.twig');

            $menu_re = preg_replace('/' . $post_name . '\/"(.*)>/i', $post_rename . '/"$1>', $menu);
            file_put_contents('../templates/layouts/menu_list.twig', $menu_re);

            //DB locklistテーブル変更
            $db = $this->container->get("db");

            $sql = $db->prepare('select * from locklist where page=?');
            $sql->execute([$post_name]);
            $lockCnt = $sql->rowCount();

            if ($lockCnt) {
                $result = $sql->fetch(PDO::FETCH_ASSOC);
                $sql = $db->prepare('update locklist set page=? where id_lock=?');

                if ($sql->execute([$post_rename, $result['id_lock']])) {
                    echo 'データを変更しました。';
                } else {
                    $content = 'テーブル修正に失敗しました。' . "\n";
                }
            }

            $content = $content . "フォルダ名を変更しました。";
        } else {
            $content = "半角英数字記号で入力してください。";
        }

        $responseBody = $response->getBody();
        $responseBody->write($content);

        return $response;
    }


    //ロック設定・解除
    // public function page_lock(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    // {
    //     $db = $this->container->get("db");
    //     $sql = $db->prepare('select * from locklist where page=:folder');
    //     $folder = $_REQUEST['folderName'];
    //     $sql->bindValue(':folder', $folder);
    //     $sql->execute();

    //     $lockCnt = $sql->rowCount();

    //     if ($lockCnt) {
    //         //リストに有り（削除）
    //         $sql = $db->prepare('delete from locklist where page=:folder');
    //         $sql->bindValue(':folder', $folder);

    //         if ($sql->execute()) {
    //             $content = '削除に成功しました。';
    //         } else {
    //             $content = '削除に失敗しました。';
    //         }

    //     } else {
    //         //リストになし（追加）
    //         $sql = $db->prepare('insert into locklist values(null, :folder, :under)');
    //         $under = 'all';//テスト

    //         $sql->bindValue(':folder', $folder);
    //         $sql->bindValue(':under', $under);

    //         if ($sql->execute()) {
    //             $content = '追加に成功しました。';
    //         } else {
    //             $content = '追加に失敗しました。';
    //         }            
    //     }

    //     $responseBody = $response->getBody();
    //     $responseBody->write($content);

    //     return $response;
    // }

    //ロック設定
    public function page_lock(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $db = $this->container->get("db");
        $sql = $db->prepare('select * from locklist where page=:folder');
        $folder = $_REQUEST['folderName'];
        $under_dir = $_REQUEST['under_dir'];

        $sql->bindValue(':folder', $folder);
        $sql->execute();
        $lockCnt = $sql->rowCount();

        if (!$lockCnt){
            $sql = $db->prepare('insert into locklist values(null, :folder, :under)');

            $sql->bindValue(':folder', $folder);
            $sql->bindValue(':under', $under_dir);

            if ($sql->execute()) {
                // $content = 'ロックを追加しました。';
            } else {
                // $content = '追加に失敗しました。';
            }            
        }else{
            //データ登録有り
        }

        // $responseBody = $response->getBody();
        // $responseBody->write($content);

        return $response;
    }


    //ロック解除
    public function page_unlock(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $db = $this->container->get("db");
        $sql = $db->prepare('select * from locklist where page=:folder');
        $folder = $_REQUEST['folderName'];

        $sql->bindValue(':folder', $folder);
        $sql->execute();
        $lockCnt = $sql->rowCount();

        if ($lockCnt){

            $sql = $db->prepare('delete from locklist where page=:folder');
            $sql->bindValue(':folder', $folder);

            if ($sql->execute()) {
                // $content = 'ロックを解除しました。';
            } else {
                // $content = '追加に失敗しました。';
            }            
        }else{
            //データ登録有り
        }

        // $responseBody = $response->getBody();
        // $responseBody->write($content);

        return $response;
    }


    //フォルダのリスト取得
    public function folder_list(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        $content = $this->container->get("folderList");

        $responseBody = $response->getBody();
        $responseBody->write($content);

        return $response;
    }


    //並べ替え確定（構成フラットから新しいフォルダ構成作成）
    public function sort_complete(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        
        global $basePath;
        global $sourcePath;

        $sourcePath = '../pages';

        $pagesObj1 = $this->container->get("folderComp"); //pagesオブジェクト
        $folderCnt1 = count($pagesObj1);


        $this->container->get("frat_create"); //pages_copyへフラットフォルダ構成の生成
        sleep(5);
        $this->container->get("create"); //pagesに再生成したフォルダ構成の作成

        $pagesObj2 = $this->container->get("folderComp"); //pagesオブジェクト
        $folderCnt2 = count($pagesObj2);

        if($folderCnt1 !== $folderCnt2){
            echo "実行前フォルダ数は、".$folderCnt1."で、実行後フォルダ数は、".$folderCnt2."になりました。<br>移動できなかったフォルダを確認してください。";
        }

        return $response;
    }


    //lockデータ削除
    public function lockdata_del(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        $db = $this->container->get("db");
        $sql = $db->prepare('select * from locklist where page=?');
        $sql->execute([$_POST['post_delFolder']]);

        $lockCnt = $sql->rowCount();

        if ($lockCnt) {
            //リストに有り（削除）
            $sql = $db->prepare('delete from locklist where page=?');
            if ($sql->execute([$_POST['post_delFolder']])) {
                echo '削除に成功しました。';
            } else {
                echo '削除に失敗しました。';
            }
        }

        return $response;
    }


    //削除したフォルダをゴミ箱(trush)に移動
    public function trush(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        $res = glob('../pages_copy' . '/*');
        date_default_timezone_set('Asia/Tokyo'); //日本時間にセット
        $dateTime = date('Y-m-d_H.i.s');

        sleep(3);

        foreach ($res as $item) {
            mkdir('../trush/' . $dateTime); //削除日時フォルダ
            $itemRe = str_replace('pages_copy', 'trush' . '/' . $dateTime, $item);

            if (rename($item, $itemRe)) {
                //移動しました。
            }
        }

        return $response;
    }


    //フォルダ構成をメニューに反映
    public function folder_complist(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        global $basePath;
        $basePath = $basePath . '/public/';
        $menuCode = '';
        global $db;

        //メニュー生成
        $db = $this->container->get("db");
        $menuCode = $this->container->get("menuComp");
        file_put_contents("../templates/layouts/menu_list.twig", $menuCode);

        return $response;
    }



    //対象のフォルダのみ削除 folderDelOnly
    public function folderDelOnly(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        global $basePath;
        global $delFolder; //削除するフォルダのパス
        global $dateTime;

        $basePath = $basePath . '/public/';

        $folderObj = $this->container->get("folderObjGet"); //フォルダのオブジェクト取得 例)Array ( [guide] => ../pages/001.guide ,･･･)
        $delFolder = $folderObj[$_POST['folderName']]; //削除するフォルダのパス 例)../pages/042.aaa

        $this->container->get("subpage_move"); //第二階層まで

        return $response;
    }


    //対象フォルダを中身ごとまとめて削除してメニュー再生成
    public function del_allfolder(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        global $basePath;
        global $delFolder; //削除するフォルダのパス
        global $dateTime;
        $menuCode = '';
        global $db;

        $basePath = $basePath . '/public/';

        $folderObj = $this->container->get("folderObjGet"); //フォルダのオブジェクト取得 例)Array ( [guide] => ../pages/001.guide ,･･･)
        $delFolder = $folderObj[$_POST['folderName']]; //削除するフォルダのパス 例)../pages/042.aaa

        $this->container->get("del_allfolder");

        return $response;
    }


    //pagesをtempにバックアップ
    public function backup(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        global $basePath;
        $basePath = $basePath . '/public/';

        $this->container->get("pages_backup");
        return $response;
    }


    //フォルダ数表示
    public function folder_cnt(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        $pagesObj = $this->container->get("folderComp"); //pagesオブジェクト
        $folderCnt = count($pagesObj);
        // print_r($folderCnt);

        return $response;
    }


    //pages_copyに残ったフォルダをpagesフォルダに戻す　テスト
    public function pagescopy_rest(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        $menuArray1 = json_decode($_POST['list']);
        $menuObj = [];

        foreach ($menuArray1 as $val) {
            $dirArray = explode('/', $val);
            $lastDir = end($dirArray); //配列の最後の値
            $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
            $menuObj[$folderNoNum] = '../pages/'.$val;
        }

        $copy_rest = glob('../pages_copy/*');

        foreach($copy_rest as $val){
            $dirArray = explode('/', $val);
            $lastDir = end($dirArray); //配列の最後の値
            $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);

            //pages_copyからpagesに残ったフォルダを戻す
            if (rename($val, $menuObj[$folderNoNum])) {
                //echo "OK";
                // echo $key;
            } else {
                //echo "エラー";
            }
        }

        return $response;
    }


    //並び替え確定（差分ディレクトリのみ移動）
    public function execution_sabun(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        global $basePath;
        global $sabunMenu;
        global $sourcePath;
        global $res_merge;

        $sourcePath = '../pages';


        $pagesObj1 = $this->container->get("folderComp"); //pagesオブジェクト
        $folderCnt1 = count($pagesObj1);

        $menuArray1 = json_decode($_POST['list']);
        $menuObj = [];

        foreach ($menuArray1 as $val) {
            $dirArray = explode('/', $val);
            $lastDir = end($dirArray); //配列の最後の値
            $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
            $menuObj[$folderNoNum] = '../pages/'.$val;
        }

        $sabunFolder = array_diff($pagesObj1, $menuObj);

        $array2 = [];
        $array3 = [];
        
        foreach ($sabunFolder as $value){
            $array1 = explode('/', $value);
            $cnt = count($array1);
            
            iF($cnt==3){
                array_push($array2, $value);
            } else if($cnt==4 && !in_array($array1[2], $array2)){
                array_push($array3, $value);
            } else if($cnt >= 5){
                //第四階層以下は、第三階層にする
                $value = $array1[0].'/'.$array1[1].'/'.$array1[2].'/'.$array1[3];
                array_push($array3, $value);               
            }
        }

        $res2 = array_unique($array2);//第二階層の差分ディレクトリ
        $res3 = array_unique($array3);//第三階層の差分ディレクトリ
 
        //第三階層ディレクトリが第二階層階層にあれば、第三階層のディレクトリは削除
        foreach ($res2 as $value){
            foreach ($res3 as $key => $item){
                if(strpos($item, $value) !== false){
                    unset($res3[$key]);
                }
            }
        }

        $res_merge = array_merge($res2, $res3);

        $this->container->get("frat_create_test");//pages_copyへフラットに移動

        sleep(2);

        $this->container->get("create"); //pagesに再生成したフォルダ構成の作成


        $pagesObj2 = $this->container->get("folderComp"); //pagesオブジェクト
        $folderCnt2 = count($pagesObj2);

        if($folderCnt1 !== $folderCnt2){
            echo "実行前フォルダ数は、".$folderCnt1."で、実行後フォルダ数は、".$folderCnt2."になりました。<br>移動できなかったフォルダを確認してください。";
        }

        return $response;
    }

}
