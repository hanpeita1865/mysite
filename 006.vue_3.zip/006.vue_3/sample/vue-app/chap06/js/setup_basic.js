Vue.createApp({})
  .component('my-counter', {
    props: ['init'],
    template: `<div>現在値は{{ current }}です！
      <input type="button" v-on:click="onclick" value="増やす" /></div>`,
    setup(props, context) {
      //データオブジェクトの準備
      const current = Vue.ref(props.init);
      //イベントハンドラの宣言
      const onclick = () => {
        current.value++;
      };
      // console.log(Vue.isRef(current));
      //コンポーネント定義を束ねたものを戻り値
      return {
        current,
        onclick
      };
    }
  })
  .mount('#app');

