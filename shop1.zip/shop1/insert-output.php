<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加完了</title>
</head>
<body>
<?php
    session_start();

    //トークンが存在しないか、セッションのトークンと送信されたトークンの値が一致しない場合は、処理停止。
    if (!isset($_POST["token"]) || $_POST["token"] != $_SESSION['token']) {
        echo "<p>不正なリクエストです</p>";
        echo '<p><a href="index.php">一覧に戻る</a></p>';
        exit();
    }

    //以下、処理続行
    $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
    $sql=$pdo->prepare('insert into products values(null, :name, :local, :price, :path)');

    $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
    $local = htmlspecialchars($_POST['local'], ENT_QUOTES, 'UTF-8');
    $price = htmlspecialchars($_POST['price'], ENT_QUOTES, 'UTF-8');
    
    //一時的保存にファイルがあるか確認
    if (empty($_FILES['image']['tmp_name'])){
        $imgpath = '';
    }else{
        $imgpath = $_FILES['image']['name'];        
    }

    $sql->bindValue(':name', $name);
    $sql->bindValue(':local', $local);
    $sql->bindValue(':price', $price);

    //セッション登録（name,local,price）
    require 'set-session.php';

    //バリデーション
    require 'validation.php';
    $errors = validation($_POST, $imgpath);//入力エラーチェック

    // print_r($errors);

    //一時的保存にファイルがあるかかつ入力エラーがないか確認
    if (!empty($_FILES['image']['tmp_name']) && empty($errors)) {

        //保存用のフォルダがなければ作成する
        if(!file_exists('images')){
            mkdir('images');
        }

        //フォルダにファイルを一時的保存から移動して格納
        if(move_uploaded_file($_FILES['image']['tmp_name'], 'images/'.$_FILES['image']['name'])){
            //画像保存に成功
        }else{
            $errors[] = '画像保存に失敗しました。';
        }
    }

    $sql->bindValue(':path', $imgpath);


    if(!empty($errors)){
        //エラーがある
        $_SESSION['flash']['message'] = $errors;

        //画像と画像ファイル名をセッションに登録
        $_SESSION['image']['data'] =  $_POST['image-base64'];
        $_SESSION['image']['name'] = $imgpath;

        header('Location:insert-input.php');//入力画面に戻る
        exit();

    }elseif ($sql->execute()) {
        //新規登録に成功　セッション削除
        require 'delete-session.php';

        $_SESSION['flash']['success'] = '「'.$_POST['name'].'」を新規登録しました。';

        header('Location:index.php');//一覧画面に戻る
        exit();

    } else {
        //新規登録に失敗
        $_SESSION['flash']['message'] = '新規登録に失敗しました。';
        header('Location:insert-input.php');//入力画面に戻る
        exit();
    }
?>
</body>
</html>