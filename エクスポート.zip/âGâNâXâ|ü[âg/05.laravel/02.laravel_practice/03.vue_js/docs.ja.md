---
title: Vue.jsを利用する
media_order: 'vue_hello.png,vue_hello2.png,vue_hello3.png'
---

## Vue.jsのセットアップ
現在のWebアプリでは、サーバーサイドだけでなく、フロントエンドでのフレームワー ク利用も当たり前に行われるようになっています。こうしたフロントエンドフレームワー クをLaravelアプリケーションから利用することも多いでしょう。フロントエンドフレームワークのLaravelアプリケーションへの組み込みと利用について考えていきましょう。

まずは、Vue.jsからです。Vue.jsは、AngularJSの開発チームの一員であったEvan You 氏によって開発されたオープンソースのフロントエンドフレームワークです。個人レベ ルで作られたものでありながら、ReactやAngularなどに並ぶ支持を得ており、日本にお いても広く普及しているフロントエンドフレームワークの1つといえるでしょう。

Vue.jsに限らず、ReactやAngularなどのフロントエンドフレームワークを利用した開発を行う場合、「Node.js」を用意しておく必要があります。Laravelでフロントエンドフ レームワークを利用するには、Node.jsのパッケージ管理ツール(npm)を使って必要なソフトウェアを管理します。従って、事前にNode.jsをインストールしておいて下さい。

### Vue.js 開発の準備
Vue.jsのセットアップは、非常に簡単です。なぜなら、Laravelのプロジェクトでは、 デフォルトでVue.js利用のための設定が済んでいるからです。  
Laravelプロジェクトのルートには「package.json」ファイルが標準で用意されていま す。これは、npm(Node.jsに用意されているパッケージ管理ツール)によるパッケージ情 報を記述したファイルで、プロジェクトで利用するパッケージ等の情報がすべてここに記述されています。これを開くと、標準で次のような内容が記述されています(細かなバージョン番号などは異なる場合があります)。

<p class="tmp list"><span>リスト1</span></p>
```
{
    "private": true,
    "scripts": {
        ……略……
    },
    "devDependencies": {
        "axios": "^0.18",
        "bootstrap": "^4.0.0",
        "cross-env": "^5.1",
        "jquery": "^3.2",
        "laravel-mix": "^4.0.7",
        "lodash": "^4.17.5",
        "popper.js": "^1.12",
        "resolve-url-loader": "^2.3.1",
        "sass": "^1.15.2",
        "sass-loader": "^7.1.0",
        "vue": "^2.5.17",
        "vue-template-compiler": "^2.6.10"
    }
}
```

devDependenciesに、プロジェクトで使われれるパッケージがまとめられています。 ここで、"vue"と"vue-template-compiler"というパッケージが見えるでしょう。これら がVue.js利用のパッケージです。このほか、bootstrapやjqueryなど広く使われているライブラリ類も最初から用意されていることがわかります。

### パッケージをインストールする
これらのパッケージは、まだ組み込まれてはいません。実際に利用する場合は、コマンドでインストールを行います。コマンドプロンプトまたはターミナルを起動し、カレントディレクトリをLaravelのプロジェクト内に移動してから、次のように実行して下さい。
```
npm install
```

これで、package.jsonに記述されたパッケージ類がすべてインストールされます。インストールには意外に時間がかかるので、すべて完了するまで待ちましょう。

### プロジェクトをビルドする
インストールしただけでは、まだVue.jsは動作しません。実際にVue.jsを使えるようにするためには、ビルド作業が必要になります。 コマンドプロンプトまたはターミナルから次のコマンドを実行して下さい。
```
npm run dev
```

これでプロジェクトのビルドが実行されます。ビルドでは、スタイルシートとスクリプトを単一ファイルにまとめて最適化し、/public/js/app.jsと/public/css/app.cssに出 力をします。この2つのファイルをロードすれば、Vue.jsの機能が使えるようになる、というわけです。  
このビルド作業には、Webpackという技術が利用されています。Webpackによりスクリプトやスタイルシートなどがすべて1つにまとめられ、それを読み込むことで、すべてが使えるようになります。

## コンポーネントを利用する
Vue.jsは、コンポーネントとしてプログラムを作成します。Laravelのプロジェクトには、標準で「ExampleComponent」というVue.jsのコンポーネントが用意されています。これは、/resources/js/components/ExampleComponent.vueというファイルとして 用意されています。  
Vue.jsのコンポーネントは、このサンプルのように/resources/js/components/という フォルダに配置します。ここに用意することで、コンポーネントが自動的に認識され、 使えるようになります。

### index.blade.php でコンポーネントを利用する
では、サンプルに用意されているコンポーネントを利用してみます。ここでは、HelloControllerで利用している index.blade.phpを使うことにしましょう。  /resources/views/hello/index.blade.phpを開き、次のように内容を書き換えて下さい。

<p class="tmp list"><span>リスト2</span></p>
```
<!doctype html>
<html lang="ja">
<head>
    <title>Index</title>
    <link href="{{ mix('css/app.css') }}" 
        rel="stylesheet" type="text/css">
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body style="padding:10px;">
    <h1>Hello/Index</h1>
    <p>{{$msg}}</p>


    <div id="app">
        <example-component></example-component>
    </div>
    <script src="{{ mix('js/app.js') }}"></script>


</body>


</html> 
```

### HTMLをチェックする
ここでは、いくつかチェックすべきポイントがあります。順に説明をしていきましょう。

■CSSの読み込み 
```
<link href="{{ mix('css/app.css') }}" rel="stylesheet" type="text/ css">
```

ヘッダー部分では、CSSファイルを読み込むための<link>が用意されています。ここでは、hrefに{{ mix('css/app.css') }}と設定をしています。これは重要です。  
Vue.jsを追加したプロジェクトでは、CSSファイルは2箇所に配置されることになります。 /resources/css/と/public/css/です。この両方の階層にある同名のファイルを合 わせて読み込むために、mixが使われています。mix(パス)とすることで、必要なCSSファ イルを1つにまとめて読み込むようになります。

■CSRFトークンの挿入 
```
<meta name='csrf-token" content="{{ csrf_token() }}">
```

LaravelでVue.jsを利用する場合、CSRFトークンを追加することが推奨されています。 これはそのためのタグです。単に指定のページにGETアクセスするだけなら、なくとも 問題はありませんが、JavaScriptのコンソールなどでは、警告が出力されるのが確認できます。特に理由がない限り、追記しておきましょう。

■Vue.jsのコンテナ 
```
<div id="app">
 	...略 ... 
</div>
```

Vue.jsのコンポーネントは、id="app"を設定したVue.jsのコンテナタグ内に組み込まれます。この&lt;div id="app"&gt;がコンテナとなる部分です。

■コンポーネントタグ 
```
<example-component></example-component>
```

ExampleComponentを組み込んでいる部分です。Vue.jsでは、コンポーネントはタグとして記述できます。この&lt;example-component&gt;タグで、サンプルの ExampleComponentコンポーネントが組み込まれます。

■スクリプトのロード 
```
<script src="{{ mix('js/app.js')}}"></script>
```
最後にある&lt;script&gt;タグで、スクリプトを読み込んでいます。これは、必ずコンテナタグの後に記述して下さい。コンテナタグより前に書くと実行に失敗します。  
またsrcでは、スタイルシートと同様、mixを使ってapp.jsをロードします。スクリプトファイルも、/resources/js/と/public/js/に分かれているので、ビルドによりこれらをひとまとめにしたものを読み込むようにします。

### ExampleComponent をチェックする
では、&lt;example-component&gt;でHTMLに埋め込んでいるExampleComponent コンポーネントはどのようになっているのでしょうか。  
/resources/js/components/ExampleCommponent.vueの内容をざっと確認しておきましょう。

<p class="tmp list"><span>リスト3</span></p>
```
<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Example Component</div>


                    <div class="card-body">
                        I'm an example component.
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
```

Vue.jsのコンポーネントは大きく2つの部分で構成されます。1つは、コンポーネントとしての表示を構築するテンプレート部分です。これは、**&lt;template&gt;**タグの中に、HTMLタグを使って内容を記述します。

もう1つは、コンポーネント用のスクリプトです。これは、**export default{......}**という形で記述されています。この中に、用途に応じてメソッドを用意しています。デフォルトでは、**mounted**というメソッドが用意されており、これはコンポーネントをマウントした際に実行される初期化処理です。  
「&lt;template&gt;内に表示の内容を記述し、&lt;script&gt;タグに必要な処理を追加する」ことで、 Vue.jsのコンポーネントが作成されるのです。

### コントローラーを修正する
最後に、コントローラーを修正しておきます。HelloController@indexメソッドを次のように修正して下さい。

<p class="tmp list"><span>リスト4</span></p>
```
public function index()
{
    $data = [
        'msg' => 'This is Vue.js application.',
    ];
    return view('hello.index', $data);
}
```
既に/helloのルート情報は/routes/web.phpに記述されているはずですが、もしまだ記述していない場合は、次のようにルート情報を追記しておきます。

<p class="tmp list"><span>リスト5</span></p>
```
Route::get('/hello', 'HelloController@index');
```

### プログラムの実行
アプリケーションの動作確認は、まず**npm run dev**でビルドし、それから**php artisan serve**を実行してアクセスし、動作を確認します。事前にビルドする必要がある、という点を忘れてはいけません。 が、サーバー起動時に次のコマンドも実行しておくと更に便利でしょう。

<p class="tmp cmd"><span>コマンド1</span></p>

npm run watch

run watchは、スタイルシートとスクリプトファイルを監視し、これらが更新される とその場でビルドして、これらの内容を更新します。  
これを実行していれば、スクリプトを書き換えた際も自動で更新されます。いちいち 「サーバー停止 → ビルド → サーバー実行」と作業をする必要はありません。

実行手順がわかったら、実際に/helloにアクセスをして表示を確認しておきましょう。画面に「Example Component」と表示された四角いエリアが現れます。これが、 ExampleComponentによる表示です。

![](vue_hello.png)

## コンポーネントを作成する
Vue.jsの動作が確認できたところで、Vue.jsの開発の基本として「**コンポーネントの作成**」を行ってみましょう。  
コンポーネントは、先に述べたように/resources/js/components/内に**.vue**ファイルと して配置をします。では、ここに「**MyComponent.vue**」という名前でファイルを用意しましょう。そして次のように記述をします。

<p class="tmp list"><span>リスト6</span></p>
```
<template>
    <div class="container">
        <p>{{msg}}</p>
        <hr>
        <input type="text" v-model="name">
        <button v-on:click="doAction">click</button>
    </div>
</template>


<script>
export default {
    data:function(){
        return {
            msg:'please your name:',
            name:'',
        };
    },
    methods:{
        doAction:function(){
            this.msg = 'Hello, ' + this.name + '!!';
        }
    }
}
</script>
```

ここでは、{{msg}}で変数を埋め込み、v-model="name"で入力フィールドの値にモデルを設定し、on:click="doAction"でボタンにdoActionメソッドを設定してあります。  MyComponent コンポーネントの内容やdoActionメソッドの処理について&lt;script&gt;タグで用意しています。この辺りはVue.jsの基本ですね。

### コンポーネントの登録
作成されたMyComponentを登録します。 resources/js/app.jsを開き、適当なところに次の文を追記します。ExampleComponentを登録するVue.component文が記述されているので、その前後辺りでいいでしょう。

<p class="tmp list"><span>リスト7</span></p>
```
Vue.component('my-component', require('./components/MyComponent.vue').default);
```

### コンポーネントの組み込み
最後に、作成したMyComponentをindex.blade.phpに組み込みます。先に記述した **&lt;div id="app"&gt;**タグの部分を次のように修正しておきます。

<p class="tmp list"><span>リスト8</span></p>
```
<div id="app">
    <my-component></my-component>
</div>
```

![](vue_hello2.png)


すべての修正ができたら、/helloにアクセスして動作を確認します。入力フィールドに名前を書いてボタンをクリックすると、メッセージが表示されます。Vue.jsのコンポー ネントが問題なく機能していることが確認できるでしょう。  
Vue.jsのコンポーネントの利用は、いくつかのポイントを押さえておけば、比較的簡単に行えます。

* コンポーネントのファイルは、/resources/js/components/内に.vueファイルとして作成する。 
* 作成したコンポーネントは、/resources/app.js内でVue.componentメソッドを 使って登録する。 
* コンポーネントの利用は、HTML内にコンポーネントに対応するタグを記述して行う。

これだけ理解していれば、Laravelの中でVue.jsのコンポーネントを作成し利用するのはそう難しくはありません。

## axiosでJSONデータを取得する
Laravelでは、複数のページを作成・送信して表示を行います。が、Vue.jsは、基本的 に現在のページで完結する形で動作します。

例えば必要なデータをサーバーから受け取る場合も、従来はフォーム送信やパラメー タを付けてアクセスすることで情報を渡し、取得したデータを使ってページ全体をレン ダリングしました。 しかし、Vue.jsでは、ページ全体を送信してリロードすることはありません。従ってデータなどが必要な場合は、ページ内からAjaxなどを使い、サーバーにアクセスしてデータを受け取ることになります。  
サーバー側では、必要に応じてJSONデータなどを出力するアクションを用意しておき、クライアント側からAjaxでアクションにアクセスしてデータを受け取る、という形 になるでしょう。

Vue.jsの場合、こうしたAjaxによるデータアクセスには「**axios**」を利用するのが便利です。axiosはオープンソースのHTTPクライアントです。非同期でのサーバーアクセスを非常に使いやすい形で実現します。XMLHttpRequestなどを直接使うよりはるかに便利です。

このaxiosは、Laravelのpackage.jsonに標準で記述されており、npm installした際に既にプロジェクトに組み込まれています。ですから別途インストールなどの作業をする必要はありません。

### json メソッドについて
では、実際に試してみましょう。先にHelloControllerにjsonというメソッドを作成しました。(リスト3-44)これはPersonのデータをJSON形式のテキストで出力するもので、 次のようになっています。

<p class="tmp list"><span>リスト9</span></p>
```
public function json($id = -1)
{
    if ($id == -1)
    {
        return Person::get()->toJson();
    }
    else
    {
        return Person::find($id)->toJson();
    }
}
```

idパラメータがあればそのidのPersonをJSON形式で出力し、そうでない場合は全Personを出力する、というものですね。これらは/routes/web.phpで次のような形でルーティングされています。

<p class="tmp list"><span>リスト10</span></p>
```
Route::get('/hello/json', 'HelloController@json');
Route::get('/hello/json/{id}', 'HelloController@json');
```

では、このHelloController@jsonを利用するコンポーネントを作成しましょう。先ほどのMyComponentを再利用します。/resources/js/components/MyComponent.vue(リスト5-6)を開き、次のように書き換えて下さい。

<p class="tmp list"><span>リスト11</span></p>
```
<template>
    <div class="container">
        <p>{{msg}}</p>
        <hr>
        <ul>
            <li v-for="(person,key) in people">
                {{person.id}}: {{person.name}} [{{person.mail}}] ({{person.age}})
            </li>
        </ul>
    </div>
</template>


<script>
const axios = require('axios');


export default {
    mounted () {
        axios.get('/hello/json')
            .then(response =>{
                this.people = response.data;
                this.msg = 'get data!';
            });
    },
    data:function(){
        return {
            msg:'wait...',
            name:'',
            people:[],
        };
    },
    methods:{
        doAction:function(){
            this.msg = 'Hello, ' + this.name + '!!';
        }
    },
}
</script>
```
![](vue_hello3.png)


修正したら/helloにアクセスしてみて下さい。画面が表示されると、一瞬遅れて peopleテーブルの内容がリスト表示されます。非同期でサーバーにアクセスしているため、アクセスと同時には表示されません。

### axios の利用について
では、axiosの利用について簡単に説明しておきましょう。ここでは、スクリプトの mountedに処理を用意してあります。mountedは、コンポーネントがマウントされる際に実行され、初期化処理などが用意されます。アクセスしたとき、自動的にデータを取得するようにしてあります。 axiosは、次のような形で実行しています。

```
axios.get('/hello/json').then(response =>{......});
```

getは、引数に指定したアドレスにGETアクセスをします。ここでは、先に作成した/ hello/jsonにアクセスをしています。これにより、peopleテーブルの内容がJSONデータ の形式で取得できます。  
アクセス後の処理はthenのクロージャで処理されます。クロージャの引数には、サー バーからのレスポンス情報を管理するresponseオブジェクトが渡されます。ここから dataを取り出せば、サーバーから送信されたコンテンツが得られます。JSONデータの場合、そのままJavaScriptオブジェクトとして取り出すことができます。

取り出したデータは、peopleに保管しています。これはテンプレートで次のように利用されます。

```
<li v-for="(person, key) in people">
....personを使って表示を作成...... 
</li>
```

**v-for**を利用し、peopleから順に値を取り出して繰り返し処理をします。後は、取り出した値(person)から必要に応じて値を書き出していくだけです。

### Laravel 側はアクションを書くだけ
ざっと流れを見ればわかりますが、実をいえばフロントエンドフレームワークを使ったからといって、Laravelの開発の方法が変わるわけではありません。  
フロントエンドフレームワークが使われるのは、ビューテンプレートの中だけです。 フロントエンドフレームワークのコードから、Laravelの機能に直接アクセスできるわけ ではありません。フロントエンドは基本的にJavaScriptであり、Laravelのサービスを記述できたりはしないのです。できるのは、ただ必要に応じてサーバー側にアクセスす ることだけです。
Laravelとしては、必要に応じてデータを受け取ったり出力したりするアクションを書 いていくだけです。感覚的にはRESTfulなサービスを作成しているのとあまり変わらな いでしょう。

* Laravel側は、データの取得と出力の処理を書くだけ
* フロントエンドはサーバーへのアクセスを書くだけ
* 
この2つが組み合わせられているだけなのだ、ということを頭に入れておけば、両者の連携はそう難しいものではないでしょう。










