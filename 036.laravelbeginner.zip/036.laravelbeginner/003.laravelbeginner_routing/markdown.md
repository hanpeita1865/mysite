*[page-title]:04. ルーティング

特定のアドレスにアクセスしたとき、どの処理を呼び出して実行するか。それを管理するのが「<span class="red bold">ルーティング</span>」です。  
ルーティングは各Webページを管理する基本となるものです。

## 「app」フォルダについて
Laravelアプリケーションに用意されているフォルダの中でも、もっとも重要かつ利用頻度が高いのは「<span class="red bold">app</span>」フォルダです。これからLaravelのプログラムを色々と作っていくことになりますが、そのほとんどは、この「app」フォルダ内に用意されることになります。
「app」フォルダは、Laravelアプリケーションの「アプリケーション」部分のプログラム が配置されます(Laravelフレームワークの部分は「vendor」フォルダに配置されます)。この「app」フォルダを開いてみると、更にその中にいくつものフォルダが用意されていることがわかるでしょう。ここで簡単にまとめておきます。

![](upload/appフォルダ.png "図　appフォルダ内"){.photo-border}

Console
: コンソールプログラムを配置するところです。

Exceptions
: 例外に関する処理を配置するところです。

<span class="red">Http</span>
: これが、Webアプリケーションにアクセスしたときの処理をまとめておくところです。アプリケーションの基本的なプログラムはここに作成します。

Providors
: 「プロバイダと呼ばれるプログラムを配置します。

Models/User.php
: ユーザー認証に関するスクリプトです。当面、使うことはありません。<br>
もっとも重要なのは、「Http」というフォルダです。この中に、アプリケーションの基本的なプログラムとなるものが作成されていきます。それ以外のものは、「必要に応じて利用する」というものですので、今すぐ役割を理解する必要はありません。


## ルーティングと「routes」フォルダ
Laravelのプログラムは「app」フォルダの中に作成をしていきますが、その前に頭に入れておいてほしいのが「<span class="red">ルーティング</span>」という機能についてです。  
一般的なWebサイトというのは、Webサーバーの公開フォルダの中にファイルを用意しておくと、そのままそのファイルにアクセスができます。  
例えば「webapp」というフォルダに「hello.html」とファイルを用意すれば、「<http://〇〇/webapp/hello.html>」 というアドレスにアクセスすると自動的にそのファイルが読み込まれ、表示されるわけです。  
が、Laravelのようなフレームワークを使っている場合、そうはいきません。 Laravelは、 特定のアドレスにアクセスをすると、そのアドレスに割り付けられたプログラムが実行され、それによって必要な処理や画面表示などが作られます。  

このように、「<span class="red">○○というアドレスにアクセスをしたら、××という処理を呼び出す</span>」 という関連付けを行っているのが「ルーティング」という機能です。ルーティングは、アクセスを設定している情報(ルートと呼ばれます)を管理する機能です。  
プログラムの作成の前に、このルーティングの仕組みがわかっていないと、そもそもプログラムを思ったように公開することができません。Laravelのルーティングは、どの ように行われているのか見てみましょう。

![](upload/routing解説図.png "図　ルーティング解説図" )


### 「routes」フォルダについて

このルーティングに関する情報をまとめてあるのが、「<span class="bold red">routes</span>」フォルダです。この中には、デフォルトでいくつかのスクリプトファイルが用意されています。

api.php
: APIのルーティングです。例えばユーザー認証などのように、プログラム内から利用するAPIの機能を特定のアドレスに割り当てるのに利 用されます。

channels.php 
: ブロードキャストチャンネルのためのルーティングです。

console.php
: コンソールプログラムのためのルーティングです。

<span class="red">web.php</span>
: これが、一般的なWebページとしてアクセスするためのルーティン グです。

基本的に、Webページとして公開するものはすべて <span class="red">web.phpにルート情報を記述する</span>、 と考えて下さい。当分の間、それ以外のファイルは利用しません。


## ルート情報の記述
では、web.phpのスクリプトがどのようになっているのか見てみましょう。以下に、 デフォルトで記述されている内容を示しておきます。なお、コメント類は省略してあり ます。

<p class="tmp list"><span>リスト1</span>routes/web.php</p>
```
<?php
Route::get('/', function () {
   return view('welcome');
});
```
非常にシンプルなスクリプトが書かれています。これは、トップページにアクセスしたときの処理について記述したものです。  
Laravelアプリケーションでは、デフォルトで トップページの表示が用意されていました。あの画面を表示させるためのものだ、と考えればよいでしょう。

引数なしのクロージャ(無名関数)になっています。内部では、returnで戻り値を指定しています。このreturnで返される値が、そのアドレスにアクセスした際に表示される 内容となります。
ここでは、「<span class="red">view</span>」という関数を使って戻り値を用意しています。これは以下のように 利用します。
```
view( テンプレート名 )
```
このViewは、<span class="red">指定したテンプレートファイルをロードし、レンダリングして返す働き</span>をします。要するに、このviewで引数にテンプレートを指定すると、それがレンダリン グされて返され、ブラウザに表示される仕組みになっていると考えて下さい。  

リスト1の「`return view('welcome');`」は、「resources/views/<span class="red">welcome.blade.php</span>」のテンプレートを表示させるという意味になります。
![](upload/welcomeテンプレート.png){.photo-border}

「welcome.blade.php」は、「<span class="green bold">Blade</span>」 という、<span class="red">Laravelに組み込まれているテンプレートエンジン</span>を使って書かれたソースコー ドになります。
Laravelでは、PHPをそのまま使ってWebページの表示を作成することもできますが、 内蔵するBladeテンプレートエンジンを使うほうがはるかに多いでしょう。ここでは、「views」フォルダの中にテンプレートファイル が用意され、それをview関数で読み込んで表示しているという基本的な処理の仕組みがわかれば十分です。

![](upload/rout_access.png "図　トップページ表示仕組み")


では、ルート情報の記述の基本を整理しましょう。

<p class="tmp"><span>書式1</span>ルート情報の基本(GETアクセス)</p>
```
Route::get(アドレス , 関数など );
```
GETアクセスのルート情報は、Routeクラスの「get」という静的メソッドを使って設定します。  第1引数に割り当てるアドレスを、第2引数にはそれによって呼び出される処理を用意します。  
これは関数を指定することもありますし、「<span class="red">コントローラ</span>」と呼ばれるものを指定することもあります。  
「<span class="red">getメソッドでアドレスと処理を割り当てる</span>」、というのがルート情報設定の基本である、ということはしっかりと理解しておきましょう。



## LaravelでHello World!の表示


では試しに「routes/web.php」へ次のコードを追加してみてください。

<p class="tmp list"><span>リスト2</span>routes/web.php（Hello World!表示）</p>
```
Route::get("/hello", function () {
    print("<h1>Hello World!</h1>");
    return null;
});
```
<http://localhost:8000/hello/>に接続すると、「Hello World!」の見出しが表示されます。
![](upload/HelloWorld表示.png){.photo-border}

これをテンプレートを使って表示されるように変更してみます。

まずは、resources/viewsフォルダに「hello.blade.php」ファイルを作成してください。
![](upload/helloblade.png){.photo-border}

そのファイルに「Hello World!」の見出しのコードを記入します。
<p class="tmp list"><span>リスト3</span>hello.blade.php</p>
```
<h1>Hello World!</h1>
```

「web.php」のコードを修正します。

<p class="tmp list"><span>リスト</span>routes/web.php（Hello World!表示）</p>
```
Route::get("/hello", function () {
    return view('hello');
});
```

これで再度<http://localhost:8000/hello/>に接続すると、先ほどと同じように表示されます。
![](upload/HelloWorld表示.png){.photo-border}

テンプレート使用については、別の章で改めて説明します。

## ヒアドキュメントを使ってみる

HTML出力の基本がわかったら、ヒアドキュメントを使ってもう少し本格的な内容を出力させてみましょう。ヒアドキュメントというのは、PHPで長文テキストを記述する のに使われるものですね。<<<演算子を使い、リスト内に直接記述されたテキストをまとめて変数などに代入できます。
先ほどのRoute:get文を削除かコメントアウトし、以下のリストを追記して下さい。なお、最初から記述されていたRoute:get文(welcomeの出力用)は消さないように注意しましょう。

<p class="tmp list"><span>リスト</span>routes/web.php（ヒアドキュメントを利用）</p>
```twig
$html = <<<EOF
<html>
<head>
<title>Hello</title>
</head>
<body>
   <h1>Hello</h1>
   <p>This is sample page.</p>
   <p>これは、サンプルで作ったページです。</p>
</body>
</html>
EOF;

Route::get('hello',function () use ($html) {
   return $html;
});
```

※貼り付けた後、&lt;html&gt;の前でENTERキーで折り返してください。

<http://localhost:8000/hello/>に接続してください。
![](upload/this_is_samplpage.png){.photo-border}




### パラメータを利用する

今度は、ルートパラメータを利用してみましょう。先ほど追記した部分を 以下のように修正して下さい。

<p class="tmp list"><span>リスト</span>routes/web.php</p>
```twig
Route::get('hello/{msg}',function ($msg) {

$html = <<<EOF
<html>
<head>
<title>Hello</title>
</head>
<body>
   <h1>Hello</h1>
   <p>{$msg}</p>
   <p>これは、サンプルで作ったページです。</p>
</body>
</html>
EOF;

   return $html;
});
```

例えば、  
<http://localhost/hello/this_is_test>

このようにアクセスをすると、「this_is_test」の部分がパラメータとして取り出され、 Webページにメッセージとして表示されます。

![](upload/this_is_test.png){.photo-border}

### 2つのパラメータ

2つのパラメータを使用する時は、次のように記述します。

例えば、このように記述すれば、$idと$passという2つのパラメータ引数を利用できるようになります。

<p class="tmp list"><span>リスト</span>routes/web.php</p>
```twig
Route::get('hello/{id}/{pass}', function ($id, $pass) {

$html = <<<EOF
<html>
<head>
<title>Hello</title>
</head>
<body>
   <h1>Hello</h1>
   <p>ID番号={$id}</p>
   <p>パスワード={$pass}</p>
   <p>これは、サンプルで作ったページです。</p>
</body>
</html>
EOF;

   return $html;
});
```

※貼り付けた後、&lt;html&gt;の前でENTERキーで折り返してください。

http://localhost:8000/hello/2523/go1425 と接続すると、2つのパラメータが表示されます。

![](upload/go1425.png){.photo-border}


## 必須パラメータと任意パラメータ

このパラメータは、基本的に「必須パラメータ」であり、パラメータを指定せずにアクセスするとエラーになってしまいます。用意されているルートパラメータは必ず付けて アクセスしなければいけません。

では、パラメータを付けなくともアクセスできるようにすることはできないのでしょうか。これは、もちろん可能です。それには「<span class="red bold">任意パラメータ</span>」を使うのです。 任意パラメータは、その名の通り「任意に付けて利用できるパラメータ」です。これは、パラメータ名の末尾に「<span class="red">?</span>」を付けて宣言をします。そして、第2引数の関数では、値が渡される仮引数にデフォルト値を指定し、引数が渡されなくとも処理できるようにしておきます。 先ほどのリスト4で記述したRoute::getの1行目の部分を以下のように書き換えてみて下さい。

<p class="tmp list"><span>リスト</span>routes/web.php</p>
```
Route::get('hello/{msg?}', function ($msg='no message.') {.....}
```
これで、msgパラメータは任意パラメータになります。パラメータを付けずにアクセ スをすると、メッセージとして「no message.」と表示されるようになります。

![](upload/no_message.png){.photo-border}

「$msg=''」とすればパラメータの箇所は空白になります。
```
Route::get('hello/{msg?}',function ($msg='') {
```

![](upload/msg空白.png){.photo-border}
