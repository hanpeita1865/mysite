<?php
    //$mark = file_get_contents('markdown.md');//markdownファイルの内容を取得
    //$array = explode('###', $mark);
    //var_dump($array);
    //$str_grep = preg_replace('/(``` )aaa( ```)/', '$1 ccc $2', $array[2]);
    //echo $str_grep;

    $path_mark = 'markdown.md';

    $path_scss = [
        'scss/style.scss',
        'scss/form.scss',
        'scss/module/_box.scss',
        'scss/module/_button.scss',
        'scss/module/_form.scss',
        'scss/module/_icon.scss',
        'scss/module/_parts.scss',
        'scss/module/_text.scss',
        'scss/layout/_header.scss',
        'scss/layout/_wrapper.scss',
        'scss/layout/_main.scss',
        'scss/layout/_footer.scss',
        'scss/base/_base.scss',
        'scss/base/_breakpoint.scss'
    ];

    //$data_scss[] = file_get_contents('scss/module/_box.scss');

    file_put_contents($path_mark, '');//ファイルの中身を削除

    foreach ($path_scss as $value) {
        $path = explode('/', $value);
        $path_name = end($path);//ファイルネーム
        $path_name = '###'.$path_name."\n";
        
        file_put_contents($path_mark, $path_name, FILE_APPEND);//ファイル名を追記

        echo $path_name;
        $data_scss = file_get_contents($value);
        $code = "\n"."```"."\n".$data_scss."\n"."```"."\n"."\n";
        echo $code;
        file_put_contents($path_mark, $code, FILE_APPEND);//markdown.mdに追記
    }
   
    //var_dump($data_scss);
    //file_put_contents($file, $fruit, FILE_APPEND | LOCK_EX);

?>


