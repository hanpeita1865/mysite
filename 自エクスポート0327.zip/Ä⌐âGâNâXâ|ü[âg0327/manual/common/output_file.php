<?php

$post_html = $_POST['url'];


if(!empty($_POST['url'])){
    echo $post_html;
    $folder = glob('../pages/*', GLOB_ONLYDIR);
    var_dump($folder);

}else if(!empty($_SERVER['HTTP_REFERER'])){
    $motourl = $_SERVER['HTTP_REFERER'];//遷移元のURL
    htmlOutput($motourl);
}

function htmlOutput($motourl){

    $urlArray = explode('/', $motourl);

    $order = count($urlArray)-2;
    $folder = $urlArray[$order];//フォルダ名格納（例: p__base）
    

    $urlSlice = array_slice($urlArray, 0,-1);   
    $slash = implode('/', $urlSlice);   
    $html = file_get_contents($slash);

    $html = str_replace('class="btn-output-edit"', 'class="btn-output-edit d-none"', $html);

    
    //遷移元のフォルダがoutputフォルダにあるか確認。なければ作成する
    if(!file_exists('../output/pages/'.$folder)){
        //echo '存在しません';
        mkdir('../output/pages/'.$folder);
    }

    //空のuploadフォルダを用意する
    if(file_exists('../output/pages/'.$folder.'/upload')){
        //uploadフォルダがあれば、中身を空にする
        if($handle = opendir('../output/pages/'.$folder.'/upload')){
            while (false !== ($entry = readdir($handle))) {
                if ($entry != "." && $entry != "..") {
                    echo $entry;
                    unlink('../output/pages/'.$folder.'/upload/'.$entry);                }
            }
        }

    }else{
        //uploadフォルダ作成
        mkdir('../output/pages/'.$folder.'/upload');
    }
    
    //uploadフォルダのファイルをコピペする
    if($handle = opendir('../pages/'.$folder.'/upload')){

        // オープンしたディレクトリにファイルがあればループ
        while (false !== ($entry = readdir($handle))) {
            //ファイル名が「.」「..」じゃなければ処理をする
            if ($entry != "." && $entry != "..") {
                copy('../pages/'.$folder.'/upload/'.$entry, '../output/pages/'.$folder.'/upload/'.$entry);
            }
        }
        // オープンしたディレクトリのハンドルをクローズ
        closedir($handle);   
    }
    
    file_put_contents( '../output/pages/'.$folder.'/index.html', $html );
}

?>
