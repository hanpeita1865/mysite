<?php
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Formatter\LineFormatter;



$container->set(
    "logger",
    function ($c) {
       
        $config = $c->get('config');
        $basePath = $config['basePath'];  // ← ここで取得できる

        //日本時間にセット
        date_default_timezone_set('Asia/Tokyo');

        $logger = new Logger('logger');
        $custom_handler = new StreamHandler($_SERVER["DOCUMENT_ROOT"] . $basePath . "/logs/app.log", Logger::INFO);

        // 時間表示のフォーマット設定
        $date_format = 'Y-n-d H:i:s';

        // ログのフォーマットを設定
        $format = '[%datetime%] %level_name%: %message%' . PHP_EOL;

        // 第三引数は「ログ内のインライン改行を有効にするかどうか」の設定
        // 今回は意味は無いが、有効にしておいた方が使いやすいのでtrueに
        $formatter = new LineFormatter($format, $date_format, true);

        $custom_handler->setFormatter($formatter);

        $logger->pushHandler($custom_handler);
        return $logger;
    }
);