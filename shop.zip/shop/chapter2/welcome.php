<?php
echo 'Welcome to PHP';
?>
