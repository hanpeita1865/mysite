<?php
    require 'basepath.php';

    $post_menu = $_POST['post_menu'];//変更前のメニュー名
    $post_reMenu = $_POST['post_reName'];//変更後のメニュー名
    $post_dir = $_POST['post_dir'];//パス 例) {{basePath}}pages/winKey111/
    $post_dirName = $_POST['post_dirName'];//パス（番号付き）例) 02.winKey111
    // $basePath = '/from_now_slim/public/';
    $basePath = $basePath.'/public/';

    //「menu_list.twig」のメニュー名の変更処理
    $menu = file_get_contents('../templates/layouts/menu_list.twig');

    $post_dir_re = str_replace($basePath,'', $post_dir);

    $post_dir_esc = preg_quote( $post_dir , '/');//エスケープ処理

    $post_menu = preg_quote( $post_menu );//エスケープ処理

   
    $menuRe = preg_replace('/(.*)'.$post_dir_esc.'(.*)'.$post_menu.'(.*)/i',  '$1'.$post_dir.'$2'.$post_reMenu.'$3', $menu);


    file_put_contents('../templates/layouts/menu_list.twig', $menuRe);

    // //「markdown.md」のtitle値の変更処理
    $md = file_get_contents('../pages/'.$post_dirName.'/markdown.md'); //マークダウンの内容を変数に格納

    preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);//マークダウン内のタイトル名を配列に格納

    if(!empty($ArrayTitle[1])){
        $md = preg_replace("/^\*\[page-title\]:\s*(.+)/", '*[page-title]:'.$post_reMenu, $md);//タイトル名を変換
        file_put_contents('../pages/'.$post_dirName.'/markdown.md', $md);//マークダウンを保存
    }else{
        //マークダウン内にtitleがない場合、新規に追加
        file_put_contents('../pages/'.$post_dirName.'/markdown.md', '*[page-title]:'.$post_reMenu."\n\n".$md);
    }

    echo 'メニュー名を「'.$post_reMenu.'」に変更しました。';
?>
