export function modalwin() {

    // マークダウン用モーダルウィンドウ
    $("a.modal-win").click(function () {

        // body要素の最後にdiv.modal-wrapを追加
        $("body").append('<div class="modal-wrap">');

        // .modal-wrap要素の中にdiv#photoを追加
        $(".modal-wrap").html('<div id="photo">');

        // .modal-wrap要素の中の最後にオーバーレイヤーを設置
        $(".modal-wrap").append('<div class="modal-overlay">');

        // それぞれ非表示にする
        //$("#photo").hide();
        //$(".modal-overlay").hide();

        // #photoの中にimg要素を追加
        $("#photo").html("<img>");

        // img要素にsrc属性を設定
        $("#photo img").attr("src", $(this).attr("href"));


        // .modal-overlayと#photoをフェードイン   
        $(".modal-overlay").fadeIn();
        $("#photo").fadeIn();

        // 背景をクリック   
        $(".modal-overlay").click(function () {
            // 背景（自分自身）をフェードアウト、完了したら削除
            $(this).fadeOut(function () {
                $(this).remove();
            });

            // 画像をフェードアウト、完了したら削除
            $("#photo").fadeOut(function () {
                $(this).remove();
                $(".modal-wrap").remove();
            });
        });

        return false;
    });

    // オーバーレイをクリックしたとき
    $('.overlay').on('click', function () {
        // オーバーレイがopenクラスを持っているならば
        if ($(this).hasClass('open')) {
            $(this).removeClass('open');
            $('.menu-trigger').removeClass('active');
            $('nav').removeClass('open');
        }
    });

}