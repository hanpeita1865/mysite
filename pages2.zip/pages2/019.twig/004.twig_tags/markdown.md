*[page-title]:Tags

## for

<p class="tmp"><span>書式</span>for文</p>
```
{% for キー in 配列 %}
		{{ キー}}
{% endfor %}
```
```
{% for キー,値 in 配列 %}
		{{ キー }} または {{ 値 }}
{% endfor %}
```

<p class="tmp list"><span>リスト</span></p>
```
{% for i in 0..10 %}
	* {{ i }}
{% endfor %}
```

<p class="result"><span>結果</span></p>
```
* 0 * 1 * 2 * 3 * 4 * 5 * 6 * 7 * 8 * 9 * 10
```

<p class="tmp list"><span>リスト</span>キーと値を表示します。</p>
```
{% for key, value in ['taro', 'ichiro', 'hanako'] %}
	{{ key }}:{{ value }}
{% endfor %}
```
<p class="result"><span>結果</span></p>
```
0:taro 1:ichiro 2:hanako
```


<div class="exp">
	<p class="tmp"><span>例</span></p>
	$assign["items"]に連想配列の値を格納して、twigに送信し、HTMLに生成して受け取った内容を表示しています。<br>
	<a href="sample/twig/index1_for.php" target="_blank">新規タブ</a>
	<iframe width="100%" height="120" src="sample/twig/index1_for.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="tmp list"><span>リスト</span>index1_for.php</p>
```
<?php
require_once("vendor/autoload.php");
$loader = new \Twig\Loader\FilesystemLoader("templates");
$twig = new \Twig\Environment($loader);

//値を配列に格納
$assign["items"] = [
    'tokyo' => '東京',
    'shibuya' => '渋谷',
    'harajuku' => '原宿',
    'yoyogi' => '代々木',
];

echo $twig->render("keyValue.twig", $assign);
```

<p class="tmp list"><span>リスト</span>keyValue.twig</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>連想配列を引き渡して表示 | for</title>
</head>
<body>
	<h1>連想配列を引き渡して表示</h1>

    {% for key, value in items %}
        {{ key }}:{{ value }}
    {% endfor %}
</body>
```

## set

コードブロック内では、変数に値を割り当てることもできます。割り当ては set タグを使用し、複数のターゲットを持つことができます。
<p class="tmp"><span>書式</span>set</p>
```
{% set 変数 = '値' %}
```

<p class="tmp list"><span>リスト</span></p>
```
{% set foo = 'bar' %}
{＃バーを表示します＃}
{{ foo }}
```
<p class="result"><span>結果</span></p>
```
bar
```

### Keyを命名して配列を定義

<p class="tmp list"><span>リスト</span></p>
```
{% set bar = {'a': 'test','b': 'text'} %}
{{ bar.b }}
```
<p class="result"><span>結果</span></p>
```
text
```
<div class="exp">
	<p class="tmp"><span>例</span>setまとめ</p>
		<a href="sample/twig/index2_set.php" target="_blank">新規タブ</a>
</div>