*[page-title]:Nuxt3メモ

## Next.jsのポート番号を変更する方法

<span class="green bold">npm run dev</span>を実行すると、port3000で通常表示されますが、そのport番号を変更したいときは、<span class="green bold">package.json</span>の次の箇所を変更すれば、指定したポート番号で開くことが出来ます。

<p class="tmp list"><span>リスト</span>package.json</p>
```
  "scripts": {
    "build": "nuxt build",
    "dev": "nuxt dev",  ➡ "nuxt --port 3333 dev",　に変更すると「http://localhost:3333/」で表示できます。
    "generate": "nuxt generate",
    "preview": "nuxt preview",
    "postinstall": "nuxt prepare"
  },
```
