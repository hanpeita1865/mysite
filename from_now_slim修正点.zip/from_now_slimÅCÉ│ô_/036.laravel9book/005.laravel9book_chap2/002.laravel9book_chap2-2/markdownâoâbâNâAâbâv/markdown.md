*[page-title]:Chap2-2 つぶやきを投稿する処理を作成する

4-1では表示したのはダミーで挿入したつぶやきなので、画面から実際につぶやきを投稿できる機能を作成しましょう。

## コントローラの作成

まずは、投稿を受け付けるコントローラを作成します。
<p class="tmp cmd"><span>コマンド</span>新規でコントローラ作成</p>
```
sail artisan make:controller Tweet/CreateController --invokable
```
![](upload/新規でコントローラ作成1.png)

CreateController.phpが作成されました。
![](upload/新規でコントローラ作成2.png)

引き続き、画面からリクエストされたデータをバリエーションするために、FormRequestというクラスを作成します。

<p class="tmp cmd"><span>コマンド</span>FormRequestクラスを作成</p>
```
sail artisan make:request Tweet/CreateRequest
```
![](upload/FormRequestクラスを作成1.png)

Requests/Tweetディレクトリが作成され、そこにCreateRequest.phpというファイルが作成されます。
![](upload/FormRequestクラスを作成2.png)

<p class="tmp list"><span>リスト</span>app/Http\Requests/Tweet/CreateRequest.php（デフォルト）</p>
```
<?php

namespace App\Http\Requests\Tweet;

use Illuminate\Foundation\Http\FormRequest;

class CreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            //
        ];
    }
}
```

<span class="red">authorize</span>と<span class="red">rules</span>の2つのメソッドを持っていて、<span class="red">authorize メソッド</span>では ユーザー情報を判別して、このリクエストを認証できるか判定させることができます。 初期値がfalseになっているので、まずは誰でもリクエストできるようにtrueに変更しましょう。

<span class="red">rulesメソッド</span>ではリクエストされる値を検証するための設定を記述します。
たとえば今回のアプリケーションであれば、投稿したつぶやきに140文字制限をかけたり、その文章は必須であるなどの条件があったとします。その場合は、次のように記述します。

<p class="tmp list"><span>リスト</span>app/Http/Requests/Tweet/CreateRequest.php</p>
```
public function authorize(): bool
{
    return true;
}

public function rules(): array
{
    return [
        'tweet' => 'required|max:140'
    ];
}
```

Laravelではバリエーションルールが多数用意されています。

公式ドキュメント  
<https://laravel.com/docs/9.x/validaton#available-validation-rules>　→not found になる

それでは独自に拡張したForRequestクラスをコントロールで利用してみましょう。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/CreateController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tweet\CreateRequest;//追加

class CreateController extends Controller
{
		//変更
    public function __invoke(CreateRequest $request)
    {
        //
    }
}
```

呼び出し方は非常に簡単で、__invokeメソッドの引数に指定するだけです。   
Laravelではサービスコンテナ によって自動的に指定したクラスをメソッドインジェクションしてくれます。  
ここまで作成したら、Routeにこのコントローラを登録して、画面からリクエストできるようにしてみましょう。次のコードを追加します。

<p class="tmp list"><span>リスト</span>routes/web.php</p>
```
Route::post('/tweet/create', \App\Http\Controllers\Tweet\CreateController::class);//追加
```

今度は/tweet/create に POSTメソッドでリクエストされた場合に Tweet/ Createコントローラが呼ばれるように設定します。  
また、Routeには名前をつけることができるので追加しましょう。名前をつけることで、別のコントローラやBladeテンプレートからRoute を呼び出す際に パスではなくその名前で指定できるので、 記述を簡略化できます。

<p class="tmp list"><span>リスト</span>routes/web.php</p>
```
Route::get('/tweet', \App\Http\Controllers\Tweet\IndexController::class) ->name('tweet.index');
Route::post('/tweet/create', \App\Http\Controllers\Tweet\CreateController::class) ->name('tweet.create');
```


## 投稿フォームの作成

続いては、resources\views\tweet\index.blade.phpにつぶやきが投稿できるフォームを追加しましょう。

<p class="tmp list"><span>リスト</span>resources\views\tweet\index.blade.php</p>

```
<h1>つぶやきアプリ</h1>
<div>
<p>投稿フォーム</p>
<form action="{{ route('tweet.create') }}" method="post">
@csrf
<label for="tweet-content">つぶやき</label>
<span>140文字まで</span>
<textarea id="tweet-content" type="text" name="tweet" placeholder="つぶやきを入力"></textarea>
<button type="submit">投稿</button>
</form>
</div>
```

･･･省略･･･


### CSRFトークンチェック

Laravelでは初期設定としてすべてのリクエストに対しCSRFトークンチェックを行います。  
CSRF (クロスサイトリクエストフォージェリ) はWebサイトにおける脆弱性 の一つであり、Laravelではこの脆弱性の対処としてトークンチェックを行うこ とでその攻撃から防ぐ仕組みを持っています。  
Laravelではセッションを利用してアプリケーション固有のトークンを生成し、そのトークンが有効かどうかを判定して自身のアプリケーションから送信 されたものであることを認識します。  
この判定はapp/Http/Middleware/VerifyCsrfTokenで行われます。  
CSRF対策で重要なことは、クライアントからトークンを送ってもらうことが 必要であるということです。  
LaravelではBladeテンプレートのディレクティブに@csrfを用意していますので、これを設定するだけで対策が完了できます。
この@csrfはHTMLとして生成する際に以下のように変換されます。
![](upload/CSRFトークンチェック.png)

inputの隠し要素として、_token という名前のデータでアプリケーションにトークンを送信できるようにしています。  
なお、CSRFトークンは常に同じ値ではなく、 定期的に更新されることでセ キュリティを担保しています。 ですので、 ブラウザで投稿画面を開きっぱなしにしていると画面のトークンが古くなり、 Laravel側のトークンが更新されることでトークンが一致しなくなります。  
その状態で投稿された場合はTokenMismatchException という例外が 発生します。 この挙動自体はセキュリティを担保するために必要ですが、アプ リケーションによってトークンの更新時間を伸ばしたり、 短くしたりしたい場合 はconfig/session.php の lifetime を変更することで対応できます。  
ただし、このlifetime は session 全般に影響する値ですので、 ログイン機能 などを有する場合はそちらとの兼ね合いも考えなければなりません。 よく理解 して利用しましょう。

### バリデーションのメッセージを表示

フォームは作成しましたが、このままではバリデーションによって失敗したリクエストをユーザーに伝えることができません。 続いてバリデーションメッセー ジの表示を追加します。

<p class="tmp list"><span>リスト</span>resources\views\tweet\index.blade.php</p>
```
<textarea id="tweet-content" type="text" name="tweet" placeholder="つぶやきを入力"></textarea>
@error('tweet')<!--追加;-->
<p style="color: red;">{{ $message }}</p>
@enderror
```

@errorディレクティブに対象の名前を入れて、{{ $message }}とすることでバリデーションのエラーメッセージが表示されます。  
複数の項目をまとめたい場合はこの@errorに複数の名前を入れることで対応できます。

![](upload/errorディレクティブ.png)

<http://localhost/tweet>にアクセスすると、フォームが表示されます

![](upload/バリデーションのメッセージを表示.png)


### バリデーションメッセージの日本語化

<p class="lang">config/app.php</p>
![](upload/バリデーションメッセージの日本語化1.png)


そしてlangディレクトリにあるenディレクトリをコピーしてjaとリネームし、ディレクトリにあるファイルの内容を日本語化することで対応できます。

※langディレクトリは、なかったので参考書サンプルからコピーしました。

バリデーションメッセージのファイルを自身で翻訳するのは手間がかかるので、OSSの翻訳済みのバリデーションメッセージのファイル「Laravel-Lang」 を利用することもできます。 まず、 sailコマンドを利用してインストールします。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail composer require laravel-lang/lang:~10.3
```

![](upload/バリデーションメッセージの日本語化2.png)

Composerインストールが完了したら、cpコマンドでファイルを移動します。

<p class="tmp cmd"><span>コマンド</span></p>
```
cp -R vendor/laravel-lang/lang/locales/ja lang/ja
```

これでバリデーションメッセージが日本語化されました。  
しかし、tweetはデータのkey名のままとなっているので、こちらも適切に変更してあげましょう。

lang/ja/validation.phpの末尾にaattributesを定義し、tweetの翻訳を追加しましょう。

![](upload/tweetの翻訳を追加.png)


### 画面からのデータを取得し保存

投稿フォームが完成したので、 フォームから投稿されたデータをデータベースに反映する処理を作りましょう。  
まず投稿されたデータを取得するために、RequestFormクラスにtweetを取得できるメソッドを追加します。

<p class="tmp list"><span>リスト</span>app/Http/Requests/Tweet/CreateRequest.php</p>
```
    public function tweet(): string
    {
        return $this->input('tweet');
    }
```

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/CreateController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tweet\CreateRequest;
use App\Models\Tweet;//追加

class CreateController extends Controller
{
    public function __invoke(CreateRequest $request)
    {
        $tweet = new Tweet;//追加
        $tweet->content = $request->tweet();//追加
        $tweet->save();//追加
        return redirect()->route('tweet.index');//追加
    }
}
```

データを入力して、投稿するとデータベースに保存されて。画面に表示されます。

![](upload/投稿するとデータベースに保存1.png)

↓画面の下に投稿文字が表示されます。

![](upload/投稿するとデータベースに保存2.png)

![](upload/投稿処理の流れ.png)


### 投稿されたつぶやきの表示を降順にする

$tweets = Tweet::all();　を次のように変更します。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/IndexController.php</p>
```
$tweets = Tweet::orderBy('created_at', 'DESC')->get();
```

投稿された新しいつぶやき順に表示されるようになりました。

![](upload/投稿されたつぶやきの表示を降順にする.png)

上記はクエリビルダの機能を利用しているため、SQL実行時にソートしています。PHP側でソートする方法もあります。
次のように書きます。
<p class="tmp list"><span>リスト</span>PHP側でソート</p>
```
$tweets = Tweet::all()->sortByDesc('created_at');
```

基本的にはPHP側で処理するより<span class="marker-yellow50">SQL側でソート</span>する方が高速になるのでよいです。






