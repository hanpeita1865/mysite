---
title: '01. 概略'
taxonomy:
    category:
        - docs
visible: true
---

<style>
	p{line-height:1.8;}
	p,.ul-list,.ol-list{letter-spacing:.06rem;}
	.ul-list li,.ol-list li{font-size:.937rem;font-weight:bold;margin-bottom:.937rem;}
</style>

<h2 class="h-type2">jQueryとは</h2>
jQueryとは、JavaScriptのライブラリ（便利な機能を使いやすくしたもの）の一種です。  

近年フラットデザインやマテリアルデザインなどのよりシンプルなデザインが、Webデザイン界では主流となっていますが、そういったデザインの中でも効果的に動きを出すことでユーザーに情報を与えやすくしています。  

そのページに動きを出す機能をjQueryは担っています。


<h2 class="h-type2">jQueryで出来ること</h2>
jQueryではCSSやHTMLでは実現できないような、ページに動きをつけたリッチなUIを実装することができます。  

<ul class="ul-list">
	<li>アニメーションをつける。</li>
	<li>時間によってページの色を変更する。</li>
	<li>ユーザーの動作によってCSSを変更してレイアウトを変える。</li>
</ul>

などができます。

CSSでも簡単なアニメーションを作成することができます。しかし、CSSは元々レイアウト用に作られた言語であるのに対して、jQueryはページにより動きを出すために作られたライブラリで、そのための便利な機能がたくさん存在します。

<h2 class="h-type2">jQueryの読み込み方法</h2>

jQueryを利用するには、あらかじめjQueryをHTML上に記述し、読み込んでおく必要があります。  
記述する場所はHTMLのhead内か、body閉じタグの直前に記述します。  
```
<html>
	<head>
		<!-- headの中に以下のように記述 -->
		<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	</head>
	<body>
	...
	...
	...
	<!-- body閉じタグ直前に以下のように記述 -->
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	</body>
</html>
```
読み込み方の主な方法は2パターンあります。

<ol class="ol-list">
	<li>Web上のソースを読み込む方法</li>
	<li>ダウンロードしてローカルで読み込む方法</li>
</ol>

***

<h3 class="h-type3">Web上のソースを読み込む方法</h3>
他のサーバーにあるjQueryファイルを使う方法です。具体的にはGoogleやMicrosoft、jQuery本家などのサーバーが配信しているjQueryを使います。  

Googleが配信しているものを使う場合、以下のように記述します。

```
<script type="text/javascript"src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
```

***

<h3 class="h-type3">ダウンロードしてローカルで読み込む方法</h3>

jQueryライブラリの公式ページからダウンロードをしましょう。  
[http://jquery.com/download/](http://jquery.com/download/)

<img src="img/jquery-foundation-01-01.png" alt="">

jQueryファイルはバージョンが1〜3までありますが、どういう違いがあるかというと「対応ブラウザの違い」です。  
例えば1.x系という古いバージョンだとIE6〜8にも対応しています。古いブラウザにも対応したい、という場合は1.x系など前のバージョンを使ったほうが良いです。

現在は3.x系が主流となっていますので、特に古いブラウザなどに対応したいという希望が無ければ、そのままダウンロードしてください。（2019年3月13日現在のバージョンは3.3.1）  

格納先としては、ルート階層に「js」フォルダを作り、そこに格納する形が一般的かと思います。  
格納したjQueryをhtmlで読み込めば完了です。
```
<script type="text/javascript" src="格納場所/jquery.min.js"></script>
```
