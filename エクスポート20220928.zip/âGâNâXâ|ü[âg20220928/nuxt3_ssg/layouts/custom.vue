<template>
  <div>
    <slot />
    <Navbar />
  </div>
</template>