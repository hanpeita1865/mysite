Vue.creareApp({
    prop: [ 'name' ],
},
{
    name: '山田'
})
.mount('#app');
  