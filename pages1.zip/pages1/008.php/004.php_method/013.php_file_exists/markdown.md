*[page-title]:フォルダとファイルの存在判定（file_exists）

参考サイト
: [PHP マニュアル file_exists](https://www.php.net/manual/ja/function.file-exists.php)

ファイルまたはディレクトリが存在するかどうか調べます。

<p class="tmp"><span>書式</span></p>
```
file_exists($filename)
```

$filename: ファイル名、フォルダ名

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<a href="http://localhost:7001/test/php/file_exists/" target="_blank">http://localhost:7001/test/php/file_exists/</a>
</div>

```
<?php
$filename = 'folder/foo.txt';

if (file_exists($filename)) {
    echo "$filename が存在します"."\n";
} else {
    echo "$filename は存在しません"."\n";
}


$folder = 'folder';

if (file_exists($folder)) {
    echo "$folder が存在します"."\n";
} else {
    echo "$folder は存在しません"."\n";
}
```