---
title: Highlight
media_order: 'plugin1.png,plugin.png,highlight_tabIndent.png'
taxonomy:
    category:
        - docs
---

<i class="fa fa-check-square text-primary"></i>（テンプレート設定済み）

記事にプログラムソースを埋め込んだときに、コードをハイライトするためのプラグインです。  
176言語と79種類のシンタックススタイルにに対応しています。 

## 使い方

ハイライトにするには、二つの方法があります。

一つ目の方法は、コードにタブのインデントを入れ、コードの最初の行の上と最後の行の下に空白行を入れます。
![](highlight_tabIndent.png?classes=inlineBlock "タブインデントを使ったハイライト変換")

二つ目の方法は、コードの最初の行の上と最後の行の下にバッククォートを付けます。

<pre>
``` 
&lt;figure role="group" class=""&gt;
    &lt;figcaption>キャプション&lt;/figcaption&gt;
&lt;/figure&gt;
```
<strong>バッククォートを使ったハイライト変換</strong>
</pre>


  


### マニュアルで言語指定

だいたい自動で分析し言語を指定してくれますが、バッククォートで変換する場合は、マニュアルで言語を指定できます。  
バッククォートに続けて言語種別を指定することで、その言語のコードハイライトが適用されます。

例)  
HTML, XML → xml、html　　CSS → css　　JavaScript → javascript、js　　Python → python、py、gyp  
Markdown → markdown、md、mkdown、mkd　　Perl → perl、pl　　SQL → sql　など

#### 言語をHTMLに指定
<p class="write"><span>記入例</span>（バッククォート使用の場合）</p>
<pre>
``` html
&lt;figure role="group" class=""&gt;
    &lt;figcaption>キャプション&lt;/figcaption&gt;
&lt;/figure&gt;
```
</pre>

<p class="result"><span>表示結果</span></p>
``` html
<figure role="group" class="">
    <figcaption>キャプション</figcaption>
</figure>
```

#### 言語をMarkdownに指定
<p class="write"><span>記入例</span>（バッククォート使用の場合）</p>
<pre>
``` markdown
## リスト

* パイナップル
* メロン
* オレンジ

## リンク
[HTML5トップページ](../../html5-foundation) 
```
</pre>

<p class="result"><span>表示結果</span></p>
``` markdown
## リスト

* パイナップル
* メロン
* オレンジ

## リンク
[HTML5トップページ](../../html5-foundation) 
```



Highlight.jsの参考サイト
:[https://syncer.jp/how-to-use-highlightjs](https://syncer.jp/how-to-use-highlightjs?target=_blank)

## Highlightのスタイルを変更

このGRAV取説では、ハイライトのスタイルは「Grav Learn」に設定しています。  
Highlightのスタイルを変更する場合は、

1.　プラグインの管理画面を開き、Hightlightのリンクをクリックします。

**プラグイン管理画面**

![](plugin1.png?classes=mt-0)

2.　Hightlightのページが開いたら、CSS Themeのリストから選択して、右上の保存ボタンをクリックして変更は完了です。

**Hightlightページ**

![](plugin.png?classes=mt-0)

このデモページがスタイル確認の参考になると思います。

[Hightlight Demo](https://highlightjs.org/static/demo/?target=_blank)









