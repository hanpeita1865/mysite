const nav_link = document.querySelectorAll('.nav-link');
const tab_pane = document.querySelectorAll('.tab-pane');

document.querySelectorAll('.nav-link').forEach(elm => {
	elm.addEventListener('click', e => {

		tab_pane.forEach(t => {
			t.classList.remove('active')
		})

		nav_link.forEach(h => {
			h.classList.remove('active')
		});

		let panelId = e.target.getAttribute('data-id');
		e.target.classList.add('active');
		document.getElementById(panelId).classList.add('active');
	});
});


const tab_nav = document.getElementById('tab-nav');

tab_nav.addEventListener('focus', (event) => {
  event.target.classList.add('active');
}, true);

tab_nav.addEventListener('blur', (event) => {
  event.target.classList.remove('active');
}, true)