*[page-title]:9-9. シェイプを結合、整列、前面、背面にしてみよう

<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-09.jpg)](upload/9-09.jpg){.image}
</div>