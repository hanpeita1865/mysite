---
title: フォルダやページの追加/削除
media_order: 'add_folder1.png,add_folder.png,add_folder3.png,add_folder2.png,add_page1.png,add_page.png,batsu_button.png,folder-delete.png,delete_tab.png,tacsonomy.png,page_manege.png,page_sorting.png'
taxonomy:
    category:
        - docs
---

## フォルダの追加

ファイルを格納するフォルダを作成したい時などに使います。

1. 管理画面の右上の追加ボタンをクリックし、「フォルダの追加」を選択します。

![](add_folder1.png)

2. フォルダ追加の画面が表示されるので、**{c:red}フォルダ名{/c}**を入力し、**{c:green}親ページ{/c}**をリストから選択し、保存ボタンを押します。

![](add_folder.png?cropResize=500,500)


3. このままだとサイドメニューに表示されるので、ページの管理画面から追加したフォルダをクリックして設定画面を開き、通常-高度のタブの画面に切り替えます。

![](add_folder3.png)

4. ページの真ん中ぐらいにある表示可能を無効にして保存ボタンを押します。

![](add_folder2.png)

## フォルダの削除

ページの管理画面を開き、削除したいフォルダ名の右端の![](batsu_button.png?classes=d-inline,my-1)ボタンをクリックします。

![](folder-delete.png)

## ページの追加

1. 管理画面の右上の追加ボタンをクリックし、「ページの追加」を選択します。

![](add_page1.png)

2. ページ追加の画面が表示されるので、**{c:blue}ページタイトル{/c}**、**{c:red}フォルダ名{/c}**を入力し、**{c:green}親ページ{/c}**と**{c:darkred}ページテンプレート{/c}**をリストから選択します。  
ページを表示させるには、表示可能を「**{c:red}はい{/c}**」にします。
続けるボタンを押すと、ページ編集画面が表示されるので、右上の保存ボタンを押してページの追加は完了です。

![](add_page.png)

よく使う**{c:darkred}ページテンプレート{/c}**の主な違いは表のようになります。

<table>
    <thead>
        <tr>
            <th class="w-25">テンプレート名</th>
            <th>default</th>
            <th>docs</th>
            <th>chapter</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th>prev、nextボタン</th>
            <td>付かない</td>
            <td>付く</td>
            <td>付く</td>
        </tr>
        <tr>
            <th>ページタイトル見出し</th>
            <td>付く</td>
            <td>付く</td>
            <td>付かない</td>
        </tr>
        <tr>
            <th>文字配置</th>
            <td>左寄せ</td>
            <td>左寄せ</td>
            <td>中央寄せ</td>
        </tr>
    </tbody>
</table>

※ prev、nextボタンでページ移動をする場合、それぞれのページの編集画面の通常-オプションでタクソノミーのCategoryが**docs**を選択しておく必要があります。 
ここを選択していないページはとばされます。
![](tacsonomy.png)

### ページ管理画面
ページ管理画面は、このようになっています。

![](page_manege.png)

## ページの削除

ページの管理画面を開き、削除したいページ名の右端の![](batsu_button.png?classes=d-inline,my-1)ボタンをクリックします。

または、ページの編集画面を開き、右上の削除ボタンをクリックします。
![](delete_tab.png)

## ページの並べ替え

ページの並べ替えは、ページ編集画面の右側にある「並べ替え可能のページ」内の移動したいページを替えたい位置までドラッグ&ドロップして、保存ボタンをクリックすればできます。  
ただし、フォルダの数値プレフィックスが有効になってないと、ページの並べ替えはできません。

![](page_sorting.png)








