*[page-title]:設定方法

参考サイト
: [Nuxt3 で SSG (静的サイトジェネレート) する方法](https://std9.jp/articles/01g37q8qg405a7c7d68mwyeg31)
: [Nuxt3をインストールしてみた](https://zenn.dev/one_dock/articles/7447952bffecf9) ←こっちを参考にした

## Nuxt3インストール方法

コマンドプロンプトを開き、作成したいフォルダにカレントを移動して、下記を実行します。
<p class="tmp cmd"><span>コマンド</span>Nuxt3インストール</p>
```
npx nuxi init nuxt3-app
```
※上記のnuxt3-appの部分は、任意のプロジェクト名になります。nuxt3-sampleとかでもいいです。

<div markdown="1" class="memo-box">
node16.4.2で、「<span class="red bold">npx nuxi init nuxt3-app</span>」などの<span class="green bold">npxコマンド</span>を使うと、下記のエラーがでる場合があります。
```
WARN  Current version of Node.js (16.4.2) is unsupported and might cause issues.   
       Please upgrade to a compatible version (^14.16.0 || ^16.11.0 || ^17.0.0 || ^18.0.0).
```
その時は、Nodeのバージョンを上記のどれかに切り替える必要があります。
</div>

今回は、node 17.0.0 で実行してみます。  
新規にnodeのバージョンをインストールした場合は、npmをバージョンに合わせたのをインストールする必要があるので、次のコマンドを実行してください。
<p class="tmp cmd"><span>コマンド</span>npmをnodeに合わせてインストール</p>
```
nodist npm match
```
下記のセキュリティ警告画面が出たら、このままでもいいと思いますが、一応ローカルの方だけにチェックを入れて、「アクセスを許可する」をクリックします。
![](upload/セキュリティ警告.png "図 セキュリティ警告画面")

<span class="red bold">npm -v</span>でnpmのバージョン確認すると、
```
8.1.0
```
と表示されます。これでnodeとnpmのバージョンが一致したので、次のコマンドを実行して、パッケージをインストールします。
<p class="tmp cmd"><span>コマンド</span>パッケージをインストール</p>
```
npm install
```
![](upload/npm_install.png "図 npm install実行結果画面")

インストール完了。  
フォルダ構成は、次のようになっています。

![](upload/デフォルトフォルダ構成.png "図 デフォルトのフォルダ構成")

次は、開発環境用のサーバーを起動します。
<p class="tmp cmd"><span>コマンド</span>開発環境用のサーバー起動</p>
```
npm run dev
```
下記の画面が表示されれば、OKです
![](upload/サーバー起動.png)

<http://localhost:3000/> にアクセスしてください。

![](upload/Nuxt3サイト初期画面.png "図 Nuxt3サイト初期画面")

上記の画面が表示されれば、Nuxt3のインストールは成功です。

![](upload/フォルダ構成サーバー起動後.png "図 サーバー起動後のフォルダ構成")

## SSG (静的サイトジェネレート)



### ページを追加して、SSGを実行

ここではページを追加して実際に各ページが静的に生成されるか確認してみます。  
app.vue にページ切り替え用のリンクを追加します。

<p class="tmp list"><span>リスト</span>app.vue</p>
```
<template>
  <!-- メニュー -->
  <ul>
    <li>
      <NuxtLink to="/">Index</NuxtLink>
    </li>
    <li>
      <NuxtLink to="/about">About</NuxtLink>
    </li>
  </ul>

  <!-- ページ内容の表示 -->
  <NuxtPage />
</template>
```

pages/index.vue と pages/about.vue を追加します。

<p class="tmp list"><span>リスト</span>pages/index.vue</p>
```
<template>
  <p>Index Page...</p>
</template>
```

<p class="tmp list"><span>リスト</span>pages/about.vue</p>
```
<template>
  <p>About Page...</p>
</template>
```
<p class="tmp cmd"><span>コマンド</span>ジェネレート</p>
```
npm run generate
```

<span class="red bold">npm run generate </span>コマンドを実行すると、<span class="bold">index.html</span>と <span class="bold">about/index.html </span>が生成されていることが確認できると思います。  
実際に静的サーバーにアップロードして動作もできます。

![](upload/ファイルを追加してジェネレート.png "図 ファイルを追加してジェネレート")

![](upload/generate_folder.png "図　ジェネレート後のフォルダ構成")

再度、<span class="red bold">npm run dev</span>コマンドを実行して、、<http://localhost:3000/about/>にアクセスしてください。  
下記のサイトが表示されます。

![](upload/indexとabout.png)

完成品は、このページのsampleファイルに格納しています。  
C:\xampp\htdocs\from_now\trunk\pages\p__nuxt3_setting\sample\nuxt3-ssg