export default {
  clear: jest.fn(),
  show: jest.fn(),
  appendLine: jest.fn(),
};
