---
title: 検索をマスターしよう
media_order: 'search1.png,search2.png,search3.png,search4.png,search5.png,search6.png,search7.png,search8.png'
taxonomy:
    category:
        - docs
---

## 検索をマスターしよう

### 検索とフィルター

Djangoでは、モデルにはobjectという属性があり、この中にManagerというクラスのインスタンスが入っていました。  
検索関係も、このManagerに用意されている機能を使います。  
それは「**フィルター**」という機能です。  
フィルターは、たくさんあるデータの中から必要なものを絞り込むためのものです。  
このフィルターは、以下のようなメソッドとして用意されています。

	変数 = 《Model》.object.filter(フィルターの内容)

メソッドの使い方はとても単純です。問題は、フィルターの内容をどう設定すればいいかでしょう。


### urlpatternsの修正

今回は、findというページを新たに用意します。  
「hello」フォルダ内のurls.pyを開き、変数urlpatternsの値を以下のように修正します。


<p class="mb-05"><span class="tmp list">リスト3-39</span><span class="bold">urls.pyの変数urlpatternsの値を修正</span></p>

    urlpatterns = [
        path('', views.index, name='index'),
        path('create', views.create, name='create'),
        path('edit/<int:num>', views.edit, name='edit'),
        path('delete/<int:num>', views.delete, name='delete'),
        path('find', views.find, name='find'),
    ]


最後に、path('find', views.find, name='find')というように文が追加されています。  
これで、/hello/findにアクセスしたらviews.pyのfind関数が実行されるようになります。


### FindFormを作る

では、findページをつくります。まずは、フォームからです。  
「hello」フォルダ内のforms.pyを開き、以下のスクリプトを追記してください。


<p class="mb-05"><span class="tmp list">リスト3-40</span><span class="bold">forms.pyにスクリプトを追記</span></p>

    class FindForm(forms.Form):
        find = forms.CharField(label='Find', required=False)


これで簡単な検索フォームを用意し、検索を行うことにしましょう。  
「templates」フォルダ内の「hello」フォルダの中に、新たに「find.html」という名前でファイルを作成します。  
以下のように内容を記述してください。

<p class="mb-05"><span class="tmp list">リスト3-41</span><span class="bold">find.htmlを新規作成</span></p>

    {% load static %}
    <!doctype html>
    <html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>{{title}}</title>
        <link rel="stylesheet" type="text/css" 
            href="{% static 'hello/css/style.css' %}" />
    </head>
    <body>
        <h1>{{title}}</h1>
        <p>{{message|safe}}</p>
        <table>
            <form action="{% url 'find' %}" method="post">
            {% csrf_token %}
            {{form}}
            <tr><th></th><td><input type="submit" value="click"></td></tr>
            </form>
        </table>
        <hr>
        <table>
            <tr>
                <th>data</th>
                <th></th>
                <th></th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item}}</td>
                <td><a href="{% url 'edit' item.id %}">Edit</a></td>
                <td><a href="{% url 'delete' item.id %}">Delete</a></td>
            <tr>
        {% endfor %}
        </table>
    </body>
    </html>


図　find.htmlの表示。ただし、まだビュー関数がないので現時点では表示できません。



### find関数を作る

続いて、ビュー関数です。  
「hello」フォルダ内のviews.pyを開き、以下のfind関数を追記しましょう。

<p class="mb-05"><span class="tmp list">リスト3-42</span><span class="bold">views.pyにfind関数を追記</span></p>

    from .forms import FindForm　#この文を追記しておく

    def find(request):
        if (request.method == 'POST'):
            msg = 'search result:'
            form = FindForm(request.POST)
            str = request.POST['find']
            data = Friend.objects.filter(name=str)
        else:
            msg = 'search words...'
            form = FindForm()
            data =Friend.objects.all()
        params = {
            'title': 'Hello',
            'message': msg,
            'form':form,
            'data':data,
        }
        return render(request, 'hello/find.html', params)
![](search1.png)
<p class="text-center">↓</p>
![](search2.png?classes=caption "図　入力フィールドに名前を書いて送信すると、その名前のレコードだけが表示されます。")


記述したら、/hello/find/にアクセスしてみます。  
フォームとレコードが表示されます。  
このフォームに、検索したいレコードの名前を記入して送信すると、nameの値だけが入力したテキストと同じレコードだけを検索して表示します。


### filterのもっともシンプルな使い方

ここでは、送付されたフォームの値を取り出し、nameからその値を探しています。この部分です。

    str = request.POST['find']
    data = Friend.objects.filter(name=str)

filterメソッドの引数には、「name=値」というように指定がされています。  
こんな具合に、検索する引数に値を指定することで、その項目から検索を行うことが出来ます。



## あいまい検索

あいまい検索は、filterメソッドの「項目名=値」の書き方に少し追記をするだけで利用できるようになります。
以下に整理してます。

* 値を含む検索
: 項目名**{c:red}__contains{/c}**=値

* 値で始まるものを検索
: 項目名**{c:red}__startswish{/c}**=値

* 値でおわるものを検索
: 項目名**{c:red}__endswish{/c}**=値

例えば、name項目から、'太郎'を含むものを検索したければ、filterメソッドの引数に「name__contains='太郎'」と指定をすればいいわけです。  
これで、「一太郎」も「山田太郎」も「太郎君」も検索されるようになります。


### __containsを試してみよう


では、実際に試してみます。先ほど記述したfind関数を修正してみます。  
「hello」フォルダ内にあるviews.pyを開き、そこにあるfind関数を以下のように修正してください。

現在

	data = Friend.objects.filter(name=str)
    
修正

	data = Friend.objects.filter(name__contains=str)    #☆

<p class="mb-05"><span class="tmp list">リスト3-43</span><span class="bold">views.pyにfind関数を修正</span></p>

    def find(request):
        if (request.method == 'POST'):
            msg = 'search result:'
            form = FindForm(request.POST)
            str = request.POST['find']
            data = Friend.objects.filter(name__contains=str)    #☆
        else:
            msg = 'search words...'
            form = FindForm()
            data =Friend.objects.all()
        params = {
            'title': 'Hello',
            'message': msg,
            'form':form,
            'data':data,
        }
        return render(request, 'hello/find.html', params)

☆の行が、修正された部分です。  
これで検索を実行すると、入力フィールドに書いたテキストをnameに含むものをすべて検索します。 
例えば、下図のように「**{c:red}r{/c}**」で検索すると、「hi**{c:red}r{/c}**ao」も「ku**{c:red}r{/c}**odaも検索されます。

![](search3.png?classes=caption "図　「r」であいまい検索")



<p>ここでは__containsを使いましたが、例えば、メールアドレスで「.comで終わるものだけを取り出したい」といったときは、mail__endswish='.com'なんて具合にすればよいです。</p>



### 大文字小文字を区別しない

アルファベットのテキストを扱うとき、注意しないといけないのが「大文字と小文字」です。  
filterの検索では、大文字と小文字は別の文字として扱われます。  
例えば、'taro'を検索する場合、"Taro"や"TARO"は探し出せません。  
こうした場合に用意されるのが、以下のようなものです。


* 大文字小文字を区別しない検索
: 項目名**{c:red}__iexact{/c}**=値


* 大文字小文字を区別しないあいまい検索
: 項目名**{c:red}__icontains{/c}**=値
: 項目名**{c:red}__istartswish{/c}**=値
: 項目名**{c:red}__iendswish{/c}**=値

<p>__iexactは、完全一致の検索を行うものです。<br>
例えば、name__iexact='taro'とすれば、'taro'も'Taro'も'TARO'も探し出すことができます。<br>
その後の3つは、大文字小文字を区別しないあいまい検索のためのものです。<br>
名前を見ればわかるように、それぞれ__の後に「i」がついています。<br>
__containsならば、__icontainsとするだけで大文字小文字を区別しなくなるのです。<br>  
先ほどfind関数を修正しましたが、その☆の文を以下のように書き換えてみましょう。</p>


<p class="mb-05"><span class="tmp list">リスト3-44</span><span class="bold">views.pyのfind関数を修正</span></p>
	data = Friend.objects.filter(name__iexact=str)

これで、大文字小文字区別せずに検索を行うようになります。  
下図のように、「SATO」で検索すると、「sato」の名前のデータをを検索できました。

![](search4.png?classes=caption "図　検索すると、nameの値を大文字小文字を区別せずに検索します。")


### 数値の比較

数値関係の検索について以下にまとめておきましょう。

* 値と等しい
: 項目名=値

* 値よりも大きい
: 項目名**{c:red}__gt{/c}**=値

* 値と等しいか大きい
: 項目名**{c:red}__gte{/c}**=値

* 値よりも小さい
: 項目名**{c:red}__lt{/c}**=値

* 値と等しいか小さい
: 項目名**{c:red}__lte{/c}**=値


これも実際に使ってみましょう。find関数の☆マークの文を以下のように書き換えてみて下さい。


<p class="mb-05"><span class="tmp list">リスト3-45</span><span class="bold">views.pyのfind関数を修正</span></p>
	data = Friend.objects.filter(age__lte=int(str))
    
「30」で入力すると、「30歳」以下の人のデータが表示されます。

![](search5.png?classes=caption "図　入力した年齢以下のレコードを検索します。")



ここでは、「age__lte=int(str)」というように実行をしています。

<p>フォームに用意してある入力フィールドはCharFieldで作成してあるので、送られてくる値はテキストであるため、intで整数にして比較してあります。  
（ただし、これは省略してage__lte=strでもちゃんと動作してくれます。テキストを__lteで比較するのはなんとなく気持ちが悪いので整数に変換しています）。</p>



### 〇〇以上〇〇以下はどうする?

例えば「10代を検索」というのは、年齢が10以上で、かつ20未満のものを探す、ということになります。両方の条件に合うものを探すわけで、そのためには同時に複数の条件を設定しないといけません。

こうした「複数の条件を設定する」という場合、2種類のやり方があります。  
1つは「**両方の条件に合うものを探す**」というもの、もう1つは「**どちらか1つでも合えば全部探す**」というものです。

まずは、「両方の条件に合うものを探す」という場合から考えてみます。  
これは簡単で、filterの引数に2つの条件をかけばいいんです。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">filterの引数に条件をかく</span></p>

	変数=《モデル》.object.filter(1つ目の条件、2つ目の条件)

こうすれば、両方の条件を満たすもの検索することができます。  
このように、複数の条件のすべてに合致するものだけを検索するやり方を「**{c:red}AND検索{/c}**」といいます。  
「AND検索」は、「どちらも正しいもの」を探すやり方です。


#### 〇〇以上〇〇以下を試してみる

「hello」フォルダ内のviews.pyを開き、find関数を以下のように書き換えて下さい。

<p class="mb-05"><span class="tmp list">リスト3-46</span><span class="bold">views.pyの編集</span></p>

    def find(request):
        if (request.method == 'POST'):
            msg = 'search result:'
            form = FindForm(request.POST)
            str = request.POST['find']
            val = str.split()
            data = Friend.objects.filter(age__gte=val[0], age__lte=val[1])  #☆
        else:
            msg = 'search words...'
            form = FindForm()
            data =Friend.objects.all()
        params = {
            'title': 'Hello',
            'message': msg,
            'form':form,
            'data':data,
        }
        return render(request, 'hello/find.html', params)


![](search6.png?classes=caption "図　20歳以上30歳以下を検索")



入力フィールドに、検索する最少年齢と最大年齢を**半角スペース**で区切って書いてください。  
例えば、「20 30」とすれば、20歳以上30歳以下を検索します。

下記では、まず入力されたテキストを取り出し、、それをスペースで分けます。

    str = request.POST['find'}
    val = str.split()

「**{c:red}split(){/c}**」というメソッドは、テキストを決まった文字や記号で分割したリストを返します。  
引数を省略すると、半角スペースや改行でテキストを分割します。  
これで、例えば「20 30」と入力されたテキストは、「20,30」というリストになります。  
後は、以下のようにリストの値を使ってfilterメソッドを呼び出し、検索を行うだけです。  

	data = Friend.objects.filter(age__gre=val[0], age__lte=val[1])

この文では、1つ目の引数では「**age__gre=val[0]**」という条件を、2つ目は「**age__lte=val[1]**」以下のレコードを取り出されるわけです。

filterメソッドは、引数は2つだけでなく、いくつでも条件を記述することができます。  
つまり、3つでも4つでも条件を設定し、「すべての条件に合うもの」を検索できます。



#### 別の書き方もある

このやり方はとてもわかりやすいんですが、filterの引数内にいくつもの条件を記述するため、かなりわかりにくいコードになってしまいます。

実際に試してみると、filterの引数が延々と続く文が出来上がってしまうでしょう。  
実は、もっとわかりやすい書き方もあります。  
filterメソッドを複数書けばいいのです。以下のようになります。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">filterメソッドを複数書く</span></p>

    変数 = 《モデル》.object\
            .filter(1つ目の条件)\
            .filter(1つ目の条件)\
            .filter(1つ目の条件)\
            .filter(1つ目の条件)\
            ……略……

こんな具合にすれば、だいぶ条件もわかりやすくなります。  
条件の数も増えた場合もまったく同様なので、1つ1つの条件も整理できます。  
先ほど書いたサンプル（find関数）の☆マークの部分を以下のように書き換えて下さい。

<p class="mb-05"><span class="tmp list">リスト3-47</span><span class="bold">views.pyのfind関数の書き換え</span></p>

    data = Friend.objects \
            .filter(age__gte=val[0]) \
            .filter(age__lte=val[1])

これでも、まったく同じように検索できます。この例では、2つのfilterが連続して実行されているのがわかります。


### AもBもどっちも検索したい

もう1つの「どちらか一方でも合えば抽出」というものも、けっこう必要となることは多いものです。  
例えば、「名前かメールアドレスのどちらかが'taro'のもの」を探す、となると、nameとmailの両方から検索をしないといけないときに必要となります。  
書き方は以下になります。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">どちらか一方でも合えば抽出</span></p>

	変数 = 《モデル》.objects.filter(Q(1つ目の条件)|Q(2つ目の条件))

Qという関数の引数に条件を指定したものを「**|**」記号でつなげてfilterの引数に書いています。  
「条件は、Qという関数の引数に書く」「それぞれの条件は、|記号でつなげて書く」というこの2点をしっかり理解するように下さい。
この書き方も、2つ以上の条件を設定できます。それぞれの条件を|記号でつなげていけばいいのです。  

このように、「複数の条件のどれかが合えば検索する」というやり方を「**{c:red}OR検索{/c}**」といいます。

#### nameとmailから検索する

「hello」フォルダ内のviews.pyを開いて、先ほど修正したfind関数を以下のように書き換えて下さい。


<p class="mb-05"><span class="tmp list">リスト3-48</span><span class="bold">views.pyのfind関数の書き換え</span></p>

    from django.db.models import Q    # 追記

    def find(request):
        if (request.method == 'POST'):
            msg = 'search result:'
            form = FindForm(request.POST)
            str = request.POST['find']
            data = Friend.objects.filter(Q(name__contains=str)|Q(mail__contains=str))    #☆
        else:
            msg = 'search words...'
            form = FindForm()
            data =Friend.objects.all()
        params = {
            'title': 'Hello',
            'message': msg,
            'form':form,
            'data':data,
        }
        return render(request, 'hello/find.html', params)


![](search7.png?classes=caption "図　nameかmailかのどちらかに検索テキストがあればすべて検索する")


最初にある from django.db.models import Q は、忘れずに書いてください。  
これで入力フィールドにテキストを書いて検索すると、nameかmailのどちらかにテキストが含まれているレコードを全部検索します。



### リストを使って検索

例えば、名前でレコードを検索するとき、「検索したい名前がたくさんある」というときはどうするのがよいでしよう。  
こういっとき、filterには「リストを使った検索」を行う機能があります。
これは以下のように実行します。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">リストを使った検索</span></p>

	変数 = 《モデル》.objects.filter(項目名__in=リスト)

これで、指定の項目にリストの中の値があれば検索できるようになります。
例えば、|'太郎','次郎','三郎'|とすれば、この3人のレコードを全部取り出すことができる、というわけです。


#### 書いた名前を全部検索する

「hello」フォルダ内のviews.pyを開き、find関数を以下のように書き換えて下さい。



<p class="mb-05"><span class="tmp list">リスト3-49</span><span class="bold">views.pyのfind関数の書き換え</span></p>

    def find(request):
        if (request.method == 'POST'):
            msg = 'search result:'
            form = FindForm(request.POST)
            str = request.POST['find']
            list = str.split()
            data = Friend.objects.filter(name__in=list)    #☆
        else:
            msg = 'search words...'
            form = FindForm()
            data =Friend.objects.all()
        params = {
            'title': 'Hello',
            'message': msg,
            'form':form,
            'data':data,
        }
        return render(request, 'hello/find.html', params)

![](search8.png?classes=caption "図　名前をスペースで区切って記述していくと、それらの名前のレコードをすべて検索し表示する。")


入力フィールドに、検索したい名前を半角スペースで区切って書いて行きましょう。  
いくつ書いても構いません。すべて書いて送信すると、それらの名前のレコードを全て表示されます。  
下記では、まず入力された名前をリストに変換します。

        str = request.POST['find']
        list = str.split()

これは前にやりましたが、splitで半角スペースでテキストを分割しリストを作ります。
これを元に検索を行えばいいのです。

	data = Friend.objects.filter(name__in=list)

上記の文で、nameからリストの名前を検索していきます。nameの名前が、リストのどれか1つにでも合えば全て取り出されます。


### この章のまとめ

#### allとgetは基本中の基本

最初に使った、**allメソッド**と**getメソッド**　この2つは、データベースを扱う上でもっとも基本となるものです。  
「全部取り出す」「指定のIDを取り出す」の2つです。
これらの使い方はしっかり覚えてください。


#### CRUDは、「C」だけ覚える

データベースアクセスの基本は**CRUD**ですが、今すぐこれらをすべてマスターする必要はありません。
とりあえず、「**Create（新規作成）**」だけできようになっておきましょう。
フォームを送信して、レコードを保存するというのは、どんなWebアプリでも必ず必要となる機能です。
このCrateでは、Forms.Formを使ったやり方と、ModelFormを使ったやり方について説明をしましたが、ModelFormのほうだけ覚えておけば十分です。


#### filterの基本だけは覚えておこう

検索の基本は、filterメソッドです。とりあえず、「項目名=値」と引数に指定して検索するやり方だけはしっかり覚えておきましょう。  
また、**__contains**を使ったあいまい検索ぐらいは覚えておくと後でいろいろ使えます。


#### 基本は「検索」と「新規作成」

データベースには様々な機能がありますが、おそらくアプリを作るとき最初に必要となるのは「**検索**」と「**新規作成**」です。
検索は、機能がいろいろありすぎるので、一番の基本である「**全部取り出す**」「**ID番号で取り出す**」「**同じ値のものを取り出す**」の3つだけはできるなりましょう。

