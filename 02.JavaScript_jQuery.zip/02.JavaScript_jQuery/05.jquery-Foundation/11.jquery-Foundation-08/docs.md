---
title: モーダルウィンドウ
visible: true
---

<a href="modal/sample1/index.html" target="_blank">モーダルダイアログサンプル</a>

<iframe width="100%" height="400" src="//jsfiddle.net/y7spmhbc/5/embedded/result,js,html,css/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<a href="modal/sample2/index.html" target="_blank">モーダルウィンドウサンプル</a>

<iframe width="100%" height="600" src="//jsfiddle.net/0ywgmrt3/9/embedded/result,js,html,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>





