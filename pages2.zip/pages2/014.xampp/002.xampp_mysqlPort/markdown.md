*[page-title]:MySQLのポート番号を変更



参考サイト
: <https://itsakura.com/xampp-port>

## Xampp側の変更

コントロールパネルのMySQLのconfigボタンを押して、myiniをクリックします。
![](upload/MySQLのポート番号を変更1.png)
myiniの次の赤線のポート番号を変更します。<br>
ここでは、デフォルトの3306を3309に書き換えました。
![](upload/MySQLのポート番号を変更2.png)
phpMyAdmin/config.inc.phpを開いて、下記のコードに3309を追加します。
![](upload/MySQLのポート番号を変更3.png)
コントロールパネルのMySQLを再起動すると、3309に変わります。
![](upload/3309にコントロールパネルがかわりました.png)

## from_now_slim側の変更

from_now_slimのデータベース接続のポート番号を追加します。<br>
containerSetups.phpの40行目を変更します。
![](upload/MySQLのポート番号を変更4.png)
common\update\index.phpにポート番号を追記します。
![](upload/MySQLのポート番号を変更5.png)

変更ファイルが多いので、一括置換するのが良い。

`mysql:host=localhost`　→　`mysql:host=localhost:3309`

![](upload/localhost全置換.png "図　VSCODEで一括置換")
