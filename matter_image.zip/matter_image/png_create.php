<?php
    //JPEGからPNGを複製
    //list($width, $hight) = getimagesize($photo); // 元の画像名を指定してサイズを取得

    $baseImage = imagecreatefromjpeg($photo); // 元の画像から新しい画像を作る準備(png用)

    $image = imagecreatetruecolor($reWidth, $reHight); // サイズを指定して新しい画像のキャンバスを作成

	//ベース画像の背景色-透過処理
	$bg_color = imagecolorallocatealpha($image, 255, 255, 255, 100);
	imagealphablending($image, true);
	imagesavealpha($image, true);
	imagefill($image, 0, 0, $bg_color);
    
    // 画像のコピーと伸縮
    imagecopyresampled($image, $baseImage, 0, 0, 0, 0, $reWidth, $reWight, $width, $hight);

    $photo_png = $_REQUEST['chatImg'].'/image.png';

    imagepng($image , $photo_png);

?>