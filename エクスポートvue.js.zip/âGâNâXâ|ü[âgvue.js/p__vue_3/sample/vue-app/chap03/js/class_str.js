Vue.createApp({
  data() {
    return {
      colorClass: 'color',
      frameClass: 'frame'
    };
  }
}).mount('#app');