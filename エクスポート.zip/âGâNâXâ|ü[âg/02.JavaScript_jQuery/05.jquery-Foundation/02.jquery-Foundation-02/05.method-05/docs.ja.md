---
title: '05. クラスの取得や追加、削除<br>（addClass、removeClass、toggleClass、hasClass）'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    .l-space {
        letter-spacing: .1rem!important;
    }
</style>
<h2 class="h-type2">クラスの追加（addClass）</h2>

要素にclassを追加するには、addClassを使用します。

<dl class="dl-methodDetail">
    <dt><span>書式</span></dt>
    <dd>$('セレクタ').addClass('クラス名');</dd>
</dl>
<div class="box-example">
    <h3 class="h-example">例1</h3>
    p要素をクリックすると、赤文字のclassを適用する。
</div>

<iframe width="100%" height="200" src="//jsfiddle.net/m13jv74y/1/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLではp要素を3つ並べています。  
CSSでは赤文字のクラスactiveを用意しています。

ではJavaScriptのコードを見てみましょう。  
p要素がクリックされたときに、その要素に対してのみactiveクラスが追加され文字が赤くなります。  

---

<h2 class="h-type2">クラスの削除（removeClass）</h2>

要素からclassを削除するには、removeClassを使用します。

<dl class="dl-methodDetail">
    <dt><span>書式</span></dt>
    <dd>$('セレクタ').removeClass('クラス名');</dd>
</dl>
<div class="box-example">
    <h3 class="h-example">例2</h3>
    p要素をクリックすると、赤文字のclassを削除する。
</div>

<iframe width="100%" height="200" src="//jsfiddle.net/m13jv74y/3/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLではactiveクラスのついたp要素を3つ並べています。  
CSSでは赤文字のクラスactiveを用意しています。

ではJavaScriptのコードを見てみましょう。  
p要素がクリックされたときに、その要素に対してのみactiveクラスが削除され文字が黒く戻ります。  

---

<h2 class="h-type2">クラスの追加または削除（toggleClass）</h2>

toggleClassを使用すると、指定した要素にclassがあれば削除、なければ追加します。

<dl class="dl-methodDetail">
    <dt><span>書式</span></dt>
    <dd>$('セレクタ').toggleClass('クラス名');</dd>
</dl>
<div class="box-example">
    <h3 class="h-example">例3</h3>
    p要素をクリックしたらclassを追加し、classを追加した要素をクリックするとclassが消える。
</div>

<iframe width="100%" height="200" src="//jsfiddle.net/m13jv74y/4/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLではp要素を3つ並べています。  
CSSでは赤文字のクラスactiveを用意しています。

ではJavaScriptのコードを見てみましょう。  
p要素がクリックされたときに、その要素にactiveクラスがなければ追加され文字が赤くなり、activeクラスがあれば削除され文字が黒く戻ります。  

---

<h2 class="h-type2">クラス存在有無の判定（hasClass）</h2>

マッチした要素に、指定したclass名が存在するかを判定するには、hasClassを使用します。

<dl class="dl-methodDetail">
    <dt><span>書式</span></dt>
    <dd>$('セレクタ').hasClass('クラス名');</dd>
    <dt><span class="l-space">戻り値</span></dt>
    <dd>真なら'true'、偽なら'false'</dd>
</dl>
<div class="box-example">
    <h3 class="h-example">例4</h3>
    クリックした箱の背景が緑色なら、文字を赤くする。
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/ucawtpj1/3/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLではdiv要素の箱を3つ並べています。真ん中だけクラスbg-greenを付けています。  
CSSでは緑背景のクラスbg-green、文字色赤のクラスfont-redを用意しています。

ではJavaScriptのコードを見てみましょう。  
div要素がクリックされたときに、その要素にbg-greenクラスがあるか判定します。  
戻り値がtrueならfont-redクラスを追加しています。