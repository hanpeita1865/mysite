<div>
<a href="login-input.php">ログイン</a>
<a href="logout-input.php">ログアウト</a>
</div>
