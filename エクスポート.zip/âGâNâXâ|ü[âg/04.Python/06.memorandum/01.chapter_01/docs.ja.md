---
title: サイトのキャプチャを取得する
media_order: 'environment.png,mytest1.png,mytest2.png,project_create.png,project_menu.png,new_file.png'
taxonomy:
    category:
        - docs
---

* [初期設定](#p1)
* [サイトのキャプチャを取得](#p2)

## 初期設定 ##{#p1}

### Anacondaに仮想環境を作成

Anacondaを起動し、mytest（仮）の仮想環境を作成していきます。

1. 左メニューのEnviromentsボタンを押し、下部のcreateアイコンをクリックする。
2. 入力画面がボップアップで表示されるので、仮想環境名（mytest）を入力し、Pythonの最新バージョンを選択したらcreateボタンをクリックする。
![](environment.png)

3. そうすると、mytestという名前の仮想環境が作成される。
![](mytest1.png)
4. この仮想環境にSpyderをインストールする。左メニューのHomeボタンを押し、Spyderのアイコンがあるボックスのinstallボタンをクリックする。しばらくかかってインストールが完了すると、ボタンが以下のようにLunchにかわります。
![](mytest2.png)
6. そのLunchボタンをクリックし、Spyderを起動します。ツールバーの「プロジェクト」-「新規プロジェクト」をクリックし、プロジェクトフォルダを作成します。ここでは「sample_project」でデスクトップに作成しました。
7. 左メニューをsample_projectに合わせたあと、ここに新規のpyファイルなどを作成していきます。
![](project_menu.png)
8. 新規ファイル作成するには、ツールバーのファイルの新規ファイルをクリックして、そこにコードを書き込んで保存します。
![](new_file.png)




### Selenium をインストール

コマンドプロンプトで下記を実行（pip で selenium を インストール）  
※仮想環境ごとにインストールするのか???

```
pip install selenium
```

### chromedriverをインストール

Chromeのバージョンに合わせて、下記サイトからchromedriver_win32.zipをダウンロードします。
<https://chromedriver.chromium.org/downloads>

解凍したら、任意の場所に格納します。ここでは、Cドライブ直下にAuto_Testフォルダを作成し、その中に格納しました。  
C:/Auto_Test/chromedriver.exe

***ここまでが初期設定になります。***

Chromeがバージョンアップされると、今のChromedriverは機能しなくなるので、その都度<https://chromedriver.chromium.org/downloads>からダウンロードしてください。

## サイトのキャプチャを取得 ##{#p2}

サイトのキャプチャを取得して、フォルダに格納するには以下のようにします。

### キャプチャ取得方法 

1. Anacondaを立ち上げる。
2. 仮想環境mytestを開く  
	Environmentsを選択し、mytestをクリック。
3. HOMEメニューにもどり、SPyderをクリックし、起動させる。
4. 下記のフォルダにPythonのファイルが格納されています。  
C:\Users\hirao\Desktop\フォルダ用ショートカットまとめ\★★色々まとめフォルダ\sample_project
5. その中から、それぞれの地区のファイルがあるので、それをSpyderで開く  
例) 東北地方 chapter_tohokupy.py
6. C:/Auto_Test/chromedriver.exeを起動します。
7. pyファイルを▶ボタンをクリックし、実行します。
8. C:\Users\hirao\Desktop\sample_project\site_captureフォルダにに出力されます。

### 各地方美術館のキャプチャを撮る
例) 北海道・東北の場合  
C:\Users\hirao\Desktop\フォルダ用ショートカットまとめ\★★色々まとめフォルダ\sample_project

1. chapter_tohokupy.pyを実行　→　sample_project\site_capture\hokkaido_tohoku にキャプチャ画像が出力される。
2. chapter_resize_sm _tohoku.pyを実行　→　リサイズされた画像が sample_project\small_site_capture\hokkaido_tohoku に格納される
3. みんばりの　living-info\facility\art_museum\images にリサイズした画像を格納する


<div class="box-example">
    <h3 class="h-example">例1</h3>
	サイトのキャプチャを指定したフォルダ（～/site_capture）に格納する。
</div>
<p class="tmp list"><span>リスト1</span>chapter_save_multi.py</p>
```
from selenium import webdriver

#キャプチャを撮るサイトのURL
urls = ["http://tendocity-museum.jp/"
        ]

#ChromeDriver格納場所
driver = webdriver.Chrome("C:/Auto_Test/chromedriver.exe")

for url in urls:
    driver.get(url)

    page_width = driver.execute_script('return document.body.scrollWidth')
    page_height = driver.execute_script('return document.body.scrollHeight')
    driver.set_window_size(page_width, page_height)

    #「https://」と「http://」を取り、「/」を「_」に置換。
    url_name = url.lstrip("https://" "http://" ).replace("/","_").replace("?", "_")
    #画像の名前に「image_」を頭につけて、指定したフォルダに格納
    driver.save_screenshot(r"C:\Users\hirao\Desktop\sample_project\site_capture\image_" + str(url_name) + ".png")


```

※ただスクロールバーも入っているので、CSSで隠すか、何かで画像をトリミングするかしないといけないかもしれません。


<div class="box-example">
    <h3 class="h-example">例2</h3>
	test_resizeフォルダに格納したサイトのキャプチャをリサイズして、リネームする。
</div>
<p class="tmp list"><span>リスト2</span>chapter_save_multi.py</p>


```
from PIL import Image

import glob

files = glob.glob("test_resize/*")
for file in files:

    im = Image.open(file)
    
    if im.mode != 'RGB':
        im = im.convert('RGB')
    
    small_view = im.resize((int(im.width / 2), int(im.height / 2)))
    
    #リサイズした画像を別のフォルダに保存
    small_view.save('small_' + file)
```














