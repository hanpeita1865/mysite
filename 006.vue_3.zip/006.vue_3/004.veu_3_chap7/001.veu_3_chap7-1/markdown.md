*[page-title]:7-1. Vue CLIの基本

## 7-1-1 Vue CLI のインストール

参考サイト
: [【Vue.js】VueCLIで新しくなったVue3のプロジェクトを作成するまでの手順を徹底解説！](https://gakogako.com/vuecli/)

<div markdown="1" class="memo-box">
<span class="red">注意）</span>
: 以前のバージョンの Vue CLI をインストールしている場合
Vue CLI は、バージョン2.xと3.x以降でパッケージ名が変更になっています(2.xは vue-cli、3.x 以降は @vue/cli です)。 よって、 もしも現在の環境に Vue CLI 2.x をインストールしている場 合には、 3.x 以降をインストールする前に、 アンインストールしておく必要があります。 以下のコマンドを実行してください。

<p class="tmp cmd">Vue CLI アンインストール</p>
```
npm uninstall -g vue-cli
```
</div>

ver2のバージョンをアンインストールし終わったら、ver3をインストールします。

<p class="tmp cmd"><span>コマンド</span>Vue CLI インストール（グローバル）</p>
```
npm install -g @vue/cli
```
![](upload/Vue_CLIインストール.png)

### プロジェクトの作成

では、プロジェクトを作成していきます。  
ディレクトリを移動して、次のコマンドを実行します。ここではプロジェクト名を「<span class="red">my-cli</span>」にしています。
<p class="tmp cmd"><span>コマンド</span>vue create</p>
```
vue create my-cli
```

画面が切り替わり、最初にVue2のデフォルト設定かVue3のデフォルト設定か、自分で詳細設定するかを聞かれます。  
詳細設定はせずに手っ取り早くVueプロジェクトを作成したい場合は、  
「 <span class="bold">Default (Vue 3) ([Vue 3] babel, eslint)</span>」  
を選択してください。
![](upload/Manually_select_features.png)
「<span class="red bold">Manually select features</span>」  
を選択すると以下の質問らが表示されます。

今回は詳細設定を解説したいので、「Manually select features」 を選択します。

画面が切り替わったら、↑↓キーで「<span class="red">Router</span>」に移動して、Spaceキーを押すと「*」が付いて選択状態になります。  
これで、Enterキーを押します。

※「Router」を選択すると、<span class="green bold">Vue Router</span>の機能が追加されます。機能の詳細は、第８章を見てください。
![](upload/Router選択.png)

「3.x」選択のまま、Enterキーを押します。
![](upload/3.x選択.png)

使用するURLの形式で、historyモードかhashモードを選ぶ事ができます。
historyモードとはhttp://localhost:8080/indexの様な普段使用している一般的なURLの形式です。
一方hashモードはhttp://localhost:8080/#/indexの様なURLの間に#が入る形式です。
<div markdown="1" class="memo-box">
※cssやjsの読み込みは、デフォルトでは「/」ルートパスになっています。相対パスに変更したい場合、「n」を入力してhashモードにしておく必要があります。そのうえで、vue.config.js に下記を追記します。
```
module.exports = {
  publicPath: './'
}
```
</div>
![](upload/history_mode_Y.png)

リンターとフォーマッターは何を使うかを聞かれています。  
ESLint + Prettierが王道だと思いますが、好きなやつを選択してください。
![](upload/ESLint_Prettier選択.png)

リントをどのタイミングで実行するかをきかれています。選択肢はファイルセーブ時とコミット時が選択できます。
両方とも選択できますが、基本的にセーブ時のみで問題ないと思います。
「Lint on save」選択のまま、Enterキーを押します。
![](upload/Lint_on_save選択.png)

babelやESLintの設定をどのファイルに記述するかを聞かれています。  
それぞれ専門の設定ファイルを使用する場合はIn dedicated config filesを、jsonファイルで管理する場合はIn package.jsonを選択します。
![](upload/In_package_json選択.png)

ここまでの質問での設定を保存しておくかを聞かれます。
![](upload/Save_this_as_a_preset.png)
保存を選択すると次回のvue createコマンド実行時に最初の質問で同じ設定を適用するかを聞いてくれます。
同じ設定で次回もプロジェクトを作成したい場合は保存しておくといいでしょう。

保存した場合、次回作成する時に最初の設定画面で次の表示がでます。
![](upload/Vue_CLI初期設定画面.png)

これでプロジェクト作成処理が開始されます。20分くらいかかります。  
処理が終わると次の画面に切り替わります。
![](upload/プロジェクト作成完了.png)

指定したディレクトリに「my-cli」プロジェクトが作成されています。
![](upload/プロジェクト作成完了.png)

「my-cli」ディレクトリに移動して、「npm run serve」コマンド でプロジェクトを実行し、WEBサーバーを立ち上げます。  
以下の画面が表示されたら、http://localhost:8080/ にアクセスします。
![](upload/local8080.png)

次の画面が表示されれば、OKです。「Roter」で設定してれば、上部のHomeとAboutのリンクでページが切り替わることが確認できると思います。
![](upload/Welcome_to_Your_Vue画面.png)

### プロジェクトをビルド
プロジェクトの内容をそのまま実行する npm run serve コマンドに対して、アプリをビルドし、本番環境に配置(<span class="green bold">デプロイ</span>) するためのファイル一式を作成するのが、 <span class="green bold">npm run build</span> コマンドの役割です。

<p class="tmp cmd"><span>コマンド</span>ビルド</p>
```
npm run build
```
上記のコマンドを実行すると、以下のように distフォルダと、その中にindex.htmlやcss、jsフォルダなどが生成されます。
![](upload/my-cli_build実行後フォルダ.png)

## 7-1-2 プロジェクトの自動生成・・・


## 7-1-3 Vue CLI の主なサブコマンド

### プラグインを追加する - vue add コマンド
Vue CLI は、プラグインベースのツールです。 標準で提供される機能はごく限られており、別に用意 されたプラグインから必要なものを組み合わせて利用するのが基本です。 たとえば前項の手順で組み込まれた Babel、ESLint なども、 プラグインとしてプロジェクトに組み込まれています。  
プラグインは、プロジェクト作成時のウィザードで組み込む他、<span class="green bold"> vue add</span> コマンドで後からプロジェ クトに組み込むことも可能です。たとえば以下は、単体テストのための Jest を組み込む例です。
<p class="tmp cmd"><span>コマンド</span>unit-jest追加例</p>
```
vue add @vue/unit-jest
```
インストールが完了して次のメッセージが表示されれば成功です。
![](upload/plug_in_nuitインストール完了.png)
package-lock.jsonに追加されています。
![](upload/package_lock_unit-jest.png)

接頭辞として 「<span class="red">@vue/</span>」 がない場合は、サードパーティのプラグインであると見なされます。 たとえば以下は、Element Plus (11-1-2項) のプラグインを導入する例です。
<p class="tmp cmd"><span>コマンド</span>vue-cli-plugin-element-plusインストール</p>
```
vue add element-plus
```
この場合、内部的には vue-cli-plugin-element-plus がインストールされます。8~9章で登場する Vue Router、Vuexのようなライブラリも同様です。
<p class="tmp cmd"><span>コマンド</span>Vue Router、Vuexインストール</p>
```
vue add router
vue add vuex
```

### .vue ファイルを素早く実行する - vue serve コマンド（CLI ver5では無効）

<details><summary>詳細内容</summary>
vue serve コマンドを利用すると、 .vue ファイルをプロジェクトを作成することなく簡単に実行でき ます。 先ほど見たように、 プロジェクト作成には関連するパッケージのインストールなど、若干の待ち 時間があります。 しかし、<span class="green bold">vue serve </span>コマンドを利用することで、 <span class="red">ちょっとしたお試しのコンポーネン トを手軽に実行できます</span>。

vue serve コマンドを利用するには、冒頭 (7-1-1項) の @vue/cli に加えて、 以下のアドオンをインストールしておく必要があります。
```
npm install -g @vue/cli-service-global
```
インストール結果
![](upload/service_grobalインストール.png)
ダウンロードサンプルの/chap07/cli-basic フォルダーに移動して、そこに用意されている App.vue を実行してみましょう。 vue ファイルについては後節で解説しますので、ここでは 「&lt;h1&gt; こんにちは、 Vue CLI ! &lt;/h1&gt;」 というコードを出力するためのコンポーネントである、 とだけ理解しておいてくだ さい。

<span class="red bold">vue serve を実行すると、下記のようにエラーがでる。なぜ??</span><br>
→これはVue CLI(ver5)では、この機能が使えなくなったことによるようです。Vue CLI(ver4)では使えてました。
![](upload/vue_serve実行エラー画面.png)
</details>


### Vue SFC Playground（リアルタイムに実行）

オンラインで .vue ファイルをリアルタイムに実行する <span class="green bold">Vue SFC Playground</span> (<https://sfc.vuejs.org/>) のようなサービスもあります。
![](upload/Vue_SFC画面.png "図 Vue_SFC画面")
左ペインでコードを編集すると、 右の [PREVIEW] タブで実行結果を即座に確認できます。 左ペイン上部の⊕ボタンから.vue ファイルを追加することも可能ですし、Playground の右 肩からはバージョンの選択もできます。 軽い動作確認に便利なので、 コマンドラインと合わせ て活用すると良いでしょう。

### Vue CLI プロジェクトをGUI管理する - vue ui コマンド

以前の 「[Veu.js 第1章 Vue.jsを使ってみよう](../p__vue1-1/#chapter3)」ページの「GUIを使おう」の項目で説明済みなので、とばします。