<?php
$database='from_now';
$user='staff';
$password='password';

$pdo=new PDO('mysql:host=localhost;dbname='.$database.';charset=utf8',$user, $password);
?>

<!DOCTYPE html>
<html lang="ja">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>管理画面｜</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/fork-awesome.min.css">
	<!--<link rel="stylesheet" href="../css/style.css">-->
    <link rel="stylesheet" href="../css/admin.css">
	<!-- <script src="../js/jquery.min.js"></script> -->
	<script>
	//閲覧不可ページ
	let lockArray = [
	<?php foreach ($pdo->query('select * from locklist') as $row): ?>
		'<?= $row['page'] ?>',
	<?php endforeach; ?>
	];
	</script>
</head>

<body>
	<main>
		<div class="container">
			<h1>管理画面</h1>
			<div id="backup-alert" class="alert alert-primary d-none" role="alert"><strong>アラート</strong> - バックアップを取得中です・・・</div>
			<ol>
				<li>メニューをドラック&amp;ドロップすると、並べ替えができます。</li>
				<li>メニュー名のリンクをダブルクリックすれば、メニュー名を変更できます。</li>
				<li>メニューをダブルクリックをすると空のサブメニュー用ボックスが作成されるので、そこにメニューをドラッグしてください。</li>
			</ol>
			<div class="sub-close-area">
				<button class="btn-sub-close">全サブメニュー開閉</button>
			</div>
			<ul id="menu" class="side-link">
            	<?php require '../templates/layouts/menu_list.twig' ?>
			</ul>
			<div class="sub-close-area">
				<button class="btn-sub-close">全サブメニュー開閉</button>
			</div>
            <div class="d-flex justify-content-between mb-3">
				<input type="button" value="新規フォルダ作成" class="btn-create" id="create">
				<input type="button" value="設定確定" class="btn-confirm" id="btn-execution">
            </div>
			<!-- <button id="btn-execution">メニュー→フォルダ構成反映</button> -->
			<button id="btn-menu-rebuild">フォルダ構成→メニュー反映</button>
			<!-- <button id="btn-file-copy">ファイルコピー</button> -->

			<ul class="mt-3">
				<li>フォルダ名の頭に「〇〇〇.」の三桁の数字を付けて、上記の「フォルダ構成→メニュー反映」ボタンを押すと、メニューに反映されます。</li>
				<li>並べ替えを実行すると、自動的に「pages_backup」フォルダに並び替え前のファイルのバックアップを取ります。<br>
				また、削除を実行したときも、自動的に「trush」フォルダにバックアップを取ります。<br>
				不要になったバックアップは、順に削除していってください。</li>
			</ul>
    </main>
	<script>
		// メニューを元にフォルダの再生成を実行
		document.querySelector('#btn-execution').addEventListener('click', e=>{
			//フォルダ構成の第一階層のフォルダを配列で取得
			folderArray = [
			<?php foreach(glob('../pages/*') as $item): ?>
				'<?= $item ?>',
			<?php endforeach; ?>
			];

			menu_create();//メニューから配列を作成
			folder_rebuilding(menuStr, 'menu-folder');//フォルダ再生成、menu_list.phpに保存
		});
	</script>
	<script src="../js/admin.js"></script> 
</body>

</html>