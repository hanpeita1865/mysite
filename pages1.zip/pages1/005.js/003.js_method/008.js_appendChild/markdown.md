*[page-title]:要素を挿入 append、appendChild、prepend

参考サイト
: [JavaScriptのappendChildメソッドの使い方を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/20820)
: [https://web-tsuku.life/appendchild-javascript/](appendChild()の使い方とデモ【JavaScript】)
: [ノードを子ノードの中の指定ノードの前または後ろに追加(before,insertBefore,after)](https://www.javadrive.jp/javascript/dom/index21.html)
: [ノードを子ノードの中の先頭または最後に追加(prepend,append,appendChild)](https://www.javadrive.jp/javascript/dom/index20.html#:~:text=%E5%85%88%E9%A0%AD%E3%81%AB%E8%BF%BD%E5%8A%A0%E3%81%99%E3%82%8B%E3%81%AB,appendChild%20%E3%83%A1%E3%82%BD%E3%83%83%E3%83%89%E3%82%92%E4%BD%BF%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)
: [Element.append()](https://developer.mozilla.org/ja/docs/Web/API/Element/append)
: [Element.prepend()](https://developer.mozilla.org/ja/docs/Web/API/Element/prepend)
: [Node.appendChild()](https://developer.mozilla.org/ja/docs/Web/API/Node/appendChild)

## 子要素の最後に挿入appendChild()
appendChildメソッドを使うと、既存のHTMLドキュメントに新しく要素を追加することが出来ます。さらに既存の要素をコピーしたり、HTML要素を新規に追加することも出来ます。

appendChild()は、特定の親ノードの子ノードリストの末尾にノードを追加します。

親要素.appendChild(追加したい要素)という形で使われます。

親要素の末尾に要素が追加されます。
<p class="tmp"><span>書式</span></p>
```
親要素.appendChild(aChild);
```

引数
: aChild ～ 指定された親ノードに追加するノード（ふつうは要素）。

例えばulタグにliタグを追加する場合、下記のようにulタグの末尾に追加されます。
![](upload/appendchild-image.png)

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe width="100%" height="400" src="//jsfiddle.net/hirao/L7n1vk48/4/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

## 子要素の最後に挿入 append()

<p class="tmp"><span>書式</span></p>
```
append(...nodesOrDOMStrings)
```
引数
: nodesOrDOMStrings ～ 挿入する一連の Node または DOMString オブジェクトです。

<hr>

Element.append() メソッドは、一連の Node または DOMString オブジェクトを Element の最後の子の後に挿入します。 DOMString オブジェクトは等価な Text ノードとして挿入されます。

Node.appendChild() との違いは次の通りです。

* Element.append() は DOMString も追加することができますが、<span class="green bold">Node.appendChild() はNode オブジェクトのみを受け付けます</span>。
* Element.append() には返値がありませんが、Node.appendChild() は追加された Node オブジェクトを返します。
* Element.append() は複数のノードや文字列を追加することができますが、Node.appendChild() はノードを 1 つだけしか追加することができせん。

例）  
要素の追加
```
let div = document.createElement("div")
let p = document.createElement("p")
div.append(p)

console.log(div.childNodes) // NodeList [ <p> ]
```

テキストの追加
```
let div = document.createElement("div")
div.append("Some text")

console.log(div.textContent) // "Some text"
```

要素とテキストの追加
```
let div = document.createElement("div")
let p = document.createElement("p")
div.append("Some text", p)

console.log(div.childNodes) // NodeList [ #text "Some text", <p> ]
```

## 子要素の先頭に挿入 prepend()

<p class="tmp"><span>書式</span></p>
```
prepend(...nodesOrDOMStrings);
```
引数
: nodesOrDOMStrings ～ 挿入する一連の Node または DOMString オブジェクトです。

<hr>

Element.prepend() メソッドは、一連の Node または DOMString オブジェクトをこの Element の最初の子の前に挿入します。 DOMString オブジェクトは、同等の Text ノードとして挿入されます。

例）   
要素の前に追加
```
let div = document.createElement("div");
let p = document.createElement("p");
let span = document.createElement("span");
div.append(p);
div.prepend(span);

console.log(div.childNodes); // NodeList [ <span>, <p> ]
```

テキストの前に追加
```
let div = document.createElement("div");
div.append("Some text");
div.prepend("Headline: ");

console.log(div.textContent); // "Headline: Some text"
```

要素とテキストの追加
```
let div = document.createElement("div");
let p = document.createElement("p");
div.prepend("Some text", p);

console.log(div.childNodes); // NodeList [ #text "Some text", <p> ]
```

## 指定した要素の前に追加 insertBefore()

参考サイト
: [【JavaScript入門】要素を追加する方法のまとめ](https://kita-note.com/js-summary-of-how-to-add-elements)
: [insertBefore()の使い方とデモ【JavaScript】](https://web-tsuku.life/insertbefore-add-element/)

ある要素の前に追加するには、次のように指定します。

<p class="tmp"><span>書式</span></p>
```:
親要素.insertBefore(追加する要素, 基準となる要素)
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
	「追加」ボタンを押すと、「child2」要素の前に青の要素が追加されます。
<iframe width="100%" height="400" src="//jsfiddle.net/huuzoo/4c2afr85/6/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">JS</p>
```
function createArea () {
  var area = document.createElement('div');
  area.id = 'blue';
  area.innerHTML = '追加された要素です。';
  var parent = document.getElementById('parent');
  var child2 = document.getElementById('child2');
  parent.insertBefore(area, child2);
}
```

<p class="lang">HTML</p>
```<input type="button" value="追加" onclick="createArea()">
<div id="parent">
  <p id="child1">child1です。</p>
  <p id="child2">child2です。</p>
</div>
```

### 【補足】末尾に要素を追加するには引数にnull
insertBeoforeは「特定の要素の直前に追加」しますが、

<p class="tmp"><span>書式</span></p>
```
親要素.insertBefore(追加したい要素, null)
```
とすることで、親要素の末尾に追加することができます。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe width="100%" height="400" src="//jsfiddle.net/huuzoo/L3jmkg6h/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">JS</p>
```
function createArea () {
  var area = document.createElement('div');
  area.id = 'blue';
  area.innerHTML = '追加された要素です。';
  var parent = document.getElementById('parent');
  var child1 = document.getElementById('child1');
	parent.insertBefore(area, null);
}
```
insertBefore(area, null)とすると、末尾に追加がされます。

### 補足
insertAfter()という関数はないが、insertBefore()を使って次のように記述することで、要素の後ろに追加することができます。
<p class="tmp"><span>書式</span></p>
```
parentElement.insertBefore(newElement, targetElement.nextSibling)
```
targetElement の後ろに newElement を入れたかったらこれで済む。

targetElement がparentElementの最後の子要素（lastChild）だったとしても、
targetElement.nextSibling は null となり、
parentElement.insertBefore(newElement, null) は末尾に追加なので、万事OK。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	「追加」ボタンを押すと、「child1」の後ろに要素が追加されます。
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/doLxah3f/1/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例</span></p>
「削除」ボタンを押すと、子要素は残して親要素のみを削除します。<a href="http://localhost:7001/test/insert/sample1(insertBefore)/" target="_blank">新規タブ</a>
	<iframe width="100%" height="300" src="http://localhost:7001/test/insert/sample1(insertBefore)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

これで、安易に insertAfter() を作らなかったことがわかります。