*[page-title]:ミドルウェアの利用


## ミドルウェアとは?

MVCアーキテクチャーは、モデル·ビュー·コントローラーがそれぞれ切り離されています。プログラムの基本部分はコントローラーですが、コントローラーはそれぞれのアクションごとに処理を用意していきます。これは、個別に処理を作れるという点は良いのですが、「すべてのアクセス時に何か決まった処理を実行したい」というときはけっこう面倒くさいものになってしまいます。

良い例が「ユーザー認証」でしょう。どのページにアクセスしても、ログインしているかどうかをチェックして認証されている場合のみページにアクセスできるようにしたい、ということはよくあります。こんなとき、すべてのページについてユーザー認証の処理を組み込んでいくのは面倒だと思いませんか?

こうしたことを考え、Laravelには「指定のアドレスにリクエストが送られてきたら、自動的に何らかの処理を行う」という仕組みが用意されています。それが「ミドルウェア」です。

> （まとめ）  
> MVCではアクションごとに処理を作れる一方、全ページ共通の処理（例：ユーザー認証）を毎回書くのは面倒です。    
> Laravelでは、リクエスト時に自動で共通処理を行える「ミドルウェア」という仕組みがあり、この問題を解決できます。


### ミドルウェアはアプリケーションの前にあるレイヤー

ミドルウェアとは、リクエストがコントローラーのアクションに届く前(または後)に配置されるレイヤー層となるプログラムです。  
特定のアドレスにアクセスがあると、Laravelはルート情報を元に指定のコントローラーのアクションを呼び出します。ミドルウェアは、その前に割り込んで、アクションの処理が実行される前(あるいは、後)に、指定のミドルウェアの処理を実行させることができます。

ミドルウェアの設定は、ルート情報を記述する際に指定できます。コントローラーのアクションで処理を呼び出しているわけではありません。コントローラーと完全に分離しているため、コントローラーで行っている処理の内容には左右されません。

> （まとめ）  
> ミドルウェアは、リクエスト処理の前後に割り込んで特定の処理を行うプログラムで、ルート設定で指定します。コントローラーとは独立して動作し、その内容に影響されません。

<div markdown="1" class="flex-center">
![](upload/ミドルウェアの説明図.png)
</div>


### ミドルウェアを作成する

ミドルウェアは手作業でも作れますが、Artisanコマンドを使うと簡単です。  
例として「HelloMiddleWare」という名前のミドルウェアを、ターミナルから作成してみます。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:middleware HelloMiddleware
```

![](upload/ミドルウェア作成コマンド実行.png)


### HelloMiddleware.phpを確認する

ミドルウェアは、「Http」内にある「Middleware」というフォルダーの中に作成されます。  
ここにHelloMiddleware.phpというファイルが作成されているのがわかるでしょう。

<p class="tmp list"><span>リスト5-19</span>Http/Middleware/HelloMiddleware.php（デフォルト）</p>
```
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class HelloMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        return $next($request);
    }
}
```

## HelloMiddleware クラス

HelloMiddlewareは継承なしのシンプルなクラスで、app/Http/Middleware に配置されます。  
正しく利用するには namespace の指定が必要です。

### handleメソッドについて

HelloMiddlewareにはhandleメソッドがあり、$request（Requestインスタンス）と$next（クロージャ）が引数として渡されます。  
$nextを呼び出すことで、リクエストを次の処理へ渡せます。
<p class="tmp"><span>書式</span>handleメソッド</p>
```
public function handle($request, Closure $next)
{
	····· 実行する処理 ·····
}
```


## HelloMiddlewareを修正する

では、実際に簡単な処理を作成してみましょう。HelloMiddlewareクラスのソースコードを以下のように修正してください。

<p class="tmp list"><span>リスト5-20</span>HelloMiddleware.php</p>
```
<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class HelloMiddleware
{
  public function handle($request, Closure $next)
  {
    $data = [
      ['name'=>'taro', 'mail'=>'taro@yamada'],
      ['name'=>'hanako', 'mail'=>'hanako@flower'],
      ['name'=>'sachiko', 'mail'=>'sachico@happy'],
    ];
    $request->merge(['data'=>$data]);
    return $next($request);
  }
}
```
mergeメソッドは、リクエストの入力値に新しい値を追加するもので、<span class="bold green">$request->merge(配列) </span>の形で使用します。  
追加した値はコントローラーで $request->data として取得できます。


## ミドルウェアの実行

作成されたミドルウェアは、それだけではまだ利用することはできません。これを使うには、「利用するミドルウェアを呼び出す処理」の追記が必要になります。  
これは、ルーティングの際に実行するのが一般的です。

web.phpを開き、ルート情報にミドルウェアの呼び出し処理を追記しましょう。  
Route:getで/hello のルート情報を設定している文を以下のように変更してください。

<p class="tmp list"><span>リスト5-21</span>web.php</p>
```
// use App\Http\Middleware\HelloMiddleware; を追記

Route::get('hello', [HelloController::class,'index'])
  ->middleware(HelloMiddleware::class);
```

ルート定義（Route::get）のあとに、->middleware() をメソッドチェーンでつなげることで、そのルートにミドルウェアを設定できます。  
引数には使いたいミドルウェアのクラスを指定します。  

->middleware() は連続して書くことができ、次のように複数のミドルウェアを順番に適用できます。

<p class="lang">例）</p>
```
Route::get('/sample', SampleController::class)
    ->middleware(AuthMiddleware::class)
    ->middleware(AdminCheckMiddleware::class);
```


## ビューとコントローラーの修正

/hello で HelloMiddleware が動作するようになったので、ミドルウェアで渡される $data の動作を確認します。  
そのために、まず HelloController の index メソッドを修正します。

<p class="tmp list"><span>リスト5-22</span>HelloController.php</p>
```
public function index(Request $request)
{
  return view('hello.index', ['data'=>$request->data]);
}
```

続いて、テンプレートの修正です。  
index.blade.phpに記述してある@section('content')ディレクティブを以下のように修正しましょう。

<p class="tmp list"><span>リスト5-23</span>hello/index.blade.php</p>
```
@section('content')
  <p>ここが本文のコンテンツです。</p>
  <table>
  @foreach($data as $item)
  <tr>
    <th style="border: solid 1px #aaa; padding:5px 10px;">
      {{$item['name']}}</th>
    <td style="border: solid 1px #aaa; padding:5px 10px;">
      {{$item['mail']}}</td>
  </tr>
  @endforeach
  </table>
@endsection
```

これで、ミドルウェアで追加されたデータが表示されるようになります。  
実際に/helloにアクセスして表示を確認してください。テーブルにデータがまとめられて表示されます。

![](upload/helloでミドルウェア.png){.photo-border}

コントローラーで $request->data を ['data' => $request->data] の形でビューに渡し、テンプレートで @foreach を使って配列を表示しています。  
今回は配列ですが、将来データベースを使う場合も、ミドルウェアで事前に必要なデータを準備すれば、コントローラーの負担を減らせます。


## リクエストとレスポンスの流れ

HelloMiddleware は、リクエスト前の処理だけでなく、アクション実行後の処理も行えます。  
handle メソッドでは $request と $next（クロージャ）が渡され、$next($request) の戻り値は レスポンス(Response) です。  
処理の流れは以下の通りです。

1. クライアントからリクエストが送られる
2. ミドルウェアの handle が呼ばれる
3. $next($request) を実行し、次のミドルウェアまたはコントローラーを呼び出す
4. アクションが終わり、ページがレンダリングされてレスポンスが生成される
5. 生成されたレスポンスが $next の戻り値として返り、クライアントに送信される

<div markdown="1" class="flex-center">
![](upload/ミドルウェア説明図.png)
</div>


### Beforeと After

ミドルウェアは、コントローラーの前処理と後処理の両方を作れます。

#### Before処理（コントローラー実行前）
$next($request) を呼び出す前に必要な処理を行い、その後 $next($request) を return します。
```
public function handle($request, Closure $next) {
    // 前処理
    return $next($request);
}
```

#### After処理（コントローラー実行後）
$next($request) の戻り値（レスポンス）を受け取った後に処理を行い、最後にレスポンスを return します。
```
public function handle($request, Closure $next) {
    $response = $next($request);
    // 後処理
    return $response;
}
```

## レスポンスを操作する

では、先ほどコントローラーの前に実行される例を挙げましたから、今度はコントローラーの呼び出し後に実行されるミドルウェアのサンプルを作ってみることにしましょう。

新たにミドルウェアを作ってもいいのですが、今回は先ほどのHelloMiddleware.phpを書き換えて利用することにします。  
HelloMiddlewareクラスを以下のように修正してください。

<p class="tmp list"><span>リスト5-24</span>HelloMiddleware.php</p>
```
class HelloMiddleware
{
  public function handle($request, Closure $next)
  {
    $response = $next($request);
    $content = $response->content();

    $pattern = '/<middleware>(.*)<\/middleware>/i';
    $replace = '<a href="http://$1">$1</a>';
    $content = preg_replace($pattern, $replace, $content);

    $response->setContent($content);
    return $response;
  }
}
```
ここでは、レスポンスから、クライアントに返送されるコンテンツを取り出し、その一部を置換して返送しています。


### 処理の流れ

handle メソッドで $next($request) を実行すると、コントローラーが動き、返却されたレスポンスが $response に入ります。

1. $response->content() でレスポンスのHTMLソース（テキスト）を取得
2. 正規表現で `<middleware>○○</middleware>` を `<a href="http://○○">○○</a>` に置換
3. $response->setContent($content) で置換後のHTMLをレスポンスに設定
4. return $response でクライアントに返送

この処理により、`<middleware>` タグ内のドメイン名が自動的にリンクへ変換されます。


### ビューとコントローラーの修正

では、この新しいミドルウェアを使ってみましょう。まず、テンプレートの修正です。  
index.blade.phpの@section('content')ディレクティブを以下のように修正しましょう。

<p class="tmp list"><span>リスト5-25</span>hello/index.blade.php</p>
```
@section('content')
   <p>ここが本文のコンテンツです。</p>
   <p>これは、<middleware>google.com</middleware>へのリンクです。</p>
   <p>これは、<middleware>yahoo.co.jp</middleware>へのリンクです。</p>
@endsection
```
今回は、サンプルとして2つの`<middleware>`タグを用意しておきました。google.comとyahoo.co.jpを値に設定してあります。  
後はコントローラーの修正です。  
HelloController クラスのindexアクションメソッドを以下のように変更しておきます。

<p class="tmp list"><span>リスト5-26</span>HelloController.php</p>
```
public function index(Request $request)
{
  return view('hello.index');
}
```

今回、コントローラー側では何も処理はしていません。値も特に設定してはおらず、ほぼデフォルトの状態でページを表示しているだけです。   
では、修正が完了したら/helloにアクセスしてみましょう。すると、`<middleware>`タグの部分が、`<a>`タグのリンクに変更されているのがわかります。  
![](upload/ミドルウェア_グーグル_ヤフー.png){.photo-border}


