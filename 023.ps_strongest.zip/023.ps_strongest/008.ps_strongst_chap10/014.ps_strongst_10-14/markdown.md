*[page-title]:10-14. ブラシで描いた画像にしてみよう

## インク画（外形）フィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-14-1.jpg)](upload/10-14-1.jpg){.image}
</div>


## その他のフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-14-2.jpg)](upload/10-14-2.jpg){.image}
</div>