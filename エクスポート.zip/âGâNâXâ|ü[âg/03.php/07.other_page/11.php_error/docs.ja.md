---
title: エラー表示対処方法
---

## Notice: Trying to access array offset on value of type null in に対処

PHP7.4から、このようなエラーが出るようになりました。
PHPのバージョンアップは仕方ないですが、昔OKな記述が急にエラーになると、修正が必要です。

```
Notice: Trying to access array offset on value of type null in
```
原因は空の配列参照

PHP7.4以降は配列は初期指定しないとエラーになります。

今回のエラーは、以下のソースで発生します。

<iframe src="https://paiza.io/projects/e/xFnQXWqPXgsl6plfu7wV0Q?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

$valueは変数ですが、配列ではありません。  
ただの変数を、配列のように参照すると今回のエラーになります。  

このように記述すればエラーになりません。

<iframe src="https://paiza.io/projects/e/ETEMJ_frV_kKIq5a8kOwww?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

＄value を「array」を使って配列を宣言しておくことでエラーになりません。


・・途中

## 参考サイト

[PHP Notice: Trying to access array offset on value of type null in に対処](https://office-obata.com/report/memorandum/post-5200/)
