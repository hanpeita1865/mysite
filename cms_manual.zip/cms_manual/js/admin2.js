const elem_box = document.getElementById('menu');
const box_items = document.querySelectorAll('#menu li');
// const elem_reset = document.getElementById('reset')
let arrayStart = [];//デフォルトの並び順初期値

//並び順初期値格納
box_items.forEach(function(value){
	arrayStart.push(value.getAttribute('id'));
});

box_items.forEach(elm => {
	//ボックスをダブルクリックして空のボックスを作成
	elm.addEventListener('dblclick', function (e) {
		let subLen = this.children.length;

		if(elm==e.target){//2階層以下の複数実行防止

			//サブメニューの空ボックスを作成
			if(subLen == 1){
				this.insertAdjacentHTML('beforeend','<ul class="emp-ul sub-menu"></ul>');
				obj = this.lastChild;//サブメニューul要素
				
			}else {
				//サブメニュー開閉
				this.children[1].classList.toggle('d-none');
				this.closest('li').classList.toggle('close');
			}
		}
	})

	sortDrop(elm);
});

//ボックス並べ替え
function sortDrop(elm){
	elm.ondragstart = function (e) {
		e.dataTransfer.setData('text/plain', e.target.id);
	};

	let empBox=1; 

	//ドラッグオーバー
	elm.ondragover = function (e) {
		e.preventDefault();

		if(elm==e.target.parentNode || elm==e.target){

			if(e.target.classList.contains('emp-ul')){
				e.stopPropagation(); //イベントを停止する
				e.preventDefault(); //画面遷移を行わない
				e.target.style.border='4px solid green';
				empBox = e.target;

			}else if(e.target.closest('li').classList.contains('box-item')){	
				let rect = e.target.closest('li').getBoundingClientRect();
				let elm_over = this
	
				//rectOver(e,rect,elm_over);//ボーダー表示
	
			}else{
				let rect = e.target.getBoundingClientRect();
				let elm_over = e.target;
	
				//rectOver(e,rect,elm_over);//ボーダー表示
			}
		}
	};
}

//ドロップ上下判定
function rectDrop(e,t,rect,elm_drag){
	if ((e.clientY - rect.top) < (rect.height / 2)) {
		//マウスカーソルの位置が要素の半分より上
		t.parentNode.insertBefore(elm_drag, t);
	} else {
		//マウスカーソルの位置が要素の半分より下
		t.parentNode.insertBefore(elm_drag, t.nextElementSibling);
	}
}