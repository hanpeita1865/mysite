const title_link = document.querySelectorAll('.news-box a.title-link');
const news_tag = document.querySelectorAll('.news-box .cate-tag');
const tab_box = document.querySelectorAll('.tab-box li button');
const news_list = document.querySelectorAll('.news-box li');

//リンクパス修正
title_link.forEach(function (elm) {
    let href = elm.getAttribute('href');
    //hrefが空のaはリンクを取る
    if (href == '') {
        let inner = elm.innerHTML;
        elm.replaceWith(inner);
    }

    //外部リンクには、「target="_blank"」を付け、ページ遷移リンクには、iframe親要素に表示させる「target="_parent"」を使用。
    if (/^http|^https/.test(href)) {
        elm.setAttribute('target', '_blank');
    } else {
        elm.setAttribute('target', '_parent');
    }
})

//タブクリックで記事表示切り替え
tab_box.forEach(function (elm) {
    elm.addEventListener('click', function (e) {
        //タブアクティブ化
        tab_box.forEach(function (s) {
            s.closest('button').classList.remove('active');
        })

        e.target.closest('button').classList.add('active');

        //記事の表示切り替え
        news_tag.forEach(function (t) {
            if(e.target.textContent=='すべて'){
                t.closest('.news-box li').classList.remove('d-none');
            }else if(t.getAttribute('data-category') != e.target.textContent) {
                t.closest('.news-box li').classList.add('d-none');
            }else{
                t.closest('.news-box li').classList.remove('d-none');
            }
        })
    });
});

//重要なお知らせ　0件時非表示

const imp_list = document.querySelectorAll('#imp-list li');

console.log(imp_list.length)

if(imp_list.length==0){
    document.querySelector('.frame-box1').classList.add('d-none');
}