Vue.createApp({
  data() {
    return {
      message: '皆さん、こんにちは！'
    };
  }
}).mount('#app');