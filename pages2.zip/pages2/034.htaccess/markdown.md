*[page-title]:htaccess

## PHPをHTMLファイルで動かす

参考サイト
: [【.htaccess】HTMLファイルでPHPを動かす方法](https://webwork-plus.com/content/website/htaccess-php.html)
: [.htaccessとは SEOにおける活用方法やディレクトリへの有効範囲について](https://www.seohacks.net/blog/986/)

通常、ファイル拡張子が「.html」となる「HTMLファイル」では、PHPを動かすことはできません。  
ですが、「.htaccessファイル」の設定によっては、HTMLファイルでもPHPを使う事が出来るようになります。

HTMLファイルでPHPを動かす「.htaccessファイル」の書き方には、いくつか種類があります。

### HTMLでPHPを動かす書き方１ AddHandler

「.htaccessファイル」に以下を記述します。

<p class="tmp">.htaccess</p>
```
#HTMLファイルでPHPを動かす
 <FilesMatch "\.html$">
AddHandler php7-script .html
 </FilesMatch>
```
「AddHandler」はファイルの動作設定をする書き方です。  
ここでは拡張子が「.html」のファイルを、PHPとして動作するように指定しています。  
この書き方は、「php7」の部分で動作させるPHPバージョンを指定します。  
サーバーで未対応のバージョンを記述すると動かないので、お使いのサーバーの対応バージョンに合わせておきましょう。  
例えばPHP5を使う場合には、「AddHandler php7-script .html」の「php7」の部分を「php5」と記述します。

***XAMPPで動作確認済***

下記のページにアクセスすると、HTMLファイルのPHPコードが表示されるのが確認できます。

<a href="upload/html_php/" target="_blank">htmlファイルをPHPでの動作確認ページ</a>
<p class="tmp">HTMLファイル index.html</p>
```
<?php
echo 'PHPで作成';
?>
```


### HTMLでPHPを動かす書き方２ AddType

<p class="tmp">.htaccess</p>
```
#HTMLでPHPを動かす２
 <FilesMatch "\.html$">
AddType application/x-httpd-php .html
 </FilesMatch>
```
「AddType」は、ファイルのMIMEタイプ（ファイル形式などの情報）を設定します。  
この指定では「.html」ファイルにPHPのMIMEタイプを設定しているので、サーバーは「php」ファイルとして認識して、PHPプログラムを動かす事ができます。

***XAMPPで動作確認済***

### HTMLでPHPを動かす書き方３　fcgid-script
こちらは最初の書き方「AddHandler」を使いますが、内容が違います。

<p class="tmp">.htaccess</p>
```
#HTMLでPHPを動かす３
 <FilesMatch "\.html$">
AddHandler fcgid-script .html
 </FilesMatch>
```

<span class="blue bold">※XAMPPではうまく動きませんでした。</span>

## URLからindex.htmlを削除
下記は、リダイレクトでindex.htmlをURLから削除する例です。
```
RewriteEngine on
RewriteCond %{THE_REQUEST} ^.*/index.html

RewriteRule ^(.*)index.html$ https://■■.com/$1 [L,R=301]
```

## 参考サイト

[.htaccessのリダイレクト – 書き方・設置場所・設定方法を解説します](https://gc-seo.jp/journal/how-to-redirect/)
