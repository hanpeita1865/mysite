// export const ModalManager = (() => {
    
export function initModals() {
    //初期化
    create('soatWarn');
    create('successModal');
    create('fdDelModal');
    create('lockModal');
    create('fdCreateModal');
    create('fdChangeModal');
    create('folderModal');
    create('draftModal');
}

const modals = {};

function create(id) {
    const el = document.getElementById(id);

    if (!el || typeof bootstrap === 'undefined') {
        return null;
    }

    const modal = new bootstrap.Modal(el);
    modals[id] = modal;   

    return modal;
}

export function get(id) {
    
    return modals[id] ?? null;
}

export function show(id) {
    const modal = get(id);
    
    if (modal) modal.show();
}

export function hide(id) {
    const modal = get(id);
    if (modal) modal.hide();
}

export function exists(id) {
    return !!get(id);
}
