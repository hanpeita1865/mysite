*[page-title]:Chap7 Vue CLI

<div markdown="1" class="page-mokuji auto-mokuji"></div>


サンプル
: <http://localhost:7008/chap03/ファイル名>

下書き
: 「<span class="green bold">C:\xampp\htdocs\from_now\trunk\pages\p__veu_3_chap3\files</span>」内　<span class="red bold">chap3_下書き.rtf </span>


属性やスタイルの操作、条件分岐、繰り返し処理など、より複雑な機能を組み込みたい場合は、<span class="red bold">ディレクティブ</span>を利用します。  
Vue.js のテンプレートを学ぶことは、ディレクティブを学ぶこと、と言い換えてもよいでしょう。それだけ膨大な機能が、ここに集約されています。  
ディレクティプは、「<span class="red bold">v-×××</span>」から始まる属性(構文)として表すのが基本です。

Vue.js では、HTML をベースとしたテンプレート構文を採用しています。標準的な HTML に対して、 ディレクティブと呼ばれる属性形式の命令を付与することで、ページに機能を付与しているのです。ディ レクティブは「<span class="red bold">v-</span>」で始まるのが基本です。

ディレクティブは、用途に応じて、以下のように分類できます。
![](upload/ディレクティブの分類.png)
データバインド関連の基本的なディレクティブについては、前章でも既に触れているので、本章では 残るディレクティブについて、順に解説していきます。

