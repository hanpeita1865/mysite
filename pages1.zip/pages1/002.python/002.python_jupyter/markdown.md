*[page-title]:Jupyter Notebookの使い方

1. Anacondaを起動し、jupyter notebookのボックスの「lunch」ボタンをクリックしてjupyter notebookを開きます。
![](upload/anacondaからjupyterを開く.png)
2. デフォルトでは、y-hirのディレクトリが開かれます。とりあえずそこにPythonShizaiフォルダを格納しています。
![](upload/フォルダ選択画面.png)
3. ファイルがあるディレクトリを開き、～.ipynbファイルを開きます。
![](upload/ipynbファイルを開く.png)
4. ～.ipynbファイルのコードが表示されました。
![](upload/ipynbファイルのコード表示.png)

## ノートブックにプログラムを入力して実行する
ノートブックには次のように「In」と表示されて右側にテキストボックスが表示されます。このテキストボックスのことをセル(Cell)と呼びます。プログラムはセルに記述します。

![](upload/新規作成1.png)

それでは簡単なプログラムを入力してください。

プログラムを実行するには Shift ＋ Enter キーを押してくださいです。プログラムが実行されて結果が表示されます。
![](upload/新規作成2.png)

同じセルの中で改行を行うには Enter キーを押してください。
![](upload/新規作成3.png)

![](upload/新規作成4.png)
```
mylist = ["Orange", "Peach", "Lemon"]
for val in mylist:
    print(val)
```

Shift ＋ Enter キーを押してプログラムを実行します。
![](upload/新規作成5.png)

## ノートブックを名前を付けて保存する

ノートブックを保存すると、セルに入力したプログラムやその実行結果を保存することができます。「File」をクリックし、表示されたメニューの中から「Save as」をクリックしてください。

![](upload/新規作成6.png)

ダイアログが表示されますので、保存するノートブックの名前を入力してください。入力が終わりましたら「Save」をクリックしてください。

![](upload/新規作成7.png)

ノートブックの保存が完了しました。  
ノートブックは拡張子 「<span class="green bold">.pynb</span>」 のファイルとして保存されます。
![](upload/新規作成8.png)

※デフォルトでは、「C:\Users\y-hir」に保存されます。

## ノートブックを閉じる
ノートブックを閉じるには「File」をクリックし、表示されたメニューの中から「Close and Halt」をクリックしてください。

![](upload/新規作成9.png)

## 保存したノートブックを開く
ブラウザで Notebook ダッシュボードを表示すると、カレントディレクトリに含まれるファイルの一覧が表示されます。
![](upload/ファイルを開く1.png)

表示されているファイルの中で拡張子が .pynb のファイルがノートブックが保存されたファイルです。保存したノートブックを開くには、開きたいノートブックのファイルをクリックしてください。



## 参考サイト

* [ノートブックの作成とPythonプログラムの実行](https://www.javadrive.jp/python/jupyter-notebook/index3.html)
