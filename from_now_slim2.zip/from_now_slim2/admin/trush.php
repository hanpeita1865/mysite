<?php
$res = glob('../pages_copy' . '/*'); 
date_default_timezone_set('Asia/Tokyo');//日本時間にセット
$dateTime = date('Y-m-d_H.i.s');


foreach ($res as $item) {
    mkdir('../trush/'.$dateTime);//削除日時フォルダ
    $itemRe = str_replace('pages_copy', 'trush'.'/'.$dateTime, $item);

    if (rename($item, $itemRe)) {
        //移動しました。
    }
}

?>