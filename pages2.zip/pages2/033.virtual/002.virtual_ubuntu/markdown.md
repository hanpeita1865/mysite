*[page-title]:Ubuntu

参考サイト
: [Ubuntuとは？｜たった3分で分かる｜特徴やできることをわかりやすく解説](https://techmania.jp/blog/linux0002/)
: [コマンドでApacheのhttpdを起動と停止と再起動する方法](https://kaworu.jpn.org/ubuntu/%E3%82%B3%E3%83%9E%E3%83%B3%E3%83%89%E3%81%A7Apache%E3%81%AEhttpd%E3%82%92%E8%B5%B7%E5%8B%95%E3%81%A8%E5%81%9C%E6%AD%A2%E3%81%A8%E5%86%8D%E8%B5%B7%E5%8B%95%E3%81%99%E3%82%8B%E6%96%B9%E6%B3%95)
: [Ubuntu 20.04, 18.04 仮想マシンを作る（VirtualBox, Vagrant を使用）（Windows 上，Ubuntu 上）](https://www.kkaneko.jp/tools/virtualbox/vagrant.html#S2)


作成ファルダ
: C:\Users\y-hir\Workdir\SocymSlimVM3


## Ubuntuを設置

※vagrantとvirtual boxはインストール済みからの設置方法です。

任意のディレクトリを作成して、そのディレクトリに移動し、Vagrantfile のダウンロードをします、
CentOSと同じように、Vagrantfileが任意のディレクトリに作成されます。
```
vagrant init ubuntu/xenial64
```
![](upload/ubuntu1.png)


```
vagrant up
```
![](upload/ubuntu2.png)
･･･
![](upload/ubuntu2-2.png)


sshして仮想マシンに入ります。
```
vagrant ssh
```

![](upload/ubuntu3.png)

利用後は仮想マシンを削除、もしくはシャットダウンします。

```
vagrant destroy
```

```
vagrant halt
```

アパッチのインストール
<https://kaworu.jpn.org/ubuntu/Apache%E3%82%92%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB%E3%81%99%E3%82%8B>
```
sudo apt install apache2
```
![](upload/ubuntu4.png)
・・・・・
![](upload/ubuntu4-2.png)

/etc/apache2 のディレクトリに設定ファイルが置かれます。

Apache の起動は、以下のコマンドのどちらかで実行できます。
```
sudo service apache2 start
sudo apachectl star
```
