select * from product where name='カシューナッツ';
