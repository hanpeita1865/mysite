<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>更新完了</title>
</head>
<body>
<?php
session_start();

//トークンが存在しないか、セッションのトークンと送信されたトークンの値が一致しない場合は、処理停止。
if (!isset($_POST["token"]) || $_POST["token"] != $_SESSION['token']) {
  echo "<p>不正なリクエストです</p>";
  echo '<p><a href="index.php">一覧に戻る</a></p>';
  exit();
}

$pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
$sql=$pdo->prepare('update products set name=:name, local=:local, price=:price where id=:id');

$id = $_POST['id'];
$name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
$local = htmlspecialchars($_POST['local'], ENT_QUOTES, 'UTF-8');
$price = htmlspecialchars($_POST['price'], ENT_QUOTES, 'UTF-8');

//一時的保存にファイルがあるか確認
if (empty($_FILES['image']['tmp_name'])){
    $imgpath = '';
}else{
    $imgpath = $_FILES['image']['name'];        
}

//セッション登録（name,local,price）
require 'set-session.php';

$sql->bindValue(':id', $id);
$sql->bindValue(':name', $name);
$sql->bindValue(':local', $local);
$sql->bindValue(':price', $price);

//バリデーション
require 'validation.php';
$errors = validation($_POST, $imgpath);

if(!empty($errors)){
    //エラーがある
    $_SESSION['flash']['message'] = $errors;
    header('Location:update-input.php?id='.$id);//入力画面に戻る
    exit();

} elseif ($sql->execute()) {
    //新規登録に成功　セッション削除
    require 'delete-session.php';

    $_SESSION['flash']['success'] = '「'.$_POST['name'].'」を更新しました。';

	//更新に成功 リダイレクト
    header('Location:index.php');
    exit();

} else {
    //編集更新に失敗
    $_SESSION['flash']['message'] = '更新に失敗しました。';
    header('Location:update-input.php');//入力画面に戻る
    exit();
}
?>
</body>
</html>
