*[page-title]:まとめノート設定・使用方法

## データベース設置

XamppのMariaDBを開いて、SQLタブをクリックし、入力欄に下記のコードを貼り付けて実行して下さい。

<p class="tmp sql"><span>SQL文</span>データベース作成</p>
```
create database from_now default character set utf8 collate utf8_general_ci;
grant all on from_now.* to 'staff'@'localhost' identified by 'password';
use from_now;
```

黄色の箇所は、自分のIPアドレスに書き換えてから実行してください。
<p class="tmp sql"><span>SQL文</span>テーブル作成</p>
<pre><code class="hljs sql"><span class="hljs-keyword">CREATE</span> <span class="hljs-keyword">TABLE</span> <span class="hljs-string">`admin_ip`</span> (
  <span class="hljs-string">`id_admin`</span> <span class="hljs-built_in">int</span>(<span class="hljs-number">30</span>) <span class="hljs-keyword">NOT</span> <span class="hljs-literal">NULL</span> AUTO_INCREMENT,
  <span class="hljs-string">`ip_address`</span> <span class="hljs-built_in">varchar</span>(<span class="hljs-number">30</span>) <span class="hljs-keyword">NOT</span> <span class="hljs-literal">NULL</span>,
  PRIMARY <span class="hljs-keyword">KEY</span> (<span class="hljs-string">`id_admin`</span>)
);


<span class="hljs-keyword">CREATE</span> <span class="hljs-keyword">TABLE</span> <span class="hljs-string">`locklist`</span> (
  <span class="hljs-string">`id_lock`</span> <span class="hljs-built_in">int</span>(<span class="hljs-number">30</span>) <span class="hljs-keyword">NOT</span> <span class="hljs-literal">NULL</span> AUTO_INCREMENT,
  <span class="hljs-string">`page`</span> <span class="hljs-built_in">varchar</span>(<span class="hljs-number">30</span>) <span class="hljs-keyword">NOT</span> <span class="hljs-literal">NULL</span>,
  <span class="hljs-string">`under_dir`</span> <span class="hljs-built_in">varchar</span>(<span class="hljs-number">30</span>) <span class="hljs-keyword">NOT</span> <span class="hljs-literal">NULL</span>,
  PRIMARY <span class="hljs-keyword">KEY</span> (<span class="hljs-string">`id_lock`</span>)
);


<span class="hljs-keyword">INSERT</span> <span class="hljs-keyword">INTO</span> <span class="hljs-string">`admin_ip`</span> (<span class="hljs-string">`id_admin`</span>, <span class="hljs-string">`ip_address`</span>) <span class="hljs-keyword">VALUES</span> (<span class="hljs-literal">NULL</span>, <span class="hljs-string">'::1'</span>), (<span class="hljs-literal">NULL</span>, <span class="hljs-string">'<span class="marker-yellow">10.000.00.00</span>'</span>);</code></pre>

次のように「admin_ip」テーブルが作成されます。ここに記録したIPアドレスの人だけ管理画面を操作したり、ページを編集できます。
![](upload/admin_ipテーブル.png){.photo-border}

「locklist」テーブルは、自分以外の人には見せくないページを記録します。


次は、本体のファイルをhtdocsに格納します。  
管理画面は「～/from_now_slim/public/admin」にアクセスし、サイトの方は、「～/from_now_slim/public/pages/guide/」にアクセスすると表示できます。

IPアドレスが、10.150.42.36の場合
```
//管理画面
http://10.150.42.36/from_now_slim/public/admin

//サイト（ガイドページ）
http://10.150.42.36/from_now_slim/public/pages/guide/
```


## ページ作成

### 新規ページ作成

管理画面を開いて、左下部にある「新規フォルダ作成」ボタンをクリックします。
![](upload/新規フォルダ作成ボタン.png){.photo-border}

新規フォルダのフォルダ名を記入するダイアログが表示されます。
![](upload/新規フォルダ作成プロンプト.png){.photo-border}

入力して「新規登録」ボタンを押すと、新しいメニューが作成されます。（メニューの名前はデフォルトでは、「メニュー名」」」になっています）
![](upload/testpageフォルダ作成完了.png){.photo-border}

次にメニューの名前を変更します。メニュー名のリンクをクリックしてください。
![](upload/メニュー名のリンクをクリック.png){.photo-border}

メニュー名変更のダイアログが表示されるので、新しい名前を入力して「ok」ボタンを押します。
![](upload/メニュー名変更.png){.photo-border}

入力した名前にメニュー名が変わりました。
![](upload/テストページ名に変更完了.png){.photo-border}


### メニュー並べ替え

現状では、サイトを開くとサイドメニューの一番下に新規作成したメニューが表示されています。
![](upload/メニュー名一番下に表示.png){.photo-border}

これを管理画面のメニューをドラッグして移動して並べ替えを行います。
![](upload/メニュー名をドラッグして移動.png)

または、他のメニューの配下に移動したい場合は、親になるメニューをダブルクリックして子のメニュー表示させてからドラッグで移動します。
![](upload/コマンド配下に移動.png){.photo-border}

これで「並べ替え確定」ボタンを押すと、並べ替え確認のメッセージが表示されるので「ok」をクリックします。
![](upload/並べ替えを確定していいですか.png){.photo-border}

数秒してから、並べ替え完了のメッセージが表示されます。
![](upload/並べ替えが完了しました.png){.photo-border}

サイトを更新すると、サイドメニューの並びが変わっているのが確認できると思います。並べ替えは複数の移動をまとめて行えます。
![](upload/メニューのテストページ表示確認.png){.photo-border}

※メニューの並び替えを行っているときは、他の操作はしないでください。  
※まれにメニューの順番が一部ちゃんと変わっていない場合もあるので、そのときは再度「並べ替え確定」ボタンを押してください。


## 閲覧制限設定

メニューの右側の「ロック設定」ボタンをクリックします。
![](upload/ロック設定ボタン単独.png){.photo-border}

ダイアログが表示されるので、「ロック設定」をクリックします。
![](upload/ロック設定単独.png){.photo-border}

設定が完了すると、管理画面の対象のメニューに鍵マークが付きます。
![](upload/管理画面テストページ鍵マーク.png){.photo-border}

サイトの方も更新すると、鍵マークが付いてるのが確認できると思います。
![](upload/サイトのメニューに鍵マーク.png){.photo-border}

これで他の人がサイトを開いたときに、その鍵マークがついたメニューは表示されなくなり、そのページへのアクセスは不可になります。


## ページの編集

サイトページの右上の「編集」ボタンをクリックすると、下記のような編集画面が表示されます。  
テキスト入力欄には、マークダウンで記入します。  
![](upload/編集画面フルサイズ.png "図　編集画面"){.photo-border}


画像やファイルは、編集画面下部にある点線枠の中にファイルをドラッグするか、枠内をクリックして選択します。  
そうすると保存されて、次のように保存ファイル一覧に表示されます。
![](upload/保存画像一覧.png "図　保存ファイル一覧"){.photo-border}

テキスト入力欄に挿入したい箇所にカーソルを持っていき、「挿入」ボタンを押すと、マークダウン形式の画像やファイル用のコードが挿入されます。
```
![](upload/ロック設定単独.png)
```
![](upload/ロック設定単独.png "図　枠なしの画像")
画像に枠を付けたいときは、コードの最後にカーソルを持っていき、ツールバーにある![](upload/枠設置アイコン.png){.figure-none}をクリックします。そうすると、「photo-border」というクラスが設定され画像に枠が付きます。
```
![](upload/ロック設定単独.png){.photo-border}
```
![](upload/ロック設定単独.png "図　枠ありの画像"){.photo-border}

キャプションを設置するときは、次のように半角開けて「"～"」を記入します。
```
![](upload/ロック設定単独.png "図　枠ありの画像"){.photo-border}
```

マークダウンについては、次ページの「マークダウン記述例」と「マークダウン記法（基本）」を参照してください。  

リストや定義リストやテーブルやコードの挿入などをよく使います。
<p class="tmp list"><span>リスト</span>マークダウン（リスト）</p>
```
* これはダミーです。
* これはダミーです。
* これはダミーです。

1. これはダミーです。
1. これはダミーです。
1. これはダミーです。
```
<p class="result"><span>表示結果</span></p>
* これはダミーです。
* これはダミーです。
* これはダミーです。

1. これはダミーです。
1. これはダミーです。
1. これはダミーです。

<p class="tmp list mt-5"><span>リスト</span>マークダウン（定義リスト）</p>
```
参考サイト
: [e.targetの扱いには注意しよう](https://qiita.com/sasurai_usagi3/items/45d61fd08cdf7cff57fa)
: [【JavaScript】無名関数とアロー関数とイベントリスナーのthis](https://laboradian.com/js-anon-func-arrow-func/)
```
<p class="result"><span>表示結果</span></p>
参考サイト
: [e.targetの扱いには注意しよう](https://qiita.com/sasurai_usagi3/items/45d61fd08cdf7cff57fa)
: [【JavaScript】無名関数とアロー関数とイベントリスナーのthis](https://laboradian.com/js-anon-func-arrow-func/)


<p class="tmp list mt-5"><span>リスト</span>マークダウン（テーブル）</p>
```
|修飾子	|用途	|
|--|--|
|public|	クラス外、クラス内どちらもアクセス化|
|private|	クラス内のみアクセス化|
|protected|	クラス内と継承先のみアクセス化|
```

<p class="result"><span>表示結果</span></p>
|修飾子	|用途	|
|--|--|
|public|	クラス外、クラス内どちらもアクセス化|
|private|	クラス内のみアクセス化|
|protected|	クラス内と継承先のみアクセス化|


コードの挿入するとは、バッククオート3つを使用してコードを上下ではさむとpreタグが付き、シンタックスハイライトが適用されます。  
また、文字列内にコードを挿入するときは、バッククォート1つをコードの前後に付けます。


テキストの入力を元に戻したいときは、カーソルが入力欄にある状態で「CTRL+Z」を押し、やり直したいときは「CTRL+Y」を押してください。

編集したテキストを保存するときは、「編集更新」ボタンをクリックするか、「CTRL+S」を押します。

<div markdown="1" class="memo-box">
作成したページは、<span class="bold red">pages</span>フォルダに保存されます。  
バックアップを取りたいときは、このpagesフォルダを別の場所に保存すればいいです。
</div>

