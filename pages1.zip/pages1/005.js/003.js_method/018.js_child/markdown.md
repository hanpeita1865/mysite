*[page-title]:子要素、親要素、前後の要素を取得

参考サイト
: [特定のHTML要素の子要素、親要素、前後の要素を取得する](https://gray-code.com/javascript/get-child-element-and-paranet-element-and-previous-element-and-next-element-of-specific-html-element/)
: [子要素（子ノード）の取得](https://shanabrian.com/web/javascript/element-children.php)
: [ノードの子・親・兄弟ノードを取得](https://www.javadrive.jp/javascript/dom/index4.html)

## 子要素（子ノード）の取得

子要素（子ノード）を取得するにはelement<span class="green bold">.children</span>プロパティを使用します。

<p class="tmp"><span>書式</span>子要素</p>
```
element.children;
```

戻り値
: HTMLCollectionを返し、存在しない場合は0個のHTMLCollectionを返します。

<p class="tmp"><span>書式</span>最初の子要素</p>
```
element.firstElementChild
```

<p class="tmp"><span>書式</span>最後の子要素</p>
```
element.lastElementChild
```

## 前の要素（ノード）の取得

参考サイト
: [前の兄弟要素を取得](https://shanabrian.com/web/javascript/previoussibling.php)

ある特定の要素の最初の子要素を取得するには、<span class="blue bold">node.previousSibling</span>プロパティを使用します。  
このプロパティは、テキストノードが含まれている場合、テキストノードを取得します。  
エレメントノードのみを取得する場合は、<span class="green bold">node.previousElementSibling</span>プロパティを使用します。


<p class="tmp">テキストノードを含む</p>
```
let siblingNode = node.previousSibling;
```

<p class="tmp">テキストノードを含まない</p>
```
let siblingNode = node.previousElementSibling;
```

戻り値
: 見つかった場合はその要素、見つからなかった場合はnullを返します。