---
title: '12. 一致した要素を順番に処理<br>（each）'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .smp-box {
        margin: 2rem 0 3rem;
    }
    .smp {
        display: inline-block;
        margin-top: 2rem;
        margin-bottom: 0;
        background: #bc495b;
        color: #fff;
        font-size: .75rem;
        font-weight: bold;
        letter-spacing: .3rem;
        padding: .2rem .5rem;
    }
    .tmp {
        background: #026ca2;
        color: #fff;
        font-size: .87rem;
        letter-spacing: .3rem;
        padding: .2rem 1rem;
        white-space: nowrap;
    }
    .dcn {
     	font-weight: bold;   
    }
    .exp {
     	border-bottom: 3px solid #14ff00;
        font-weight: bold;
        font-size: 2rem;
    }
</style>
## eachメソッド

eachメソッドは、HTML要素・配列・オブジェクトなどに対して繰り返し処理を行うことができるメソッドになります。<br>
for文のようにカウントを取ることはせずに、指定したセレクタの数だけループしてくれます。

<p class="mb-05"><span class="tmp">書式1</span>　HTML要素に対して繰り返し処理を行う</p>

<pre>
	$('セレクタ').each(function() {
        //繰り返し処理を記述する
    }) 
     
    または、
    
	$('セレクタ').each(function(index, element) {
        //繰り返し処理を記述する
    })
</pre>

※eachに指定する関数は引数として、「index（各要素のインデックス番号）」「element（繰り返し処理中の要素）」を取得できます。

<p><span class="smp">例1</span>　リストからテキストを順番に取得して、コンソールに表示させます。
<iframe id="exp-1" width="100%" height="300" src="//jsfiddle.net/5uvzkesc/6/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</p>

<p><span class="smp">例2</span>　引数を使用
<iframe id="exp-1" width="100%" height="300" src="//jsfiddle.net/r5ec0n3v/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</p>

<h2 class="h-type2">配列やオブジェクトでの使用</h2>

<p><span class="smp">例3</span>　配列を繰り返し処理
<iframe id="exp-1" width="100%" height="300" src="//jsfiddle.net/qv3x5mwe/3/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</p>

<p><span class="smp">例4</span>　オブジェクトを繰り返し処理
<iframe id="exp-1" width="100%" height="300" src="//jsfiddle.net/6qoy7m8j/7/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</p>



<h2 class="h-type2">繰り返し処理をスキップ</h2>

<strong>return true</strong>　を記入すると繰り返し処理をスキップできます。<br>
※「continue」は使えません。

<p><span class="smp">例5</span>
<iframe id="exp-1" width="100%" height="400" src="//jsfiddle.net/wb75zapL/2/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</p>


<h2 class="h-type2">繰り返し処理を中断</h2>

<strong>return false</strong>　を記入すると繰り返し処理を中断できます。<br>
※breakは使えません。

<p><span class="smp">例6</span>
<iframe id="exp-1" width="100%" height="400" src="//jsfiddle.net/r5c1tqwj/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</p>

###サンプル
 [03. フィルタリング](../../../jquery-foundation/jquery-foundation-12 "03. フィルタリング") のページに移動してください。
