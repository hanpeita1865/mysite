---
title: '26. ユーザー認証'
taxonomy:
    category:
        - docs
media_order: 'auth_table_5.png,password_resets.png,users_table.png,auth_login.png,auth_input.png,auth_login_in.png,auth_page.png,auth_home.png'
---

* [認証機能とAuth](#p1)
* [データベースの準備](#p2)
* [/helloでログインをチェックする](#p3)
* [Authの認証関係ページ](#p4)
* [特定ページの保護](#p5)
* [ログイン処理の実装](#p6)


ログインしないと使えないようなサービスの開発に不可欠なのが、ユーザー認証機能です。Laravelに標準装備されている認証機能「Auth」の使い方について説明しましょう。

## 認証機能とAuth ##{#p1}
個々のユーザーに対してサービスを提供するようなWebアプリケーションでは、どうやって各ユーザーを識別し、対処するかは重要です。例えば掲示板のようなものからオンラインショッピングのようなものまで、ユーザーごとに情報を管理し、処理するサービスは多数あります。  
こうしたWebアプリケーションでは、ユーザーを登録し、ログインしてから操作を行うように設計するのが一般的です。このようなユーザーのログインに関する処理を行うのが、「ユーザー認証」と一般に呼ばれる機能です。 ユーザー認証は、ざっと以下のような機能を提供します。

* ユーザーの登録
* ユーザーのログインとログアウト
* ユーザー情報の管理などを行うホーム画面
* ログインしていないユーザーのアクセスを制限するアクセス制限
* 現在のユーザーのログイン状態などをプログラム内から調べるための各種機能

こうした機能を一から開発していくのはかなり大変です。Laravelでは、標準で認証機能を持っており、簡単に実装することができます。これは「Auth」というクラスで、サー ビスプロバイダやファサードなど多数のプログラムで構成されています。このAuth機能の基本的な使い方がわかれば、ユーザー登録型のWebアプリケーションの開発が可能になります。

## データベースの準備 ##{#p2}
Authでは、ユーザー情報をデータベースで管理します。したがって、Authを利用するにはまずデータベースの準備が必要です。  
データベースにAuthが利用するためのテーブルを作成します。これは、実はartisanのコマンドで簡単に作成できます。コマンドプロンプトまたはターミナルから以下のように実行して下さい。

### バージョン5系以前の場合

<p class="tmp cmd"><span>コマンド1</span>バージョン5系まで</p>
```
php artisan make:auth
```
成功すると、「Authentication scaffolding generated successfully.」と表示されます。  
これで、Auth利用のためのマイグレーションファイルが生成されます。そのままマイ グレーションを実行して、テーブルを生成します。

<p class="tmp cmd"><span>コマンド2</span>バージョン5系まで</p>
```
php artisan migrate
```
マイグレーションが成功すると、以下のように表示され、
![](auth_table_5.png)

password_resetsとusersの２つのテーブルが作成されます。

![](password_resets.png?classes=caption "図1　password_resetsテーブル")

![](users_table.png?classes=caption "図2　usersテーブル")



実行済みの場合は、Nothing to migrateと 表示されます。

おそらく、artisan migrateを実行しても「Nothing to migrate」と表示された人もいるかもしれません。後述しますが、Authでは「user」と「password_reset」というテーブルを利用します。これは、プロジェクトを作成した際にマイグレーションファイルが作成されており、これまでマイグレーションした際に、実行済みになっているでしょう。その場合は、既にテーブルはできていますので、そのままにしておいて構いません。


### バージョン6系以降の場合

Laravel6系から認証機能（Laravel/ui）が別パッケージとして管理されるようになりました。そのためまずはcomposerでパッケージをインストールしましょう。

<p class="tmp cmd"><span>コマンド3</span>バージョン6系以降</p>
```
composer require laravel/ui
```

<p class="tmp cmd"><span>コマンド4</span>コンテナ内で php artisanコマンドを実行</p>
```
php artisan ui vue --auth
```
これで、データベースにテーブルが作成されます。

### user テーブルについて
「database」内の「migration」フォルダには、「xxxx_create_user_table.php」(xxxxは任意の日時)というマイグレーションファイルが作成されています。これが、Authによる認 証データを保管するテーブルを生成するためのものです。 このファイルの中を見ると、以下のようになっています(コメント類は省略)。

<p class="tmp list"><span>リスト1</span>xxxx_create_user_table.php</p>
```
<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
   public function up()
   {
       Schema::create('users', function (Blueprint $table) {
           $table->increments('id');
           $table->string('name');
           $table->string('email')->unique();
           $table->string('password');
           $table->rememberToken();
           $table->timestamps();
       });
   }

   public function down()
   {
       Schema::dropIfExists('users');
   }
}
```

ここでは、「users」というテーブルを作成しています。ここには、「id」「name」「email」 「password」といったフィールドが用意されており、その他、rememberToken と timestampsが呼び出されています。これらはトークン(クライアント識別のために生成 されるランダムな文字列)と日時を保管するためのフィールドを追加するものです。　　
ユーザー情報そのものは、ここに挙げた4つのフィールドで保管されるものがすべて だと考えてよいでしょう。

## /helloでログインをチェックする ##{#p3}
では、Authによるユーザー認証機能を使ってみましょう。ここでは、先ほどまでサンプルに使っていた/helloアクションを修正して、ログイン状態をチェックする処理を追 加してみます。  
まずは、コントローラの修正です。HelloControllerクラスのindexアクションメソッドを以下のように修正します。

<p class="tmp list"><span>リスト2</span>HelloController.php</p>
```
// use Illuminate\Support\Facades\Auth;　を追記

public function index(Request $request)
{
    $user = Auth::user();
    $items = Customer::orderBy('name', 'asc')
        ->simplePaginate(5);
    $param = ['items' => $items, 'sort' => 'name', 'user' => $user];
    return view('hello.index', $param);
}
```

ここでは、Auth::userというメソッドの戻り値を変数$userに入れて、テンプレートに渡しています。このAuth::userは、ログインしているユーザーのモデルインスタンス(Auth では、Userというモデルクラスが用意されています)を返します。ログインしていなけ ればnullとなります。

### テンプレートの修正
続いて、テンプレート側の修正です。「views」内の「hello」フォルダの中からindex.blade.phpを開いて下さい。そして、@section(content)の次の行に以下のスクリプトを 追加して下さい。

<p class="tmp list"><span>リスト3</span>index.blade.php</p>
```
@if (Auth::check())
<p>USER: {{$user->name . ' (' . $user->email . ')'}}</p>
@else
<p>※ログインしていません。（<a href="/login">ログイン</a>｜
   <a href="/register">登録</a>）</p>
@endif
```

ここでは、Auth::checkという値をチェックしています。これは、現在アクセスしているユーザーがログインしているかどうかを確認するものです。ログインしていれば true、していなければfalseとなります。これにより、ログイン時とそうでないときの表示を変えていたのです。

修正ができたら、/helloにアクセスしてみましょう。Authは、認証に関連する機能を 全て持っています。それらの働きを確認しておきましょう。

## Authの認証関係ページ ##{#p4}
まずは、/helloにアクセスをしてみて下さい。この状態では、画面には「※ログインしていません」といった表示が現れます。これが、認証されていない状態の画面になります。

![](auth_login.png?classes=caption "図1　ログインしていない状態。")

### 認証ページ
ページに表示されている「登録」リンクをクリックすると、ユーザーの登録画面に移動します。これは、/registerというアドレスになります。ここでユーザー名・メールアドレスパスワードを入力し送信すると、それが登録されます。

![](auth_input.png?classes=caption "図2　ユーザー登録の画面")


### ログインページ
既にユーザー登録してある場合は、/helloで「ログイン」リンクをクリックするとログイン画面になります。ここで登録してあるメールアドレスとパスワードを入力して送信 すれば、ログインできます。

![](.png?classes=caption "図3　ログイン画面。ここで登録済みのペールアドレスとパスワードを入力する。")

### ログイン後の/helloページ
ログインした後で、再び/helloにアクセスしてみましょう。すると、今度は「USER: ○○」 というように、ログインしているユーザー名とメールアドレスが表示されます。指定の名前でログインできていることがわかります。

![](auth_login_in.png?classes=caption "図4　ログインして/helloにアクセスすると、ログインユーザーの名前とメールアドレスが表示される。")

### ホーム画面
ログイン後、/homeにアクセスしてみましょう。すると、ホーム画面という呼ばれる 表示が現れます。これは、ログインの状態などを表示するページです。ここには、ログ インしている自分自身の情報が表示されます。ここからログアウトすることもできます。

![](auth_home.png?classes=caption "図5　ホーム画面。ログイン中のユーザーの情報が表示される。ここからメニューを選んでログアウトさせることもできる。")

<div class="gray-box" markdown="1">
#### Column Chromeで登録・ログインができない!」
Chromeを利用している場合、登録ページで自分の名前などを入力して送信しても、 TokenMismatchExceptionが発生する場合があります。これは、既に何度か説明をしましたが、Chromeでセッションが中断される問題によるものです。 Auth利用の際には、Chrome以外のブラウザで動作確認などを行って下さい。
</div>

## 特定ページの保護 ##{#p5}
アクションやテンプレート内で、ログイン中のユーザーを示す値($user)の値を使ってログインしているかどうかをチェックする、というのは比較的簡単に行えます。これ は、Authミドルウェアを利用します。

ルート情報を記述してあるweb.phpを開き、/helloのルート情報を探して下さい。  
**Route::get('hello', 'HelloController@index')**といった形で記述されているはずです。 この文を見つけたら、その後に処理を追記して、以下のように修正して下さい。

<p class="tmp list"><span>リスト4</span></p>
```
Route::get('hello', 'HelloController@index')
    ->middleware('auth');
```

これで、/helloアクションはログイン必須となります。ログインせずに/helloにアクセスすると、ログインページにリダイレクトされます。

## ログイン処理の実装 ##{#p6}
Authは、このようにユーザー登録やログインといった基本的な機能をすべて持っており、そこにリダイレクトするだけで処理を行えるようになっています。これは非常に便 利ですが、「独自にログインページを作って使いたい」ということもあるでしょう。

ユーザーのログイン処理は、Authクラスにあるメソッドで簡単に行えます。ですから、 独自にアクションを作成し、その中でログイン処理を行うこともできるのです。

ログイン処理は、Authクラスの「attempt」というメソッドで行います。基本的な処理 の流れを整理すると以下のようになります。

<p class="tmp"><span>書式1</span></p>
```
if (Auth::attempt(['email' => 文字列 , 'password' => 文字列 ])) {
	...ログイン成功時の処理... 
} else {
	...ログイン失敗時の処理...
}
```
**Auth::attempt**では、引数にemailとpasswordというキーを持った連想配列を渡します。これらの値を元にログインを実行し、成功すればtrue、失敗すればfalseを返します。ログインに必要な処理は、たったこれだけなのです。

### auth.blade.php の作成
では、実際に簡単なログインページを作ってみましょう。ここでは、/hello/authとい うアクションを作成し、ログイン処理を行ってみます。 まずは、テンプレートの用意です。「views」内の「hello」フォルダ内に、新たに「auth.blade.php」という名前でファイルを作成しましょう。そして以下のように内容を記述しておきます。

<p class="tmp list"><span>リスト5</span>auth.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'ユーザー認証')

@section('menubar')
   @parent
   ユーザー認証ページ
@endsection

@section('content')
<p>{{$message}}</p>
   <table>
   <form action="/hello/auth" method="post">
      {{ csrf_field() }}
      <tr><th>mail: </th><td><input type="text" 
            name="email"></td></tr>
      <tr><th>pass: </th><td><input type="password" 
            name="password"></td></tr>
      <tr><th></th><td><input type="submit" 
            value="send"></td></tr>
   </form>
   </table>
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```

ここでは、$message変数の出力と、/hello/authにPOST送信するフォームを用意してあります。フォームには、emailとpasswordという2つの入力コントロールがあります。 このフォームでログインし、結果を$messageに表示しよう、というわけです。

### アクションの作成
続いて、アクションを作りましょう。HelloControllerクラスに、以下のアクションメソッドを追記して下さい。

<p class="tmp list"><span>リスト6</span>HelloController.php</p>
```
public function getAuth(Request $request)
{
   $param = ['message' => 'ログインして下さい。'];
   return view('hello.auth', $param);
}

public function postAuth(Request $request)
{
   $email = $request->email;
   $password = $request->password;
   if (Auth::attempt(['email' => $email,
           'password' => $password])) {
       $msg = 'ログインしました。（' . Auth::user()->name . '）';
   } else {
       $msg = 'ログインに失敗しました。';
   }
   return view('hello.auth', ['message' => $msg]);
}
```

※コントローラー記述後、web.phpに以下のルート情報を用意

<p class="tmp list"><span>リスト7</span>web.php</p>
```
Route::get('hello/auth', 'HelloController@getAuth');
Route::post('hello/auth', 'HelloController@postAuth');
```

![](auth_page.png?classes=caption "図6　/hello/authにアクセスし、メールアドレスとパスワードを入力する。それらが登録されていれ ばログインの表示がされ、登録が見つからないとログイン失敗の表示がされる。")

ここでは、getAuthとpostAuthの2つのアクションメソッドを用意してあります。

getAuthでは、messageという値をつけてhello.authテンプレートを表示させているだけです。  
postAuthでは、送信されたemailとpasswordの値を取り出し、それらを使って Auth::attemptを実行しています。これで、送信されたフォームの値でログイン処理が行われます。後は、結果に応じてメッセージを設定し、hello.authテンプレートを表示するだけです。

単にメッセージの表示でログイン状態を確認しましたが、実際の利用では、例えばログイン時には別のページにリダイレクトして移動するような形になるでしょう。


