<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Container\ContainerInterface;

require '../admin/basepath.php';

class EditController
{
    // コンテナインスタンス
    private $container;

    // コンストラクタ
    public function __construct(ContainerInterface $container)
    {
        // 引数のコンテナインスタンスをプロパティに格納。
        $this->container = $container;
    }


    //マークダウン変換
    public function markData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        global $basePath;
        global $folderName;
        global $db;
        global $flag;
        global $countIp;
        global $lockData;
        global $lockArray;

        $flag = $request->getAttribute('flag');
        $motourl = $request->getAttribute('moto');
        $countIp = $request->getAttribute('countIp');

        try {
            //PDOインスタンスをコンテナから取得
            $db = $this->container->get("db");

            $folderName = basename($_SERVER['REQUEST_URI']); //フォルダ名

            // URL中のパラメータを取得
            $folder = $args["folderName"]; //フォルダ名を取得
            $assign["folder"] = $folder; //配列に格納

            //ロックしたページでかつユーザーのIPがadmin_ipテーブルにない場合、閲覧不可にする処理
            if($flag==0){
                header('Location:' . $motourl, true, 307);
                $flag = 0; //閲覧不可
                exit;               
            }

            //フォルダ構成をオブジェクトで取得
            $folderObj = $this->container->get("folderComp");

            $lockArray = []; 

            $stmt = $db->prepare('select page, under_dir from locklist');
            $stmt->execute();
            $lockData = $stmt -> fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_GROUP);

            foreach($lockData as $key => $value){
                if(array_key_exists($key, $folderObj)){

                    if($lockData[$key][0]=='all'){
                        $folder_dir = preg_quote($folderObj[$key], '/');//正規表現をクオートする
                        $dir_group = preg_grep('/'.$folder_dir.'/', $folderObj);
                        $lockArray = array_merge($lockArray, $dir_group);     

                    }else{
                        $array = [$key => $folderObj[$key]];
                    }
                }
            }

            $lockArray = array_merge($lockArray, $array); 


            //メニュー生成
            $menuData = $this->container->get("menuComp");
            $assign["menuData"] = $menuData; //メニューリスト

            //マークダウン変換インスタンスをコンテナから取得
            $markData = $this->container->get("mark");

            $htmlData = $markData['html']; //HTMLデータ
            $title = $markData['title']; //タイトル

            $assign["folderObj"] = $folderObj; //フォルダ構成オブジェクト
            $assign["htmlData"] = $htmlData; //記事内容
            $assign["title"] = $title; //タイトル格納

            $templatePath = "base.twig";
        }
        //例外処理
        catch (PDOException $ex) {

            //障害メッセージを作成
            $assign["errorMsg"] = "データベース処理に失敗しました。もう一度始めからやり直してください。";
            //表示先テンプレートをエラー画面に変更。
            $templatePath = "error.twig";
        } finally {
            //DB切断。
            $db = null;
        }

        //管理者かどうかの判定値
        $assign["countIp"] = $countIp;
        //ディレクトリ名を格納
        $assign["pathBase"] = $basePath;
        // Twigインスタンスをコンテナから取得。
        $twig = $this->container->get("view");
        // memberAdd.htmlをもとにしたレスポンスオブジェクトを生成。
        $response = $twig->render($response, $templatePath, $assign);

        // レスポンスオブジェクトをリターン。
        return $response;
    }

    //編集画面
    public function editData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        global $basePath;
        global $folderName;

        $ipAddress = $_SERVER["REMOTE_ADDR"]; //取得したIPアドレス
        $folderName = basename($_SERVER['REQUEST_URI']); //フォルダ名

        //PDOインスタンスをコンテナから取得
        $db = $this->container->get("db");
        $sql_ip = $db->prepare('select * from admin_ip where ip_address=?');
        $sql_ip->execute([$ipAddress]);

        $countIp = $sql_ip->rowCount();

        try {
            //例外判定
            if ($countIp == 0) {
                throw new Exception('管理者以外は編集できません');
            } else {

                $folderName = basename($_SERVER['REQUEST_URI']); //フォルダ名

                //フォルダ構成をオブジェクトで取得
                $folderObj = $this->container->get("folderComp");
                $folderDir = $folderObj[$_REQUEST['folder']];

                if (empty($_SERVER['HTTP_REFERER'])) {
                    //echo '未定義';
                    $motourl = '../p__base/'; //修正予定
                } else {
                    $motourl = $_SERVER['HTTP_REFERER']; //遷移元のURL
                }

                $mkData = file_get_contents($folderDir . '/markdown.md');
                // $mkData = htmlspecialchars($mkData, ENT_QUOTES);

                // Twigインスタンスをコンテナから取得。
                $twig = $this->container->get("view");

                $filelist = $this->container->get("fileIcon");

                // print_r($filelist);

                $assign["pathBase"] = $basePath;
                $assign["mkData"] = $mkData;
                $assign["edit"] = $_REQUEST['edit'];
                $assign["folder"] = $_REQUEST['folder'];
                $assign["folderPath"] = $_REQUEST['folderPath'];
                $assign["scroll"] = $_REQUEST['scroll'];
                $assign["motourl"] = $motourl;
                $assign["fileList"] = $filelist;
                $assign["folderDir"] = $folderDir;

                // templateのbase.twigからをHTMLを生成。
                $response = $twig->render($response, "edit.twig", $assign);

                return $response;
            }
        } catch (Exception $ex) {
            echo $ex->getMessage();
            // header('Location:'. $motourl); //遷移元かトップに戻る
            exit;
        }

        return $response;
    }


    //編集保存
    public function markdownUpload(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        echo $_POST['folderDir'];
        file_put_contents($_POST['folderDir'].'/markdown.md', $_POST['report']);//mdファイル保存

        return $response;
    }


    //ファイル保存　テスト
    public function fileSave(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        //一時的保存にファイルがあるか確認
        //if (is_uploaded_file($_FILES['hoge']['tmp_name'])) {
        if (!empty($_FILES['hoge']['tmp_name'])) {

            //保存用のフォルダがなければ作成する
            if(!file_exists($_POST['folderDir'].'/upload')){
                mkdir($_POST['folderDir'].'upload');
            }
    
            //保存先のファイルのパスを変数に取得。
            $file = $_POST['folderDir'].'/upload/'.basename($_FILES['hoge']['name']);
    
            //フォルダにファイルを一時的保存から移動して格納
            move_uploaded_file($_FILES['hoge']['tmp_name'], $file);
            
            //更新日付順表示
            $sort_by_lastmod = function($a, $b) {
                return  filemtime($a) - filemtime($b);
            };
    
            $files = glob($_POST['folderDir'].'/upload/*');
            usort( $files, $sort_by_lastmod );
            $thmbSrc = str_replace('../../', '../', $_POST['folderDir']);//サムネイル用
    
            //保存ファイルのリストを表示
            foreach ($files as $item) {
                $file_name = basename($item);//ファイル名だけを抜き出す
                $fileClass ='';
                $photo = false;
    
                switch (1) {
                    //エクセル
                    case preg_match('/.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/',$file_name):
                        $fileClass = 'file_icon excel-icon';
                        break;
                    //テキスト
                    case preg_match('/.txt$/',$file_name):
                        $fileClass = 'file_icon text-icon';
                        break;
                    //ワード
                    case preg_match('/.doc$|.docm$|.docx$|.dot$|.dotx$/',$file_name):
                        $fileClass = 'file_icon word-icon';
                        break;
                    //パワーポイント
                    case preg_match('/.pptx$/',$file_name):
                        $fileClass = 'file_icon pptx-icon';
                        break;
                    //zipファイル
                    case preg_match('/.zip$/',$file_name):
                        $fileClass = 'file_icon zip-icon';
                        break;
                    //PDFファイル
                    case preg_match('/.pdf$/',$file_name):
                        $fileClass = 'file_icon pdf-icon';
                        break;
                    //画像
                    case preg_match('/.png$|.PNG$|.jpg$|.jpeg$|.JPG$|.JPEG$|.svg$|.svgz$|.gif$|.webp$/',$file_name):
                        $photo = true;
                        break;
                }
    
                if(!$photo == true){
                    echo '<li><span class="filename '.$fileClass.'">'.$file_name.'</span><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                }else{
                    // echo '<li class="photo-list"><span class="filename">'.$file_name.'</span><img src="'.$_POST['folderDir'].'/upload/'.$file_name.'" alt=""><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
    
                    echo '<li class="photo-list"><span class="filename">'.$file_name.'</span><img src="'.$thmbSrc.'/upload/'.$file_name.'" alt=""><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                }
            }
        }

        return $response;
    }


    //ファイル削除
    public function fileDelete(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $result = $_POST['folderDir'].'/upload/'.$_POST['item'];//ポストで受け取れる

        unlink($result);//ファイル削除
    
        //更新日付順表示
        $sort_by_lastmod = function($a, $b) {
            return  filemtime($a) - filemtime($b);
        };
    
        $files = glob($_POST['folderDir'].'/upload/*');
        usort( $files, $sort_by_lastmod );
        $thmbSrc = str_replace('../../', '../', $_POST['folderDir']);//サムネイル用
    
        //保存ファイルのリストを表示
        foreach ($files as $item) {
            $file_name = basename($item);//ファイル名だけを抜き出す
            $fileClass ='';
            $photo = false;
    
            switch (1) {
                //エクセル
                case preg_match('/.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/',$file_name):
                    $fileClass = 'file_icon excel-icon';
                    break;
                //テキスト
                case preg_match('/.txt$/',$file_name):
                    $fileClass = 'file_icon text-icon';
                    break;
                //ワード
                case preg_match('/.doc$|.docm$|.docx$|.dot$|.dotx$/',$file_name):
                    $fileClass = 'file_icon word-icon';
                    break;
                //パワーポイント
                case preg_match('/.pptx$/',$file_name):
                    $fileClass = 'file_icon pptx-icon';
                    break;
                //zipファイル
                case preg_match('/.zip$/',$file_name):
                    $fileClass = 'file_icon zip-icon';
                    break;
                //PDFファイル
                case preg_match('/.pdf$/',$file_name):
                    $fileClass = 'file_icon pdf-icon';
                    break;
                //画像
                case preg_match('/.png$|.jpg$|.jpeg$|.JPG$|.JPEG$|..svg$|.svgz$|.gif$|.webp$/',$file_name):
                    $fileClass = 'file_icon pdf-icon';
                    $photo = true;
                    break;
            }
    
            if(!$photo == true){
                echo '<li><span class="filename '.$fileClass.'">'.$file_name.'</span><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
            }else{
                // echo '<li class="photo-list"><span class="filename">'.$file_name.'</span><img src="'.$_POST['folderDir'].'/upload/'.$file_name.'" alt=""><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
    
                echo '<li class="photo-list"><span class="filename">'.$file_name.'</span><img src="'.$thmbSrc.'/upload/'.$file_name.'" alt=""><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
            }
        }

        return $response;
    }



    //編集画面を表示
    public function page_update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        global $basePath;
        $basePath = $basePath . '/public/';

        return $response;
    }
}
