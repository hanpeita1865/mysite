<?php
$database='from_now';
$user='staff';
$password='password';

$pdo=new PDO('mysql:host=localhost;dbname='.$database.';charset=utf8',$user, $password);
?>

<!DOCTYPE html>
<html lang="ja">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>管理画面｜</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/fork-awesome.min.css">
	<!--<link rel="stylesheet" href="../css/style.css">-->
    <link rel="stylesheet" href="../css/admin.css">
	<!-- <script src="../js/jquery.min.js"></script> -->
	<script>
	//閲覧不可ページ
	let lockArray = [
	<?php foreach ($pdo->query('select * from locklist') as $row): ?>
		'<?= $row['page'] ?>',
	<?php endforeach; ?>
	];
	</script>
</head>

<body>
	<main>
		<div class="container">
			<h1>管理画面</h1>
			<ol>
				<li>メニューをドラック&amp;ドロップすると、並べ替えができます。</li>
				<li>メニュー名のリンクをダブルクリックすれば、メニュー名を変更できます。</li>
				<li>メニューをダブルクリックをすると空のサブメニュー用ボックスが作成されるので、そこにメニューをドラッグしてください。</li>
			</ol>
			<div class="sub-close-area">
				<button class="btn-sub-close">全サブメニュー開閉</button>
			</div>
			<ul id="menu" class="side-link">
            	<?php require '../templates/layouts/menu_list.twig' ?>
			</ul>
			<div class="sub-close-area">
				<button class="btn-sub-close">全サブメニュー開閉</button>
			</div>
            <div class="d-flex justify-content-between mb-3">
				<input type="button" value="新規フォルダ作成" class="btn-create" id="create">	
            </div>
			<!-- <button id="btn-execution">メニュー→フォルダ構成反映</button> -->
			<button id="btn-menu-rebuild">フォルダ構成→メニュー反映</button>
			<button id="btn-file-copy">ファイルコピー</button>
    </main>
	<script src="../js/admin.js"></script> 
</body>

</html>