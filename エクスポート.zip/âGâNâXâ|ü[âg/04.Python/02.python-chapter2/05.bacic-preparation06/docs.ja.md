---
title: 05.タプル
taxonomy:
    category:
        - docs
visible: true
---

すでに学んだ「リスト」の他にも、Pythonには多くのデータ構造があります。<br>
各データ構造の性質を理解して使い分けたり、異なるデータ構造を組み合わせたりすることで、高度なプログラムを効率よく作成することができます。

<h2 class="h-type2">タプル</h2>

タプルとは、リストと同様にデータ構造の一つで、複数のデータをまとめるのに便利な機能です。<br>
複数のデータをまとめるという点はリストと共通していますが、次のような違いがあります。

<h3 class="h-type3">リストとタプルの違い</h3>
<dl>
    <dt>リストの特徴</dt>
    <dd>
        <ul class="mt-05">
            <li>[値,値.…]のように、<span class="red bold">角括弧</span>で囲んで作成する。</li>
            <li>ミュータブルなので、<span class="red bold">要素の追加／挿入／変更／削除ができる。</span></li>
        </ul> 
    </dd>
    <dt>タプルの特徴</dt>
    <dd>
        <ul class="mt-05">
            <li>(値,値.…)のように、<span class="red bold">丸括弧</span>で囲んで作成する。</li>
            <li>イミュータブルなので、<span class="red bold">要素の追加／挿入／変更／削除ができない。</span></li>
            <li>要素を変数へ簡単に取り出す機能（アンパック）があるので、リストよりも<span class="red bold">プログ				ラムを簡潔に書ける</span>可能性があります。</li>
        </ul> 
    </dd>
</dl>

※一度使ったタプルは変更できません。変更したい場合は、新しいタプルを丸ごと作り直します。

<p class="tmp"><span>書式1</span>タプルの作成</p>
<pre>
(値, 値,…)
</pre>

※カンマで区切られた値をタプルに登録します。値は、それぞれ別の要素として登録されます。<br>
　作成したタプルは変数に代入することができます。

<p class="tmp"><span>書式2</span>タプルの代入</p>
<pre>
変数 = (値, 値,…)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> item = ('blue', 'hat')
>>> item
('blue', 'hat')
</pre>

※値を持たない空のタプルは「()」と書きます。

<p class="tmp"><span>書式3</span>タプルとインデックス</p>
<pre>
タプル[インデックス]
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> item[0]
'blue'
>>> item[1]
'hat'
>>>
</pre>

<h2 class="h-type2">パックとアンパック</h2>

実は丸括弧で囲まなくても、タプルを作ることが出来ます。この機能のことを<span class="red bold">パック</span>または<span class="red bold">パッキング</span>と呼びます。

<p class="tmp"><span>書式4</span>パック</p>
<pre>
変数 = 値, 値, …
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> item2 = 'red', 'shirt'
>>> item2
('red', 'shirt')
</pre>

※複数のタプルを組み合わせた処理をしたい場合、各タプルを区別するために、丸括弧で囲まなくてはならない場合があります。


パックとは逆に、タプルの要素を複数の変数に代入することが出来ます。この機能のことを<span class="red bold">アンパック</span>または<span class="red bold">アンパッキング</span>と呼びます。

<p class="tmp"><span>書式5</span>アンパック</p>
<pre>
変数, 変数, … = タプル
</pre>

※タプルが持つ要素の数と、代入する変数の数は一致させる必要があります。

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> color, name = item2
>>> color
'red'
>>> name
'shirt'
</pre>

<p class="tmp"><span>書式6</span>複数同時代入</p>
<pre>
変数A, 変数B, … = 値A, 値B, …
</pre>

※代入させる変数と値の個数は一致させる必要があります。

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> color, name = 'green', 'socks'
>>> color
'green'
>>> name
'socks'
</pre>

<h2 class="h-type2">タプルのリスト</h2>

タプルとリストは組み合わせて使うことができます。例えば、要素かタプルであるリストを作ることが可能です。

<p class="tmp"><span>書式7</span>タプルのリスト</p>
<pre>
[(値, …), (値, …), …]
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> catalog = [('blue', 'hat'), ('red', 'shirt'), ('green', 'socks')]
>>> catalog
[('blue', 'hat'), ('red', 'shirt'), ('green', 'socks')]
>>> catalog[1]
('red', 'shirt')
>>> catalog[1][1]
'shirt'
</pre>

<dl>
    <dt>タプルとリストの使い分け</dt>
    <dd>
        <ul>
            <li>タプルは、<span class="red bold">決まった個数のデータ</span>をまとめるのに向いています。<br>
				アンパックの機能があるので、データを簡単に取り出せることも利点です。</li>
            <li>リストは、<span class="red bold">個数が決まらないデータ</span>をまとめるのに向いています。<br>
				後からデータを追加したり、データを削除したりすることが簡単にできるためです。</li>
        </ul>
    </dd>
</dl>


<h2 class="h-type2">enumerate関数</h2>

enumerate関数は、for文と一緒に使う関数です。指定したイテラブルを元に、（番号, 要素）のようなタプルを生成します。

<p class="tmp"><span>書式8</span>enumerate関数</p>
<pre>
for 変数A, 変数B in enumerate(イテラブル):
    処理
</pre>

<p class="tmp"><span>書式9</span>enumerate関数における開始値の指定</p>
<pre>
for 変数A, 変数B in enumerate(イテラブル, 開始値):
    処理
</pre>

リストなどに対して繰り返しを行うときに、「0, 1, 2…」のように何番目の要素なのかを表す番号が欲しいことがあります。
このような場合に役立つのがenumerate関数です。<br>
上記の書式のように記述することで、イテラブル（リストや文字列など）から順に要素を取り出し、変数Bに代入します。
変数Aには「0, 1, 2…」のように、0から開始して1ずつ増加する整数が入ります。<br>
enumerate関数は指定したイテラブルを元に、（番号, 要素）のようなタプルを生成します。
上記の書式の変数Aと変数Bのように2つの変数を指定すれば、このタプルをアンパックして、変数Aに番号、変数Bに要素を取り出すことができます。

<p class="inpre"><span>インタプリタ</span></p>
<pre>
<span class="comment">catalog = [('blue', 'hat'), ('red', 'shirt'), ('green', 'socks')]//先ほど記述済</span>

>>> for index, item in <span class="bold">enumerate(catalog, 1)</span>:
...     print(index, item)
...
1 ('blue', 'hat')
2 ('red', 'shirt')
3 ('green', 'socks')
</pre>

<h2 class="h-type2">可変長引数</h2>
個数を変更することができる引数のことです。引数の前に「<span class="red">*</span>」を付けると、可変長引数を使うことができます。可変長引数を使うと、任意個の位置引数を受け取る関数を定義することができます。

<p class="tmp"><span>書式10</span>位置引数の可変長引数</p>
<pre>
def 関数名(<span class="red">*</span>引数):
    処理
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> def test(<span class="red">*</span>x):
...     print(x)
...
>>> test(1, 2)
(1, 2)
>>> test(1, 2, 3)
(1, 2, 3)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> def sum(<span class="red">*</span>number):
...     s = 0
...     for n in number:
...         s += n
...     return s
...
>>> sum(1, 2)
3
>>> sum(1, 2, 3)
6
</pre>

