<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MenuService,
    MarkdownService,
};

require '../admin/basepath.php';

class SearchController
{
    private EditService $editService;
    private FolderService $folderService;
    private MenuService $menuService;
    private MarkdownService $markdownService;
    private $container;

    
    public function __construct(EditService $editService, FolderService $folderService, MenuService $menuService, MarkdownService $markdownService, ContainerInterface $container)
    {
        $this->container = $container;
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->menuService = $menuService;
        $this->markdownService = $markdownService;
    }
    

    public function searchResult(Request $request, Response $response, array $args): Response
    {         
        $config = $this->container->get('config');
        $basePath = $config['basePath'];
        
        $params = $request->getQueryParams();
        $category = trim($params['cate'] ?? '');
        $fullText = isset($params['fullText']);

        $folderName = basename($_SERVER['REQUEST_URI']);
        $this->container->set('folderName', $folderName);

        $countIp = $request->getAttribute('countIp');
        
        if (!$this->container->has('countIp')) {
            $this->container->set('countIp', $countIp);
        }
        
        if($category==''){
            $searchFolder = '../pages';
        }else{
            $searchFolder = '../pages/'.$category;
        }
        
        $folderObj = $this->folderService->getFolderComp($searchFolder);//サービス
        $menuData = $this->menuService->buildMenu('../pages', '');//サービス
        
        if(isset($_REQUEST['fullText'])){
            $fullText = true;
        }else{
            $fullText = false;
        }
        
        $word = trim($params['word'] ?? '');

        if ($word === '') {
            // 検索語が空なら検索せず、元のページを再描画
            $twig = $this->editService->view();
            $assign = [
                "countIp" => $request->getAttribute('countIp'),
                "pathBase" => $basePath,
                "htmlData" => "検索キーワードが空です。", 
                "title" => "検索",     // 元のページタイトル
                "fullText" => $fullText,
                "menuData" => $menuData,
            ];
            return $twig->render($response, "base.twig", $assign);
        }

        $folderArray = array_values($folderObj);
        $mdArray = [];
        
        foreach ($folderArray as $dir){
            $md = file_get_contents($_SERVER["DOCUMENT_ROOT"] . $basePath . '/pages/' . $dir . '/markdown.md');

            if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle)) {
                $title = $ArrayTitle[1];
            }

            if($fullText){
                //マークダウンに含まれるか判定
                if(preg_match('/'.$word.'/i',$md)){
                    $mdArray[] = ['dir'=>$dir, 'md'=> $md];
                }
                
            }else{
                if(preg_match('/'.$word.'/i',$title)){
                    $mdArray[] = ['dir'=>$dir, 'md'=> $md];
                }
            }           
        }

        $markData = $this->markdownService->markSearch($mdArray, $word, $fullText);//サービス（検索とHTML変換）
        $htmlData = $markData['html']; 

        $assign["countIp"] = $countIp;
        $assign["pathBase"] = $basePath;
        $assign["htmlData"] = $htmlData;
        $assign["title"] = '検索結果';
        $assign["fullText"] = $fullText;
        $assign["menuData"] = $menuData;

        $twig = $this->editService->view();

        $response = $twig->render($response, "base.twig", $assign); 

        return $response;
    }

}    