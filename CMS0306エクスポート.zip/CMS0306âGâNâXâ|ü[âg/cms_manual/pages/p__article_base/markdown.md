*[page-title]:基本

サイトや記事内容からテキストをコピーしてCKEditorに「<span class="blue bold">Ctrl + V</span>」でペーストした場合、styleによる装飾やリンクがそのまま入ります。  
「<span class="green bold">Ctrl + Shift + V</span>」でペーストすると装飾なしのプレーンテキストとしてペーストされます。


<div class="exp mb-5" markdown="1">
<p class="tmp"><span>例</span>下記のテキストをコピーペーストしてみます。</p>
<ul>
    <li>
        <mark class="marker-yellow">buy the ticket</mark>
    </li>
    <li>
        <mark class="marker-green">start your adventure</mark>
    </li>
</ul>
</div>

「<span class="blue bold">Ctrl + V</span>」でペーストした場合、そのままのスタイルになります。
<ul class="mb-5">
    <li>
        <mark class="marker-yellow">buy the ticket</mark>
    </li>
    <li>
        <mark class="marker-green">start your adventure</mark>
    </li>
</ul>

「<span class="green bold">Ctrl + Shift + V</span>」でペーストすると、スタイルなしになります。
<p>
    buy the ticket
    <br>
    start your adventure
</p>


テキストの後ろで「Enterキー」だけ押すと、段落<kbd>&lt;p&gt;</kbd>になります。

「Shiftキー + Enterキー」を同時に押すと、改行<kbd>&lt;br&gt;</kbd>になります。