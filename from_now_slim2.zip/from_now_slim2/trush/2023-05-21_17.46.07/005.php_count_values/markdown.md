*[page-title]:配列の値の数を数える array_count_values

参考サイト
: [PHP マニュアル array_count_values](https://www.php.net/manual/ja/function.array-count-values.php)

array_count_values() は、 配列 array の値 (数値または文字列でなければいけません) をキーとし、 array におけるその値の出現回数を値とした配列を返します。

<p class="tmp"><span>書式</span>array_count_values</p>
```
array_count_values($array):
```

<div class="exp">
	<p class="tmp"><span>例1</span>array_count_values() の例</p>
	<iframe src="https://paiza.io/projects/e/cw2OmAYHyLIjyflHe_e0AA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

count() の場合は、 配列または Countable オブジェクトに含まれるすべての要素の数を数える
<div class="exp">
	<p class="tmp"><span>例2</span>count()</p>
</div>
<iframe src="https://paiza.io/projects/e/Umn6jLQJ16KJtR5Vt1WUMA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>