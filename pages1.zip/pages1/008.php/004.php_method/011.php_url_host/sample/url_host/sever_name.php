<?php
//apacheやnginxなどで設定されているServerName
echo $_SERVER['SERVER_NAME'];
?>