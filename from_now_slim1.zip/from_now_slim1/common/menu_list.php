<li id="item1" class="box-item"><a href="<?= $basePath ?>pages/base/">共有事項</a>
<ul class="sub-menu">
<li id="item2" class="box-item"><a href="<?= $basePath ?>pages/base/test/">パソコン</a></li>
</ul>
</li>
<li id="item3" class="box-item"><a href="<?= $basePath ?>pages/computer/">パソコン</a></li>
<li id="item4" class="box-item"><a href="<?= $basePath ?>pages/markdown_exp/">マークダウン記述例</a></li>
