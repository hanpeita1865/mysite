---
title: 多次元配列
taxonomy:
    category:
        - docs
---

PHPでは、配列の要素の中を配列とすることもできます。これにより多次元配列を作成することができます。

<!--<iframe src="https://paiza.io/projects/e/r50rrmum0oyAI2nBECZ1DQ?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>-->

<iframe src="https://paiza.io/projects/e/gaWR0HgJ8YL3mf96zbVRag?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>



<iframe src="https://paiza.io/projects/e/Dtf6D-x6HBxk0PANKIyhKA?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>