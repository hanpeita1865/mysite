import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "custom" | "default" | "sample"
declare module "C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}