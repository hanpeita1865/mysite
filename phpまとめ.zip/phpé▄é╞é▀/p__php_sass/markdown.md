*[page-title]:PHP Sassコンパイラー

参考サイト
: [php-sassでSCSSをコンパイル](https://www.blog.danishi.net/2020/03/18/post-3301/)

SCSSからCSSを生成するためにはSCSSコンパイラにかける必要があるのですが、これをPHPで実行できるライブラリがphp-sassです。


composerでインストールします。
```
composer require panique/php-sass
```
PHPファイルとSCSSファイルを用意します。


フォルダ構成はこんな感じです。
```
/
├───index.php
├───vendor/
├───scss/
│       style.scss
│       base.scss
└───css/
```

<p class="tmp list"><span>リスト</span>index.php</p>
```
<?php
require 'vendor/autoload.php';

if($_SERVER['SERVER_NAME'] == 'localhost') {
    SassCompiler::run("scss/", "css/");
}
?>
<html>
<head>
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
    <div class="main">
        <p class="rotate">hello php-sass</p>
    </div>
</body>
</html>
```

PHPはSassCompiler::run()メソッドを呼び出して、SCSSの入力先とCSSの出力先を指定するだけです。

<p class="tmp list"><span>リスト</span>base.scss</p>
```
// 変数
$font-stack:    Helvetica, sans-serif;
$color: #fff;
$back-color: #BF4080;

body {
  font: 100% $font-stack;
  color: $color;
  background-color: $back-color;
}
```

<p class="tmp list"><span>リスト</span>style.scss</p>
```
@import "base"; // インポート

// コメント（コンパイル後残らない）

%message { /* コメント（コンパイル後も残る） */
  font-size: 10px * 3;  // オペレーター
  text-align: center;
}

// ネスト
.main {
  p {
    // 継承
    @extend %message;
    margin-top: 100px;
  }
}

// ミックスイン
@mixin transform($property) {
  -webkit-transform: $property;
  -ms-transform: $property;
  transform: $property;
}
.rotate { @include transform(rotate(30deg)); }
```

実行するとCSSが出力されてスタイルが適用されます。

<a href="sample/php_sass/">php_sassサンプル</a>

<p class="tmp list"><span>リスト</span>base.css</p>
```
body {
  font: 100% Helvetica, sans-serif;
  color: #fff;
  background-color: #bf4080;
}
```

<p class="tmp list"><span>リスト</span>style.css</p>
```
@import "base";
.main p {
  /* コメント（コンパイル後も残る） */
  font-size: 30px;
  text-align: center;
}
.main p {
  margin-top: 100px;
}
.rotate {
  -webkit-transform: rotate(30deg);
  -ms-transform: rotate(30deg);
  transform: rotate(30deg);
}
```

なぜか、@import "base"; がそのまま残ってしまう。


