$('#box').on('dragstart', onDragStart);//ドラッグを開始したときに、onDragStart関数を行う

$('#box').on('drag', onDrag);//ドラッグ中

$('#box').on('dragend', onDragEnd);//ドラッグ終わり

$('#box').on('drop', onDrop);//ドロップ

//ドラッグスタート
function onDragStart(e) {
	console.log('dragstart');
}

//ドラッグ中
function onDrag(e) {
	console.log('drag');
}

//ドラッグ終わり
function onDragEnd(e) {
	console.log('dragend');
}

//ドロップ
function onDrop(e) {
	console.log('drop');
}
