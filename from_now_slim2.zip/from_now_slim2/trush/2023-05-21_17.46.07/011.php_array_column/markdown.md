*[page-title]:入力配列から単一のカラムの値を取得 array_column()

参考サイト
: [PHP マニュアル array_column](https://www.php.net/manual/ja/function.array-column.php)

<p class="tmp"><span>書式</span></p>
```
array_column($array, $column_key, $index_key)
```
配列 $array の中から $column_key で指定した単一のカラムの値を返します。 オプションで $index_key も指定できます。 これを指定すると、 入力配列内のカラム $index_key の値をキーとし、 カラム $column_key を値とした配列が返されます。

array_columnは、入力配列から単一のカラムの値を返します。

<div class="exp">
	<p class="tmp"><span>例1</span>レコードセットからのファーストネームの取得</p>
	<iframe src="https://paiza.io/projects/e/SdggbYAhZOShfvARZ3XC_w?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例2</span>レコードセットから姓を取得し、"id"で並べ替える例</p>
	<iframe src="https://paiza.io/projects/e/uxL7qCHM8oKqSL8sNI_W9g?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例3</span>オブジェクトの public プロパティ "username" からユーザー名を取得する例</p>
	<iframe src="https://paiza.io/projects/e/OnxvIQWhS6AmSA5Xyy5pDw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>