import { ssrRenderAttrs, ssrRenderSlot } from 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/vue/server-renderer/index.mjs';
import { useSSRContext } from 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/vue/index.mjs';
import { a as _export_sfc } from './server.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/ohmyfetch/dist/node.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/ufo/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/hookable/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/unctx/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/vue-router/dist/vue-router.node.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/h3/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/defu/dist/defu.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/@vue/shared/index.js';
import './nitro-prerenderer.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/node-fetch-native/dist/polyfill.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/destr/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/radix3/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/unenv/runtime/fetch/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/scule/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/ohash/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/unstorage/dist/index.mjs';
import 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/unstorage/dist/drivers/fs.mjs';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><p>\u30B5\u30F3\u30D7\u30EB\u30DA\u30FC\u30B8\u3067\u3059\u3002</p>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/sample.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const sample = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { sample as default };
//# sourceMappingURL=sample.3c759351.mjs.map
