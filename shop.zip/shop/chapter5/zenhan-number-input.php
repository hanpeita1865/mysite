<?php require '../header.php'; ?>
<p>購入個数を入力してください。</p>
<form action="zenhan-number-output.php" method="post">
<input type="text" name="count">
<input type="submit" value="確定">
</form>
<?php require '../footer.php'; ?>
