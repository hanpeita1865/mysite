<?php
//現在アクセスされているプロトコル判定
echo (empty($_SERVER['HTTPS']) ? 'http://' : 'https://')
?>