Vue.createApp({
  data() {
    return {
      url: 'https://wings.msn.to/'
    };
  }
}).mount('#app');