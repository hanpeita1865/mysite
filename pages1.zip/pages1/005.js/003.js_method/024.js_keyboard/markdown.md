*[page-title]:キーボード操作

## 矢印キーイベント検出

 参考サイト
: [JavaScript で矢印キーの押下を検出する](https://www.delftstack.com/ja/howto/javascript/javascript-arrow-keys/]


<p class="tmp"><span>書式</span>キーボードイベント検出</p>
```
document.addEventListener("keydown", function(event) {});
```

<p class="tmp">矢印キーを検出</p>
```
document.addEventListener("keydown", function(event) {
    if (event.key == "ArrowLeft"){
        alert("Left key"); //show the message saying Left key"
    } else if (event.key == "ArrowUp"){
        alert("Up key"); //show the message saying Up key"
    } else if (event.key == "ArrowRight"){
        alert("Right key"); //show the message saying Right key"
    } else if (event.key == "ArrowDown"){
        alert("Down key"); //show the message saying Down key"
    }
});
```

サンプル
: <http://localhost:7001/test/tab/sample(keyarrow)/>

## その他

参考サイト
: <https://1-notes.com/javascript-addeventlistener-key-ivent/#toc_id_6>

codepen
: <https://codepen.io/yochans/pen/oNzrqEq>

参考サイト
: https://1-notes.com/javascript-wasd-and-arrow-key-input-events/

codepen
: <https://codepen.io/yochans/pen/dyWvNGM?editors=1111>
