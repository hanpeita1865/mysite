*[page-title]:問題（PHP 配列）


<span class="bold green fz-12">問題1</span>　$stackの配列へ「ぶどう」を追加するよう空欄に記入してください。
<div markdown="1" class="problem-column">
![](upload/array_push問題.png)
<div markdown="1" class="">
<input type="text" value="" autocomplete="off">　または　<input type="text" value="" autocomplete="off">
</div>
<details markdown="1"><summary>解答</summary>
array_push($stack,"ぶどう");　または　$stack[] = "ぶどう";
<p class="tmp"><span>書式</span></p>
```
array_push( 要素を追加する配列 , 追加したい要素1 [, 追加したい要素2 ] )
```
※第3引数以降は省略可能です。第3引数以降にも値を渡すことで複数の要素を一度に追加することができます。
</details>
</div>


<span class="bold green fz-12">問題2</span>　$stackの連想配列が最初にキーがbanana値がばななを追加し、そのあとキーがmikan値がみかんを追加するよう空欄に当てはまるコードを記入してください。   
<div markdown="1" class="problem-column">
![](upload/連想配列に追加.png)

<div markdown="1" class="problem flex-nowrap justify-content-start">
<label>①</label>
<input type="text" value="" autocomplete="off">
<label>②</label>
<input type="text"  value="" autocomplete="off">
</div>
<details><summary>解答</summary>
	① $stack['banana'] = 'バナナ'　② $stack['mikan'] = 'みかん'　
</details>
</div>


<span class="bold green fz-12">問題3</span>　配列と連想配列のセット$memberに追加するよう空欄に記入してください。
<div markdown="1" class="problem-column">
<div markdown="1" class="d-flex justify-content-start">
![](upload/memberに追加コード.png)
![](upload/memberに追加.png)
</div>
<div markdown="1" class="problem flex-nowrap justify-content-start">
<label>①</label>
<input type="text" value="" autocomplete="off" class="wd=10">
<label>②</label>
<input type="text"  value="" autocomplete="off" class="wd60">
</div>
または
<div markdown="1" class="problem flex-nowrap justify-content-start">
<label>①</label>
<input type="text" value="" autocomplete="off" class="wd=10">
<label>②</label>
<input type="text"  value="" autocomplete="off" class="wd60">
</div>
<details markdown="1"><summary>解答</summary>
① $member[]　② ['name' => '山本', 'age' => '35', 'place' => '岡山']　または　array_push($member, ["name"=>"山本", "age"=>35, "place"=>"岡山"])
</details>
</div>


<span class="bold green fz-12">問題4</span>　$queueの要素の並びが逆になるよう空欄に当てはまるコードを記入してください。
<div markdown="1" class="problem-column">
<div markdown="1" class="d-flex justify-content-start">
![](upload/array_mergeコード.png)
![](upload/array_merge実行結果.png)
</div>
<div markdown="1" class="problem">
<div markdown="1">
<input type="text" value="" autocomplete="off"></input>
</div>
</div>
<details markdown="1"><summary>解答</summary>
array_reverse($queue)
</details>
</div>


<span class="bold green fz-12">問題5</span>　値だけを抽出し配列で返すよう空欄にコードを記入してください。
<div markdown="1" class="problem-column">
<div markdown="1" class="d-flex justify-content-start">
![](upload/array_valuesコード.png)
![](upload/array_values結果.png)
</div>
<div markdown="1" class="problem">
<div markdown="1">
<input type="text" value="" autocomplete="off"></input>
</div>
</div>
<details markdown="1"><summary>解答</summary>
array_values($fruits)
</details>
</div>


<span class="bold green fz-12">問題6</span>　$keysの要素を$fruitsのキーに、$valuesの要素を$fruitsの値に設定した連想配列を作成するように空欄にコードを記入してください。
<div markdown="1" class="problem-column">
<div markdown="1" class="d-flex justify-content-start">
![](upload/array_combineコード.png)
![](upload/array_combine結果.png)
</div>
<div markdown="1" class="problem">
<div markdown="1">
<input type="text" value="" autocomplete="off"></input>
</div>
</div>
<details markdown="1"><summary>解答</summary>
array_combine($keys, $values)
</details>
</div>


<span class="bold green fz-12">問題7</span>　$fruits配列のorange要素を削除するよう空欄に当てはまるコードを記入してください。
<div markdown="1" class="problem-column">
<div markdown="1" class="d-flex justify-content-start">
![](upload/array_spliceコード.png)
![](upload/array_splice結果.png)
</div>
<div markdown="1" class="problem">
<div markdown="1">
<input type="text" value="" autocomplete="off"></input>
</div>
</div>
<details markdown="1"><summary>解答</summary>
array_splice($fruits, 1)
<p class="tmp"><span>書式</span></p>
```
array_splice($削除対象配列名, 削除対象位置　[, 削除数])
```
第三引数の削除数は、指定した値のみ要素を残して、後に続く要素をいくつ残すか指定します。  
単純に第二引数で指定した数値のあとの要素数をいくつ削除するか指定するものではありません。  
※array_splice関数は、削除後の配列の要素数が自動的に詰められます。
</details>
</div>


<span class="bold green fz-12">問題8</span>　同じく$fruits配列のorange要素を削除するよう空欄に当てはまるコードを記入してください。ただし要素番号は詰めない方法で行ってください。
<div markdown="1" class="problem-column">
<div markdown="1" class="d-flex justify-content-start">
![](upload/unsetコード.png)
![](upload/unset結果.png)
</div>
<div markdown="1" class="problem">
<div markdown="1">
<input type="text" value="" autocomplete="off"></input>
</div>
</div>
<details markdown="1"><summary>解答</summary>
unset($fruits[1])
<p class="tmp"><span>書式</span></p>
```
unset($配列[要素番号] [, $配列[要素番号], …)
```
引数
: 1つまたは複数の変数や配列の要素番号を指定します。

返り値
: unset関数には返り値はありません。
</details>
</div>


<span class="bold green fz-12">問題9</span>　問題8の方法で要素を削除した後に要素番号を詰める処理するメソッドを空欄に記入してください。
<div markdown="1" class="problem-column">
<div markdown="1" class="d-flex justify-content-start">
![](upload/array_valuesコード2.png)
![](upload/array_values結果2.png)
</div>
<div markdown="1" class="problem">
<div markdown="1">
<input type="text" value="" autocomplete="off"></input>
</div>
</div>
<details markdown="1"><summary>解答</summary>
array_values
</details>
</div>
