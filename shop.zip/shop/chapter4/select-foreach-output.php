<?php require '../header.php'; ?>
<?php
echo '<p>質問は「', $_REQUEST['question'], '」</p>';
echo '<p>回答は「', $_REQUEST['answer'], '」</p>';
?>
<?php require '../footer.php'; ?>
