---
title: '06. フローティングメニュー'
media_order: 'fixed.png,footer.png,resize.png,static.png,script.js,style.css,index.html'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: blue;}
    .black {color: #000;}
    .large {font-size: 2rem}
    .smp-box {
         margin: 2rem 0 3rem;
    }
    .smp {
        display: inline-block;
        margin-top: 2rem;
        margin-bottom: 0;
        background: #bc495b;
        color: #fff;
        font-size: .75rem;
        font-weight: bold;
        letter-spacing: .3rem;
        padding: .2rem .5rem;
    }
    .tmp {
        background: #026ca2;
        color: #fff;
        font-size: .87rem;
        letter-spacing: .3rem;
        padding: .2rem 1rem;
        white-space: nowrap;
    }
    .dcn {
     font-weight: bold;   
    }
    .gray-box {
     	border: 1px solid gray;
        padding: 20px 30px;
        display: inline-block;
    }
    .w-400 {
      	width: 400px;
     }
    .comment {
      font-style: italic;
      color: green;
      font-size: 1rem;
    }
</style>


##サンプル
<p>スクロールした時、サイドメニューがフローティングに切り替わり、フッタまでいくと手前で止まり一緒にスクロールされます。</p>

<iframe width="100%" height="650" src="//jsfiddle.net/m4rLxz6a/embedded/result,html,css,js,/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


##解説

####1.初期値（サイドメニュー　positon: static）
![初期状態](static.png)

####2.（サイドメニュー　posiion: fixedに切り替え）<br>
青はサイドメニューの外枠の<span class="blue bold">#left-menu</span>の領域。<br>
その上端を**offset().top**で位置を取得。<br>



![fixed](fixed.png)

####3.（サイドメニュー　position: absoluteに切り替え）<br>
黄色はサイドメニューのマージンの領域です。<br>
フッター位置の値よりサイドメニューのマージンを入れた高さとscrollTop()を足した値のほうが大きくなると、サイドメニューをposisition:absolute（クラス名:position-bottom）にしています。
![absolute](footer.png)

####4. サイドメニューの高さが画面の高さより大きくなった場合

（サイドメニュー　posiion: fixedの時）


![absolute](resize.png)

<pre>
<span class="comment">//ブラウザ高さがサイドメニューより小さい時の処理</span>
winNavi = function(){
	
	winH = $(window).height();<span class="comment">//画面高さ取得</span>
	navH = $('#side-nav').outerHeight(true);<span class="comment">//サイドメニューの高さ</span>

	if(navH>winH){

		if ( $('#side-nav').hasClass('position-fixed') ){
			$('#side-nav').removeClass('position-fixed');
		}
		
		if ( $('#side-nav').hasClass('position-bottom') ){
			$('#side-nav').removeClass('position-bottom');
		}
		
	}
}

<span class="comment">//画面をスクロール</span>
$(window).on('scroll', function() {
	sideNav();
	winNavi();
});

<span class="comment">//画面をリサイズ</span>
$(window).on('resize', function() {
	sideNav();
	winNavi();
});
</pre>

下記ののリンクから、リサイズしたときなどの状態を確認できます。<br>
<a href="jquery-foundation-04/index.html" target="_blank">フローティングメニュー</a>（別ウィンドウで開きます。）