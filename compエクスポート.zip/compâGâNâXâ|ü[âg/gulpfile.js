let gulp = require("gulp");
let concat = require('gulp-concat');

gulp.task("default", function() {
  return gulp.src(['src_js/brow_sort.js','src_js/origin_pagenation.js','src_js/announce.js','src_js/view_news.js','src_js/news_cookie.js'])
    .pipe(concat('script.js'))
    .pipe(gulp.dest('js/'));
});
