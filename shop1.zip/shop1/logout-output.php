<?php session_start(); ?>

<?php
echo isset($_SESSION['user']);
if (isset($_SESSION['user'])) {
	unset($_SESSION['user']);
	echo 'ログアウトしました。';
	header('Location:index.php');
} else {
	echo 'すでにログアウトしています。';
	header('Location:index.php');
}
?>