*[page-title]:スニペットの設定

参考サイト
: [VSCodeでスニペットを作成する](https://zenn.dev/yhsi/articles/80c8a030c2761d)
: [Snippets in Visual Studio Code](https://code.visualstudio.com/docs/editor/userdefinedsnippets)

## 設定方法

左下の歯車マークをクリックして、メニューから「ユーザースニペット」を選択します。
![](upload/ユーザースニペットメニュー.png)

一覧から作成したい言語を選択します。ここでは「javascript」を選択しています。
![](upload/一覧からjavascripptを選択.png "図　一覧からjavascripptを選択")

javascriptのsnippetsのファイルが開かれます。デフォルトは、次のようになっています。
![](upload/snippet記述用ファイル.png "図　javascript用snippetファイル（デフォルト）")

例えば、次のようなfetchのテンプレートを作成したい場合、
![](upload/fetch用テンプレートコード.png "図　fetch用テンプレートコード")

snippetsのファイルに次のようにコードを追記します。  
※「`\n`」は改行、「`\t`」はタブインデントの記号になります。
```
{
	"Print to fetch": {
		"prefix": "fetch@",
		"body": [
			"let fd = new FormData();\nfd.append('キー名', '値');\n\nfetch('URL', {\n\tmethod: 'post',\n\tbody: fd,\n}, { cache: 'no-store' })\n\t.then((response) => {\n\t\tif (!response.ok) {\n\t\t\tthrow new Error();\n\t\t}\n\t\treturn response;\n\t})\n\t.then(response => response.text())\n\t.then(data => {\n\n\t})\n\t.catch(() => {\n\t\tconsole.log('エラー')\n\t})"
		],
		"description": "Log output to console"
	}
}
```

追記したら保存します。  
どれかjsファイルを開いて「@fetch」の記述して候補から@fetchを選択します。
![](upload/候補からfetch@を選択.png "図　候補からfetch@を選択")

そうすると、作成したfetchのテンプレート用のコードが挿入されます。
![](upload/fetchコード挿入.png "図　fetchのテンプレート用コード挿入")

こういったように、テンプレート用のコードをsnippetに作成しておくと便利です。