*[page-title]:データをバリデート


一覧ページ
: <http://localhost:7001/php/shop1/index.php>

## 新規登録にバリデート設定

バリデーションにかかって入力画面へ戻ってきた場合に、キーが「<span class="red">name、local、price</span>」のセッション登録があれば、キーのセッション値をvalue値に格納する設定を行います。

<p class="tmp list"><span>リスト</span>insert-input.php</p>
```
<?php
// セッションの開始
session_start();

// ワンタイムトークンの生成
$toke_byte = random_bytes(16);
$token = bin2hex($toke_byte);

// トークンをセッションに保存
$_SESSION['token'] = $token;
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <p><a href="index.php">一覧に戻る</a></p>
    <form class="form-box" action="insert-output.php" method="post">
        <!-- hiddenで生成したトークンを埋め込む -->
        <input type="hidden" name="token" value="<?= $token; ?>">
        <label for="name">商品名</label>
        <input id="name" type="text" name="name" value="<?php if(isset($_SESSION['name'])){echo $_SESSION['name'];} ?>">
        <label for="local">生産地</label>
        <input id="local" type="text" name="local" value="<?php if(isset($_SESSION['local'])){echo $_SESSION['local'];} ?>">
        <label for="price">価格</label>
        <input id="local" type="text" name="price" value="<?php if(isset($_SESSION['price'])){echo $_SESSION['price'];} ?>">
        <input type="submit" value="新規追加">
    </form>
</body>
</html>
```

「<span class="red">空の入力があった時</span>」と「<span class="red">価格に数値以外が入力されていた時</span>」と「<span class="red">新規登録に失敗した時</span>」に、入力画面へ戻って送信した値から再入力できるように設定を行います。

<p class="tmp list"><span>リスト</span>insert-output.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加完了</title>
</head>
<body>
<?php
session_start();

//トークンが存在しないか、セッションのトークンと送信されたトークンの値が一致しない場合は、処理停止。
if (!isset($_POST["token"]) || $_POST["token"] != $_SESSION['token']) {
    echo "<p>不正なリクエストです</p>";
    echo '<p><a href="index.php">一覧に戻る</a></p>';
    exit();
}
    ・・・省略・・・

    //セッションに入力データを登録（追加）
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['local'] = $_POST['local'];
    $_SESSION['price'] = $_POST['price'];

    if(empty($_POST['name']) || empty($_POST['local']) || empty($_POST['price'])){
        //空の入力値がある
        header('Location:insert-input.php');
        exit();

    }elseif (!preg_match('/[0-9]+/', $_POST['price'])) {
        //価格の値に数値以外の入力がされている
        header('Location:insert-input.php');
        exit();

    }elseif ($sql->execute()) {
        //新規登録に成功　セッション削除（追加）
        unset($_SESSION['name']);
        unset($_SESSION['local']);
        unset($_SESSION['price']);

        header('Location:index.php');
        exit();

    } else {
        //新規登録に失敗
        header('Location:insert-input.php');
        exit();
    }
    ?>
</body>
</html>
```

<div markdown="1" class="d-flex">
![](upload/マンゴ価格ねねね.png "図　価格の入力値が数値以外")
![](upload/マンゴ生産地空.png "図　生産地の入力が空")
</div>
　↓
<p>リダイレクトされて同じ入力画面に戻ります。</p>


## エラーメッセージを設定

リダイレクトした時にエラーメッセージを表示させる設定をします。

エラーのチェックはvalidation.phpにまとめておきます。

<p class="tmp list"><span>リスト</span>validation.php</p>
```
<?php
    function validation($request) 
    {
        $errors = [];

        if(empty($_POST['name'])){
            $errors[] = '商品名の入力は必須です。';
        }

        if(empty($_POST['local'])){
            $errors[] = '生産地の入力は必須です。';
        }

        if(empty($_POST['price'])){
            $errors[] = '価格の入力は必須です。';
        }

        if(!preg_match('/[0-9]+/', $_POST['price'])){
            $errors[] = '価格の入力は必須です。';
        }

        return $errors; //$errorsを返す
    }
?>
```

入力画面へ戻った時にエラーメッセージを表示する設定と、成功して一覧に戻った時の成功メッセージも追加します。

<p class="tmp list"><span>リスト</span>insert-output.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加完了</title>
</head>
<body>
<?php
session_start();


//トークンが存在しないか、セッションのトークンと送信されたトークンの値が一致しない場合は、処理停止。
if (!isset($_POST["token"]) || $_POST["token"] != $_SESSION['token']) {
    echo "<p>不正なリクエストです</p>";
    echo '<p><a href="index.php">一覧に戻る</a></p>';
    exit();
}
    ・・・省略・・・

    //セッションに入力データを登録
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['local'] = $_POST['local'];
    $_SESSION['price'] = $_POST['price'];

    //バリデーション
    require 'validation.php';//追加
    $errors = validation($_POST);//追加

    if(!empty($errors)){
        //エラーがある
        $_SESSION['flash']['message'] = $errors;//追加
        header('Location:insert-input.php');//入力画面に戻る
        exit();

    }elseif ($sql->execute()) {
        //新規登録に成功　セッション削除
        unset($_SESSION['name']);
        unset($_SESSION['local']);
        unset($_SESSION['price']);

        $_SESSION['flash']['success'] = '「'.$_POST['name'].'」を新規登録しました。';//追加

        header('Location:index.php');//一覧画面に戻る
        exit();

    } else {
        //新規登録に失敗
        $_SESSION['flash']['message'] = '新規登録に失敗';//追加
        header('Location:insert-input.php');//入力画面に戻る
        exit();
    }
?>
</body>
</html>
```

入力画面に戻った時に、エラーメッセージを表示させる設定です。
<p class="tmp list"><span>リスト</span>insert-input.php</p>
```
<?php
// セッションの開始
session_start();

// ワンタイムトークンの生成
$toke_byte = random_bytes(16);
$token = bin2hex($toke_byte);

// トークンをセッションに保存
$_SESSION['token'] = $token;

//フラッシュメッセージ
if (isset($_SESSION['flash'])) {
    $flash_messages = $_SESSION['flash']['message'];
}
unset($_SESSION['flash']);

if (isset($flash_messages)) {
    echo '<ul class="feedback">';
    foreach ((array)$flash_messages as $message) {
        echo '<li>'. $message .'</li>';
    }
    echo '</ul>';
}
?>

・・・以下省略
```
例として、価格に数値以外を入力した場合、次のようにエラーメッセージが表示されます。
![](upload/価格に数値以外が入力されたときのメッセージ.png "図　価格に数値以外が入力された時のメッセージ"){.photo-border}

一覧画面に戻った時に、成功メッセージを表示させる設定です。
<p class="tmp list"><span>リスト</span>index.php</p>
```
<?php
// セッションの開始
session_start();

//フラッシュメッセージ
if( isset($_SESSION['flash']) ){
	$flash_messages = $_SESSION['flash']['success'];
  }
  unset($_SESSION['flash']);

	if (isset($flash_messages)) {
			echo '<ul class="feedback">';
			foreach ((array)$flash_messages as $message) {
					echo '<li>'. $message .'</li>';
			}
			echo '</ul>';
	}
?>

・・・以下省略
```

いちじくの新規登録が成功すると、次のようにメッセージが表示されます。
![](upload/いちじく新規登録成功.png "図　いちじく新規登録"){.photo-border}

## 数秒後にメッセージを消す

フラッシュメッセージのように、エラーメッセージや成功メッセージが数秒経過すると、ゆっくり消えるように設定します。

<p class="tmp list"><span>リスト</span>js/admin.js</p>
```
if(document.querySelector('.feedback') !== null){
    const FADE_OUT = document.querySelector('.feedback').animate([
            {opacity: 1},// from
            {opacity: 0}// to
        ],
        {//option
            delay: 7000,
            duration: 2000
        }
    )
    //animation終了後の処理
    FADE_OUT.addEventListener('finish', function() {
        document.querySelector('.feedback').remove();
    });
}
```

一覧画面と入力画面にadmin.jsを読み込むように設定します。

<p class="tmp list"><span>リスト</span>index.php/insert-input.php</p>
```
・・・
    if (isset($flash_messages)){
        foreach ((array)$flash_messages as $message){
            echo '<p class="feedback">'.$message.'</p>';//「feedback」クラスを追加
        }
    }
?>
	・・・省略・・・
	<script src="js/admin.js"></script>
</body>
</html>
```

スタイルシートに「.feedback」を追加します。

<p class="tmp list"><span>リスト</span>css/style.css</p>
```
.feedback {
    color: green;
    font-weight: bold;
}
```

これでメッセージが数秒したらゆっくり消えるようになります。

あと、セッションに登録と削除のコードは汎用的に使えるよう、set-session.phpとdelete-session.phpにまとめておきます。
<p class="tmp list"><span>リスト</span>set-session.php</p>
```
<?php
//セッションに入力データを登録
$_SESSION['name'] = $_POST['name'];
$_SESSION['local'] = $_POST['local'];
$_SESSION['price'] = $_POST['price'];
?>
```

<p class="tmp list"><span>リスト</span>delete-session.php</p>
```
<?php
//新規登録に成功　セッション削除
unset($_SESSION['name']);
unset($_SESSION['local']);
unset($_SESSION['price']);
?>
```

<p class="tmp list"><span>リスト</span>insert-outputphp</p>
```
・・・
    $sql->bindValue(':name', $name);
    $sql->bindValue(':local', $local);
    $sql->bindValue(':price', $price);

    //セッション登録（name,local,price）
    require 'set-session.php';//追加

    //バリデーション
    require 'validation.php';
		
・・・

    }elseif ($sql->execute()) {
        //新規登録に成功　セッション削除
        require 'delete-session.php';//追加

        $_SESSION['flash']['success'] = '「'.$_POST['name'].'」を新規登録しました。';

        header('Location:index.php');//一覧画面に戻る
        exit();

    } else {
        //新規登録に失敗
        $_SESSION['flash']['message'] = '新規登録に失敗しました。';
        header('Location:insert-input.php');//入力画面に戻る
        exit();
    }
?>
</body>
</html>
```


## 編集フォームにもバリデートを設定

新規登録と同じように、編集フォームにもバリデートを設定します。

<p class="tmp list"><span>リスト</span>update-input.php</p>
```
<?php
// セッションの開始
session_start();

// ワンタイムトークンの生成
$toke_byte = random_bytes(16);
$token = bin2hex($toke_byte);

// トークンをセッションに保存
$_SESSION['token'] = $token;

//フラッシュメッセージ 追加
if (isset($_SESSION['flash'])) {
    $flash_messages = $_SESSION['flash']['message'];
}
unset($_SESSION['flash']);

if (isset($flash_messages)) {
    foreach ((array)$flash_messages as $message) {
        echo '<p class="feedback">' . $message . '</p>';
    }
}
?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>編集フォーム</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php
    $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8', 'staff', 'password');
    ?>
    <p><a href="index.php">一覧に戻る</a></p>
    <h1>商品編集</h1>
    <table>
        <thead>
            <tr>
                <th>商品名</th>
                <th>生産地</th>
                <th>価格</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = $pdo->prepare('select * from products where id=?');
            $sql->execute([$_GET['id']]);
            foreach ($sql->fetchAll() as $row): ?>
                <form action="update-output.php" method="post">
                    <input type="hidden" name="token" value="<?= $token; ?>">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <td><input type="text" name="name" value="<?php if (isset($_SESSION['name'])) {
                                                                    echo $_SESSION['name'];
                                                                } else {
                                                                    echo $row['name'];
                                                                } ?>"></td>
                    <td><input type="text" name="local" value="<?php if (isset($_SESSION['local'])) {
                                                                    echo $_SESSION['local'];
                                                                } else {
                                                                    echo $row['local'];
                                                                } ?>"></td>
                    <td><input type="text" name="price" value="<?php if (isset($_SESSION['price'])) {
                                                                    echo $_SESSION['price'];
                                                                } else {
                                                                    echo $row['price'];
                                                                } ?>"></td>
                    <td><input type="submit" value="更新"></td>
                </form>
            <?php endforeach ?>
        </tbody>
    </table>
</body>

</html>
<?php require 'delete-session.php'; ?>
```


<p class="tmp list"><span>リスト</span>update-output.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>更新完了</title>
</head>
<body>
<?php
session_start();

//トークンが存在しないか、セッションのトークンと送信されたトークンの値が一致しない場合は、処理停止。
if (!isset($_POST["token"]) || $_POST["token"] != $_SESSION['token']) {
  echo "<p>不正なリクエストです</p>";
  echo '<p><a href="index.php">一覧に戻る</a></p>';
  exit();
}

$pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
$sql=$pdo->prepare('update products set name=:name, local=:local, price=:price where id=:id');

$id = $_POST['id'];
$name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
$local = htmlspecialchars($_POST['local'], ENT_QUOTES, 'UTF-8');
$price = htmlspecialchars($_POST['price'], ENT_QUOTES, 'UTF-8');

//一時的保存にファイルがあるか確認
if (empty($_FILES['image']['tmp_name'])){
    $imgpath = '';
}else{
    $imgpath = $_FILES['image']['name'];        
}

//セッション登録（name,local,price）
require 'set-session.php';

$sql->bindValue(':id', $id);
$sql->bindValue(':name', $name);
$sql->bindValue(':local', $local);
$sql->bindValue(':price', $price);

//バリデーション
require 'validation.php';
$errors = validation($_POST, $imgpath);

if(!empty($errors)){
    //エラーがある
    $_SESSION['flash']['message'] = $errors;
    header('Location:update-input.php?id='.$id);//入力画面に戻る
    exit();

} elseif ($sql->execute()) {
    //新規登録に成功　セッション削除
    require 'delete-session.php';

    $_SESSION['flash']['success'] = '「'.$_POST['name'].'」を更新しました。';

	//更新に成功 リダイレクト
    header('Location:index.php');
    exit();

} else {
    //編集更新に失敗
    $_SESSION['flash']['message'] = '更新に失敗しました。';
    header('Location:update-input.php');//入力画面に戻る
    exit();
}
?>
</body>
</html>
```

これで価格欄を空で送信したりすると、バリデートにかかって編集画面に戻ります。
![](upload/商品編集価格欄空で送信.png){.photo-border}
<span class="arrow-down-24 ml-5"></span>
![](upload/商品編集価格の入力は必須です.png){.photo-border}

