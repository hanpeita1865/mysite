*[page-title]:DBクラスの利用


## DBクラスとは?

Laravelには DBクラス という、基本的なデータベースアクセス用の機能があります。  
DBクラスを使うと、SQLを直接実行してデータを操作できます。

まずは、このDBクラスを使って peopleテーブル にアクセスしてみましょう。

>  👉ポイントは「LaravelのDBクラスを使えば、SQLを直接実行でき、手軽にデータベース操作を始められる」ということです。


### コントローラーの修正

「Http/Controllers/HelloController.php」を開き、クラス内の indexアクションメソッド を指定の内容に変更します。

<p class="tmp list"><span>リスト6-3</span>HelloController.php</p>
```
// use Illuminate\Support\Facades\DB; を追加

public function index(Request $request)
{
  $items = DB::select('select * from people');
  return view('hello.index', ['items' => $items]);
}
```

### テンプレートの修正

内容の説明は後回しにして、まずテンプレートを修正します。  
「views/hello/index.blade.php」を開き、@section('content') の部分を指定の内容に変更します。

<p class="tmp list"><span>リスト6-4</span>views/hello/index.blade.php</p>
```
@section('content')
  <table>
  <tr><th>Name</th><th>Mail</th><th>Age</th></tr>
  @foreach ($items as $item)
    <tr>
      <td>{{$item->name}}</td>
      <td>{{$item->mail}}</td>
      <td>{{$item->age}}</td>
    </tr>
  @endforeach
  </table>
@endsection
```

テンプレートは完成しましたが、テーブル用のスタイルがまだないので、「layouts/helloapp.blade.php」の `<header>` 内 `<style>` タグにテーブル用のスタイルを追加してください。

<p class="tmp list"><span>リスト6-5</span>layouts/helloapp.blade.php</p>
```
th {background-color:#999; color:fff; padding:5px 10px; }
td {border: solid 1px #aaa; color:#999; padding:5px 10px; }
```

これで修正は完了です。終わったら、/helloにアクセスしてください。  
先ほどpeopleテーブルに追加したダミーレコードがテーブルに一覧表示されます。
![](upload/DBクラスpeopleテーブル表示.png){.photo-border}


### DB:selectの利用

では、データベースにアクセスしている部分を見てみましょう。今回は、以下のような文を実行しているのがわかります。
```
$items = ĐB :: select('select * from people');
```
ここで使っている「DB:select」というのが、データベースからレコードのデータを取り出すための処理です。DB :: selectは、DBクラスにある静的メソッドで、以下のように呼び出します。
<p class="tmp"><span>書式</span></p>
```
$変数=DB :: select( 実行するSQL文);
```
DB::select は、SQL の select 文を実行し、レコードを取得するためのメソッドです。引数にSQL文を文字列で渡すと、結果のレコードが戻り値として返されます。

### テンプレートの処理

DB::select の戻り値は「レコードをまとめたオブジェクトの配列」です。テンプレートでは
```
@foreach ($items as $item)
   {{ $item->name }}
@endforeach
```
のように1件ずつ取り出して値を表示します。つまり、「**DB::select で配列として取得 → テンプレートで繰り返し処理 → フィールドの値を出力**」、という流れで簡単にデータを表示できます。

SQLを理解していれば最もシンプルな方法です。


## パラメーター結合の利用

複雑な検索ではSQL文の作成が大変なので、「パラメーター結合」を使うと便利です。  
これはSQL文に文字列とパラメーター配列を組み合わせて簡単に記述する方法です。  
実際に使うには、HelloControllerのindexアクションを修正して試します。

<p class="tmp list"><span>リスト6-6</span>HelloController.php</p>
```
public function index(Request $request)
{
  if (isset($request->id))
  {
    $param = ['id' => $request->id];
    $items = DB::select('select * from people where id = :id', $param);
  } else {
    $items = DB::select('select * from people');
  }
  return view('hello.index', ['items' => $items]);
}
```
修正後に /hello?id=番号 でアクセスすると、そのIDのレコードだけが表示されます。  
パラメーターを付けずに /hello とアクセスすると、これまで通り全レコードが表示されます。
![](upload/DBクラスid_2を表示.png){.photo-border}

### パラメーター結合の働き

クエリ文字列に id があれば、
```
$param = ['id' => $request->id];
$items = DB::select('select * from people where id = :id', $param);
```
のように パラメーター配列 を作り、:id という プレースホルダー に値をはめ込んでSQLを実行します。  
プレースホルダーは複数使えるので、入力値などを組み合わせたSQLも簡単に作成できます。


## DB :: insertによるレコード作成

DB::select はレコード取得専用ですが、データ追加には DB::insert を使います。

書き方は次の通りです。
<p class="tmp"><span>書式</span></p>
```
DB::insert('insert into ...', [パラメーター配列]);
```
DB::insert はレコードを返さないので、戻り値は不要です。  
実際には /hello/add アクションを作り、フォーム送信でデータを保存できるようにします。

### add.blade.phpの作成

まずは、テンプレートです。今回は、新しいテンプレートファイルを作成しましょう。  
「views」内の「hello」フォルダーの中に、新たに「add.blade.php」というファイルを作成してください。そして以下のようにソースコードを記述しておきましょう。

<p class="tmp list"><span>リスト6-7</span>views/hello/add.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Add')

@section('menubar')
  @parent
  新規作成ページ
@endsection

@section('content')
  <form action="/hello/add" method="post">
    @csrf
    <label for="name">name:</label>
    <div><input type="text" name="name"></div>
    <label for="mail">mail:</label>
    <div><input type="text" name="mail"></div>
    <label for="age">age:</label>
    <div><input type="number" name="age"></div>
    <div><input type="submit" value="send"></div>
  </form>
@endsection

@section('footer')
copyright 2025 tuyano.
@endsection
```

フォームを /hello/add に送信して新規レコードを作成します。  
その際、フォームの見た目を整えるために、helloapp.blade.php の `<style>` 内にCSSを追加します。

<p class="tmp list"><span>リスト6-8</span>layouts/helloapp.blade.php</p>
```
label {margin: 0px; font-size:16px; }
input {padding:5px 10px; margin:2px; }
button {padding:5px 20px; margin:2px;}
```

これでフォームもある程度整った形で表示されるようになります。

### HelloControllerの修正

では、HelloController クラスを修正しましょう。先ほどの indexとpostはそのまま残し、新たにaddとcreateメソッドを追加することにします。わかりやすいように、クラス全体のソースコードを掲載しておきます。

<p class="tmp list"><span>リスト6-9</span>HelloController.php</p>
```
class HelloController extends Controller
{
  public function index(Request $request)
  {
    $items = DB::select('select * from people');
    return view('hello.index', ['items' => $items]);
  }

  public function post(Request $request)
  {
    $items = DB::select('select * from people');
    return view('hello.index', ['items' => $items]);
  }

  public function add(Request $request)
  {
    return view('hello.add');
  }

  public function create(Request $request)
  {
    $param = [
      'name' => $request->name,
      'mail' => $request->mail,
      'age' => $request->age,
    ];
    DB::insert('insert into people (name, mail, age) values (:name, :mail, :age)', $param);
    return redirect('/hello');
  }

}
```

フォームから送信された値を配列 $param にまとめ、
それを使って DB::insert を実行し、新しいレコードを追加します。
```
$param = [
  'name' => $request->name,
  'mail' => $request->mail,
  'age'  => $request->age,
];

DB::insert('insert into people (name, mail, age) values (:name, :mail, :age)', $param);
```

処理が終わったら redirect('/hello') で一覧ページに戻ります。

まとめると、新規作成は次の流れです。

1. フォームの値を取得
2. DB::insert で保存
3. /hello へリダイレクト


### ルート情報の追加

最後に、/hello/addのルート情報を追加しておきましょう。web.phpを開き、その末尾に以下の文を追記してください。
<p class="tmp list"><span>リスト6-10</span>web.php</p>
```
Route::get('hello/add', [HelloController::class, 'add']);
Route::post('hello/add', [HelloController::class, 'create']);
```

これで完成です。/hello/addにアクセスし、フォームに入力して送信すると、その内容が新しいレコードとしてテーブルに保存されます。そのまま/helloにリダイレクトされるので、表示されるレコードの一覧をチェックし、新しくレコードが保存されていることを確認しましょう。

<div markdown="1" class="d-flex">
![](upload/jiroをaddで追加.png){.photo-border}
<span class="arrow-right mt-5"></span>
![](upload/jiroをaddで追加完了.png){.photo-border}
</div>


## DB :: update による更新

レコードの更新には SQL の update 文 を使い、Laravel では DB::update メソッドを利用します。  
使い方は DB::insert とほぼ同じで、違うのはクエリー文の内容だけです。
<p class="tmp"><span>書式</span></p>
```
DB::update(クエリー文, パラメーター配列);
```

実際の処理は /hello/edit アクションで行います。

👉 まとめると：

1. 更新処理は DB::update を使用
2. 使い方は DB::insert と同じ
3. 実際の処理は /hello/edit に用意する


### ledit.blade.phpの作成

まずテンプレートを用意しましょう。「views」内の「hello」フォルダー内に、新たに「edit.blade.php」というファイルを作成してください。ソースコードは以下のようにしておきます。

<p class="tmp list"><span>リスト6-11</span>views/hello/edit.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Edit')

@section('menubar')
  @parent
  更新ページ
@endsection

@section('content')
  <form action="/hello/edit" method="post">
    @csrf
    <input type="hidden" name="id" value="{{$form->id}}">
    <label for="name">name:</label>
    <div><input type="text" name="name" value="{{$form->name}}"></div>
    <label for="mail">mail:</label>
    <div><input type="text" name="mail" value="{{$form->mail}}"></div>
    <label for="age">age:</label>
    <div><input type="number" name="age" value="{{$form->age}}"></div>
    <div><input type="submit" value="send"></div>
  </form>
@endsection

@section('footer')
copyright 2025 tuyano.
@endsection
```

更新用フォームでは、各入力欄に $form の値を value 属性に設定 して、編集対象のデータを表示できるようにしています。  
さらに、更新時にどのレコードを修正するか特定するため、非表示フィールドにIDを保持 しています。
```
<input type="hidden" name="id" value="{{$form->id}}">
```

👉 まとめると：

* フォームの初期値に $form のデータを設定して表示
* レコードを特定するため、必ず ID を非表示フィールドで送信する


### edit/updateアクションの追加

続いて、HelloControllerにアクションメソッドを追加します。今回は、edit と updateという2つのアクションメソッドをクラスに追加することにしましょう。

<p class="tmp list"><span>リスト6-12</span>HelloController.php</p>
```
public function edit(Request $request)
{
  $param = ['id' => $request->id];
  $item = DB::select('select * from people where id = :id', $param);
  return view('hello.edit', ['form' => $item[0]]);
}

public function update(Request $request)
{
  $param = [
    'id' => $request->id,
    'name' => $request->name,
    'mail' => $request->mail,
    'age' => $request->age,
  ];
  DB::update('update people set name =:name, mail = :mail, age = :age where id = :id', $param);
  return redirect('/hello');
}
```

edit アクションでは、クエリー文字列から受け取った ID を使って、更新対象のレコードを DB::select で取得し、$form としてテンプレートに渡しています。

更新用の SQL 文は次のような形です：
```
update people set name = :name, mail = :mail, age = :age where id = :id
```

ポイント：
* set の後に更新する項目と値を指定
* where で更新対象のレコードを ID で指定
* これにより、指定した ID のレコードの値が更新されます


### /hello/editを試す

これで更新の処理そのものは用意できました。最後にweb.phpにルート情報を以下のように記述しておきましょう。
<p class="tmp list"><span>リスト6-13</span>web.php</p>
```
Route::get('hello/edit', [HelloController::class, 'edit']);
Route::post('hello/edit', [HelloController::class, 'update']);
```

/hello/edit?id=1 のようにアクセスすると、指定した ID のレコードが表示され、フォームで内容を編集して送信するとそのレコードが更新されます。

<div markdown="1" class="d-flex align-items-center">
![](upload/edit_taroをタローに変更.png){.photo-border}
<span class="arrow-right mt-5"></span>
![](upload/edit_taroをTAROに変更完了.png){.photo-border}
</div>


## DB :: deleteによる削除

<p class="tmp"><span>書式</span></p>
```
DB :: delete( クエリー文,パラメーター配列);
```

レコード削除は DBクラスの delete メソッドで行い、SQL の delete from テーブル where ～ を実行して条件に合うレコードを削除します。使い方は他のメソッドと同じです。


### del.blade.phpの作成

まずはテンプレートからです。「views」内の「hello」フォルダー内に「del.blade.php」という名前でファイルを作成しましょう。そして以下のように記述しておきます。

<p class="tmp list"><span>リスト6-14</span>del.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Delete')

@section('menubar')
   @parent
   削除ページ
@endsection

@section('content')
  <table>
    <tr><th>name: </th><td>{{$form->name}}</td></tr>
    <tr><th>mail: </th><td>{{$form->mail}}</td></tr>
    <tr><th>age: </th><td>{{$form->age}}</td></tr>
  </table>
  <form action="/hello/del" method="post">
    @csrf
    <input type="hidden" name="id" value="{{$form->id}}">
    <div><input type="submit" value="send"></div>
  </form>

@endsection

@section('footer')
copyright 2025 tuyano.
@endsection
```

フォームでは削除するレコードの IDだけを送信します。実際の内容はテーブルで表示し、確認したうえで「削除」ボタンを押す仕組みです。


### del/removeアクションの追加

続いて、コントローラーへのアクションメソッドの追加です。今回は、delとremoveというメソッドとして追加することにしましょう。

<p class="tmp list"><span>リスト6-15</span>HelloController.php</p>
```
public function del(Request $request)
{
  $param = ['id' => $request->id];
  $item = DB::select('select * from people where id = :id', $param);
  return view('hello.del', ['form' => $item[0]]);
}

public function remove(Request $request)
{
  $param = ['id' => $request->id];
  DB::delete('delete from people where id = :id', $param);
  return redirect('/hello');
}
```

削除処理は更新処理（edit）と似ており、まずIDでレコードを取得してフォームに表示します。実際の削除は remove で行い、
```
delete from people where id = :id
```
というSQLで指定IDのレコードを消します。削除はIDさえ分かればできるので更新より簡単です。


### 削除を実行する

最後に、web.phpにルーティングの情報を追記して完成させましょう。

<p class="tmp list"><span>リスト6-16</span>web.php</p>
```
Route::get('hello/del', [HelloController::class, 'del']);
Route::post('hello/del', [HelloController::class, 'remove']);
```

/hello/delアクションに、idパラメーターをつけてアクセスしてみてください(/hello/del?id=4といった具合)。そのレコードの内容が表示されます。そのまま送信ボタンを押せば、そのレコードが削除されます。

![](upload/peopleテーブルdel実行前.png "図　peopleテーブルデータ del実行前"){.photo-border}

<div markdown="1" class="d-flex">
![](upload/id4_del表示.png "図　削除するデータを表示"){.photo-border}
<span class="arrow-right mt-5"></span>
![](upload/id4_del実行結果.png "図　id=4のデータが削除されました"){.photo-border}
</div>


<div markdown="1" class="note-box">
##### SQLクエリーがすべて?

これでデータベース操作の基本である CRUD（作成・読み取り・更新・削除） ができるようになり、アプリを作れるようになりました。 ただし今の方法はSQL文を直接書く形で、あまりスマートではありません。PHPらしい書き方として「クエリービルダー」という仕組みが用意されています。
</div>