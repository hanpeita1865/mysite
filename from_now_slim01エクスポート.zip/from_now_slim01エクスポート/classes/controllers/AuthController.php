<?php
// namespace App\Controllers;

// use Psr\Http\Message\ResponseInterface as Response;
// use Psr\Http\Message\ServerRequestInterface as Request;
// use Slim\Views\Twig;

// class AuthController {
//     private Twig $view;

//     public function __construct(Twig $view) {
//         $this->view = $view;
//     }

//     // ログインフォームを表示
//     public function showLoginForm(Request $request, Response $response): Response {
//         return $this->view->render($response, 'login.twig');
//     }

//     // ログイン処理
//     public function login(Request $request, Response $response): Response {
//         $data = $request->getParsedBody();

//         $username = $data['username'] ?? '';
//         $password = $data['password'] ?? '';

//         // 仮ユーザーデータ（本来はDBから取得）
//         $validUser = 'admin';
//         $validPass = 'pass123';

//         if ($username === $validUser && $password === $validPass) {
//             if (session_status() === PHP_SESSION_NONE) session_start();

//             $_SESSION['fromUser'] = $username;

//             // ログイン後の遷移先
//             $redirectUrl = $_GET['url'] ?? '/admin';
//             return $response
//                 ->withHeader('Location', $redirectUrl)
//                 ->withStatus(302);
//         }

//         // ログイン失敗
//         return $this->view->render($response, 'login.twig', [
//             'error' => 'ユーザー名またはパスワードが違います。'
//         ]);
//     }

//     // ログアウト処理
//     public function logout(Request $request, Response $response): Response {
//         if (session_status() === PHP_SESSION_NONE) session_start();
//         session_destroy();

//         return $response
//             ->withHeader('Location', '/login')
//             ->withStatus(302);
//     }
// }


namespace SocymSlim\SlimMiddle\controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Views\Twig;

class AuthController {
    private Twig $view;

    public function __construct(Twig $view) {
        $this->view = $view;
    }

    // ログインフォームを表示
    public function showLoginForm(Request $request, Response $response): Response {
        return $this->view->render($response, 'login.twig');
    }

    // ログイン処理
    public function login(Request $request, Response $response): Response {
        $data = $request->getParsedBody();

        $username = $data['username'] ?? '';
        $password = $data['password'] ?? '';

        // 仮ユーザーデータ（本来はDBから取得）
        $validUser = 'admin';
        $validPass = 'pass123';

        if ($username === $validUser && $password === $validPass) {
            if (session_status() === PHP_SESSION_NONE) session_start();

            $_SESSION['fromUser'] = $username;

            // ログイン後の遷移先
            $redirectUrl = $_GET['url'] ?? '/admin';
            return $response
                ->withHeader('Location', $redirectUrl)
                ->withStatus(302);
        }

        // ログイン失敗
        return $this->view->render($response, 'login.twig', [
            'error' => 'ユーザー名またはパスワードが違います。'
        ]);
    }

    // ログアウト処理
    public function logout(Request $request, Response $response): Response {
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_destroy();

        return $response
            ->withHeader('Location', '/login')
            ->withStatus(302);
    }
}