---
title: 基礎文法
media_order: 'cmd_01.png,cmd_02.png,cmd_03.png,cmd_04.png,cmd_05.png,cmd_06.png,dir_01.png,dir_02.png,dir_03.png,dir_04.png,pycode2.png,pycode1.png'
taxonomy:
    category:
        - docs
visible: true
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:12px 0 12px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
</style>


## 目次

1. [変数、数値、文字列](bacic-preparation02)
2. [リスト](bacic-preparation03)  ← JSでは、配列のこと
4. [制御構文](bacic-preparation04)
5. [関数の定義と変数のスコープ](bacic-preparation05)
6. [タプル](bacic-preparation06)  ← JSでは、配列のこと
7. [集合](bacic-preparation07)  ← JSでは、配列のこと
8. [辞書](bacic-preparation08)  ← JSでは、オブジェクトのこと
9. [内包表記](bacic-preparation09)
10. [ジェネレータ式](bacic-preparation10)
11. [オブジェクト指向プログラミング](bacic-preparation11)
12. [発展的な機能](bacic-preparation12)