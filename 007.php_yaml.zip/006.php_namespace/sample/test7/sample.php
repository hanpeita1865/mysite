<?php
require_once 'greeting.php';
use const Asia\Japan\Kanto\Tokyo\Hello;

echo Hello; // 出力結果：やあ、こんにちは