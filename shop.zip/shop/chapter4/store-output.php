<?php require '../header.php'; ?>
<?php
echo '店舗コードは', $_REQUEST['code'], 'です。';
?>
<?php require '../footer.php'; ?>
