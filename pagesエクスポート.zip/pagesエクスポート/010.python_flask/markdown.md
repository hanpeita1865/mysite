*[page-title]:Flask


参考サイト
: [【Python】Flaskとは？FlaskでWeb開発の基礎を学ぼう！](https://aiacademy.jp/media/?p=57)
: [【Python Flask】初心者プログラマーのWebアプリ#1 簡単なページ作成](https://qiita.com/Bashi50/items/30065e8f54f7e8038323)


## はじめに

### Flaskとは

Flask（フラスコ/フラスク）とは、PythonのWebアプリケーションフレームワークで、小規模向けの簡単なWebアプリケーションを作るのに適しています。
Webフレームワークとは、ウェブサイトやウェブアプリケーションを作るための機能を提供し、ウェブフレームワークを使わない時よりもより容易にWebアプリケーションを作ることができるものです。


### 設定

Flaskをインストールをします。
<p class="tmp cmd"><span>コマンド</span>Flaskインストール</p>
```
pip install flask
```

## 簡単なアプリ

作業場所
: C:\xampp\htdocs\test\python\flask

![](upload/flask_serverフォルダ構成.png "図　フォルダ構成")

<p class="tmp list"><span>リスト</span>server.py</p>
```
from testapp import app

if __name__ == '__main__':
    app.run(debug=True)
```

<p class="tmp list"><span>リスト</span>testaapp/views.py</p>
```
from testapp import app

@app.route('/')
def index():
    return 'Hellow World!'
```

<p class="tmp list"><span>リスト</span>testapp/__init__.py</p>
```
from flask import Flask

app = Flask(__name__)

import testapp.views
```

server.pyをターミナルで実行します。
![](upload/Flask_server.pyを実行.png)

<http://127.0.0.1:5000/>にアクセスして、「Hellow World!」が表示されればOKです。
![](upload/5000にアクセスするとHelloWorldが表示.png){.photo-border}


次のコードを追加して、<http://127.0.0.1:5000/test>にアクセスすると「テストページです！」が表示されます。
<p class="tmp list"><span>リスト</span>views.py</p>
```
・・・

@app.route('/test')
def other1():
    return "テストページです！"
```

![](upload/テストページですが表示されます.png){.photo-border}



## データを受け取る

参考サイト
: [PHPとPythonの組み合わせ: ユースケースと実装方法](https://pythonjp.ikitai.net/entry/2024/02/14/024757)


### Pythonのファイルからデータを受け取る

pythonの`data = {'key1': 'value1'}`の値をPHPでリクエストしたページで受け取ってJsonから配列に変換して表示しています。  

※PythonでAPIを作成し、それをPHPから呼び出してデータを取得しています。

<p class="tmp list"><span>リスト</span>date.py</p>
```
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/data')
def get_data():
    data = {'key1': 'value1'}
    return jsonify(data)

if __name__ == '__main__':
    app.run()
```

<p class="tmp list"><span>リスト</span>index.php</p>
```
<?php
$url = 'http://localhost:5000/data';
$data = json_decode(file_get_contents($url), true);
print_r($data);
?>
```



ターミナルからdata.pyを実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
python data.py
```

<http://localhost:7001/test/python/flask/sample1/>にアクセスすると、次のように表示されます。

![](upload/data.pyからデータを受け取る.png){.photo-border}


