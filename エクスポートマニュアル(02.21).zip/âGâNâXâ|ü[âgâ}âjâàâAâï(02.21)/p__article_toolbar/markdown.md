*[page-title]:ツールバー説明

![](upload/ツールバーまとめ.png "図　ツールバー一覧")


| アイコン | 名称 | 機能 |
| -------- | -------- | -------- |
| ![](upload/undo.png)     | Undo      | 操作の取り消し     |
| ![](upload/redo.png)    | Redo      | 操作のやり直し（Undoした内容を元に戻す）     |
| ![](upload/heading.png)    | Headindg      | 見出しを選択する     |
| ![](upload/bold.png)     | Bold      | 太字にする     |
|![](upload/strikethrouth.png)     | Strikethrouth      | 打ち消し線をつける  |
| ![](upload/subscript.png)    | Subscript      | 下付き文字をつける    |
| ![](upload/superscript.png)    | Superscript      | 上付き文字をつける    |
| ![](upload/fontsize.png)     | Font Size     | 文字サイズを変更する     |
| ![](upload/fontcolor.png)     | Font Color      | 文字の色を設定する     |
| ![](upload/fontbackcolor.png)    | Font Background Color     | 文字の背景色を設定する     |
| ![](upload/highlight.png)    | Highlight      | 文字にマーカーを設定する。    |
| ![](upload/text_align.png)    | Text alignment     | 文字の横配置位置を設定する     |
| ![](upload/list.png)     | Bulleted List    | 箇条書きリスト（&lt;ul&gt;タグ）を追加する    |
| ![](upload/number_list.png)     | Numbered List    | 番号付きリスト（&lt;ol&gt;タグ）を追加する   |
| ![](upload/indent取消.png)    | Decrease Indent     | インデントを削除する     |
| ![](upload/indent.png)    | Increase Indent      | インデントを設定する     |
| ![](upload/findreplace.png)    | Find and replace      | 検索と置換を実行する    |
|   ![](upload/allselect.png)  | Select all      | 全て選択する    |
| ![](upload/link.png)     | Link      | リンクを挿入する     |
| ![](upload/block_quart.png)     | Block quate     | Block quateを設置します    |
| ![](upload/table.png)    | Insert table      | テーブルを挿入します    |
| ![](upload/movie.png)   | insert madia      | 動画を挿入します     |
| ![](upload/horizen_line.png)    | Horizonral line    | 水平線を追加します     |
| ![](upload/source.png)    | Source      | HTMLコードを表示します    |

