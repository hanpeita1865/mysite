<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MarkdownService,
};

require '../admin/basepath.php';


class PreviewController
{
    private EditService $editService;
    private FolderService $folderService;
    private MarkdownService $markdownService;
    private $container;

    
    public function __construct(EditService $editService, FolderService $folderService, MarkdownService $markdownService, ContainerInterface $container)
    {
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->markdownService = $markdownService;
        $this->container = $container;        
    }

    public function previewData(Request $request, Response $response, array $args): Response
    {
        $config = $this->container->get('config');
        $basePath = $config['basePath'];       

        $folderObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）

        $markData = $this->markdownService->getPreviewMarkData($folderObj);//サービス

        $htmlData = $markData['html'];
        $title = $markData['title'];

        $assign["folderObj"] = $folderObj;
        $assign["pathBase"] = $basePath;
        $assign["htmlData"] = $htmlData;
        $assign["title"] = $title;

        $twig = $this->editService->view();

        $response = $twig->render($response, "preview.twig", $assign);

        return $response;
    }
}
