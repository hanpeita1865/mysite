<?php
function hello()
{
    return 'こんにちは';
}
