Vue.createApp({
  data() {
    return {
      agree : true
    };
  }
}).mount('#app');