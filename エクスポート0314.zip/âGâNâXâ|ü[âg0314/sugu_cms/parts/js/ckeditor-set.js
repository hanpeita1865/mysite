//CKeditor用
CKEDITOR.ClassicEditor.create(document.getElementById("body"), {
    fontColor: {
        colors: [
            {
                color: 'hsl(0, 10%, 0%)',
                label: 'Black'
            },
            {
                color: 'hsl(0, 0%, 30%)',
                label: 'Dim grey'
            },
            {
                color: 'hsl(0, 0%, 60%)',
                label: 'Grey'
            },
            {
                color: 'hsl(0, 0%, 90%)',
                label: 'Light grey'
            },
            {
                color: 'hsl(0, 0%, 100%)',
                label: 'White',
                hasBorder: true
            },
            {
                color: 'hsl(0, 99%, 30%)',
                label: 'Red'
            },
            {
                color: 'hsl(30, 75%, 70%)',
                label: 'Orange'
            },
            {
                color: 'hsl(45, 100%, 51%)',
                label: 'Yellow'
            },
            {
                color: 'hsl(131, 64%, 41%)',
                label: 'Green'
            },
            {
                color: 'hsl(150, 75%, 70%)',
                label: 'Aquamarine'
            },
            {
                color: 'hsl(180, 75%, 70%)',
                label: 'Turquoise'
            },
            {
                color: 'hsl(210, 75%, 70%)',
                label: 'Light blue'
            },
            {
                color: 'hsl(211, 100%, 50%)',
                label: 'Blue'
            },
            {
                color: 'hsl(264, 39%, 51%)',
                label: 'Purple'
            }
            // More colors.
            // ...
        ]
    },
    fontBackgroundColor: {
        //... // Font background color feature configuration.
        //const fontBackgroundColorConfig = {
            colors: [
                // {
                //     color: 'hsl(0, 0%, 0%)',
                //     label: 'Black'
                // },
                {
                    color: 'hsl(0, 0%, 30%)',
                    label: 'Dim grey'
                },
                {
                    color: 'hsl(0, 0%, 60%)',
                    label: 'Grey'
                },
                {
                    color: 'hsl(0, 0%, 90%)',
                    label: 'Light grey'
                },
                {
                    color: 'hsl(0, 0%, 100%)',
                    label: 'White',
                    hasBorder: true
                },
                {
                    color: 'hsl(0, 75%, 70%)',
                    label: 'Red'
                },
                {
                    color: 'hsl(30, 75%, 70%)',
                    label: 'Orange'
                },
                {
                    color: 'hsl(60, 92%, 59%)',
                    label: 'Yellow'
                },
                {
                    color: 'hsl(90, 100%, 68%)',
                    label: 'Light green'
                },
                {
                    color: 'hsl(120, 75%, 70%)',
                    label: 'Green'
                },
                {
                    color: 'hsl(150, 75%, 70%)',
                    label: 'Aquamarine'
                },
                {
                    color: 'hsl(180, 75%, 70%)',
                    label: 'Turquoise'
                },
                {
                    color: 'hsl(210, 75%, 70%)',
                    label: 'Light blue'
                },
                {
                    color: 'hsl(240, 100%, 82%)',
                    label: 'Blue'
                },
                {
                    color: 'hsl(270, 100%, 82%)',
                    label: 'Purple'
                }
            ]
        //}
    },
    highlight: {
        options: [
            {
                model: 'yellowMarker',
                class: 'marker-yellow',
                title: 'Yellow marker',
                color: 'var(--ck-highlight-marker-yellow)',
                type: 'marker'
            },
            {
                model: 'greenMarker',
                class: 'marker-green',
                title: 'Green marker',
                color: 'var(--ck-highlight-marker-green)',
                type: 'marker'
            },
            {
                model: 'pinkMarker',
                class: 'marker-pink',
                title: 'Pink marker',
                color: 'var(--ck-highlight-marker-pink)',
                type: 'marker'
            },
            {
                model: 'blueMarker',
                class: 'marker-blue',
                title: 'Blue marker',
                color: 'var(--ck-highlight-marker-blue)',
                type: 'marker'
            },
            {
                model: 'PurpleMarker',
                class: 'marker-purple',
                title: 'Purple marker',
                color: 'var(--ck-highlight-marker-purple)',
                type: 'marker'
            },
            {
                model: 'GrayMarker',
                class: 'marker-gray',
                title: 'Gray marker',
                color: 'var(--ck-highlight-marker-gray)',
                type: 'marker'
            },
        ]
    },
    image: {
        resizeUnit: "%",
        resizeOptions: [ 
            {
                name: 'resizeImage:original',
                value: null
            },
            {
                name: 'resizeImage:30',
                value: '30'
            },
            {
                name: 'resizeImage:35',
                value: '35'
            },
            {
                name: 'resizeImage:40',
                value: '40'
            },
            {
                name: 'resizeImage:45',
                value: '45'
            },
            {
                name: 'resizeImage:50',
                value: '50'
            },
            {
                name: 'resizeImage:55',
                value: '55'
            },
            {
                name: 'resizeImage:60',
                value: '60'
            },
            {
                name: 'resizeImage:65',
                value: '65'
            },
            {
                name: 'resizeImage:70',
                value: '70'
            },
            {
                name: 'resizeImage:75',
                value: '75'
            },
            {
                name: 'resizeImage:80',
                value: '80'
            }, 
            {
                name: 'resizeImage:85',
                value: '85'
            },
            {
                name: 'resizeImage:90',
                value: '90'
            },  
            {
                name: 'resizeImage:95',
                value: '95'
            },  
        ]
    },
    toolbar: {
        items: [
            'undo', 'redo', '|',
            'heading', '|',
            'bold', 'strikethrough', 'underline', 'subscript', 'superscript', 'removeFormat','|',
            'fontSize', 'fontColor', 'fontBackgroundColor', 'highlight', '|',
            'alignment', '|',
            'bulletedList', 'numberedList', '|',
            'outdent', 'indent', '|',
            'findAndReplace', 'selectAll', '|',
            'link', /*'insertImage',*/ 'blockQuote', 'insertTable', 'mediaEmbed', '|',
            'specialCharacters', 'horizontalLine', '|',
            'sourceEditing', '|',
        ],
        shouldNotGroupWhenFull: true
    },
    // Changing the language of the interface requires loading the language file using the <script> tag.
    // language: 'es',
    list: {
        properties: {
            styles: true,
            startIndex: true,
            reversed: true
        }
    },
    // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
    heading: {
        options: [
            { model: 'paragraph', title: 'paragraph', class: 'ck-heading_paragraph' },
            {
                model: 'heading2',
                view: {
                    name: 'h2',
                    classes: 'heading2'
                },
                title: '見出しH2',
                class: 'ck-heading_heading2'
            },
            {
                model: 'heading3-1',
                view: {
                    name: 'h3',
                    classes: 'heading3'
                },
                title: '見出しH3',
                class: 'ck-heading_heading3'
            },
            {
                model: 'heading4-1',
                view: {
                    name: 'h4',
                    classes: 'heading4'
                },
                title: '見出しH4',
                class: 'ck-heading_heading4'
            },
            {
                model: 'heading5-1',
                view: {
                    name: 'h5',
                    classes: 'heading5'
                },
                title: '見出しH5',
                class: 'ck-heading_heading5'
            },
            {
                model: 'heading6-1',
                view: {
                    name: 'h6',
                    classes: 'heading6'
                },
                title: '見出しH6',
                class: 'ck-heading_heading6'
            },
            // {
            //     model: 'picture-grid',
            //     view: {
            //         name: 'paragraph',
            //         classes: 'picture-grid'
            //     },
            //     title: '画像横並び(picture-grid)',
            //     class: 'picture-grid'
            // }
        ]
    },
    placeholder: '入力してください。',
    fontSize: {
        options: [12, 14, 'default', 18, 20, 22, 24],
        supportAllValues: true
    },
    htmlSupport: {
        allow: [
            {
                name: /.*/,
                attributes: true,
                classes: true,
                styles: true
            }
        ]
    },
    link: {
        addTargetToExternalLinks: true,
    },
    mention: {
        feeds: [
            {
                marker: '@',
                feed: [
                    '@apple', '@bears', '@brownie', '@cake', '@cake', '@candy', '@canes', '@chocolate', '@cookie', '@cotton', '@cream',
                    '@cupcake', '@danish', '@donut', '@dragée', '@fruitcake', '@gingerbread', '@gummi', '@ice', '@jelly-o',
                    '@liquorice', '@macaroon', '@marzipan', '@oat', '@pie', '@plum', '@pudding', '@sesame', '@snaps', '@soufflé',
                    '@sugar', '@sweet', '@topping', '@wafer'
                ],
                minimumCharacters: 1
            }
        ]
    },
    removePlugins: [
        'CKBox',
        'CKFinder',
        'EasyImage',
        'RealTimeCollaborativeComments',
        'RealTimeCollaborativeTrackChanges',
        'RealTimeCollaborativeRevisionHistory',
        'PresenceList',
        'Comments',
        'TrackChanges',
        'TrackChangesData',
        'RevisionHistory',
        'Pagination',
        'WProofreader',
        'MathType'
    ]
})
    .then(newEditor => {
        editor = newEditor;
        let editorData = editor.getData();
        editorData = editorData.replace('<p>{{{</p>', '').replace('<p>}}}</p>', '').replace('<p>{{{}}}</p>', '');
        editorData = editorData.trim();
        editor.setData(editorData);


        //記事に画像を挿入
        document.querySelectorAll('.insert-image').forEach(function (elm) {
            elm.addEventListener('click', function (e) {
                let href = e.target.closest('.sugu-control-group').querySelector('.current_image').getAttribute('href');
                editor.execute('insertImage', { source: href });
                alert('画像を本文内に挿入しました。')
            });
        });

        const regexp = new RegExp(/.jpg$|.jpeg$|.jpe$|.jfif$|.png$|.gif$|.svgx$|webp$/i);

        //記事に画像を挿入（添付用コントロール）
        document.querySelectorAll('.insert-tenpu').forEach(function (elm) {

            let id = elm.getAttribute('data-id');//current_file_数値
            let href = document.getElementById(id).getAttribute('href');
            let fileTextId = id.replace('current_file_', 'current_file_text,');//ファイル名欄
            let fileLinkId = id.replace('current_file_', 'current_file_link,');//ファイルリンク欄
            let fileCurrent = id.replace('current_file_', 'file_current_');//親ボックス

            //画像以外か判定
            if (regexp.test(href)) {
                //画像の場合、「挿入ボタン」を表示、ファイルリンクを非表示
                let filename = document.getElementById(fileTextId).value;
                elm.classList.add('d-block');
                document.getElementById(fileTextId).classList.add('d-none');
                document.getElementById(fileTextId).previousElementSibling.classList.add('d-none');
                document.getElementById(fileLinkId).classList.add('d-none');
                document.getElementById(fileLinkId).previousElementSibling.classList.add('d-none');

                document.getElementById(fileCurrent).querySelector('.tenpu-delete').insertAdjacentHTML('beforebegin','<span>（'+filename+'）</span>');

            } else {
                document.getElementById(fileLinkId).value = href;//相対パスをリンク欄に反映
            }


            //画像やリンクを記事に挿入
            elm.addEventListener('click', function (e) {
                id = e.target.getAttribute('data-id');

                if (regexp.test(href)) {
                    href = document.getElementById(id).getAttribute('href');
                    editor.execute('insertImage', { source: href });
                    alert('画像を本文内に挿入しました。')
                }else{
                    fileLinkId = id.replace('current_file_', 'current_file_link,');//ファイルリンク欄
                    fileTextId = id.replace('current_file_', 'current_file_text,');//ファイルテキスト欄　current_file_text,3
                    let fileLinkVal = document.getElementById(fileLinkId).value;
                    let fileTextVal = document.getElementById(fileTextId).value;

                    editor.model.change( writer => {
                        const insertPosition = editor.model.document.selection.getFirstPosition();
                        writer.insertText( fileTextVal, { linkHref: fileLinkVal }, insertPosition );
                        alert('ファイルリンクを本文内に挿入しました。')
                    } );
                }
            });
        });

    })
    // .catch(error => {
    //     consolelog('エラーです')
    // });




//確認ボタンクリックで送信前の処理
function set_submit(LIST) {
    let editorData = editor.getData();
    editorData = editorData.replace('<script>','&ltscript&gt').replace('</script>','&lt/script&gt');//scriptタグ文字列化
    document.getElementById('body1').value = '{{{' + editorData + '}}}';

    //未選択の確認（タイトル、日付、カテゴリー名）
    const title_box = document.getElementById('subject');//タイトルボックス
    const year_box = document.getElementById('yyyy');//年
    const month_box = document.getElementById('mm');//月
    const day_box = document.getElementById('dd');//日
    const sugu_progress = document.querySelector('.sugu-progress');//基本項目(fieldset)要素
    const tag_select = document.getElementById('linetext3');//カテゴリー名選択
    let blankArray = [];
    //追加
    const filename_box = document.getElementById('article_filename');//記事ファイル欄
    const url_box = document.getElementById('linetext2');//URL欄
    const file_box = document.getElementById('imagename4');//ファイル（type=file）
    const current_file_box = document.getElementById('current_image_name,4');//カレントファイル（type=hidden）
    const main_form = document.getElementById('mainform');//フォーム
    const radioNodeList = main_form.elements['current_image_flg,4'];//カレントファイル 削除ラジオボタン
    let checkValue = radioNodeList.value;//添付(1)か削除(0)


    //追加ここまで

    if(title_box.value==''){
        blankArray.push('<p class="msg_error">タイトルが未記入です。</p>');
    }

    if(year_box.value==''|| month_box.value==''||day_box.value==''){
        blankArray.push('<p class="msg_error">年月日に未記入の項目があります。</p>');
    }

    if(tag_select.value==''){
        blankArray.push('<p class="msg_error">カテゴリー名が未選択です。</p>');
    }


    let fileExist = false;

    //カレントか選択のどちらかファイルあり
    if(current_file_box.value!='' && checkValue==1 || file_box.value!='' ){
        fileExist = true;
    }


    if(fileExist==true && filename_box.value!='.none'){ 
        //ファイル選択か、URLにサイトページのURLが記入されてる場合は、記事ファイル名に「.none」を記入
        blankArray.push('<p class="msg_error">記事ファイル名に「.none」を記入してください。</p>');

    }else if(/^http:|^https:/.test(url_box.value) && filename_box.value!='.none'){
        //URL欄にサイトページを記入した場合、記事ファイル名に「.none」を記入
        blankArray.push('<p class="msg_error">URL欄にサイトページ（http:～、https:～）を記入した場合、記事ファイル名に「.none」を記入してください。</p>');

    }else if(fileExist==false && filename_box.value!='' && url_box.value!=''){//記事ファイル記入済み、ファイル未選択、URL記入済み
        //記事ファイル名とURL値が違う
        if(filename_box.value!=url_box.value && !/^http:|^https:/.test(url_box.value)){
            blankArray.push('<p class="msg_error">URL欄の値が記事ファイル名と一致しません。</p>');
        }
    }else if(fileExist==false && filename_box.value!='' && filename_box.value!='.none' && url_box.value==''){
        //記事ファイル記入済み、ファイル未選択、URL未記入
        blankArray.push('<p class="msg_error">URL欄が未記入です。（記事ファイルを作成した場合は記入してください）</p>');
    }


    if(blankArray.length > 0){
        //必須項目に未記入有りの場合 再度入力
        if(document.querySelector('.msg_error')!=null){
            document.querySelectorAll('.msg_error').forEach(e=>{
                e.remove();
            });
        }

        for( let item of blankArray ) {
            sugu_progress.insertAdjacentHTML("beforebegin",item);
        }
        scroll_top();
        return false;

    }else{
        
        //確認画面に遷移
        var ListTable = document.getElementById(LIST);
        var ListOfChildId = "";
        if (set_order == null) { return true; }
        if (!$('#' + LIST).children(".file-unit") || $('#' + LIST).children(".file-unit").length == 0) { return true; }

        $('#' + LIST).children(".file-unit").each(function () {
            ListOfChildId += $(this).attr("id") + "\n\n";
        });
        var MyForm = document.getElementById("mainform");
        MyForm.file_order.value = ListOfChildId;
        return true;
    }
}

//トップへ戻る
function scroll_top() {
    window.scroll({ top: 0, behavior: "smooth" });
  }