function test2(){
    //処理2
}