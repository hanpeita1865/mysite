---
title: ファイルシステム
taxonomy:
    category:
        - docs
---

## Storageクラスについて
アプリケーションによっては、ファイルを利用してデータを管理することもあります。 アプリケーション内に、あるファイルを読み込んだり、ファイルにデータを保存するな どして、ファイルを利用したデータ管理を行うことはよくあるでしょう。
こうした場合、Laravelには便利なクラスが用意されています。「Storage」は、次のようにuse文を用意することで使えるようになります。
```
use Illuminate\Support\Facades\Storage;
```
### ファイルを読み込む
Storageは、非常にシンプルにファイルアクセスを行えます。ファイルを読み込むには、 次のように実行するだけです。

■ファイルの読み込み 
```
$変数 = Storage::get(ファイルパス );
```
これで、指定のファイルの内容を読み込んで返します。Storageがデフォルトでアクセ スするディレクトリは、アプリケーション内の「storage」フォルダ内の「app」フォルダに なっています。ここにファイルを設置することで、getでそのファイルを読み込むことが できます。


■ファイルの書き出し 
```
Storage::put(ファイルパス , 値 );
```
putは、保存するファイルのパスと、保存する値(テキスト)を引数に指定します。これで、/storage/app内に指定の名前でファイルを作成し、値を保存します。

リスト1-33
```
// use Illuminate\Support\Facades\Storage;        // 追加


class HelloController extends Controller
{
    private $fname;


    public function __construct()
    {
        $this->fname = 'sample.txt';
    }


    public function index()
    {
        $sample_msg = $this->fname;
        $sample_data = Storage::get($this->fname);
        $data = [
            'msg'=> $sample_msg,
            'data'=> explode(PHP_EOL, $sample_data)
        ];
        return view('hello.index', $data);
    }


    public function other($msg)
    {
        $data = Storage::get($this->fname) . PHP_EOL . $msg;
        Storage::put($this->fname, $data);
        return redirect()->route('hello');
    }
}
```

リスト1-34
```
Route::get('/hello', 'HelloController@index')->name('hello');
Route::get('/hello/{msg}', 'HelloController@other');
```

### ファイルへの追記
Storageには実はもっと簡単に値の追記を行えるメソッドが用意されています。

ファイルの先頭に追加 
```
Storage::prepend(ファイルパス , 値 );
```
ファイルの末尾に追加 
```
Storage::append(ファイルパス , 値 );
```
リスト1-35
```
public function other($msg)
{
    Storage::append($this->fname, $msg);
    return redirect()->route('hello');
}
```
これで、全く同じ働きをします。単にStorage::appendするだけで追記できるので、ファイルの内容を取り出す必要もなくなります。



















