*[page-title]:よく使う機能

## VSCODEでPythonを実行

参考サイト
: [Python開発のための超便利ツールを活用しよう！ ～テキストエディタ「Visual Studio Code（VS Code）」](https://www.insource.co.jp/python-gakuin/mail-backnumber/vol24.html)

VSCODE 拡張機能「Python」をインストール
![](upload/python拡張機能.png)

## デバッグ プログラムを1行ずつ実行する方法

参考サイト
: [デバック用のツールバーの「ステップイン」を押せばステップ実行が可能です。](https://www.insource.co.jp/python-gakuin/mail-backnumber/vol24.html)

1. 「practice.py」に、複数行のコードを記述します。
![](upload/practice.pyコード.png)
2. for文を使ったコードのほうが、動作確認がしやすいかもしれません。それでは、デバッガを起動してプログラムを1行ずつ実行してみます。<br>
まず、「practice.py」の1行目にカーソルを乗せて、「F9」キーをクリックします。<br>
すると、以下画像のように1行目の横に赤丸が付きます。
![](upload/practice.pyコード2.png)
3. この状態で、「F5」キーをクリックします。そうすると、上部に選択肢が表示されるので、python_practiceを選択します。
![](upload/python.file選択.png)
4. すると、1行目で処理が一時停止され、黄色背景が付きました。
![](upload/practice.pyコード3.png)
5. 次に、「F10」キーを押すと、次のプログラム行に処理が移ります。
![](upload/practice.pyコード4.png)
6. ステップ実行を続けると、ターミナルに結果が表示されていきます。
![](upload/ターミナルに数値表示.png)
7. 次の表示になると、ステップ実行は終了です。
![](upload/PRACTICEステップ実行終了.png)


## Excelからデータを抽出

参考サイト
: [意外と簡単！Pythonで複数エクセルからデータを抽出＆集計して効率化](https://code-fam.com/business_programming/excel_data_extraction/)

## Jupyter Notebookの使い方

参考サイト
: [Jupyter Notebookの起動と停止](https://www.javadrive.jp/python/jupyter-notebook/index2.html)
: [★ノートブックの作成とPythonプログラムの実行](https://www.javadrive.jp/python/jupyter-notebook/index3.html)


## resampleを使用した時にエラーが出る

参考サイト
: [【Python】pandas のresampleで”TypeError: Only valid with DatetimeIndex, TimedeltaIndex or PeriodIndex, but got an instance of ‘RangeIndex'”が出た時の対処法](https://obenkyolab.com/?p=4743)

<iframe src="https://paiza.io/projects/e/-SUH9vOAZxCsxXuDOJn3Uw?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>

ポイント
: pandas resampleメソッドを使用する場合にはdatetime型にすることと、indexにその列を指定しておくことが必要でした。

## Spyderのコードをコメントアウト

コメントアウトするショートカットキー ～<span class="green bold"> Ctrl + 1</span>

## Excelにデータを書き込む

参考サイト
: [【Python】Excelのセルに書き込みする](https://pg-chain.com/python-excel-cell-write)

<p class="tmp"><span>書式</span></p>
```
import openpyxl

# ブックを取得
ブック変数 = openpyxl.Workbook(ファイル名)
# シートを取得
シート変数 = ブック変数[シート名]
# セルへ書き込む
シート変数[セル記号] = 書き込む値
シート変数.cell(row=行,column=列).value = 書き込む値
```

ポイント1
: ファイルのディレクトリを指定するとき、「\」は「\\」にしないとエラーになる。

例）  
エラー
```
book = openpyxl.load_workbook('C:\Users\y-hir\PythonShizai\ExcelData\excel_write\data.xlsx')
```

接続成功
```
book = openpyxl.load_workbook('C:\\Users\\y-hir\\PythonShizai\\ExcelData\\excel_write\\data.xlsx')
```

ポイント2
: エクセルファイルは閉じていないと、書き込みエラーになります。


参考サイト
: [［解決！Python］OpenPyXLを使ってExcelファイルを読み書きするには](https://atmarkit.itmedia.co.jp/ait/articles/2202/08/news031.html)


##  Selenium（ウェブブラウザ操作の自動化）

参考サイト
: [【Python】Seleniumの使い方【ウェブブラウザ操作の自動化】](https://daeudaeu.com/python-selenium-brower-operation/)
: [https://daeudaeu.com/what-is-selenium/](https://daeudaeu.com/what-is-selenium/)

## リンクチェッカー

参考サイト
: [5分でできる！Python3を利用した自動リンクチェッカーの開発](https://engineers.weddingpark.co.jp/python/)

まだ、試してません。