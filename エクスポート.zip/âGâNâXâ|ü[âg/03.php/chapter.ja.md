---
title: PHP
taxonomy:
    category:
        - docs
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<!--<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:12px 0 12px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
</style>-->
<style>
    #body-inner > ol > li {
     	font-weight: bold;
        color:#d3ac3f;
        font-family:'Fjalla One',sans-serif;
        font-size:1.2rem;
    }
    #body-inner > ol > li ol li {
        color: #555;
        font-weight: normal;
        font-size: 1rem;
        font-family: "Montserrat", "Helvetica", "Tahoma", "Geneva", "Arial", sans-serif;
    }
</style>

# PHP

## 目次

1. PHPの基本
	1. アクセス修飾子
1. PHP記述のしかた
	1. ヒアドキュメント
1. SQL
	1. MySQL操作
	1. SQLite
1. 配列
1. 関数・メソッド
    1. file_exists、file_get_contents、json_encode
    1. 文字列操作（explode、implode、trim）
    1. 日時の設定・表示（date）
    1. 文字列の置換（str_replace、str_ireplace、strtr、substr_replace、preg_replace）
    1. switch文、for文
1. その他色々
    1. PHPでコンソールに表示させる
    1. ログイン・ログアウト設定
    1. 会員やユーザの登録情報
    1. 商品一覧を表示
    1. 商品を検索、追加、編集する
	1. テーブルの結合
1. Laravel
    1. Laravelの基本
    1. アプリケーションの構成
    1. 処理の流れとルーティング
    1. ビューの使い方
    1. コントローラクラスについて
    1. ミドルウェア