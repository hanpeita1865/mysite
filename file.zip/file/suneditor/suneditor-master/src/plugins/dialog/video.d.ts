import { DialogPlugin } from '../DialogPlugin';

declare const video: DialogPlugin;

export default video;