*[page-title]:データベース接続メモ


データベース接続したときにエラーが出た場合。
```
Uncaught PDOException: could not find driver
```
原因は、PDOのドライバーの設定がされていないためです。    
phpinfoを開いて、PDOの項目を確認してみてください。「PDO drivers」が「no value」になってたらインストールがされていません。
![](upload/PDO_driverがない.png "図　phpinfoの表示"){.photo-border}

PHPフォルダ内のphp.iniを開いて、次のコードのコメントアウトを取るか追加してください。
```
extension=mysqli
extension=pdo_mysql
```
![](upload/php.iniにextension追加.png "図　php.ini")

Apacheを再起動した後、接続確認をおこないます。

下記のDBの「from_now」のテーブル「user」のデータを表示してみます。
![](upload/userテーブル.png "図　userテーブル"){.photo-border}

htdocsに下記のコードを記述したファイルを格納してください。
<p class="tmp list"><span>リスト</span>test.php</p>
<pre><code class="hljs php"><span class="hljs-meta">&lt;?php</span>
$pdo=<span class="hljs-keyword">new</span> PDO(<span class="hljs-string">'mysql:dbname=from_now;host=localhost<span class="marker-yellow">:3316</span>'</span>,<span class="hljs-string">'staff'</span>,<span class="hljs-string">'password'</span>); 

<span class="hljs-keyword">foreach</span> ($pdo-&gt;query(<span class="hljs-string">'select * from user'</span>) <span class="hljs-keyword">as</span> $row){
    <span class="hljs-keyword">echo</span> $row[<span class="hljs-string">'user_id'</span>];
    <span class="hljs-keyword">echo</span> $row[<span class="hljs-string">'user_name'</span>];
    <span class="hljs-keyword">echo</span> $row[<span class="hljs-string">'password'</span>];
}</code></pre>

次のように表示できてれば、データベース接続はOKです。
```
1ryouma1010335
```


<div markdown="1" class="memo-box">
利用中のポート番号を確認するには、「show variables」で「port」を確認できます。
```
show variables like 'port'
```
</div>