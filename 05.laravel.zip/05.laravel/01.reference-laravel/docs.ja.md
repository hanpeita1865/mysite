---
title: Laravel(参考書)
media_order: 'composer2.png,composer4.png,composer5.png,composer7.png,composer8.png'
taxonomy:
    category:
        - docs
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:0px 0 5px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
</style>


## 目次

1. [Laravelについて](laravel_basic)
2. [Laravelを準備する](laravel_ready)
3. [Laravelを使ってみる](laravel_try)
4. [ルーティング](routing)
5. [コントローラ](controller)
6. [PHPテンプレートの利用](php_template)
7. [Bladeテンプレートを使う](blade_template)
8. [Bladeの構文](blade_syntax)
9. [レイアウトの作成](template_layout)
10. [ビューコンポーザ](view_composer)
11. [ミドルウェア](reference-middlewaere)
12. [バリデーション](validation)
13. [バリデーションをカスタマイズ](validation_customize)
14. [その他のリクエスト・レスポンス処理](request_response)
15. [データベースを準備する](database_ready)
16. [DBクラスの利用](dbclass_use)
17. [クエリビルダ](query_builder)
18. [マイグレーションとシーディング](migration_and_seeding)
19. [Eloquentの基本](eloquent_base)
20. [検索とスコープ](search_scope)
21. [モデルの保存・更新・削除](model_save)
22. [モデルのリレーション](model_relation)
23. [リソースコントローラとRESTful](reference-laravel/restful)
24. [セッション](session)
25. [ペジネーション](pagenation).
26. [ユーザー認証](authentication)
27. [ユニットテスト](unit_test)






















