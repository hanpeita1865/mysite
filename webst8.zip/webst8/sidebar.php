<h1 class="text-center">セミナー情報</h1>
<section id="wordpress-seminar">
    <h2>WordPress入門セミナー</h2>
    <p>
        <img src="<?php echo get_template_directory_uri(); ?>/images/seminar-wordpress.png" alt="ワードプレスセミナー画像">
    </p>                    
</section>
<section id="seo-seminar">
    <h2>SEO入門セミナー</h2>
    <p>
        <img src="<?php echo get_template_directory_uri(); ?>/images/seminar-seo.png" alt="SEOセミナー画像">
    </p>                    
</section>