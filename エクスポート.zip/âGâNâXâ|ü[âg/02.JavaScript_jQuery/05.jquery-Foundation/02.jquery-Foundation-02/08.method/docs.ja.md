---
title: '08. スライドダウン、スライドアップ<br>（slideDown、slideUp、slideToggle）'
taxonomy:
    category:
        - docs
visible: true
---

<style>
	p{letter-spacing:.06rem;}
</style>

<p>これらのメソッドは指定した要素の表示・非表示を切り替える「show, hide, toggle」メソッドにスライドアニメーションを加えたものになります。</p>

<h2 class="h-type2">要素をスライドダウンさせる（slideDown）</h2>

<dl class="dl-methodDetail">
	<dt><span>書式</span></dt>
	<dd>$(セレクタ).slideDown([speed][,func])</dd>
	<dt><span>機能</span></dt>
	<dd>$(セレクタ)をスライドダウンアニメーションをつけて表示します。</dd>
	<dt><span>引数</span></dt>
	<dd>
		<dl class="dl-methodDetailInner">
			<dt>speed：</dt>
			<dd>動作する時間を「slow」、「normal」、「fast」の文字列か、もしくは数値（ミリ秒単位）で指定します。</dd>
			<dt>func：</dt>
			<dd>アニメーション完了後に実行する関数</dd>
		</dl>
	</dd>
</dl>
<div class="box-example">
	<h3 class="h-example">例1</h3>
	<p>ボタンを押すと1秒間かけてスライドダウン表示する。</p>
</div>
<iframe width="100%" height="200" src="//jsfiddle.net/rag5kdsf/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLを見てみましょう．  
CSSは割愛しますが、buttonが設置され、その下にboxがdisplay:none;で非表示になっています．

ではJavaScriptのコードを見てみましょう．  
buttonをクリックするとboxが1000ミリ秒かけてスライドダウン表示されるコードとなっています．

---

<h2 class="h-type2">要素をスライドアップさせる（slideUp）</h2>

<dl class="dl-methodDetail">
	<dt><span>書式</span></dt>
	<dd>$(セレクタ).slideUp([speed][,func])</dd>
	<dt><span>機能</span></dt>
	<dd>$(セレクタ)をスライドアップアニメーションをつけて非表示にします。</dd>
	<dt><span>引数</span></dt>
	<dd>
		<dl class="dl-methodDetailInner">
			<dt>speed：</dt>
			<dd>動作する時間を「slow」、「normal」、「fast」の文字列か、もしくは数値（ミリ秒単位）で指定します。</dd>
			<dt>func：</dt>
			<dd>アニメーション完了後に実行する関数</dd>
		</dl>
	</dd>
</dl>
<div class="box-example">
	<h3 class="h-example">例2</h3>
	<p>ボタンを押すと1秒間かけてスライドアップで非表示にする。</p>
</div>
<iframe width="100%" height="200" src="//jsfiddle.net/darfev1t/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLを見てみましょう．  
buttonが設置され、その下に今度はboxが表示されています．

ではJavaScriptのコードを見てみましょう．  
buttonをクリックするとboxが1000ミリ秒かけてスライドアップで非表示になるコードとなっています．

---

<h2 class="h-type2">スライドダウン・アップの切り替え（slideToggle）</h2>

今度は、スライドダウン・アップを簡単に繰り返すことができるメソッドについて見ていきましょう。  

<dl class="dl-methodDetail">
	<dt><span>書式</span></dt>
	<dd>$(セレクタ).slideToggle([speed][,func])</dd>
	<dt><span>機能</span></dt>
	<dd>$(セレクタ)をスライドダウン・アップアニメーションをつけて表示・非表示にします。</dd>
	<dt><span>引数</span></dt>
	<dd>
		<dl class="dl-methodDetailInner">
			<dt>speed：</dt>
			<dd>動作する時間を「slow」、「normal」、「fast」の文字列か、もしくは数値（ミリ秒単位）で指定します。</dd>
			<dt>func：</dt>
			<dd>アニメーション完了後に実行する関数</dd>
		</dl>
	</dd>
</dl>
<div class="box-example">
	<h3 class="h-example">例3</h3>
	<p>ボタンを押すと1秒間かけてスライドダウン・アップで表示・非表示にする。</p>
</div>
<iframe width="100%" height="200" src="//jsfiddle.net/q4jtLwe5/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLを見てみましょう．  
先程とまったく同じで、buttonが設置され、その下にboxが表示されています．

ではJavaScriptのコードを見てみましょう．  
今度はslideToggleメソッドを使って、buttonをクリックする度にboxが表示されたり，非表示になるコードとなっています．
