---
title: '10. data属性の使い方'
media_order: 'common.png,common.png'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: blue;}
    .smp-box {
         margin: 2rem 0 3rem;
    }
    .smp {
        display: inline-block;
        margin-top: 2rem;
        margin-bottom: 0;
        background: #bc495b;
        color: #fff;
        font-size: .75rem;
        font-weight: bold;
        letter-spacing: .3rem;
        padding: .2rem .5rem;
    }
    span.tmp {
        background: #026ca2;
        color: #fff;
        font-size: .87rem;
        letter-spacing: .3rem;
        padding: .2rem 0.3rem .2rem .7rem;
        white-space: nowrap;
    }
    .dcn {
     font-weight: bold;   
    }
    .gray-box {
     	border: 1px solid gray;
        padding: 20px 30px;
        display: inline-block;
    }
    .w-400 {
      	width: 400px;
     }
    .comment {
      font-style: italic;
      color: green;
      font-size: 1rem;
    }
    h3 span {
      border-bottom: 3px solid green;   
    }
    h4 {margin-top: 3rem;}

</style>
「独自データ属性」とは、html5で追加されたオリジナルの属性をつくれる仕様です。
独自データ属性、カスタムデータ属性、data-role属性・・・
と色々な呼ばれ方をします。ここではデータ属性とします。

オリジナルで属性を作って一体なんのためになるのかというと、基本的にどのタグにも対応でき、その属性に対して値を入れておくことで、
javascriptやjQueryで値が取得できます。
その名の通り、自分で任意に追加することができる属性のことです。

<section>
    <h2>データ属性の記述と値の取得</h2>
記述は簡単です。例えばこんな感じです。
<pre>
&lt;div id=”box” data-<span class="red">name</span>=”<span class="blue">だいち</span>”&gt;ダミーテキスト&lt;/div&gt;
</pre>
    
<p class="mb-05"><span class="tmp">書式1</span>　<span class="bold">データ属性の記述方法</span></p>
<pre class="w-300">
	data-<span class="red">〇〇</span> = ”<span class="blue">属性値</span>”
</pre>
<p>このように<span class="red">〇〇</span>の部分は、アルファベットなど任意の文字を自分で決めて記述します。
使用できるのは、文字、数字、ハイフン（-）、ドット（.）、アンダースコア（_）です。大文字は使えません。<br>

<span class="blue">属性値</span>には、数字、文字列、全角もOKです。
先頭に「#」や「.」をつけてもOKです。よって、クリックして簡単に目的の要素のidやclassを指定することができます。<br>
また、1つの要素に、さまざまな値を持ったデータ属性をいくつも持つこともできます。</p>

<p>先ほどのコードからjQueryで値を取得するときはこのように記述します。</p>

<pre>
$('#box').attr('data-name'); 
</pre>

これで取得できる値は「<strong>だいち</strong>」になります。</p>
<p class="mb-05"><span class="tmp">書式2</span>　<span class="bold">データ属性値の取得（attr()）</span></p>
<pre>
	$('セレクタ').<span class="red bold">attr</span>('data-〇〇'); 
</pre>


<p><span class="bold">dataメソッド</span>を使用しても下記のようにしてdata属性の値を取得することもできます。</p>

<pre>
$('#box').data('name');
</pre>
<p class="mb-05"><span class="tmp">書式3</span>　<span class="bold">データ属性値の取得（data()）</span></p>
<pre>
	$('セレクタ').<span class="blue bold">data</span>('〇〇');
</pre>

取得だけでなく、jQueryを使って新しいdata属性を設定することも可能です。

<p class="mb-05"><span class="tmp">書式4</span>　<span class="bold">dataメソッドでのデータの設定や変更</span></p>
<pre>
	$(‘セレクタ’).<span class="blue bold">data</span>('〇〇','値')
</pre>

「attr()」でdata属性を設定する場合も、これまでと同様に【 対象要素.attr( 属性名, 値 ) 】と記述すればOKです！<br>
ただ、属性名の指定は「data-」の部分も一緒に記述しなければいけません。

<p class="mb-05"><span class="tmp">書式5</span>　<span class="bold">attrメソッドでのデータの設定や変更</span></p>
<pre>
	$(‘セレクタ’).<span class="bold red">attr</span>('data-〇〇','値')
</pre>

attr() と data()でのデータ属性の設定や変更の内容には違いがあり、要点をまとめると次のようになります。<br>

<ul>
    <li>attr()」で設定した属性はHTML要素へ直接追加される</li>
    <li>「data()」で設定した属性はjQuery内へ一時的に保持される</li>
</ul>


<div class="smp-box"><span class="smp">例1 </span>
<iframe width="100%" height="350" src="//jsfiddle.net/5w0t1b3y/1/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p>dataメソッドとattrメソッドは、独自データ属性を取得できるという意味で、一見、似た役割を持ちますが、その挙動は異なります。特に混在して利用する場合には、思わぬ挙動の原因となりますので、注意してください。</p>

<p>こういった問題を起こさないために、「attr()」で設定したら「attr()」で取得する…または「data()」で設定したら「data()」で取得するようにしましょう。<br>
ただ、jQueryで設定、変更をしない場合は、あまり気にしなくていいと思います。</p>



<div class="smp-box"><span class="smp">例2</span>　<span class="bold">要素に複数のデータ属性を設定し、それぞれの値を取得する</span>
<script async src="//jsfiddle.net/hvg5apm8/12/embed/html,js,result/"></script>
 <dl>
    <dt>解説</dt>
    <dd>id="test"の要素の中にある3つのデータ属性の値をボタンをクリックすることによって取得します。
    </dd>
</dl>
</div>

<div class="smp-box"><span class="smp">例3</span>　<span class="bold">data属性に基づいて要素を選択する</span>
<script async src="//jsfiddle.net/mygLfv9t/embed/html,css,js,result/"></script>
 <dl>
    <dt>解説</dt>
    <dd>ボタンをクリックすると、data-name="だいち"のある要素にクラスtext-redを設定しテキストを赤にします。
    </dd>
</dl>
</div>

<p class="mb-05"><span class="tmp">書式6</span>　<span class="bold">指定したデータ属性値のある要素を選択</span></p>
<pre>
	$('[data-test="値"]').～
</pre>

ただ注意点として、データ属性を使うのは、ほかに適切なHTML要素や属性がない場合だけに限るべきです。
たとえば、要素のclassをdata-class属性を設定しそこに格納するのは適切ではありません。
</section>

---------------------------------------

<h3><span>サンプル1</span></h3>
<p>データ属性で画像やデータを切り替える</p>

<iframe width="100%" height="650" src="//jsfiddle.net/hn5sujLr/1/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

 <dl>
    <dt>解説</dt>
    <dd>ケーキの名前を記入しているli要素をクリックすることによって、そのli要素内の3つのデータ属性（<span class="red">画像のURL、画像のalt、ケーキの値段</span>）の値を取得します。<br>
        取得したを属性値を#image-box要素内のそれぞれの要素に設定します。
    </dd>
</dl>


<h3><span>サンプル2</span></h3>
<p>下記のcommonフォルダにある年度別の順位表のコードが記述されたファイルを、data属性の値で選別して読み込んでいます。</p>

![absolute](common.png)

<iframe width="100%" height="750" src="jquery-foundation-13/sample1/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<iframe width="100%" height="650" src="//jsfiddle.net/k9hb8wqv/embedded/html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


