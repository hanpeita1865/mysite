*[page-title]:要素を挿入 appendChild

参考サイト
: [JavaScriptのappendChildメソッドの使い方を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/20820)
: [https://web-tsuku.life/appendchild-javascript/](appendChild()の使い方とデモ【JavaScript】)
: [ノードを子ノードの中の指定ノードの前または後ろに追加(before,insertBefore,after)](https://www.javadrive.jp/javascript/dom/index21.html)
: [ノードを子ノードの中の先頭または最後に追加(prepend,append,appendChild)](https://www.javadrive.jp/javascript/dom/index20.html#:~:text=%E5%85%88%E9%A0%AD%E3%81%AB%E8%BF%BD%E5%8A%A0%E3%81%99%E3%82%8B%E3%81%AB,appendChild%20%E3%83%A1%E3%82%BD%E3%83%83%E3%83%89%E3%82%92%E4%BD%BF%E3%81%84%E3%81%BE%E3%81%99%E3%80%82)

appendChildメソッドを使うと、既存のHTMLドキュメントに新しく要素を追加することが出来ます。さらに既存の要素をコピーしたり、HTML要素を新規に追加することも出来ます。