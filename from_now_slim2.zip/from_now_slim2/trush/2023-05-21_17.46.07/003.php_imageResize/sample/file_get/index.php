<?php
    //$url = "https://www.google.co.jp/images/srpr/logo11w.png";

	$url = 'logo11w.png';

    $img = file_get_contents($url);

	//var_dump($img);

    $imginfo = pathinfo($url);

    $img_name = $imginfo['basename'];

    //画像を保存
    //file_put_contents('./upload/' . $img_name, $img);
?>
<script>
	var img_name = <?= $img ?>;
	
	console.log(img_name);
	
	//fd = new FormData();
</script>

