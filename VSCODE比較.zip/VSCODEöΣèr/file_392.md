## 2つのファイルの内容を比較する

Visual Studio Codeには2つのファイルの内容を比較して、その差を分かりやすく表示してくれる機能が内蔵されています。

![](img7)

<details markdown="1"><summary>詳細</summary>

まず比較したいファイルの両方を開いておきます。  
次にメニューの<span class="bold">【表示】→【コマンドパレット</span>】か <span class="bold text-green">Shift + Ctrl + P</span> でコマンドパレットを表示し、「<span class="bold text-red">compare</span>」と入力してから［<span class="red bold">ファイル: アクティブ ファイルを比較しています</span>］コマンドを選択します。  
（次回からは、最近使った項目に表示されるので「compare」は、入力しなくてよくなります。）
![](img1)

最近開いたファイルの一覧が表示されるので、アクティブではないもう一方の比較対象のファイルを選択します。
![](img2)
そうすると、比較結果が表示されます。左画面がアクティブになってる方のファイル（赤色）で、右画面がもう一方のファイル（黄色）になります。
![](img3)

※修正するごとに、赤や黄色のマーカーは消えていきます。

### サイドバーのリストから比較する

サイドバーのファイルメニューからもファイルを比較することができます。  
まず、比較対象のファイル上で右クリックをし、「比較対象の選択」をクリックします。  
![](img4)
次に、もう一方のファイル上で右クリックをして、「選択項目と比較」をクリックすると、比較結果が表示されます。
![](img5)
![](img6)
</details>


## Emmet

<span class="bold text-green">Emmet</span>とは、だいたいのテキストエディタで使用できるコードの補完機能です。 HTMLとCSSを入力する際に使えてコーディングの効率が上がります。 また、補完機能がコードを入力してくれるのでタイプミスがなくなります。

[Emmet Cheet Sheet](https://docs.emmet.io/cheat-sheet/)

## HTMLタグの挿入


### 基本
「<span class="text-blue">.クラス名</span>」や「<span class="text-green">#id名</span>」と入力して、Enterキーかtabキーを押すと、クラス付きやid付きのdiv要素が作成されます。（入力候補が表示されない場合は、tabキーで変換します。）       
複数のクラス名をつける場合は、「.クラス名.クラス名」のように後ろに続けて入力します。idも同じです。

![](upload/div_p_a.gif)

他によく使う記号として、「<span class="text-red bold">{}</span>」**テキスト挿入**、「<span class="bold text-red">></span>」**子要素を指定**、「<span class="bold text-red">+</span>」**隣接を指定**、「<span class="bold text-red">*</span>」**要素の個数**、「<span class="bold text-red">$</span>」**連番**、「<span class="bold text-red">()</span>」**グループ化**、「<span class="bold text-red">^</span>」**一つ上の階層に戻る**、があります。


例えば「div.test>p{ダミーテキスト}」で、Enterキーかtabキーを押すと、次のように変換されます。  
※divにクラスを設定してる場合、.test>p{ダミーテキスト} のように div は省略できます。
![](upload/div_p.gif)



### リスト

<p class="tmp"><span>書式</span>リスト</p>
```
ul>li*個数
ol>li*個数
```
上記の基本形と「. （ドット）クラス名」「()グループ化」、「$連番」、「{} テキスト」の記号を組み合わせると次のようになります。  
<span class="bold purple">`ul>li*3`</span>　→　<span class="bold purple">`ul>li{ダミーテキスト}*3`</span>　→　<span class="bold purple">`ul>(li.item$>a{ダミーテキスト})*3`</span>　→ 　<span class="bold purple">`(ul>li{ダミーテキスト}*2)*2`</span><br>の順番で入力しています。
![](upload/ul_li_a.gif)

### 定義リスト
定義リストでは、「+ 隣接」を使います。
<p class="tmp"><span>書式</span>定義リスト</p>
```
dl>dt+dd
dl>(dt+dd)*個数
```
同じように「. （ドット）クラス名」「() グループ化」、「$ 連番」、「{} テキスト」の記号を組み合わせてみました。  
<span class="purple bold">`dl>dt+dd`</span>　→　<span class="purple bold">`dl>(dt+dd)*2`</span>　→　<span class="purple bold">`(dl.box$>(dt+dd))*2`</span>　の順番で入力しています。
![](upload/dl_dt_dd.gif)

## 「wrap with abbreviation」でタグを後から付け足す

参考サイト
: [【VSCode】まずはこれを覚えよう！初心者のためのショートカット２９選！](https://skillhub.jp/blogs/234)

1. 囲みたい部分を選択します。
2. コマンドパレット（Shift+Ctrl+P）を開いて、「wrap」と入力すると候補で出てくるので<br>「<span class="green bold">Emmet: Wrap with Abbreviation</span>」を選択します。
![](upload/wrap変換.png) 
3. 入力窓が出てきますので、テキストや要素などを囲んでをタグを入力すれば、記入されます。

ショートカットキーを設定しておけば便利です。  
上記の歯車アイコンをクリックして、設定画面を開き、左端の「+」かペンアイコンをクリックすればキーを設定できます。

ここでは、「Alt+J」にしました。（WindowsやVSCODEの既存のショートカットキーと被らないようにしましょう。）
![](upload/emmet_alt_j.png)

![](upload/タグを後から付け足す.gif)

<p>ではショートカットキーを設定したとして、wrap機能を使ってみます。</p>  

「<span class="green bold">`テキストを選択`</span>」→ 「<span class="green bold">`ul>li* を入力`</span>」→「<span class="green bold">`削除`</span>」→「<span class="green bold">`p*を入力`</span> 」→「<span class="green bold">`変換後さらに<div class="box">を設置`</span>」 の順番で行っています。  
※既存の要素らをdivなどにクラスやidを付けたりして囲むときに便利です。
![](upload/wrap_ul_p.gif)

### コメントアウトの設定

Emmetの機能とは違うと思いますが、コードを選択して、「<span class="red bold">CTRL + /</span>」を押すとコメントアウトを設定でき、もう一度押すと解除することができます。  
とびとびで複数行選択する場合は、Altキーを押しながら選択します。  

「<span class="green bold">`HTMLのコメントアウト`</span>」 → 「<span class="green bold">`CSSのコメントアウト`</span>」 → 「<span class="green bold">`JSのコメントアウト`</span>」の順番で行っています。
![](upload/html_css_js_commentout.gif)

## 補足

### スニペットに独自のEmmetを追加する

参考
: [snippets/html.json](https://github.com/emmetio/snippets/blob/master/html.json)
: [Visual Studio CodeのEmmetをカスタマイズする方法](https://satoyan419.com/custom-emmet-snippets-in-visual-studio-code/)

1. <span class="red">snippets.json</span>ファイルを作成し、下記コードを記述して保存します。保存場所はどこでもいいです。
<p class="lang">snippets.json</p>
```
{
    "variables": {},
    "html": {
        "snippets": {}
    },
    "css": {
        "snippets": {}
    }
}
```


2. [ファイル]-[ユーザー設定]-[設定]から設定画面を開き、入力欄に「emmet」と記入します。  
　抽出された項目の中から、「<span class="green bold">Emmet: Extensions Path</span>」の［<span class="red">項目を追加</span>］ボタンをクリックします。
![](upload/extensions_path項目の追加.jpg)

3. 先ほど「snippets.json」を保存した<span class="red">フォルダのパス</span>を記入して、OKをクリックします。
![](upload/vscode_setting.png)
これで、上記のローカルに保存した snippets.jsonのファイルに追記していけば、記法の変更や追加をすることができます。  

例えば、cssの箇所に下記のようなメディアクエリー用の省略記法を追加してみました。  
ブレイクポイントを任意で設定するパターンと、よく使うブレイクポイント（1200px, 992px, 768, 576px）は、xl, lg, md, smを追記することで記入されるようにしています。また、それぞれmin-widthとmax-width用で作成してます。
```
    "css": {
      "snippets": {
        "@min": "@media screen and (min-width: ${1}px) {\n\t${0}\n}",
        "@max": "@media screen and (max-width: ${1}px) {\n\t${0}\n}",
        "@mm": "@media screen and (min-width: ${1}px) and (max-width: ${2}px) {\n\t${0}\n}",
        "@minxl": "@media screen and (min-width: 1200px) {\n\t${0}\n}",
        "@maxxl": "@media screen and (max-width: 1199px) {\n\t${0}\n}",
        "@minlg": "@media screen and (min-width: 992px) {\n\t${0}\n}",
        "@maxlg": "@media screen and (max-width: 991px) {\n\t${0}\n}",
        "@minmd": "@media screen and (min-width: 768px) {\n\t${0}\n}",
        "@maxmd": "@media screen and (max-width: 767px) {\n\t${0}\n}",
        "@minsm": "@media screen and (min-width: 576px) {\n\t${0}\n}",
        "@maxsm": "@media screen and (max-width: 575px) {\n\t${0}\n}"
      }
    }
```

![](upload/emmet_madiaquery1.gif)


デフォルトで「<span class="green bold">!</span>」で入力すると、次のような基本的なタグが挿入されたHTML用テンプレートが作成されます。  
![](upload/HTMLテンプレートデフォルト.png "デフォルトのHTMLテンプレート")

ただ、デフォルトの場合2行目のlang属性が「en」になってるので、あらかじめ「ja」に変更しておくとよいです。下記のように「"variables":～」のコードを追記します。

5行目のIE用のmetaタグも必要ないと思われれば、「"doc":～」を追記すればよいです。
snippets.jsonを次のように書き換えます。

<p class="lang">snippets.json</p>
```
{
  "variables": {
      "lang": "ja"
  },
  "html": {
    "snippets": {
      "doc": "html[lang=${lang}]>(head>meta[charset=${charset}]+meta:vp+title{${1:Document}})+body",
    }
  },
  "css": {
    "snippets": {}
  }
}
```
そうすると、同じく「!」で入力すると、次のように変更されたテンプレートが挿入されます。
![](upload/HTMLテンプレートカスタマイズ.png)

その他に、htmlやcssで記法を修正や追記したいものがあれば、デフォルトの[snippets/html.json](https://github.com/emmetio/snippets/blob/master/html.json)と[snippets/css.json](https://github.com/emmetio/snippets/blob/master/css.json)"を参考に、それぞれの"snippets": {･･･}に書き加えてみてください。  


## EmmetがTABキーを押しても、実行されない場合の対応

参考サイト
: [VSCodeでEmmetが使えない時の対処方法](https://taiyosite.com/vscode-emmet/)

1. 左下の歯車をクリックし、「設定」を選択する。
2. 設定画面の検索窓に、「Trigger Expansion On Tab」を入力し、エンターキーを押します。
3. Emmet:「Trigger Expansion On Tab」の項目にチェックを入れ、一度VSCODEを再起動します。
4. 立ち上がったら、省略記号を入れてTABキーを押せば、HTMLのコードに変換されます。

