$(function() {
  var d = $(document).height();
  var win = $(window).height();
  $('#document span').text(d);
  $('#win span').text(win);
});

$(window).on("scroll", function() { 
  var scrollPos = $(window).scrollTop(); //トップからの位置
  $('#scrollTop span').text(scrollPos);
});

$(window).on("resize", function() {
  var win = $(window).height();
  $('#win span').text(win);
});