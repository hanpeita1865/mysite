(function() {
    'use strict';
  
    let ENCODINGS = ['SJIS', 'JIS', 'EUCJP', 'UTF8'];
  
    /*$(document).ready(doit);
  
    function doit() {
      let run = document.getElementById('run');
      run.removeAttribute('disabled');
      run.addEventListener('click', function() {
        run.disabled = true;
        convert();
      }, false);
    }*/

    convert();
  
    function convert() {
      let d = $.Deferred();
  
      ENCODINGS.forEach(function(encodingName) {
        d.then(function() {
          let filename = 'encoding-' + encodingName.toLowerCase() + '.txt';
  
          return readFile(filename).then(function(data) {
            appendTitle('Open ', filename);
  
            appendText(encodingName + ' Array', Array.prototype.slice.call(data).toString());
            appendText(encodingName + ' String', Encoding.codeToString(data));
  
            let detected = Encoding.detect(data);//SJIS、UTF8、...
            appendText('Encoding.detect(' + encodingName +' Array)', detected);
  
            let encoded = Encoding.urlEncode(data);
            appendText('Encoding.urlEncode(' + encodingName + ' Array)', encoded);
  
            let decoded = Encoding.urlDecode(encoded);//Array(～)
            appendText('Encoding.urlDecode()', decoded.toString());
  
            // Convert to Unicode.
            let unicode = Encoding.convert(data, {//Unicodeに変換 Array(～)
              to: 'UNICODE',
              from: 'AUTO'
            });
  
            appendText(encodingName + ' Array => UNICODE Array', unicode.toString());
            appendText('UNICODE Array => UNICODE String', Encoding.codeToString(unicode));
          }, function(err) {
            appendTitle('Open ', filename);
            appendText('Error', err);
            console.error(err);
            throw err;
          });
        });
      });
  
      d.resolve();
    }
  
    function readFile(url) {
      let d = $.Deferred();
      let req = new XMLHttpRequest();
      req.open('GET', url, true);
      req.responseType = 'arraybuffer';
  
      req.onload = function(ev) {
        if (req.readyState === 4) {
          if (req.status === 200) {
            let buffer = req.response;
            if (buffer) {
              let data = new Uint8Array(buffer);
              d.resolve(data);
            } else {
              d.reject(req.statusText);
            }
          } else {
            d.reject(req.statusText);
          }
        }
      };
  
      req.onerror = function(ev) {
        d.reject(req.statusText);
      };
  
      req.send(null);
  
      return d;
    }
  
    function appendTitle(title, url) {
      let a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.textContent = url;
  
      let h3 = document.createElement('h3');
      h3.appendChild(document.createTextNode(title));
      h3.appendChild(a);
  
      let result = document.getElementById('result');
      result.appendChild(h3);
    }
  
    function appendText(title, text) {
      let div = document.createElement('div');
      div.appendChild(document.createTextNode(title));
  
      let textarea = document.createElement('textarea');
      textarea.value = text;
  
      let result = document.getElementById('result');
      result.appendChild(div);
      result.appendChild(textarea);
    }
  
  }());