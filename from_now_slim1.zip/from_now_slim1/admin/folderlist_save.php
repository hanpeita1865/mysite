<?php
    $post_list = $_POST['list'];
    file_put_contents("../templates/layouts/menu_list.twig", $post_list);
?>