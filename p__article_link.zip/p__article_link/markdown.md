*[page-title]:リンク配置

## ファイルリンクを設置

### ファイルの登録

まず、PDF、WORD、EXCELなどのファイルのアップロードを行います。  
添付ファイル用の欄にある<kbd class="border border-secondary">ファイルを選択</kbd>ボタンをクリックして、アップロードするファイルを選択します。

<div markdown="1" class="d-flex justify-content-start align-items-center">
![](upload/選択前のボックス.png "図　添付ファイル欄の「ファイルを選択」ボタンをクリック")
<p class="d-flex flex-column align-items-center mx-3"><span class="fz-16">➡</span></p>
![](upload/ファイルを選択.png "図　ファイルが選択されました")
</div>

他にもアップロードしたいファイルがあれば選択しておいてから、右端にある<kbd class="border border-secondary">先にアップロード</kbd>ボタンを押します。  
ページが更新され、下のようにアップロードしたファイル名とリンクが表示されます。  
これで仮のアップロードは完了しました。  
（※確認画面でページ編集を確定せず、ここで編集を中止すると仮アップロードしたファイルは自動的に削除されます。）

![](upload/仮のアップロード完了.png "図　仮アップロード完了")


### 本文内にファイルリンクの設置

本文内に挿入する前にリンク名を変更しておきます。  
ファイル名のままでよければ、そのままでいいです。また、挿入した後からでも変更はできます。
![](upload/ファイルリンク名の変更.png)

本文内のリンクを挿入したい箇所（「お申し込みは」の後ろ）にカーソルを持っていき、<kbd class="border border-secondary">本文内に挿入</kbd>ボタンを押します、
![](upload/企業説明会リンク挿入前.png "図　ファイルリンク挿入箇所を指定")
<p class="d-flex flex-column align-items-center"><span class="fz-16 rotate90">➡</span></p>
ファイルリンクの挿入ができました。
![](upload/企業説明会リンク挿入後.png "図　ファイルリンクの挿入完了")

挿入した後にリンク名を変更する場合は、