---
title: '08. オブジェクト'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .smp {margin-top: 2rem; margin-bottom: 0;}  
</style>


オブジェクトとは、「複数のプロパティを持つデータのまとまり」です。
それぞれのプロパティにはデータが保存されているので、「各種データをひとまとめにして、一つの変数として扱えるデータ」ということもできます。
この点は配列と同じです。
配列もオブジェクトの一種といえます。<br>
二つの違いはというと<br>
・配列：<span class="red">添字（番号）</span>を使って格納されたデータを参照<br>
・オブジェクト： <span class="red">名前（プロパティ）</span>を使って格納されたデータを参照 <br>
となります。

<section>
    <h2 class="h-type2">オブジェクトの設定と読み取り</h2>
<p class="tmp"><span>書式1</span>プロパティ数が0個のオブジェクトを作成して変数に保存する</p>
<pre>
var 変数名 = {};
</pre>

<p class="tmp"><span>書式2</span>プロパティが1個以上あるオブジェクトを作成する</p>
<pre>
var 変数名 = {プロパティ名1:データ, プロパティ名2:データ, ... ,プロパティ名X:データ};
</pre>

<p class="tmp"><span>書式3</span>プロパティのデータを読み取る方法</p>
<pre>オブジェクト名.プロパティ名

または

オブジェクト名['プロパティ名']
</pre>

<div class="box-example">
<h3 class="h-example">例8-1</h3>
変数studyにプロパティ（theme, date, number）を作成し、それぞれにデータを設定しています。
</div>
<!--<script async src="//jsfiddle.net/gu0p9a3j/4/embed/js,result/"></script>-->

<iframe width="100%" height="400" src="//jsfiddle.net/dv1La3k7/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>
<section>
    <h2 class="h-type2">データの書き換え</h2>
    <p class="tmp"><span>書式4</span>プロパティのデータを書き換える</p>
<pre>オブジェクト名.プロパティ名 = 新しいデータ;

または

オブジェクト名['プロパティ名'] = 新しいデータ;
</pre>

<div class="box-example">
<h3 class="h-example">例8-2</h3>
開催する日（dateプロパティ）のデータを「8月末」から「10月上旬」に書き換えています。
</div>
<!--<script async src="//jsfiddle.net/u1hcyLtz/1/embed/js,result/"></script>-->
<iframe width="100%" height="300" src="//jsfiddle.net/hvba3ek0/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

</section>

<section>
    <h2 class="h-type2">すべてのプロパティを表示する（for...in文）</h2>
    <p>オブジェクトのプロパティをすべて読み取ることだけを目的とした専用の繰り返し文です。</p>
    <p class="tmp"><span>書式5</span></p>
    <pre>for(var プロパティを保存しておく変数名 in オブジェクト名) {
　  処理内容
}
    </pre>
  
<div class="box-example">
<h3 class="h-example">例8-3</h3>
    変数studyのプロパティのデータを読み取りコンソールに表示しています。
</div>
    <!--<script async src="//jsfiddle.net/L4y1sxm9/2/embed/js,result/"></script>-->
    <iframe width="100%" height="300" src="//jsfiddle.net/6euw70p2/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>

<section>
    <h2 class="h-type2">配列とオブジェクトのどちらを使うか</h2>
    どちらを使うかについては、対象となるデータを管理・参照するのに、 配列とオブジェクトのどちらが適切で管理・参照しやすいかを考えて使用します。<br>
例えば、数値だけが順番にならんでいるようなデータなら配列が適切です。<br>
ID、名前、住所、電話番号などのデータをまとめて扱うならオブジェクトが適切です。

     <table style="width:200px;">
     <caption class="bold">配列向き<br>↓</caption>
    <tr>
    	<td>1</td><td>北海道</td>
    </tr>
    <tr>
    	<td>2</td><td>青森</td>
    </tr>
     <tr>
    	<td>...</td><td>...</td>
    </tr>
    <tr>
    	<td>47</td><td>沖縄</td>
    </tr>
    </table>
 
 
    <table style="width:600px;">
    <caption class="bold">オブジェクト向き<br>↓</caption>
    <tr>
    	<th>ID</th><th>名前</th><th>住所</th><th>電話番号</th>
    </tr>
    <tr>
    	<td>7315101</td><td>だいち太郎</td><td>東京都××××</td><td>050-××××-××××</td>
    </tr>
    </table>
</section>

<section>
    <h3>配列とオブジェクトを組み合わせ</h3>
    下表は配列とオブジェクトを組み合わせて管理します。
    
    <table style="width:600px;">
    <tr>
    	<th>ID</th><th>名前</th><th>住所</th><th>電話番号</th>
    </tr>
    <tr>
    	<td>1</td><td>ポチ</td><td>広島県××××</td><td>082-941-××××</td>
    </tr>
    <tr>
    	<td>2</td><td>タマ</td><td>岡山県××××</td><td>086-803-××××</td>
    </tr>
    <tr>
    	<td>3</td><td>モモ</td><td>島根県××××</td><td>0852-55-××××</td>
    </tr>
    <tr>
    	<td>4</td><td>ミケ</td><td>鳥取県××××</td><td>0857-22-××××</td>
    </tr>
    <tr>
    	<td>5</td><td>クロ</td><td>山口県××××</td><td>083-922-××××</td>
    </tr>
    </table>

  <div class="box-example">
<h3 class="h-example">例8-4</h3>
上記の表のデータを変数に格納し、指定したデータと全てのデータをそれぞれ読み取り表示しています。
</div>
   <!--<script async src="//jsfiddle.net/e7qty36u/5/embed/js,result/"></script>-->
   <iframe width="100%" height="450" src="//jsfiddle.net/ks94jxq7/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>

<section>
  <div class="box-example">
<h3 class="h-example">例8-5</h3>
オブジェクトの中に配列でデータを格納しています。
</div>
   <!--<script async src="//jsfiddle.net/e7qty36u/5/embed/js,result/"></script>-->
   <iframe width="100%" height="350" src="//jsfiddle.net/vg76rhL3/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>

<section>
  <div class="box-example">
<h3 class="h-example">例8-6</h3>
連想配列にデーをを追加して、一覧表示しています。
</div>
   <iframe width="100%" height="350" src="//jsfiddle.net/he1mdoju/2/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</section>


## その他 追加

### 連想配列（オブジェクト）の中の連想配列でkeyとvalueを取り出す方法

<script async src="//jsfiddle.net/hirao/jz7trc32/12/embed/js,result/"></script>


<script async src="//jsfiddle.net/hirao/k8oq6nbf/1/embed/js,result/"></script>

### 連想配列（オブジェクト）の要素数を取得

<p class="tmp"><span>書式</span>連想配列（オブジェクト）の要素数</p>
```
let object1 = {
  プロパティ名: 値,  ...
}

let len = Object.keys(object1).length;//要素数
```
<script async src="//jsfiddle.net/5ytdb91j/embed/js,result/"></script>

### 配列の要素数を取得

<p class="tmp"><span>書式</span>配列の要素数</p>
```
let array1 = ['値',･･･];

// 要素数を取得する
let len = array1.length;
```

<script async src="//jsfiddle.net/cewkoqxf/embed/js,result/"></script>

### 連想配列（オブジェクト）の指定した要素の値の個数を表示

<script async src="//jsfiddle.net/t3kaw5pc/2/embed/js,result/"></script>
    