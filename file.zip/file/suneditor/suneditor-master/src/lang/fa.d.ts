import { Lang } from './Lang';

declare const fa: Lang;

export default fa;