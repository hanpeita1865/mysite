<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MenuService,
    MarkdownService,
    PaginationService,
};
use SocymSlim\SlimMiddle\Config\AppConfig;
use SocymSlim\SlimMiddle\Config\PageArea;//追加



class SearchController
{
    private EditService $editService;
    private FolderService $folderService;
    private MenuService $menuService;
    private MarkdownService $markdownService;
    private AppConfig $config;
    private PaginationService $paginationService;


    
    public function __construct(EditService $editService, FolderService $folderService, MenuService $menuService, MarkdownService $markdownService, AppConfig $config, PaginationService $paginationService)
    {
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->menuService = $menuService;
        $this->markdownService = $markdownService;
        $this->config = $config;
        $this->paginationService = $paginationService;
    }
    

    public function searchResult(Request $request, Response $response, array $args): Response
    {    
        $basePath = $this->config->basePath;
        $viewFlag = $request->getAttribute('viewFlag');

        $uri = $request->getUri();
        $query = $uri->getQuery();
        $path = rtrim($uri->getPath() . ($query ? '?' . $query : ''), '/');
        
        $params = $request->getQueryParams();
        $category = trim($params['cate'] ?? '');

        $folderName = basename($_SERVER['REQUEST_URI']);
        
        // if($category==''){
        //     $searchFolder = '../pages';
        // }else{
        //     $searchFolder = '../pages/'.$category;
        // }
        
        $db = $this->editService->db(); //dbサービス
                    
        
        $pageArea = $params['pageArea'] ?? PageArea::NORMAL;

        if ($pageArea !== PageArea::MANUAL) {
            $pageArea = PageArea::NORMAL;
        }
        
        $pageDir = PageArea::getPageDir($pageArea);

        $folderObj = $this->folderService->getFolderCompCached($pageDir);
        
        $this->menuService->loadLockData($db, $folderObj);//サービス（$lockData、$lockArrayの値をプロパティ設定）
        $lockArray = $this->menuService->getLockArray();

        $menuData = $this->menuService->buildMenuCached($pageDir);//サービス（メニュー生成）
        
        
        if(isset($params['fullText'])){
            $fullText = true;
        }else{
            $fullText = false;
        }
        
        $word = trim($params['word'] ?? '');
        
        $assign['pageArea'] = $pageArea;//追加

        if ($word === '') {
            // 検索語が空なら検索せず、元のページを再描画
            $twig = $this->editService->view();
            $assign = [
                "countIp" => $request->getAttribute('countIp'),
                "pathBase" => $basePath,
                "htmlData" => "検索キーワードが空です。", 
                "title" => "検索",     // 元のページタイトル
                "fullText" => $fullText,
                "menuData" => $menuData,
            ];
            return $twig->render($response, "base.twig", $assign);
        }

        $result = $this->markdownService->searchKeyword($word, $folderObj, $fullText, $lockArray, $pageArea, $category);//$category追加
        
        // $result = $this->markdownService->searchKeyword($word, $folderObj, $fullText, $lockArray, $pageArea);
        
        // $paginationHtml = $this->paginationService->build(
        //     $result['page'],
        //     $result['total'],
        //     $result['perPage'],
        //     [
        //         'word' => $word,
        //         'fullText' => $fullText ? 1 : null
        //     ]
        // );
        

        $assign["isLogin"] = isset($_SESSION['auth_user']);
        $assign["canView"] = false;
        
        if ($assign["isLogin"]) {
            //ログイン済み               
            $role = $_SESSION['auth_user']['role'];
            
            if($role === 'admin'){
                //admin
                $assign["canView"] = true;
                $assign["isAdmin"] = true;
                
            }elseif($role === 'limited_editor'){
                //limited_editor
                if (!isset($_SESSION['registered_pages'])) {
                    $_SESSION['registered_pages'] =
                        $this->folderService->getPageFoldersByUserId($_SESSION['auth_user']['user_id']);
                }
                
                $registeredPages = $_SESSION['registered_pages'];
                
                if(in_array($folderName, $registeredPages, true)){
                    $assign["canView"] = true;
                }
                
            }else{
                //editor
                $assign["canView"] = true;                    
            }
            
            $assign["userName"] = $_SESSION['auth_user']['name'];
        }
                
        $assign["pathBase"] = $basePath;
        // $assign['htmlData'] = $result['html'] . $paginationHtml;
        $assign['htmlData'] = $result['html'];
        $assign["title"] = '検索結果';
        $assign["fullText"] = $fullText;
        $assign["menuData"] = $menuData;
        $assign["redirect"] = $path;

        $twig = $this->editService->view();

        $response = $twig->render($response, "base.twig", $assign); 

        return $response;
    }

    
    //検索用DB一括書き込み
    public function searchdbSave(Request $request, Response $response, array $args): Response
    {
        // $folderObj = $this->folderService->getFolderComp();//サービス
        $rootPath = $this->config->rootPath;
        
        $db = $this->editService->db();//サービス
        
        //データを空にする
        try {
            $table = "page_list";

            $db->exec("TRUNCATE TABLE `$table`");
            echo "テーブルを初期化しました。";

        } catch (PDOException $e) {
            echo "エラー: " . $e->getMessage();
            return $response;
        }


        $db->beginTransaction(); // トランザクション
        
        $sql = $db->prepare("INSERT INTO page_list VALUES (NULL, :fdName, :title, :text, :page_area)");
        // $sql = $db->prepare("INSERT INTO page_list VALUES (NULL, :fdName, :title, :text)");
        
        $folderAreas = [
            [
                'dir' => '../pages',
                'pageArea' => PageArea::NORMAL
            ],
            [
                'dir' => '../manual/pages',
                'pageArea' => PageArea::MANUAL
            ]
        ];
        
        
    foreach ($folderAreas as $folderArea) {

        $dir = $folderArea['dir'];
        $pageArea = $folderArea['pageArea'];

        $folderObj = $this->folderService->getFolderComp($dir);
        
        foreach ($folderObj as $key => $folderDir) {

            $reDir = str_replace($dir . '/', '', $folderDir);

            $fullPath = $rootPath . '/' . str_replace('../', '', $dir) . '/' . $reDir . '/markdown.md';

            if (!file_exists($fullPath)) {
                continue;
            }

            $md = file_get_contents($fullPath);

            $text = $this->markdownService->convertToText($md);

            $title = '';

            if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle)) {
                $title = $ArrayTitle[1];
            }

            $sql->bindValue(':fdName', $key);
            $sql->bindValue(':title', $title);
            $sql->bindValue(':text', $text);
            $sql->bindValue(':page_area', $pageArea);
            $sql->execute();
        }
    }
        
        
        try {
            $db->commit(); // 最後に1回だけ書き込み
            echo "書き込み完了しました。";

        } catch (PDOException $e) {
            echo "書き込みエラー: " . $e->getMessage();
        }
        
        return $response;
    }
    
}    






