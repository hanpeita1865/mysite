---
title: '04. コマンドライン引数やキーボードからの入力を受け取る'
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">コマンドライン引数を受け取る</h2>

プログラムを実行するたびに、プログラムが処理するデータを変更したいことがあります。<br>
例えば、以下は価格のリストから合計金額を求めるプログラムです。

<div class="box-example">
    <h3 class="h-example">例1</h3>
	価格のリストから合計金額を求める
</div>
<p class="editpre"><span>テキストエディタ</span>argv1.py</p>

    list = [120, 150, 230]
    total = 0
    for price in list:
        total += price
    print('合計', total, '円')

<p class="result">実行結果</p>
<pre>
合計 500 円
</pre>

<iframe src="https://paiza.io/projects/e/5iUPkXDY57S7aCkCbGMCsA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


<p class="att">※これでは価格が変わるたびにプログラムを書き換えなくてはいけません。<br>
こんな場合に「コマンドライン引数」を使って、プログラムの実行時にコマンドラインからデータを渡せるようにします。<br>
価格のリストをプログラム内に記述しないので、価格が変わってもプログラムを変更する必要がなくなります。</p>

<p class="tmp"><span>書式1</span>コマンドライン引数の指定</p>

	python プログラム名 引数1 引数2


<p class="att">※コマンドライン引数を使えば、プログラムを変更しなくても手軽に入力データを変えることができます。<br>
コマンドライン引数を受け取るには、sysモジュールの変数srgvを使います。変数argvにはコマンドライン引数の一覧がリストとして保存されています。</p>

<p class="tmp"><span>書式2</span>コマンドライン引数の取得</p>
	sys.argv

<div class="box-example">
    <h3 class="h-example">例2</h3>
	
</div>
<p class="editpre"><span>テキストエディタ</span>argv2.py</p>

    import sys
    print(sys.argv)

<p class="inpre"><span>コマンドライン</span></p>

	python argv2.py 120 150 230


<p class="result">実行結果</p>
<pre>
['argv2.py', '120', '150', '230']
</pre>

※print(sys.argv[1:])のようにすれば、最初のファイル名（argv2.py）を除いたリストが得られます。

<div class="box-example">
    <h3 class="h-example">例3</h3>
	コマンドライン引数を使って、価格リストから合計金額を求める
</div>
<p class="editpre"><span>テキストエディタ</span>argv3.py</p>

    import sys
    total = 0
    for price in sys.argv[1:]:
        total += int(price)
    print('合計', total, '円')

<p class="inpre"><span>コマンドライン</span></p>

	python argv3.py 120 150 230

<p class="result">実行結果</p>
<pre>
合計 500 円
</pre>

<p class="inpre"><span>コマンドライン</span></p>

	python argv3.py 310 250 470

<p class="result">実行結果</p>
<pre>
合計 1030 円
</pre>


<h2 class="h-type2">キーボードからの入力を受け取る</h2>

キーボードから入力を受け取るには、input関数を使います。<br>
input関数を使うために、モジュールをインポートする必要はありません。

<p class="tmp"><span>書式3</span>キーボードから1行の入力を受け取り、末尾の改行を除いて文字列として返す</p>

input()

<p class="inpre"><span>インタプリタ</span></p>

    input()
    >>> input()
    97
    '97'  # 数字を入力した場合も、文字列として入力される


<div class="box-example">
    <h3 class="h-example">例4</h3>
	キーボードから価格を入力するたびに、合計金額を「合計 〇〇円」のように表示し、合計金額が300円よりおおきくなると終了にする
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    total = 0
    while total <= 300:
        price = input()
        total += int(price)
        print('合計', total, '円')

<p class="result">実行結果</p>
<pre>
20
合計 20 円<span class="comment">  # 結果</span>
50
合計 70 円<span class="comment">  # 結果</span>
40
合計 110 円<span class="comment">  # 結果</span>
150
合計 260 円<span class="comment">  # 結果</span>
30
合計 290 円<span class="comment">  # 結果</span>
40
合計 330 円 <span class="comment">  # 300円より大きくなったのでここで終了</span>
</pre>






