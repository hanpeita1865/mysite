<?php
namespace SocymSlim\SlimMiddle\Services;
use Psr\Container\ContainerInterface;


use Spatie\Async\Pool;

class FolderService {
    
    protected $editService;
    private ContainerInterface $container;

    public function __construct(EditService $editService, ContainerInterface $container)
    {
        $this->editService = $editService;
        $this->container = $container;
    }


    //----------------------//
    //     並べ替え確定   
    //---------------------//
    
    public function sortTogether(array $sortHistory): void {

        $folderObj = $this->globAll('../pages');

        // $pool = Pool::create();
        $pool = Pool::create()->concurrency(1); // 同時実行数を制限

        foreach ($sortHistory as $key => $item) {

            $pool[] = async(function ()use($folderObj, $sortHistory, $key, $item) {

                if(rename($folderObj[$item['fdName']], $item['to'])){
                    // unset($sortHistory[$key]);
                    return $key; // 成功したキーを返す
                }else{
                    //失敗
                    sleep(2);
                    if(rename($folderObj[$item['fdName']], $item['to'])){
                        //成功
                    }else{
                        //失敗
                        sleep(2);
                        if(rename($folderObj[$item['fdName']], $item['to'])){
                            //成功
                        }else{
                            //失敗
                            echo '失敗（'.$folderObj[$item['fdName']].'→'.$item['to'].'）';                       
                        }
                    }
                }
            
                return null;
            });

            $folderObj = $this->globAll('../pages');
        }
        
        $results = await($pool);
        
        foreach ($results as $key) {
            if ($key !== null && isset($sortHistory[$key])) {
                unset($sortHistory[$key]);
            }
        }
        
        //試作途中
        if(!empty($sortHistory)){
            echo '移動できてないフォルダがあります。';
            print_r($sortHistory);
        }
    }
    

    //---------------------------------
    // 並べ替え後のフォルダ番号の整理
    //---------------------------------
    
    public function dirNumReplace(array $menuArray, array $folderObj): void
    {
        $menuObj = [];

        // メニュー配列から番号なしフォルダ名を作成
        foreach ($menuArray as $val) {
            $dirArray = explode('/', $val);
            $lastDir = end($dirArray);
            $folderNoNum = preg_replace('/^\d{3}\./', '', $lastDir);
            $menuObj[$folderNoNum] = $lastDir;
        }

        // 実際のフォルダとの突合
        foreach ($folderObj as $key => $dir) {
            if (!isset($menuObj[$key])) {
                continue;
            }

            $menuDirAry = explode('/', $menuObj[$key]);
            $menuFdName = end($menuDirAry);

            $dirArray1 = explode('/', $dir);
            $pagesFdName = end($dirArray1);

            if ($pagesFdName !== $menuFdName) {
                array_pop($dirArray1); // 最後を削除
                $dirArray1[] = $menuFdName; // 新しいフォルダ名を追加
                $newPath = implode('/', $dirArray1);

                if (!rename($dir, $newPath)) {
                    error_log("[FolderService] Rename failed: {$dir} → {$newPath}");
                }
            }
        }
    }
    
    
    //-------------------------
    //   フォルダ一覧を取得
    //-------------------------

    public function getFolderComp(string $dir='../pages'): array {
        return $this->globAll($dir);
    }

    
    //---------------------------------
    // pages配下のフォルダ一覧（再帰）
    //---------------------------------

    private function globAll(string $folder, array &$folderArray = []): array {
        $folderObj = [];

        if (!is_file($folder)) {
            $res = glob($folder . '/*');

            foreach ($res as $f) {
                $dirArray = explode('/', $f);
                $lastDir = end($dirArray);

                if (preg_match('/^\d{3}\./', $lastDir)) {
                    $folderNoNum = preg_replace('/^\d{3}\./', '', $lastDir);
                    $folderObj[$folderNoNum] = $f;
                    $folderArray[] = $f;

                    // 再帰
                    $folderObj = array_merge($folderObj, $this->globAll($f, $folderArray));
                }
            }
        }

        return $folderObj;
    }
    
    

    //-----------------------------
    //   タイトルとパスの一覧を取得
    //-----------------------------

    public function getTitlePathList(string $dir='../pages'): array {
        $config = $this->container->get('config');
        $basePath = $config['basePath'];
        return $this->globTitlePath($dir, $basePath);
    }    
    
    
    //-------------------------------------
    // pages配下のタイトルとパスの一覧（再帰）
    //-------------------------------------
        
    private function globTitlePath(string $folder, string $basePath): array {
        $list = [];

        // ファイルであれば処理しない
        if (is_file($folder)) {
            return $list;
        }

        // ディレクトリ一覧取得
        $items = glob($folder . '/*');

        foreach ($items as $f) {

            $dirArray = explode('/', $f);
            $lastDir = end($dirArray);

            // 例: 001.xxx のフォルダだけ対象
            if (!preg_match('/^\d{3}\./', $lastDir)) {
                continue;
            }

            $title = '';

            // タイトル取得
            if (file_exists($f . '/markdown.md')) {
                $md = file_get_contents($f . '/markdown.md');

                if (preg_match("/^\*\[page-title\]:\s*(.+)/m", $md, $match)) {
                    $title = trim($match[1]);
                }
            }
            
            // パス整形
            $path = str_replace('../pages/', '', $f) . '/';
            $pathRe = preg_replace('/^\d{3}\./', '', $path);
            $pathRe = preg_replace('/\/\d{3}\./', '/', $pathRe);
            $converted = $basePath . '/public/pages/' . $pathRe;           

            $list[] = [
                'title' => $title,
                'path'  => $converted,
            ];

            // ★ 再帰（戻り値をマージ）
            $childList = $this->globTitlePath($f, $basePath);
            $list = array_merge($list, $childList);
        }

        return $list;
    }
    

    //-------------------------------------
    // pages配下のタイトルとパスの一覧（再帰）
    //-------------------------------------

    // private function globTitlePath(string $folder, array &$titlePathArray = []): array {
    //     $titlePathObj = [];

    //     if (!is_file($folder)) {
    //         $res = glob($folder . '/*');

    //         foreach ($res as $f) {
    //             $dirArray = explode('/', $f);
    //             $lastDir = end($dirArray);
                
    //             if (preg_match('/^\d{3}\./', $lastDir)) {
                    
    //                 if (file_exists($f . '/markdown.md')) {
    //                     $md = file_get_contents($f . '/markdown.md');

    //                     if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $match)) {
    //                         $title = $match[1];
    //                     }else{
    //                         $title = '';
    //                     }                   
    //                 }
                                        
    //                 $titlePathObj[$title] = $f;
    //                 $titlePathArray[] = $f;

    //                 // 再帰
    //                 $titlePathObj = array_merge($titlePathObj, $this->globTitlePath($f, $titlePathArray));
                    
    //                 // // ★ ここで配列に追加
    //                 // $titlePathObj[] = [
    //                 //     'title' => $title,
    //                 //     'path'  => $f,
    //                 // ];

    //                 // // ★ 再帰（戻り値をマージ）
    //                 //  $titlePathObj = array_merge($titlePathObj, $this->globTitlePath($f, $titlePathArray));
    //             }
    //         }
    //     }

    //     return $titlePathObj;
    // }
    
    
    
    
    
    
 
    //--------------------------------------------------------------------
    // サブページフォルダを上位階層に移動する（削除で使用）（旧 subpage_move）
    //--------------------------------------------------------------------

    public function subpageMove(string $delFolder): void {
        $delAry = explode('/', $delFolder);
        $delFd = end($delAry); // 例: 042.aaa
        $num = explode('.', $delFd)[0]; // 例: 042

        array_pop($delAry); // 最後を削除
        $parent = implode('/', $delAry); // ../pages

        $this->moveSubpages($delFolder, $delFd, $num, $parent);
    }

    

    //------------------------------------------
    // 実際にサブページを移動する処理（内部専用）
    //------------------------------------------

    private function moveSubpages(string $delFolder, string $delFd, string $num, string $parent): void {
        // 親フォルダが存在しなければスキップ
        if (!is_dir($delFolder)) {
            error_log("[FolderService] 指定フォルダが存在しません: {$delFolder}");
            return;
        }

        // 移動対象フォルダ内のファイルを取得
        $files = glob($delFolder . '/*');

        foreach ($files as $file) {
            $basename = basename($file);
            $newPath = $parent . '/' . $basename;

            if (!rename($file, $newPath)) {
                error_log("[FolderService] ファイル移動失敗: {$file} → {$newPath}");
            }
        }
        
        //対象フォルダをtrushにバックアップ
        $this->trushBackup($delFolder);
        //対象のフォルダを削除
        $this->removeDirectory($delFolder);
        //フォルダ番号再設定
        $this->numberReset($parent);
    }
    
    

    //--------------------------------------
    //  削除フォルダをtrushにバックアップ 
    //--------------------------------------
    
    public function trushBackup(string $delFolder): void {
        date_default_timezone_set('Asia/Tokyo');
        $dateTime = date('Y-m-d_H.i.s');

        $trushDir = '../trush/' . $dateTime;
        if (!file_exists($trushDir)) {
            mkdir($trushDir, 0777, true);
        }

        $delDir = str_replace('pages', 'trush/' . $dateTime, $delFolder);
        if (!file_exists($delDir)) {
            mkdir($delDir, 0777, true);
        }

        $this->copyDirectory($delFolder, $delDir);
    }

    

    //--------------------------------
    //   ディレクトリを再帰的に削除
    //--------------------------------
    
    public function removeDirectory(string $dir): bool {
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = "$dir/$file";
            if (is_dir($path)) {
                $this->removeDirectory($path);
            } else {
                unlink($path);
            }
        }
        return rmdir($dir);
    }

    

    //-------------------------------
    //   ディレクトリを再帰的にコピー
    //-------------------------------

    private function copyDirectory(string $src, string $dst): void {
        if (!file_exists($dst)) {
            mkdir($dst, 0777, true);
        }

        $files = array_diff(scandir($src), ['.', '..']);
        foreach ($files as $file) {
            $srcPath = "$src/$file";
            $dstPath = "$dst/$file";

            if (is_dir($srcPath)) {
                $this->copyDirectory($srcPath, $dstPath);
            } else {
                copy($srcPath, $dstPath);
            }
        }
    }



    //-----------------------------------------------------
    // 同階層フォルダの番号をリセット（001.～の番号振り直し）
    //-----------------------------------------------------
    
    public function numberReset(string $parent): void {
        $parentAry = glob($parent . '/*');
        $num = 1;

        foreach ($parentAry as $val) {
            $valAry = explode('/', $val);
            $lastData = end($valAry);

            if (preg_match('/^\d{3}\./', $lastData)) {
                $name = explode('.', $lastData)[1];      // 例: aaa
                $fdNum = sprintf('%03d', $num);          // 3桁番号
                $fdName = $fdNum . '.' . $name;

                array_pop($valAry);
                array_push($valAry, $fdName);
                $newDir = implode('/', $valAry);

                rename($val, $newDir);
                $num++;
            }
        }
    }
    

    /**
     * 並び替え（フォルダ番号修正）
     * 旧: dirNumReplace
     */
    // public function dirNumReplace(string $parent): void
    // {
    //     $this->numberReset($parent);
    // }
    

    
    //------------------------------------------------------------
    // 対象フォルダを中身ごと削除（trushにバックアップしてから削除）
    //------------------------------------------------------------
    
    public function deleteAllFolder(string $delFolder): void
    {
        // trushにバックアップ
        $this->trushBackup($delFolder);

        // 本体削除
        $this->removeDirectory($delFolder);

        // 親フォルダのパス取得
        $delAry = explode('/', $delFolder);
        array_pop($delAry);
        $parent = implode('/', $delAry);

        // 番号を再設定
        $this->numberReset($parent);
    }
    
    
  
    //-------------------------------
    //      新規フォルダ作成
    //-------------------------------
    
    public function createNewFolder(string $newFolder): bool {
        // --- 1️. 入力チェック ---
        if (trim($newFolder) === '') {
            throw new \InvalidArgumentException('フォルダ名を入力してください。');
        }

        // 半角英数字記号のみ許可
        if (!preg_match("/^[!-~]+$/", $newFolder)) {
            throw new \InvalidArgumentException('半角英数字記号で入力してください。');
        }

        // --- 2️. pages 直下の最大番号を調べる ---
        $pagesDir = '../pages';
        if (!is_dir($pagesDir)) {
            throw new \RuntimeException('pagesディレクトリが存在しません。');
        }

        $pagesGlob = glob($pagesDir . '/*', GLOB_ONLYDIR);
        $maxNum = 0;

        foreach ($pagesGlob as $val) {
            $dirName = basename($val);
            if (preg_match('/^(\d{3})\./', $dirName, $m)) {
                $num = (int)$m[1];
                if ($num > $maxNum) {
                    $maxNum = $num;
                }
            }
        }

        // --- 3️. 新しい番号とディレクトリ名を作成 ---
        $nextNum = sprintf('%03d', $maxNum + 1);
        $baseDir = "{$pagesDir}/{$nextNum}.{$newFolder}";

        // --- 4️. 既に同名フォルダがある場合のチェック ---
        $folderObj = $this->globAll('../pages');

        if (array_key_exists($newFolder, $folderObj)) {
            throw new \RuntimeException("同名のフォルダ '{$newFolder}' がすでに存在します。");
        }

        // --- 5. 実際の作成処理 ---
        if (!mkdir($baseDir, 0777, true)) {
            throw new \RuntimeException("フォルダ作成に失敗しました。: {$baseDir}");
        }

        mkdir("{$baseDir}/upload", 0777, true);

        $mdPath = "{$baseDir}/markdown.md";
        if (!file_put_contents($mdPath, '*[page-title]:メニュー名')) {
            throw new \RuntimeException("{$mdPath} の作成に失敗しました。");
        }

        return true;
    }

    
    


    //------------------------------------------
    // メニュー名変更 既存のメソッド群の下に追記 
    //------------------------------------------
    
    public function renameMenu(string $dirName, string $oldMenu, string $newMenu): bool
    {
        $targetFile = "../pages/{$dirName}/markdown.md";

        if (!file_exists($targetFile)) {
            throw new \Exception("ファイルが見つかりません: {$targetFile}");
        }

        $md = file_get_contents($targetFile);

        // page-title 行を検索して置換
        if (preg_match("/^\*\[page-title\]:\s*(.+)/m", $md)) {
            $md = preg_replace(
                "/^\*\[page-title\]:\s*(.+)/m",
                "*[page-title]:{$newMenu}",
                $md
            );
        } else {
            // title 行がなければ先頭に追加
            $md = "*[page-title]:{$newMenu}\n\n" . $md;
        }

        file_put_contents($targetFile, $md);
        return true;
    }
    
    
    
    //--------------------------
    //     フォルダ名変更
    //--------------------------
    
    public function renameFolder(string $oldDir, string $newDir, string $oldName, string $newName): string
    {
        // 🔹 入力値バリデーションをここで実施
        $this->validateFolderName($newName);
        
        // 半角英数字記号チェック
        if (!preg_match("/^[!-~]+$/", $newDir)) {
            return "半角英数字記号で入力してください。";
        }

        $oldPath = "../pages/{$oldDir}";
        $newPath = "../pages/{$newDir}";

        // フォルダ名変更処理
        if (!rename($oldPath, $newPath)) {
            return "変更に失敗しました。";
        }
        

        // DB更新処理
        $db = $this->editService->db();

        $sql = $db->prepare("SELECT * FROM locklist WHERE page = ?");
        $sql->execute([$oldName]);
        $lockCnt = $sql->rowCount();

        if ($lockCnt) {
            $result = $sql->fetch(PDO::FETCH_ASSOC);
            $updateSql = $db->prepare("UPDATE locklist SET page = ? WHERE id_lock = ?");

            if (!$updateSql->execute([$newName, $result['id_lock']])) {
                return "テーブル修正に失敗しました。";
            }
        }

        return "フォルダ名を「{$newName}」に変更しました。";
    }
    
    
    /**
     * 🔹 フォルダ名バリデーション
     */
    private function validateFolderName(string $name): void {
        // 空チェック
        if ($name === '') {
            throw new Exception("フォルダ名が空です。");
        }

        // 禁止文字チェック
        if (preg_match('/[.*":?<>\/\\\\]/', $name)) {
            throw new Exception('フォルダ名に使用できない文字（. * " : ? < > / \\）が含まれています。');
        }

        // 半角英数字記号チェック
        if (!preg_match('/^[!-~]+$/', $name)) {
            throw new Exception('英数字以外の文字、または全角文字・空白が含まれています。');
        }
    }
    
    

    //-----------------------------------
    //   ファイルアイコン設定 作成途中
    //-----------------------------------
        
    public function fileIcon() {
        
            //更新日付順表示（古い順）
            $sort_by_lastmod = function ($a, $b) {
                return  filemtime($a) - filemtime($b);
            };

            $folderObj = $this->globAll('../pages');
            
            $folderDir = $folderObj[$_REQUEST['folder']];
            $totalList = '';

            $files = glob($folderDir . '/upload/*');
            
            usort($files, $sort_by_lastmod);

            if (empty($files)) {
                $fileList = '';
            } else {
                foreach ($files as $item) {
                    $file_name = basename($item); //ファイル名だけを抜き出す
                    $fileClass = '';
                    $photo = false;

                    switch (1) {
                            //エクセル
                        case preg_match('/.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/', $file_name):
                            $fileClass = 'file_icon excel-icon';
                            break;
                            //テキスト
                        case preg_match('/.txt$/', $file_name):
                            $fileClass = 'file_icon text-icon';
                            break;
                            //ワード
                        case preg_match('/.doc$|.docm$|.docx$|.dot$|.dotx$/', $file_name):
                            $fileClass = 'file_icon word-icon';
                            break;
                            //パワーポイント
                        case preg_match('/.pptx$/', $file_name):
                            $fileClass = 'file_icon pptx-icon';
                            break;
                            //zipファイル
                        case preg_match('/.zip$/', $file_name):
                            $fileClass = 'file_icon zip-icon';
                            break;
                            //PDFファイル
                        case preg_match('/.pdf$/', $file_name):
                            $fileClass = 'file_icon pdf-icon';
                            break;
                            //画像
                        case preg_match('/.png$|.PNG$|.jpg$|.jpeg$|.JPG$|.JPEG$|..svg$|.svgz$|.gif$|.webp$/', $file_name):
                            $fileClass = 'file_icon pdf-icon';
                            $photo = true;
                            break;
                    }

                    if (!$photo == true) {
                        $fileList = '<li class="file-list"><span class="filename ' . $fileClass . '">' . $file_name . '</span><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                    } else {
                        $fileList = '<li class="photo-list"><span class="filename">' . $file_name . '</span><img src="' . $folderDir . '/upload/' . $file_name . '" alt=""><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                    }

                    $totalList = $totalList . $fileList;
                }
            }

            return $totalList;
        }
       
}