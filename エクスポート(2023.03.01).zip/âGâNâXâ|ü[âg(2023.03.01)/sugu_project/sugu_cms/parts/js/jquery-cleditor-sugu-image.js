/**
 @preserve CLEditor Image Insert Plugin with Sugutsukaeru CGI v1.0.0
 http://premiumsoftware.net/cleditor
 requires CLEditor v1.4.4 or later
*/

(function($) {

  // Define the inlineimage button
  $.cleditor.buttons.inlineimage = {
    name: "inlineimage",
    image: "../img/inlineimage.gif",
    title: "Insert Images and Files",
    command: "inserthtml",
    popupName: "image and files",
    popupClass: "cleditorPrompt",
    popupContent:
      "__OPTIONS__",
    buttonClick: imageSelect
  };

  // Add the button to the default controls
  $.cleditor.defaultOptions.controls = $.cleditor.defaultOptions.controls
    .replace("image ", "image inlineimage ");

	//オプションコードを作成
	//上段：管理画面の選択用ボタン
	//下段：挿入するコード
	var BtnTplt4Img = [
		[
			'<button type="button" data-group="img" data-index="__INDEX__" data-thumb="__THUMB__" data-alt="__ALT__" data-href="__HREF__" class="sugu-image-select-button"><img src="__THUMB__" alt="__ALT__" style="width: 50px;"> (元画像)<\/button>',
			'<img src="__HREF__" alt="__ALT__">'
		]
		,[
			'<button type="button" data-group="img" data-index="__INDEX__" data-thumb="__THUMB__" data-alt="__ALT__" data-href="__HREF__" class="sugu-image-select-button"><img src="__THUMB__" alt="__ALT__" style="width: 50px;"> (サムネイル)<\/button>',
			'<a href="__HREF__" target="_blank" title="拡大:__ALT__" class="image-link" data-caption="__ALT__"><img src="__THUMB__" alt="__ALT__"></a>'
		]
	];
	var BtnTplt4File = [
		[
			'<button type="button" data-group="file" data-index="__INDEX__" data-alt="__ALT__" data-href="__HREF__" data-icon="__ICON__" class="sugu-file-select-button"><span class="filelink __ICON__">__ALT__<\/span><\/button>',
			'<a href="__HREF__" class="filelink __ICON__">__ALT__</a>'
		]
	];
	var OptionList = $("<div/>");
	$('a[id^="current_image_"][class~="current_image"]').each(function(){
		var myId=$(this).attr("id");
		if (myId.match(/_[2345]$/)){ //本文に挿入したい画像番号
			var myHref=$(this).attr("href");
			var myAlt=$(this).attr("title");
			var thumbSrc=$(this).find("img").first().attr("src");
			for (i=0; i < BtnTplt4Img.length; i++){
				OptionList.append(
						$("<div/>")
						.html(
							BtnTplt4Img[i][0]
							.replace(/__INDEX__/g, i)
							.replace(/__THUMB__/g, thumbSrc).replace(/__ALT__/g, myAlt).replace(/__HREF__/g, myHref)
						)
					);
			}
		}
	});

	$('a[id^="current_image_"][class~="current_file"]').each(function(){
//	$('a[id^="current_image_"][class~="current_file"], a[id^="current_file_"]').each(function(){ // 繰り返しファイルも本文に挿入したい場合
		var myHref=encodeURI($(this).attr("href"));
		var myAlt=$(this).attr("title");
		var myClass=$(this).attr("class").replace(/\s*current_file\s*/, "").replace(/\s*filelink\s*/, "");
		for (i=0; i < BtnTplt4File.length; i++){
			OptionList.append(
					$("<div/>")
					.html(BtnTplt4File[i][0]
						.replace(/__INDEX__/g, i)
						.replace(/__ALT__/g, myAlt).replace(/__HREF__/g, myHref).replace(/__ICON__/g, myClass)
					)
				);
		}
	});
	if (OptionList.html() != ""){
		$.cleditor.buttons.inlineimage.popupContent = $.cleditor.buttons.inlineimage.popupContent
				.replace(/__OPTIONS__/, OptionList.html())
			;
	} else {
		$.cleditor.buttons.inlineimage.popupContent = $.cleditor.buttons.inlineimage.popupContent
				.replace(/__OPTIONS__/, "Upload image or file first")
			;
	}

  // Inline Image button click event handler
  function imageSelect(e, data) {
	// Get the editor
	var editor = data.editor;

    // Wire up the button click event handler
    $(data.popup).find("button")
      .unbind("click")
      .bind("click", function(e) {

        // Get image info
 		var myGrp=$(this).attr("data-group");
		var myHref=$(this).attr("data-href");
		var myAlt=$(this).attr("data-alt");
		var myIndex=$(this).attr("data-index");
		var imagelink;
		if (myGrp == "img"){
			var myThumb=$(this).attr("data-thumb");
			imagelink = BtnTplt4Img[parseInt(myIndex)][1]
				.replace(/__HREF__/g, myHref)
				.replace(/__THUMB__/g, myThumb)
				.replace(/__ALT__/g, myAlt)
			;
		} else if (myGrp == "file"){
			var myIcon=$(this).attr("data-icon");
			imagelink = BtnTplt4File[parseInt(myIndex)][1]
				.replace(/__HREF__/g, myHref)
				.replace(/__ICON__/g, myIcon)
				.replace(/__ALT__/g, myAlt)
			;
		}

          editor.execCommand(data.command, imagelink, null, data.button);
	      editor.hidePopups();
	      editor.focus();
      });

    }

})(jQuery);