*[page-title]:Chap5-1 アプリケーションをテストする

※ワードパッドに記載済み「5-01 アプリケーションをテストする」

Webアプリケーションを安定して運用していくためには、テストが不可欠です。ここでは、テスト用のコードの書き方についてみていきましょう。

## Laravelのテスト機能

Webアプリケーションのテストは重要です。もしテストがなければ、リリースのたびに追加したコードによって以前の機能が壊れていないかを気にする必要があるでしょう。  
もちろん手動で毎回テストを行うことも可能ですが、ページや機能が増えるほど、テストにかかる時間も増えていきます。少しでもその労力を減らすために、コードによるテストが可能な場所については、積極的にテストコードを書いていきたいものです。

ここでは、次の3つのテストに焦点を当てて解説していきます。

<div markdown="1" class="bold green">
* ユニットテスト
* フィーチャーテスト
* ブラウザテスト
</div>

Laravelでは「<span class="red">PHPUnit</span>」がデフォルトでサポートされており、各種テストを実行することができます。

testsディレクトリには、<span class="red bold">ユニットテスト（単体テスト）</span>が配置できる「<span class="red">Unitディレクトリ</span>」と<span class="blue bold">フィーチャーテスト（機能テスト）</span>が配置できる「<span class="blue">Featureディレクトリ</span>」が最初から用意されています。
![](upload/Feature、Unitディレクトリ.png){.photo-border}

また、[Laravel Dusk](https://readouble.com/laravel/10.x/ja/dusk.html)というブラウザテストをサポートするツールも公式から提供されています。


### テストの概要
各テストの詳細に入る前に、まずはテストコマンドを紹介します。テストには次のようなコマンドが用意されています。

<span class="red">※実行すると現在のデータベースに存在するデータが削除されるので注意してください。</span>
<p class="tmp cmd"><span>コマンド</span></p>
```
sail test
```

現状で実行するとデータベースに存在するこれまでのデータがすべて消えてしまいますが、仮にコマンドを実行した場合はいくつかのテストが実行され、すべてのテストがパスします。

前述したように、 Laravelではユニットテスト、 フィーチャーテストのサンプルテストが初めから用意されているためそれが実行されています。

* ユニットテスト : tests/Unit/ExampleTest.php
* フィーチャーテスト : tests/Feature/ExampleTest.php

また、Laravel Breezeを導入している場合、Featureにその他のテストも追加されており、それらも実行されています。
まずはこのようにコマンドを1つ実行するだけで、複数のテストを実行できることを理解しておきましょう。


## ユニットテスト

ユニットテストは単体テストとも呼ばれ、アプリケーション全体ではなくクラスなどの小さい単位に対して動作の検証を行います。  
ここからはすでに作成されている、「app/Services/TweetService.php」の「checkOwnTweet」に対するユニットテストを実装していきます。

### 処理の流れを確認
まずは、改めて「checkOwnTweet」の処理を確認してみましょう。

<p class="tmp list"><span>リスト1-1</span>app/Services/TweetService.phpの「<span class="red">checkOwnTweet</span>」メソッド</p>
```
// 自分のtweetかどうかをチェックするメソッド
public function checkOwnTweet(int $userId, int $tweetId): bool //･･･(1)
{
    $tweet = Tweet::where('id', $tweetId)->first(); //･･･(2)
    if (!$tweet) {
        return false; //･･･(3)
    }

    return $tweet->user_id === $userId; //･･･(4)
}
```
1. まず引数で<span class="bold">$userld（ユーザーID）</span>と<span class="bold">$tweetld（つぶやきID）</span>を受け取る。
2. Tweetモデルを使い、引数で受け取ったつぶやきIDに合致するデータをデータベースから取得する。
3. つぶやきIDに合致するデータがなければfalseを返す。
4. データがある場合は、取得したつぶやきのユーザーIDと引数で受け取ったユーザーIDが等しければtrueを返し、違えばfalseを返す。

checkOwnTweetメソッドの処理の流れは以上のようになっており、投稿者のみがつぶやきの編集削除ができるように制御するメソッドです。


### テストコードの作成

処理の流れが確認できたところで早速テストを書いていきます。  
まず次のコマンドを実行しましょう。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:test Services/TweetServiceTest --unit
```
![](upload/TweetServiceTest--unit.png){.photo-border}

すると「tests/Unit/Services/<span class="red">TweetServiceTest.php</span>」ファイルが作成されます。
![](upload/TweetServiceTest.phpファイル作成.png){.photo-border}

<p class="tmp list"><span>リスト1-2</span>tests/Unit/Services/TweetServiceTest.php（デフォルト）</p>
```
<?php

namespace Tests\Unit\Services;

use PHPUnit\Framework\TestCase;

class TweetServiceTest extends TestCase
{
    /**
     * A basic unit test example.
     */
    public function test_example()
    {
        $this->assertTrue(true);
    }
}
```

このようにサンプルのテストが書かれた状態でファイルが生成されますので、「<span class="bold">test_exampl()</span>」を書き換えながらテストを書いていきます。  
まずはテストのメソッド名を変更しましょう。「<span class="red">test_check_own_tweet</span>」という名前に変更して書き進めていきます。

<p class="tmp list"><span>リスト1-3</span>tests/Unit/Services/TweetServiceTest.php</p>
```
･･･省略･･･
class TweetServiceTest extends TestCase
{
    public function test_check_own_tweet()
    {
        $this->assertTrue(true);
    }
}
```

何はともあれTweetServiceクラスをインスタンス化しないとはじまらないので、インスタンスを作成します。

<p class="tmp list"><span>リスト1-4</span>tests/Unit/Services/TweetServiceTest.php</p>
```
<?php

namespace Tests\Unit\Services;

use PHPUnit\Framework\TestCase;
use App\Services\TweetService;//追加

public function test_check_own_tweet()
{
    $tweetService = new TweetService(); // TweetServiceのインスタンスを作成
    $this->assertTrue(true);
}
```

ファイルの冒頭に「use App\Services\TweetService;」を指定するのも忘れないようにしましょう。  
今回チェックしたいのは「checkOwnTweet」の動作です。先ほど処理の流れを確認した通り、渡された$userldと$tweetldによってtrueかfalseが返ってくるかどうかが確認できれば問題ないでしょう。まずはtrueになるかどうかを確認するテストを書いてみます。

<p class="tmp list"><span>リスト1-5</span>tests/Unit/Services/TweetServiceTest.php</p>
```
･･･省略･･･
public function test_check_own_tweet()
{
    $tweetService = new TweetService();

    $result = $tweetService->checkOwnTweet(1, 1);//追加
    $this->assertTrue($result);
}
```

checkOwnTweetには「<span class="bold">ユーザーIDが1</span>」、「<span class="bold">つぶやきIDが1</span>」の値を引数に渡しています。
「$this->assertTrue($result);」は$resultの値がtrueであるかどうかをチェックする「<span class="red">アサーションメソッド</span>」になります。


<div markdown="1" class="memo-box">
#### アサーションメソッド
assertooはアサーションメソッドと呼ばれ、PHPUnitで利用することができるメソッドで、いろいろな値のチェックを行えます。今回はtrueとfalseを判定するために「<span class="red">assertTrue</span>」と「<span class="red">assertFalse</span>」を利用しています。  
その他にも「assertNull($result)」は$resultがNULLかをチェックし、「assertEquals($val1,$val2)」は$valと$val2が等しいかをチェックするなど、さまざまなアサーションメソッドがあります。テストに応じて使い分けましょう。
</div>

続いてfalseになるかどうかを確認するテストも追加します。

<p class="tmp list"><span>リスト1-6</span>tests/Unit/Services/TweetServiceTest.php</p>
```
public function test_check_own_tweet()
{
    $tweetService = new TweetService();

    $result = $tweetService->checkOwnTweet(1, 1);
    $this->assertTrue($result);

    $result = $tweetService->checkOwnTweet(2, 1);//追加
    $this->assertFalse($result);//追加
}
```

checkOwnTweetには「ユーザーIDが2」、「つぶやきIDが1」の値を引数に渡しています。「$this->assertFalse($result);」は、先ほどとは逆に$resultの値がfalseであるかどうかをチェックします。

### モックを利用する

ここまでで書いたテストですが、つぶやきIDが1の投稿をしたユーザーのユーザーIDが1であるというデータがデータベースに存在すれば正しく動作するでしょう。ですが、<span class="marker-yellow50 bold">ユニットテストは基本的にはデータベースに接続しないで行うのが望ましいです</span>。

ユニットテストは冒頭でも触れた通り、アプリケーション全体ではなくクラスなどの小さい単位に対する動作確認であることから、外部接続を行うデータベースや外部サイトのAPI呼び出しなどに依存しないようにするためです。TweetServiceクラスのcheckOwnTweetメソッドの中では冒頭で処理の流れを確認いただいた通り、「<span class="red">$tweet = Tweet::where('id', $tweetld) ->first();</span>」の部分でデータベースに問い合わせをしています。この部分をデータベースに接続しないようにしていきます。そのために利用する機能が「<span class="green bold marker-yellow50">モック</span>」です。

まずは実際にモックを利用したテストコードを見てみましょう。

<p class="tmp list"><span>リスト1-7</span>tests/Unit/Services/TweetServiceTest.php（全文）</p>
```
<?php

namespace Tests\Unit\Services;

use PHPUnit\Framework\TestCase;
use App\Services\TweetService;
use Mockery;//追加1

class TweetServiceTest extends TestCase
{
/**
    * @runInSeparateProcess
    * @return void
    */
    public function test_check_own_tweet()
    {
        $tweetService = new TweetService();

        $mock = Mockery::mock('alias:App\Models\Tweet');//追加2
        $mock->shouldReceive('where->first')->andReturn((object)[ //追加3
            'id' => 1,
            'user_id' => 1
        ]);

        $result = $tweetService->checkOwnTweet(1, 1);
        $this->assertTrue($result);

        $result = $tweetService->checkOwnTweet(2, 1);
        $this->assertFalse($result);
    }
}
```

冒頭に「<span class="red">use Mockery;</span>」を追加しています。 このMockeryというツールでモックを作成することができます。モックを利用することで、データベース接続や外部サイトのAPI呼び出し部分を、テスト実行時にのみ、コード内で想定動作を模したものに置き換えられます。ユニットテストの独立性を高め、テストを書きやすくする役割を持ちます。

先ほどのテストコード内では 、追加2の「`$mock= Mockery::mock('alias: App\Models\Tweet'); `」 の部分でTweetモデルの<span class="green bold">モックオブジェクト</span>を作成しています。ここで作成している<span class="green bold">モックオブジェクト</span>はApp\Models\Tweets.phpをテストのために差し替えた模造品、と考えてよいでしょう。 次に、<span class="green bold">モックオブジェクト</span>に対して「Tweet::where('id', $tweetld) ->first();」が実行された場合の処理を追加しています（追加3コード）。

```
$mock->shouldReceive('where->first')->andReturn((object)[
    'id' => 1,
    'user_id' => 1
]);
```

shouldReceiveには呼び出されるメソッド名を入れますが、今回は「where('id', $tweetld)->first();」のように->でつないだメソッドチェーンになっていますので、引数に「where->first」を指定しています。そして、そのメソッドが呼び出された場合には「idが1」、「user_idが1」のオブジェクトを返すように指定しました。  
このようにして、本来はデータベースへの接続を行ってデータの取得をするTweetモデルを、自身で定義したモックオブジェクトに置き換えられます。

また、Docコメントに「<span class="red">@runInSeparateProcess</span>」を追加しています。通常はコメントとして無視される部分ですが、PHPUnitに対しては有効です。今回利用している「Mockery:: mock('alias:App\Models\Tweet');」のモックはEloquentモデルを簡単にモックできるものの、とても強力で他のテストに影響を及ぼしてしまう可能性が高く、別のテストとは違うプロセスで動くようにアノテーションを追加しています。

それではテストを実行してみましょう。テストファイルを指定することで、そのテストのみを実行することができます。

<div markdown="1" class="memo-box">
アノテーションとは、コードに対してコメントを利用して情報(メタデータ)を追記できる仕組みです。PHPではドキュメントコメント(Docコメント)と呼ばれます。PHPUnitが解釈するアノテーション以外にも、引数のパラメータに情報を付与したり、PHPStanなどの静的解析ツールが解釈するものを記述することができます。
</div>

<p class="tmp cmd"><span>コマンド</span>ユニットテスト実行</p>
```
sail test tests/Unit/Services/TweetServiceTest.php
```
![](upload/TweetServiceTest.php実行エラー.png)
エラーが表示された・・・。

対応
: [https://teratail.com/questions/ts1h4uz96w8slg](https://teratail.com/questions/ts1h4uz96w8slg)

tests\Unit\Services\TweetServiceTest.phpのアノテーションを消す
![](upload/アノテーションを消す.png)

そうするとうまく動作しました。
![](upload/そうするとうまく動作した.png)

このようにテストがパスしたはずです。無事app/Services/TweetService.phpのcheckOwnTweetに対するユニットテストを実装することができました。 

例えば、故意にテストで引っかかるように一つ目の値を「`$result = $tweetService->checkOwnTweet(5, 4);`」に替えて、テスト実行してみます。  
![](upload/chekowntestの値を変更.png)
そうすると、次のように表示されます。  
テストでエラーがあることが確認できます。
![](upload/checkoentestチェックでエラーメッセージ.png)


Tweetモデルをモックにして実行した箇所については少々とっつきにくいかもしれませんが、データベースへ接続することなくテストできるため、データベースへの依存をなくしテストを安定させるための手法の一つとしてぜひ覚えておきましょう。


## フィーチャーテスト

フィーチャーテストは機能テストとも呼ばれます。ユニットテストはクラスなど小さい単位に対するテストでしたが、フィーチャーテストは「<span class="marker-yellow50">複数のクラスが組み合わさった場合の一連の動作のテスト</span>」を行います。

ここではつぶやきの削除を行うための「app/Http/Controllers/Tweet/<span class="red">DeleteController.php</span>」の機能に対するテストを実装していきたいと思います。

### 処理の流れを確認

まず改めてDeleteController.phpを確認してみます。

<p class="tmp list"><span>リスト2-1</span>app/Http/Controllers/Tweet/DeleteController.php</p>
```
class DeleteController extends Controller
{
    public function __invoke(Request $request, TweetService $tweetService)
    {
        $tweetId = (int) $request->route('tweetId');//･･･(1)
        if (!$tweetService->checkOwnTweet($request->user()->id, $tweetId)) {//･･･(2)
            throw new AccessDeniedHttpException();//･･･(3)
        }

        $tweetService->deleteTweet($tweetId);//･･･(4)
        return redirect()//･･･(5)
            ->route('tweet.index')
            ->with('feedback.success', "つぶやきを削除しました");
    }
}
```

1. まずつぶやきIDをリクエストから取得
2. ログイン中のユーザーIDを取得し、つぶやきIDと一緒に先ほどテストを書いた 「checkOwnTweet」に値を渡す。
3. つぶやきを削除できるユーザーでなければ「AccessDeniedHttpException」を返す。
4. つぶやきを削除できるユーザーであればデータを削除。
5. つぶやき削除後に一覧ページ (/tweet) にリダイレクトしてメッセージを表示。

DeleteController.phpの処理の流れは以上のようになっています。

### テスト用のデータベースの設定

フィーチャーテストではデータベースへの接続も含めたテストを行いますので、テスト用のデータベースの設定を行います。  
「<span class="red">docker-compose.yml</span>」にテストデータベースの定義を追加します。

<p class="tmp list"><span>リスト2-2</span>docker-compose.yml</p>
```
…省略…
    mysql:
        …省略…
    //テスト用追加
    mysql.test:
        image: 'mysql/mysql-server:8.0'
        environment:
            MYSQL_ROOT_PASSWORD: '${DB_PASSWORD}'
            MYSQL_ROOT_HOST: "%"
            MYSQL_DATABASE: '${DB_DATABASE}'
            MYSQL_USER: '${DB_USERNAME}'
            MYSQL_PASSWORD: '${DB_PASSWORD}'
            MYSQL_ALLOW_EMPTY_PASSWORD: 1
        networks:
            - sail
        healthcheck:
            test: [ "CMD", "mysqladmin", "ping", "-p${DB_PASSWORD}" ]
            retries: 3
            timeout: 5s
    redis:
        …省略…
```
![](upload/mysql.test設定コード.png "図　docker-compose.yml")

追記する際にはインデントが揃うように注意してください。
追記が完了したら「<span class="red">sail up -d</span>」コマンドを実行してテストデータベースを起動するのを忘れないようにしましょう。

次にプロジェクト直下のphpunit.xmlを修正します。 phpunit.xmlではテスト時に利用する環境変数の定義をすることができます。


<p class="tmp list"><span>リスト2-3</span>phpunit.xml</p>
```
    <php>
        <env name="APP_ENV" value="testing"/>
        <env name="BCRYPT_ROUNDS" value="4"/>
        <env name="CACHE_DRIVER" value="array"/>
        <!-- <env name="DB_CONNECTION" value="sqlite"/> -->
        <!-- <env name="DB_DATABASE" value=":memory:"/> -->
        <env name="DB_HOST" value="mysql.test"/><!--追加-->
        <env name="MAIL_MAILER" value="array"/>
        <env name="QUEUE_CONNECTION" value="sync"/>
        <env name="SESSION_DRIVER" value="array"/>
        <env name="TELESCOPE_ENABLED" value="false"/>
    </php>
```

「`<env name="DB_HOST" value="mysql.test" />`」の行を追加しましょう。こうすることで、テスト時のみ「<span class="red">DB_HOST</span>」が切り替わり、先ほど「<span class="red">docker-compose.yml</span>」に定義したテスト用のデータベースを参照するようになります。

### テストコードの作成

データベースの設定が完了したので、 テストを書いてみましょう。
```
sail artisan make:test Tweet/DeleteTest
```
![](upload/DeleteTestコマンド.png)

ユニットテストの作成の際には`--unit`をコマンド末尾に付与しましたが、フィーチャーテストの作成の場合には必要ありません。このコマンドを実行すると「tests/Feature/Tweet/<span class="red">DeleteTest.php</span>」が作成されます。
![](upload/DeleteTest.php作成.png){.photo-border}


<p class="tmp list"><span>リスト2-4</span>tests/Feature/Tweet/DeleteTest.php（デフォルト）</p>
```
<?php

namespace Tests\Feature\Tweet;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class DeleteTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_example()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }
}
```

作成されたサンプルテストでは、「$response=$this->get('/');」でトップページにアクセスし、そのページのステータスコードが200であるかどうかを「$response->assertStatus(200);」で確認しています。  
このようにフィーチャーテストではHTTPリクエストを送った場合のテストが可能です。  
今回はつぶやき削除のHTTPリクエスト「<span class="red">/tweet/delete/{tweetld}</span>」に対するテストを実装していきます。

<p class="tmp list"><span>リスト2-5</span>tests/Feature/Tweet/DeleteTest.php</p>
```
class DeleteTest extends TestCase
{
    …省略…
    public function test_delete_successed()
    {
        $response = $this->delete('/tweet/delete/1');

        $response->assertRedirect('/tweet');
    }
}
```

「`$response->assertRedirect('/tweet');`」は/tweetページにリダイレクトしたことを確認するためのアサーションになります。  
ここで一度テストを実行してみましょう。 次のコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail test tests/Feature/Tweet/DeleteTest.php
```
![](upload/DeleteTest実行エラー表示.png "図　エラー表示")

テストは失敗するはずですが、問題ありません。ここから必要な実装を加えていきましょう。  
まずは、「<span class="red">use RefreshDatabase;</span>」の行を追加します。

<p class="tmp list"><span>リスト2-6</span>tests/Feature/Tweet/DeleteTest.php</p>
```
class DeleteTest extends TestCase
{
    use RefreshDatabase;//追加
    …省略…

    public function test_delete_successed()
    {
        $response = $this->delete('/tweet/delete/1');

        $response->assertRedirect('/tweet');
    }
}
```

この「<span class="red">use RefreshDatabase;</span>」はLaravelのフィーチャーテストで利用できる機能で、テストの実行前後にデータベースが初期化されます。今回作成しているのはつぶやき削除のテストですが、<span class="blue bold">つぶやき投稿</span>や<span class="blue bold">更新</span>などのテストも実装する場合、それらのデータが存在することによって不整合が発生し、テストが正しく動かないという事態が起こりえます。

そのような問題を回避するために、データの不整合が起こらないように気をつけながらテストを書くというのも1つの方法ではありますが、今回はテストの独立性を高めるため「<span class="red">use RefreshDatabase;</span>」 を利用します。


### テスト用のデータの作成
さて、削除のテストを成功させるためには、実際にデータベースにデータが存在する必要があります。次の2つが必要です。

1. 削除したいつぶやきのデータ
2. そのつぶやきを投稿したユーザーのデータ

テストのためにこの2つのデータを作成していきます。  
まずはユーザーのデータから作成します。すでに作成しているUserモデルのファクトリーを利用してユーザーを作成します。

<p class="tmp list"><span>リスト2-7</span>tests/Feature/Tweet/DeleteTest.php</p>
```
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;

class DeleteTest extends TestCase
{
…省略…
    public function test_delete_successed()
    {
        $user = User::factory()->create(); // ユーザーを作成

        $response = $this->delete('/tweet/delete/1');

        $response->assertRedirect('/tweet');
    }
}
```

続いてつぶやきも作成していきましょう。こちらはTweetファクトリーを使います。ファクトリーのcreateメソッドの引数に先に作成したユーザーのIDを指定します。

<p class="tmp list"><span>リスト2-8</span>tests/Feature/Tweet/DeleteTest.php</p>
```
…省略…
use Tests\TestCase;
use App\Models\User;
use App\Models\Tweet;

…省略…
    public function test_delete_successed()
    {
        $user = User::factory()->create();

        $tweet = Tweet::factory()->create(['user_id' => $user->id]); // つぶやきを作成

        $response = $this->delete('/tweet/delete/' . $tweet->id); // 作成したつぶやきIDを指定

        $response->assertRedirect('/tweet');
    }
}
```

ところでつぶやきの削除はつぶやいたユーザーのみが行える仕様なので、ログインが必要になります。 Laravelのフィーチャーテストでは、ログインに関してもサポートされています。


<p class="tmp list"><span>リスト2-9</span>tests/Feature/Tweet/DeleteTest.php</p>
```
public function test_delete_successed()
{
    $user = User::factory()->create(); // ユーザーを作成

    $tweet = Tweet::factory()->create(['user_id' => $user->id]); // つぶやきを作成

    $this->actingAs($user); // 指定したユーザーでログインした状態にする

    $response = $this->delete('/tweet/delete/' . $tweet->id); // 作成したつぶやきIDを指定

    $response->assertRedirect('/tweet');
}
```

「`$this->actingAs($user);` 」を利用すると、引数に指定したユーザーでログインすることができます。ここまでで仕様を満たしたテストが書けましたので、テストを再度実行してみましょう。

<p class="tmp cmd"><span>コマンド</span>テスト再度実行</p>
```
sail test tests/Feature/Tweet/DeleteTest.php
```

![](upload/DeleteTest.phpテストを再度実行.png)

<span class="red">※注意</span>「sail down --rmi all -v」を実行すると、example-appのテーブルがぜんぶ消えた。　再度mygrationなどを行う必要がある。

原因は、php.unitの次の赤線のコードをコメントアウトしていなかったため。
![](upload/env_nameコメントアウト.png)

再度「`sail test tests/Feature/Tweet/DeleteTest.php`」コマンドでテストを実行すると、成功しました。
![](upload/テスト再実行成功.png)
無事テストがパスできたはずです。このようにフィーチャーテストでは複数のクラスが組み合わさった一連の動作のテストを実行できます。ユニットテストと比べて、データベースへの接続も含めたテストも簡単に行えることも理解できたと思います。


## Laravel Duskを使う

Laravel Duskはアプリケーションのブラウザテストを行うためのツールです。本来、ブラウザテストを行うためには、ローカル環境に「JDK」や「Selenium」などのインストールが必要ですが、Laravel Sailではそれらの環境が初めから用意されており、簡単にブラウザテストを始めることができます。

### Laravel Duskのインストール

まずは次のコマンドを実行して、Laravel Duskのパッケージをインストールします。
<p class="tmp cmd"><span>コマンド</span>Laravel Duskインストール</p>
```
sail composer require --dev laravel/dusk
```

![](upload/Laravel_Duskインストール.png)

さらに次のコマンドを実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan dusk:install
```

![](upload/dusk_install.png)

こちらのArtisanコマンドを実行すると、 Laravel Duskのブラウザテスト用のコードを配置するtests/Browserディレクトリが作成されます。また同時にサンプルのテストも追加されます。  
この状態で、ひとまずLaravel Duskを実行してみましょう。テストを行うには、「<span class="red">sail dusk</span>」コマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>Laravel Dus実行</p>
```
sail dusk
```
![](upload/sail_dusk実行.png)

無事テストが完了したはずです。では、ここでどのようなテストが実行されたか、テストファイルを見てみましょう。  
サンプルのテストは「tests/Browser/ExampleTest.php」です。

<p class="tmp list"><span>リスト3-1</span>tests/Browser/ExampleTest.php</p>
```
<?php

namespace Tests\Browser;

use Illuminate\Foundation\Testing\DatabaseMigrations;
use Laravel\Dusk\Browser;
use Tests\DuskTestCase;

class ExampleTest extends DuskTestCase
{
    /**
     * A basic browser test example.
     */
    public function testBasicExample()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/')
                    ->assertSee('Laravel');
        });
    }
}
```
このテストでは、「$browser->visit('/')」でトップページにアクセスし、ページ内に「Laravel」の文字が存在するかどうかをチェックしています。実際に <http://localhost> にアクセスして確認してみると、トップページにはいくつか「Laravel」という文字が存在することもわかります。

![](upload/Laravelの文字が存在するかテストチェック.png)

テストの動作確認をするために、テストを少し書き換えてみましょう。

<p class="tmp list"><span>リスト3-2</span>tests/Browser/ExampleTest.php</p>
```
public function testBasicExample()
{
    $this->browse(function (Browser $browser) {
    $browser->visit('/')
            ->assertSee('Laravel')
            ->assertSee('Hello!');//追加
    });
}
```

「`->assertSee('Hello!')`」 を追加しました。この状態で再度 sail duskコマンドを実行してみるとエラーになります。

![](upload/hello_sail_dusk実行.png)

エラーになる原因は、ページ内に 「Hello!」 の文字がないためです。  
「resources/views/welcome.blade.php」 に「Hello!」の文字を追加してみましょう。

<p class="tmp list"><span>リスト3-3</span>resources/views/welcome.blade.php</p>
```
	･･･省略･･･
        </div>
        Hello!
    </body>
</html>
```

ここでは`</body>`タグの直上に「Hello!」を追記しましたが、`<body>~</body>`のどこに追記しても問題ありません。再度「sail dusk」を実行してみます。
![](upload/再度sail_dusk実行.png)

今度はテストが成功しました。「OK (1 test, 2 assertions)」と、「assert See('Hello!')」を追加したぶん「assertions」が1つ増えていることも確認できます。  
このようにLaravel Duskを使えば、とても簡単にブラウザテストを行えます。 サンプルテストではページ内に対象の文字列が存在するかを確認するだけの assertSeeというアサーションを利用しましたが、 それ以外にもさまざま なアサーションがあり目的に応じたテストを行うことができます。


## ログインテストを作成する

ではさらに実践的にログインのブラウザテストを書いてみましょう。  
ここでは正しいEmailとパスワードが入力された状態で「LOG IN」ボタンをクリックした場合に、ログインが成功することを確認するテストを書いていきます。


### 処理の流れを確認

具体的なテストを書いていく前に、ログインが成功した場合、どのような処理になるのかを確認します。改めて<http://localhost/login>にアクセスしてみると、ログインにはEmailとPasswordが必要であることがわかります。実際にログインを試してみて、次のような動作になることを確認しましょう。


1. <http://localhost/login> にアクセス
2. Emailの入力
3. Password の入力
4. 「LOG IN」 ボタンをクリック
5. ログイン成功時は<http://localhost/tweet>にリダイレクトされる


このリストを1つ1つテストに書いていけばよいでしょう。

### テストコードの作成

まずはテストを作成します。 次のコマンドを実行しましょう。
<p class="tmp cmd"><span>コマンド</span>LoginTestファイル作成</p>
```
sail artisan dusk:make LoginTest
```
![](upload/LoginTest実行.png)

「tests/Browser/LoginTest.php」が作成されます。
![](upload/LoginTest.php作成.png){.photo-border}


<p class="tmp list"><span>リスト4-1</span>tests/Browser/LoginTest.php（デフォルト）</p>
```
<?php

namespace Tests\Browser;

use Illuminate\Foundation\Testing\DatabaseMigrations;
use Laravel\Dusk\Browser;
use Tests\DuskTestCase;

class LoginTest extends DuskTestCase
{
    /**
     * A Dusk test example.
     */
    public function testExample(): void
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/')
                    ->assertSee('Laravel');
        });
    }
}
```

testExampleのメソッドにはサンプルのテストが書かれていますので、ここを変更していきましょう。  
まずはテストの名「testSuccessfulLogin」に変更し、<http://localhost/login>にアクセスする処理を書きます。すでに「$browser->visit('/')」という記述があります。これが指定したパスに遷移するための処理ですから、ここの対象を/loginに変えます。

<p class="tmp list"><span>リスト4-2</span>tests/Browser/LoginTest.php</p>
```
class LoginTest extends DuskTestCase
{
    …省略…
    public function testSuccessfulLogin()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/login') // パスを変更する
                ->assertSee('Laravel');
        });
    }
}
```

### フォームへの入力内容を設定

次にEmailの入力です。ページ上のフォームに入力するためには 「$brow ser->type('email', 'test@example.com');」の処理を行います。typeの第1引数は「`<input id="email" type="email" name="email" requi red="required" autofocus="autofocus">`」のようなタグのtype属性の部分が指定できます。

<p class="tmp list"><span>リスト4-3</span>tests/Browser/LoginTest.php</p>
```
    public function testSuccessfulLogin()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/login')
                ->type('email', 'test@example.com') // メールアドレスを入力する
                ->assertSee('Laravel');
        });
    }
```

パスワードも同様に対応しましょう。 パスワードのインプットタグには「type="password"」が指定されています。

<p class="tmp list"><span>リスト4-4</span>tests/Browser/LoginTest.php</p>
```
    public function testSuccessfulLogin()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/login')
                ->type('email', 'test@example.com')
                ->type('password', 'password') // パスワードを入力する
                ->assertSee('Laravel');
        });
    }
```

### テスト用のユーザーを作成

では、テストに使用するユーザーはどうすればよいでしょう？  ユーザーの登録がないとログインは失敗しますので、どうにかしてユーザーの登録をする必要があります。今回はテストの中で、Userファクトリーを使ってユーザーを作成しましょう。

<p class="tmp list"><span>リスト4-5</span>tests/Browser/LoginTest.php</p>
```
<?php

namespace Tests\Browser;

use Illuminate\Foundation\Testing\DatabaseMigrations;
use Laravel\Dusk\Browser;
use Tests\DuskTestCase;
use App\Models\User;//追加

class LoginTest extends DuskTestCase
{
    /**
     * A Dusk test example.
     */
    public function testSuccessfulLogin()
    {
        $this->browse(function (Browser $browser) {
            $user = User::factory()->create(); // テスト用のユーザーを作成する
            $browser->visit('/login')
                ->type('email', $user->email) // テスト用のユーザーのメールアドレスを指定する
                ->type('password', 'password')
                ->assertSee('Laravel');
        });
    }
}
```

ファイルの冒頭に「`use App\Models\User;`」の記述も必要ですので追加します。  
これでユーザーを作成できます。Userファクトリーはデフォルトでパスワードが「password」の文字列になるように設定されているので、パスワードの入力欄は「password」のままで今回は問題ありません。


### フォーム送信とログイン後の挙動の設定
EmailとPasswordの入力ができたので「LOG IN」ボタンをクリックします。ボタンのクリックは「`$browser->press('LOG IN');`」で実行できます。今回はボタンの表示テキストになっている「LOG IN」を引数に渡しますが、ここでも対象のタグのidやclassなどのセレクタを指定することもできます。

<p class="tmp list"><span>リスト4-6</span>tests/Browser/LoginTest.php</p>
```
    public function testSuccessfulLogin()
    {
        $this->browse(function (Browser $browser) {
            $user = User::factory()->create();
            $browser->visit('/login')
            ->type('email', $user->email)
                ->type('password', 'password')
                ->press('LOG IN') // 「LOG IN」ボタンをクリックする
                ->assertSee('Laravel');
        });
    }
```

ログインが成功すると<http://localhost/tweet>に遷移するはずですので、そこも検証します。 次のページが正しく開かれたかを確認するためには 「assertPathls('/tweet')」 を利用します。

<p class="tmp list"><span>リスト4-7</span>tests/Browser/LoginTest.php</p>
```
    public function testSuccessfulLogin()
    {
        $this->browse(function (Browser $browser) {
            $user = User::factory()->create();
            $browser->visit('/login')
            ->type('email', $user->email)
                ->type('password', 'password')
                ->press('LOG IN')
                ->assertPathIs('/tweet') // /tweetに遷移したことを確認する
                ->assertSee('Laravel');
        });
    }
```

ログインが成功するとつぶやきトップ画面に遷移しますが、「つぶやきアプリ」のタイトルが表示されますので、そちらを検証しましょう。

<p class="tmp list"><span>リスト4-8</span>tests/Browser/LoginTest.php</p>
```
    public function testSuccessfulLogin()
    {
        $this->browse(function (Browser $browser) {
            $user = User::factory()->create();
            $browser->visit('/login')
            ->type('email', $user->email)
                ->type('password', 'password')
                ->press('LOG IN')
                ->assertPathIs('/tweet')
                ->assertSee('つぶやきアプリ'); // ページ内に「つぶやきアプリ」が表示されていることの確認
        });
    }
```

これでコードが完成しました。それではLaravel Duskでテストを実行してみましょう。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail dusk
```
エラーになる･･･。

![](upload/Loginテストエラーになる.png)

原因）->press('LOG IN')　と ->assertPathIs('/tweet')　が逆だった。

成功しました。
![](upload/Loginテスト成功しました.png)

無事に成功しました。 testsが1つ増え、 assertionsが2つ増えていますので、今回追加したものが反映されていることがわかります。
このように、Laravel Duskを使えばかなりシンプルにブラウザテストを実行することが可能です。

今回の例ではログインページのようなシンプルなページを対象にしましたが、より複雑な操作が必要なページであっても対応可能です。どのようなブラウザ操作ができるのか、どのようなチェックができるのかなどの詳細は公式のドキュメントに例示があります。  
それらを参照しながら、自分の環境にあわせたブラウザテストを構築しましょう。




