$(function () {
    //----------------------------------
    // basePath
    //----------------------------------

    //URLから$bath_pathと同じ値を取得
    var urlPathname = location.pathname.replace(/\/$/, '');
    var pathAry = urlPathname.split('/');
    var pathPub = pathAry.indexOf('public');

    var basePath = '';

    for (var i = 1; i < pathPub; i++) {
        basePath = basePath + '/' + pathAry[i];
    }
    
    var folderName = pathAry[pathAry.length - 1];

    var STORAGE_KEY = 'shortcutFavorites';
    var currentType = 'windows';

    //----------------------------------
    // localStorage
    //----------------------------------

    function getFavorites() {
        var data = localStorage.getItem(STORAGE_KEY);

        if (!data) {
            return [];
        }

        return JSON.parse(data);
    }

    function saveFavorites(favorites) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(favorites));
    }
    
    var shortcutData = {};

    function loadShortcuts(type, folderName) {
        $.ajax({
            url: basePath + '/public/shortcut-api',
            type: 'GET',
            data: { type: type, folderName: folderName },
            dataType: 'json',
        }).done(function (data) {
            // renderShortcutList(data);
            // console.log(data);
            
            shortcutData = data;
            filterShortcut();
        });
    }
    

    $('#shortcutSearch').on('input',filterShortcut);

    $('.shortcut-filter input').on('change',filterShortcut);
    

    function filterShortcut() {

        var keyword = $('#shortcutSearch').val().toLowerCase();
        var keys = [];
        
        var hitCount = 0;

        $('.shortcut-filter input:checked').each(function () {
            keys.push($(this).val().toLowerCase());
        });
        
        // リセットボタンの表示切替
        if (keyword || keys.length > 0) {
            $('#shortcutSearchReset').show();
        } else {
            $('#shortcutSearchReset').hide();
            $('#shortcutNoResult').hide();
        }

        // 現在表示中の一覧だけ取得
        var $panel = $('.shortcut-panel:visible');

        $panel.find('.shortcut-category').each(function () {

            var categoryVisible = false;

            $(this).find('.shortcut-item').each(function () {

                var key = $(this).find('.shortcut-key').text().toLowerCase();
                var desc = $(this).find('.shortcut-desc').text().toLowerCase();

                var show = true;

                // キーワード検索
                if (keyword) {
                    if ((key + ' ' + desc).indexOf(keyword) === -1) {
                        show = false;
                    }
                }

                // Ctrl Shift Alt Win のチェック
                if (show && keys.length) {

                    for (var i = 0; i < keys.length; i++) {

                        if (key.indexOf(keys[i]) === -1) {
                            show = false;
                            break;
                        }
                    }
                }

                $(this).toggle(show);
                                
                if (show) {
                    categoryVisible = true;
                    hitCount++;
                }
            });

            // ヒットが無いカテゴリは見出しごと隠す
            $(this).toggle(categoryVisible);
        });
        
          
        if (hitCount === 0) {
            $('#shortcutNoResult').show();
        } else {
            $('#shortcutNoResult').hide();
        }

    }
    
    //検索リセット
    $('#shortcutSearchReset').on('click', function () {
        // 検索文字をクリア
        $('#shortcutSearch').val('');
        // チェックを外す
        $('.shortcut-filter input').prop('checked', false);
        // 再検索（全件表示になる）
        filterShortcut();
    });
    
    
    

    //----------------------------------
    // ショートカット一覧
    //----------------------------------

    // function renderShortcutList(shortcuts) {
    //     var favorites = getFavorites().map(String);
    //     var html = '';

    //     $.each(shortcuts, function (category, list) {
    //         html +=
    //             '<div class="shortcut-category">' +
    //             '<h3 class="shortcut-heading">' +
    //             category +
    //             '</h3>' +
    //             '<div class="shortcut-category-box">';

    //         $.each(list, function (index, shortcut) {
    //             var isFavorite =
    //                 $.inArray(String(shortcut.id), favorites) !== -1;

    //             html +=
    //                 '<div class="shortcut-item">' +
    //                 '<div class="shortcut-left">' +
    //                 '<div class="shortcut-key">' +
    //                 shortcut.key +
    //                 '</div>' +
    //                 '<div class="shortcut-desc">' +
    //                 shortcut.desc +
    //                 '</div>' +
    //                 '</div>' +
    //                 '<div class="shortcut-right">' +
    //                 '<button ' +
    //                 'class="detail-btn btn" ' +
    //                 'data-id="' +
    //                 shortcut.id +
    //                 '" ' +
    //                 'data-title="' +
    //                 shortcut.key +
    //                 '" ' +
    //                 'data-desc="' +
    //                 shortcut.desc +
    //                 '" ' +
    //                 'data-detail="' +
    //                 (shortcut.detail || '') +
    //                 '">' +
    //                 '詳細' +
    //                 '</button>' +
    //                 '<div class="favorite-btn ' +
    //                 (isFavorite ? 'active' : '') +
    //                 '" data-id="' +
    //                 shortcut.id +
    //                 '" title="お気に入りにから外す"' +
    //                 '">' +
    //                 '</div>' +
    //                 '</div>' +
    //                 '</div>';
    //         });

    //         html += '</div></div>';
    //     });

    //     $('#shortcutList').html(html);
    // }

    //----------------------------------
    // お気に入り描画
    //----------------------------------

    function renderFavoriteList() {
        var favorites = getFavorites().map(String);

        var all = window.shortcutLists;

        var htmlWindows = '';
        var htmlVscode = '';
        var htmlBrowser = '';

        // 後に登録したものを先頭表示
        $.each(favorites.slice().reverse(), function (i, favoriteId) {
            $.each(['windows', 'vscode', 'browser'], function (index, type) {
                // all[type],
                $.each(all[type].items, function (category, list) {
                    $.each(list, function (idx, shortcut) {
                        if (String(shortcut.id) !== favoriteId) {
                            return true;
                        }

                        var html =
                            // '<div class="shortcut-item">' +
                            '<div class="shortcut-item" data-id="' +
                            shortcut.id +
                            '">' +
                            '<div class="shortcut-left">' +
                            '<div class="shortcut-key">' +
                            shortcut.key +
                            '</div>' +
                            '<div class="shortcut-desc">' +
                            shortcut.desc +
                            '</div>' +
                            '</div>' +
                            '<div class="shortcut-right">' +
                            '<button ' +
                            'class="detail-btn btn" ' +
                            'data-id="' +
                            shortcut.id +
                            '" ' +
                            'data-title="' +
                            shortcut.key +
                            '" ' +
                            'data-desc="' +
                            shortcut.desc +
                            '" ' +
                            'data-advice="' +
                            escapeAttr(shortcut.advice) +
                            '" ' +                            
                            '">' +
                            '詳細' +
                            '</button>' +
                            '<div class="favorite-btn active" data-id="' +
                            shortcut.id +
                            '" title="お気に入りに登録"' +
                            '">' +
                            '</div>' +
                            '<div class="favorite-tooltip">登録しました</div>' + 
                            '</div>' +
                            '</div>';

                        if (type === 'windows') {
                            htmlWindows += html;
                        }

                        if (type === 'vscode') {
                            htmlVscode += html;
                        }

                        if (type === 'browser') {
                            htmlBrowser += html;
                        }
                    });
                });
            });
        });

        $('#favoriteListWindows').html(htmlWindows);
        $('#favoriteListVscode').html(htmlVscode);
        $('#favoriteListBrowser').html(htmlBrowser);

        // カテゴリー毎に表示・非表示
        $('#favoriteListWindows')
            .closest('.favorite-section')
            .toggle(htmlWindows !== '');

        $('#favoriteListVscode')
            .closest('.favorite-section')
            .toggle(htmlVscode !== '');

        $('#favoriteListBrowser')
            .closest('.favorite-section')
            .toggle(htmlBrowser !== '');

        // 全カテゴリー空ならメッセージ表示
        var hasFavorite =
            htmlWindows !== '' || htmlVscode !== '' || htmlBrowser !== '';

        $('#favoriteEmptyAll').toggle(!hasFavorite);

        updateFavoriteResetButton(); //リセットボタン表示判定
    }
    
    

    //----------------------------------
    // お気に入り開閉
    //----------------------------------

    $('#favoriteToggle').on('click', function () {
        toggleFavoriteDrawer();
    });

    
    
    //----------------------------------
    // お気に入りクリック
    //----------------------------------

    $(document).on('click', '.favorite-btn', function () {
        
        var id = String($(this).data('id'));
        var favorites = getFavorites().map(String);
        var index = $.inArray(id, favorites);
        var addedId = null;
        

        if (index !== -1) {
            favorites.splice(index, 1);
        } else {
            // 初回保存時だけ確認
            if (!confirmFavoriteStorage()) {
                return;
            }

            favorites.push(id);
            addedId = id;

            // ドロワーが閉じていたら開く
            if (!$('#favoriteContent').is(':visible')) {
                openFavoriteDrawer();
            }
        }

        saveFavorites(favorites);
        loadShortcuts(currentType, folderName);
        renderFavoriteList();

        if (addedId) {
            var $tooltip = $('#favoriteContent').find(
                '.shortcut-item[data-id="' + addedId + '"] .favorite-tooltip',
            );

            $tooltip.stop(true, true).fadeIn(200);

            setTimeout(function () {
                $tooltip.fadeOut(300);
            }, 2000);
        }

        applyFavoriteState();
    });

    
    
    
    //----------------------------------
    // ドロワー
    //----------------------------------

    //詳細ボタンクリック
    $(document).on('click', '.detail-btn', function () {

        var id = $(this).data('id');

        $('#drawerTitle').text($(this).data('title'));
        $('#drawerDesc').text($(this).data('desc'));

        // $('#drawerDetail').html('読み込み中...');

        $('#shortcutDrawer').addClass('open');
        $('#drawerOverlay').addClass('open');
        $('body').css('overflow', 'hidden');

        $('#drawerDetail').empty();

        $.ajax({
            url: basePath + '/public/shortcut-detail-api/' + id,
            type: 'GET',
            dataType: 'json',
            data: {
                folderName: folderName,
            },
        })
            .done(function (response) {
                $('#drawerDetail').html(response.html);

                // Ajaxで挿入した code ブロックに対してハイライトを実行
                $('#drawerDetail pre code').each(function () {
                    hljs.highlightElement(this);
                });

                // imgにfigureを設置
                $('#drawerDetail img').each(function () {
                    var $img = $(this);

                    if ($img.parent()[0].tagName == 'P') {
                        $img.unwrap();
                    }

                    $img.wrap('<figure></figure>');

                    if ($img.is('[title]')) {
                        // title属性がある場合
                        var imgTitle = $img.attr('title');
                        $img.after('<figcaption>' + imgTitle + '</figcaption>');
                    }
                });
            })
            .fail(function () {
                $('#drawerDetail').html(
                    '<p>詳細の読み込みに失敗しました。</p>',
                );
            });
    });

    // 閉じる
    function closeDrawer() {
        $('#shortcutDrawer').removeClass('open');
        $('#drawerOverlay').removeClass('open');
        $('body').css('overflow', '');
    }

    $('#drawerClose').on('click', closeDrawer);
    $('#drawerOverlay').on('click', closeDrawer);

    
    
    //----------------------------------
    // 初期表示
    //----------------------------------

    renderFavoriteList();

    applyFavoriteState();



    //----------------------------------
    // 一覧初期表示
    //----------------------------------

    var savedType = sessionStorage.getItem('shortcut_tab_type') || 'windows';

    setActiveTab(savedType);
    showPanel(savedType);

    
    //カテゴリーボタンクリック
    $('.shortcut-tab button').on('click', function () {
        // ページ先頭へスクロール
        $('html, body').animate(
            {
                scrollTop: 130,
            },
            50,
        );

        var type = $(this).data('type');

        sessionStorage.setItem('shortcut_tab_type', type);

        setActiveTab(type);
        showPanel(type);
        applyFavoriteState();       
        // resetSearchCondition();
        $('#shortcutSearch').val('');
        $('.shortcut-filter input').prop('checked', false);
        $('#shortcutSearchReset').hide();
    });
    
    

    

    function applyFavoriteState() {
        const favorites = getFavorites().map(String);

        $('.favorite-btn').each(function () {
            const id = String($(this).data('id'));

            const isFavorite = favorites.indexOf(id) !== -1;

            if (isFavorite) {
                $(this).addClass('active');
                // .text('★');
            } else {
                $(this).removeClass('active');
                // .text('☆');
            }
        });
    }
    
    

    //ストレージ登録確認
    function confirmFavoriteStorage() {
        // すでに保存キーがあるなら確認不要
        if (localStorage.getItem(STORAGE_KEY) !== null) {
            return true;
        }

        return window.confirm(
            'お気に入りショートカットをこのブラウザに保存します。よろしいですか？',
        );
    }

    //お気に入りリセット
    function updateFavoriteResetButton() {
        var favorites = getFavoriteIds(); // 例：["win-copy","vs-save"]

        if (favorites.length > 0) {
            $('#favorite-reset').show();
        } else {
            $('#favorite-reset').hide();
        }
    }

    //お気に入りリセット
    $('#favorite-reset').on('click', function () {
        var result = confirm(
            'ブラウザに登録したお気に入りをすべて削除します。\nよろしいですか？',
        );

        if (!result) {
            return;
        }

        localStorage.removeItem(STORAGE_KEY);

        renderFavoriteList();

        $('.favorite-btn.active').removeClass('active');
    });

    function getFavoriteIds() {
        const favorites = localStorage.getItem(STORAGE_KEY);

        if (!favorites) {
            return [];
        }

        try {
            return JSON.parse(favorites);
        } catch (e) {
            return [];
        }
    }
    
    
    
    //--------------------
    //  ポップアップ生成
    //--------------------
    
    function createAdvicePopup() {

        if ($('#shortcutAdvicePopup').length) {
            return;
        }

        var html = '';

        html += '<div id="shortcutAdvicePopup">';
        html += ' <div class="popup-title"></div>';
        html += ' <div class="popup-body"></div>';
        html += '</div>';

        $('body').append(html);
    }

    createAdvicePopup();
    

    $(document).on('mouseenter', '.detail-btn', function () {

        var advice = $(this).data('advice');

        if (!advice) {
            return;
        }

        var offset = $(this).offset();
        var left = offset.left - 550;

        $('#shortcutAdvicePopup .popup-title')
            .text('💡 活用シーン');

        $('#shortcutAdvicePopup .popup-body')
            .text(advice);

        
        if ($(window).width() < offset.left+320) {
            left = offset.left - 620;
        }
        
        $('#shortcutAdvicePopup')
            .css({
                top: offset.top -120,
                left: left
            })
            .stop(true, true)
            .fadeIn(100);

    });
        
    
    $(document).on('mouseleave', '.detail-btn', function () {

        $('#shortcutAdvicePopup')
            .stop(true, true)
            .fadeOut(100);

    });
    
    
    //エスケープ処理
    function escapeAttr(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

});

function showPanel(type) {
    $('.shortcut-panel').removeClass('active');

    $('#shortcut-' + type).addClass('active');
}

function setActiveTab(type) {
    $('.shortcut-tab button')
        .removeClass('btn-primary active')
        .addClass('btn-outline-primary');

    $('.shortcut-tab button[data-type="' + type + '"]')
        .removeClass('btn-outline-primary')
        .addClass('btn-primary active');
}

//開閉用
function openFavoriteDrawer() {
    $('#favoriteContent').stop(true, true).slideDown(200);
    $('#favoriteToggleIcon').text('▲');
}

function closeFavoriteDrawer() {
    $('#favoriteContent').stop(true, true).slideUp(200);
    $('#favoriteToggleIcon').text('▼');
}

function toggleFavoriteDrawer() {
    if ($('#favoriteContent').is(':visible')) {
        closeFavoriteDrawer();
    } else {
        openFavoriteDrawer();
    }
}





