<template>
  <div>
    <Navbar />
    <slot />
  </div>
</template>