*[page-title]:postMessage

参考サイト
: [mdn web docs Window.postMessage()](https://developer.mozilla.org/ja/docs/Web/API/Window/postMessage)
: [JavaScriptでiframeとやりとりするためにpostMessageを使う](https://www.konosumi.net/entry/2022/10/30/233552)

window.postMessage() は、 Window オブジェクト間で安全にオリジン間通信を可能にするためのメソッドです。例えば、ポップアップとそれを表示したページの間や、iframe とそれが埋め込まれたページの間での通信に使うことができます。

通常、異なった複数のページでのスクリプトはそれらが実行されたページが同じプロトコル、ポート番号、ホストである場合に限りお互いにアクセスすることが可能です（「同一オリジンポリシー」とも呼ばれます）。正しく使用した window.postMessage はこの制限を安全に回避するための制御された仕組みを提供します。

大まかには、ウィンドウが他のウィンドウへの参照を取得できる場合 ( targetWindow = window.opener など)、targetWindow.postMessage() を使って MessageEvent をそのウィンドウ上で配信することができます。受け取ったウィンドウでは必要に応じて自由にイベントを処理することができます。window.postMessage() に渡された引数 ("message") はイベントオブジェクトを通して対象のウィンドウに公開されます。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	iframeで読み込んだファイルからデータを受け取り、スクリプトに使っています。
</div>
読み込み元ページ  
<http://localhost:7001/postMessage/sub.html>  
```
<div id="box">サブページです</div>
<script>
  let box_height = document.getElementById('box').clientHeight;
  window.parent.postMessage(box_height, "http://localhost:7000/");
</script>
```
読み込み先ページ<http://localhost:7001/test/iframe/postMessage/>
```
<div id="frame-box">
	<iframe id="myframe" src="http://localhost:7001/postMessage/sub.html" scrolling="no" frameborder="0"></iframe>
</div>
<script>
	// iframe呼び出し元は、自分自身のイベントをリッスンしている
	window.addEventListener("message", (e) => {
		console.log('event.origin = '+event.origin)
		if (event.origin == "http://localhost:7001"){
			console.log('e.data='+e.data)
			document.getElementById('myframe').style.height = e.data + 'px'
		}
		return;
	}, false);
</script>
```


<p class="tmp"><span>書式</span></p>
```
postMessage(message, targetOrigin)
postMessage(message, targetOrigin, transfer)
```

## 引数
message
: 他のウィンドウに送られるデータ。データは構造化複製アルゴリズムに従ってシリアル化されます。つまり、手動でシリアル化することなく様々なデータオブジェクトを宛先に安全に渡すことができます。

targetOrigin
: イベントを配信するこのウィンドウのオリジンを指定します。リテラル文字列 "*" (優先順位なし) か URI のどちらかで指定します。イベントが配信される予定時刻に、このウィンドウの文書のスキーム、ホスト名、ポートが targetOrigin で指定されたものと一致しない場合、イベントは配信されません。この仕組みにより、メッセージが送信される場所を制御できます。例えば、 postMessage() をパスワードを送信するために使用する場合、悪意のある第三者によるパスワードの傍受を防ぐために、この引数がパスワードを含むメッセージの受信予定者と同じオリジンの URI であることが絶対に重要でしょう。 他のウィンドウの文書がどこにあるものか知っている場合は、 * ではなく、常に特定の targetOrigin を指定してください。特定のターゲットを指定しないと、悪意のあるサイトに送信したデータが開示されてしまいます。

transfer 省略可
: メッセージと一緒に移譲される移譲可能オブジェクトのシーケンスです。これらのオブジェクトの所有権は送信先に移譲され、送信元では使えなくなります。

返値
: なし (undefined)。

## 配信されるイベント
window は以下の JavaScript を実行することで、配信されたメッセージを受け取ることができます。
```
window.addEventListener("message", (event) => {
  if (event.origin !== "http://example.org:8080")
    return;

  // …
}, false);
``` 

配信されたメッセージには、以下のプロパティがあります。

data
: 他のウィンドウから渡されたメッセージを保持しているオブジェクト。

origin
: postMessage が呼び出されたときにメッセージを送るウィンドウのオリジン。この文字列は、プロトコルと "://"、ホスト名（存在する場合）、そして、":" の後に続くポート番号（既定のポートと指定したポートが異なる場合）が連結されたものです。典型的なオリジンの例は` https://example.org` (この場合のポートは 443)、`http://example.net` (この場合のポートは 80)、そして` http://example.com:8080`。このオリジン生成元はそのウィンドウの現在もしくは将来のオリジンであることを保証していないことに注意してください。 postMessage が呼び出された時とは異なる場所に移動しているかもしれません。

source
: メッセージを送った window オブジェクトへの参照。これを使うことでオリジンの異なる二つのウィンドウ間で双方向の通信を確立することができます。

セキュリティの考慮事項
: 他のサイトからメッセージを受け取りたくない場合、message イベントに対して一切イベントリスナーを追加しないでください。これはセキュリティ的な問題を避けるための完全にフールプルーフな方法です。

他のサイトからメッセージを受け取りたい場合、origin あるいは source プロパティを用いて常に送信者の識別情報を確かめてください。任意のウィンドウ（例えば、`http://evil.example.com` も含む）は任意の他のウィンドウにメッセージを送ることができ、見知らぬ送信者が悪意あるメッセージを送らない保証はありません。識別情報を確かめたとしても、常に受け取ったメッセージの構文を確かめるべきです。そうしないと、信頼されたメッセージだけを送るとして信頼されたサイトにセキュリティホールが存在した場合に、クロスサイトスクリプティングのセキュリティホールをサイトに開けることになり得ます。

他のウィンドウに postMessage でデータを送信する場合、 * ではなく、常に具体的なターゲットオリジンを指定してください。悪意を持ったサイトはあなたの知らないうちに送信先ウィンドウの場所を変更することができ、そのまま postMessage で送信されたデータを傍受することができてしまいます。