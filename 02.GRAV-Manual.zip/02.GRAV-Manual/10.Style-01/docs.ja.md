---
title: スタイル設定について
media_order: 'xss_dangerous_tag.png,XSS_security1.png'
taxonomy:
    category:
        - docs
visible: true
---

## テーマごとの共通のスタイル

テーマをカスタマイズする場合、下記の**{c:red}custom.css{/c}**にスタイルを追加します。  
デフォルトではないので、指定の場所に追加する必要があります。  
（テンプレートでは、設置しています。）

★テーマが「**{c:blue}learn2{/c}**」の場合

user > themes > **{c:blue}learn2{/c}** > css > **{c:red}custom.css{/c}** 


※ ただしこのファイルは管理者しかさわれません。

個別にページのフォルダごとにスタイルを設定したい場合は、頭に **body[data-url^="/フォルダ名"]**  を入れてやればいいです。

<p class="write"><span>記入例</span></p>
<pre>
<span class="comment">//第一階層のフォルダが「html5_css3」の場合</span>
body[data-url^="<strong>/html5_css3</strong>"] h2 {
	margin-top: 5rem;
	margin-bottom: 2.5rem;
}

<span class="comment">//第一階層のフォルダが「html5_css3」で第二階層のフォルダが「html5-foundation」の場合</span>
body[data-url^="<strong>/html5_css3/html5-foundation</strong>"] h2 {
	color: blue;
	margin-bottom: 1.5rem;
}
</pre>

## ページのスタイル

編集しているページのみにスタイルを当てたい場合は、ページの頭に**&lt;style&gt; ～ &lt;/style&gt;** を設置し、その中にスタイルを記述することもできます。

<p class="write"><span>記入例</span></p>
<pre>
&lt;style&gt;
    p.test1 span {
        background: #008000;
    }

    p.test2 span {
        background: #ffa600;
    }
&lt;/style&gt;
</pre>

※ただしページに&lt;style&gt;～&lt;/style&gt;を入れる方法は、GRAVのセキュリティーで下記のような警告文がページの上部にでます。これは悪意のあるコードをタグの中に仕込まれるのを防止するものです。  

![](xss_dangerous_tag.png)

特に気にしないという方は、設定 - Security　の画面を開き、「Filter Dangerous HTML tags」を「いいえ」に変更し、保存ボタンを押してください。  

![](XSS_security1.png?cropResize=600,600)

再度ページの編集画面を開くと、警告文は消えているはずです。





