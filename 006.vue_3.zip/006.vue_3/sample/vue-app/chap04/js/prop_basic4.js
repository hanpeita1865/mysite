Vue.createApp({})
    .component('my-hello', {
        //props: [ 'yourName' ],
        /*props: {
            yourName: {
                type: String,
                required: true
            }
        },*/

        props: {
            yourName: {
                type: String,
                required: true, 
                // 文字数が5文字以内であれば成功 
                validator(value) {
                    console.log(value.length);
                    return value.length <= 5;
                }
            }
        },
        template: `<div>こんにちは、{{ yourName }}さん！</div>`,
    })
    .mount('#app');