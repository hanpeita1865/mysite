*[page-title]:05. コントローラ

Webページの具体的な処理は、コントローラを使って行うのが基本です。コントローラは、MVCアーキテクチャの基本となるものです。

## MVCとコントローラ
<span class="red">ルーティング</span>は、アクセスしたアドレスを元に処理を割り振るための機能です。先ほど、<span class="red">Route::get</span> を使って簡単なWebページを表示させてみましたが、もちろんルーティングはWebページを作って表示するためのものではありません。具体的に実行すべき処理は別に用意されていて、それを特定アドレスに割り振って呼び出すためのものです。  
では、呼び出される「具体的に実行すべき処理」というのは、どういうものか。それを実装するために用意されているのが「<span class="marker-yellow50"><span class="red bold">コントローラ</span></span>」です。

![](upload/controller_web.png "図　コントローラーの役割"){.photo-border}


## MVC アーキテクチャ

コントローラを知るには、まず「<span class="red bold">MVC</span>」と呼ばれるアーキテクチャについて理解しなければいけません。 MVCは、「Model-View-Controller」の略です。これはアプリケーションの処理を、MVCの3つの要素の組み合わせとして構築していく考え方です。MVCは、それぞれ以下のような役割を果たします。

<span class="green">モデル(Model)</span>
: ～データ処理全般を担当します。具体的には、データベースアクセスに関する処理全般を扱うものと考えてよいでしょう。

<span class="green">ビュー(View)</span>
: ～画面表示を担当します。表示に使うテンプレートなどがこれに相当します。 
 
<span class="green">コントローラ(Controller)</span>
: ～全体の制御を担当します。必要に応じてModelを使ってデータを取得したり、Viewを利用して画面表示を作成したりします。

モデル(Model)やビュー(View)は、特定の機能に特化したものです。これに対しコントローラ(Controller)は処理全体の制御を担当するものであり、プログラムの本体部分といってもよいものなのです。モデルやビューは、不要であれば用意しないでおくことも可能ですが、<span class="red">コントローラは、ないと処理そのものが実行できません</span>。  
Laravelの開発は、まずコントローラを作るところから始まる、といってもよいでしょう。


## コントローラの作成

では、コントローラを作成してみましょう。コントローラは、PHPのスクリプトファイルとして作成します。テキストエディタ等でファイルを作成してもいいですが、ここでは*artisan(アーティザン)コマンド*を使って作成しましょう。  
コマンドプロンプトまたはターミナルで、プロジェクトフォルダの中にcdコマンドで移動して下さい。そして以下のようにコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>HelloController新規作成</p>
```
php artisan make:controller HelloController
```

![](upload/hellocontroller実行.png)
ファイルが作成されました。
![](upload/hellocontrollerファイル作成.png){.photo-border}

これで、「<span class="red">HelloController</span>」という名前のコントローラが作成されます。  
ここでは、artisanコマンドというものを使いました。これは、以下のような形で実行します。

<p class="tmp cmd"><span>コマンド書式1</span></p>
```
php artisan コマンド
```
今回使ったのは、「make:controller」というコマンドです。これは以下のように実行を します。
<p class="tmp cmd"><span>コマンド書式2</span></p>
```
php artisan make:controller コントローラ名
```
これで、指定した名前でコントローラが作成されます。今回は、HelloControllerとい うコントローラを作成していました。  
コントローラは通常、「<span class="red">○○Controller</span>」というように、名前の後に「<span class="marker-yellow30">Controller</span>」を付けたものが使われます。

では、作成されたコントローラのファイルを見てみましょう。コントローラは、「**app**」フォルダの「**Http**」フォルダ内にある「<span class="red bold">Controllers</span>」というフォルダの中に作成されます。



作成されたHelloControllerのデフォルトのコードは、次のようになっています。

<p class="list tmp"><span>リスト2</span>app/Http/Controllers/HelloController.php（デフォルト）</p>
```
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HelloController extends Controller
{
    //
}
```
これがコントローラの基本ソースコードになります。ポイントを整理していきましょう。


### Controllers 名前空間
コントローラは、クラスとして作成されます。このクラスは、「<span class="red bold">App\Http\Controllers</span> 」という<span class="red">名前空間</span>に配置されます。名前空間というのは、<span class="red">クラスを階層的に整理するための仕組み</span>です。フォルダを使って階層的にファイルを整理するのと同じようなものをイメージすればよいでしょう。

ここでは、「App\Http\Controllers」という名前空間を使っていますが、これはよく見るとどこかで見覚えのある名前が並んでいるのがわかります。そう、コントローラのファイルが置かれている場所は、「app」フォルダ内の「Http」フォルダの中にある「Controllers」 フォルダの中でした。このフォルダ構成に沿って名前空間が指定されていることがわかるでしょう。 この名前空間を指定しているのが最初の文です。

```
namespace App\Http\Controllers;
```
これは、コントローラクラスを作成する際の基本設定として覚えておきましょう。

### use によるクラスのインポート
次に記述されているのは、use文です。これは以下のように記述されています。  
```
use Illuminate\Http\Request;
```
ここでは、Illuminate\Httpパッケージ内に用意されている「<span class="red bold">Request</span>」を使える状態にしています。まだこの段階ではRequestは不要ですが、これから多用することになるク ラスですので、デフォルトでuse文が追加されているのです。

#### クラスの定義
続いて、クラスの定義がされています。ここでは、HelloControllerクラスが以下のように定義されています。
```
class HelloController extends Controller
{
	//
}
```
コントローラクラスは、このようにControllerというクラスを継承して作成をします。 また名前は、既に触れたように「<span class="red">○○Controller</span>」というものにしておきます。これは必須というわけではありませんが、クラスをわかりやすく整理する上で必要な命名ルールと考えて下さい。  
これで、コントローラクラスは用意できました。後は、ここに具体的な処理をメソッドとして追加していくだけです。


## アクションを追加する

では、コントローラに処理を追加しましょう。  
コントローラに用意される処理は、「<span class="red">アクション</span>」と呼ばれます。これはメソッドの形で用意されます。アクションは、「<span class="red">コントローラに用意される処理を行う</span>」ためのもので、 複数を用意することができます。 では、HelloController.phpを以下のように書き換えて下さい。


<p class="list tmp"><span>リスト3</span>HelloController.php</p>
```twig
<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class HelloController extends Controller {

    public function index() {

        return <<<EOF
 <html>
 <head>
 <title>Hello/Index</title>
 </head>
 <body>
    <h1>Index</h1>
    <p>これは、Helloコントローラのindexアクションです。</p>
 </body>
 </html>
 EOF;
    }
 }
```

ここでは、HelloControllerクラスの中に「*index*」というメソッドを追加しています。これが、アクションとして使われる*メソッド*です。  
アクションメソッドは、このindexのように引数を持たないメソッドとして用意されます（ただし、必要に応じて引数を用意する場合もあります。これについては後述しま す）。

アクションメソッドでは、returnでHTMLのソースコードを返しています。このようにreturnされた内容が、アクセスしたWebブラウザへ返され、それが表示されることになります。


### ルート情報の用意
これでコントローラにアクションは用意できましたが、これだけでは表示はされません。アクションを使うようにするためには、アクションにルートを割り当てる設定が必要です。  
「<span class="red">routes</span>」フォルダの<span class="red">web.php</span>を開き、先に追記した内容(ルーティング リスト4)を削除して下さい。 そして、以下の文を改めて追記しましょう。

<p class="tmp list"><span>リスト4</span>web.php</p>
```
Route::get('hello', 'App\Http\Controllers\HelloController@index');
または
Route::get('hello', [\App\Http\Controllers\HelloController::class,'index']);
```
Route::getを使って、ルート情報を設定しています。ここでは、第2引数には関数は使っていません。代わりに、「<span class="red">～HelloController::class,'index</span>」というテキストが用意されています。  

コントローラを利用する場合は、このように第2引数に「呼び出すコントローラとアクション」を指定します。

これにより、第1引数のアドレスにアクセスされると、第2引数に指定されたコントローラのアクションが実行されるようになります。  
ルート情報まで記述できたら、Webブラウザで/helloにアクセスをしてみましょう。 「Index」というタイトルの画面が表示されます。これがindexアクションによって作成されたWebページです。

<http://localhost:8000/hello>

![](upload/hello_controller_index.png){.photo-border}


## ルートパラメータの利用

では、ルートパラメータはどのように利用することになるのでしょうか。これもアクションメソッドを修正して使ってみることにしましょう。  
HelloControllerクラスに以下のコードを追加して下さい。

<p class="tmp list"><span>リスト5</span>HelloController.php</p>
```twig
   public function rootPara($id='noname', $pass='unknown') {

      return <<<EOF
<html>
<head>
<title>Hello/Index</title>
</head>
<body>
   <h1>Index</h1>
   <p>これは、Helloコントローラのindexアクションです。</p>
   <ul>
       <li>ID: {$id}</li>
       <li>PASS: {$pass}</li>
   </ul>
</body>
</html>
EOF;
   }
```

続いて、ルート情報の修正です。web.phpに追記した、「\App\Http\Controllers\HelloController::class,'index' 」への Route::get文を以下のように修正して下さい。  

<p class="tmp list"><span>リスト6</span>web.php</p>
```
Route::get('hello/{id?}/{pass?}', [\App\Http\Controllers\HelloController::class,'rootPara']);
```

これで修正完了です。/hello/taro/yamadaというように、/helloの後に2つのパラメー タを付けてアクセスしてみましょう。それらのパラメータの値が画面に表示されます。

![](upload/taro_yamada.png "図 「ID: taro」「PASS: yamada」とパラメータの値が表示される。"){.photo-border}

### ルートパラメータの設定 
では、Route::get文から見てみましょう。ここでは以下のように第1引数が用意されていました。
```
'hello/{id?}/{pass?}'
```
<span class="marker-yellow30">{id?}</span>と<span class="marker-yellow30">{pass?}</span>2つのパラメータが用意されています。いずれも?を付けて、任意パラメータとして用意してあります。Route::getのパラメータについては、先にRoute::get で設定したのとまったく同じことがわかります。

### アクションメソッドの設定
では、コントローラクラスに用意したアクションメソッドを見てみましょう。ここでは、以下のようにメソッドの定義が変更されています。
```
public function rootPara($id='noname', $pass="unknown') {......)
```
indexメソッドには、*$id*と*$pass*の2つの引数が追加されました。これが、ルートパラ メータに指定された*{id}*と*{pass}*の値を受け取るための引数になります。先にRoute::get の第2引数にクロージャとして処理を用意しましたが、あれがそのままアクションメソッドに置き換わっていることがわかるでしょう。  
今回は任意パラメータですので、それぞれの引数にはデフォルト値を指定してありま す。このあたりも、Route::getでルートパラメータを使ったときの無名関数の書き方と まったく同じです。

![](upload/hnown.png "図「～/hello/」のパラメータなしでアクセスした場合"){.photo-border}


## シングルアクションコントローラ

コントローラには、次のように複数のアクションを用意することができます。

```
class HelloController extends Controller {

    public function multiAction() {
        //処理を記入
     }
     
     public function other() {
       //処理を記入
     }
}
```

複数アクションを用意するのとは反対に、「1つのコントローラに1つのアクションだけしか用意しない」というような設計をすることもあります。  
このような場合には、「<span class="red">シングルアクションコントローラ</span>」としてクラスを用意します。
シングルアクションコントローラは、特別なクラスというわけではありません。一般的なアクションメソッドの代わりに、「<span class="green bold">_invoke</span>」というメソッドを使って処理を実装します。

<p class="tmp"><span>書式3</span>シングルアクションコントローラの基本形</p>
```
class コントローラ extends Controller
{
	public function__invoke() {
		//...アクション処理......
	}
}
```

これ以外にアクションメソッドは用意しません。メソッドは追加できますが、それら はアクションとしての利用はできません。  
シングルアクションコントローラとして作成されたコントローラは、ルート情報の設定も少し変わってきます。
<p class="tmp"><span>書式4</span></p>
```
Route::get( 'アドレス', 'コントローラ名');
```
このように、コントローラ名だけを指定します。アクションの指定はしません。これにより、指定のアドレスにコントローラが割り当てられます。そしてそのアドレスにアクセスをすると、クラスの<span class="green bold">_invoke</span>が呼び出され処理が実行される、というわけです。

### HelloController をシングルアクション化
では、実際にやってみましょう。HelloControllerクラスにシングルアクションコントローラを追加して下さい。

新規の場合、artisanコマンドで作成できます。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:controller HelloSingleController --invokable
```
![](upload/hello_sigle.png)

![](upload/helloSingleファイル作成.png "図　invoke用ファイル作成")

<p class="tmp list"><span>リスト9</span>HelloSingleController.php</p>
```twig
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HelloSingleController extends Controller
{
    public function __invoke(Request $request)
    {
        return <<<EOF
        <html>
        <head>
        <title>Hello</title>
        </head>
        <body>
          <h1>Single Action</h1>
          <p>これは、シングルアクションコントローラのアクションです。</p>
        </body>
        </html>
        EOF;
    }
}
```

コントローラの修正が終わったら、ルート情報です。web.phpを開き、HelloSingleController のルート情報を追記します。

<p class="tmp list"><span>リスト10</span>web.php</p>
```
//Route::get('hello', 'HelloController@__invoke');
Route::get('/helloSiingle', \App\Http\Controllers\HelloSingleController::class);
```

<http://localhost:8000/helloSingle/>にアクセスしてください。  
「Single Action」 とタイトル表示されたWebページが表示されます。  
ここでは、割り当てるコントローラまたはアクションを示す第2引数には、コントローラ名だけしか記述されていません。  
これで、指定したコントローラの_invokeが呼び出されて処理が実行されるようになるのです。

![](upload/helloSingle.png){.photo-border}


## リクエストとレスポンス

コントローラの基本的な使い方はだいぶわかってきたことでしょう。最後に、クライアントとサーバーの間のやり取りを管理する「<span class="red bold">リクエスト(Request)</span>」と「<span class="red bold">レスポンス (Response)</span>」について触れておきましょう。  
ここまで作成してきたアクションメソッドを見ると、引数も特に用意されておらず、 非常にあっさりとした構造でした。が、実際のWebアクセスというのは、内部で非常に 多くの情報をやり取りしています。  
既にPHPを使っている皆さんなら、アクセスに関する情報を取得するために、$_ REQUESTなどのグローバル変数を利用したことがあるでしょう。$_REQUESTは、リクエストに関する情報をまとめたものでした。 

クライアントからサーバーヘアクセスをしたとき、クライアントから送られてきた情報は「リクエスト」として扱われます。そしてサーバーからクライアントへ返送する情報は「レスポンス」として扱います。このリクエストとレスポンスをうまく扱うことが、 Webサイトへのアクセス処理にはとても重要なことでした。

このリクエストとレスポンスの情報は、Laravelでも利用することができます。これは、 Illuminate\Http名前空間に用意されている「<span class="red bold">Request</span>」「<span class="red bold">Response</span>」というクラスとして用意されています。  
これらのオブジェクトには、リクエストまたはレスポンスに関する情報を保管するプ ロパティや、それらを操作するためのメソッドが用意されています。本格的な利用はも う少しLaravelを使いこなせるようになってから考えるとして、とりあえずこれらのオブジェクトがどんなものか、どう使うのかぐらいは覚えておきましょう。

![](upload/request_response.png "図　リクエストとレスポンスについて")


## Request および Response

では、実際にRequestおよびResponseオブジェクトを使ってみましょう。 HelloController.phpを以下の部分を追加して下さい。なお、今回はuse文などもすべて掲載しておきます。

<p class="tmp list"><span>リスト11</span>HelloController.php</p>
```twig
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;//追加1

class HelloController extends Controller
{
・・・・省略・・・・

 //コントローラークラス内に追加2
   public function response(Request $request, Response $response) {

$html = <<<EOF
<html>
<head>
<title>Hello/Index</title>
</head>
<body>
  <h1>Hello</h1>
  <h3>Request</h3>
  <pre>{$request}</pre>
  <h3>Response</h3>
  <pre>{$response}</pre>
</body>
</html>
EOF;
       $response->setContent($html);
       return $response;
   }

}
```

これで完成です。続いて、ルート情報の設定も行っておきましょう。web.phpに追記した文を削除し、新たに以下のリストを追加します。
<p class="list tmp"><span>リスト11-2</span>web.php</p>
```
Route::get('helloResponse', [\App\Http\Controllers\HelloController::class,'response']);
//または
Route::get('helloResponse', '\App\Http\Controllers\HelloController@response');
```
これで、/helloResponseにアクセスすると、クライアントからヘッダー 情報が、またレスポンスからはキャッシュコントロールや日付などの情報が得られてい るのがわかります。

![](upload/hellResponse.png){.photo-border}


### アクションメソッドの引数定義
ここでは、まずRequestとResponseを利用するため、use文を追記してあります。
```
use Illuminate\Http\Request; 
use Illuminate\Http\Response;//追加
```
Requestはデフォルトで用意されていましたので、それにResponseのuseを追加しています。これで両方のクラスが利用できるようになりました。  
これらの利用は、アクションメソッドで行います。indexを見ると、以下のような形 で定義されています。
```
public function index(Request $request, Response $response) { .......
```
引数に、RequestとResponseが用意されているのがわかります。このように、これらを引数に追加するだけでインスタンスが用意され、使えるようになります。


### Request の主なメソッド
では、Request/Responseの利用例として、アクセスしたURLを表示させてみましょう。

<p class="tmp"><span>書式5</span></p>
```
$request->url();
```

<div class="exp">
	<p class="tmp"><span>例</span>アクセスしたURLを表示</p>
</div>
$url = $request->url();  と　$urlを  
public function index(Request $request, Response $response) {   
の中に追加してやると、アクセスしたURLが表示されます。

<p class="list tmp"><span>リスト12-1</span>web.php</p>
```
Route::get('helloUrl', [\App\Http\Controllers\HelloController::class,'showUrl']);
```


<p class="tmp list"><span>リスト12-2</span>HelloController.php</p>
```
public function showUrl(Request $request, Response $response) {

    $url = $request->url();
    $response->setContent($url);
    
    return $response;
}
```

<http://localhost:8000/helloUrl/>にアクセスすると、下記のようにURLが表示されます。
![](upload/helloUrlアクセス.png){.photo-border}

「<span class="red bold">url</span>」は、アクセスしたURLを返します。  
ただし、クエリー文字列（アドレスのあとに付けられる、?abc-xyzというようなテキスト）は省略されます。
<p class="tmp"><span>書式6</span>fullurl()</p>
```
$request->fullurl();
```
「<span class="red bold">fullUrl</span>」は、アクセスしたアドレスを完全な形で返します（クエリー文字列も含まれます）。

<p class="tmp"><span>書式7</span>path()</p>
```
$request->path();
```
「<span class="red bold">path</span>」は、ドメイン下のパス部分だけを返します。


### Response の主なメソッド
続いてResponseです。こちらは、クライアントへ返送する際のステータスコード、表示コンテンツの設定などがあります。

<p class="tmp"><span>書式8</span>ステータスコード</p>
```
$this->status();
```
アクセスに関するステータスコードを返します。これは正常にアクセスが終了していたら200になります。
<p class="tmp"><span>書式9</span>コンテンツを取得、変更</p>
```
$this->content(); 
$this->setContent(値);
```
コンテンツの取得・設定を行うものです。contentはコンテンツを取得し、setContent は引数の値にコンテンツを変更します。  
これらのオブジェクトは、これから先、Laravelを使いこなすにつれて利用価値が高まっていくことでしょう。まずは、ここに挙げたメソッドを使って、オブジェクトの使い方を覚えておきましょう。

