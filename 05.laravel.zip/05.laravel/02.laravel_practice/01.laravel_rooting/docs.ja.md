---
title: '01. ルーティング'
media_order: 'HelloController.jpg,Hello_index.jpg'
taxonomy:
    category:
        - docs
---

Laravelには非常に多くの機能が組み込まれています。まずは、そのコアとなる機能と しての「ルーティング」について掘り下げていくことにします。

今回は、ver5.8を使用していきます。

## 準備

### コントローラーとビューの作成
プロジェクトには、サンプルとしてHelloというコントローラーを用意しておくことにします。「laravel_app」フォルダ（任意の名前）にカレントディレクトリを移動後、以下を実行します。

<p class="tmp cmd"><span>コマンド1</span></p>
```
php artisan make:controller HelloController
```
「Controller created successfully.」と表示されたら、「HelloController.php」が作成されています。
![](HelloController.jpg)

このファイルを開き、サンプルとしてアクションメソッドを追加しておきましょう。


<p class="tmp list"><span>リスト1-1</span>HelloController.php</p>
```
<?php
namespace App\Http\Controllers;


use Illuminate\Http\Request;


class HelloController extends Controller
{
    public function index()
    {
        $data = [
            'msg'=>'this is sample message.',
        ];
        return view('hello.index', $data);
    }
}
```
indexメソッドを追加しておきました。ここでは、hello.indexビューを読み込み、 $dataを値として渡すようにしてあります。これは、あくまで動作確認用のダミーです。

### テンプレートの作成
では、テンプレートを用意しましょう。「resources」フォルダ内の「views」フォルダ内 に、新たに「hello」フォルダを用意します。このフォルダ内に「index.blade.php」という ファイルを作成し、次のように記述しておきます。

<p class="tmp list"><span>リスト1-2</span>index.blade.php</p>
```
<!doctype html>
<html lang="ja">
<head>
    <title>Index</title>
</head>
<body>
    <h1>Hello/Index</h1>
    <p>{{$msg}}</p>
</body>
</html>
```
HelloControllerクラスのindexで渡された$msgを画面に表示するだけの簡単なサンプルです。これも動作確認用のダミー です。

### ルート情報の用意
最後に、HelloControllerのindexアクションのルート情報を追記します。 /routes/web. phpファイルを開き、次の文を追記します。

<p class="tmp list"><span>リスト1-3</span>web.php</p>
```
Route::get('/hello', 'HelloController@index');
```
<p>http://localhost～/hello　にアクセスすると、</p>
![](Hello_index.jpg)
と表示されます。

### ルートの基本
Laravelでは、コントローラーとそのアクションを公開する際には必ず「ルート情報」を用意することになっています。通常、ルート情報の記述は、「ルート定義メソッド」を利用するか、「ビュールート」を使うかするでしょう。

<p class="tmp"><span>書式1</span>ルート定義メソッド</p>
```
Route::get(《url》, コールバック ); 
Route::post(《url》,コールパック); 
Route::put(《url》, コールバック); 
Route::patch(《url》, コールバック); 
Route::delete(《url》,コールバック ); 
Route::options(《url》, コールパック);
```

<p class="tmp"><span>書式2</span>ビュールート</p>
```
Route::view(《url》, ビュー[,オプション] );
```
ルート定義メソッドは、HTTPメソッドごとに対応するメソッドが用意されています。 使い方は基本的に同じで、第1引数にURIとなるテキストを、第2引数には指定のURIに アクセスがあった際に呼び出されるコールバックを指定します。  
ビュールートは、第1引数にURIを指定する点は同じですが、第2引数にはコールバッ クではなく表示するビューの指定を記述します。場合によっては、ビューに渡す値を連 想列としてまとめて第3引数に指定することもあります。


## 名前付きルートについて
名前付きルートは、ルート情報に名前を設定して管理します。通常、ルート情報というのは、例えば次のような形で記述されます。

<p class="tmp"><span>書式3</span></p>
```
Route::get(・・・)->name( 名前);
```
getやpostといったルート定義メソッドは、Routeクラスのインスタンスを返します。 このインスタンスから更にnameを呼び出すことで、名前を設定したインスタンスが返されるようにします。  
こうして名前を設定したルート情報(Routeインスタンス)は、コントローラー側でルートを利用する際、名前を指定するだけで呼び出すことができるようになります。

### lindex/other ルートを利用する
/routes/web.phpに記述されている /hello'のルート情報を削除し、次のルート情報を新たに追記して下さい。

<p class="tmp list"><span>リスト1-4</span>web.php</p>
```
Route::get('/hello', 'HelloController@index')->name('hello');
Route::get('/hello/other', 'HelloController@other');
```

HelloControllerクラスに、次のother メソッドを追加して下さい。

<p class="tmp list"><span>リスト1-5</span>HelloController.php</p>
```
public function other()
{
    return redirect()->route('hello');
}
```
/hello/otherにアクセスをすると、瞬時に/helloにリダイレクトされます。ここ ではredirectメソッドを使ってリダイレクトを行っているのですが、その戻り値か ら更にrouteメソッドを呼び出すことで、引数に指定した名前のルート情報による RedirectResponseインスタンスを返すことができます。 このroute('hello)で指定されるのは、web.phpでnamechello)を使って名前を設定したルート情報です。名前だけでルート情報が取り出され、利用できるようになっているこ とがわかります。  
ここではリダイレクトに使いましたが、ルート情報に名前を付けておくことで、ルー ト情報が必要となるシーンではいつでも名前だけでルート情報を取り出せるようになり
ます。




## whereによる正規表現ルート
このnameのようなRouteクラスのメソッドは、ほかにもあります。パラメータを使用したルート情報を設定する際、パラメータに強力な制約を設定できるのが「where」メ ソッドです。ルートにパラメータを設定する際、そのパラメータがどのような制約を受けるか、正規表現を使って設定することができます。 whereは、次のような形で呼び出します。

<p class="tmp"><span>書式4</span></p>
```
《Route》 ->where(パラメータ名,パターン);
```
※《Route》はRouteクラスのインスタンスを表します。

第1引数には、制約を設定するパラメータ名を指定します。これは、例えばgetメソッ ドの引数などで)を使ってパラメータ設定したものを、そのまま指定すればよいでしょ う。そして第2引数に、そのパラメータに渡すことのできる値を、正規表現のパターンで指定します。

### 数字のみ設定できる id パラメータを作る
では、whereの利用例を挙げておきましょう。helleアクションに「id」というパラメー タを用意し、そこに数字だけが利用できるようにしてみます。まず、/routes/web.php にルート情報の記述を用意します。


<p class="tmp list"><span>リスト1-6</span></p>
```
Route::get('/hello/{id}','HelloController@index')->where('id', '[0-9]+');
```
ここでは、/hello/{id}'として、「id」というパラメータを用意しています。そして、 whereでidパラメータについて'[0-9]+'という制約を課しています。これで、idには数値以外が入力できなくなります。 では、HelloController@indexアクションを修正しましょう。


<p class="tmp list"><span>リスト1-7</span></p>
```
public function index($id)
{
    $data = [
        'msg'=>'id = ' . $id,
    ];
    return view('hello.index', $data);
}
```
修正したら、http://localhost:8000/hello/12345にアクセスしてみましょう。すると、 「id = 12345」とメッセージが表示されます。パラメータで渡された値を取り出し、メッ セージとして表示していることがわかります。  
では、数字以外の値をパラメータに指定してみましょう。例えば、http:// localhost:8000/hello/abcとアクセスしてみると、「404 Not Found」と表示が現れます。 これは、HTTPの404エラーの画面です。404は、アドレスが未検出である場合に発生す るので、「そのアドレスが見つからない」ことを示します。パラメータに数字以外のものが渡されると、このように404エラーが発生するようになっているのです。


ここでは数字のみを入力するように指定しましたが、正規表現のパターン次第で、ど のようにも制約を用意できます。また制約に反する場合は、404エラーとして処理され るため、コントローラーなどで独自にエラー処理を用意する必要がありません。単に、 404エラーの処理を用意しておくだけで済みます。

## HTTPステータスコードによるエラー表示
ここで、404エラーによるエラー表示の仕組みについても触れておくことにしましょう。 404エラーのようにHTTPのステータスコードによるエラー表示は、Laravelではデフォルトで用意されています。これは、エラーコード関係のビューテンプレートを用意することで、カスタマイズすることもできます。  
手作業で1つひとつのファイルを作成していくこともできますが、artisanコマンドを 使ってテンプレートファイルを作成し、それをカスタマイズしていったほうが簡単です。 コマンドプロンプトまたはターミナルから、次のように実行して下さい。

<p class="tmp cmd"><span>コマンド2</span></p>
```
php artisan vendor:publish --tag=laravel-errors
```

これで、「views」フォルダ内に「errors」というフォルダが作成され、その中にHTTPス テータスコードによるエラー表示のテンプレートファイル類が生成されます。ここには、 2つのファイルが用意されています。

<dl class="dl-table">
    <div>
        <dt>ステータスコード.blade.php</dt>
        <dd>ステータスコードに「blade.php」を付けたファイルは、そのステータスコードのエラーが発生した際の表示を行う ビューテンプレートファイルです。</dd>
    </div>
    <div>
        <dt>レイアウト名.blade.php</dt>
        <dd>レイアウト用のテンプレートファイルです。layout.blade. php、minimal.blade.php、illustrated-layout.blade. phpの3つが用意されています。</dd>
    </div>
</dl>


<p class="tmp list"><span>リスト1-8</span></p>
```
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">


        <title>@yield('title')</title>


        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" 
                rel="stylesheet" type="text/css">


        <!-- Styles -->
        <style>
            ……略……
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <div class="code">
                @yield('code')
            </div>


            <div class="message" style="padding: 10px;">
                @yield('message')
            </div>
        </div>
    </body>
</html>
```

|	|	|
|--|--|
|@yield('title') |タイトルを出力します。|
|@yield ('code') |ステータスコードを出力します。|
|@yield ('message')|メッセージを表示します。|


## ルートグループについて
ルートには、特定の機能を複数のルートにまとめて割り当てるための「ルートグルー プ」という機能があります。

* ミドルウェアの割り当て 
* 名前空間の指定 
* サブドメインの指定 
* URIプレフィクスの指定


## ミドルウェアの適用
では、ルートグループの例として、ミドルウェアを適用することを考えてみましょう。 ミドルウェアは、アクションの前後に特定の処理を割り込ませるプログラムです。

<p class="tmp list"><span>リスト1-9</span></p>
```
<?php
namespace App\Http\Middleware;


use Closure;


class HelloMiddleware
{
    public function handle($request, Closure $next)
    {
        $hello = 'Hello! This is Middleware!!';
        $bye = 'Good-bye, Middleware...';
        $data = [
            'hello'=>$hello,
            'bye'=>$bye
        ];
        $request->merge($data);
        return $next($request);
    }
}
```


<p class="tmp list"><span>リスト1-10</span></p>
```
<?php
namespace App\Http\Controllers;


use Illuminate\Http\Request;


class HelloController extends Controller
{
    public function index(Request $request)
    {
        $data = [
            'msg'=>$request->hello,
        ];
        return view('hello.index', $data);
    }


    public function other(Request $request)
    {
        $data = [
            'msg'=>$request->bye,
        ];
        return view('hello.index', $data);
    }
}
```

### ルートグループでミドルウェアを割り当てる
作成したミドルウェア(HelloMiddleware)をルートグループで特定のルートに割り当 てましょう。  
/routes/web.phpのHelloController関係のルート情報を次のように修正し て下さい。


<p class="tmp list"><span>リスト1-11</span></p>
```
Route::middleware([HelloMiddleware::class])->group(function () {
    Route::get('/hello', 'HelloController@index');
    Route::get('/hello/other', 'HelloController@other');
});
```

Route::middlewareでHelloMiddleware::classをミドルウェアに指定し、groupでグループ設定をしています。  
このgroupは関数を引数に指定するようになっており、その関数内でRoute::get文を必要なだけ記述してルートを用意しています。ここに用意されたルート全てについて、 HelloMiddlewareが組み込まれ、使えるようになるわけです。


## 名前空間とグループルート
特定の名前空間に配置されているコントローラーのアクションをまとめて ルート設定するような場合には、Route::namespaceを使って名前空間を指定し、そこからgroupでグループルート設定を行う、というやり方をします。
```
Route::namespace(
a )->group(function() {......});
```
groupメソッドの使い方は、Route::namespaceで名前空間を指定することで、その名前空間にあるコントローラーを利用したルート設定をまとめて 管理します。










