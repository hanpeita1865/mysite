*[page-title]:CSS新機能一覧


## 要素設定系

### :has() 

用途
: 特定の要素の存在のあり・なしをCSSで判別できます。

サポート状況
: <https://caniuse.com/css-has>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/:has)
: [CSSの便利な新セレクタ :has() / :is() / :where() の使い方解説](https://b-risk.jp/blog/2023/06/new-selector/#has)

<p class="tmp"><span>書式</span></p>
```
:has(存在チェックする要素) {
  /* ... */
}
```
	
<div class="exp">
<p class="tmp"><span>例</span></p>
画像のボックスがあるかないかを「:has」で判別し、スタイルを使い分けています。
<iframe width="100%" height="300" src="//jsfiddle.net/hirao/1beL8fgo/2/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

上記の例では、画像がある場合、元々あるスタイルに次のスタイルがプラスされて、右側のボックスのように画像とテキストが横並びになります。
```
/* .card-imgクラスの要素が存在する場合 */
.card:has(.card-img) {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
}

.card:has(.card-img) .card-content {
  margin-left: 15px;
  width: calc(100% - 165px);
}
```


### :is() 

用途
: 指定した要素に一致する場合、CSSを適用できます。特定の要素をまとめて選択し、一括でスタイルを指定することができるので、コードを簡潔にすることができます。

※擬似要素は :is() のセレクターリストでは無効です。

サポート状況： 
: <https://caniuse.com/?search=%3Ais>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/:is)

<p class="tmp"><span>書式</span></p>
```
:is(セレクタ, セレクタ, セレクタ) {
   /* スタイルの宣言 */
}
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
	CSSを見てもらうと、2番目以降のp要素のスタイルに「:is」を使って文字色を赤にしています。
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/uc0d9rjz/6/embedded/css,html,result" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

通常だと次のように書かないといけないので、CSSで記述する場合少し楽になります。
```
/* 通常の書き方 */
.wrapper .test1 p, .wrapper .test2 p, .wrapper .test3 p {
    color: red;
}
```


### :where()

用途
: 「:is()」と同じように特定の要素をまとめて選択し、一括でスタイルを指定することができるセレクタです。<br>
:is()と違うのは、「<span class="red">詳細度（CSSの優先度）の高さ</span>」です。<br>
<span class="bold green">:where()</span>セレクタを使うと詳細度が0になり優先順位が低くなるので、スタイルを上書きしたいときに便利なセレクタです。

サポート状況
: <https://caniuse.com/?search=css-where>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/:where)


セレクタの固有性（詳細度）について
: <https://www.webword.jp/cssguide/priority/index4.html>
mdn_web_docs 詳細度
: <https://developer.mozilla.org/ja/docs/Web/CSS/Specificity>
基本的なセレクタ
: <https://creatorquest.jp/lessons/css/base-selector/>

<div class="exp">
	<p class="tmp"><span>例</span></p>
	CSSのスタイルは先ほどの「:is」の例とほぼ同じですが、最終行に文字の色を緑に変更している部分だけ違います。通常の書き方や「:is」を使った場合だと、同じようなスタイルを記述しても、文字の色は緑に変わりません。これは、:whereを使った<span class="red bold marker-yellow50">セレクタの詳細度が0</span>になるためで、「.test3 p」の方の優先度が高くなったためです。<br>
詳しくは、下にある「詳細度について」をご確認ください。	
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/c8oupgrd/1/embedded/result,css,html" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

#### 詳細度について

VSCODEやデベロッパーツールのスタイルのセレクタをマウスオーバーすると、次のように固有値（特異性）が確認できます。

<div markdown="1" class="d-flex justify-content-around">
<div markdown="1" class="ml-5">
![](upload/wrapper_where_p.png "図　VSCODE")
![](upload/wrapper_where_p_dev.png "図　デベロッパーツール"){.photo-border}
</div>
<div markdown="1" class="">
![](upload/test3_p_selector.png "図　VSCODE")
![](upload/test3_p_dev.png "図　デベロッパーツール"){.photo-border}
</div>
</div>

この固有値（特異性）の数値によって優先順位が変わってきます。
<p class="tmp"><span>書式</span>固有値（特異性）</p>
```
〇(ID列)　〇(CLASS列)　〇(TYPE列)
```
<span class="green">ID列 </span> 
: 各セレクターのID数を表しています。競合するセレクターのID列の数値が比較されます。他の列の値がどうであれ、ID列の値がより大きいセレクターが勝ちます。

<span class="green">CLASS列  </span>
: セレクターに含まれるクラス名、属性セレクター、擬似クラスの数です。 

<span class="green">TYPE列  </span>
: セレクターに入力された要素型と擬似要素の数です。最初の2列が同じ値である場合、TYPE列数値が大きいセレクターが勝ちます。

例の「`.wrapper :where(.test1, .test2, .test3) p`」では、「:where」の中のクラスは0になるのでクラス列の値は「.wrapper」のみの数で値は1になります。TYPE列 は、p要素のみなので1になります。  
「`.test3 p`」では、クラスが「.test」だけで1になり、TYPE列もpだけで1になります。  
比較すると固有値は同じ(0,1,1)ですが、後から書かれた方が優先度が高くなるので、「.test3 p」のスタイルが適用されます。

少し分かりづらいですが、一括でスタイルを指定する場合、指定したセレクターの詳細度を0にして後ろに記述した同じセレクターが入ったスタイルを適用したいときは「<span class="bold green">:where</span>」を使い、そうでないときは「<span class="bold blue">:is</span>」を使えばいいと憶えておけばいいと思います



### gap

用途
: gap はアイテム間の余白を指定するプロパティです。「<span class="red bold">display:flex</span>」や「<span class="blue bold">display:grid</span>」で使用します。gap を使用すれば margin を使用するよりも簡単に、かつ柔軟にアイテム間の余白を指定できます。もともとgapプロパティはCSS Gridでのみ利用できていましたが、Flexboxでもgapプロパティが使えるようになりました。

サポート状況
: <https://caniuse.com/?search=gap>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/gap)

<p class="tmp"><span>書式</span></p>
```
//一括指定の例「gap」
gap: 10px 20px; //横の間隔　縦の間隔
gap: 10px; //縦横の間隔

//分割指定の例「row-gap（縦の間隔）」と「column-gap（横の間隔）」
row-gap: 10px;
column-gap: 20px;
```

FLEXBOXでボックスなどを並べるときに、マージンで間隔をとって「:first-child」や「:last-child」などを使って調整してたかと思いますが、<span class="bold green">gap</span>を使うことで簡単に間隔設定をすることができるようになります。  

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe width="100%" height="350" src="//jsfiddle.net/hirao/vxkr7q8e/5/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>
上記の例では、ボックスを4列ずつ並べて横の間隔を4%、縦の間隔を20pxにしています。ボックスの幅は、calc()でその間隔分を引いた値になっています。  
下記のスタイルがその部分です。  


<p class="tmp list"><span>リスト</span>4列スタイル</p>
```
.wrap .flex-box {
    column-gap: 4%;/* 横の間隔 */
    row-gap: 20px /* 縦の間隔 */
}

.wrap .flex-box div {
    width: calc(100%/4 - 4%*3/4);/* ボックスの幅 */
    border: 1px solid #afafaf;
}
```




### max-content

用途
: max-contentは内因性で、要素内のコンテンツのサイズに依存して要素のサイズが決まります。オーバーフローが発生しても、コンテンツがまったく折り返されません。

サポート状況
: <https://caniuse.com/?search=max-content>
: <https://developer.mozilla.org/ja/docs/Web/CSS/max-content>（ページ最下部の「ブラウザーの互換性」を確認）

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/max-content)
: <https://coliss.com/articles/build-websites/operation/css/intrinsic-sizing-in-css.html>

<div class="exp">
	<p class="tmp"><span>例</span></p>
	max-contentの要素は、テキストが変更されるとそれに応じて幅が変更されます。
	<iframe width="100%" height="600" src="//jsfiddle.net/hirao/mhfq7pnd/11/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>




### min() 、max() 、clamp()

用途
: 通常幅、最小幅、最大幅を一行で指定することができます。
: この中で特に便利なのが、<span class="bold red">clamp関数</span>です。文字や要素のサイズを指定する際、今までは細かいブレイクポイントを設定する必要がありましたが、clamp()関数を使えば、わずか1行のコードでそれが実現可能です。最も分かりやすい使い道は文字サイズです。特に見出しなど、大きなサイズの文字は画面のサイズが小さくなるとレイアウト崩れの要因になりやすいです。従来であればブレイクポイント毎にサイズを指定していましたが、clamp()関数を使えば、たった1行のコードで自動的に調整してくれます。

サポート状況
: <https://caniuse.com/?search=min()>
: <https://caniuse.com/?search=max()>
: <https://caniuse.com/?search=clamp()>

参考サイト
: [mdn_web_docs（min()）](https://developer.mozilla.org/ja/docs/Web/CSS/min)
: [mdn_web_docs（max()）](https://developer.mozilla.org/ja/docs/Web/CSS/max)	
: [mdn_web_docs（clamp()）](https://developer.mozilla.org/ja/docs/Web/CSS/clamp)
: [【超便利】CSS関数min()・max()・clamp()の使い方を解説！](https://pengi-n.co.jp/blog/min-max-clamp/)
: [動画）最強に便利なCSSの比較関数 min, max, clamp を紹介！これからのレスポンシブ対応に必須！](https://www.youtube.com/watch?v=oXHmEK_z-lo)

<p class="tmp"><span>書式</span></p>
```
min(通常幅, 最大幅)　例）width: min(50vw, 600px);
max(通常幅, 最小幅)　例）width: max(50vw, 240px);
clamp(最小幅, 通常幅, 最大幅)　例）width: clamp(400px, 50vw, 600px);  font-size: clamp(1rem, 2vw, 5rem); 
```
※ 「vw」は、Viewport Width（ビューポートの幅）の略で、画面の幅を基準に大きさを指定する単位です。1vwは画面幅の1%を表します。

次のようにwidth、min-width、max-width を別々で書いてたのを、1行にすることができます。
<div markdown="1" class="d-flex align-items-center justify-content-around gray-box">
<div markdown="1" class="d-flex flex-column align-items-center">
<p>min()</p>
```
/*　いままでの書き方 */
.box {
　width: 50vw;
　max-width: 600px;
}
```
<span class="arrow-down mb-3"></span>

```
/*1行にまとめられる*/
.box {
  width: min(50vw, 600px);
}

```
</div>
<div markdown="1" class="d-flex flex-column align-items-center">
<p>max()</p>
```
/*　いままでの書き方 */
.box {
　width: 50vw;
　min-width: 400px;
}
```
<span class="arrow-down mb-3"></span>

```
/*1行にまとめられる*/
.box {
  width: max(50vw, 400px); 
}

```
</div>
<div markdown="1" class="d-flex flex-column align-items-center">
<p>clamp()</p>
```
/*　いままでの書き方 */
.box {
　width: 50vw;
　min-width: 400px;
　max-width: 600px;
}
```
<span class="arrow-down mb-3"></span>

```
/*1行にまとめられる*/
.box {
  width: clamp(400px, 50vw, 600px);
}

```
</div>
</div>


## 変数系

### Custom Property（カスタムプロパティ）

変数は、一度定義しておけば繰り返し汎用的に利用できるものになります。変数の中身を変えると、その変数を使った箇所にもその変更が反映されるため、修正の手間をかなり削減することができます。  
Sass等ではお馴染みですが、Sassがなくてもカスタムプロパティを利用することで、CSSでも変数を使うことができるようになります。

特定の色やフォント、コンテンツの両脇の空きなどを、:rootのCSS変数として管理すれば、CSSの見通しが良くなります。

サポート状況
: <https://caniuse.com/?search=--*>
: <https://developer.mozilla.org/ja/docs/Web/CSS/--*>

#### CSS変数の定義の仕方

CSS変数を定義するためには、「<span class="bold green">--</span>」ハイフンふたつを使って定義します。  
例えば、以下のように記述します。
```
:root {
  --green: #28a745;
｝
```
上記の「`--green`」の部分が変数名になり、自由に名前をつけることができます。また、大文字・小文字の区別があります。  
「`:root`」というのは、<span class="bold blue">グローバル変数</span>というものになります。

※グローバル変数とは、宣言することであらゆるところで使用できる変数のことを言います。


#### 定義したCSSカスタムプロパティを呼び出す

実際に使いたい箇所で、 `var(--変数名)` と記述すると、定義した値を当てはめられます。  
例えば、次のように記述します。
```
.box {
  background-color: var(--green);
}
```

また、rootを使わずに要素内で定義した場合、その変数は宣言した要素の中だけでの利用になります。  
例えば、次のようにheader内で変数を定義すると、footerではその変数は利用できません。
```
header {
	--theme-color: #86c0de;
    background-color: var(--theme-color);/* 変数を定義 */
    width: 100%;
    height: 200px;
}

footer {
    background-color: var(--theme-color);/* この変数は反映されない */
    width: 100%;
    height: 150px;
}
```

ただし、宣言した要素の子要素や要素の疑似要素では利用できます。
```
header {
	--theme-color: #86c0de;
    background-color: var(--theme-color);/* 変数を定義 */
	
}

header::after {
    content: '';
    position: absolute;
    border: 1px solid var(--theme-color);/* この変数は反映される */
    ・・・・・
}

header .inner {
    background-color: #fff;
    color: var(--theme-color);/* この変数は反映される */
    ・・・・・ 
}
```

ちなみに変数の中で変数を使うこともできます。
```
:root {
  --box-margin-top: 100px;
  --box-margin-bottom: 50px;
  --box-margin: var(--box-margin-top) auto var(--box-margin-bottom);
}
```

他に予備のフォールバックの値をセットすることができます。  
`var(--color,フォールバック値)`と言ったように指定すると、変数が定義されていない場合、フォールバックの値が適用されます。





## テキスト系


### line-clamp

用途
: 要素に行数制限を指定できます。行数を超えたテキストは、省略記号の「…」となります。<br>
「text-overflow: ellipsis」では単一行でしか「…」を使用できませんでしたが、「<span class="bold green">line-clamp</span>」を使うと、複数行で使用できるようになりました。

サポート状況
: <https://caniuse.com/?search=line-clamp>

参考サイト
: [CSSリファレンス](https://www.tohoho-web.com/css/prop/line-clamp.htm)

display に -webkit-box または -webkit-inline-box、overflow に hidden が設定されている場合に有効です。Firefox の場合は -webkit-box-orient に vertical の設定も必要です。
```
.example-box {
  ・・・・
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical; /*FireFox用*/
  -webkit-line-clamp: 3; /*行数を指定*/
}
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
	テキストの表示は5行で設定しているので、5行目の最後に省略記号の「…」が付きます。
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/bngwmy1z/2/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>



### text-stroke（-webkit-text-stroke）

以前までは、シャドウ用の「<span class="bold blue">text-shadow</span>」で縁取りをしていましたが、「<span class="bold red">text-stroke</span>」でも同じように行うことができます。Chrome, Edge, Safari, Firefox, Opera でサポートされていますが 「<span class="bold red">-webkit- </span>」をつける必要があります。

用途
: 文字を縁取りします。

サポート状況
: <https://caniuse.com/?search=css-text-stroke>

参考サイト
: [CSSリファレンス](https://www.tohoho-web.com/css/prop/text-stroke.htm)
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/-webkit-text-stroke)
: [縁取り文字はCSSのtext-strokeで可能。（非推奨の時代は終わり。）](https://igawa.co/memos/%E7%B8%81%E5%8F%96%E3%82%8A%E6%96%87%E5%AD%97%E3%81%AFcss%E3%81%AEtext-stroke%E3%81%A7%E5%8F%AF%E8%83%BD%E3%80%82%EF%BC%88%E9%9D%9E%E6%8E%A8%E5%A5%A8%E3%81%AE%E6%99%82%E4%BB%A3%E3%81%AF%E7%B5%82/)


<p class="tmp"><span>書式</span></p>
```
-webkit-text-stroke: 輪郭線の太さ 輪郭線の色;
text-stroke: 輪郭線の太さ 輪郭線の色;
```

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/L5m4crb6/5/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例2</span>画像上に透明の文字を縁取って配置</p>
	<iframe width="100%" height="500" src="//jsfiddle.net/hirao/kehfwn9b/2/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


### background-clip:text

用途
: 背景を文字の中に切り取って表示できます。

サポート状況
: <https://caniuse.com/?search=background-clip>
: <https://developer.mozilla.org/ja/docs/Web/CSS/background-clip>

参考サイト
: [CSSリファレンス](https://www.tohoho-web.com/css/prop/background-clip.htm)

<div class="exp">
	<p class="tmp"><span>例</span></p>
	この<a href="https://fastly.picsum.photos/id/990/630/400.jpg?hmac=azyd-s1Fb7EtbkLdaYbKXMp3lCIYjYqvfRVNGVSd3A0">画像</a>を文字の背景に使用しています。
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/Lefg3mkr/1/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

↓ のプロパティはいまいち使い道がわからん。
background-clipではtext以外でも次のような値を使うことができます。
* border-box：	背景を境界の外側の辺まで拡張します (但し、境界の下に重ね合わせられます)。
* padding-box：背景をパディングの外側の辺まで拡張します。境界の下には背景が描かれません。
* content-box：背景をコンテンツボックスの中に (切り取って) 表示します。





## 動作系


### position: sticky

position: stickyは、粘着位置指定といい、親要素を基準に配置され、スクロールに応じて<span class="bold red">親要素の範囲内</span>で基準に追従させるプロパティです。  
追従する点で、position: fixed;に似ています。  
fixedはウィンドウを基準に配置されますが、stickyは<span class="bold red">親要素を基準に配置</span>されます。  
そのため、親要素の一番下までスクロールすると自動的に要素が親要素の下部で止まります。

注意点
親要素にoverflowが指定されている  
: 親要素に、overflow: visible;以外の値（auto, hidden, scroll）が指定されていると、追従してくれません。

topを指定していない  
: stickyの要素にtopが指定されていない場合は追従しません。一番外側（要素のフチ）で追従の場合は、top: 0;でよいです。


サポート状況
: <https://caniuse.com/?search=position%3Asticky>

<div class="exp">
	<p class="tmp"><span>例</span>グロナビ固定</p>
	スクロールすると、stickyによってヘッダーは通り過ぎてグロナビの箇所で上部に固定されます。
	<iframe width="100%" height="600" src="//jsfiddle.net/hirao/vr0g5jnk/1/embedded/result,html,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例</span>サイドバー固定</p>
	ヘッダーを通り過ぎるとサイドバーが固定され、フッターの位置まで来ると固定が解除されます。
	<iframe width="100%" height="700" src="//jsfiddle.net/hirao/exz5r90L/2/embedded/result,html,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例</span>見出し固定</p>
	スクロールすると、各見出しが固定されます。次の見出しの位置に来ると前の見出しの固定は解除されます。
	<iframe width="100%" height="500" src="//jsfiddle.net/hirao/1bxkt72a/1/embedded/result,html,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>




### scroll-behavior: smooth

用途
: ページ内リンクのスクロールをスムーススクロールにできます。また、アンカーリンク付きURLでアクセスしたときもスムーススクロールでスクロールされます。

サポート状況
: <https://caniuse.com/?search=scroll-behavior>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/scroll-behavior)
	
<div class="exp">
	<p class="tmp"><span>例</span></p>
	左側はスムーススクロールなしで、右側はスムーススクロールを設定しているのでスムーズにスクロールします。<br>A、B、Cのリンクをクリックすると動作が確認できます。
</div>
<div markdown="1" class="d-flex justify-content-between gray-box">
<div markdown="1" class="wd45">
<p class="lang fz-12 blue">設定なし</p>
<iframe width="100%" height="350" src="//jsfiddle.net/hirao/x2wvhtbr/3/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>
<div markdown="1" class="wd45">
<p class="lang fz-12 red">設定あり</p>
<iframe width="100%" height="350" src="//jsfiddle.net/hirao/ws9xamnv/5/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>
</div>


## 図形系


### clip-path

用途
: 要素のどの部分を表示するかを設定するクリッピング領域を作ります。領域の内部の部分は表示され、外側の部分は非表示になります。それを使って色々な形を作成したり、画像を切り抜いたりできます。
: tableやiframe要素といったコーディングされた要素から動画まで、元になるクリッピングの対象要素は何にでも使用できます。
: clip-pathには、inset( )四角形、polygon()多角形、circle()円、ellipse()楕円などがあります。

サポート状況
: <https://caniuse.com/?search=clip-path>
: <https://developer.mozilla.org/ja/docs/Web/CSS/clip-path>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/clip-path)
: [IEサポート終了後にCSSで実装できるclip-pathの使い方](https://tane-be.co.jp/knowledge/web-design/405/)

#### insert()
inset() は内側へオフセットされた矩形（四角形）を定義します。inset() を使うと矩形のシェイプを切り抜くことができます。
<p class="tmp"><span>書式</span></p>
```
inset（ length [ round ] ）
```


 値 | 意味 
 -------- | -------- 
length     | 要素（正確には基準ボックス）の各端からの距離（オフセット）を単位付きの値または ％ で指定します。指定方法は margin などと同じで値を１〜４個まで半角スペースで区切って指定します。<br>値が１つ：「上下左右」<br>値が２つ：「上下」と「左右」<br>  値が３つ：「上」と「左右」「下」<br>  値が４つ：「上」と「右」と「下」と「左」（時計回り）
round | round	ボックスの角を丸くする（角丸にする）場合に角丸の半径の値を指定します。指定方法は border-radius の略式プロパティと同じです。<br>値が１つ：全ての角の半径<br>値が２つ：「左上と右下」と「右上と左下」<br>値が３つ：「左上」と「右上と左下」と「右下」<br>値が４つ：「左上」と「右上」と「右下」と「左下」（時計回り）

<div class="exp">
	<p class="tmp"><span>例</span>inset()</p>
</div>
```
.cp-inset {
  clip-path: inset(40px 50px round 20px);
}
```
上記のように記述すると、上下40px、左右50px、角丸20pxの四角形になります。
![](upload/puple_angle1.png)

<iframe width="100%" height="300" src="//jsfiddle.net/hirao/ft3q9poc/2/embedded/result,html,css/" class="iframe-border mb-5" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


#### polygon()

polygon() は多角形を定義します。polygon() を使うと多角形のシェイプを切り抜くことができます。

<p class="tmp"><span>書式</span></p>
```
polygon（ [fill-rule,] 頂点の座標1, 頂点の座標2, ... ）
```

 値 | 意味
 -------- | --------
 fill-rule  | 塗り潰し方法を指定します。nonzero（初期値）または evenodd（領域が囲まれている線の本数が奇数の場合は塗り潰し、偶数の場合は塗らない）を指定できます。
<span class="text-nowrap">頂点の座標</span> | 多角形の頂点のスペース区切りのX座標とY座標のペアをカンマ区切りで指定します。

clip-pass-maker（<https://bennettfeely.com/clippy/>）というジェネレータを参考に様々な形のスタイルを作ることもできます。  
形を選択すると、最下部にスタイルが表示されるのでそれをコピペして使用します。

<iframe width="100%" height="800" src="https://bennettfeely.com/clippy/" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<div class="exp">
	<p class="tmp"><span>例</span></p>
	ここでは、inset( )、polygon()、circle()、ellipse()と上のジェネレータを使って、切り抜いたように画像を表示させています。
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/4nLetqpu/12/embedded/result,html,css/" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>



#### 正三角形を作る

CSSで三角形を作る方法と言えば、borderを使った方法が一般的でしたが、clip-pathを使うことで簡単に作ることができます。  
正三角形を作るには、clip-pathと後ほど説明で出てくる<span class="bold">三角関数</span>を使用します。

基本的な正三角形スタイルは、次のように記述できます。

<div class="exp">
	<p class="tmp"><span>例</span>正三角形（上向き、下向き、左向き、右向き）</p>
	サイズの調整は、上向きと下向きではwidthの値、左向きと右向きではheightの値を変更します。
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/p7uvj4zb/2/embedded/result,html,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

下記の三角形用のCSSジェネレータ（<https://css-generators.com/triangle-shapes/>）を利用すると、色々な三角形のスタイルが取得できます。
<iframe width="100%" height="300" src="https://css-generators.com/triangle-shapes/" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


### 三角関数

今までは固定であればあらかじめ計算された値を指定したり、JavaScriptで処理したりしていましたが、CSSに三角関数が実装されたことにより、今まであらかじめ固定値で実装していたところやJavaScriptで実装していたところを、簡単にCSS側で対応することができるようになりました。

三角関数を用いれば、<span class="bold green">中心からの距離（半径）</span>と<span class="bold green">角度</span>を入力することで、<span class="bold red">辺の高さ</span>や<span class="bold red">長さ</span>を算出することができます。つまり【オブジェクトに対して円状や扇状に配置したい】が、簡単に叶うようになりました。

サポート状況
: <span class="marker-yellow50 bold green">sin()</span>　<https://caniuse.com/mdn-css_types_sin>
: <span class="marker-yellow50 bold green">cos()</span>　<https://caniuse.com/mdn-css_types_cos>
: <span class="marker-yellow50 bold green">tan()</span>　<https://caniuse.com/mdn-css_types_tan>

実際に使ってみる前に、昔学校で習った三角比について簡単に説明しておきます。

#### 三角比とは？
三角比とは、三角形の辺の比のことです。  
直角三角形の斜辺（一番長い辺）と高さの比を正弦（サイン）、斜辺と底辺の比を余弦（コサイン）、底辺と高さの比を正接（タンジェント）と呼び、次のように表します。
![](upload/trigonometric_ratio.png){.photo-border}

#### 三角比の基本

三角定規に用いられる、30°・45°・60°の三角比が基本の角度でみてみましょう。
<div markdown="1" class="d-flex flex-wrap">
![](upload/30angle.png)
![](upload/45angle.png)
![](upload/60angle.png)
</div>


上記で使用されている![](upload/rute.png){.figure-none}（ ルート）とは、平方根を表す記号です。

例えば、2の平方根は次のような値になります。  
2 = (1.414･･･)<sup>2</sup>　→ この中の1.414･･･が![](upload/rute2.png){.figure-none} の値です。  

3の場合は、3 = (1.732･･･)<sup>2</sup> →　1.732･･･が![](upload/rute3.png){.figure-none} の値です。 

#### 実際に使ってみる

<p class="tmp"><span>書式</span>sin()、cos()</p>
```
x座標 = 半径×cos(角度) 
y座標 = 半径×sin（角度）
```

例えば半径100px　角度30度 の場合、  
x座標は、100px × cos(30)  
y座標は、100px × sin(30)で取得できます。  
それを位置指定すると、次のようになります。そのまま記入すると下側の角度になるので、(360-角度)で設定する必要があります。

<iframe width="100%" height="300" src="//jsfiddle.net/hirao/zqLytv4c/2/embedded/result,html,css" class="iframe-border mb-5" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

次は、ローディングを作成してみます。  
<div class="exp">
	<p class="tmp"><span>例</span></p>
	この場合はまず360°を8で割って●を設置し、それを@keyframesを使って●を順番に表示・非表示を繰り返します。
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/efc863sh/3/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


## 画像系


### object-fit

用途
: 画像の高さを縮めた時に、画像が圧縮した感じになることなくきれいに表示させることができます。<br>
backgroundでの画像をcontainやcoverなどできれいに表示させることはできてましたが、それを<span class="red">imgタグ</span>の画像にも同じように適用させて表示することができます。

サポート状況
: <https://caniuse.com/?search=object-fit>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/object-fit)
: [object-fit のおさらい](https://www.tribeck.jp/column/opinion/production/20230213/)

<div class="exp">
	<p class="tmp"><span>例</span></p>
	画像エリアより大きい画像と小さい画像でのobject-fitプロパティの値による表示の比較をしています
	<iframe width="100%" height="1900" src="sample/object-fit/" class="iframe-border" allowfullscreen=" class="iframe-border" allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


### aspect-ratio

用途
: アスペクト比を保持するためのCSSプロパティです。アスペクト比とは、画像や画面の縦と横の長さの比率（縦横比）のことです。例えば、640px × 480pxの画像のアスペクト比は「4:3」になります。aspect-ratioプロパティを使うことによって、CSSでアスペクト比を指定できるようになり、保守性がより高まります。

サポート状況
: <https://caniuse.com/?search=aspect-ratio>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/aspect-ratio)
: [aspect-ratioプロパティとは？使い方について解説](https://zero-plus.io/media/css-aspect-ratio/)

<div class="exp">
	<p class="tmp"><span>例</span></p>
	2番目の画像には縦長の画像が入っていますが、imgタグに<span class="bold red">aspect-ratio</span>と<span class="bold green">object-fit: cover; </span>を設定することによって、画像のアスペクト比を維持しつつ 400 × 250 の枠内に収まるように表示することができます。
	<iframe width="100%" height="400" src="//jsfiddle.net/hirao/f9bo3quk/2/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

imgタグに<span class="bold green">object-fit: cover; </span>のみ設定して、aspect-ratioの設定をしない場合、次のような表示になります。
<iframe width="100%" height="630" src="sample/aspect-ratio/index3.html" class="iframe-border mb-5" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

imgタグに<span class="bold red">aspect-ratio</span>のみ設定をして、object-fit: cover;なしだと2番目の縦長の画像が枠内にむりやり全体を表示させてしまってるようになります。
<iframe width="100%" height="300" src="sample/aspect-ratio/index1.html" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>




### mask-image

mask-imageと同じように画像を切り抜く機能を持つclip-pathがありますが、大きな違いとして、透過情報を適用できるかどうか、という違いがあります。「mask-image」はマスク用画像の透過情報が適用されますが、「clip-path」は適用されません。

次の例を見て頂くとわかりますが、mask-imageはグラデーションを使って画像に白い霧がかかったように見せたり、放射状グラデーション(円形)などすることができます。
<div class="exp">
	<p class="tmp"><span>例</span></p>
<iframe width="100%" height="600" src="//jsfiddle.net/hirao/rux1zqs3/2/embedded/result,html,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<iframe width="100%" height="400" src="//jsfiddle.net/hirao/s1fm3t24/3/embedded/result,html,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


### filter

用途
: 画像にぼかしや色調などのいろいろな効果を指定することができます。<!--<br>CSS Filter ジェネレーター（<https://front-end-tools.com/generateFilter/>）を使うと様々なパターンの効果を簡単に作成することができます。-->

サポート状況
: <https://caniuse.com/?search=css-filter>

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/filter)
: [CSS Filter ジェネレーター](https://front-end-tools.com/generateFilter/)

<div class="exp">
<p class="tmp"><span>例</span></p>
各フィルターの表示です。複数のフィルターを組み合わせることも可能です。
<iframe width="100%" height="800" src="//jsfiddle.net/hirao/1fghn83w/4/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


### mix-blend-mode

用途
: 重なる要素の色を識別して要素の色を変更できるCSSプロパティです。<br>
mix-blend-modeは独自の値があり、重なった部分の色を反転させたり、明るさを変えたりなど、どのように混ざり合うかを指定できます。
Photoshopなどのグラフィックツールで使っていたブレンドモード機能をCSSでも設定できるようになります。

サポート状況
: <https://caniuse.com/?search=mix-blend-mode>
: <https://developer.mozilla.org/ja/docs/Web/CSS/mix-blend-mode>（ページ最下部の「ブラウザーの互換性」を確認）

参考サイト
: [mdn_web_docs](https://developer.mozilla.org/ja/docs/Web/CSS/mix-blend-mode)
: [mix-blend-modeの使い方を徹底解説！重なり合う要素をオシャレに色変更！](https://pengi-n.co.jp/blog/mix-blend-mode/)
: [CSSのブレンドモードが素敵！mix-blend-modeを使いこなそう](https://ics.media/entry/7258/)
: [CSSで乗算がかけられる!!css3の新プロパティ「mix-blend-mode」でデザインの幅を広げよう!!](https://wk-partners.co.jp/homepage/blog/hpseisaku/htmlcss/mix-blend-mode/)
: [mix-blend-mode を使いこなして、Webデザインの可能性を広げよう！](https://qiita.com/emily_unt/items/bfd8c25cb6fc45bed553)
: [CSS mix-blend-modeを利用してブレンドモードをキレイに再現しよう](https://www.asobou.co.jp/blog/web/css-mix-blend)
: [CSSブレンドモード。mix-blend-modeの例一覧。乗算やスクリーンを！](https://igawa.co/memos/css%E3%83%96%E3%83%AC%E3%83%B3%E3%83%89%E3%83%A2%E3%83%BC%E3%83%89%E3%80%82mix-blend-mode%E3%81%AE%E4%BE%8B%E4%B8%80%E8%A6%A7%E3%80%82/#google_vignette)
	
	<p class="tmp"><span>書式</span></p>
	```
	mix-blend-mode: 値を指定;
	```
<span class="red">※前提として、mix-blend-modeは要素を重ねる必要があります。</span>

#### mix-blend-modeの値の種類

<iframe width="100%" height="650" src="sample/mix-blend-mode/index.html" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<div class="exp">
	<p class="tmp"><span>例</span></p>
	「mix-blend-mode: difference;」を使うと、文字色が反転されて背景色によって文字色が変わります。
	<iframe width="100%" height="400" src="//jsfiddle.net/hirao/uhc2kevq/4/embedded/result,html,css" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


#### サイトサンプル

[RESCALAR｜株式会社リスカラ](https://rescalar.co.jp/)

色差（diffence）を使い画像上のテキスト色を反転させた、しゃれたデザインになっています。
<iframe width="100%" height="450" src="https://rescalar.co.jp/" style="transform: scale(0.7) translate(-20%, -20%); " class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

[DROP TOKYO](https://droptokyo.com/freshsnaps/324754/)

スクロールすると、画面上のテキストが反転した色で変わっていくのがわかります。色差（diffence）やオーバーレイ（overlay）を使用して、このデザインの表現を実現させています。
<iframe width="100%" height="500" src="https://droptokyo.com/freshsnaps/324754/" style="transform: scale(0.8) translate(-10%, -10%); " class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


### backdrop-filter

背景の要素に色の変更やぼかしなどさまざまな効果を与えることができるプロパティです。

サポート状況
: <https://caniuse.com/?search=backdrop-filter>

参考サイト
: [msdn_docs](https://developer.mozilla.org/ja/docs/Web/CSS/backdrop-filter)
: [backdrop-filterの使い方解説！CSSでグラスモーフィズムを実装！](https://pengi-n.co.jp/blog/backdrop-filter/)
: [たった一行でガラス板の美しいエフェクトが実装できる、backdrop-filterプロパティの使い方を解説](https://coliss.com/articles/build-websites/operation/css/css-property-backdrop-filter.html#google_vignette)

デモ
: <https://codepen.io/robinrendle/pen/LmzLEL?editors=1100>
: <https://cdpn.io/pen/debug/ZoXGgG>

ジェネレータ →みんばりにはのせない
: <https://front-end-tools.com/generateBackDropFilter/#google_vignette>

<p class="tmp"><span>書式</span></p>
```
backdrop-filter: 値を指定;
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
	「NTTDATA DAICHI」の帯に<span class="bold green">backdrop-filter</span>のプロパティを設定しています。
	<iframe width="100%" height="1100" src="sample/backdrop-filter/index.html" class="iframe-border" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


## その他

### display: contents; 　
: 用途
	: ：特定のタグを非表示にすることができます。display:none;と違って、子要素は消さないで指定したタグだけ消します。<br>
ただし、一部のブラウザーの現在の実装では、アクセシビリティツリーから display の値が contents であるすべての要素を削除します (ただし子孫は残ります)。これにより、その要素自身は読み上げソフトでは読み上げられなくなります。これは CSS 仕様書によれば正しくありません。（<https://drafts.csswg.org/css-display/#valdef-display-contents>）<br>
display: contentsはまだ新しい方なので順次対応していくと思いますが、アクセシビリティツールを考えると使用はできるだけ最小限にした方が良いのかもしれません。
: サポート状況
	: ：<https://caniuse.com/?search=display%3A%20contents>
: 参考サイト
	: ：[【CSS】display: contents の使用方法！便利な使い方を例を交えて解説します](https://retval.jp/blog/css-display-contents/)




## 参考サイト

サイト
: [IEサポート終了したのでIE非対応の便利なCSSを6選紹介します。](https://evoworx.dev/blog/css-ie-not-supported/)
: [【CSS Flexbox】で余白の設定をする方法！【gapとcalc】も便利！](https://ui-hack.com/programming/html_css/cssflexmargin/)
: [CSSの便利な新セレクタ :has() / :is() / :where() の使い方解説](https://b-risk.jp/wp/wp-content/themes/brisk/sample/entry/20230615/#section01-2)
: [CSSの便利な新セレクタ :has() / :is() / :where() の使い方解説](https://b-risk.jp/blog/2023/06/new-selector/#has)
: [CSSリファレンス](https://www.tohoho-web.com/css/index.htm)

YOUTUBE
: [【2022】これから使えるCSSプロパティ18選！新しく使える便利なCSSテクニック！](https://www.youtube.com/watch?v=EeZM5SXuCsU)


