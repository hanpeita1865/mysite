---
title: '27. ユニットテスト'
taxonomy:
    category:
        - docs
media_order: 'touch_command.png,php_unit.png,unit_error.png'
---

Laravelには、各種のテスト機能があります。その中でも、もっとも基本となる「ユニットテスト」の使い方について、ここで説明します。

## ユニットテストとPHPUnit
アプリケーションの開発では、プログラムが正常に動作しているかをチェックする作業が重要になります。これに用いられるのが「ユニットテスト」です。

ユニットテストは、「単体テスト」とも呼ばれます。プログラム全体ではなく、1つ1つの機能(ユニット)について動作を確認していくものです。Laravelでは、PHP用のユニッ トテストプログラム「PHPUnit」が組み込まれており、これを利用してユニットテストを行うことができます。

ユニットテストには、テストのスクリプトファイルを作成し、そこにテストの内容を記述しておく必要があります。これは、プロジェクトフォルダ内にある「tests」フォルダ の中にまとめられています。

このフォルダの中には「Feature」と「Unit」というフォルダが用意されています。これらの中に「ExampleTest.php」というファイルが用意されています。これは、サンプルとしてデフォルトで用意されているテスト用のスクリプトファイルです。このファイルを参考に、テスト処理を作成していけばいいというわけです。

### ExampleTest.php について
では、デフォルトで用意されているExampleTest.phpがどのようになっているか、中身を見てみましょう(コメントは省略)。

#### ver.5.4.0の場合
<p class="tmp list"><span>リスト1-1</span>Feature/ExampleTest.php</p>
```
<?php
namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class HelloTest extends TestCase
{
   public function testExample()
   {
       $this->assertTrue(true);
   }
}
```

#### ver.5.8の場合
<p class="tmp list"><span>リスト1-2</span>Feature/ExampleTest.php</p>
```
<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testBasicTest()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }
}
```

これは、「Feature」フォルダにあるExampleTest.phpの中身です。「Unit」フォルダにあるものも、use文が一部違うだけで基本的には同じです。 ユニットテストのスクリプトファイルは、以下のような形で記述されます。
```
class クラス名 extends Test Case
{
public function test 〇〇 ()
	{
		・・・テスト処理・・・
    }
}
```
ユニットテストのプログラムは、TestCaseクラスを継承して作成されます。メソッド名は、testExample(ver.5.4の場合)やtestBasicTest(ver.5.8の場合)となっていますが、これは必ずこの名前で用意するわけではありません。

TestCaseクラスにあるメソッドは、「test」で始まる名前のメソッドをテスト用のメソッドと判断し、テスト時にそれらをすべて実行するようになっています。したがって、 testABCでもtestOKでも、どんな名前でも(冒頭にtestさえついていれば)構わないのです。

## テスト用データベースの準備
では、実際にユニットテストを行ってみましょう。まず、テスト用のデータベースファイルを用意しましょう。今のところはまだ本格的なプログラムは作っていませんが、実際の開発では「正式公開時に使っているデータベースをそのままテストで使う」というのは非常に危険です。テスト用のデータベースを用意しておき、それを利用するようにしておくべきです。

コマンドプロンプトまたはターミナルから以下のように実行しましょう。

<p class="tmp cmd"><span>コマンド1</span></p>
```
touch database/database_test
```
これで、「database」フォルダ内に「**database_test**」というファイルが作成されます。これをテスト時に利用することにしましょう。

※touchコマンドを実行して「コマンドがありません」と表示された場合は、下記のコードをコマンドプロンプトで実行してください。

```
npm install touch-cli -g
```
以下の画面が表示されれば、touchコマンドが次から使えるようになるので、再度コマンド1を実行してください。

![](touch_command.png)

### phpunit.xml の追記
続いて、PHPUnitの設定に使用するデータベースの情報を追記します。プロジェクトフォルダを開いたところに「phpunit.xml」というファイルがあるのでこれを開いて下さ い。これはXMLであり、&lt;phpunit&gt;というタグの中に各種の設定情報が記述されています。
この中から、&lt;php&gt;というタグ(中に、&lt;env name="ON" value="○○"&gt;といったタグがいくつか用意されています)の中に、以下のタグを追記して下さい。

<p class="tmp list"><span>リスト2</span>MySQLの場合</p>
```
<env name="DB_DATABASE" value="database_test"/>
```

DB_DATABASEというのが、PHPUnitで使用するデータベース名です。SQLiteでは、データベースファイルのパス（database/database_test.sqlite）を記述します。**MySQL**やPostgreSQLの場合は、**使用するデータベース名**を指定するだけでOKです。



## ダミーレコードの用意
続いて、テストで利用するダミーレコードの情報を用意しましょう。これは、「database」内の「factories」フォルダの中に用意されます。  
デフォルトでは、「ModelFactory.php」というファイルが用意されています。これは名前の通り、モデルを作成するスクリプトです。これを開くと、以下のようなスクリプト がサンプルとして用意されています。

<p class="tmp list"><span>リスト3</span>ModelFactory.php</p>
```
<?php
$factory->define(App\User::class, 
      function (Faker\Generator $faker) {
   static $password;

   return [
       'name' => $faker->name,
       'email' => $faker->unique()->safeEmail,
       'password' => $password ?: $password = bcrypt('secret'),
       'remember_token' => str_random(10),
   ];
});
```

ここでは、$factory->defineというメソッドを呼び出しています。これがモデルを生成する処理を設定するものです。これは、以下のように定義されます。

<p class="tmp"><span>書式1</span></p>
```
$factory->define(モデルクラス , function(Faker\Generator $faker){
    ......処理を用意する...... 
    return [ データ配列 ];
});
```

define メソッドは、第1引数に生成するモデルクラス、第2引数にクロージャを用意し ます。クロージャにはFaker\Generatorクラスのインスタンスが渡されており、これを 利用してフェイクデータを用意し、モデルに設定する各フィールドの値を連想配列にま とめてreturnします。このreturnされた配列の値を使ってモデルが生成され、データベー スに保存されるのです。
サンプルで用意されているのは、Userモデルクラスを生成する処理です。これは、 Authによる認証で利用されているモデルでしたね。Authを利用するテストでは、必ず Userモデルが必要となりますから、最初から用意してあるのでしょう。

今回は、この他にPersonモデルも利用することにしましょう。では、ModelFactory.phpに以下の処理を追記して下さい。

<p class="tmp list"><span>リスト4</span>ModelFactory.php</p>
```
$factory->define(App\Customer::class, 
      function (Faker\Generator $faker) {
   return [
       'name' => $faker->name,
       'mail' => $faker->safeEmail,
       'age' => random_int(1,99),
   ];
});
```

これで、UserとPersonのモデルを生成するための仕組みができました。Personでは、nameとmailの値をFaker\GEneratorから受け取り、ageは乱数を使って値を設定していま す。

## ユニットテストのスクリプト作成
では、ユニットテストのスクリプトを作りましょう。これはコマンドで作成できます。 コマンドプロンプトまたはターミナルから以下のコマンドを実行して下さい。

<p class="tmp cmd"><span>コマンド2</span></p>
```
php artisan make:test HelloTest
```
これで、「tests」内の「Feature」フォルダの中に「HelloTest.php」というファイルが作成されます。これが新たに作成されたユニットテストのファイルです。では、ここに簡単なサンプルを書いてテストしていくことにしましょう。

## 一般的な値のテスト
まずは、Laravel以前の問題として、PHPの一般的な値(数値やテキスト、配列など)を チェックしてみます。スクリプトを以下のように書き換えて下さい。

<p class="tmp list"><span>リスト5</span>HelloTest.php</p>
```
<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class HelloTest extends TestCase
{

   public function testHello()
   {
       $this->assertTrue(true);

       $arr = [];
       $this->assertEmpty($arr);

       $msg = "Hello";
       $this->assertEquals('Hello', $msg);

       $n = random_int(0, 100);
       $this->assertLessThan(100, $n);
   }
}
```

記述したら、コマンドプロンプトまたはターミナルからPHPUnitを実行します。プロジェクトのフォルダにカレントディレクトリがあることを確認し、以下のように実行し て下さい。

■Windowsの場合 
<p class="tmp cmd"><span>コマンド3</span></p>
```
vendor\bin\phpunit
```

最後に「OK (3 tests, 6 assertions)」と表示されれば、すべてのチェックを正しくクリアしています。OK以外のメッセージが出た場合は、どこかでテストに失敗していると考えてよいでしょう。

![](php_unit.png)

### 値をチェックするためのメソッド
ここでは、**$this->assertTrue**とか、**$this->assertEquals**といったメソッドを呼び出していますね。この「assert〇〇」が、値をチェックするメソッドです。これらのメソッドの引数にチェックする値を入れて呼び出せば、値が正しいかどうかをチェックしてくれ ます。

**assert～**で始まるメソッドには、非常に多くのものが用意されています。すべてを一度に覚えるのは無理なので、とりあえず以下のものだけでも覚えて使えるようになっておきましょう。これだけでも使えるようになれば、一通りのチェックは行えるようになります。

<p class="tmp"><span>書式2</span></p>
```
assertTrue(値) 
assertFalse(値)
```
引数の値(真偽値)をチェックします。 assertTrueは、引数の値がtrueかどうかを調べ、 assertFalseは逆に引数がfalseであることを調べます。

<p class="tmp"><span>書式3</span></p>
```
assertEquals( 値1,値2) 
assertNotEquals( 値1, 値2)
```

引数の2つの値が等しいかどうかをチェックします。assertEqualsは等しければtrue、assertNotEqualsは等しくなければtrueになります。

<p class="tmp"><span>書式4</span></p>
```
assertLessThan(値1,値2) 
assertLessThanorEqual( 値1,値2) 
assert GreaterThan(値1,値2) 
assert GreaterThan0rEqual( 値1,値2)
```

2つの値のどちらが大きいかをチェックします。前者2つは第1引数より第2引数のほうが小さい(または等しい)、後者2つは第1引数より第2引数のほうが大きい(または等しい)ことをチェックします。

<p class="tmp"><span>書式5</span></p>
```
assertEmpty(値) 
assertNotEmpty(値) 
assertNull(値) 
assert NotNull(値)
```

引数の値が空またはnullかどうかをチェックします。 assertEmptyとassertNullは、値が空またはnullならtrue、残りの2つは逆に空あるいはnullでないならtrueになります。
<p class="tmp"><span>書式6</span></p>
```
assertstringStartsWith(値1,値2) 
assertStringEndsWith(値1,値2)
```

引数の文字列が指定の文字列で始まる、あるいは終わるかどうかをチェックします。 第2引数の「値2」に調べる文字列を指定し、「値1」には「値2」の最初または最後となる文字列を指定します。値2の最初または最後が値1ならばtrue、そうでないならfalseとなります。

## 指定アドレスにアクセスする
Webアプリケーションの場合、個々の変数などの値をチェックするよりも、作成したアクションのアドレスにちゃんとアクセスできるかのほうが重要でしょう。こうしたテストもLaravelには用意されています。 では、HelloTestクラスを以下のように書き換えてみましょう。

<p class="tmp list"><span>リスト6</span>HelloTest.php</p>
```
// use App\User;　を追記

class HelloTest extends TestCase
{
   use DatabaseMigrations;

   public function testHello()
   {
       $this->assertTrue(true);

       $response = $this->get('/');
       $response->assertStatus(200);
      
       $response = $this->get('/hello');
       $response->assertStatus(302);
      
       $user = factory(User::class)->create();
       $response = $this->actingAs($user)->get('/hello');
       $response->assertStatus(200);

       $response = $this->get('/no_route');
       $response->assertStatus(404);
   }
}
```

記述したら、phpunitコマンドを実行してテストを行いましょう。


エラー画面が表示される。一旦停止
![](unit_error.png)


なお、ここでは、web.phpに記述してある/helloのルート設定に以下のような形でAuthを指定してあり、ログインしなければアクセスできないようになっている状態を想定しています。
```
Route::get('hello', 'HelloControlleraindex')->middleware('auth');
```

### 指定アドレスへのアクセス手順
では、どのようにして指定のアドレスにアクセスをしているのか見てみましょう。これは大きく2つの文に分かれます。1つはアクセスしてレスポンスを取得する処理、もう 1つはレスポンスから状態をチェックする処理です。

■ レスポンスの取得 
```
$response = $this->get('/');
```

まず、指定のアドレスにGETアクセスし、Responseインスタンスを取得します。これは「get」メソッドで行えます。引数にはアクセスするアドレスを指定します。
同様に、「post」「put」「patch」「delete」といったメソッドも用意されています。使い方 はいずれも同じです。


アクセスしたステータスを調べる 
```
$response->assertStatus(200);
```

アクセスの状況は、レスポンスのステータスコードを知ればわかります。それをチェックするのが「assertStatus」です。引数に指定したステータスコードかどうかをチェックします。正常にアクセスできた場合は、200になります。


### 認証が必要なページへのアクセス
/helloへのアクセスでは、ステータスコードが「302」かどうかチェックしています。 302は、「ページは存在する(が、アクセスできない)」ことを示す番号です。普通にアクセスすると、認証が必要なページは302になります。  
ここでは、認証してアクセスする処理も用意してあります。これはアクセスの際に、 ログイン情報を追加しておくのです。 まず、ログインするUserモデルのインスタンスを作成します。
```
$user = factory (User::class)->create();
```

モデルの作成は、**factory**を使います。引数にモデルのクラスを指定して実行し、更に **create**メソッドを呼び出します。これで指定のモデルが作成されます。

このモデルの作成は、先にModelFactory.phpで用意しておいた**$factory->define**のクロージャによって得られた値を元にインスタンス生成が行われています。
```
$response = $this->actingAs($user)->get('/hello');
```

作成されたUserインスタンスを「actingAs」というメソッドの引数に指定し、更にgetを 呼び出して/helloにアクセスします。このように、**$this->actingAs->get**と呼び出すことで、指定のUserでログインした状態でアクセスすることができます。このとき、Userイ ンスタンスに保管されている値がデータベーステーブルに登録済みであるかどうかは問いません。登録されていない値を設定されたUserインスタンスであっても、ログインし アクセスすることができます。

最後に、ページのないアドレスにアクセスして、結果が「404」となるのも確認してい ます。ページが見つからない場合は、このようにステータスコードは404が返されます。

## データベースをテストする
データベースのテストについても行ってみましょう。HelloTestクラスを以下のように書き換えて、テストを実行してみて下さい。

<p class="tmp list"><span>リスト7</span>HelloTest.php</p>
```
// use App\User;
// use App\Customer;　を追記

class HelloTest extends TestCase
{
   use DatabaseMigrations;

   public function testHello()
   {
       // ダミーで利用するデータ
       factory(User::class)->create([
           'name' => 'AAA',
           'email' => 'BBB@CCC.COM',
           'password' => 'ABCABC',
       ]);
       factory(User::class, 10)->create();

       $this->assertDatabaseHas('users', [
           'name' => 'AAA',
           'email' => 'BBB@CCC.COM',
           'password' => 'ABCABC',
       ]);

       // ダミーで利用するデータ
       factory(Person::class)->create([
           'name' => 'XXX',
           'mail' => 'YYY@ZZZ.COM',
           'age' => 123,
       ]);
       factory(Person::class, 10)->create();

       $this->assertDatabaseHas('people', [
           'name' => 'XXX',
           'mail' => 'YYY@ZZZ.COM',
           'age' => 123,
       ]);

   }
}
```


### マイグレーションについて
データベースを利用する場合、注意しておきたいのが「マイグレーション」です。データベースに、必要なテーブルを作成し、必要に応じて値を保存する。そして使い終わっ たら元の状態に戻す。テストの際にはこうした作業を行う必要があります。「テストなんだから別にそのままでいいのでは?」と思うかもしれませんが、前のテストの値が残っていたりすると、次のテストに影響を与えることもあります。テスト終了時には、テスト前の状態に戻しておく必要があるのです。

それを行っているのが、クラスの最初の部分に書かれている、この文です。
```
use Database Migrations;
```
これは、実は先ほどの指定アドレスにアクセスするテストのときにも記述してありました。このuse文により、DatabaseMigrationsというクラスが機能するようになります。
これは、スタート前にマイグレーションを実行し、テスト終了後にはロールバックして初期状態に戻す、という作業を自動で行ってくれるのです。つまり、この1文さえ書いてあれば、データベースのマイグレーションやロールバックは考えなくてよいのです。

### モデルの作成
モデルの作成は、既にやりました。factory->createでレコードを新たに作り、保存することができました。が、単にcreateするだけだと、ModelFactoryに用意した形でレコードが保存されます。

ここでは、あらかじめこちらで指定したレコードを1つ保存しておき、そのレコードの有無をチェックしています。このように、指定した値でレコードを保存させたい場合 は、createの引数に連想配列で値を用意しておきます。

```
factory(User::class)->create([
    'name' => 'AAA',
    'email' => 'BBBaccc.com',
    'password' => 'ABCABC',
]);
```
ここでは、Userにname、email、passwordの値を指定してレコードを保存しています。

すべての項目を用意する必要はありません。変更したい項目だけを用意すれば、それ以外はModelFactoryに用意したやり方で値が設定されます。  
また、レコードを多数作成したい場合もあるでしょう。この場合は、factoryの第2引数に、作成するインスタンス数を指定してやります。
```
factory (User::class, 10)->create();
```
これで、Userモデルを10個生成し、保存することができます。多数のダミーレコードを生成したい場合は、これで数百数千のレコードを自動的に生成することができます。

## ユニットテスト以外のテスト
これで、基本的なコントローラやモデルの動作確認は一通りできるようになります。 が、これがLaravelのテストのすべてというわけではありません。

Laravelには、「ブラウザテスト」といって、Webブラウザから実際にアクセスして動作 を確認するテスト機能も用意されています。また、アプリケーションの一部をモック(本物を擬似的に再現するプログラム)して動作をチェックする機能もあります。

ユニットテストは、テストの基本中の基本ですが、これがすべてというわけではありません。一通りユニットテストが使えるようになったら、「ブラウザテスト」「モック」といったものについても調べてみるとよいでしょう。





