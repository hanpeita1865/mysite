*[page-title]:Drag & Drop

参考サイト
: [HTML5 Drag and Drop APIの使用](https://web.dev/i18n/ja/drag-and-drop/)
: [JavaScriptを使って要素をドラッグ＆ドロップで移動](https://q-az.net/elements-drag-and-drop/)←圭吾さんより

Drag & Drop API（以降、DnDと呼びます）は、ページ内の要素をドラッグで動かし、ほかの場所に移動させたり、ブラウザ外からファイルをページにドロップしたりといった操作を可能にするHTML5のAPIです。

次のような機能を実装することができます。

* 要素の順番や位置を入れ替える
* ローカルにある画像やテキストをブラウザにドロップして読み込む

## イベントの種類 ##{.h-type2}

|イベント名 |	発生するタイミング|
| ------- | ----------------- |
|**dragstart** |ドラッグ開始時|
|**drag** |	ドラッグしている間|
|**dragend** |ドラッグ終了時|
|**dragenter** |ドラッグしている要素がドロップ領域に入ったとき|
|**dragover** |ドラッグしている要素がドロップ領域にある間|
|**dragleave** |ドラッグしている要素がドロップ領域から出たとき|
|**drop** |ドラッグしている要素がドロップ領域にドロップされたとき|

<div class="exp">
	<p class="tmp"><span>例1</span>drag&dropイベントをコンソールで確認</p>
	緑のボックス（#box）をクリックしてドラッグ、ドロップを行うと、コンソールにイベント名が表示されます。<br>
	<a href="sample/sample1(console)/" target="_blank">新規タブ</a>
</div>

<div class="exp">
	<p class="tmp"><span>例2</span>drag&dropイベントをコンソールで確認</p>
	画像をドラッグ、ドロップを行うと、コンソールにイベント名が表示されます。<br>
	<a href="sample/sample2(eventcheck)/" target="_blank">新規タブ</a>
</div>

※ドラッグとドロップの操作はセットで扱うことが多いですが、イベント「drop」は「dragover」のデフォルトの挙動が有効になっているときは発生しないため注意が必要です。  
イベント「drop」をイベントリスナーに登録するときは、「dragover」に対してpreventDefaultメソッドでデフォルトの挙動を無効にします。

<p class="lang">JS</p>
```
window.addEventListener('DOMContentLoaded', function () {

	document.addEventListener('drag', function (e) {
		console.log('drag');
	});

	document.addEventListener('dragend', function (e) {
		console.log('dragend');
	});

	document.addEventListener('dragenter', function (e) {
		console.log('dragenter');
	});

	document.addEventListener('dragexit', function (e) {
		console.log('dragexit');
	});

	document.addEventListener('dragleave', function (e) {
		console.log('dragleave');
	});

	document.addEventListener('dragover', function (e) {
		e.preventDefault();
		console.log('dragover');
	});

	document.addEventListener('dragstart', function (e) {
		console.log('dragstart');
	});

	document.addEventListener('drop', function (e) {
		e.preventDefault();
		console.log('drop');
	});
});
	```

<div class="exp">
	<p class="tmp"><span>例</span>drag&dropイベント</p>
	緑のボックス（#box）をドラッグすると、ウサギのイメージ画像が表示される。青のボックスでは、表示されない。
		<a href="sample/sample5(DnD)/" target="_blank">新規タブ</a>
<iframe width="100%" height="250" src="sample/sample5(DnD)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">HTML</p>
```
<div>  
<div id="box" class="box green" draggable="true"></div>
	<div class="box blue" draggable="true"></div> 
</div>
```

<p class="lang">JS</p>
```
var dragImage = document.createElement('img');//img要素を作成
dragImage.src = 'image/0-01.png'; //ドラッグしてるときのイメージ画像を設定

$('#box').on('dragstart', onDragStart);//#boxのドラッグを開始したときに、作成したonDragStart関数を行う

function onDragStart(e) {
		//DataTrasnferオブジェクトにidを設定
		e.originalEvent.dataTransfer.setData('text', this.id);
		//DataTrasnferオブジェクトにイメージを設定
		e.originalEvent.dataTransfer.setDragImage(dragImage, 40, 40);
}
```
		
<div class="exp">
	<p class="tmp"><span>例</span></p>
	<https://q-az.net/elements-drag-and-drop/>より参照（記事は2016と古いです）<br>
	要素をDrag&Dropを行うと、ドロップした位置に配置されます。
		<a href="sample/sample2(three_colorbox)/" target="_blank">新規タブ</a>
<iframe width="100%" height="350" src="//jsfiddle.net/hirao/or7djkbg/embedded/result,html,js,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>