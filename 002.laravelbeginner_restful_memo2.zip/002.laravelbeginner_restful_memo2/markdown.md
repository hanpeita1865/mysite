*[page-title]:リソースコントローラメモ2（認証と紐づける）

参考サイト
: [初心者でもLaravelのユーザー認証が使えるようになる解説](https://rakuraku-engineer.com/posts/user-auth/)

## Laravelの認証方法の種類
すべてのシナリオを認証する万能な方法はありませんが、それぞれの方法を知ることで、より良い判断ができます。Laravel9で導入された新機能により、認証モードを切り替える操作が非常に簡単になりました。


<span class="green">パスワードベース認証</span>
: パスワードは、ユーザー認証の初歩的な方法であり、未だ何千もの組織で使用されています。しかし、現在の開発現場では、明らかに時代遅れになりつつあります。<br>
サイト制作者は、複雑なパスワードの実装を徹底すると同時に、エンドユーザーの負担を最小限に抑えなければなりません。<br>
パスワード認証は極めて単純に動作します。ユーザーは、ユーザー名とパスワードを入力し、それがデータベースに保存されている登録情報と一致すれば、サーバーがリクエストを認証します。すると、ユーザーはあらかじめ定義された期間、リソースにアクセスすることができます。


<span class="red">トークンベース認証</span>
: この方法は、認証時、ユーザーに一意のトークンを発行するものです。<br>
・トークンを持つユーザーは、その有効期限が切れるまで関連リソースにアクセスすることができます。<br>
・トークンが有効な間、ユーザー名やパスワードが不要ですが、新たにトークンを取得する際には必要になります。<br>
・トークンは今日、様々な場面で使用されています。これはトークンがすべての認証データを含む、ステートレスなエンティティであるためです。<br>
・トークンの生成と検証を分離する方法があることで、高い柔軟性を確保することができます。


多要素認証　→今回は使う必要なし
: 多要素認証は、その名が示すとおり、少なくとも2つ以上の認証要素を組み合わせるもので、安全性を高めることができます。<br>
2つの要素のみを使用する二要素認証とは異なり、多要素認証では2つ以上の要素を使用できます。<br>
典型的な使用事例としては、まずパスワードを使用し、次にユーザーのスマートフォンに認証コードを送信します。多要素認証を導入する場合は、誤検知やネットワークの停止に注意が必要です。特に、事業規模を急速に拡大している場面では、大きな問題になる可能性があります。

参考サイト
: [初心者でもLaravelのユーザー認証が使えるようになる解説](https://rakuraku-engineer.com/posts/user-auth/)

### ログイン関連ページ（テンプレート）

![](upload/ログイン関連のページ表まとめ.png)

view/auth内のファイルは、下記になります。
![](upload/views_auth内ファイル.png)

### ログイン関連コントローラー

![](upload/認証関連コントローラー表まとめ.png)

Controller/Auth内のファイルは、下記になります。
![](upload/Controller_Auth内ファイル.png)


### ルーティング

以下のルーティングが追加されています。

<p class="lang">routes/web.php</p>
```
// ログイン関連のページのルーティング
// これ1行で全ページ（ホーム画面以外）のルーティングが完了する
Auth::routes();

// ログインのホーム画面のルーティング
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
```
![](upload/これ1行でホーム以外認証がかかる.png)

※上記ではホーム画面以外は認証がかかるとあるが、普通に開ける。なぜ?   
例）<http://localhost:6002/sample>

ただし、次のようにauthのミドルウェアの中に入れると認証がかかります。
![](upload/authミドルウェア内にルート記述.png)

<http://localhost:6002/login>にアクセスすると、認証画面が表示される。
![](upload/認証が面が表示されます.png)


### authとguestとは

<span class="red">authの中身</span>
: auth（\Illuminate\Auth\Middleware\Authenticate::class）<br>
<span class="marker-yellow50 bold">特定のルートへのアクセスに対してユーザー認証を行う機能</span>

<span class="blue">guestの中身</span>
: guest（\App\Http\Middleware\RedirectIfAuthenticated::class）<br>
<span class="marker-blue50 bold">認証済かチェックし、認証済であれば /home にリダイレクトする機能</span>


### ログイン制限をかける

ログインしないとアクセスできないようにする方法

* ルーティングにミドルウェアを設定するだけ
* ミドルウェアを知らなくても簡単に使える。
* 具体的には<span class="red">->middleware('auth')</span>と書くだけでOK

<p class="lang">例  routes/web.php</p>
```
// 任意のルーティングに ->middleware('auth') を付け足す！
// →「ドメイン名/hoge」にアクセス制限がかかる！
Route::get('/hoge', 'App\Http\Controllers\TestController@hoge')->middleware('auth');
```
【補足】未ログイン制限をかける。反対にゲストユーザーのみアクセス可能にすることもできる。<br>
「新規登録画面」などで有用！

<p class="lang">例　routes/web.php</p>
```
// 任意のルーティングに ->middleware('guest') を付け足す！
// →「ドメイン名/hoge」にアクセス制限がかかる！
Route::get('/hoge', 'App\Http\Controllers\TestController@hoge')->middleware('guest');
```

※これだけでログイン制限がかかる。<br>
未ログインのときはログインページにリダイレクトしてくれる！


### 全ページにログイン制限をかける

* 前述の方法では1ページずつログイン制限をかけないといけない* 
* 特定のコントローラーのページすべてにログイン制限をかけることができる！
* コンストラクタで<span class="red">$this->middleware('auth')</span>を設定するだけでOK

<p class="lang">例：app/Http/Controllers/TestController.php</p>
```
class TestController extends Controller
{
	public function __construct()
    {
        // アクセス制限
        // exceptを追記すると、index, show, topらは制限から除かれる
        $this->middleware('auth')->except(['index', 'show', 'top']);
    }
}
```

※<span class="bold blue">except(…)</span>で対象外のページを指定することもできる！→引数はアクションメソッド名


## 認証と管理画面を紐づける

My参考書「ログイン機能をつぶやきアプリと連携する」ページより
: http://localhost:7001/from_now_slim/public/pages/laravel9book/laravel9book_chap3/laravel9book_chap3-2/#chapter6

1.	ログインしているユーザーのみ書き込みができるようにする
2.	ログインしているユーザーの情報をつぶやきとともに保存する
3.	自分がつぶやいたものだけを編集、削除できるようにする

### 登録・ログイン後のページの設定を変更する

下記の管理画面一覧ぺージに遷移させるようにします。  
http://localhost:6002/rest

デフォルトでは登録・ログイン後に「/dashboard」のパスに遷移するようになっているので、アプリのトップページに遷移できるように変更します。

![](upload/デフォルトdashboardページ.png "app/Providers/RouteServiceProvider.php（デフォルト）"){.fig-top .pr-5}
↓　restページに設定変更
![](upload/HOMEをrestページに設定変更.png)

これでログインすると、管理一覧画面（<http://localhost:6002/rest>）に遷移されます。
![](upload/restトップページ表示.png){.photo-border}


### restdataテーブルに「user_id」のカラムを設定

誰が投稿したのかわかるように、restdataテーブルにユーザーIDを追加していきます。
次のartisanコマンドを使ってマイグレーションファイルを作成します。

<p class="tmp cmd"><span>コマンド</span>マイグレーションファイル作成</p>
```
php artisan make:migration add_user_id_to_restdata
```

作成されたマイグレーションファイルに追記していきます。

<p class="tmp list"><span>リスト2-1</span>2024_06_20_013228_add_user_id_to_restdata</p>
```
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('restdata', function (Blueprint $table) {
            $table->unsignedBigInteger('user_id')->after('id');//追記

            // usersテーブルのidカラムにuser_idカラムを関連付けます。
            $table->foreign('user_id')->references('id')->on('users');//追記
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('restdata', function (Blueprint $table) {
            $table->dropForeign('restdata_user_id_foreign');//追記
            $table->dropColumn('user_id');//追記
        });
    }
};
```

上記の「<span class="red">$table->foreign('user_id')->references('id')->on('users');</span>」のコードでrestdataテーブルのuser_idとusersテーブルのidを関連付けられます。

add_user_id_to_restdataファイルのマイグレーションを実行します。
<p class="tmp cmd"><span>コマンド</span>add_user_id_to_restdataファイルのマイグレーション</p>
```
php artisan migrate --path=/database/migrations/2024_06_20_013228_add_user_id_to_restdata.php
```

restdataテーブルのidカラムの後にuser_idカラムが追加され、usersテーブルのidと関連付けられました。

<div markdown="1" class="d-flex">
![](upload/restdataテーブル構造リスト.png "restdataテーブル構造リスト"){.fig-top .photo-border}
![](upload/usersテーブル構造リスト.png "usersテーブル構造リスト"){.fig-top .photo-border}
</div>

restdataテーブル用シーダーファイルにuser_idを追加しておきます。

<p class="tmp list"><span>リスト2-2</span>ResrdataTableSeeder.php</p>
```
・・・
class RestdataTableSeeder extends Seeder
{
    public function run(): void
    {
        $param = [
            'user_id' => 1,
            'message' => 'Google Japan',
            'url' => 'https://www.google.co.jp',
        ];
        $restdata = new Restdata;
        $restdata->fill($param)->save();
        $param = [
            'user_id' => 1,
            'message' => 'Yahoo Japan',
            'url' => 'https://www.yahoo.co.jp',
        ];
        $restdata = new Restdata;
        $restdata->fill($param)->save();
        $param = [
            'user_id' => 1,
            'message' => 'MSN Japan',
            'url' => 'http://www.msn.com/ja-jp',
        ];
        $restdata = new Restdata;
        $restdata->fill($param)->save();
    }
}
・・・
```

restdataテーブルを空にして、再度シーディングを実行すると、次のようデータが挿入されます。
<p class="tmp cmd"><span>コマンド</span>シーディング実行</p>
```
php artisan db:seed --class=RestdataTableSeeder
```
![](upload/restdataにuser_idを追加してシーディング.png){.photo-border}


### restdataテーブルにユーザーのIDを保存する

新規登録したユーザのIDをrestdataテーブルに保存していきます。  
ユーザー情報については、Requestクラスから取得することができます。

まず、フォームリクエストを作成します。
<p class="tmp cmd"><span>コマンド</span>フォームリクエスト作成</p>
```
php artisan make:request Rest/CreateRequest
```
![](upload/RestのCreateRequest作成実行.png)

リクエストのファイルが作成されました。
![](upload/RestのCreateRequestファイルが作成されました.png){.photo-border}

下記のようにコードを追記します。
C:\xampp\htdocs\laravelapp_validate\app\Http\Requests\Rest\CreateRequest.php

<p class="tmp list"><span>リスト2-3</span>app/Http/Requests/Rest/CreateRequest.php</p>
```
<?php

namespace App\Http\Requests\Rest;

use Illuminate\Foundation\Http\FormRequest;

class CreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;//「true」に変更
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            //
        ];
    }

    //追加
    // Requestクラスのuser関数で今自分がログインしているユーザーが取得できる
    public function userId(): int {
        return $this->user()->id;
    }

    public function restdata(): string {
        return $this->input('restdata');
    }
}
```


「authorize」と「rules」の2つのメソッドを持っていて、「authorizeメソッド」では ユーザー情報を判別して、このリクエストを認証できるか判定させることができます。 初期値がfalseになっているので、まずは誰でもリクエストできるようにtrueに変更しましょう。

「rulesメソッド」ではリクエストされる値を検証するための設定を記述します。今は設定なしにしています。

最後の方に、<span class="red">ログインしているユーザーが取得できる関数を追加</span>しています。

Requestクラスのuser 関数は今ログインしているユーザーの情報を返してくれます。ガードのところで説明しましたが、今はwebガードがデフォルトで設定されており、providerの設定からusersテーブルの情報をEloquentモデルにして返してくれるようになっています。  
こちらのidを、つぶやきを保存するときの他の情報と一緒に保存します。


### クラスベースコンポーネントを作る

編集と削除のコンポーネントを「クラスベースコンポーネント」で作成します。  
クラスベースコンポーネントは匿名コンポーネントと異なり、artisanコマンドから作成できます。

<p class="tmp cmd"><span>コマンド</span>クラスベースコンポーネント作成</p>
```
php artisan make:component Rest/Options
```

![](upload/Optionsコマンド実行.png)
Options.phpが作成されました。
![](upload/Options.phpが作成されました.png){.photo-border}

次のように修正します。

<p class="tmp list"><span>リスト2-4</span>app/View/Components/Rest/Options.php</p>
```
<?php

namespace App\View\Components\Rest;

use Illuminate\View\Component;

class Options extends Component {
    private int $restdataId;//追加
    private int $userId;//追加

    public function __construct(int $restdataId, int $userId) {//「int $restdataId, int $userId」の引数を追加
        $this->restdataId = $restdataId;//追加
        $this->userId = $userId;//追加
    }

    public function render() {
        return view('components.rest.options')
            //追加				
            ->with('resttId', $this->restdataId)
            ->with('myRest', \Illuminate\Support\Facades\Auth::id() === $this->userId);
    }
}
```

options.blade.phpも作成されました。
![](upload/options.blade.phpが作成されました.png){.photo-border}

テーブルは次のようになっています。
![](upload/restdataテーブルのデータ.png "restdataテーブルデータ"){.photo-border .fig-top}
![](upload/usersテーブルのデータ.png "usersテーブルデータ"){.photo-border .fig-top}

試しにoptions.blade.phpを下記に修正してみます。
```
@if($myRest)
<div>登録した記事です。</div>
@endif
```

<p class="tmp list"><span>リスト2-5</span>rest/index.blade.php</p>
```
･･･
<tr>
    <td>
    <x-rest.options :restId="$item->id" :userId="$item->user_id"></x-rest.options><!--ここにoption.blade.phpが挿入される-->
        <form action="/rest/{{{$item->id}}}" method="post">
            @csrf
            @method('DELETE')
            <input class="btn-delete" type="submit" value="削除">
        </form>
    </td>
    <td>
        <form action="/rest/{{{$item->id}}}/edit" method="get">
            <input class="btn-exit" type="submit" value="編集">
        </form>
    </td>
</tr>
@endforeach
･･･
```

これでtanakaでログインして管理一覧を表示してみると、tanakaが登録記事だけに「登録した記事です。」が付くようになります。
![](upload/登録した記事ですが付く.png){.photo-border}


### dashboardページにあるヘッダーを設定する。

dashboardページのような下記のヘッダーを登録・編集画面に設定します。
![](upload/Dashboardにあるヘッダー.png){.photo-border}

<p class="tmp list"><span>リスト2-6</span>views/rest/index.blade.php</p>
```
<!--追加-->
<x-app-layout>
    <x-slot name="header">
    <form action="/rest/create" method="get">
        <input type="submit" value="新規登録">
    </form>
    </x-slot>

    @if (Route::has('login'))
        <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
            @auth
                <!--<a href="{{ url('/dashboard') }}" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">登録・編集画面</a>-->
            @else
                <a href="{{ route('login') }}" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>

                @if (Route::has('register'))
                    <a href="{{ route('register') }}" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                @endif
            @endauth
        </div>
    @endif
		
	・・・・
	
</x-app-layout>
```



## ログアウト後のページを設定

参考サイト
: [ログアウト後のリダイレクト先を変更する](https://rakuraku-engineer.com/posts/user-auth/)

デフォルトのログアウト処理（<span class="red">/logout</span>）を使うと、自動的にトップページにリダイレクトされます。  

### リダイレクト先をトップページ以外に設定する方法

コントローラーにメソッドを追加するだけでOK

<p class="tmp list"><span>リスト3-1</span>app/Http/Controllers/Auth/LoginController.php</p>
```
class LoginController extends Controller
{
		// ログアウト後「ドメイン名/hoge」に遷移する 追加
		protected function loggedOut()
    {
        return redirect('/hoge');
    }
}
```

一度ログインしてからログアウトします。
![](upload/LogOutをクリック.png){.photo-border}

設定変更した「hoge」ページに遷移します。
![](upload/ログアウト後hogeページに遷移.png){.photo-border}



または、下記のファイルの箇所を変更しても遷移先を変えられます。

![](upload/ログアウト後の遷移先変更.png "app/Http/Controllers/Auth/AuthenticatedSessionController.php"){.fig-top}


## 新規登録を修正（紐づけ後）

### 仕組み

CreateRequest.phpの下記のメソッドからユーザーIDを取得
![](upload/CreateRequestからユーザーID取得.png "app/Http/Requests/Rest/CreateRequest.php"){.fig-top}

$restdata->user_id = $request->userId(); で$restsataにユーザーIDを格納。  
画像保存があれば$pathに画像パスを格納。画像保存なければ、$pathは空にする。  
「->with('rest',$restdata)」を追加して、テンプレートにユーザーIDを送る。
![](upload/RestappControllerの新規登録を修正.png "app/Http/Controllers/RestappController.php"){.fig-top}

create.blade.php  コントローラーから送信されたユーザーIDをinputのvalueに格納。
送信ボタンを押すと、上記のstoreメソッドで処理される。
![](upload/テンプレートユーザーID追加.png "resources/views/rest/create.blade.php"){.fig-top}
input name="user_id"のvalueに挿入される。
![](upload/input_user_idの値.png  "図　新規登録フォームコード"){.photo-border}
sendボタンを押す。
![](upload/createの入力フォーム.png "図　新規登録フォーム"){.photo-border}
新規登録できた。
![](upload/新規登録できた.png "図　管理一覧ページ"){.photo-border}


## ロゴやボタンの変更

### ログイン画面のロゴ

下記のログイン画面にあるロゴを変更する場合、「resources/views/components/application-logo.blade.php」のコードを他のSVGのコードに変更します。
![](upload/ログインのロゴ.png)

<p class="lang">resources/views/components/application-logo.blade.php</p>
```
<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
    <path d="M305.8 81.125C305.77 80.995 305.69 80.885 305.65 80.755C305.56 80.525 305.49 80.285 305.37 80.075C305.29 79.935 305.17 79.815 305.07 79.685C304.94 79.515 304.83 79.325 304.68 79.175C304.55 79.045 304.39 78.955 304.25 78.845C304.09 78.715 303.95 78.575 303.77 78.475L251.32 48.275C249.97 47.495 248.31 47.495 246.96 48.275L194.51 78.475C194.33 78.575 194.19 78.725 194.03 78.845C193.89 78.955 193.73 79.045 193.6 79.175C193.45 79.325 193.34 79.515 193.21 79.685C193.11 79.815 192.99 79.935 192.91 80.075C192.79 80.285 192.71 80.525 192.63 80.755C192.58 80.875 192.51 80.995 192.48 81.125C192.38 81.495 192.33 81.875 192.33 82.265V139.625L148.62 164.795V52.575C148.62 52.185 148.57 51.805 148.47 51.435C148.44 51.305 148.36 51.195 148.32 51.065C148.23 50.835 148.16 50.595 148.04 50.385C147.96 50.245 147.84 50.125 147.74 49.995C147.61 49.825 147.5 49.635 147.35 49.485C147.22 49.355 147.06 49.265 146.92 49.155C146.76 49.025 146.62 48.885 146.44 48.785L93.99 18.585C92.64 17.805 90.98 17.805 89.63 18.585L37.18 48.785C37 48.885 36.86 49.035 36.7 49.155C36.56 49.265 36.4 49.355 36.27 49.485C36.12 49.635 36.01 49.825 35.88 49.995C35.78 50.125 35.66 50.245 35.58 50.385C35.46 50.595 35.38 50.835 35.3 51.065C35.25 51.185 35.18 51.305 35.15 51.435C35.05 51.805 35 52.185 35 52.575V232.235C35 233.795 35.84 235.245 37.19 236.025L142.1 296.425C142.33 296.555 142.58 296.635 142.82 296.725C142.93 296.765 143.04 296.835 143.16 296.865C143.53 296.965 143.9 297.015 144.28 297.015C144.66 297.015 145.03 296.965 145.4 296.865C145.5 296.835 145.59 296.775 145.69 296.745C145.95 296.655 146.21 296.565 146.45 296.435L251.36 236.035C252.72 235.255 253.55 233.815 253.55 232.245V174.885L303.81 145.945C305.17 145.165 306 143.725 306 142.155V82.265C305.95 81.875 305.89 81.495 305.8 81.125ZM144.2 227.205L100.57 202.515L146.39 176.135L196.66 147.195L240.33 172.335L208.29 190.625L144.2 227.205ZM244.75 114.995V164.795L226.39 154.225L201.03 139.625V89.825L219.39 100.395L244.75 114.995ZM249.12 57.105L292.81 82.265L249.12 107.425L205.43 82.265L249.12 57.105ZM114.49 184.425L96.13 194.995V85.305L121.49 70.705L139.85 60.135V169.815L114.49 184.425ZM91.76 27.425L135.45 52.585L91.76 77.745L48.07 52.585L91.76 27.425ZM43.67 60.135L62.03 70.705L87.39 85.305V202.545V202.555V202.565C87.39 202.735 87.44 202.895 87.46 203.055C87.49 203.265 87.49 203.485 87.55 203.695V203.705C87.6 203.875 87.69 204.035 87.76 204.195C87.84 204.375 87.89 204.575 87.99 204.745C87.99 204.745 87.99 204.755 88 204.755C88.09 204.905 88.22 205.035 88.33 205.175C88.45 205.335 88.55 205.495 88.69 205.635L88.7 205.645C88.82 205.765 88.98 205.855 89.12 205.965C89.28 206.085 89.42 206.225 89.59 206.325C89.6 206.325 89.6 206.325 89.61 206.335C89.62 206.335 89.62 206.345 89.63 206.345L139.87 234.775V285.065L43.67 229.705V60.135ZM244.75 229.705L148.58 285.075V234.775L219.8 194.115L244.75 179.875V229.705ZM297.2 139.625L253.49 164.795V114.995L278.85 100.395L297.21 89.825V139.625H297.2Z"/>
</svg>
```

### ボタンの変更

既存のボタンは、次のようになっています。
![](upload/ログインボタンpng.png)

<p class="lang">resources\views\components\primary-button.blade.php</p>
```
<button {{ $attributes->merge(['type' => 'submit', 'class' => 'inline-flex items-center px-4 py-2 bg-gray-800 dark:bg-gray-200 border border-transparent rounded-md font-semibold text-xs text-white dark:text-gray-800 uppercase tracking-widest hover:bg-gray-700 dark:hover:bg-white focus:bg-gray-700 dark:focus:bg-white active:bg-gray-900 dark:active:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150']) }}>
    {{ $slot }}
</button>
```


## 管理者権限を設定

[Laravel Permissionを使用して簡単に権限を付与する](https://qiita.com/MINORI_Ta/items/0c0299c49f3d946f1223)

LaravelのSpatie/Permissionパッケージは、ユーザー（User）と役割（Role）を紐づけるため（もちろん違うテーブルでも可能です）の中間テーブルを管理するライブラリです。このパッケージを使用することで、Laravelアプリケーションの権限管理機能を簡単に実装することができます。

-Laravel Permissionでできること-
* ユーザーに役割を割り当てる（UserとRoleの紐づけ）
* ユーザーが特定の役割を持っているかどうかのチェック
* 役割に基づいたアクセス制御の実装
* 権限の管理（権限の作成、削除、編集など）

※今回はユーザー認証にLaravel Breezeを利用しています。前提としてLaravelプロジェクトの立ち上げ、Breezeのインストール、データベース接続が完了としていることとします。

Laravel Permissionライブラリをインストールします。

<p class="tmp cmd"><span>コマンド</span>Laravel Permissionインストール</p>
```
composer require spatie/laravel-permiss
```

インストールできました。
![](upload/LaravelPermissionインストール.png)

サービスプロバイダの登録をします。ドキュメントでは自動的に登録されると書いてるようですが、手動で記述しました。

<p class="lang">config/app.php</p>
```
'providers' => [
    // ...省略
    Spatie\Permission\PermissionServiceProvider::class,
];
```
![](upload/Spatie_permission.png)

プロバイダを登録したら以下のコマンドを実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
```
![](upload/PermissionServiceProvider.png)

configpermission.phpとmigrations/xxx_xx_xx_xxxxxx_create_permission_tables.phpが作成されました。
![](upload/permission.php作成.png)
![](upload/permission_tables作成.png)

ここで設定を反映させるためキャッシュをクリアしておきましょう。
<p class="tmp cmd"><span>コマンド</span>キャッシュクリア</p>
```
php artisan config:clear
```
![](upload/キャッシュクリア.png)

permissionテーブルを作成するためにマイグレーションを実行します。
```
php artisan migrate --path=/database/migrations/2024_06_29_023940_create_permission_tables.php
```
rolesテーブルは自動生成されます。
![](upload/role_has_permission.png){.photo-border}

roleを紐づけるUserモデルに以下を記載します。

<p class="tmp list"><span>リスト</span>App/Models/User.php</p>
```
use Spatie\Permission\Traits\HasRoles; // 追加

class User extends Authenticatable
{

    use HasRoles; // 追加

    // ...省略
}
```

これでLaravel Permissionを使用する準備は整いました。

### 役割と権限の作成
ここで間違えてはいけないのが、Role(役割)　と　Permission(権限)　です。  
Permission(権限)は直接ユーザーではなくRole(役割)に与えるのが推奨されます。

例を挙げます。  
管理者と利用者というRole(役割)があります。管理者は『<span class="bold green">利用者を登録する</span>』というPermission(権限)があります。利用者にはその権限がありません。

登録の担当がAさんからBさんに変わったとします。その時にBさんに直接権限を付与することもできます。が、Aさんから権限を剥奪するという手間がかかります。また、間違ってCさんに権限を与えてしまう可能性もあります。  
なので管理者という役割に権限を与えて、管理者をAさんからBさんに変更する方が間違いが少ないです。

ということで、<span class="red">Role(役割)</span>に<span class="red">Permission(権限)</span>を与えていきます。  
今回はマスタデータ用のSeederを作成します。
<p class="tmp cmd"><span>コマンド</span>Seeder作成</p>
```
php artisan make:seeder MasterDatabaseSeeder
```
![](upload/MasterDatabaseSeeder.png){.photo-border}


作成したseederファイルを記述していきます。

<p class="tmp list"><span>リスト</span>database/seeders/MasterDatabaseSeeder.php</p>
```
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role; // 追加
use Spatie\Permission\Models\Permission; // 追加
use App\Models\User; // 追加

class MasterDatabaseSeeder extends Seeder
{

    public function run()
    {
        // ユーザー作成
        $president = User::create([
            'name' => '社長',
            'email' => 'president@sample.com',
            'password' => bcrypt('password'),
            ]);

        User::create([
            'name' => '社員1',
            'email' => 'gest@sample.com',
            'password' => bcrypt('password'),
            ]);


        // ロール作成
        $adminRole = Role::create(['name' => 'admin']);

        // 権限作成
        $registerPermission = Permission::create(['name' => 'register']);


        // admin役割にregister権限を付与
        $adminRole->givePermissionTo($registerPermission);

        // 社長にadminを割り当て
        $president->assignRole($adminRole);
    }
}
```

<p class="tmp cmd"><span>コマンド</span>シーダー実行</p>
```
php artisan db:seed --class=MasterDatabaseSeeder
```
![](upload/MasterDataSeeder実行.png){.photo-border}
ここでは、

<div markdown="1" class="red">
* 社長と社員というユーザー
* admin(管理者) というRole(役割)
* register(利用者登録) というPermission(権限)
</div>

を作成し、

<div markdown="1" class="blue">
* admin(管理者) に register(利用者登録) を付与
* 社長に admin(管理者) を割り当て
</div>

しています。

では権限が付与できたか確認してみましょう！  
dashboardのページを管理者用として、次のように書き換えてみます。
<p class="tmp list"><span>リスト</span>resources/views/dashboard.blade.php</p>
```
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('管理者用ページ') }}        
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    
                @can('register')
                <p>register権限を持つ人だけが見れるよ</p>
                @else
                <p>閲覧できません</p>
                @endcan
                
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
```

「社員」でログインすると、閲覧できませんが表示されます。
![](upload/管理者用ページ社員.png)
権限を持つ「社長」でログインすると、閲覧することができます。
![](upload/管理者用ページ社長.png)

コンポーネントを利用して、少し書き換えてみます。
<p class="tmp list"><span>リスト</span>dashboard.blade.php</p>
```
<x-app-layout>
･･･
                @can('register')
                 <x-register></x-register><!--変更-->
                @else
                <p>閲覧できません</p>
                @endcan
･･･
</x-app-layout>
```

「register/index.blade.php」を新規作成して、コードを追記します。
<p class="tmp list"><span>リスト</span>views/components/register/index.blade.php</p>
```
<p>register権限を持つ人だけが見れるよ</p>
```

※管理者権限を付与する場合、シーダーを実行して行っていますが、他の方法はあるのだろうか?