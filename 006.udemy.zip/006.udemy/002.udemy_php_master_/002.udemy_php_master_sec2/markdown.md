*[page-title]:セクション2（制御構造）


## 19. 「もしも」の条件で処理を分けよう-if構文

```
<?php
echo '数字を入力してください >';
$number = trim(fgets(STDIN));

// 10よりも大きいかを判断する
if ($number > 10) {
    echo '10よりも大きいです';    
} else {
    echo '10以下です';
}

// if ($number > 10):
//     echo '10よりも大きいです';
// else:
//     echo '10以下です';
// endif;
```

参考サイト
: [比較演算子](https://www.php.net/manual/ja/language.operators.comparison.php)


<div markdown="1" class="line-box">
##### 宇宙船演算子について

PHPの宇宙船演算子 ( <=> ) は、2つの値を比較し、結果を-1, 0, 1のいずれかで返す比較演算子です。左辺が右辺より小さい場合は-1、等しい場合は0、大きい場合は1を返します。

詳細:
: 機能:宇宙船演算子は、主に配列やオブジェクトのソート時に、複数の要素を比較する際に使用されます。﻿

構文:
: <<=>> (左辺 <=> 右辺)﻿

戻り値:
: 左辺が右辺より小さい場合: -1﻿
: 左辺と右辺が等しい場合: 0﻿
: 左辺が右辺より大きい場合: 1﻿

</div>
<p class="lang">例）宇宙船演算子</p>
```
$a = 5;
$b = 10;
$c = 5;

echo $a <=> $b; // 出力: -1
echo $a <=> $c; // 出力: 0
echo $b <=> $a; // 出力: 1
```

## 20. 複数の条件で判断しよう-elseif

```
<?php
echo '数字を入力してください >';
$number = trim(fgets(STDIN));

// 10よりも大きいかを判断する
// if ($number > 10) {
//     echo '10よりも大きいです';    
// } else {
//     if ($number == 10) {
//         echo '10です';
//     } else {
//         echo '10以下です';
//     }
// }

if ($number > 10) {
    echo '10よりも大きいです';
} elseif($number == 10) {
    echo '10です';
} elseif($number <= 0) {
    echo '0以下です';
} else {
    echo '10以下です';
}
```

ネストを使わない方がシンプルになります。

## 21. 条件を組み合わせよう-論理演算子

参考サイト
: [論理演算子](https://www.php.net/manual/ja/language.operators.logical.php)
: [演算子の優先順位](https://www.php.net/manual/ja/language.operators.precedence.php)

```
<?php
$gender = '男性';
$age = 21;

// if ($gender == '男性') {
//     if ($age == 20) {
//         echo '男性で20歳ですね？';
//     }
// }

// if ($gender == '男性' && $age == 20) {
//     echo '男性で20歳ですね？';
// }

// if ($gender == '男性' || $age == 20) {
//     echo '男性かまたは 20歳ですね？';
// }

// if ($gender == '男性' xor $age == 20) {
//     echo '20歳ではない男性か、20歳の女性ですね？';
// }

if ($gender == '男性' && ($age == 20 || $age == 21)) {
    echo '男性で、20歳か21歳ですね？';
}
```

<div markdown="1" class="line-box">
<span class="red">$a xor $b</span>	排他的論理和	
: $a または $b のどちらかが true で<span class="marker-yellow50">かつ</span>両方とも true でない場合に true
</div>

次のような場合は、falseになります。
```
<?php
$gender = '男性';
$age = 20;

if ($gender == '男性' xor $age == 20) {
    echo '20歳ではない男性か、20歳の女性ですね？';
}
```

## 22. or演算子(I))の注意点

「||」が入ると論理演算子がややこしくなります。

```
$gender = '女性';
$age = 21;

if($gender == '男性' && $age == 20 || $age == 21){
    echo '男性で、20歳か21歳ですね？';
}
```
上記のように演算子を書くと、「&&」が打ち消されて「||」のあとの$age == 21で判定されるので、男性で20才かまたは男性か女性の21才という条件になっています。  
そのためここでは、trueになります。

次のように括弧を付けると、男性で20才か21才という条件になり、falseになります。
```
$gender = '女性';
$age = 21;

if($gender == '男性' && ($age == 20 || $age == 21)){
    echo '男性で、20歳か21歳ですね？';
}
```

このように、括弧のなかが先に判断されます。


## 23. 2-5条件の応用テクニック

参考サイト
: [is_numeric](https://www.php.net/manual/ja/function.is-numeric.php)

```php
<?php
$number = 'abc';

// $numeric = is_numeric($number);

// if (is_numeric($number)) { // == trueを省略
//     echo '数字です';
// } else {
//     echo '数字ではありません';
// }

// if (!is_numeric($number)) {
//     echo '数字ではありません';
// }

// $one = 1;
// if ($one) { //  != 0が省略
//     echo '0以外です';
// }

$message = '';
if ($message) { // != ''が省略
    echo '文字列が代入されています';
}
```

## 24. [実践]和暦変換プログラムを作ろう

参考サイト
: [date](https://www.php.net/manual/ja/function.date.php)

```
<?php
echo '西暦を入力してください >';
$year = trim(fgets(STDIN));

if (is_numeric($year) && $year <= date('Y')) { // == trueを省略
    //echo '数字が入力されました';
    if ($year >= 2018) {
        echo '令和です';
    } elseif ($year >= 1988) {
        echo '平成です';
    } elseif ($year >= 1925) {
        echo '昭和です';
    } elseif ($year >= 1911) {
        echo '大正です';
    } elseif ($year >= 1867) {
        echo '明治です';
    } else {
        echo '明治よりも前です';
    }
} else {
    echo '今年よりも前の数字を入力してください';
}
```


## 25. 2-7変数の再代入とインクリメント·デクリメント

「$sum = $sum + 20;」は、「$sum <span class="bold red">+=</span> 20;」と書けます。  
他の変数再代入に、`-=`、`*=`、`/=`、などもあります。

```
<?php
$sum = 10 + 5;

// 変数の再代入
//$sum = $sum + 20;
$sum += 20;
$sum -= 5;
$sum *= 2;
$sum /= 3;

// インクリメント・デクリメント
//$sum = $sum + 1;
//$sum += 1;
$sum++; // インクリメント
$sum--; // デクリメント
//$sum**;　→存在しない
//$sum//;　→存在しない

echo $sum;
```






