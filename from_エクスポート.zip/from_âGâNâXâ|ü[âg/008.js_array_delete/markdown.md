*[page-title]:配列から値指定で要素削除する

参考サイト
: [JavaScriptで配列から値指定で要素削除する２つの方法](https://pisuke-code.com/js-remove-element-by-value/)

## 方法１．単体の値なら splice を使って要素削除

まずは値が１つの場合の削除について。  
これには Array.splice  を使うのが簡単でした。

※splice() メソッドは、 (in place で) 既存の要素を取り除いたり、置き換えたり、新しい要素を追加したりすることで、配列の内容を変更します。

<iframe src="https://paiza.io/projects/e/duoQc0l2FCH9xjPZdkDR1w?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

ただし 配列に重複値がないこと が前提です。  
もし複数値を削除するなら、次の方法もあります。


## 方法２．複数値なら filter を使って要素削除

もし複数値をまとめて削除したいなら・・・  
その場合は Array.filter  を使うのが確実です。

filter() メソッドは、与えられた関数によって実装されたテストに合格したすべての配列からなる新しい配列を生成します。
```
let newArray = arr.filter(callback(element[, index, [array]])[, thisArg])
```
callback 配列の各要素に対して実行するテスト関数です。この関数が true を返した要素は残され、false を返した要素は取り除かれます。

この関数を使えば値の一括削除が可能。  
あと重複値（ダブリ）があっても確実に削除できます。

<iframe src="https://paiza.io/projects/e/-u3xeOFPZDY-5wD8VVO9-g?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

