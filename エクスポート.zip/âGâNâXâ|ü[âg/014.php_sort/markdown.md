*[page-title]:配列を並べ替え

参考サイト
: [[PHP] 連想配列を並び替えする方法（キーでのソート、値でのソート、ソート順の独自定義）](https://www.yoheim.net/blog.php?q=20191103)
: [DBからの検索結果をPHPで並び替える（array_multisortの利用、昇順、降順、複数のソートキー、ユーザー定義ソート）](https://www.yoheim.net/blog.php?q=20191104)

## 今回説明に使うデータ
以下のような、配列の中に連想配列が入ったもの（=多次元配列）を使いたいと思います。
```
$fruits = [
  array('id' =>'01', 'name' => 'apple'),
  array('id' =>'02', 'name' => 'orange'),
  array('id' =>'03', 'name' => 'pinapple')
];
```
フルーツの一覧を、データベースから取得した時のデータ構造のイメージです。

## 任意のキーで、昇順や降順に並び替える

まずは、並び替えに使うキーを決めます。ここではid列の値で並び替えたいと思います。  
idの昇順や降順に並び替えるには、<span class="red">array_multisort()</span>を用いて実装します。

<div class="exp">
	<p class="tmp"><span>例1-1</span></p>
	昇順に並び替えています。
	<iframe src="https://paiza.io/projects/e/s7bvQw9BqfRMKFaMhQm-Qw?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例1-2</span></p>
	降順に並び替えています。
	<iframe src="https://paiza.io/projects/e/sesKd0kbBobaNfQIO38vmQ?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>
</div>



## 複数のキーを使って、並び替える

第1ソートキーをvolumeと第2ソートキーをeditionに設定して、並べ替えます。

<div class="exp">
	<p class="tmp"><span>例2-1</span></p>
	<iframe src="https://paiza.io/projects/e/DWLkW5sf9RfwXS36zxnSkA?theme=twilight" width="100%" height="900" scrolling="no" seamless="seamless"></iframe>
</div>
