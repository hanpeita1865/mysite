<?php
require 'database_access.php';

// $sql = $pdo->prepare('insert into message values(null, ?)');

// echo $_POST['msdata'];

// if($sql->execute([$_POST['msdata']])){
//     echo '追加に成功しました。';
// }else{
//     echo '追加に失敗しました。';
// }


$id = str_replace('check','',$_POST['id']);
$name = $_POST['name'];

if($_POST['check']=='true'){
    $check = $_POST['check'];//true
}else{
    $check = '';
}

$sql = $pdo->prepare('update member set absence=? where id=?');

if($sql->execute([$check, $id])){
    echo '更新に成功しました。';
}else{
    echo '更新に失敗しました。';
}

?>