*[page-title]:PHPの記述方法

ここではまずPHPの基本的な記述ルールを簡単に紹介します。

PHPで作成するファイルは、たとえば「index.php」のようにファイル名に拡張子として「***.php***」をつけておくことで、サーバーがPHPファイルとして認識して処理します。

PHPでは、以下のように「**<?php**」と「**?>**」と記載したコードの間に内容を記述します。
たとえば以下の通りです。
<p class="tmp"><span>書式</span></p>
```
<?php
 echo '<p>Hello World</p>'; 
?>
```
こうすると、PHPによってWebページに「Hello World」と表示されます。

コードの最後には、**セミコロン(；)**をつけます。  
PHPでは1つ1つの命令コードの最後にセミコロン（；）をつける決まりになっています。  
たとえば以下の通りです。
<p class="tmp"><span>書式</span></p>
```
<?php
　echo "テスト1";
　echo "テスト2";
　echo "テスト3";
?>
```

コメントの記述方法には、以下の3種類があります。

行頭に「*//*」と書く  
行頭に「*#*」と書く  
<p>複数行でコメントしたい場合は「<span class="text-danger">/*</span> コメント <span class="text-danger">*/</span>」で囲む</p>

以下がコメントの例です。

<p class="tmp"><span>書式</span>コメントの記述方法</p>
```
<?php
echo '<p>Hello World</p>';
 
// これはコメントです
# これもコメントです
/*
　これはコメントが
　複数行にわたる場合です。
*/
?>
```


***<?=*** は、**<?php echo** のショートタグですが、こちらはPHP 5.4.0以降、short_open_tagの設定にかかわらず有効です。


<p class="tmp"><span>書式</span>&lt;?php echoのショートタグ</p>
```php
<?= ～ ?> //<?php echo ～?>と同じ意味になります。
		　//※覚えておくと、コードが見やすくなって便利です
```

例えば、<?php echo～を使って書いた以下のコードを
```
<?php
echo '<input type="hidden" name="local" value="'.$local.'">';
echo '<input type="hidden" name="field" value="'.$field.'">';
?>
```


<?= ～ ?>を使うと、以下のようにコードを読みやすく書くことが出来ます。
```
<input type="hidden" name="local" value="<?= $local ?>">
<input type="hidden" name="field" value="<?= $field ?>">
```


## switch文の構文

<p class="tmp"><span>書式</span></p>
```
switch (条件分岐の対象) {
 case 条件;
  処理を記述
  break;
 case……
  （条件の数だけ続く）
 }
 ```

<iframe src="https://paiza.io/projects/e/DnSndecxBHODzCScICUrWw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>