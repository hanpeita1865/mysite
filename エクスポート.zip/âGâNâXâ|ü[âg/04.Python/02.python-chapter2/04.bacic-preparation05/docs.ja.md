---
title: 04.関数の定義と変数のスコープ
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">関数の定義</h2>

関数は、次のように定義します。

<p class="tmp"><span>書式1</span>関数の定義</p>

    def 関数名(引数,…):
        関数の処理
        return 戻り値


<p class="indent-01">※関数を定義するには、「def」というキーワードを使います。defはdefinition（定義）の略です。<br>
スタイルガイドでは、関数定義の前後には2行ずつ空行を配置することが推奨されています。</p>

 
 <p class="tmp"><span>書式2</span>return文を関数の途中に配置</p>

    def 関数名(引数,…):
      if 式:
        関数の処理1
        return 戻り値1
        関数の処理2
        return 戻り値2

※if文の式がTrueのときには戻り値1を、Falseのときには戻り値2を返します。
 
<p class="inpre"><span>インタプリタ</span>所要時間を計算する関数を定義します。距離と速度を与えると所要時間を返すようにします</p>
<pre>
>>> def trip(dist, speed):
...     time = dist / speed
...     return time
...
>>>
</pre>
 
※スタイルガイドで推奨されている関数の命名規則は、変数とおなじです。

<p class="tmp"><span>書式3</span>関数の呼び出し</p>

	関数名(引数Aの値,引数Bの値,…)


<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> trip(140,80)<span class="comment">  # 距離140km、速度80km/h</span>
1.75<span class="comment">  # 所要時間1.75時間（1時間45分）</span>
>>> trip(15,4)<span class="comment">  # 距離15km、速度4km/h</span>
3.75<span class="comment">  # 所要時間3.75時間（3時間45分）</span>
>>>
</pre>


<span class="bold red">ドキュメンテーション文字列</span> ～ Pythonプログラムの説明書を作成/管理/提供するための機能です。関数の説明を記述したりします。


<p class="tmp"><span>書式4</span>ドキュメンテーション文字列</p>
<pre>
def 関数名(引数,…);
    <span class="red bold">"""</span><span class="blue">概要説明</span>.

    <span class="blue">詳細説明</span>
    <span class="red bold">"""</span>
    関数の処理
    return 戻り値
</pre>

<p class="indent-01">※三重のシングルクォート(<span class="red bold">'''</span>)または三重のダブルクォート(<span class="red bold">"""</span>)で囲んだ文字列のことを、三重クォート文字列と呼びます。ドキュメンテーション文字列を書くときには、三重クォート文字列を使います。</p>

<p class="list-title">※スタイルガイドに沿って上記の書式は記述しています。</p>

+ 三重のダブルクォート(""")を使う。
+ 二行目は空行にする。
+ 三行目以降に詳細説明を書く


<p class="editpre"><span>テキストエディタ</span>関数の説明をつける</p>
<pre>
def trip(dist, speed):
    <span class="bold red">"""<span class="blue">距離と速度から所要時間を計算して返します.

    引数:
    dist -- 距離
    speed -- 速度</span>
    """</span>
    time = dist / speed
    return time
</pre>



<span class="red bold">help関数</span>を使うと、指定した関数の説明を表示することができます。

<p class="tmp"><span>書式5</span>help関数</p>

	help(関数名)



<p class="inpre"><span>インタプリタ</span>インタプリタで定義したtrip関数の説明を表示させてみます。</p>
<pre>
>>> help(trip)
Help on function trip in module __main__:

trip(dist, speed)
    距離と速度から所要時間を計算して返します.

    引数:
    dist -- 距離
    speed -- 速度
</pre>

<span class="red bold">再帰呼び出し</span>～ある関数の中から、その関数自身を呼び出すことを言います。

<p class="tmp"><span>書式6</span>関数の再帰呼び出し</p>

    def 関数名(引数,…):
        …
        関数名(引数,…)


※再帰呼び出しを使うと、ある種の処理が簡潔に書けることがあります。しかし繰り返しを使って書いた方が高速に実行できたりすることがあるので、無理に再帰呼び出しを使う必要はありません。

<p class="inpre"><span>インタプリタ</span>n以下の整数の合計</p>
<pre>
>>> def sum(n):<span class="comment">  # sum関数を定義</span>
...     if n > 0:
...         return n + sum(n-1)
...     return 0
...
>>> sum(3)<span class="comment">  # n=3の場合</span>
6
>>> sum(12)<span class="comment">  # n=12の場合</span>
78
</pre>


関数を定義した時の引数の順序と関数呼び出しにおける引数の順序は一致させる必要があります。このような引数のことを<span class="red bold">位置引数</span>といいます。

<p class="inpre"><span>インタプリタ</span>lunch関数を定義と位置引数での呼び出し</p>
<pre>
>>> def lunch(main, side, drink):<span class="comment">  # lunch関数を定義</span>
...     print('main :', main)
...     print('side :', side)
...     print('drink :',drink)
...
>>> lunch('beef', 'soup', 'coffee')<span class="comment">  # lunch関数の呼び出し</span>
main : beef
side : soup
drink : coffee
</pre>

※上記の関数の定義では戻り値を返す必要がないので、return文は省略しています。


<span class="red bold">キーワード引数</span>を使うと、引数を指定する順番を自由に決めることができます。

<p class="tmp"><span>書式7</span>キーワード引数による呼び出し</p>
<pre>
関数名(引数A=引数Aの値, 引数B=引数Bの値,…)
または
関数名(引数B=引数Bの値, 引数A=引数Aの値,…)
</pre>

<p class="inpre"><span>インタプリタ</span>キーワード引数による呼び出し</p>
<pre>
>>> lunch(side='soup', drink='coffee', main='beef')
main : beef
side : soup
drink : coffee
>>> lunch(drink='coffee', main='beef', side='soup')
main : beef
side : soup
drink : coffee
</pre>

<dl>
    <dt>位置引数とキーワード引数のそれぞれの利点</dt>
    <dd>・位置引数～関数呼び出しの記述が短くなる。<br>
		・キーワード引数～引数の順序を自由に入れ替えられる。   
    </dd>
    <dt>使い分け</dt>
    <dd>通常は位置引数を使用する。（関数呼び出しが短いと、プログラムが簡潔になる）<br>
	オプションの引数（設定してもしなくてもよい引数）には、キーワード引数を使用する。</dd>
</dl>

<p class="inpre"><span>インタプリタ</span>位置引数とキーワード引数の両方を使用</p>
<pre>
>>> lunch('soup', drink='coffee', side='beef')
main : soup
side : beef
drink : coffee
</pre>
※位置引数とキーワード引数がだぶらないようにする。

関数の定義において、<span class="red bold">引数のデフォルト値</span>を設定することができます。

<p class="tmp"><span>書式8</span>引数のデフォルト値</p>
<pre>
def 関数名(引数=値, …)
</pre>

※デフォルト値を指定した引数は、<span class="red bold">呼び出しの際に省略</span>することができます。

<p class="inpre"><span>インタプリタ</span>デフォルト値を設定する</p>
<pre>
>>> def lunch(main='beef', side='soup', drink='coffee'):
...     print('main :', main)
...     print('side :', side)
...     print('drink :',drink)
...
>>> lunch('fish')
main : fish
side : soup<span class="comment">  # デフォルト値を表示</span>
drink : coffee<span class="comment">  # デフォルト値を表示</span>
</pre>



<span class="red bold">ラムダ式</span>を使うと、無名関数を定義することが出来ます。

<p class="tmp"><span>書式9</span></p>

	lambda 引数, …: 戻り値

lambdaキーワードに続いて引数を指定します。引数は「,（カンマ）」で区切って複数指定することができます。
引数の後には「:（コロン）」を記述し、続けて戻り値を指定します。引数は省略することが可能です（戻り値は省略することができません）。

※ラムダ式が役立つのは、map関数のように、「関数を引数とする関数」を使うときです。

<dl>
    <dt>map関数とは</dt>
    <dd>リストのような複数の要素持ったオブジェクト（シーケンスと呼ぶ）と関数を引数として受け取ります。
		そしてシーケンスの各要素を受け取った関数に渡して実行してくれます。<br>
		このように関数を受け取る関数や関数を返す関数を高階関数とよびます。</dd>
</dl>

<p class="tmp"><span>書式10</span>map関数</p>

	map(関数名, リスト)


※引数として関数名を指定する代わりに、直接lambda式を記述することができます。

<p class="tmp"><span>書式11</span>map関数（lambda式を利用）</p>

	map(lambda式, リスト)


<p class="tmp"><span>書式13</span>map関数（変数+lambda式を利用）</p>

    変数 = lambda式
    map(変数, リスト)


※map関数の結果を取得するには、list関数と組み合わせます。list関数はリストを作成する関数です。

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> list(map(lambda x: x*x, [1, 2, 3, 4, 5]))
[1, 4, 9, 16, 25]
</pre>

ラムダ式を使うと、リストの要素に対して何らかの関数を適用するような処理を、簡潔に書くことができます。例えば、前述のプログラムを繰り返しを使って書くと、次のようになります。

<p class="inpre"><span>インタプリタ</span>繰り返しを使った場合</p>
<pre>
>>> a = []
>>> for x in [1, 2, 3, 4, 5]:
...     a.append(x*x)
...
>>> a
[1, 4, 9, 16, 25]
</pre>

<h2 class="h-type2">変数のスコープ（使用できる範囲）</h2>

<dl>
    <dt>グローバル変数</dt>
    <dd>関数の外側で定義した変数。関数の外側でも内側でも使える。（プログラム全域で使いたい場合）</dd>
    <dt>ローカル変数</dt>
    <dd>関数の内側で定義した変数。その関数の内側だけで使える。</dd>
</dl>

<p class="editpre"><span>テキストエディタ</span></p>
<pre>
def show():
    print(pet)

pet = 'dog'
show()
</pre>
<p class="blue bold mb-05">実行結果</p>
<pre>
dog
</pre>
変数petはグローバル変数なので、show関数の内側でも使えます。したがってshow関数を呼び出すと、petに格納されている'dog'が表示されます。

<p class="editpre"><span>テキストエディタ</span></p>
<pre>
def show():
	pet = 'cat'<span class="comment">  # 関数内だけで有効</span>
    print(pet)

pet = 'dog'<span class="comment">  # プログラム全体で有効</span>
show()
</pre>
<p class="blue bold mb-05">実行結果</p>
<pre>
dog
</pre>

グローバル変数は関数内でも使えますが、関数内でグローバル変数に値を代入する場合には、<span class="red bold">global文</span>が必要です。

<p class="tmp"><span>書式14</span></p>

	global 変数


<p class="editpre"><span>テキストエディタ</span>global文を設定</p>
<pre>
def cat():
    <span class="bold red">global</span> pet
    pet = 'cat'

pet = 'dog'
cat()
print(pet)
</pre>
<p class="blue bold mb-05">実行結果</p>
<pre>
cat
</pre>

<dl>
    <dt>nonlocal文</dt>
    <dd>global文に関連する文に、nonlocal文があります。実はPythonでは、<span class="red bold">関数の内側で別の関数を定義</span>することができます。
		このとき内側の関数において、<span class="red bold">外側の関数のローカル変数に値を代入</span>するときに必要なのが、<span class="red bold">nonlocal文		</span>です。
		nonlocal文を書かずに、内側の関数で変数に値を代入しようとすると、内側の関数におけるローカル変数の定義になってしまいます。</dd>
</dl>

<p class="tmp"><span>書式15</span>mapnonlocal文</p>
<pre>
nonlocal 変数
</pre>

<p class="editpre"><span>テキストエディタ</span></p>
<pre>
def dog():
    def cat():
        <span class="bold red">nonlocal</span> pet
        pet = 'cat'

    pet = 'dog'
    cat()
    print(pet)
dog()
</pre>

<p class="blue bold mb-05">実行結果</p>
<pre>
cat
</pre>

※nonlocal petを書かなかったら、結果はdogになる。


