Vue.createApp({
  data() {
    return {
      list: [ '赤パジャマ', '青パジャマ', '黄パジャマ' ]
    };
  },
  methods: {
    onclick() {
        this.list[1] = '茶パジャマ';

        //配列の先頭行を削除（リスト3-63）
        //this.list.shift(); 
    }
  }
}).mount('#app');
