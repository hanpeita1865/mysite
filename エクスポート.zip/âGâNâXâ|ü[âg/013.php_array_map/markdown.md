*[page-title]:指定した配列の要素にコールバック関数を適用 array_map

参考サイト
: [PHP マニュアル array_map](https://www.php.net/manual/ja/function.array-map.php)
: [【PHP入門】array_mapで配列の全要素に特定の関数を適用させる](https://www.sejuku.net/blog/22549)

<p class="tmp"><span>書式</span></p>
```
array_map(callback, $array,  arrays)
```
callback: 配列の各要素に適用する callable。複数の配列に zip 操作を行うために、 callback に null を渡すことができます。 array のみが与えられた場合、 array_map() は、入力された配列を返します。  

$array: コールバック関数を適用する配列。  
arrays: callback に渡す引数を指定する配列の可変リスト。

<div class="exp">
	<p class="tmp"><span>例1</span>array_map() の例</p>
	配列の値をコールバック関数に渡して、3乗にした値が返ってきます。
	<iframe src="https://paiza.io/projects/e/8vuOIhcdc9pI7U6eOcuY1w?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例2</span></p>
	array_mapの引数内で関数処理をします。配列の値に1を足しものを返しています。
	<iframe src="https://paiza.io/projects/e/urfyXJT0QKQZC61iHDJ0iA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例3</span>配列に「曜日」を付ける</p>
	<iframe src="https://paiza.io/projects/e/erzhLtWdpPjSNtBcpaybdg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


### 複数の配列に特定の関数を渡す

<div class="exp">
	<p class="tmp"><span>例4</span></p>
	3つの配列の値を渡して、計算したものを返しています。
	<iframe src="https://paiza.io/projects/e/dGuVTIrfeUSy6NUBV0dXwQ?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>
</div>


### 連想配列に特定の関数を渡す
連想配列の場合でも、使い方は配列の時とほとんど変わりませんが、1つの連想配列か、複数の連想配列かで、実行結果のキーの値が変わってきます。

#### 1つの連想配列の場合
連想配列が1つの場合、キーとなる部分(ここではMondayやTuesdayなど)はそのまま保持され、値の部分にコールバック関数が適用されます。

<div class="exp">
	<p class="tmp"><span>例5</span></p>
	<iframe src="https://paiza.io/projects/e/tbRKk567YDnGUpJXmWN6fw?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>
</div>



#### 連想配列が複数の場合
<div class="exp">
	<p class="tmp"><span>例6</span></p>
	<iframe src="https://paiza.io/projects/e/wSgqHkWripLd-a-ViDmrLA?theme=twilight" width="100%" height="800" scrolling="no" seamless="seamless"></iframe>
</div>

※連想配列が1つの場合はキー部分は保持されましたが、複数の連想配列になるとキーは保持されなくなり、番号でのキーになってしまいます。