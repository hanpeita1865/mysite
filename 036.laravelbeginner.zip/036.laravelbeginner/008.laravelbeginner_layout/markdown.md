*[page-title]:09. レイアウトの作成


Bladeには、レイアウトを継承し、いくつものテンプレートをセクションとして組み合わせてレイアウトを作成していく機能が用意されています。Blade式のレイアウトの 作り方をここで説明します。

## レイアウトの定義と継承
ここまでのテンプレート(index.blade.php)は、基本的に1つのテンプレートの中でペー ジ全体の表示を記述していました。これは1つ1つのテンプレートが完結していてわかり やすいのですが、多数のページを持ったWebサイトを構築する場合はかなり面倒になってきます。 多くのページがあるサイトでは、全体の統一感を持たせるために、共通したデザインでページが表示されるようにしているのが一般的です。そのためには、サイト全体で共 通するベースとなるレイアウトを用意し、それをもとに各ページのデザインを行うよう なやり方をする必要があるでしょう。

こうしたサイト全体を統一したデザインでレイアウトするために、Bladeには強力な 機能が用意されています。それは「<span class="green bold marker-yellow50">継承</span>」と「<span class="green bold marker-yellow50">セクション</span>」です。

### 「継承とは?
継承は、PHPのクラスで利用したことがあるでしょう。既に存在しているクラスを受け継いで、新しいクラスを作成するための機能でした。  
Bladeの継承も、考え方としては同じです。すなわち、「<span class="red">既にあるテンプレートのレイアウトを継承して新しいテンプレートを作成する</span>」のです。継承元のテンプレートに用意されている表示は、すべて新たに継承して作られたテンプレートでそのまま表示されます。新しいテンプレートでは、<span class="marker-yellow30">継承元にはない要素を用意するだけ</span>でいいのです。

### セクションとは?
継承でページをデザインするとき、ページ内の要素として活用されるのが「<span class="green bold">セクション</span>」です。  
セクションは、レイアウト内に用意される区画です。レイアウト用テンプレートでは、 「<span class="red">ページ内にセクションの区画を用意しておき、継承して作られた新しいテンプレートで、 そのセクションの内容を用意しておく</span>」のです。こうすることで、指定の内容がセクションに組み込まれ、レイアウトが完成します。  
この「継承」と「セクション」により、ベースとなるレイアウトから同じレイアウトのページをいくつも作っていくことが可能になります。

![](upload/layout01.png "図　ベースとなるレイアウトを継承し、用意されたセクションに表示内容をはめ込んでいけば、同じレイアウトでページをどんどん作っていける。")


## @sectionと@yield
セクションの利用のために、Bladeには2つの<span class="red bold">ディレクティブ</span>が用意されています。 <span class="green bold marker-yellow50">@section</span>と<span class="green bold marker-yellow50">@yield</span>です。この2つを使いこなすことが、レイアウト作成のポイントといってよいでしょう。

### @section について
レイアウトで、さまざまな区画を定義するために用いられるのが、@sectionです。 <span class="bold">@section</span>は、「<span class="marker-yellow30">ページに表示されるコンテンツの区画を定義</span>」します。これは、以下のように記述します。
<p class="tmp"><span>書式1</span></p>
```
@section(名前) 
	･･･表示内容･･･
@endsection
```
これで、指定した名前でセクションが用意されます。このセクションは、同じ名前の <span class="red">@yield</span>にはめ込まれ、表示されます。 また、<span class="red">@section</span>は、継承したページで@sectionによって上書きすることもできます。

### @yield について
<span class="bold">@yield</span>は、「<span class="marker-yellow30">セクションの内容をはめ込んで表示するためのもの</span>」です。これは以下のように記述します。
<p class="tmp"><span>書式2</span></p>
```
@yield(名前)
```

@yieldで指定した名前のセクションがあると、そのセクションが@yieldのところにはめ込まれます。@yieldは配置場所を示すものなので、@yieldendのようなものはありません。具体的なコンテンツなどを用意する必要はないのです。


## ベース・レイアウトを作成する
では、実際に簡単なサンプルを作成してみましょう。まずは、ベースとなるレイアウト用のテンプレートからです。  
「<span class="bold">resources</span>」内の「<span class="bold">views</span>」フォルダの中に、新たに「<span class="bold red">layouts</span>」というフォルダを作成して下さい。レイアウトのテンプレートは、このフォルダの中に用意することにしましょう。  
「layouts」フォルダの中に、「<span class="red">helloapp.blade.php</span>」という名前で新しいファイルを作成して下さい。これがベースとなるレイアウト用のファイルです。
![](upload/helloapp.blade.php作成.png){.photo-border}

作成したら、以下のリストを記述しておきましょう。

<p class="tmp list"><span>リスト1</span>resources/views/layouts/helloapp.blade.php（ベースのレイアウト用テンプレート）</p>
```
<html>
<head>
   <title>@yield('title')</title>
   <style>
   body {font-size:16pt; color:#999; margin: 5px; }
   h1 { font-size:50pt; text-align:right; color:#f6f6f6;
       margin:-20px 0px -30px 0px; letter-spacing:-4pt; }
   ul { font-size:12pt; }
   hr { margin: 25px 100px; border-top: 1px dashed #ddd; }
   .menutitle {font-size:14pt; font-weight:bold; margin: 0px; }
   .content {margin:10px; }
   .footer { text-align:right; font-size:10pt; margin:10px;
       border-bottom:solid 1px #ccc; color:#ccc; }
   </style>
</head>
<body>
   <h1>@yield('title')</h1>
   @section('menubar')
   <h2 class="menutitle">※メニュー</h2>
   <ul>
       <li>@show</li>
   </ul>
   <hr size="1">
   <div class="content">
   @yield('content')
   </div>
   <div class="footer">
   @yield('footer')
   </div>
</body>
</html>
```

### 解説

ここでは、何ヶ所かにディレクティブが用意されています。以下に簡単にまとめておきます。
```
<title>@yield('title')</title>
<h1>@yield('title')</h1>
```
タイトル表示の部分には、"title'という名前で@yieldを用意してあります。ここにtitle のコンテンツを設定します。また&lt;body&gt;内の&lt;h1&gt;にも同様に@yieldを用意し、タイトルを表示するようにしてあります。
```
@section('menubar')
```
これは、メニュー表示の区画です。セクションは区画を定義するものですが、一番土台となるレイアウトで@sectionを用意する場合は、@endsectionではなく、@showというディレクティブでセクションの終わりを指定します。
```
@yield('content') 
@yield('footer')
```
残る@yieldはこの2つです。これらは、それぞれコンテンツとフッターをはめ込むために用意してあります。継承したレイアウトで、これらの名前で@sectionを用意しておけば、 そのセクションのレイアウトがこれらの@yieldにはめ込まれることになるでしょう。


## 継承レイアウトの作成
続いて、このレイアウト用テンプレートを継承して、実際のWebページに使うテンプレートを用意しましょう。  
hello9フォルダを作成して以下のように index.blade.phpのスクリプトを追加して下さい。

<p class="tmp list"><span>リスト2</span>views/hello9/index.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Index')

@section('menubar')
   @parent
   インデックスページ
@endsection

@section('content')
   <p>ここが本文のコンテンツです。</p>
   <p>必要なだけ記述できます。</p>
@endsection

@section('footer')
copyright 2023
@endsection
```

今回は、先ほどのhelloapp.blade.phpとはうって変わって、HTMLらしい記述がほとんどないものになってしまいました。


### @extends について
まず最初に用意すべきは、レイアウトの継承設定でしょう。これは以下のように記述をしています。
```
@extends('layouts.helloapp')
```

これで、「layouts」フォルダ内の「helloapp.blade.php」というレイアウトファイルをロードし、親レイアウトとして継承します。これがないと、レイアウトの継承そのものが機能しなくなりますので注意して下さい。

### @section の書き方
続いて、@sectionの表示内容の書き方です。これには2通りあります。 1つは、タイトルの表示に使った書き方です。
```
@section ('title', 'Index')
```
単純にテキストや数字などをセクションに表示させるだけなら、@sectionの引数内に、当てはめるセクション名と、そこに表示する値をそれぞれ引数に用意します。今回は、 'title"という名前のセクションに、'Index'というテキスト値を設定します。
もう1つの書き方は、@endsectionを併用した書き方です。例えば以下の部分がそうです。
```
@section ('menubar')
    @parent
    インデックスページ 
@endsection
```

@sectionから@endsectionまでの部分が、セクションの内容になります。親レイアウトに'menubar"というyieldがあれば、そこにはめ込まれて表示されるわけです。  
ただし、今回の親レイアウトには、'menubar"という@yieldはなく、@sectionがあります。この場合、@sectionは上書きして置き換わります。  
このセクションには、<span class="red bold">@parent</span>というディレクティブがありますが、これは<span class="marker-yellow30">親レイアウトのセクションを示します</span>。親の@sectionに子の@sectionを指定する場合、親の @section部分を子のセクションが上書きします。このとき、親にあるセクションも残して表示したいこともあります。このようなときに、@parentで親のセクションをはめ込んで表示させることができます。  

その他の@section('content')や@section('footer)などは、親レイアウト側は@yieldで場所を指定しているだけなので、その部分にセクションがはめ込まれて表示されます。

コントローラーとルート情報に追記します。

<p class="tmp list"><span>リスト3</span>HelloLayoutController.php</p>
```
public function index() {
		return view('hello9.index');
}
```

<p class="tmp list"><span>リスト4</span>web.php</p>
```
Route::get('helloLayout', [\App\Http\Controllers\HelloLayoutController::class,'index']);
```

### 表示を確認する 
「親と子のレイアウトがそれぞれ用意できたら、実際に/helloLayoutにアクセスして表示を確認しましょう。helloapp.blade.phpのレイアウトに、hello9/index.blade.phpに用意したセクションがはめ込まれて表示されていることがわかるでしょう。  
![](upload/helloLayout表示.png "図　「/helloLayout」ページの表示"){.photo-border}

![](upload/helloLayoutコード.png "図　「/helloLayout」ページのコード"){.photo-border}
このように、レイアウトの継承を利用することで、子側のテンプレートには、セクションに表示する内容だけを記述すれば済みます。そしてすべて親のレイアウトを継承することで、同じレイアウトでページが表示されるようになるのです。



## コンポーネントについて
継承を利用したレイアウトでは、親レイアウトの必要な部分に子側のセクションをはめ込んで表示を完成させました。このやり方は、全体を一式揃えて作成するには大変便利な方法です。  
が、ときには「<span class="red">一部を切り離して作成し、組み込みたい</span>」ということもあるでしょう。 例えばタイトルやフッターの表示などは、それぞれ独立した部品として用意しておければとても便利です。各レイアウトから<span class="bold">タイトル</span>や<span class="bold">フッター</span>の部分を切り離すことで、純粋にそのページのコンテンツだけに集中することができます。また必要に応じてそれらの部品だけを修正すれば、サイト全体の表示を更新できるようになります。  

このような場合に用いられるのが「<span class="green bold">コンポーネント</span>」です。コンポーネントは、「<span class="red">1つの テンプレートとして独立して用意されるレイアウト用の部品</span>」です。コンポーネントは、 <span class="marker-yellow30">テンプレートから読み込まれ、必要な場所に組み込まれます</span>。
![](upload/コンポーネントについて.png "図　コンポーネントは、独立したテンプレートとして用意される部品。それらを組み合わせてレイア ウトを構築できる。")

### @component ディレクティブ
コンポーネントは、普通のテンプレートとして内容を作成します。コンポーネントといっても、書き方は普通のテンプレートと違いはありません。  
作成されたコンポーネントは、@componentというディレクティブを使って表示場所を設定されます。これは以下のように記述します。

p class="tmp"><span>書式3</span>コンポーネントの組み込み</p>
```
@component( 名前 )
	･･･コンポーネントの表示内容･･･
@endcomponent
```
コンポーネントの名前は、「**views**」フォルダにあるファイル名で指定されます。例えば、「**components**」フォルダ内に「<span class="red">ok</span>.blade.php」というファイル名で用意してあったならば、「 '<span class="red">components.ok</span>'」と指定すれば読み込むことができます。


## コンポーネントを作成する
では、実際にコンポーネントを作成してみましょう。ここでは、「**views**」フォルダの中に、新たに「**components**」というフォルダを用意し、この中にコンポーネントを用意することにします。 「components」フォルダを作成し、その中に「<span class="red">message.blade.php</span>」という名前でファイルを作成して下さい。そこに以下のようにソースコードを記述します。

<p class="tmp list"><span>リスト5</span>views/components/message.blade.php（コンポーネント）</p>
```
<style>
.message { border:double 4px #ccc; margin:10px; padding:10px;
   background-color:#fafafa; }
.msg_title { margin:10px 20px; color:#999;
   font-size:16pt; font-weight:bold; }
.msg_content {margin:10px 20px; color:#aaa;
   font-size:12pt; }
</style>
<div class="message">
   <p class="msg_title">{{$msg_title}}</p>
   <p class="msg_content">{{$msg_content}}</p>
</div>
```

ここでは、**{{$msg_title}}**と**{{$msg_content}}**という変数を表示するテンプレートを用意しておきました。それ以外に特に難しい点はないでしょう。ごく普通のHTMLタグベー スのテンプレートであることがわかります。

### コンポーネントを組み込む
では、このmessageコンポーネントをテンプレートに組み込んで表示させてみましょう。ここでは、index.blade.phpをコピペしてindex2.blade.phpを作成し、contentセクションの中に組み込んでみます。   @section('content')のセクション部分を以下のリストのように修正して下さい。

<p class="tmp list"><span>リスト6</span>hello9/index2.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Index')

@section('menubar')
   @parent
   インデックスページ
@endsection

@section('content')
   <p>ここが本文のコンテンツです。</p>
   <p>必要なだけ記述できます。</p>

   @component('components.message')
       @slot('msg_title')
       CAUTION!
       @endslot

       @slot('msg_content')
       これはメッセージの表示です。
       @endslot
   @endcomponent

@endsection
```

コントローラーとルート情報に追記します。

<p class="tmp list"><span>リスト7</span>HelloLayoutController.php</p>
```
public function component() {
		return view('hello9.index2');
}
```

<p class="tmp list"><span>リスト8</span>web.php</p>
```
Route::get('helloComponent', [\App\Http\Controllers\HelloLayoutController::class,'component']);
```



修正したら、「/helloComponent」にアクセスしてみましょう。コンテンツの下部に、四角い枠線で囲われたメッセージが表示されます。

![](upload/helloComponent表示.png "図「/helloComponent」の表示"){.photo-border}

![](upload/helloComponentコード.png "図「/helloComponent」のコード"){.photo-border}

これが、messageコンポーネントの表示です。このように、コンポーネントを組み込むことで、さまざまな表示をレイアウトの中に追加できます。

### スロットについて
ここでは、message.blade.phpの中に{{$msg_title}}と{{$msg_content}}という変数を用意していました。コンポーネントを利用する際には、これらの変数に必要な値を渡さなければいけません。
それを行っているのが、「<span class="red bold">スロット</span>」です。スロットは、<span class="red">{{ }}</span>で指定された変数に値を設定するためのものです。これは以下のように記述します。

<p class="tmp"><span>書式4</span>スロット</p>
```
@slot( 名前 )
	･･･設定する内容･･･ 
@endslot
```

ここでは、@component('components.message")として「components」フォルダの message.blade.phpをコンポーネントとして組み込むことを指定しています。そしてこの @component内に、<span class="red">@slot('msg_title')</span>と<span class="red">@slot('msg_content')</span>を用意してあります。これらのスロットの内容が、コンポーネントの<span class="red">$msg_title</span> と<span class="red">$msg_content</span>にはめ込まれて表示されるのです。

<span class="marker-yellow30">コンポーネントを使い、ページに表示されるさまざまな部品を用意しておけば、それらを組み合わせてページをデザインできるようになります</span>。  
そしてそれらはすべて統一されたデザインで表示されることになるのです。


## サブビューについて

コンポーネントは使い勝手の良い部品ですが、例えばページフッターやサイドバーなどのように定形のコンテンツなどは、もっと単純に「用意したテンプレートをただはめ 込んで表示できればいい」というものであったりします。こうしたものは、テンプレー トを読み込んでそのままテンプレート内にはめ込むことができます。こうした「<span class="red">ある ビューから別のビューを読み込んではめ込んだもの</span>」を<span class="green bold marker-yellow30">サブビュー</span>といいます。  
サブビューは、専用のテンプレートがあるわけではありません。ごく普通のテンプレー トとして用意しておき、それをそのまま読み込んで表示するだけのシンプルな仕組みなのです。

スロットのようなものは、サブビューでは使えません。ただし、コントローラからテンプレートに渡された変数などは、そのままサブビューのテンプレート内でも使うことができます。また、サブビューを読み込む際に変数を渡すこともできます。 サブビューは、以下のようにして読み込みます。

<p class="tmp"><span>書式5</span>サブビュー</p>
```
@include(テンプレート名 , [･･･値の指定･･･」)
```

第1引数には、読み込むテンプレートファイルを指定します。単にテンプレートの内容を表示するだけならこれだけでかまいません。何らかの値をサブビューのテンプレートに渡したい場合は、第2引数に配列(連想配列)にまとめた値を用意しておきます。

### message.blade.php をサブビューで読み込む
では、実際にやってみましょう。先ほど作成したmessage.blade.phpを、サブビューと してコンテンツ内に読み込み、表示させてみましょう。 index3.blade.phpの@section('content')部分を以下のように修正して下さい。

<p class="tmp list"><span>リスト9</span>hello9/index3.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Index')

@section('menubar')
   @parent
   インデックスページ
@endsection

@section('content')
   <p>ここが本文のコンテンツです。</p>
   <p>必要なだけ記述できます。</p>
  
   @include('components.message', ['msg_title'=>'OK', 
      'msg_content'=>'サブビューです。'])

@endsection
```

コントローラーとルート情報に追記します。

<p class="tmp list"><span>リスト10</span>HelloLayoutController.php</p>
```
public function subview() {
		return view('hello9.index3');
}
```

<p class="tmp list"><span>リスト11</span>web.php</p>
```
Route::get('helloSubview', [\App\Http\Controllers\HelloLayoutController::class,'subview']);
```

「/helloSubview」にアクセスすると、先程と同様にメッセージのボックスが表示されます。
![](upload/helloSubview表示.png "図　「helloSubview」を表示"){.photo-border}

![](upload/helloSubviewコード.png "図　「helloSubview」をコード"){.photo-border}

ここでは、@includeの第2引数に msg_titleとmsg_contentの値を配列として渡しています。 こうすることで、必要な値をテンプレート側に渡して表示させることができます。



## @eachによるコレクションビュー

表示の一部を切り離して作成する、ということを考えたとき、意外と利用頻度が高いのが「繰り返しの表示」です。例えばデータを繰り返しディレクティブなどで表示させるとき、表示する各項目のレイアウトを切り離して作成できたら便利です。  
テーブルの表示、リストの表示、通常のテキストコンテンツの表示など、あらかじめ 用意しておいたデータを繰り返し出力していくことはよくあります。こうした場合に役立つのが「<span class="green bold marker-yellow30">@each</span>」というディレクティブです。

@eachディレクティブは、「<span class="red">あらかじめ用意されていた配列やコレクションから順に値を取り出し、指定のテンプレートにはめ込んで出力するもの</span>」です。これは以下のように 記述します。

<p class="tmp"><span>書式5</span></p>
```
@each(テンプレート名 , 配列 , 変数名 )
```

第2引数には、表示するデータをまとめた配列やコレクションを指定します。そして 第3引数には、配列から取り出したデータを代入する変数名を指定します。テンプレート側では、この変数を使ってデータを受け取り、表示を行います。

### @each による表示を利用する
では、実際にやってみましょう。まずは、繰り返し表示する項目のテンプレートを用意します。
今回は「<span class="red">components</span>」フォルダの中に「<span class="red">item.blade.php</span>」という名前でファイルを作成することにします。内容は以下のように記述しておきましょう。

<p class="tmp list"><span>リスト12</span>components/item.blade.php</p>
```
<li>{{$item['name']}} [{{$item['mail']}}]</li>
```

ここでは、<span class="red">$item</span>という変数から<span class="red">name</span>と<span class="red">mail</span>の値を取り出して表示しています。ということは、nameとmailをまとめた配列データを、更に配列としてまとめたものを用意すればいいことがわかるでしょう。  

続いて、index.blade.phpの@section('content')の修正です。 「<span class="red">@each</span>」を使い、item.blade.phpでデータの項目を表示するようにしておきます。

<p class="tmp list"><span>リスト13</span>hello9/index4.blade.php</p>
```
@section('content')
   <p>ここが本文のコンテンツです。</p>
   <ul>
   @each('components.item', $data, 'item')
   </ul>
@endsection
```

このようになりました。ここでは<span class="red">@each</span>で、<span class="red">$data</span>という変数を<span class="red">'item'</span>に入れて繰り返すようにしてあります。  
ということは、アクションメソッド側で$data変数を用意しておき、テンプレートに渡せばいいわけです。では、HelloController.phpのindexアクションメソッドを修正しましょう。
<p class="tmp list"><span>リスト14</span>HelloController.php</p>
```
public function each()
{
   $data = [
       ['name'=>'山田たろう', 'mail'=>'taro@yamada'],
       ['name'=>'田中はなこ', 'mail'=>'hanako@flower'],
       ['name'=>'鈴木さちこ', 'mail'=>'sachico@happy']
   ];
   return view('hello.index', ['data'=>$data]);
}
```

ルート情報を追記します。
<p class="tmp list"><span>リスト15</span>web.php</p>
```
Route::get('helloEach', [\App\Http\Controllers\HelloLayoutController::class,'each']);
```
これで完成です。「/helloEach」にアクセスします。

![](upload/helloEach表示.png "図　「/helloEach」の表示"){.photo-border}

![](upload/helloEachコード.png "図　「/helloEach」のコード"){.photo-border}


$dataには、['name'=>○○, 'mail"=>○○」という形式の配列をデー タとしてまとめてあります。@eachでは、この1つ1つの配列が取り出され、そこから nameとmailの値を取り出して項目として出力していくことになるのです。  

@eachは、テンプレート名を指定して呼び出すだけですから、新しいテンプレートを作成したら、テンプレート名を書き換えるだけでデータの表示をがらりと変えてしまうことができます。データを多用するアプリでは非常に便利なディレクティブでしょう。




