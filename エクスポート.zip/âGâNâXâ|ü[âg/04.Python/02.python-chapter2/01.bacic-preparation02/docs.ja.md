---
title: 01.変数、数値、文字列
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">変数について</h2>

インタブリタで計算
「total=数値」と書くと、変数に数値を代入することが出来ます。<br>
「=」を付けずに「total」のみを書くと、「その変数に格納されている値を読み出す」という意味になります。

<p class="inpre"><span>インタプリタ</span>「790 + 680 + 290」の値を変数「total」に格納し、その変数値を2で割った結果を表示します。</p>
```
>>> total = 790 + 690 +290
>>> total / 2
885.0
>>>
```

<iframe src="https://paiza.io/projects/e/WnOqEGSzqtAez_QjJ17qig?theme=twilight" width="100%" height="300" scrolling="no" seamless="seamless"></iframe>


変数名を付ける規則
: ・1文字目に半角数字は使用できない。
: ・予約語は使用できない。

|予約語一覧|         |          |            |              |            |              |
|:------------:|:------------:|:------------:|:------------:|:------------:|:------------:|:------------:|
| False    | None        | True         | and       | as        | assert         | break         |
| class    | continue    | def         | del       | elif        | else         | except         |
| finally  | for        | from         | global       | if        | import         | in         |
| is       | tambda        | nonlocal     | not       | or        | pass         | raise         |
| return   | try        | while         | with       | yield        |          |          |

<dl>
    <dt>「PEP8」の命名規則に沿って付ける場合</dt>
    <dd>・半角の英小文字を使用する。</dd>
    <dd>・変数名の2文字目以降には、半角の数字を使用することもある。</dd>
    <dd>・英単語の区切りは「_」（アンダーバー）で示す。</dd>
</dl>



<h2 class="h-type2">変数の型</h2>

型の種類
: ・整数（int）
: ・浮動小数点（float）
: ・文字列（str）
: ・真理値（bool）

Pythoneの変数には、どのような型の値でも代入できます。<br>
次のように、それまで文字列を保存していた変数に、新たに数値を代入することも可能です。


<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> name = '田中'  <span class="comment"># 変数に文字を格納</span>
>>> name
'田中'
>>> type(name)
class 'str'&gt;  <span class="comment"># 文字列型</span>
>>> name = 5  <span class="comment"># 次に変数を数値に格納</span>
>>> name
5
>>> type(name)
&lt;class 'int'&gt;  <span class="comment"># 整数型</span>
</pre>

<iframe src="https://paiza.io/projects/e/0y9BHsdRyhvkFm6aKjjsYw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<h2 class="h-type2">数値</h2>

数値の計算には、下記の表の演算子を使います。

<p class="t-caption">算術演算子</p>

| 演算子 | 　　機能　 |
|:-----------:|:------------|
| +     | 　　加算    |
| -     | 　　減算    |
| *     | 　　乗算    |
| /     | 　　除算    |
| //    | 　　除算（結果の小数点以下は切り捨て）      |
| %     | 　　剰余    |
| **    | 　　べき乗  |

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> 1 + 2 * 3  <span class="comment"># 1 + 2 × 3</span>
7
>>> 2 * 3 / 4  <span class="comment"># 2 × 3 ÷ 4</span>
1.5
>>> 2 ** 3  <span class="comment"># 2の3乗</span>
8
</pre>

<iframe src="https://paiza.io/projects/e/UEXMlZI7hPwrKWk1Hk2EIw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>


<p class="t-caption">主な複合代入演算子</p>

| 演算子 | 　　機能　 |
|:-----------:|:------------|
| +=     | 　　加算    |
| -=     | 　　減算    |
| *=     | 　　乗算    |
| /=     | 　　除算    |
| //=    | 　　除算（結果の小数点以下は切り捨て）      |
| %=     | 　　剰余    |
| %=    | 　　べき乗  |

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> cnt = 1
>>> cnt += 2  <span class="comment"># cnt = cnt + 2</span>
>>> cnt
3
>>> cnt *= 3  <span class="comment"># cnt = cnt × 3</span>
>>> cnt
9
>>> cnt %= 2  <span class="comment"># cnt = cnt ÷ 2 の余り</span>
>>> cnt
1
>>>
</pre>

<iframe src="https://paiza.io/projects/e/BiTchXq5twwh16l-ocoBEA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<h2 class="h-type2">文字列</h2>

<p class="inpre"><span>インタプリタ</span>文字列の連結</p>
<pre>
>>> 'NTT' + 'DATA'
'NTTDATA'
</pre>

<p class="inpre"><span>インタプリタ</span>文字列の繰り返し連結</p>
<pre>
>>> '--+--' * 5
'--+----+----+----+----+--'
</pre>

<p class="inpre"><span>インタプリタ</span>文字列の連結と繰り返し連結の組み合わせ</p>
<pre>
>>> 'きゅう' * 2 + 'しゃ'
'きゅうきゅうしゃ'
</pre>

<iframe src="https://paiza.io/projects/e/MCTUNh7fdY_MPMk4L13HwQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式1</span>文字列の長さを調べる</p>
<pre>
len('文字列')
</pre>

<p class="inpre"><span>インタプリタ</span>文字列'325478'と'あかさたなはまやらわ'の長さを調べます。</p>
<pre>
>>> len('325478')
6
>>> len('あかさたなはまやらわ')
10
>>>
</pre>

<iframe src="https://paiza.io/projects/e/PtHsuuGgrqrDaXxtFcoSiw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>


文字列のインデックス
「文字列の何文字目かを表す整数」のことを「インデックス」と呼びます。

<p class="tmp"><span>書式2</span>インデックスの指定</p>
<pre>
文字列[インデックス]
</pre>

<p class="inpre"><span>インタプリタ</span>文字列'string'の指定した文字を取り出す。</p>
<pre>
>>> s = 'string'
>>> s[0]
's'
>>> s[4]
'n'
>>>
</pre>

<iframe src="https://paiza.io/projects/e/9JfRH1OgEB7pGZcxtPf4Lg?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

インデックスは負の数でも指定できます。その場合指定した文字は下記の表のようになります。<br>
[-1]にすると最後尾の文字を取得できます。

|    |    |    |    |    |    |
|:--:|:--:|:--:|:--:|:--:|:--:|
| s  | t  | r  | i  | n  | g  |
| -6 | -5 | -4 | -3 | -2 | -1 |

<p class="inpre"><span>インタプリタ</span>文字列'string'から負の数のインデックスを使って、指定した文字を取り出す。</p>
<pre>
>>> s = 'string'
>>> s[-1]
'g'
>>> s[-2]
'n'
>>> s[-4]
'r'
>>> s[-6]
's'
>>>
</pre>

<iframe src="https://paiza.io/projects/e/I1BshIcXOppm6fEhSahubw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="bold">Python言語における文字列は、作成した後は変更できません。こうした性質を「<span class="red">イミュータブル</span>」といいます。</p>


<p class="tmp"><span>書式3</span>文字列の取り出し（スライス）</p>
<pre>
文字列(開始インデックス:終了インデックス)
</pre>
※ 終了インデックスを省略すると、開始インデックスから最後の文字までを取り出します。<br>
   また、開始インデックスを省略すると、最初の文字から終了インデックス-1までを取り出します。

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> zipcode = '1008924'
>>> zipcode[0:3]
'100'
>>> zipcode[3:]<span class="comment">  # 終了インデックスを省略</span>
'8924'
>>> zipcode[:3]<span class="comment">  # 開始インデックスを省略</span>
'100'
</pre>

<iframe src="https://paiza.io/projects/e/cvYiu24hvx_hGsM4Hhic4A?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

'1008924'から最初の3文字'100'を取り出して「-」を結合し、そこに残りの'8924'を結合します。

<p class="inpre"><span>インタプリタ</span> 郵便番号作成</p>
<pre>
>>> zipcode='1008924'
>>> zipcode[:3] + '-'+ zipcode[3:]
'100-8924'
</pre>

<iframe src="https://paiza.io/projects/e/z9vSdfxZ-OTnUdyVrfuCaA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式4</span>ステップを使って、文字列の取り出し</p>
<pre>
文字列[開始インデックス:終了インデックス:ステップ]
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> s = 'あいうえおかきくけこさしすせそたちつてとなにぬねの'
>>> s[2:20:5]
'うくすつ'
>>> s[::5]<span class="comment">  # 開始・終了インデックスを省略</span>
'あかさたな'
</pre>

<iframe src="https://paiza.io/projects/e/pQjo-xoDPSwSKNQBVq2Sow?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


※ステップに負の数を使うと、元の文字列を逆順にした文字列を作れます。

<p class="inpre"><span>インタプリタ</span>文字列の最後尾から順番に文字を取り出す</p>
<pre>
>>> s = 'no lemon no melon'
>>> s[::-1]
'nolem on nomel on'
</pre>

<iframe src="https://paiza.io/projects/e/ngmYyyWonm4YJItzbBjcLA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<p class="inpre"><span>インタプリタ</span>文字列の6番目から3番目までを逆順に文字を取り出す</p>
<pre>
>>> s = 'おもいかるいし'
>>> s[5:2:-1]
'いるか'
</pre>

<iframe src="https://paiza.io/projects/e/McJIBhWay08YsbV24-BMCA?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>


formatメソッドは、文字列内の{}に引数の順番に書き込んだ文字列を表示します。
同じ値を何度も表示するときに便利です。

<p class="tmp"><span>書式5</span>formatメソッド</p>
<pre>
文字列.format(引数,引数,・・・)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> s = '{}は「{}」の呪文を唱えた。'
>>> s.format('大根','ひらけごま')
'大根は「ひらけごま」の呪文を唱えた。'
</pre>

<iframe src="https://paiza.io/projects/e/VjeHWQRhS7tEiJ1wscb34Q?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="inpre"><span>インタプリタ</span>引数の番号を指定</p>
<pre>
>>> s = '{0}は「{1}」の呪文を唱えた。{0}は体力を{2}失った!'
>>> s.format('大根','ひらけごま',1)
'大根は「ひらけごま」の呪文を唱えた。大根は体力を1失った!'
</pre>

<iframe src="https://paiza.io/projects/e/8-YtXDjONYReQ60nMIWF5g?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>


※ formatメソッドには、出力の桁数を指定する機能もあります。

<p class="tmp"><span>書式6</span>桁数を指定</p>
<pre>
{引数番号:桁数}
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> s = '{0:6}'
>>> s.format('abc')
'abc   '<span class="comment">  # 文字列の場合、左詰めで空いている桁に空白が入る</span>
>>> s.format(123)
'   123'<span class="comment">  # 数値の場合、右詰めで空いている桁に空白が入る</span>
</pre>

<iframe src="https://paiza.io/projects/e/Ekkjd6H9hnVjrkMo7rb5gw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式7</span>文字の置換</p>
<pre>
文字列.replace(旧文字列,新文字列)
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> guest = '佐藤,鈴木,田中,'
>>> guest.replace(',','様、' )
'佐藤様、鈴木様、田中様、'
</pre>

<iframe src="https://paiza.io/projects/e/ekvJKRu7PjSa3Qv-gqbSXQ?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式8</span>置換の処理の回数を指定（1にすると最初の文字だけ置換）</p>
<pre>
文字列.replace(旧文字列,新文字列,回数)
</pre>

<p class="inpre"><span>インタプリタ</span>最初の指定した文字だけ置換</p>
<pre>
>>> guest = '佐藤,鈴木,田中,'
>>> guest.replace(',','様,',1 )
'佐藤様,鈴木,田中,'<span class="comment">  # 最初の名前にだけ「様」がつく</span>
</pre>

<iframe src="https://paiza.io/projects/e/Ud6I2lx_b28OS_zAgE3ERg?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>
