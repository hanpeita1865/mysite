*[page-title]:テンプレート利用の基本

## Laravelのビューとテンプレートの概要

Laravelでは、画面表示を「ビュー」が担当し、HTMLを使って柔軟な表示が可能になります。  
ビューは「テンプレート」として作られ、コントローラーから呼び出されて表示されます。  
テンプレートには変数や処理を記述でき、アクセス時に必要な情報を埋め込んで画面を生成します。この処理をレンダリングと呼びます。  
レンダリングは「テンプレートエンジン」によって行われます。

Laravelでは以下の2種類のテンプレート方式が使えます。
* PHPコードを直接使う方法
* Laravel独自のテンプレートエンジン「Blade」を使う方法
 
これらを理解すれば、Laravelでの画面表示の基本を習得したと言えます。

<div markdown="1" class="flex-center">
![](upload/コントローラーからテンプレート.png "図　クライアントがアクセスすると、呼び出されたコントローラーからテンプレートが読み込まれ、テンプレートエンジンによってレンダリングされる。"){.photo-border}
</div>

### PHPテンプレートの作成手順（Laravel）

まず「resources/views」フォルダ内に「hello」フォルダを作成します。  
各コントローラーごとにテンプレート用のフォルダを分けるのが基本的な構成です（必須ではないが推奨）。

「hello」フォルダ内に「index.php」というテンプレートファイルを作成します。  
![](upload/views_helloフォルダ構成.png)

このテンプレートは、HelloControllerのアクションから読み込まれて使われます。  

では下記のコードをそれぞれ記入してください。

<p class="tmp list"><span>リスト3-1</span>hello/index.php</p>
```
<html>
<head>
  <title>Hello/Index</title>
  <style>
  body {font-size:16pt; color:#777;}
  h1 {font-size:50pt;text-align:right;color:#e0e0e0;
      margin:-25px 0px 0px 0px;}
  </style>
</head>
<body>
  <h1>Index</h1>
  <p>This is a sample page with php-template.</p>
</body>
</html>
```

<p class="tmp list"><span>リスト3-2</span>web.php</p>
```
Route::get('hello', function() {
   return view('hello.index');
});
```

「～/hello」にアクセスしてみてください。次のように表示されます。
![](upload/hello_php_template.png){.photo-border}


### viewメソッドの使い方

view()メソッドは、指定したテンプレートを読み込んで返す関数です。
```
view('フォルダー名.ファイル名')
```
テンプレートは「resources/views」内から検索されます。

例：view('hello.index') → 「views/hello/index.php」を読み込む。

フォルダーを使って整理している場合は、必ず「フォルダー名.ファイル名」の形式で指定する必要があります。


<div markdown="1" class="memo-box">
このview メソッドの戻り値をreturnすると、そのままテンプレートの内容が表示されます。  
このことから、「viewは、テンプレートを読み込んでその内容を返すんだ」と思ってしまいがちですが、実はそうではありません。  
view が返すのは、「<span class="bold red">Response</span>」インスタンスなのです。もちろん、このResponseには、指定したテンプレートのレンダリング結果がコンテンツとして設定されています。ですから、テンプレートの内容がきちんと表示されます。結果として「viewの戻り値をそのまま返せばテンプレートの内容が表示される」という点では同じですが、「viewにより、テンプレートのソースコードがそのまま返されるわけではない」という点は知っておきましょう。
</div>


### コントローラーでテンプレートを使う

まず、コントローラーを修正しましょう。HelloControllerクラスの indexメソッドとweb.phpを以下のように修正してください。

<p class="tmp list"><span>リスト3-3</span>app/Http/Controllers/HelloController.php</p>
```
public function index()
{
  return view('hello.index');
}
```

<p class="tmp list"><span>リスト3-4</span>web.php</p>
```
Route::get('hello', [HelloController::class, 'index']);
```

「～/hello」にアクセスすると、index.phpの内容が表示されます。  
違いは、Route::get()で直接view()を使うか、アクションメソッド内でview()を使うかだけです。  
表示結果は同じです。

## テンプレートに値を渡す方法

テンプレートはただHTMLを表示するだけでなく、変数の値や処理結果を表示できるのが利点です。  
テンプレート（例：index.php）では <?= ?> タグでPHPの変数や処理を記述可能。

変数を表示するには、コントローラーからテンプレートへ値を渡す必要があります。  
例として、$msg という変数と日付を `<p>`タグで表示するために、コントローラーのアクションメソッドを修正して、テンプレートに値を渡すようにします。

<p class="tmp list"><span>リスト3-5</span>views/hello/index.php（テンプレート）</p>
```
<body>
  <h1>Index</h1>
  <p><?= $msg; ?></p>
  <p><?= date("Y年n月j日"); ?></p>
</body>
```

<p class="tmp list"><span>リスト3-6</span>app/Http/Controllers/HelloController.php</p>
```
public function index()
{
  $data = ['msg'=>'これはコントローラーから渡されたメッセージです。'];
  return view('hello.index', $data);
}
```

「～/hello」にアクセスしてみてください。  
「これはコントローラーから渡されたメッセージです」というテキストが表示されます。$msgに値を渡し、それが表示されることが確認できました。
![](upload/コントローラーから渡されたメッセージです.png){.photo-border}

このようにviewの第2引数では、テンプレート側に用意する変数名をキーに指定して値を用意します。  
配列ですから、必要があればいくつでも値を用意し渡すことが可能です。

<p class="tmp"><span>書式</span></p>
```
return view( テンプレート, 配列);
```

## Bladeテンプレートの概要と作成方法

PHPだけでテンプレートを書くと、記述が煩雑になり、バグの原因にもなりやすいです。  
Laravel標準のテンプレートエンジン「Blade」は、簡潔で効率的な記述ができ、レイアウト継承やセクション分割も可能です。

Bladeを使うには、「resources/views」内にテンプレートファイルを作成して、ファイル名は「〇〇.blade.php」の形式にします。

例として「hello/index.blade.php」を作成してみます。  

<p class="tmp list"><span>リスト3-7</span>resources/views/hello/index.blade.php</p>
```
<html>
<head>
  <title>Hello/Index</title>
  <style>
    body {font-size:16pt; color:#777; }
    h1 { font-size:40pt; text-align:right; color:#d0d0f0;
      margin:-20px 0px 0px 0px; }
  </style>
</head>
<body>
  <h1>Blade/Index</h1>
  <p>{{$msg}}</p>
</body>
</html>
```

コントローラーの方も修正します。  
msgの値だけ先ほどと変えています。
<p class="tmp list"><span>リスト3-8</span>app/Http/Controllers/HelloController.php</p>
```
public function index()
{
  $data = [
    'msg'=>'これはBladeを利用したサンプルです。',
  ];
  return view('hello.index', $data);
}
```

これで完成です。「～/hello」にアクセスすると、index.blade.phpテンプレートを使って画面が表示されます。
![](upload/Bladeを利用したサンプルです.png){.photo-border}

<div markdown="1" class="memo-box">
##### index.php とindex.blade.php、どっちを使うの?
index.blade.phpを使ってページの表示ができましたが、ちょっと考えてみてください。ここでは、「Bladeテンプレートを使う」といった設定は一切行っていません。そして、これまで使っていたindex.phpもそのままになっています。それなのに、view('hello.index'~)と実行すると、index.blade.phpを使って画面の表示がされました。

Laravelでは、Bladeテンプレートがあると、それが優先して読み込まれます。テンプレート名を'index'と指定してあるなら、index.phpではなく、<span class="bold green">index.blade.php</span>が使われるのです。このファイルがない場合には、index.phpが使われます。このため、同名のファイル「〇○.php」「○○.blade.php」があれば、「〇○.blade.php」が使われます。

もし、「index.blade.phpではなく、index.phpのほうを使いたい」という場合は、テンプレートファイル名を拡張子まで含めて"index.php"というように指定してください。こうすれば完全に一致するファイルが利用されます。
</div>

### フォームの利用

フォームはユーザー入力を受け取るための基本機能です。  

Bladeテンプレート（例：index.blade.php）に `<form method="POST" action="/hello">` を記述し、POST送信を行います。  
送信先の/helloに対応する処理（コントローラー側）を用意すれば、送信データを受け取って処理ができます。

<p class="tmp list"><span>リスト3-9</span>index.blade.php</p>
<pre><code class="hljs xml"><span class="hljs-tag">&lt;<span class="hljs-name">body</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">h1</span>&gt;</span>Blade/Index<span class="hljs-tag">&lt;/<span class="hljs-name">h1</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>{{$msg}}<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">form</span> <span class="hljs-attr">method</span>=<span class="hljs-string">"POST"</span> <span class="hljs-attr">action</span>=<span class="hljs-string">"/hello"</span>&gt;</span>
    <span class="marker-yellow">@csrf</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"text"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"msg"</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"submit"</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">form</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">body</span>&gt;</span></code></pre>

ここで重要なのは、`<form>`タグ直後に必要な記述がある点（※通常はCSRF対策など）です。

### @csrfとCSRF対策について

Laravelでフォームを使う際は、<span class="bold red">@csrf</span>をフォーム内に記述する必要があります。
これは、**<span class="green">CSRF（クロスサイトリクエストフォージェリ）</span>**という外部からの不正なリクエスト送信を防ぐためのセキュリティ対策です。

<span class="bold red">@csrf</span>は、ランダムなトークンを含む「非表示フィールド（CSRFフィールド）」を自動生成し、Laravelはこのトークンを検証することで、正規のフォームからの送信かどうかを判断します。

Bladeの<span class="red bold">@csrf</span>のような「@から始まる構文」はディレクティブと呼ばれ、PHPコードを簡潔に書けるようにする機能です。

Laravelでは、<span class="marker-yellow50">@csrfがないフォームからの送信はエラーとなり受付拒否されるため、フォーム使用時は必ず@csrfを入れる必要があります</span>。
<div markdown="1" class="flex-center">
![](upload/CSRFの機能の説明図.png "図　CSRFは、外部からプログラムなどによってフォームを送信する攻撃。用意されたフォームかどうか見分ける工夫が必要になる")
</div>


HelloControllerクラスを以下のように修正してください。

<p class="tmp list"><span>リスト3-10</span>HelloController.php</p>
```
class HelloController extends Controller
{
  
  public function index()
  {
    $data = [
      'msg'=>'お名前を入力下さい。',
    ];
    return view('hello.index', $data);
  }

  public function post(Request $request)
  {
    $msg = $request->msg;
    $data = [
      'msg'=>'こんにちは、' . $msg . 'さん！',
    ];
    return view('hello.index', $data);
  }
}
```
web.phpに下記を追加してください。（indexの方は削除せずにそのまま）
<p class="tmp list"><span>リスト3-11</span>web.php</p>
```
Route::post('hello', [HelloController::class, 'post']);
```
POST送信には、Route::postメソッドを使います。使い方はRoute::getと同様で、URLと対応するアクションを指定します。  
同じアドレスでも、GETとPOSTで使い分けが可能です。たとえば、/helloに対してGETは表示、POSTはデータ処理というように使い分けられます。

<div markdown="1" class="d-flex">
![](upload/田中一郎を入力.png "図　名前を入力して送信"){.photo-border}
<span class="arrow-right mx-3 mt-5"></span>
![](upload/こんにちは田中一郎さん.png "図　POST送信された名前が表示されます"){.photo-border}
</div>

