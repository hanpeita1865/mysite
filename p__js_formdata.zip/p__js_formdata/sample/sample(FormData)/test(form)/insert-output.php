<?php
ini_set('display_errors', 0);
//if (!empty($_REQUEST['name'] )) {
    echo $_REQUEST['name'];
//}
?>