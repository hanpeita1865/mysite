<?php
// セッションの開始
session_start();

// ワンタイムトークンの生成
$toke_byte = random_bytes(16);
$token = bin2hex($toke_byte);

// トークンをセッションに保存
$_SESSION['token'] = $token;

//フラッシュメッセージ 追加
if (isset($_SESSION['flash'])) {
    $flash_messages = $_SESSION['flash']['message'];
}
unset($_SESSION['flash']);

if (isset($flash_messages)) {
    echo '<ul class="feedback">';
    foreach ((array)$flash_messages as $message) {
        echo '<li>'. $message .'</li>';
    }
    echo '</ul>';
}
?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>編集フォーム</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php
    $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8', 'staff', 'password');
    ?>
    <p><a href="index.php">一覧に戻る</a></p>
    <h1>商品編集</h1>
    <table>
        <thead>
            <tr>
                <th>商品名</th>
                <th>生産地</th>
                <th>価格</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = $pdo->prepare('select * from products where id=?');
            $sql->execute([$_GET['id']]);
            foreach ($sql->fetchAll() as $row): ?>
                <form action="update-output.php" method="post">
                    <input type="hidden" name="token" value="<?= $token; ?>">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <td><input type="text" name="name" value="<?php if (isset($_SESSION['name'])) {
                                                                    echo $_SESSION['name'];
                                                                } else {
                                                                    echo $row['name'];
                                                                } ?>"></td>
                    <td><input type="text" name="local" value="<?php if (isset($_SESSION['local'])) {
                                                                    echo $_SESSION['local'];
                                                                } else {
                                                                    echo $row['local'];
                                                                } ?>"></td>
                    <td><input type="text" name="price" value="<?php if (isset($_SESSION['price'])) {
                                                                    echo $_SESSION['price'];
                                                                } else {
                                                                    echo $row['price'];
                                                                } ?>"></td>
                    <td><input type="submit" value="更新"></td>
                </form>
            <?php endforeach ?>
        </tbody>
    </table>
</body>

</html>
<?php require 'delete-session.php'; ?>