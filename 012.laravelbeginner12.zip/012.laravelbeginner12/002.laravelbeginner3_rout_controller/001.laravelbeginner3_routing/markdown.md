*[page-title]:ルーティング

作業環境
: http://laravel_3rdherd.test/hello

<p class="tmp list"><span>リスト2-3</span>web.php</p>
```
Route::get('hello',function () {
  return '<html><body><h1>Hello</h1><p>This is sample page.</p></body></html>';
});
```

「/hello」にアクセスします。
![](upload/This_is_samplePage.png){.photo-border}


### パラメータを利用

<p class="tmp list"><span>リスト2-5</span>web.php</p>
```
Route::get('hello/{msg}',function ($msg) {
  $html = <<<EOF
    <html>
    <head>
    <title>Hello</title>
    <style>
    body {font-size:16pt; color:#999; }
    h1 { font-size:100pt;text-align:right;color:#eee;
      margin:-40px 0px -50px 0px; }
    </style>
    </head>
    <body>
      <h1>Hello</h1>
      <p>{$msg}</p>
      <p>これは、サンプルで作ったページです。</p>
    </body>
    </html>
  EOF;

  return $html;
});
```

![](upload/hello_こんにちは.png){.photo-border}

このパラメーターは、基本的に「必須パラメーター」であり、パラメーターを指定せずにアクセスするとエラーになってしまいます。用意されているルートパラメーターは必ずつけてアクセスしなければいけません。


### 任意パラメータ

パラメーター名の末尾に「<span class="bold red">?</span>」をつけて宣言をします。そして、第2引数の関数では、値が渡される仮引数に<span class="bold red">デフォルト値</span>を指定し、引数が渡されなくとも処理できるようにしておきます。
先ほどのリスト2-5で記述したRoute:getの1行目の部分を以下のように書き換えてみて
ください。
<pre><code class="hljs php">Route :: get(<span class="hljs-string">'hello/{msg<span class="marker-yellow">?</span>}'</span>,<span class="hljs-function"><span class="hljs-keyword">function</span><span class="hljs-params">(<span class="marker-yellow">$msg=<span class="hljs-string">'no message.'</span></span>)</span></span>{ ......</code></pre>

![](upload/no_message.png){.photo-border}