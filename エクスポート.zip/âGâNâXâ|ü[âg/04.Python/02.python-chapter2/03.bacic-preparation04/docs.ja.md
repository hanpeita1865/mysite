---
title: 03.制御構文
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">for文～繰り返し文～</h2>

<p class="tmp"><span>書式1</span></p>
<pre>
for 変数 in リスト:
    処理
</pre>

<p class="indent-01">※二行目の処理はインデントをつけます。（スタイルガイドでは、半角スペース4個が推奨されています。）<br>
インデントされている範囲が、for文の内部の処理です。インデントされなくなったら、for分の外部の処理になります。</p>


<p class="tmp"><span>書式2</span></p>
<pre>
for 変数 in リスト:
    内部の処理1
    内部の処理1
　　・・・・
外部の処理
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> price = [100, 120, 150]
>>> for p in price:
...     print(p)
...
100
120
150
</pre>
<p class="indent-01">※インタプリタで上記の最初の二行を入力してENTERキーを押すと、「…」が表示され、半角スペースを4つ入れてprint(p)を入力し、ENTERキーを押し「…」が表示されたら、もう一度エンターキーを押すと結果が表示されます。</p>

<iframe src="https://paiza.io/projects/e/0ODeoECDay6Gx8buHld92Q?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>


<p class="inpre"><span>インタプリタ</span>3割引きの価格を表示する</p>
<pre>
>>> price = [100, 120, 150]
>>> for p in price:
...     print(p * 0.7)
...
70.0
84.0
105.0
</pre>

<iframe src="https://paiza.io/projects/e/T3omouYu7eb8XcVRUYf6tw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<span class="bold red">int関数</span>を使うと小数点以下が切り捨てられる。

<p class="tmp"><span>書式3</span>整数への変換</p>
<pre>
int(式)
</pre>

<p class="inpre"><span>インタプリタ</span>35%引きの価格を整数で表示する</p>
<pre>
>>> price = [100, 120, 150]
>>> for p in price:
...     print(<span class="red">int</span>(p * 0.65))
...
65
78
97
</pre>

<iframe src="https://paiza.io/projects/e/Nys5xOiL4HcG2wdZ-aX5WQ?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<h2 class="h-type2">if文～条件分岐～</h2>

| 比較演算子 | 　　機能　 |
|:-----------:|:------------|
| X == Y    | 　　XとYが等しければTrue        |
| X != Y    | 　　XとYが等しくなければTrue    |
| X < Y     | 　　XがYよりも小さければTrue（XがY未満ならばTrue）    |
| X > Y     | 　　XがYよりも大きければTrue    |
| X <= Y    | 　　XがY以下ならばTrue          |
| X >= Y    | 　　XがY以上ならばTrue          |


<p class="tmp"><span>書式4</span></p>
<pre>
if 式:
    内部の処理1
    内部の処理2
    内部の処理3
    ・・・・
外部の処理
</pre>

※for文のように二行目以下はインデントを入れる。

<p class="inpre"><span>インタプリタ</span></p>
```
>>> temp = 18
>>> if temp < 20:
...     print('heater')<span class="comment">  # tempの値が20未満の時、'heater'を表示</span>
...
heater
```

<iframe src="https://paiza.io/projects/e/nairzhM-QYcZZ_MtyF1twA?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式5</span>if～else文</p>
<pre>
if 式:
    Trueの処理
else:
    Falseの処理
</pre>

<p class="inpre"><span>インタプリタ</span></p>
```
>>> temp = 24
>>> if temp < 20:
...     print('heater')
... else:
...     print('stop')
...
stop
```

<iframe src="https://paiza.io/projects/e/p9ojuVp9rq_ADllxmntZqw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式6</span>if～elif～</p>
<pre>
if 式A:
    処理A
elif 式B:
    処理B
</pre>

※elifはelse ifの略です。

<p class="tmp"><span>書式7</span>if～elif～else～</p>
```
if 式A:
    処理A
elif 式B:
    処理B
elif 式C:
    処理C
else:
    処理D 
```

<p class="inpre"><span>インタプリタ</span></p>
```
>>> temp = 31
>>> if temp < 20:
...     print('heater')
... elif temp >= 30:
...     print('cooler')
... else:
...     print('stop')
...
cooler
```
<iframe src="https://paiza.io/projects/e/c_CJpWaEkq8GD_nM5ixY0g?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>


<h2 class="h-type2">メンバーシップ・テスト演算子</h2>

+ 文字列が、指定した部分文字列を含んでいるかどうかを調べる。
+ リストが、指定した値の要素を含んでいるかどうかを調べる。

<p class="tmp"><span>書式8</span>文字列とin演算子</p>
<pre>
部分文字列 in 文字列
</pre>

<p class="tmp"><span>書式9</span>文字列とnot in演算子</p>
<pre>
部分文字列 not in 文字列
</pre>

<p class="inpre"><span>インタプリタ</span>文字列に指定した文字が含まれてるか、または含まれてないかを調べる</p>
<pre>
>>> 'み' <span class="red">in</span> 'ままみまま'
True
>>> 'み' <span class="red">not in</span> 'ままみまま'
False
</pre>

<iframe src="https://paiza.io/projects/e/MCy5JeUnOglZJXPXxaWDrQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

#### 文字列中で特定の部分文字列が存在するインデックスを取得（例外を発生しない）

<iframe src="https://paiza.io/projects/e/IrBs9PVf3dkF_7-oWrOCBg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<iframe src="https://paiza.io/projects/e/6yioSj6-Rzfy5zRh_QcUxA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<iframe src="https://paiza.io/projects/e/Em5E3j9mWmU--RS-Pu1FtA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<iframe src="https://paiza.io/projects/e/OGfHYVkhvdRSOXP1XGkMqw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<iframe src="https://paiza.io/projects/e/cBVfC4Hwdib3daxbA0r7lg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<iframe src="https://paiza.io/projects/e/moukwZSc5s2aEcgpa5skew?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<iframe src="https://paiza.io/projects/e/JxGT2UmyS9ADdGMtSkQcqg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<iframe src="https://paiza.io/projects/e/VOR5Zg9wTQhAibmC7wqyOw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


<p class="tmp"><span>書式10</span>リストとin演算子</p>
<pre>
値 in リスト
</pre>

<p class="tmp"><span>書式11</span>リストとnot in演算子</p>
<pre>
値 not in リスト
</pre>


<p class="inpre"><span>インタプリタ</span>リストに指定した要素が含まれてるか、または含まれてないかを調べる</p>
<pre>
>>> card = [1,2,4,7,9,10,12]
>>> 7 <span class="red">in</span> card
True
>>> 7 <span class="red">not in</span> card
False
</pre>

<iframe src="https://paiza.io/projects/e/NY0CxZXDZf-IcpZeJ7Y5oA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


<h2 class="h-type2">論理演算子</h2>

| 論理演算子 | 　　機能　 |
|:----------:|:-----------|
| and     | 　　かつ    |
| かつ    | 　　または    |
| not     | 　　否定    |


<p class="inpre"><span>インタプリタ</span>and</p>
```
>>> temp = 18
>>> if 15 <= temp and temp < 25:
...     print('go outside')
...
go outside
```

<p class="inpre"><span>インタプリタ</span>not</p>
```
>>> temp = 31
>>> if not (15 <= temp and temp < 25):
...     print('stay inside')
...
stay inside
```
<iframe src="https://paiza.io/projects/e/T0MXAA9Gm4j-NSEmuGAJRg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<p class="indent-01">※論理演算子の優先順位～高い方から　not > and > or　の順です。<br>
notはandやorよりも優先順位が高いので下記のように（）で囲みます。</p>
 
　　　not (15 <= temp and temp < 25):

<h2 class="h-type2">while文</h2>

<p class="tmp"><span>書式12</span>while文</p>
```
while 式:
    処理
```

<p class="tmp"><span>書式13</span>while文</p>
<pre>
while 式:
    内部処理1
    内部処理2
    内部処理3
    ・・・・
外部処理
</pre>

<p class="inpre"><span>インタプリタ</span></p>
```
>>> stage = 1
>>> while stage <= 8:
...     print(stage)
...     stage += 1
...
1
2
3
4
5
6
7
8
```

<iframe src="https://paiza.io/projects/e/VQvNZYLrx1e2SCikfH5vPQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


繰り返しの中断は、「break文」を記述する。

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> stage = 1
>>> while stage <= 8:
...     print(stage)
...     if stage == 4:
...         <span class="bold red">break</span>
...     stage += 1
...
1
2
3
4
</pre>

continue文～繰り返しの継続

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> stage = 1
>>> while stage <= 8:
...     print(stage)
...     if stage == 4:
...         stage = 8
...         <span class="bold red">continue</span>
...     stage += 1
...
1
2
3
4
8
</pre>

<dl>
    <dt>range関数とは</dt>
    <dd>終了値-1までの繰り返しを行います。変数に代入される値は0から始まり、1ずつ増加して、終了値-1で終わります。<br>
for文とrange関数を組み合わせると、指定した範囲の繰り返しを簡単に実現することができます。</dd>
</dl>

<p class="tmp"><span>書式13</span>指定した範囲の繰り返し</p>
<pre>
for 変数 in range(終了値):
    処理
</pre>

※終了値は変数に代入されません。

<p class="inpre"><span>インタプリタ</span></p>
```
>>> for i in range(5):
...     print(i)
...
0
1
2
3
4
```

<p class="tmp"><span>書式15</span>開始値（0以外）と終了値を指定した繰り返し</p>
<pre>
for 変数 in range(開始値,終了値):
    処理
</pre>

<p class="inpre"><span>インタプリタ</span></p>
```
>>> for i in range(1,6):
...     print(i)
...
1
2
3
4
5
```

<p class="tmp"><span>書式16</span>変化値（1以外）を指定した繰り返し</p>
<pre>
for 変数 in range(開始値,終了値,変化値):
    処理
</pre>

<p class="inpre"><span>インタプリタ</span></p>
```
>>> for i in range(1,10,2):
...     print(i)
...
1
3
5
7
9
```

<dl>
    <dt>reversed関数とは</dt>
    <dd>リストの末尾から順に要素を取り出して変数に代入し、指定した処理を行うという動作を繰り返す関数。<br>
for文とreversed関数を組み合わせると、リストを逆順に取り出すことができます。</dd>
</dl>

<p class="inpre"><span>インタプリタ</span></p>
```
>>> fruit = ['apple', 'banana', 'coconut']
>>> for f in <span class="red">reversed</span>(fruit):
...     print(f)
...
coconut
banana
apple
```




・for文やwhile文のelse部

<p class="tmp"><span>書式17</span>for～else～</p>
<pre>
for 変数 in リスト
    処理A
else:
    処理B
</pre>

<p class="tmp"><span>書式18</span>while～else～</p>
<pre>
while 式:
    処理A
else:
    処理B
</pre>

<p class="indent-01">※なぜelseを使うか～不適切なデータを見つけたら繰り返しを中止するといった場合、繰り返しが最後まで無事に実行できたときに限ってelseの処理を実行することができるようになります。</p>

<p class="inpre"><span>インタプリタ</span>合格の場合</p>
```
>>> score = [80, 100, 90]
>>> for s in score:
...     if s < 70:
...         break
... else:
...     print('合格')
...
合格
```

<p class="inpre"><span>インタプリタ</span>不合格の場合</p>
```
>>> score = [80, 60, 90]
>>> for s in score:
...     if s < 70:
...         break
... else:
...     print('合格')
...
>>>   <span class="comment"># 途中で繰り返しを中止するので表示なし</span>
```

<dl>
    <dt>pass文</dt>
    <dd>何もしない文です。Pythoneの文法上、必ず何らかの処理を書かなければいけない箇所があります。<br>
例えば、for文、while文、if文において処理の部分を省略することはできません。少なくとも一行は処理を書く必要があります。<br>
これらの制御構造が不要になったけれども、また後で制御構文自体は使うかもしれないので残しておきたいという状況が生じることがあります。<br>
こういったときに、元の処理をpass文に置き換えれば、制御構文は残したままで、何もしないプログラムにることができます。</dd>
</dl>

<p class="inpre"><span>インタプリタ</span></p>
```
>>> stage = 1
>>> while stage <= 8:
...     print(stage)
...     if stage == 4:
...         <span class="bold red">pass</span>
...     stage += 1
...
1
2
3
4
5
6
7
8
```


