<?php

namespace SocymSlim\SlimMiddle\Services;

use SocymSlim\SlimMiddle\Config\AppConfig;
// use SocymSlim\SlimMiddle\Services\Markdown\ParsedownFactory;
use SocymSlim\SlimMiddle\Factory\ParsedownFactory;
use SocymSlim\SlimMiddle\Services\Markdown\HtmlSanitizer;
use SocymSlim\SlimMiddle\Services\Markdown\HtmlPathRewriter;

use PDO;//テスト


class MarkdownService
{
    private EditService $editService;
    private AppConfig $config;
    private ParsedownFactory $parserFactory;
    private HtmlSanitizer $sanitizer;
    private HtmlPathRewriter $pathRewriter;

    public function __construct(
        EditService $editService,
        AppConfig $config,
        ParsedownFactory $parserFactory,
        HtmlSanitizer $sanitizer,
        HtmlPathRewriter $pathRewriter
    ) {
        $this->editService   = $editService;
        $this->config        = $config;
        $this->parserFactory = $parserFactory;
        $this->sanitizer     = $sanitizer;
        $this->pathRewriter  = $pathRewriter;
    }

    //-----------------------------//
    //   マークダウンをHTMLに変換   
    //----------------------------//

    public function getMarkdownData(array $folderObj, string $folderName, bool $viewFlag): array
    {     
        // 対象フォルダが存在するか確認
        if (empty($folderObj[$folderName])) {
            return [
                'success' => false,
                'html' => '', 
                'title' => '',
                'message' => 'ページが存在しません。',
            ];
        }

        $folderPath = str_replace('..', '', $folderObj[$folderName]);
        $markdownFile = $this->config->rootPath . $folderPath . '/markdown.md';

        if (!file_exists($markdownFile)) {
            return [
                'success' => false,
                'html' => '',
                'title' => '',
                'message' => 'Markdownファイルが見つかりません。',
                'updateDay' => ''//追加
            ];
        }
            
        $md = file_get_contents($markdownFile);

        // ページタイトルを抽出
        preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
        $title = $ArrayTitle[1] ?? '';
        
        // 更新日
        $updateDay = '';

        if (preg_match("/^\*\[update-day\]:\s*(.+)/m", $md, $ArrayDay)) {
            $updateDay = trim($ArrayDay[1]) ?? '';
        }
        
        // // page-title取得 追加
        // preg_match('/^\*\[page-title\]:\s*(.+)$/m', $md, $matchTitle);
        // $title = $matchTitle[1] ?? '';

        // // category取得　追加
        // preg_match('/^\*\[sub-category\]:\s*(.+)$/m', $md, $matchCategory);
        // $subCategory = $matchCategory[1] ?? '';


        if (!$viewFlag) {
            return [
                'success' => false,
                'html' => '', 
                'title' => $title,
                'message' => '権限がないと閲覧できないページです。',
                'updateDay' => ''//追加
            ];
        }
        
        $parser = $this->parserFactory->create();
            
        // HTML変換
        $htmlData = $parser->text($md);
        //スクリプトタグなど除去
        $htmlData = $this->sanitizer->sanitize($htmlData);
        //src、hrefのパスを生成
        $htmlData = $this->pathRewriter->rewrite($htmlData, $folderPath);

        return [
            'success' => true,
            'html' => $htmlData,
            'title' => $title,
            'updateDay' => $updateDay//追加
            // 'subCategory' => $subCategory,//追加
        ];
    }
    
 
    
    // //------------------------------
    // //  検索結果用 マークダウン変換
    // //------------------------------

    // public function markSearch(array $mdArray, string $word, bool $fullText){
        
    //     // $pattern = '/'.$word.'/';
    //     $parser = $this->parserFactory->create();
    //     $pattern = '/' . preg_quote($word, '/') . '/';
        
    //     $wordNum = 0;
    //     $htmlData = '';
        
    //     foreach($mdArray as $val){

    //         $dirNonum = preg_replace('/\/\d{3}./','/',$val['dir']).'/';
    //         $dirNonum = preg_replace('/\.\.\//','',$dirNonum);

    //         //ページタイトル markdown.mdの先頭にあるpage-titleの値を、$ArrayTitleに格納。
    //         preg_match("/^\*\[page-title\]:\s*(.+)/", $val['md'], $ArrayTitle);

    //         if(!empty($ArrayTitle[1])){
    //             $title = $ArrayTitle[1];//ページタイトル
    //         }else{
    //             $title = '';
    //         }

    //         $html = $this->parser->text($val['md']);
    //         $text = strip_tags($html,"<pre><code>");//<pre><code>は残す
    //         $getWord = null;

    //         if($fullText){
    //             //全文検索
    //             if(preg_match_all($pattern, $text, $getWord)){
    //                 $sumWord = array_unique($getWord[0]);

    //                 if($fullText){
    //                     foreach ($sumWord as $value) {
    //                         $patternDiff = '/'.$value.'/';
    //                         $text = preg_replace($patternDiff, '<mark class="hilight">'.$value.'</mark>', $text);//検索文字にマークを付ける
    //                     }    
    //                 }

    //                 $htmlData = $htmlData.'<section><h3><a href="'.$dirNonum.'" >'.$title.'</a></h3><div class="search-text">'.$text.'</div></section>';
    //                 $wordNum++;
    //             }
    //         } else {
    //             //タイトル検索
    //             $htmlData = $htmlData.'<section><h3><a href="'.$dirNonum.'" >'.$title.'</a></h3><div class="search-text">'.$text.'</div></section>';
    //             $wordNum++;
    //         }
    //     }

    //     return [
    //         'html' =>
    //             '<p id="search-number">「' . $word . '」の検索結果：' .
    //             '<span id="word-num">' . $wordNum . '</span>ページ</p>' .
    //             $htmlData
    //     ];
    // }
    
    
    //------------------------------
    //  プレビュー用 マークダウン変換
    //------------------------------       
    public function getPreviewMarkData(array $folderObj): array
    {
        // $basePath = $this->config->basePath;

        $md = $_REQUEST['report-p']; //記事原文
        $title = $_REQUEST['pagename-p']; //タイトル
        $folderPath = $_REQUEST['folderPath-p']; //パス
        $folderName = $_REQUEST['folder-p']; //フォルダ名

        $folderPath = $folderObj[$folderName];
        $folderPath1 = str_replace('..', '', $folderPath);

        $parser = $this->parserFactory->create();
        $htmlData = $parser->text($md);       
        $htmlData = $this->pathRewriter->rewrite($htmlData, $folderPath);

        return [
            'html'  => $htmlData,
            'title' => $title,
        ];
    }
    
    

    //---------------------------
    //  マークダウン変換のみ
    //---------------------------

    public function convertToText(string $md): string
    {
        $parser = $this->parserFactory->create();
        $html = strip_tags($parser->text($md));
                
        $html = preg_replace('/^\s*[\r\n]+/m', '', $html);
        
        return $html;        
    }
    
    
    
    //-------------------------------------------------------
    //  page_list（DB）からタイトルまたは本文内テキストから検索
    //-------------------------------------------------------

    public function searchKeyword(string $keyword, array $searchObj, bool $fullText, array $lockArray, string $pageArea, string $category = ''): array
    {
        $db = $this->editService->db();

        $lockKeys = array_keys($lockArray);
        
        $sql = "SELECT * FROM page_list WHERE page_area = :pageArea AND text LIKE :keyword";
        
        $params = [
            ':pageArea' => $pageArea,
            ':keyword' => '%' . $keyword . '%'
        ];

        // lock除外 
        if (!empty($lockKeys) && !isset($_SESSION['auth_user']['name'])) {
            $placeholders = [];

            foreach ($lockKeys as $i => $val) {
                $ph = ":lock{$i}";
                $placeholders[] = $ph;
                $params[$ph] = $val;
            }

            $sql .= " AND fdName NOT IN (" . implode(',', $placeholders) . ")";
        }

        $sql .= " ORDER BY page_id";

        $stmt = $db->prepare($sql);

        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val, PDO::PARAM_STR);
        }

        $stmt->execute();

        $pattern = '/' . preg_quote($keyword, '/') . '/i';

        $htmlData = '';
        $count = 0;
        
        // カテゴリーが選択されている場合は、そのパスを取得 追加
        $categoryPath = '';

        if ($category !== '' && isset($searchObj[$category])) {
            $categoryPath = rtrim(str_replace('\\', '/', $searchObj[$category]), '/');
        }

        while ($row = $stmt->fetch()) {

            if (!isset($searchObj[$row['fdName']])) {
                continue;
            }

            $folderDir = $searchObj[$row['fdName']];
            
            // カテゴリーが選択されている場合は配下のページだけに絞る 追加
            if ($category !== '') {
                // カテゴリーが存在しない場合は対象外
                if ($categoryPath === '') {
                    continue;
                }

                $normalizedFolderDir = rtrim(
                    str_replace('\\', '/', $folderDir),
                    '/'
                );

                // カテゴリー自身、またはその配下のページかを判定
                if (
                    $normalizedFolderDir !== $categoryPath
                    && strpos($normalizedFolderDir, $categoryPath . '/') !== 0
                ) {
                    continue;
                }
            }
            
            $text = $row['text'];
            $title = trim($row['title']);

            $dirNonum = preg_replace('/\/\d{3}./', '/', $folderDir) . '/';
            $dirNonum = preg_replace('/\.\.\//', '', $dirNonum);

            if ($fullText) {
                $text = preg_replace(
                    $pattern, 
                    '<mark class="hilight">' . $keyword . '</mark>', 
                    $text
                );
            }

            $count++;

            $htmlData .= '<section>' .
                    '<h3><a href="' . $dirNonum . '">' . htmlspecialchars($title) . '</a></h3>' .
                    '<div class="search-text">' . $text . '</div>' .
                '</section>';
        }

        $htmlData = '<p id="search-number">「' . $keyword . '」の検索結果：<span id="word-num">' . $count . '</span>ページ</p>' . $htmlData;

        return [
            'html' => $htmlData
        ];
    }
    
    
    
    //-------------------------------------------------------
    //  page_list（DB）を更新
    //-------------------------------------------------------

    public function updatePageText( PDO $db, string $fdName, string $md, string $pageArea ): void {

        $text = $this->convertToText($md);

        $sql = " UPDATE page_list SET text = :text WHERE fdName = :fdName AND page_area = :pageArea";
        // $sql = " UPDATE page_list SET text = :text WHERE fdName = :fdName ";

        $stmt = $db->prepare($sql);

        $result = $stmt->execute([
            ':text'   => $text,
            ':fdName' => $fdName,
            ':pageArea' => $pageArea
            
        ]);

        if (!$result) {

            throw new \RuntimeException(
                'page_list 更新に失敗しました'
            );
        }

    }     

}
