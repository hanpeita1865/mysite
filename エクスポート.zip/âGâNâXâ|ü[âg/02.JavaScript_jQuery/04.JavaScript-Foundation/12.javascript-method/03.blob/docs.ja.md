---
title: blob
---

## 参考サイト

* [Blobの使い方とダウンロード・保存方法まとめ！](https://www.sejuku.net/blog/67735)