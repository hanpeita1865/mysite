*[page-title]:置換 replace()

参考サイト
: [【JavaScript入門】replaceの文字列置換・正規表現の使い方まとめ！](https://www.sejuku.net/blog/21107)

## 「replace」の使い方

<p class="tmp"><span>書式</span></p>
```
文字列.replace( 対象の文字, 置換する文字 );
```

文字列を用意して、「_（アンダーバー）」を「-（ハイフン）」に置換してみます。
```
var str = 'user_123';
var result = str.replace( '_', '-' );
 
console.log( result );
```

<p class="result"><span>実行結果</span></p>
```
user-123
```