---
title: '05. ''条件式 if文 switch文'''
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">if文</h2>


「もし条件に合っているなら処理を行う」という条件分岐の方法のひとつに、if文と呼ばれるものがあります。

<p class="tmp"><span>書式1</span></p>
```
if( 条件式 ){ 処理 }
	条件に合致していれば、中カッコ内の処理を行う
```

条件式のところでは、比較演算子と呼ばれる記号を使って条件を記述します。  
代表的な比較演算子には、以下のようなものがあります。

|演算子|意味|演算子|意味|
|::|::|::|::|
|==|式が等しい|!=|式が等しくない|
|>|左が大きい|>=|左が等しいか大きい|
|<|右が大きい|<=|右が大きいか等しい|

### if文の例

<iframe width="100%" height="200" src="//jsfiddle.net/xa4deuy1/3/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

答えは「50より大きいです。」と表示されます。  
変数num3には5×12つまり60が入っているからです。  
条件に合っているのは一番下だけです。  
条件に合っていないものは、中括弧内の処理が行われません。

---

<h2 class="h-type2">if～else文</h2>

条件に合っているかどうかによって別々の処理を行う方法に、if～else文があります。

<p class="tmp"><span>書式2</span></p>
```
if ( 条件式 ){ 処理1 } else { 処理2 }
	条件式に合致している場合、処理1を実行します
	条件式に合致しない場合、処理2を実行します
```

### if～else文の例

<iframe width="100%" height="220" src="//jsfiddle.net/xa4deuy1/6/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

答えは「３より大きいです。」となります。  
変数numには5が入っているので、条件式「 n < 3 」には当てはまりません。  
その結果、else以下の処理が行なわれる訳です。

---

<h2 class="h-type2">switch文</h2>

条件分岐のif文は、「条件に合っている」「条件に合っていない」の2種類にしか分岐できません。  
これ以上分岐させるには、if文を何重にも重ねて書く必要がありますが、switch文を使えば一回で何通りにも分岐させることができます。

<p class="tmp"><span>書式3</span></p>
```
switch ( 式 ) {
//式が値と合致したときに処理を行い、どれにも合致しなかった場合defaultの処理を行う。

case 値1 :
	処理;
	break;

case 値2 :
	処理;
	break;

default :
	処理;
	break;
}
```

### switch文の例

<!--
<iframe width="100%" height="420" src="//jsfiddle.net/xa4deuy1/11/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>-->

<iframe width="100%" height="420" src="//jsfiddle.net/hirao/vg80pw4n/2/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


出力結果は「今日は雨です！」となります。  
この例では、変数「weather」に「雨」を代入しているため、caseが「雨」と書かれた箇所の処理を実行することになります。  
つまり、「weather」の値が変わることで、実行する処理を変えられるプログラムをシンプルに実装できるわけです。