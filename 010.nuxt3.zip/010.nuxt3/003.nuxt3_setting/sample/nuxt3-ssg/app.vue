<template>
  <!-- メニュー -->
  <ul>
    <li>
      <NuxtLink to="/">Index</NuxtLink>
    </li>
    <li>
      <NuxtLink to="/about">About</NuxtLink>
    </li>
  </ul>

  <!-- ページ内容の表示 -->
  <NuxtPage />
</template>