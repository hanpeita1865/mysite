<?php
$database='heyawake';
$user='staff';
$password='password';

$pdo=new PDO('mysql:host=localhost:3306;dbname='.$database.';charset=utf8',$user, $password);
?>

