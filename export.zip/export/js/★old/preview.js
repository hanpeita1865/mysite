//初期表示でクッキーからスクロール位置を取得して設定する
let scrollVal = 0;

cookieGet();

const cookieExist = document.cookie.indexOf('previewScroll');
const headingVal = $('h1').text();//h1見出し値

if (cookieExist !== -1) {
    //Cookieがある
    cookieGet();

    if (titleVal == headingVal) {//プレビューページのタイトルとCookieに保存したタイトルが一致
        //スクロール位置の設定
        $(window).scrollTop(scrollVal);
    }
}

//cookieの値を取得
function cookieGet() {
    //データを1つずつに分ける
    let cookieArray = document.cookie.split(';');
    let scrollTop = cookieArray.filter(value => value.split('=')[0].match(/previewScroll/));
    let pageTitle = cookieArray.filter(value => value.split('=')[0].match(/previewTitle/));

    scrollVal = scrollTop.map(function (value) {
        return value.split('=')[1];
    });

    titleVal = pageTitle.map(function (value) {
        return value.split('=')[1];
    });

    scrollVal = Number(scrollVal);
}


//スクロールの位置とページタイトルをクッキーに保存
$(window).on("scroll", function () {
    let scrollPos = $(window).scrollTop(); //トップからの位置
    let pageTitle = $('h1').text();//ページタイトル
    
    document.cookie = 'previewScroll=' + scrollPos +'; max-age=43200';//半日（12時間）後に削除
    document.cookie = 'previewTitle=' + pageTitle + '; max-age=43200';// 〃
});