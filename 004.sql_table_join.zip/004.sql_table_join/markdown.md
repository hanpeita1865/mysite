*[page-title]:テーブル結合

参考サイト
:  [JOINによるテーブルの結合方法５種類を整理](https://mathwords.net/tablejoin)



## 3つのテーブルを結合

### 複数のテーブルを結合するSQLの書き方

<p class="tmp"><span>書式1</span></p>
```
SELECT *
FROM 表1 LEFT OUTER JOIN 表2 ON 条件1   /*表1と表2を結合*/
LEFT OUTER JOIN 表3 ON 条件2　          /*表1と表2を結合したテーブルと、表3を結合*/
```

<div class="exp">
	<p class="tmp"><span>例1</span></p>
</div>

```
SELECT * FROM register LEFT OUTER JOIN personal ON register.id=personal.e_id 
LEFT OUTER JOIN local_base ON work_location=id_local 
where register.id=2 

/*1行目 テーブルregisterとテーブルpersonalを結合*/
/*2行目 上記で先に結合したテーブルと、テーブルlocal_baseを結合*/
/*3行目 テーブルregisterのid=2がある行を表示*/
```

## JOINによるテーブルの結合方法の整理

* 内部結合：共通部分だけをとってくる
* 左外部結合：左にあるものを全部とってくる
* 右外部結合：右にあるものを全部とってくる
* 完全外部結合：どちらかにあれば全部とってくる


![](upload/tablejoin1-228x300.png)

「table1」と「table2」のテーブルを準備して、それぞれの結合方法と結果を見てみましょう。


<div class="d-flex justify-content-around" markdown="1">
<div markdown="1">
##### table1 {.t-caption}
|name|age|
|--|--|
|Aさん|20|
|Bさん|30|
|Cさん|40|
|Dさん|50|
</div>
<div markdown="1">
##### table2 {.t-caption}
|name|income|
|--|--|
|Aさん|300|
|Eさん|500|
</div>
</div>


### 内部結合（INNER JOIN）

「両方のテーブルにある行」のみを取り出して結合することを内部結合と言います。

<p class="tmp"><span>書式2</span>内部結合</p>
```
SELECT * FROM 表1 INNER JOIN 表2 ON 表1.名前 = 表2.名前
```

<div class="exp">
	<p class="tmp"><span>例2</span>「table1」と「table2」の「name」をキーにして内部結合</p>
</div>
```
SELECT * FROM table1 INNER JOIN table2 ON table1.name = table2.name
```
|name|age|name|income|
|--|--|--|--|
|Aさん|20|Aさん|300|

```
/*表示するカラムを指定*/
SELECT table1.name,table1.age,table2.income 
FROM table1 INNER JOIN table2 ON table1.name = table2.name
```
|name|age|income|
|--|--|--|
|Aさん|20|300|


または　where句を使って結合することもできます。
```
SELECT * FROM table1,table2 WHERE table1.name = table2.name

/*表示するカラムを指定*/
SELECT table1.name,table1.age,table2.income 
FROM table1,table2 WHERE table1.name = table2.name
```
「INNER JOIN」と同じ結果が得られます。





### 左外部結合（LEFT OUTER JOIN）

「１つ目のテーブルにある行」を全て取り出して結合することを左外部結合と言います。

<p class="tmp"><span>書式3</span>左外部結合</p>
```
SELECT * FROM 表1 LEFT OUTER JOIN 表2 ON 表1.名前 = 表2.名前
```

<div class="exp">
	<p class="tmp"><span>例3</span>「table1」と「table2」の「name」をキーして左外部結合</p>
</div>

```
SELECT * FROM table1 LEFT OUTER JOIN table2 ON table1.name = table2.name
```
|name|age|name|income|
|--|--|--|--|
|Aさん|20|Aさん|300|
|Bさん|30|NULL|NULL|
|Cさん|40|NULL|NULL|
|Dさん|50|NULL|NULL|


### 右外部結合（RIGHT OUTER JOIN）

「２つ目のテーブルにある行」を全て取り出して結合することを右外部結合と言います。

<p class="tmp"><span>書式4</span>右外部結合</p>
```
SELECT * FROM 表1 RIGHT OUTER JOIN 表2 ON 表1.名前 = 表2.名前
```


<div class="exp">
	<p class="tmp"><span>例4</span> 「table1」と「table2」の「name」をキーして右外部結合</p>
</div>

```
SELECT * FROM table1 RIGHT OUTER JOIN table2 ON table1.name = table2.name
```

|name|age|name|income|
|--|--|--|--|
|Aさん|20|Aさん|300|
|NULL|NULL|Eさん|500|



## 二つのテーブルのデータを更新

まず、登録してるテーブルをそれぞれ表示させてみます。

[新規タブ](sample/all/index.php)

<iframe width="100%" height="650" src="sample/all/index.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

##### all/index.php
```
<!DOCTYPE html>
<head>
    <style>
        table {
            width: 300px;
            border: 1px solid #555;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th,td {
            border: 1px solid #555;
        }
        td {
            text-align: right;
        }
    </style>
</head>
<table>
<caption>fruitテーブル</caption>
<tr><th>id</th><th>name</th></tr>
<?php
$pdo=new PDO('mysql:host=localhost;dbname=join_test;charset=utf8', 'root', '');

foreach ($pdo->query('select * from fruits') as $row) {
    echo '<tr>';
    echo '<td>'.$row['id'].'</td>';
    echo '<td>'.$row['name'].'</td>';
    echo '</tr>';
}
?>
</table>

<table>
<caption>priceテーブル</caption>
<tr><th>fruit_id</th><th>price</th></tr>
<?php
foreach ($pdo->query('select * from price') as $row) {
    echo '<tr>';
    echo '<td>'.$row['fruit_id'].'</td>';
    echo '<td>'.$row['price'].'</td>';
    echo '</tr>';
}
?>
</table>


<table>
<caption>fruitとpriceのテーブルを結合</caption>
<tr><th>id</th><th>name</th><th>price</th></tr>

<?php
foreach ($pdo->query('SELECT * FROM fruits LEFT OUTER JOIN price ON fruits.id=price.fruit_id') as $row) {
    echo '<tr>';
    echo '<td>'.$row['id'].'</td>';
    echo '<td>'.$row['name'].'</td>';
    echo '<td>'.$row['price'].'</td>';
    echo '</tr>';
}
?>
</table>
```

では、データを更新します。  
update/index.phpに接続すると、以下のデータが更新されます。
```
$dataUp[] = '柿';
$dataUp[] = '80';
$dataUp[] = '2';
```

[新規タブ](sample/update/index.php)

##### update/index.php
```
<?php
$pdo=new PDO('mysql:host=localhost;dbname=join_test;charset=utf8', 'root', '');

    
$query =
    'UPDATE fruits
        INNER JOIN
            price
            ON fruits.id=price.fruit_id
        SET
            fruits.name = ?,
            price.price = ?
        WHERE
            fruits.id = ?';

$sql=$pdo->prepare($query);

$dataUp[] = '柿';
$dataUp[] = '80';
$dataUp[] = '2';

$sql->execute($dataUp);

echo '更新しました';

?>

```












