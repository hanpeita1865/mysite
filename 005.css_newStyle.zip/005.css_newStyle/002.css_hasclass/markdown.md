*[page-title]::has()疑似クラス

参考サイト
: [朗報！ CSSの:has()疑似クラスがすべてのブラウザにサポートされました、:has()疑似クラスの便利な使い方のまとめ](https://coliss.com/articles/build-websites/operation/css/css-has-pseudo-class.html)
: [CSSの:has()疑似クラスの便利な使い方を徹底解説](https://coliss.com/articles/build-websites/operation/css/has-pseudo-class.html)

CSSの:has()疑似クラスは便利そうだけどブラウザのサポートがまだ、と見送っていた人に朗報です。12/19にリリースされたFirefox 121（リリース情報）でサポートされ、これで:has()疑似クラスがすべてのブラウザにサポートされました。

そんな:has()疑似クラスの便利な使い方を紹介します。

## :has()疑似クラスの基礎知識
CSSの:has()疑似クラスとは、指定した要素がある場合にのみスタイルを適用できるCSSの新機能です。

今までのCSSでは、要素の存在のあり・なしによって特定の親や要素にスタイルを設定することは不可能でした。あり用となし用のクラスを作成し、必要なバリエーションに応じて切り替える必要がありました。

今までのCSSでは、下記のように2つのクラスを作成して実装します。

<p class="lang">CSS</p>
```
/* 画像あり用のスタイル */
.card {
    display: flex;
    align-items: center;
    gap: 1rem;
}
 
/* 画像なし用のスタイル */
.card--plain {
    display: block;
    border-top: 3px solid #7c93e9;
}
```

<p class="lang">HTML</p>
```
<!-- 画像ありのカード -->
<div class="card">
    <div class="card__image">
        <img src="awameh.jpg" alt="">
    </div>
    <div class="card__content">
        <!-- Card content here -->
    </div>
</div>
 
<!-- 画像なしのカード -->
<div class="card card--plain">
    <div class="card__content">
        <!-- Card content here -->
    </div>
</div>
```

画像なしにはFlexboxが必要ないため、なし用とあり用の2つのバリエーションのクラスを作成しました。このような場合にバリエーションのクラスを作成しないで、CSSで条件式のように定義できるとしたら、どう思いますか。

ここで、CSSの:has()の出番です！  
:has()を使用すると、`.card`要素の中に`.card__image`があるかどうかをチェックできます。

たとえば、カードに画像があるかどうかをチェックし、ある場合にはFlexboxで配置できます。

<p class="lang">CSS</p>
```
.card:has(.card__image) {
    display: flex;
    align-items: center;
}
```


## :has()疑似クラスの基本的な使い方
:has()疑似クラスを使用すると、子の数に基づいて親要素のスタイルを設定できます。

<p class="lang">CSS</p>
```
/* 最大3個の子（0を除く3以下） */
ul:has(> :nth-child(-n+3):last-child) {
	outline: 1px solid red;
}
 
/* 最大3個の子（0を含む3以下） */
ul:not(:has(> :nth-child(3))) {
	outline: 1px solid red;
}
 
/* ちょうど5個の子 */
ul:has(> :nth-child(5):last-child) {
	outline: 1px solid blue;
}
 
/* 10個以上の子 */
ul:has(> :nth-child(10)) {
	outline: 1px solid green;
}
 
/* 7～9個の子（境界を含む） */
ul:has(> :nth-child(7)):has(> :nth-child(-n+9):last-child) {
	outline: 1px solid yellow;
}
```

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	<iframe height="500" style="width: 100%;" scrolling="no" title="Styling parent elements based on the number of children with CSS :has()" src="https://codepen.io/coliss/embed/eYXOvQy?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/coliss/pen/eYXOvQy">
  Styling parent elements based on the number of children with CSS :has()</a> by coliss (<a href="https://codepen.io/coliss">@coliss</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
</div>

## フォームの実装
フォームはCSSでスタイルするのが難しいことで知られています。たとえば、入力欄とそのラベルのスタイルです。入力が有効であることを示すにはどうすればよいでしょうか？

:has()疑似クラスを使用すると、これが非常に簡単になります。:validや:invalidなど、関連するフォームの疑似クラスをフックにできます。

<p class="lang">HTML</p>
```
<div class="form-group">
  <label for="email" class="form-label">Email</label>
  <input
    required
    type="email"
    id="email"
    class="form-input"
    title="Enter valid email address"
    placeholder="Enter valid email address"
  />   
</div>
```

<p class="lang">CSS</p>
```
label {
  color: var(--color);
}
input {
  border: 4px solid var(--color);
}

.form-group:has(:invalid) {
  --color: var(--invalid);
}

.form-group:has(:focus) {
  --color: var(--focus);
}

.form-group:has(:valid) {
  --color: var(--valid);
}

.form-group:has(:placeholder-shown) {
  --color: var(--blur);
}
```


<div class="exp">
	<p class="tmp"><span>例2</span></p>
	<iframe height="300" style="width: 100%;" scrolling="no" title=":has some &lt;input&gt;" src="https://codepen.io/coliss/embed/MWxgoYR?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/coliss/pen/MWxgoYR">
  :has some &lt;input&gt;</a> by coliss (<a href="https://codepen.io/coliss">@coliss</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>
</div>


さらに、:has()疑似クラスを使用して、エラーメッセージを表示・非表示することもできます。Emailのフィールドグループを使用して、エラーメッセージを追加してみます。

<p class="lang">HTML</p>
```
<div class="form-group">
  <label for="email" class="form-label">
    Email
  </label>
  <div class="form-group__input">
    <input
      required
      type="email"
      id="email"
      class="form-input"
      title="Enter valid email address"
      placeholder="Enter valid email address"
    />   
    <div class="form-group__error">Enter a valid email address</div>
  </div>
</div>
```

デフォルトでは、エラーメッセージを非表示にします。
```
.form-group__error {
  display: none;
}

.form-group__error {
  display: none;
}
```

そしてフィールドが:invalidになり、かつフォーカスされていない場合、追加のクラス名を必要とせずにメッセージを表示できます。
```
.form-group:has(:invalid:not(:focus)) .form-group__error {
  display: block;
}
```

実際の動作は、デモをご覧ください。

<div class="exp">
	<p class="tmp"><span>例3</span></p>
	<p class="codepen" data-height="400" data-default-tab="html,result" data-slug-hash="eYXORmw" data-user="coliss" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/coliss/pen/eYXORmw">
  This form shows and hides its error messages</a> by coliss (<a href="https://codepen.io/coliss">@coliss</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>
</div>

<a href="sample/hasclass1/" target="_blank">新規タブ</a>