*[page-title]:PHP基本学習用


### 目次
<div markdown="1" class="page-mokuji auto-mokuji">
</div>
