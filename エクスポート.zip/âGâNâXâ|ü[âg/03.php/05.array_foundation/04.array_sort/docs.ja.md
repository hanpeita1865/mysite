---
title: 配列の並べ替え
taxonomy:
    category:
        - docs
---

sort関数で昇順に並び替え

<iframe src="https://paiza.io/projects/e/kg3198negPuS60rMlHNpzQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


rsort関数で降順に並び替え

<iframe src="https://paiza.io/projects/e/NG5vkxuKzaRJUCJXnWd6Iw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## 連想配列の要素をソート

asort関数で値を昇順に並び替え

<iframe src="https://paiza.io/projects/e/KTFQgSCRMZ0mJ9-uKicqsA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

※連想配列を並び替えたい場合はこのasortか後述するarsort関数で並び替えないとキーが壊れてしまうという問題があります。


arsort関数で値を降順に並び替え

<iframe src="https://paiza.io/projects/e/QaVCOqdBhDP2Mp0ni-aPqw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

こちらも連想配列のキーを壊すことなく値で降順に並び替えることができました！


## 配列のキーをもとにソート

ksort関数で値を昇順に並び替え

この章では配列のキーをもとにして要素を並び替えます。

<iframe src="https://paiza.io/projects/e/x9M4keru7j8anD53X_60RA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

このサンプルでは最初の配列で要素番号が0からではなく3，0・・・と不規則な並びになっています。  
そこでksort関数を使うと配列の要素番号を昇順に並べるため0，1，2・・・と要素番号を昇順で規則的に並び替えることができます。


krsort関数で値を降順に並び替え

先程は配列のキーを昇順に並べましたが今度は降順に並べてみます。  
関数名が変わるだけでこちらも使い方は今までの関数と何らかわりません。

<iframe src="https://paiza.io/projects/e/b2S_qEk2EGaJ-OdIalFDFA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

先ほどとは逆でしっかり要素番号が降順になりました


## 配列の要素をshuffle関数でランダムにソート

先程までは配列の値やキーについて昇順・降順と規則正しい並び替え方をしてきました。

今回はshuffle関数を使ってランダムに並び替えてみたいと思います。

<iframe src="https://paiza.io/projects/e/pfTBK4kG8INoTEmeE2M6KA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## usort関数の使い方

phpの配列の中身を並び替える関数はいくつかあります。自分で指定した意図通りに並び替えることができるusort関数というものがあります。


* 自分で指定した順番で配列の中身を並び替えることができる
* 順番の指定はコールバック関数で行う

<p class="tmp"><span>書式1</span></p>
```
usort(第一引数に配列、第二引数にコールバック関数）
```

<iframe src="https://paiza.io/projects/e/lNzkfs5cr4f4LxcgIauh-Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

```
並び替え前
0: ナゲット
1: チキンフィレオ
2: ポテト
3: ダブルチーズバーガー
4: えびフィレオ
5: コーラ

並び替え後
0: ポテト
1: コーラ
2: ナゲット
3: えびフィレオ
4: チキンフィレオ
5: ダブルチーズバーガー
```


















