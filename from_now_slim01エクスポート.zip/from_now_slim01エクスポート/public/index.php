<?php
// use DI\Container;
use Slim\Factory\AppFactory;
use Dotenv\Dotenv;

require '../admin/basepath.php';

require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/php/Parsedown.php");
require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/php/ParsedownExtra.php");
require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/vendor/autoload.php");

$dotenv = Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

$container = new \DI\Container();

// $definitions = require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/containerSetups.php");
$definitions = require $_SERVER["DOCUMENT_ROOT"] .$basePath. "/config/container/containerSetups.php";


foreach ($definitions as $key => $definition) {
    $container->set($key, $definition);
}

// Slim にコンテナを設定
AppFactory::setContainer($container);

$app = AppFactory::create();
require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/bootstrappers.php");
require_once($_SERVER["DOCUMENT_ROOT"].$basePath."/routes.php");

$app->run();



