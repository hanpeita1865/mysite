*[page-title]:パソコン

## [Windows 10] Xbox Game Barでアプリの画面を録画する方法

※うまく録画できなかった。前にアンインストールしたっぽいので、Micro Storeでダウンロードして再インストールしました。

【Windows】キーを押しながら【G】キーを押すと、Xbox Game Barが起動し、アプリの画面を録画できるようになります。

Xbox Game Bar（エックスボックス ゲーム バー）は、Windows10でプレイしているゲームの操作をコントロールできるアプリです。  
Windows 10に標準でインストールされています。

### 参考サイト

* [FUJITSU [Windows 10] Xbox Game Barでアプリの画面を録画する方法を教えてください。](https://www.fmworld.net/cs/azbyclub/qanavi/jsp/qacontents.jsp?rid=417&PID=3711-2674)

## モバイル画面サイズ
IPhone（アイフォン）、IPad（アイパッド）のサイズ表です。

![](upload/スマホ・アイパッド画面サイズ.png)

参考サイト
: [【2020年度決定版】レスポンシブデザインのブレークポイントはこれで決まり！](https://www.webdlab.com/labs/responsive-web-design-5/)

現在（2020年度）市販されている代表的な端末のCSSピクセルサイズの一覧をご紹介します。基本的にこれらの端末のCSSピクセルサイズはなるべくカバーするということを前提としました。  
下記の表はChromeとSafariの開発者モードで出てくるCSSピクセルのサイズ一覧です。
![](upload/2020年度版ブレークポイント.png "2020年度版ブレークポイント")

## スマホで表示したサイトをChromeのデベロッパーツールで確認

参考サイト
: https://webrandum.net/chrome-dev-tool-android-real-machine/

スマホとパソコンをUSBで接続します。

Chromeに以下のURLをコピペして、開きます。
```
chrome://inspect/#devices
```

次の画面が表示されるので、確認したいサイトの「incept」のリンクをクリックします。
![](upload/スマホChromeデベロッパーツールで確認1.png)

そうすると、以下のような画面が表示されるので、ここでいつものようにデベロッパーツールで確認することができます。
![](upload/スマホChromeデベロッパーツールで確認2.png)

## PC起動時に自動的にアプリを実行する設定方法

参考サイト
: [Windows 10 の起動時に自動的に実行するアプリを追加する](https://support.microsoft.com/ja-jp/windows/windows-10-%E3%81%AE%E8%B5%B7%E5%8B%95%E6%99%82%E3%81%AB%E8%87%AA%E5%8B%95%E7%9A%84%E3%81%AB%E5%AE%9F%E8%A1%8C%E3%81%99%E3%82%8B%E3%82%A2%E3%83%97%E3%83%AA%E3%82%92%E8%BF%BD%E5%8A%A0%E3%81%99%E3%82%8B-150da165-dcd9-7230-517b-cf3c295d89dd)

 [スタート]  ボタンを選択し、スクロールして、起動時に実行するアプリを見つけます。
 
 アプリを右クリックし、[その他] を選択して、[ファイルの場所を開く] を選択します。これにより、アプリのショートカットが保存されている場所が開きます。[ファイルの場所を開く] のオプションがない場合は、そのアプリを起動時に実行できないことを意味します。
 
ファイルの場所を開いた状態で、<span class="green bold">Windowsキー + R</span> キーを押し、「<span class="red bold">shell:startup</span>」と入力して [OK] を選択します。
 ![](upload/shellstartup実行.png)
これにより、[スタートアップ] フォルダーが開きます。

ファイルの場所からアプリのショートカットをコピーして、[スタートアップ] フォルダーに貼り付けます

## 「ScreenToGif」で画面をGifで録画
参考サイト
: [ScreenToGif公式サイト](https://www.screentogif.com/)
: [Windows で 画面操作を Gif で録画したいなら ScreenToGif がオススメ](https://dev.classmethod.jp/articles/introduction-screentogif/)


<div markdown="1" class="memo-box">
または、画面を録画する場合、「XBox Game Bar」がいいようです。ただし自分のパソコンはこの前アンインストールしたみたいなので、再インストールする必要があります。

参考サイト
: [Windows10標準の機能でVSCode（でなくてもよい）+マイク音声を録画する](https://blog.takeyuweb.co.jp/entry/2020/04/02/100000)
</div>


スタートアップの次のScreenToGifのショートカットアイコンをダブルクリックして、起動してください。
![](upload/SGスタートアップアイコン.png)

起動したら、左端の「レコーダー」ボタンをクリックしてください。
![](upload/起動画面.png)

この中が透明の枠が表示されます。これが録画エリアです。 録画したいウィンドウの上に ScreenToGif のウィンドウを移動やウィンドウサイズの変更してください。  
位置やサイズが決まったら録画を開始し、操作しましょう。
![](upload/録画画面範囲指定.png)

操作が完了したら停止ボタンを押してください。
![](upload/録画完了.png)

次の画面が開かれるので、再生ボタンをクリックして確認してみてください。
![](upload/再生開始.png)

これでよければ、ファイルを保存します。
![](upload/ファイル保存.png)

こうして、Gifファイルで保存されます。
![](upload/sample_gifアイコン.png)

このような感じでGifファイルは、再生されます。
![](upload/sample.gif)









