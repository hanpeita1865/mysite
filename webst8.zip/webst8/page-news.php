<?php
$paged = (int) get_query_var('paged');
$args = array(
'posts_per_page' => 5,
'paged' => $paged,
'orderby' => 'post_date',
'order' => 'DESC',
'post_type' => array('投稿タイプ１','投稿タイプ2'),
'post_status' => 'publish'
);
$the_query = new WP_Query($args);

if ( $the_query->have_posts() ) :
while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
<?php
$product_terms = wp_get_object_terms($post->ID, array('タクソノミー１','タクソノミー２','タクソノミー3'));
if(!empty($product_terms)){
if(!is_wp_error( $product_terms )){
foreach($product_terms as $term){
echo '<span class="category_tag '.$term->slug.'">'.$term->name.'</span>';
}}}
?>

<time class="post-date" datetime="<?php echo get_the_date( 'Y-m-d' ); ?>"><?php the_time( get_option( 'date_format' ) ); ?></time>

<div class="post flex">
<a href="<?php the_permalink(); ?>" class="thumbnail-box"><?php the_post_thumbnail(); ?></a>
<div class="summary">
<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
<p class="btn"><a href="<?php the_permalink(); ?>" class="thumbnail-box">READ MORE</a></p>
</div>
</div>
<?php endwhile; ?>

<?php else : ?>
<div class="post">
<h3>Not Found</h3>
<p>Sorry, but you are looking for something that isn't here.</p>
</div>
<?php endif; /** ループ終了 */ ?>
<div class="pagination">
<?php
if ($the_query->max_num_pages > 1) {
echo paginate_links(array(
'base' => get_pagenum_link(1) . '%_%',
'format' => 'page/%#%/',
'current' => max(1, $paged),
'total' => $the_query->max_num_pages
));
} ?>