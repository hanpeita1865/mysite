import { createApp } from 'vue'

import App from './App.vue'
createApp(App).mount('#app')

// App2.vueを使う場合
// import App from './App2.vue'
// createApp(App).mount('#app')