<?php
	$file = file_get_contents('foo.txt');
	var_dump($file);
?>
