const news = document.getElementById('news');
const title_link = document.querySelectorAll('.news-box a.title-link');//記事リンク
const news_tag = document.querySelectorAll('.news-box .cate-tag');//カテゴリータグ
//const tab_box = document.querySelectorAll('.tab-box li a');
const tab_btn = document.querySelectorAll('.tab-box li button');//タブボタン
const news_list = document.querySelectorAll('.news-box li');//記事リスト
const tab_wrap = document.querySelector('.tab-box');//タブ全体を囲う要素
const tab_num = document.querySelectorAll('.tab-box li button').length;//タブボタン数
//const host = 'kinki-3.ndd-sv.net';//本番用
const host = '10.203.1.68:55507';//ローカル
//const host = 'www.city.kishiwada.osaka.jp';//テスト
const hostRegexp = new RegExp(host);

//タブを切り替えるボタンにイベント登録
tab_btn.forEach(x => {
    x.addEventListener('click', tabClick);
    // x.addEventListener('keydown', focusTranslate);
});

//フォーカスの順番を制御
news.addEventListener('focus', tabIndexAdd, true);
news.addEventListener('blur', tabIndexRemove, true);

//表示するタブを切り替える
function tabClick(e) {
    
    //現在表示中のタブを非アクティブ
    document.querySelector('.tab-box li button[aria-selected="true"]').setAttribute('aria-selected', false);

    //const data_id = this.dataset.id;//タブを切り替えるボタンのdata-idを取得
    const tab_id = this.getAttribute('id');
    document.querySelector('.news-box').setAttribute('aria-labelledby', tab_id);
    
    //クリックしたボタンに対応したタブを表示
    this.setAttribute('aria-selected', true);

    const lists = Array.from(tab_btn);
    const num = lists.findIndex(list => list === e.target)+1;

    //記事表示切替
    if (e.target.textContent == 'すべて') {
        news_list.forEach(function (v) {
            v.classList.remove('d-none');
            console.log(num);
            title_link.tabIndex = num;
        })
    } else {
        news_tag.forEach(function (t) {
            if (t.getAttribute('data-category') != e.target.textContent) {
                t.closest('.news-box li').classList.add('d-none');
            }
        })
    }
    title_link.forEach(e => e.tabIndex = num);
}

//リンクパス修正
title_link.forEach(function (elm) {
    let href = elm.getAttribute('href');
    let host_match = hostRegexp.test(href);//当サイトのホストと一致するか判定

    //hrefが空のaはリンクを取る
    if (href == '') {
        let inner = elm.innerHTML;
        elm.replaceWith(inner);
    }

    //外部リンクには、「target="_blank"」を付け、ページ遷移リンクには、iframe親要素に表示させる「target="_parent"」を使用。
    if (/^http|^https/.test(href) && host_match==false) {
        //外部リンク
        elm.setAttribute('target', '_blank');
    } else if(document.querySelector('.tab-box')!=null && /.html$/.test(href)) {
        //トップ用　お知らせ サイト内ページ
        elm.setAttribute('target', '_parent');
    } else if(document.querySelector('.frame-box1')!=null && /.html$/.test(href)){
        //トップページ用　重要なお知らせ　サイト内ページ
        elm.setAttribute('target', '_parent');
    }
})

//タブクリックで記事表示切り替え
tab_box.forEach(function (elm) {
    elm.addEventListener('click', function (e) {
        //タブアクティブ化
        tab_box.forEach(function (s) {
            s.closest('button').classList.remove('active');
        })

        e.target.closest('button').classList.add('active');

        //記事の表示切り替え
        news_tag.forEach(function (t) {
            if(e.target.textContent=='すべて'){
                t.closest('.news-box li').classList.remove('d-none');
            }else if(t.getAttribute('data-category') != e.target.textContent) {
                t.closest('.news-box li').classList.add('d-none');
            }else{
                t.closest('.news-box li').classList.remove('d-none');
            }
        })

		//お知らせ　高さ調整
        const frame_box = document.querySelector('.sugu-window');		
        let frameHeight = frame_box.clientHeight;		
        let frameData3 = {
            height3: frameHeight	
        }

        window.parent.postMessage(frameData3, "http://10.203.1.68:55508/");//トップページへ（ローカル用）
        //window.parent.postMessage(frameData3, "https://kinki-3-static.ndd-sv.net/");//トップページへ（本サイト用）
    });
});