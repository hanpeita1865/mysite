<?php
   date_default_timezone_set('Asia/Tokyo');//日本時間にセット
   $dateTime = date('Y-m-d_H.i.s');

   function dirBackup($ptn) {

       global $dateTime;

       // 指定されたディレクトリ内の一覧を取得
       $res = glob($ptn.'/*');

       // 一覧をループ
       foreach ($res as $f) {
           $fcopy = str_replace('../pages','../pages_backup/'.$dateTime,$f);

           if (!is_file($f)) {
               if(!file_exists($fcopy)){
                   mkdir($fcopy);
               }
               dirBackup($f);
           }else{
 
                // if (copy($f,$fcopy)) {
                //     // コピーに成功したら以下を表示
                //     echo 'コピー成功です。';
                // } else {
                //     // コピーに失敗したら以下を表示
                //     echo 'コピー失敗です。';
                // }

                // エラー時に例外をスローするように登録
                set_error_handler(function($errno, $errstr, $errfile, $errline) {
                    if (!(error_reporting() & $errno)) {
                        return;
                    }
                    throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
                });

                try {
                    // 警告のエラーを発生させる
                    copy($f,$fcopy);

                } catch (Exception $e) {
                    echo "例外が発生しました。".$e->getMessage();
                }
           }
       }
   }

    if(!file_exists('../pages_backup/'.$dateTime)){
        mkdir('../pages_backup/'.$dateTime);
        //バックアップとる
        dirBackup('../pages');
    }

?>