<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;
use Slim\Views\Twig;//テスト

require_once("../Parsedown.php"); //Parsedownを読み込み テスト
require_once("../ParsedownExtra.php"); //Extraを読み込み テスト

class MarkComp implements MiddlewareInterface
{
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $response = $handler->handle($request); //----(3)

        $serverParams = $request->getServerParams();
        /*$ipAddress = $serverParams["REMOTE_ADDR"];
        $path = $serverParams["REQUEST_URI"];
        $content = "<p>IPアドレスは".$ipAddress."でパスは".$path."</p>";
        $responseBody = $response->getBody();
        $responseBody->write($content);*/

        $twig = $this->get("view"); 
        $response = $twig->render($response, "helloWithVals.html", $assign);

        return $response;

		/*$folder = $args['folderName'];
		//$md = file_get_contents('../pages/'.$folder.'/markdown.md');//マークダウンファイル取得
		$md = file_get_contents($_SERVER["DOCUMENT_ROOT"].'/slimmiddle/pages/'.$folder.'/markdown.md');//マークダウンファイル取得
		$imgBasePath = '/slimmiddle/pages/' .$folder;
		$Extra = new ParsedownExtra();
		$htmlData = $Extra->text($md);//HTMLに変換

		$assign["htmlData"] = $htmlData;

		$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimmiddle/templates");
		$response = $twig->render($response, "markTest.html", $assign);

        return $response;*/
    }
}

