<?php
    // 再帰的にディレクトリを削除する関数
    function remove_directory($dir) {
        $files = array_diff(scandir($dir), array('.','..'));
        foreach ($files as $file) {
            // ファイルかディレクトリによって処理を分ける
            if (is_dir("$dir/$file")) {
                // ディレクトリなら再度同じ関数を呼び出す
                remove_directory("$dir/$file");
            } else {
                // ファイルなら削除
                unlink("$dir/$file");
            }
        }
        // 指定したディレクトリを削除
        return rmdir($dir);
    }

    // 空ではないディレクトリを削除
    remove_directory('../pages_backup');

    function dirBackup($ptn) {

        // 指定されたディレクトリ内の一覧を取得
        $res = glob($ptn.'/*');

        iF($ptn=='../pages'){
            print_r(count($res));
        }

        // 一覧をループ
        foreach ($res as $f) {
            // is_file() を使ってファイルかどうかを判定
            $fcopy = str_replace('pages','pages_backup',$f);

            if (!is_file($f)) {
                if(!file_exists($fcopy)){
                    mkdir($fcopy);
                }
                dirBackup($f);
            }else{
                copy($f,$fcopy);
            }
        }
    }

    if(!file_exists('../pages_backup')){
        mkdir('../pages_backup');
    }

    //バックアップとる
    dirBackup('../pages');


    //pages_copyフォルダを空にする。
    remove_directory('../pages_copy');

    //「pages_copy」がなければ作成
    if (!file_exists('../pages_copy')) {
        mkdir('../pages_copy');
    }

    // print_r($firstfdNum);
?>