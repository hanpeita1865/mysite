<?php
namespace SocymSlim\SlimMiddle\controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;


class SlimMiddleController
{
    private $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    // public function middlewareTest(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    // {
    //     $content = "<p>ミドルウェアのテスト。こちらはリクエスト処理。</p>";
    //     $responseBody = $response->getBody();
    //     $responseBody->write($content);
    //     return $response;
    // }

    // //マークダウンテスト
    // public function middlewareMarkTest(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    // {
    //     $content = "<p>ミドルウェアのテスト。こちらはリクエスト処理。</p>";
    //     $responseBody = $response->getBody();
    //     $responseBody->write($content);
    //     return $response;

	// 	/*$folder = $args['folderName'];
	// 	//$md = file_get_contents('../pages/'.$folder.'/markdown.md');//マークダウンファイル取得
	// 	$md = file_get_contents($_SERVER["DOCUMENT_ROOT"].'/slimmiddle/pages/'.$folder.'/markdown.md');//マークダウンファイル取得
	// 	$imgBasePath = '/slimmiddle/pages/' .$folder;
	// 	$Extra = new ParsedownExtra();
	// 	$htmlData = $Extra->text($md);//HTMLに変換

	// 	$assign["htmlData"] = $htmlData;

	// 	$twig = Twig::create($_SERVER["DOCUMENT_ROOT"]."/slimmiddle/templates");
	// 	$response = $twig->render($response, "markTest.html", $assign);

	// 	return $response;*/
    // }
}