//----------------------------------------------------------//
// Gulpfile.js
//----------------------------------------------------------//
const { src, dest, watch, parallel, series } = require('gulp');		//Gulp
const browserSync = require('browser-sync').create();							//ブラウザ同期
const notify = require('gulp-notify');														//通知
const plumber = require('gulp-plumber');													//エラー制御
const cached = require('gulp-cached');														//キャッシュ
const htmlhint = require('gulp-htmlhint');
const concat = require('gulp-concat');//ファイル結合								//HTMLバリデート
//const sass = require('gulp-sass');																//Sass/scssコンパル
const sass = require('gulp-sass')(require('sass'));
const autoPrefixer = require('gulp-autoprefixer');								//ベンダープレフィックス付与
const cssComb = require('gulp-csscomb');												//CSS整形
const cleanCss = require('gulp-clean-css');												//CSS圧縮
//const imagemin = require('gulp-imagemin');												//画像圧縮
const rename = require('gulp-rename');														//変名
const uglify = require('gulp-uglify');														//JavaScript圧縮
const sassGlob = require('gulp-sass-glob')
const sourcemaps = require('gulp-sourcemaps'); //①「gulp-sourcemaps」を読み込み

const errMessage = 'Error: <%= error.message %>';									//エラーメッセージ

const base = 'project/';																					//対象ディレクトリ
const path = {
	src: {
		scss: base + '_scss/**/*.scss',
		js: base + '_js_org/',
		images: base + '_images_org/**/*.+(png|jpg|gif|svg)',
		html: base + '**/*.html',
	},
	dist: {
		css: base + 'css/',
		js: base + 'js/',
		images: base + 'images/',
	},
};


//----------------------------------------------------------//
// JS Compile
//----------------------------------------------------------//

const js_compile = function () {
	return src([path.src.js+'file1.js',path.src.js+'file2.js',path.src.js+'file3.js'])
	  .pipe(concat('script.js'))
	  .pipe(dest(path.dist.js));
  }


//----------------------------------------------------------//
// Scss Compile
//----------------------------------------------------------//
const scss = () => {
	return src([path.src.scss])
		.pipe(plumber({
			errorHandler: notify.onError(errMessage)
		}))
		.pipe(sourcemaps.init())
		.pipe(sassGlob())
		//.pipe(sass())
		.pipe(sass({ outputStyle: 'expanded' }))
		.pipe(autoPrefixer({
			cascade: false
		}))
		//.pipe(cssComb())
		//.pipe(dest(path.dist.css))
		//.pipe(cleanCss({ compatibility: 'ie8' }))
		//.pipe(rename({
		//	extname: '.min.css'
		//}))
		.pipe(sourcemaps.write('./'))
		.pipe(dest(path.dist.css))
		.pipe(browserSync.stream())
	//.pipe(notify('scss task finished'))
};

//exports.default = series(scss);

//----------------------------------------------------------//
// HTML Validate
//----------------------------------------------------------//
const html = () => {
	return src([path.src.html])
		.pipe(plumber({
			errorHandler: notify.onError(errMessage)
		}))
		.pipe(cached('htmlhint_log'))
		.pipe(htmlhint())
		.pipe(htmlhint.failReporter())
		.pipe(browserSync.stream())
	//.pipe(notify('html task finished'))
};

//----------------------------------------------------------//
// JavaScript Compression
//----------------------------------------------------------//
/*const js = () => {
	return src([path.src.js])
		.pipe(plumber({
			errorHandler: notify.onError(errMessage)
		}))
		.pipe(dest(path.dist.js))
		.pipe(uglify())
		.pipe(rename({
			extname: '.min.js'
		}))
		.pipe(dest(path.dist.js))
		.pipe(browserSync.stream())
	//.pipe(notify('js task finished'))
};*/

//----------------------------------------------------------//
// Image Compression
//----------------------------------------------------------//
//const img = () => {
//	return src([path.src.images])
//		.pipe(plumber({
//			errorHandler: notify.onError(errMessage)
//		}))
//		.pipe(cached('images_log'))
//		.pipe(imagemin())
//		.pipe(dest(path.dist.images))
//		.pipe(notify('images task finished'))
//};

//----------------------------------------------------------//
// Default(for Markup Engineer)
//----------------------------------------------------------//
exports.default = () => {
	browserSync.init({
		port: 9400,
		server: {
			baseDir: base									//対象ディレクトリ
			, index: 'index.html'					//インデックスファイル
		}
	});

	watch(path.src.scss, scss);
	watch(path.src.html, html);
	//watch(path.src.js, js);
	watch(path.src.js+'*.js', js_compile);
}

//----------------------------------------------------------//
// Coder(for Coder)
//----------------------------------------------------------//
exports.coder = () => {
	browserSync.init({
		port: 55500,
		server: {
			baseDir: base									//対象ディレクトリ
			, index: 'index.html'					//インデックスファイル
		}
	});

	watch(path.src.html, html);
}

//----------------------------------------------------------//
// call
//----------------------------------------------------------//
//exports.imgcomp = series(img);
exports.build = parallel(html, scss, js_compile);

//----------------------------------------------------------//

