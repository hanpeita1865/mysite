<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Container\ContainerInterface;

require '../admin/basepath.php';


class PreviewController
{
    // コンテナインスタンス
    private $container;

    // コンストラクタ
    public function __construct(ContainerInterface $container)
    {
        // 引数のコンテナインスタンスをプロパティに格納。
        $this->container = $container;
    }

    public function previewData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {

        global $basePath;

        //フォルダ構成をオブジェクトで取得
        $folderObj = $this->container->get("folderComp");

        //マークダウン変換インスタンスをコンテナから取得
        $markData = $this->container->get("preview");


        $htmlData = $markData['html']; //HTMLデータ
        $title = $markData['title']; //タイトル

        $assign["folderObj"] = $folderObj; //フォルダ構成オブジェクト
        $assign["pathBase"] = $basePath;
        $assign["htmlData"] = $htmlData; //記事内容
        $assign["title"] = $title; //タイトル格納

        // Twigインスタンスをコンテナから取得。
        $twig = $this->container->get("view");

        // templateのpreview.twigからをHTMLを生成。
        $response = $twig->render($response, "preview.twig", $assign);

        return $response;
    }
}
