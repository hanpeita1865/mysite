---
title: 'Image Captions （画像キャプション）'
media_order: '0-11.png,image_captions.png'
---

このプラグインは、HTMLの &lt;img&gt;タグを&lt;figcaption&gt;キャプション付きの&lt;figure&gt;タグに変換します。  
デフォルトでは、&lt;img&gt;タグに「caption」クラスを設定したときのみ、キャプション付きの画像になるようになっています。

同じように変換してくれる「Img Captions」というプラグインもありますが、こちらは全ての&lt;img&gt;タグが&lt;figure&gt;タグに変換されます。  
また、&lt;img&gt;タグに「-（ハイフン）」付きのクラスを設定すると、そのクラスはうまく変換してくれません。

なので、「Image Captions」プラグインの方が使い勝手はいいので、こちらをおすすめします。 

<p class="tmp"><span>書式</span>画像タイトルの箇所がキャプションになります</p>
<pre>
<strong>![テキスト](画像のURL<span class="text-primary">?classes=caption</span> "<span class="text-danger">画像タイトル</span>")</strong>
</pre>

### 例）
    
![](0-11.png?classes=caption "図1 ヒマワリ")


<p class="write"><span>記入例</span></p>
<pre>
&#33;[](0-11.png?classes=caption "図1 ヒマワリ")
</pre>

<p class="comp"><span>HTML変換</span></p>

``` html
<figure class="image-caption">
    <img title="図1 ヒマワリ" alt="" class="caption" src="0-11.png">
    <figcaption class="">図1 ヒマワリ</figcaption>
</figure>
```

## 設定

Image Captionsの設定画面を開くと、下記のようになっています。
![](image_captions.png)



### figureやfigcaptionにクラスを設定

設定画面の**Figure class**と**Figcaption class**の入力欄に記入することで、それぞれのクラスを設定することができます。  
デフォルトでは、上図のようにFigure classには「image-caption」が設定されています。



### プラグインが動作する範囲を定義


プラグインが動作する範囲を定義できます。たとえば、デフォルトでは、上図のようにScopeの値が「**img.caption**」に設定されているので、クラスcaptionを持つすべての&lt;img&gt;タグが検索され変換されます。  
**Scope**の入力欄の値を変更することで、その指定したクラスのみが&lt;figure&gt;に変換されます。  
また、この値を「img」だけにすると、すべての&lt;img&gt;タグが変換の対象になります。


### スタイル

※figureやfigcaption、imgのスタイルは、独自に設定してください。

デフォルトのスタイルはこのようなっています。

    figure.image-caption figcaption {
        opacity: 0.7;
        font-size: 90%;
    }

    figure.image-caption figcaption {
        opacity: 0.7;
        font-size: 90%;
    }

    #body img {
        margin: 3rem auto;
        display: block;
        text-align: center;
    }


















