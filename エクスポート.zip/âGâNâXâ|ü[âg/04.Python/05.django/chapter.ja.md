---
title: Django
taxonomy:
    category:
        - docs
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:12px 0 12px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
</style>


DjangoはPython製のWebフレームワークです。  
Djangoには、以下のような多くのメリットがあるため、広く使われています。

* 便利な管理画面
* Django一つでWebフレームワークとして完結している
* Pythonで書かれていて読みやすい

## 目次

1. [Djangoの概略と使い方](django_howto)
2. 
3. 
4. 
5. [データベースを作る](database)
6. [管理ツールを使おう](management-tools)
7. [レコードの取得の基本とManager](record_manager)




### 参考サイト

[Anaconda公式サイト](https://www.anaconda.com/)

[Anaconda公式サイト（翻訳）](https://translate.google.com/translate?hl=ja&sl=en&tl=ja&u=https%3A%2F%2Fwww.anaconda.com)

[はじめての Django アプリ作成](https://docs.djangoproject.com/ja/2.2/intro/tutorial01/)

[Django概要（翻訳）](https://translate.google.com/translate?hl=ja&sl=en&tl=ja&u=https%3A%2F%2Fwww.djangoproject.com%2Fstart%2Foverview%2F)