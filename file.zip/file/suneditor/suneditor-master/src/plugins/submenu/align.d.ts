import { SubmenuPlugin } from '../SubmenuPlugin';

declare const align: SubmenuPlugin;

export default align;