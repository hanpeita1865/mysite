//data属性から、階層数を取得
let dirLevel = document.querySelector('body').getAttribute('data-dirlevel')
if (!dirLevel) {
  dirLevel = 1
}
//data属性から、カテゴリを取得
let category
if (document.querySelector('body').getAttribute('data-category')) {
  category = document.querySelector('body').getAttribute('data-category')
}
if (!category) {
  category = ''
}

//URL取得し配列に格納
siteUrl = location.href //ページURL
siteUrl = siteUrl.split('#')[0] //ページ内リンクは削除
regIndex = new RegExp(/\index.html$/) //index.htmlは変数から削除
siteUrl = siteUrl.replace(regIndex, '')
regIndex = new RegExp(/\.html$/)
siteUrl = siteUrl.replace(regIndex, '')
siteUrl = siteUrl.split('/')

PATH = {
  LV_1: '',
  LV_2: '../',
  LV_3: '../../',
  LV_4: '../../../'
}
let current = PATH['LV_' + dirLevel]
let cmnHeader = 'components/header.html' //ヘッダー共通ファイル
let cmnSide = 'components/sidebar_' + category + '.html' //サイドバー共通ファイル
let cmnNav = 'components/nav.html' //グロナビ共通ファイル
let cmnFoot = 'components/footer.html' //フッター共通ファイル
headerPath = current + cmnHeader
sidebarPath = current + cmnSide
navPath = current + cmnNav
footPath = current + cmnFoot

//HTMLパーツ読み込み
function Get(pathLv, loadfile, idname, func = null, func2 = null, func3 = null) {
  let request = new XMLHttpRequest()
  request.open('get', loadfile, true)
  request.setRequestHeader('Pragma', 'no-cache')
  request.setRequestHeader('Cache-Control', 'no-cache')
  request.send()
  request.onreadystatechange = function() {
    document.getElementById(idname).innerHTML = request.responseText
    setImgPath(pathLv, '#' + idname)
    setPath(pathLv, '#' + idname)
  }
  request.onload = function() {
    let width = window.innerWidth
    if (typeof func == 'function') {
      func()
    }
    if (typeof func2 == 'function') {
      func2()
    }
    if (typeof func3 == 'function') {
      headerglonavSet(width)
      func3()
    }
  }
}

//読み込み時処理
window.addEventListener('load', function() {
  if (!document.querySelector('.sugu-ruled-list')) {
    //	document.querySelector('.information').style.display = 'none'
  }

  let initwidth = window.innerWidth
  if (initwidth >= 992) {}
})

//リサイズ処理
window.addEventListener('resize', function() {
  let width = window.innerWidth
  if (width >= 992) {
    document.querySelector('.global-nav__menu').classList.remove('open')
    document.querySelector('.global-nav__button').setAttribute('aria-expanded', 'true')
    document.querySelector('.global-nav__lists').classList.remove('open'),
      document.querySelector('.global-nav__wrapper').classList.remove('open'),
      document.querySelector('.serch').classList.remove('open'),
      (document.getElementById('btnStatus').textContent = 'メニューを開く'),
      (document.getElementById('btnText').textContent = 'メニュー'),
      document.querySelector('.global-nav__button').classList.remove('pushed'),
      (document.querySelector('.global-nav').style.top = '')
  } else {
    document.querySelector('.global-nav__button').setAttribute('aria-expanded', 'false')
    document.querySelector('.global-nav__sub-menu').classList.remove('open')
  }
  headerglonavSet(width)
})

//グロナビボタン
const nav = function navButton() {
  const button = document.querySelector('.global-nav__button')
  button.addEventListener('click', function() {
    let buttonjudge = button.getAttribute('aria-expanded')
    buttonjudge == 'false' ? //グロナビ開く処理
      (document.querySelector('.global-nav__menu').classList.add('open'),
        document.querySelector('.global-nav__wrapper').classList.add('open'),
        document.querySelector('.global-nav__lists').classList.add('open'),
        document.querySelector('.serch').classList.add('open'),
        (document.getElementById('btnStatus').textContent = 'メニューを閉じる'),
        (document.getElementById('btnText').textContent = '閉じる'),
        button.classList.add('pushed'),
        button.setAttribute('aria-expanded', 'true')) :
      (document.querySelector('.global-nav__menu').classList.remove('open'),
        document.querySelector('.global-nav__wrapper').classList.remove('open'),
        document.querySelector('.global-nav__lists').classList.remove('open'),
        document.querySelector('.serch').classList.remove('open'),
        (document.getElementById('btnStatus').textContent = 'メニューを開く'),
        (document.getElementById('btnText').textContent = 'メニュー'),
        button.classList.remove('pushed'),
        button.setAttribute('aria-expanded', 'false'))

    const html = document.querySelector('html')

    if (!html.classList.contains('is-openMenu')) {
      scrollPos = window.pageYOffset
    }
    //グロナビ開く処理
    if (buttonjudge == 'false') {
      html.classList.add('is-openMenu')
    } else {
      html.classList.remove('is-openMenu')
      window.scrollTo(0, scrollPos)
    }
  })

  // let links = document.querySelectorAll('.global-nav__menu > li > a')
  // let link = Array.prototype.slice.call(links, 0)

  // link.forEach(function (element) {
  // 	element.addEventListener(
  // 		'click',
  // 		function () {
  // 			if (992 > window.innerWidth) {
  // 				//	element.parentNode.querySelector('.global-nav__sub-menu').classList.toggle('open')
  // 				//	element.classList.toggle('pushed')
  // 			}
  // 		},
  // 		false
  // 	)
  // })
}

//グロナビホバー
const nav1 = function navHover() {
  let links = document.querySelectorAll('.global-nav__menu > li > a')
  let link = Array.prototype.slice.call(links, 0)
  link.forEach(function(element) {
    if (element.parentNode.querySelector('.global-nav__sub-menu')) {
      //element.classList.add('plus')
    }
    element.addEventListener(
      'mouseover',
      function() {
        console.log(element)
        if (992 <= window.innerWidth && element.parentNode.querySelector('.global-nav__sub-menu')) {
          element.parentNode.querySelector('.global-nav__sub-menu').classList.add('open')
        }
      },
      false
    )
    element.addEventListener(
      'mouseout',
      function() {
        if (992 <= window.innerWidth && element.parentNode.querySelector('.global-nav__sub-menu')) {
          element.parentNode.querySelector('.global-nav__sub-menu').classList.remove('open')
        }
      },
      false
    )
    if (element.parentNode.querySelector('.global-nav__sub-menu')) {
      element.parentNode.querySelector('.global-nav__sub-menu').addEventListener(
        'mouseover',
        function() {
          if (992 <= window.innerWidth) {
            element.parentNode.querySelector('.global-nav__sub-menu').classList.add('open')
          }
        },
        false
      )
      element.parentNode.querySelector('.global-nav__sub-menu').addEventListener(
        'mouseout',
        function() {
          if (992 <= window.innerWidth) {
            element.parentNode.querySelector('.global-nav__sub-menu').classList.remove('open')
          }
        },
        false
      )
    }
  })
}

//グロナビフォーカス
const nav2 = function navFocus() {
  document.querySelector('.global-nav__link-sp').addEventListener('click', function() {
    document.getElementById('navBtn').focus()
  })

  document.querySelector('a[href="#navList"]').addEventListener('click', function() {
    document.getElementById('navList').focus()
  })
  let links = document.querySelectorAll('.global-nav__menu > li > a')
  let link = Array.prototype.slice.call(links, 0)
  let submenus = document.querySelectorAll('.global-nav__sub-menu')
  let submenu = Array.prototype.slice.call(submenus, 0)
  link.forEach(function(element) {
    element.addEventListener(
      'focusin',
      function() {
        if (992 <= window.innerWidth) {
          submenu.forEach(function(elem) {
            elem.classList.remove('open')
          })
          if (element.parentNode.querySelector('.global-nav__sub-menu')) {
            element.parentNode.querySelector('.global-nav__sub-menu').classList.add('open')
          }
        }
      },
      false
    )
  })
}
//ヘッダーとグロナビ位置
let headerglonavSet = function headerglonavSet(width) {
  let headerHeight = document.querySelector('header').getBoundingClientRect().bottom
  let header = document.querySelector('header')
  let nav = document.querySelector('.global-nav')

  if (width > 992) {
    if (document.querySelector('.carousel')) {
      document.querySelector('.carousel').style.marginTop = 145 + 'px'
    } else {
      document.querySelector('main').style.marginTop = 145 + 'px'
    }
    window.addEventListener('scroll', function() {
      // 処理内容
      let scrollingAmount = document.scrollingElement.scrollTop
      let width = window.innerWidth
      if (scrollingAmount > 100 && width > 992) {
        header.classList.add('scroll')
        nav.classList.add('scroll')
      } else {
        header.classList.remove('scroll')
        nav.classList.remove('scroll')
      }
    })
  } else {
    document.querySelector('.global-nav').style.top = 70 + 'px'

    if (document.querySelector('.carousel')) {
      document.querySelector('.carousel').style.marginTop = 70 + 'px'
    } else {
      document.querySelector('main').style.marginTop = 70 + 'px'
    }
  }
}
//ページの先頭へボタン
let linkToTop = function linkToTop() {
  window.addEventListener('scroll', function() {
    // let timeoutId
    // clearTimeout(timeoutId)

    // timeoutId = setTimeout(function () {
    // 処理内容
    let scrollingAmount = document.scrollingElement.scrollTop
    if (scrollingAmount > 100) {
      //ページの上から100pxスクロール
      document.querySelector('#pagetop').style.display = 'block'

      // requestAnimationFrame(function () {
      // 	document.querySelector('#pagetop').style.opacity = '1'
      // }) //ボタンがフェードイン
    } else {
      // requestAnimationFrame(function () {
      //     document.querySelector('#pagetop').style.opacity = '0'
      // })
      //fadeOut('#pagetop', 110, () => {
      document.querySelector('#pagetop').style.display = 'none'
      //})
    }
    //}//, 500)
  })
  const anchorLinks = document.querySelectorAll('a[href^="#"]')
  // const anchorLinksArr = Array.prototype.slice.call(anchorLinks)

  // anchorLinksArr.forEach((link) => {
  // 	link.addEventListener('click', (e) => {
  // 		e.preventDefault()
  // 		let headerHeight = document.querySelector('header').getBoundingClientRect().bottom
  // 		let navHeight = document.querySelector('nav').getBoundingClientRect().bottom
  // 		let Height = headerHeight + navHeight + 'px'
  // 		const targetId = link.hash
  // 		const targetElement = document.querySelector(targetId)
  // 		const targetOffsetTop = window.pageYOffset + targetElement.getBoundingClientRect().top
  // 		window.scrollTo({
  // 			top: targetOffsetTop + Height,
  // 			behavior: 'smooth'
  // 		})
  // 	})
  // })
}
//文字サイズ変更
let changeTextSize = function changeTextSize() {
  const buttons = document.querySelectorAll('.header__text-size button')
  const buttonArr = Array.prototype.slice.call(buttons)
  buttonArr.forEach((button) => {
    button.addEventListener('click', (e) => {
      let fontSize = button.getAttribute('data-font')
      document.querySelector('html').style.fontSize = fontSize + '%'
      document.querySelector('.header__text-size .active').classList.remove('active')
      button.classList.add('active')
    })
  })
}

let displayList = function displayList() {
  //URL取得し配列に格納
  let siteUrl = location.href //ページURL
  siteUrl = siteUrl.split('#')[0] //ページ内リンクは削除
  siteUrl = siteUrl.split('/')
  siteCategory = siteUrl.indexOf(category)
  siteUrlArr = siteUrl.slice(siteCategory - 1)
  siteCurrentUrlArr = siteUrlArr
  siteCurrentUrlArr = siteCurrentUrlArr.slice(1)
  siteUrl = siteCurrentUrlArr.join('/')
  if (siteCurrentUrlArr.indexOf('index.html') == -1) {
    siteCurrentUrlArr.push('index.html')
    console.log(siteCurrentUrlArr)
  }
  siteCategoryLink = siteUrlArr.splice(1, 2)
  siteCategoryLink = siteCategoryLink.join('/')

  //console.log(siteUrl)
  //サイドバーカテゴリ判別
  siteCategoryLink = new RegExp(siteCategoryLink)
  let sidebarCategoryLink = document.querySelectorAll('.sidebar__list >li>a')
  let sidebarCategoryLinkArr = Array.prototype.slice.call(sidebarCategoryLink)
  sidebarCategoryLinkArr.forEach((categorylink) => {
    let categoryhref = categorylink.getAttribute('href')
    categoryhrefArr = categoryhref.split('/')
    categoryhrefArr = categoryhrefArr.filter((item) => item.match(/\.\./) == null)
    categoryhref = categoryhrefArr.join('/')
    if (categoryhref.match(siteCategoryLink)) {
      categorylink.parentNode.classList.add('is-Current')
    }
  })
  let sidebarLink = document.querySelectorAll('.sidebar__list a')
  let sidebarLinkArr = Array.prototype.slice.call(sidebarLink)
  sidebarLinkArr.forEach((link) => {
    let href = link.getAttribute('href')
    hrefArr = href.split('/')
    hrefArr = hrefArr.filter((item) => item.match(/\.\./) == null)
    href = hrefArr.join('/')
    if (siteUrl == href) {
      link.parentNode.classList.add('open')
      if (siteUrlArr.length == 4) {
        hrefArr.splice(2, 1)
        hrefCategory = hrefArr.join('/')
        sidebarLinkArr.forEach((link2) => {
          let href2 = link2.getAttribute('href')
          hrefArr2 = href2.split('/')
          hrefArr2 = hrefArr2.filter((item) => item.match(/\.\./) == null)
          href2 = hrefArr2.join('/')
          if (hrefCategory == href2) {
            link2.classList.add('open')
          }
        })
      }
    }
  })
}

Get(current, headerPath, 'pagehead', changeTextSize, linkToTop)
Get(current, navPath, 'globalnav', nav, nav2, nav1)
Get(current, footPath, 'footer', linkToTop)
if (document.getElementById('sidebar')) {
  Get(current, sidebarPath, 'sidebar', displayList)
}
//フェードアウト
function fadeOut(id, time, func = null) {
  const targetElement = document.querySelector(id)
  let i = 1.0
  const timer = setInterval(() => {
    targetElement.style.opacity = i
    if (i >= 0.6) {
      i -= 0.083
    }

    if (i < 0.6) {
      i -= 0.15
    }
    if (i <= 0) {
      clearInterval(timer)
      if (typeof func == 'function') {
        func(targetElement)
      }
    }
  }, time)
}

//-- リンクのパス階層変更用の関数 --//
function setPath(pathLv, element) {
  arrLink = document.querySelectorAll(element + ' a')
  for (let i = 0; i <= arrLink.length - 1; i++) {
    let link = arrLink[i].getAttribute('href') //aのhrefの値を変数に格納
    if (!(/^http:|^https:|^mailto:|^javascript|^#/.test(link) || link == '')) {
      //外部リンク、メールリンク、「#」、空の場合は除外
      link = 'https://kinki-3-static.ndd-sv.net/' + pathLv + link
      arrLink[i].setAttribute('href', link)
    }
  }
}

//-- 画像のパス階層変更用の関数 --//
function setImgPath(pathLv, element) {
  arrImg = document.querySelectorAll(element + ' img')
  for (let l = 0; l <= arrImg.length - 1; l++) {
    let srcPath = arrImg[l].getAttribute('src')
    if (!(/^http:|^https:/.test(srcPath) || srcPath == '')) {
      //外部リンクと空の場合は除外
      srcPath = pathLv + srcPath
      arrImg[l].setAttribute('src', srcPath) //imgのsrcの値を変数に格納
    }
  }
}