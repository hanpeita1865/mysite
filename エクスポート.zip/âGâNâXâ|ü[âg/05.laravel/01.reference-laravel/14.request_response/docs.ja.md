---
title: '14. その他のリクエスト・レスポンス処理'
media_order: 'request_response01.png,request_response02.png,request_response03.png'
taxonomy:
    category:
        - docs
---

* [CSRF対策とVerifyCsrfToken](#p1)
* [クッキーを読み書きする](#p2)
* [リダイレクトについて](#p3)

リクエストやレスポンスに用意されている機能で、ぜひ覚えておきたいというものに 「***CSRF対策***」「***クッキーの処理***」「***リダレクト***」といったものがあります。これらの使い方をまとめて説明しましょう。

## CSRF対策とVerifyCsrfToken ##{#p1}
ここまで、たくさんのフォームをサンプルとして作成し、動かしてきました。それらは基本的にすべて**CSRF対策**のための機能を組み込んでありました。フォームの中には、 **{{ csrf_field() }}** という値が埋め込んであり、これによってCSRF対策用のトークンを出力する非表示フィールドが組み込まれました。  
が、実際に試してみると、うまくフォームが送信できないこともあったのではないでしょうか。例えば、一定時間が経過してフォームを送信すると、トークンの寿命が切れていてエラーが発生することもあります。また、そもそも送信された情報をデータベースに保存したり画面に表示したりするわけではないので、CSRF対策は必要ない、というケースもあります。  
こうした場合、フォームへのCSRF対策を適用しないように設定変更をする必要があります。  
CSRF対策の処理は、「**VerifyCsrfToken**」というクラスによって行われています。このクラスは、ミドルウェアとして用意されています。「**Http**」内の「**Middleware**」フォルダを 開いてみて下さい。その中に、「**VerifyCsrfToken.php**」というファイルが見つかります。 これが、CSRF対策を行っているスクリプトです。

![](request_response01.png?classes=caption "図 「Middleware」フォルダの中身。この中のVerifyCsrfToken.phpがCSRF対策を行うためのものだ。")

### $except に追記する
このVerifyCsrfTokenクラスには、標準で**$except**という変数が用意されています。これが、CSRF対策を適用しないアクションの配列です。 では、この部分を以下のように修正してみましょう。

<p class="tmp list"><span>リスト1</span>VerifyCsrfToken.php</p>
```
protected $except = [
   'hello',
];
```
これで、/helloにPOST送信された際にはCSRF対策が実行されなくなります。index.blade.phpを開き、フォームに記述してあった{{ csrf_field() }}を削除しましょう。そして /helloのフォームを送信し、問題なく処理されることを確認して下さい。

![](request_response02.png?classes=caption "図 フォームを送信すると正常に動く。")

### CSRF の除外とワイルドカード
<p>ここでは、$exceptに追記をしています。'hello'を指定することで/helloへのアクセス にCSRF対策を取らなくなります。  
この$exceptは配列になっており、必要なだけ値を用意することができます。また、値にはワイルドカード(*)を使うことが可能です。  
例えば、'hello/*'というようにすれば、/hello下に用意されたすべてのページでCSRF 対策が行われなくなります。</p>

<div class="gray-box" markdown="1">
#### VerifyCsrfToken自体をOFFにするには?
1つ1つのフォームでなく、アプリケーション全体でCSRF対策をOFFにしたい場合は、処理を行っている**VerifyCsrfToken**というミドルウェアをOFFにします。  
ミドルウェアの組み込みは、「Http」内にあるKernel.phpというファイルの中で行っています。この中に、$middlewareGroupsという配列が定義されており、その中の'web'という値に、更にミドルウェアクラスの配列が用意されています。そこから、
```
\App\Http\Middleware\VerifyCsrfToken::class,
```
この文を探して削除して下さい。これでVerifyCsrfTokenが読み込まれなくなり、フォー ムのCSRF対策がOFFになります。
</div>

## クッキーを読み書きする ##{#p2}
ちょっとした情報をクライアント側に保管しておくのに多用されるのが***クッキー***で す。PHPにはクッキー利用のための機能がありますが、Laravelを利用すればもっと簡単にクッキーを利用することができるようになります。  
クッキーの利用は、リクエスト(Request)とレスポンス(Response)のクラスに用意されているメソッドを利用します。

<p class="tmp"><span>書式1</span>保存されているクッキーの値を取得する</p>
```
$変数 = $request->cookie(キー );
```

<p class="tmp"><span>書式2</span>クッキーを新たに保存する</p>
```
$response->cookie(キー , 値 , 分数 );
```
クッキーを利用する場合、注意しておきたいのが「**値の保存と値の取得は、用意されているオブジェクトが違う**」という点です。*クッキーの値を取得するにはリクエストを使い*、*値を保存するにはレスポンスを使います*。  
値の取得は、**リクエストのcookieメソッド**を呼び出します。引数には、取得するクッ キーのキー(保存する際に指定したもの)を渡します。  
値の保存は、**レスポンスのcookieメソッド**を使います。引数には、割り当てるキー(名前)、保管する値、そして保存期間を示す値(分数)を用意します。

### クッキーを読み書きする
では、実際にクッキーの値を読み書きしてみましょう。今回は、フォームからテキストを送信したものをクッキーとして保管してみます。  
まずフォームを少し修正しましょう。index.blade.phpの@section('content)ディレクティブを以下のように書き換えます。

<p class="tmp list"><span>リスト2</span>index.blade.php</p>
```
@section('content')
   <p>{{$msg}}</p>
   @if (count($errors) > 0)
   <p>入力に問題があります。再入力して下さい。</p>
   @endif
   <table>
   <form action="/hello" method="post">
       {{ csrf_field() }}
       @if ($errors->has('msg'))
       <tr><th>ERROR</th><td>{{$errors->first('msg')}}</td></tr>
       @endif
       <tr><th>Message: </th><td><input type="text" name="msg"
           value="{{old('msg')}}"></td></tr>
       <tr><th></th><td><input type="submit" value="send"></td></tr>
   </form>
   </table>
@endsection
```

これで、msgという入力フィールド1つだけのフォームが表示されるようになります。 では、このフォームを使ってクッキーを保存し、それを表示するような処理を作りましょう。HelloControllerクラスを以下のように修正して下さい。

<p class="tmp list"><span>リスト3</span>HelloController.php</p>
```
class HelloController extends Controller
{
  
   public function index(Request $request)
   {
       if ($request->hasCookie('msg'))
       {
           $msg = 'Cookie: ' . $request->cookie('msg');
       } else {
           $msg = '※クッキーはありません。';
       }
       return view('hello.index', ['msg'=> $msg]);
   }

   public function post(Request $request)
   {
       $validate_rule = [
           'msg' => 'required',
       ];
       $this->validate($request, $validate_rule);
       $msg = $request->msg;
       $response = new Response(view('hello.index', ['msg'=>
           '「' . $msg . '」をクッキーに保存しました。']));
       $response->cookie('msg', $msg, 100);
       return  $response;
   }

}
```

![](request_response03.png?classes=caption "図 フィールドに何か書いて送信するとクッキーに保存する。以後、/helloにアクセスすると保存し たクッキーが表示される。")


これで完成です。/helloにアクセスすると、「※クッキーはありません。」と表示されます。このままフォームにテキストを書いて送信してみて下さい。送信されたテキストが クッキーとして保存されます。  
保存されたら、改めて/helloにアクセスしてみましょう。今度は、保存されたクッキー の値がメッセージとして表示されるようになります。

### クッキーの取得
では、クッキーの操作を行っている部分を見てみましょう。まずは、クッキーの値の取得からです。  
ここでは、まず「msg」というキーのクッキーが保存されているかどうかをチェックしています。
```
if ($request->hasCookie('msg'))......
```
Requestクラスの「**hasCookie**」メソッドは、引数に指定したキーのクッキーが保管されているかどうかを調べます。この結果がtrueならば、値を取り出して利用すればいいのです。
```
$msg = 'Cookie: ' . $request->cookie('msg');
```
値の取得は、このように非常にあっさりしています。が、保存になるとちょっと面倒なことになります。

### クッキーの保存
値の保存は、Responseのcookieメソッドを使いますが、注意しないといけないのは、cookieメソッドで保存処理をしたresponseを返送しないとクッキーは保存されないという点です。アクションメソッドではreturn viewしていましたが、クッキーを利用する場合は、Responseを用意し、cookieで保存してから、そのResponseをreturnするようにしてやる必要があります。 ここでは、まずResponseインスタンスを作成しています。
```
$response = new Response(view('hello.index', ['msg'=>
	'「' . $msg . '」をクッキーに保存しました。']));
```
Responseインスタンスの作成は、使用するViewを引数に指定します。これは、アクションでreturnしていたviewメソッドをそのまま引数として指定すればよいでしょう。  
Responseが用意できたら、そのcookieを呼び出してクッキーを保存し、このResponse をreturnします。
```
$response->cookie('msg', $msg, 100); 
return $response;
```
これで、作成したレスポンスがクライアントに返され、クッキーが保存されます。クッキーはクライアント側に保存されるものですから、クッキーを設定したレスポンスをク ライアントに返さないと保存はされないのです。

## リダイレクトについて ##{#p3}
アクションにアクセスしたとき、他のアクションを表示させるのに使われるのが「リダイレクト」です。これは既に使ったことがあります。バリデーションの処理で、エラー時に/helloに処理を回すのに、以下のような関数を用いました。
```
return redirect('/hello')......
```

この「redirect」という関数が、リダイレクトを実行するためのものです。これは「ヘルパ」と呼ばれるものの一種で、面倒な処理を簡単な関数として呼び出せるようにしたものです。 単純に、指定したアドレスにリダイレクトするだけなら、このように引数に移動するパスを指定するだけで済みます。  
このredirectヘルパは、「RedirectResponse」というレスポンスを返すものなのです。リダイレクトを使いこなすということは、このRedirectResponseの使い方を覚えるということなのです。

### RedirectResponse の主なメソッド
では、RedirectResponseにある主なメソッドについて、ここで簡単に整理しておきましょう。ここでは、メソッドチェーンとして使える(つまり、$this自身を戻り値とする) ものに絞ってまとめておきます。

<p class="tmp"><span>書式3</span>入力データを付加する</p>
```
$response->with Input()
```
これは、既に登場しました。フォームの送信などの際にリダイレクトを行う場合、送られてきたフォームの値をそのまま付加してリダイレクトします。

<p class="tmp"><span>書式4</span>バリデータのエラーを付加する</p>
```
$response->withErrors(《MessageProvider》)
```
これも既に登場しました。これはエラーメッセージを付加してリダイレクトするものです。引数には、MessageProviderというインターフェイスを用意します。具体的な実装例としては、illuminate\Contracts\ValidationのValidatorクラスがあります。

<p class="tmp"><span>書式5</span>クッキーを付加する</p>
```
$response->withCookie(Cookie 配列 )
```
先に、Responseのcookieメソッドでクッキーを追加する方法は説明しましたが、複数 のクッキーデータを付加してリダイレクトさせるものとしてwithCookieというメソッド も用意されています。引数には、Cookieインスタンスをまとめた配列を用意します。

### Redirector の主なメソッド
redirectヘルパを引数なしで呼び出すと、illuminate\routingの「Redirector」というクラスのインスタンスが返されます。これは、ルーティングに関する情報を扱うためのものです。このクラスのメソッドを呼び出すことで、リダイレクト先の設定などを行えるようになります。
では、このRedirectorのメソッドもいくつか紹介しておきましょう。
<p class="tmp"><span>書式6</span>ルートおよびアクションを指定する</p>
```
redirect()->route(ルート名 , 配列 ) redirect()->action(アクションの指定 , 配列 )
```
ルートの設定情報やコントローラのアクションを指定する場合に使うものです。 routeは、web.phpにルート情報として記述したものを指定します。またactionは、 "HelloController@index' というようにコントローラとアクションを指定します。

<p class="tmp"><span>書式7</span>ビューを指定する</p>
```
redirect()->view( ビュー名 )
```
ビューを指定してリダイレクトします。これは、アクションメソッドなどでreturn viewするときに用いられる名前と同じものです。

<p class="tmp"><span>書式8</span>JSONデータを返す</p>
```
redirect()->json( テキスト )
```
JSONデータをクライアントに返す場合に用いられるものです。引数には、JSON形式 のテキストを指定します。これで、指定のJSONデータを出力させることができます。

<p class="tmp"><span>書式9</span>ファイルを返す</p>
```
redirect()->download(ファイルパス ) redirect()->filet ファイルパス )
```
ファイルをダウンロードしたり、表示したりするためのものです。引数には、利用す るファイルのパスをテキストで指定します。これで、ファイルをダウンロードさせたり、 PDFやイメージファイルなどを表示させたりすることが簡単に行えます。

ーこのように、リダイレクトというのは、単純に「フォームを再表示する」ということだけを行うものではありません。*特定のアクションやルートを指定して表示させることもできますし、JSONデータやファイルのダウンロードなどを行わせるのに利用することもできます*。   
これらは、今すぐ覚えなくとも困ることはありませんが、使えるようになるとそれだけ表現力が増します。余力があればぜひ覚えて、使ってみて下さい。









