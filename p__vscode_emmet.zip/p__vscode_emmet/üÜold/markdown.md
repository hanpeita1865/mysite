*[page-title]:Emmet

## Emmet記法の活用

VSCODEのEmmetの説明サイト
: https://code.visualstudio.com/docs/editor/emmet


参考サイト
: [【チートシート付き】Emmetをまとめてみた！コーディング速度アップを目指そう！](https://crestadesign.org/emmet/)
: [Emmet（エメット）でHTMLとCSSを効率的にコーディングする](https://b-risk.jp/blog/2021/06/emmet/)

### HTMLの基本テンプレートを呼び出す方法

参考サイト
: [【Visual Studio Code】HTMLの基本テンプレートを呼び出す方法](https://manabu-biology.com/archives/%E3%80%90visual-studio-code%E3%80%91html%E3%81%AE%E5%9F%BA%E6%9C%AC%E3%83%86%E3%83%B3%E3%83%97%E3%83%AC%E3%83%BC%E3%83%88%E3%82%92%E5%91%BC%E3%81%B3%E5%87%BA%E3%81%99%E6%96%B9%E6%B3%95.html)

#### 「!」を入力してtabキーを押す

HTMLファイル上で「<span class="red bold">!</span>」を入力して<span class="red">tabキー</span>を押すと、以下のコードが記入されます。  
ただデフォルトでは、lang属性が「<span class="red">en</span>」になってるのと、IEに対して互換性のモードを指定するmetaタグが入っているので、これをlang属性は「ja」に変更し、IEに対してのmetaタグは削除されたコードが記入されるように設定しておくと良いです。

![](upload/lang_en.jpg)

##### 設定変更方法

参考サイト
: https://satoyan419.com/custom-emmet-snippets-in-visual-studio-code/

1. snippets.jsonファイルを作成して、下記コードを記述し、保存します。保存場所はどこでもいいです。

<p class="lang">snippets.json</p>
```
{
  "variables": {
    "lang": "ja"
  },
  "html": {
    "snippets": {
      "doc": "html[lang=${lang}]>(head>meta[charset=${charset}]+meta:vp+title{${1:Document}})+body"
    }
  }
}
```

2. 設定画面を開き、入力欄に「emmet」と記入し、エンターキーを押します。  
　抽出された項目の中から、「Emmet: Extensions Path」の［<span class="red">項目を追加</span>］ボタンをクリックして、snippets.jsonファイルを保存した<span class="red">フォルダのパス</span>を記入して、OKをクリックします。

![](upload/extensions_path項目の追加.jpg)

3. 再度HTMLファイル上で「<span class="red bold">!</span>」を入力して<span class="red">Tabキー</span>を押すと、以下のようにlang属性が「ja」でIE用のmetaタグが削除されたコードが記入されます。
![](upload/lang_ja_meta削除.jpg)

css読み込みのlinkタグの場合

「link:css」 を入力して、Enterキーを押下します。  
そうすると、次のlinkタグが入力されます。
```
<link rel="stylesheet" href="style.css">
```

javascriptの読み込みコードの場合、「script:src」と入力してEnterキーを押下します。  
そうすると、次のコードが入力されます。
```
<script src=""></script>
```

### Emmetが効かない場合の対応

参考サイト
: [VSCodeでEmmetが使えない時の対処方法](https://taiyosite.com/vscode-emmet/)

tabキーを押しても、変換されないときは、Emmetが「off」になってると思われるので、下記を実行してください。

右下の歯車アイコンをクリックし、「設定」を選択します。

検索窓に、「Trigger Expansion On Tab」と入力し、下記のチェックボックスにチェックを入れれば完了です

![](upload/TriggerExpansionOnTab.png)



### 通常のHTMLタグ

HTMLタグを入力したいときは、HTMLタグ名を入力してtabキーを押下します。

例えば、h1と入力してtabキーを押下すると、以下のようになります。

```
<h1></h1>
```

また、h1{タイトル}と入力してtabキーを押下すると、テキストが記入されます。

<div class="exp">
	<p class="tmp"><span>例</span></p>
「	h1{見出しです}」と入力した場合、次のようになります。
	</div>
```
<h1>見出しです</h1>
```

クラスを設定する場合、「.」（ピリオド）を付けます。



ulタグやolタグを入力するときは、「ul>li*リスト数」 や 「ol>li*リスト数」 を入力して、tabキーを押下します。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	「ul>li*3」と入力した場合、次のようになります。
	</div>
```
<ul>
    <li></li>
    <li></li>
    <li></li>
</ul>
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
「ul>li{リストです}*3」と入力した場合、次のようになります。
	</div>
```
<ul>
    <li>リストです</li>
    <li>リストです</li>
    <li>リストです</li>
</ul>
```

リストの中に、aのリンクを設置する場合は、ul>(li>a{リンク})*3を入力して、エンターキーを押します。

<div class="exp">
	<p class="tmp"><span>例</span></p>
	ul>(li>a{リンク})*3を入力した場合
	</div>
```
<ul>
    <li><a href="">リンク</a></li>
    <li><a href="">リンク</a></li>
    <li><a href="">リンク</a></li>
</ul>
```
