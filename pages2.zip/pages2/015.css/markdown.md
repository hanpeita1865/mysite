*[page-title]:CSS

参考サイト
: [Into the Program  HTML/CSS](https://into-the-program.com/category/html/)
: [新しいCSSの書き方 最新テクニック20選まとめ実用サンプルコード付き](https://photoshopvip.net/137332)
: [【2022】これから使えるCSSプロパティ18選！新しく使える便利なCSSテクニック！](https://www.youtube.com/watch?v=EeZM5SXuCsU)

## object-fit

画像の一覧を表示する時などは、画像のサイズが統一されていると並べて表示させてもすっきりキレイに整って見えますが、必ずしもサイズが同じとは限りません。かといってPhotoshopを使ってすべての画像をリサイズできない…ということもあるでしょう。そんな時はCSSでトリミングすると楽です！「<span class="green bold">object-fit</span>」というプロパティーを使って、画像の縦横比を保ちつつトリミングすることができるようになります。

参考サイト
: https://www.webcreatorbox.com/tech/object-fit

元画像
![](upload/cat-landscape.jpg)
![](upload/cat-portrait.jpg)

<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>

<a href="sample/object-fit-center-trim/" target="_blank">新規タブ</a>

<p class="codepen" data-height="400" data-default-tab="result" data-slug-hash="vxxgvw" data-user="manabox" style="height: 400px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/manabox/pen/vxxgvw">
  Image Trimming w/ object-fit: cover</a> by Mana (<a href="https://codepen.io/manabox">@manabox</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>

中央でトリミングされています。  
これまで position プロパティーを駆使してなんとか中央に表示させてきましたが、object-fit プロパティーひとつで済むのでCSSもすっきりします。

このように画像の縦横比を維持したままボックスを埋めたい時は、object-fit: cover; を使います。画像のサイズは縦横のうち小さい方を基準にして自動的に拡大・縮小され、ボックスからはみ出した部分はトリミングされます。

## 下線を引く

参考サイト
: [下線として使うのは間違い！HTML5で新定義された＜u＞タグの非言語注釈とは？](https://webukatu.com/wordpress/blog/15540/)

HTMLではCSSを使わなくても、文字を強調したり、注釈を付け加えたりするタグがありますが、今回ご紹介するuタグもそのうちのひとつ。

しかしHTML5では、今まで使用されていた「下線」ではなく「非言語注釈」としての役割が新たに定義づけられました。

### uタグを使わずに下線を表示する方法

<p class="codepen" data-height="300" data-default-tab="html" data-slug-hash="eYdgqOL" data-user="rabbittyu" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/rabbittyu/pen/eYdgqOL">
  underline</a> by rabbittyu (<a href="https://codepen.io/rabbittyu">@rabbittyu</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>


## ボックス間のマージン

### 4列
```
     x1                 x2      x3              x3     x2                    x1    
    0.75              0.25      0.5            0.5     0.25                 0.75
1枚目                      2枚目                   3枚目                      4枚目
            y                            y                           y
　　　　　　1                           1                           1
```

### 5列

```
　x1     x2            x3          x4         x4           x3           x2       x1 
    0.8	  0.2	　  0.6033920417482061	   0.4        0.4 　 0.6033920417482061  　0.2      0.8
1枚目         2枚目             3枚目             4枚目        5枚目
```

## ハンバーガメニューボタン

<p class="codepen" data-height="300" data-default-tab="html" data-slug-hash="Ypwrdx" data-user="KPCodes" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/KPCodes/pen/Ypwrdx">
  Half Second Hamburger Helper</a> by Kurt Petrek (<a href="https://codepen.io/KPCodes">@KPCodes</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>

<iframe width="100%" height="500" src="sample/half-second-hamburger-helper/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<a href="sample/half-second-hamburger-helper/" target="_blank">新規タブ</a>

## スクロールバー

### ボックスのスクロールバー位置設定

##### CodePen
<https://codepen.io/KazuyoshiGoto/pen/YzQgKv>

<iframe width="100%" height="500" src="sample/box_scrollbar/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<a href="sample/box_scrollbar/" target="_blank">新規タブ</a>


## 指定した行数でテキストを省略表示する（line-clamp）

<span class="green bold">ボックス</span>に収まらないテキストの最後が「...」で表示されます。  
「text-overflow: ellipsis」の場合は、<span class="green bold">一行</span>に収まらないときに、「...」になる。


参考サイト
: [【CSS】【line-clamp】指定した行数でテキストを省略表示する](https://into-the-program.com/css-line-clamp/)

<iframe height="300" style="width: 100%;" scrolling="no" title="7681" src="https://codepen.io/intotheprogram/embed/rNJGYQR?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/intotheprogram/pen/rNJGYQR">
  7681</a> by ryohei (<a href="https://codepen.io/intotheprogram">@intotheprogram</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>


## 文字の縁取り（-webkit-text-stroke）非標準

非標準: この機能は標準ではなく、標準化の予定もありません。公開されているウェブサイトには使用しないでください。ユーザーによっては使用できないことがあります。実装ごとに大きな差があることもあり、将来は振る舞いが変わるかもしれません。

<iframe height="300" style="width: 100%;" scrolling="no" title="CSS | Text Stroke" src="https://codepen.io/yochans/embed/qBqZgVa?default-tab=html%2Cresult" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/yochans/pen/qBqZgVa">
  CSS | Text Stroke</a> by yochans (<a href="https://codepen.io/yochans">@yochans</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

## 画像をいろいろな形に切り取る（clip-path）

参考サイト
: [CSSのclip-pathプロパティでいろいろ簡単に実装できる、便利な使い方と実装のポイント](https://coliss.com/articles/build-websites/operation/css/how-to-use-css-clip-path.html)
: [CSS clip-path の使い方](https://www.webdesignleaves.com/pr/css/css_clip_path.html)

ジェネレータ
: <https://bennettfeely.com/clippy/>

## 最小値、推奨値、最大値の3つの引数（clamp）

参考サイト
: <https://coliss.com/articles/build-websites/operation/css/css-about-min-max-clamp.html>

## リスト カウンタ

①②③・・・をつける。

参考サイト
: [【CSS】olのリストで①、②、③（丸数字）を表示させる](https://125naroom.com/web/2877)

<p class="codepen" data-height="300" data-default-tab="html,result" data-slug-hash="xxKLvLj" data-user="125naroom" style="height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/125naroom/pen/xxKLvLj">
  【CSS】olのリストで①、②、③（丸数字）を表示させる、spanや①は無しバージョン</a> by 125naroom (<a href="https://codepen.io/125naroom">@125naroom</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>