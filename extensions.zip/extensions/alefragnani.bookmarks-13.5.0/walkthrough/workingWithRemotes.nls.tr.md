## Uzaktan Çalışma

Uzantı, [Uzaktan Geliştirme](https://code.visualstudio.com/docs/remote/remote-overview) senaryolarını tamamen destekler.

Bu, Docker Container, SSH veya WSL gibi bir _remote_ konuma bağlandığınızda uzantının kullanıma hazır olacağı anlamına gelir.

> Uzantıyı uzak cihaza yüklemenize gerek yoktur.

Daha da iyisi, `true` olarak tanımlanan `bookmarks.saveBookmarksInProject` ayarını kullanırsanız, yerel olarak kaydedilen yer işaretleri uzaktan kullanılabilir olacak ve yer işaretlerinde gezinebilecek ve bunları güncelleyebileceksiniz. Tıpkı uzaktan açtığınız klasördeki bir kaynak olduğu gibi.
