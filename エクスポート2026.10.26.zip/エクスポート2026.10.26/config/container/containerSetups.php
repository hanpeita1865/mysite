<?php

use DI\Container;
use Slim\Factory\AppFactory;


$container = new Container();

AppFactory::setContainer($container);

// 個別設定をロード（自分自身は除外）
$files = glob(__DIR__ . '/*.php');
foreach ($files as $file) {
    if (basename($file) === 'containerSetups.php') {
        continue; // 自分自身はスキップ！
    }

    $setup = require $file;
    if (is_callable($setup)) {
        $setup($container);
    }
}

return $container;



