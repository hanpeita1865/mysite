## Testing

1. Use the special characters icon in order to add a special character to the editor.
1. Use the select in order to change category of displayed special characters.
