<?php
namespace SocymSlim\SlimMiddle\Services;
use Psr\Container\ContainerInterface;
use PDO;

class MenuService
{

    // private string $basePath;
    // private string $siteName;
    private array $lockData = [];
    private array $lockArray = [];
    private int $countIp = 0;
    private ContainerInterface $container;
    
    
    public function __construct(/*string $basePath, string $siteName,*/ ContainerInterface $container)
    {
        // $this->basePath = $basePath;
        //$this->siteName = $siteName;
        $this->container = $container;
    }
 
    
    public function setCountIp(int $countIp): void
    {
        $this->countIp = $countIp;
    }

    
    //---------------------------//
    //   DBからロック情報を取得   
    //--------------------------//

    public function loadLockData(PDO $db, array $folderObj): void
    {
        $stmt = $db->prepare('SELECT page, under_dir FROM locklist');
        $stmt->execute();
        $this->lockData = $stmt->fetchAll(PDO::FETCH_COLUMN | PDO::FETCH_GROUP);

        foreach ($this->lockData as $key => $value) {
            if (array_key_exists($key, $folderObj)) {
                if ($this->lockData[$key][0] === 'all') {
                    $folder_dir = preg_quote($folderObj[$key], '/');
                    $dir_group = preg_grep('/' . $folder_dir . '/', $folderObj);
                    $this->lockArray = array_merge($this->lockArray, $dir_group);
                }
            }
        }
    }
    
    
    
    
    //-------------------------------//
    //   検索メニュー構築
    //-------------------------------//
    
    public function buildSearchMenu(): array {
        return $this->getTopLevelFolders('../pages');
    }
    
    

    //---------------------------------------//
    //  第一階層フォルダを取得
    //--------------------------------------//
    
    public function getTopLevelFolders(string $folder): array {
        $folderFirst = [];

        if (!is_file($folder)) {
            $res = glob($folder . '/*');

            foreach ($res as $f) {
                $dirArray = explode('/', $f);
                $lastDir = end($dirArray);

                // 先頭3桁＋ドット付きフォルダのみ
                if (preg_match('/^\d{3}\./', $lastDir)) {
                    $folderNoNum = preg_replace('/^\d{3}\./', '', $lastDir);

                    if (file_exists($f . '/markdown.md')) {
                        $md = file_get_contents($f . '/markdown.md');

                        if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md)) {
                            $folderFirst[$folderNoNum] = $lastDir;
                        }
                    }
                }
            }
        }

        return $folderFirst;
    }
    



    //---------------------------//
    //   メニュー生成   
    //--------------------------//

    public function buildMenu(string $folder, string $folderName, int &$boxNum = 1, bool &$hasActive = false): string
    {
        $menuCode = '';
        $hasActive = false;

        // --- コンテナ登録済み情報を取得 ---
        $config = $this->container->get('config');
        $basePath = $config['basePath'];
        $countIp = $this->countIp; // プロパティから取得
        $lockData = $this->lockData; // プロパティから取得
        $lockArray = $this->lockArray; // プロパティから取得


        if (!is_file($folder)) {
            $entries = glob($folder . '/*');
            
            foreach ($entries as $entry) {
                $dirArray = explode('/', $entry);
                $lastDir = end($dirArray);

                // 先頭3桁＋ドットのディレクトリ名のみ対象
                if (!preg_match('/^\d{3}\./', $lastDir)) {
                    continue;
                }

                // パス整形
                $path = str_replace('../pages/', '', $entry) . '/';
                $pathRe = preg_replace('/^\d{3}\./', '', $path);
                $pathRe = preg_replace('/\/\d{3}\./', '/', $pathRe);
                $link = $basePath . '/public/pages/' . $pathRe;

                // markdown.md からタイトル抽出
                $title = preg_replace('/^\d{3}\./', '', $lastDir);
                if (file_exists($entry . '/markdown.md')) {
                    $md = file_get_contents($entry . '/markdown.md');
                    if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $match)) {
                        $title = $match[1];
                    }
                }

                // --- ロック判定（排他処理なし）---
                $lockCls = '';
                $showItem = true; // 初期値：表示する
                
                $pureName = preg_replace('/^\d{3}./', '', $lastDir);

                if ($countIp == 1) {
                    // 管理者
                    if (array_key_exists($pureName, $lockData)) {
                        $lockCls = ($lockData[$pureName][0] === 'all') ? 'all-lock' : 'lock';
                    }
                    
                } elseif ($folderName === 'admin') {
                    // 管理画面では常に表示
                    $lockCls = '';
                    
                } else {
                    // 一般ユーザー
                    if (array_key_exists($pureName, $lockArray)) {
                        $showItem = false; // ロック配下 → 非表示
                    } elseif (array_key_exists($pureName, $lockData)) {
                        $lockCls = 'lock'; // 部分ロック
                    }
                }

                // 非表示対象はスキップ
                if (!$showItem) continue;
                
                
                // --- メニューHTML生成 ---
                
                // 「番号抜きのディレクトリ名」と「現在のフォルダ名」が一致したら active を付与
                $isActive = ($pureName === $folderName);
                
                // 現在の <li> に付けるクラスを準備
                $liClasses = ['box-item'];
                if ($isActive) {
                    $liClasses[] = 'active';
                }
                
                if ($lockCls) {
                    $liClasses[] = $lockCls;
                }
                
                // 再帰：子要素を生成（子から hasActive を受け取る）
                $childHasActive = false;
                $childrenHtml = $this->buildMenu($entry, $folderName, $boxNum, $childHasActive);
                
                // もし子にアクティブがあれば親側に cate-active クラスを付ける
                if ($childHasActive) {
                    // 親 li を toggle + cate-active にしたいならこちらに追加
                    $liClasses[] = 'toggle';
                    $liClasses[] = 'cate-active';
                } elseif ($childrenHtml !== '') {
                    // 子がいるけどアクティブでない場合でも toggle クラスは付ける
                    $liClasses[] = 'toggle';
                }
                
                // li の id をセット（itemN）
                $liId = 'item' . $boxNum;
                $boxNum++;
                
                // li を組み立て
                $liClassAttr = $liClasses ? ' class="' . implode(' ', array_unique($liClasses)) . '"' : '';
                $menuCode .= sprintf('<li id="%s"%s><a href="%s" title="%s">%s</a>',
                    htmlspecialchars($liId, ENT_QUOTES),
                    $liClassAttr,
                    htmlspecialchars($link, ENT_QUOTES),
                    htmlspecialchars($title, ENT_QUOTES),
                    htmlspecialchars($title, ENT_QUOTES)
                );                
                    
                // 子があれば挿入
                if ($childrenHtml !== '') {
                    $menuCode .= "\n<ul class=\"sub-menu\">\n{$childrenHtml}</ul>\n";
                }

                $menuCode .= "</li>\n";                
                                
                // このレベルにアクティブがあるかを集計：自分 or 子ども
                if ($isActive || $childHasActive) {
                    $hasActive = true;
                }                
            }
        }

        return $menuCode;
    }
    

    //--------------------------------------------------------//
    //   管理画面用メニュー構築（旧 menuCompAdmin / globMenu）  
    //-------------------------------------------------------//

    public function buildAdminMenu(string $folder = '../pages', int &$boxNum = 1): string {
        $menuCode = '';
        $config = $this->container->get('config');
        $basePath = $config['basePath'];
        $countIp = $this->countIp;
        $lockData = $this->lockData;
        $lockArray = $this->lockArray;

        if (!is_file($folder)) {
            $entries = glob($folder . '/*');

            foreach ($entries as $entry) {
                $dirArray = explode('/', $entry);
                $lastDir = end($dirArray);

                if (!preg_match('/^\d{3}\./', $lastDir)) {
                    continue;
                }

                $path = str_replace('../pages/', '', $entry) . '/';
                $pathRe = preg_replace('/^\d{3}\./', '', $path);
                $pathRe = preg_replace('/\/\d{3}\./', '/', $pathRe);

                $title = preg_replace('/^\d{3}\./', '', $lastDir);
                if (file_exists($entry . '/markdown.md')) {
                    $md = file_get_contents($entry . '/markdown.md');
                    if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $match)) {
                        $title = $match[1];
                    }
                }

                // --- ロック判定 ---
                $lockCls = '';
                $showItem = true;

                if ($countIp == 1) {
                    if (array_key_exists($lastDir, $lockData)) {
                        $lockCls = ($lockData[$lastDir][0] === 'all') ? 'all-lock' : 'lock';
                    }
                // } elseif ($folderName === 'admin') {
                //     $lockCls = '';
                } else {
                    if (array_key_exists($lastDir, $lockArray)) {
                        $showItem = false;
                    } elseif (array_key_exists($lastDir, $lockData)) {
                        $lockCls = 'lock';
                    }
                }

                if (!$showItem) {
                    continue;
                }

                $menuCode .= sprintf(
                    '<li id="item%d" class="box-item"><a href="%s"%s>%s</a>',
                    $boxNum,
                    htmlspecialchars($basePath . '/public/pages/' . $pathRe, ENT_QUOTES),
                    $lockCls ? ' class="' . htmlspecialchars($lockCls, ENT_QUOTES) . '"' : '',
                    htmlspecialchars($title, ENT_QUOTES)
                );
                $boxNum++;

                // 子フォルダ再帰
                $children = $this->buildAdminMenu($entry, $boxNum);
                if ($children !== '') {
                    $menuCode .= "\n<ul class=\"sub-menu\">\n{$children}</ul>\n";
                }

                $menuCode .= "</li>\n";
            }
        }

        return $menuCode;
    }
}
