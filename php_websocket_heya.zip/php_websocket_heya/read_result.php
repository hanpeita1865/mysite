<?php 
// print_r('テスト送信です。')

require 'database_access.php';

$stmt = $pdo->prepare('SELECT * FROM result');
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC); 

if(!empty($result)){
    print_r($result['html'] );
}

?>