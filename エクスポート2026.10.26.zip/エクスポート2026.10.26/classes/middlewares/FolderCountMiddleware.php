<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use SocymSlim\SlimMiddle\Services\{
    FolderService,
};
use SocymSlim\SlimMiddle\Config\PageArea;//追加

class FolderCountMiddleware implements MiddlewareInterface {
    
    private FolderService $folderService;

    public function __construct(FolderService $folderService) {
        $this->folderService = $folderService;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {

        $pageArea = $request->getAttribute('pageArea');//追加
        $pageDir = PageArea::getPageDir($pageArea);//追加
        $pagesObj = $this->folderService->getFolderComp($pageDir);
        // $pagesObj = $this->folderService->getFolderComp();
        $folderCnt = count($pagesObj);

        $request = $request->withAttribute('count', $folderCnt);
        $response = $handler->handle($request);

        return $response;
    }
}