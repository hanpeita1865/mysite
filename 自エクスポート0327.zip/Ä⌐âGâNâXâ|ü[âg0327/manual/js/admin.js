const elem_box = document.getElementById('menu');
const box_items = document.querySelectorAll('.box-item');
const elem_reset = document.getElementById('reset');
let subMenu = document.querySelectorAll('.sub-menu');
let arrayStart = [];//デフォルトの並び順初期値

//並び順初期値格納
box_items.forEach(function (value) {
	arrayStart.push(value.getAttribute('id'));
});

box_items.forEach(elm => {
	//ボックスをダブルクリックして空のボックスを作成
	elm.addEventListener('dblclick', function (e) {
		let subLen = this.children.length;
		console.log(subLen)
		if (elm == e.target) {//2階層以下の複数実行防止

			//サブメニューの空ボックスを作成
			if (subLen == 4) {
				this.insertAdjacentHTML('beforeend', '<ul class="emp-ul sub-menu"></ul>\n');
				obj = this.lastChild;//サブメニューul要素

			} else {
				//サブメニュー開閉
				this.closest('.box-item').classList.toggle('s-close');
			}
		}
	})

	elm.setAttribute('draggable', 'true');

	let href = elm.querySelector('a').getAttribute('href');
	let folderName = href.split('/')[1];

	elm.insertAdjacentHTML('beforeend', '<span class="link-name">' + folderName + '</span>');

	if (folderName != 'p_base') {
		elm.insertAdjacentHTML('beforeend', '<button class="folder-rename">フォルダ名変更</button>');
		elm.insertAdjacentHTML('beforeend', '<button class="folder-del">削除</button>');
		// elm.insertAdjacentHTML('beforeend', '<button class="btn-lock">ロック変更</button>');
	}

	elm.querySelector('a').setAttribute('title', 'ダブルクリックするとメニュー名を変更できます。');

	if (elm.children.length > 4) {
		elm.querySelector('a').insertAdjacentHTML('beforeend', '<span class="icon-slide"></span>');
	}

	sortDrop(elm);
});

//ボックス並べ替え
function sortDrop(elm) {
	elm.ondragstart = function (e) {
		e.dataTransfer.setData('text/plain', e.target.id);
	};

	let empBox = 1;

	//ドラッグオーバー
	elm.ondragover = function (e) {
		e.preventDefault();

		if (elm == e.target.parentNode || elm == e.target) {

			if (e.target.classList.contains('emp-ul')) {
				e.stopPropagation(); //イベントを停止する
				e.preventDefault(); //画面遷移を行わない
				e.target.style.border = '4px solid green';
				empBox = e.target;

			} else if (e.target.closest('li').classList.contains('box-item')) {
				let rect = e.target.closest('li').getBoundingClientRect();
				let elm_over = this

				rectOver(e, rect, elm_over);//ボーダー表示

			} else {
				let rect = e.target.getBoundingClientRect();
				let elm_over = e.target;

				rectOver(e, rect, elm_over);//ボーダー表示
			}
		}
	};

	//ドラッグリープ（ボックスから離れる）
	elm.ondragleave = function (e) {
		if (empBox != 1) {
			empBox.removeAttribute('style');
		}

		this.style.borderTop = '';
		this.style.borderBottom = '';
	}

	//ドロップ
	elm.ondrop = function (e) {
		e.preventDefault();

		if (elm == e.target.parentNode || elm == e.target) {//2階層以下の複数実行防止

			let id = e.dataTransfer.getData('text/plain');
			const elm_drag = document.getElementById(id);

			try {
				if (e.target.classList.contains('emp-ul')) {//空のボックスに挿入

					let id = e.dataTransfer.getData('text/plain');
					let dropItem = document.getElementById(id);

					e.target.removeAttribute('style');
					e.preventDefault();

					try {

						e.target.appendChild(dropItem);
						e.target.closest('.box-item').firstElementChild.insertAdjacentHTML('beforeend', '<span class="icon-slide"></span>');

						dropItem.parentNode.classList.remove('emp-ul');
						subEmpDelete();

					} catch (error) {
						console.log('エラー');
						dropItem.parentNode.classList.remove('emp-ul');
						subEmpDelete();
					}

				} else if (this.classList.contains('box-item')) { //並べ替え

					let rect = this.getBoundingClientRect();

					rectDrop(e, e.currentTarget, rect, elm_drag);//挿入位置が上側か下側かを判定
					subEmpDelete();//空になった挿入用ボックス削除
				}

				box_items.forEach(function (t) {
					t.removeAttribute('style');
				});

			} catch (error) {
				console.log('エラー')
				//ボーダー削除
				box_items.forEach(function (e) {
					e.removeAttribute('style');
				});

				subMenu.forEach(function (e) {
					e.removeAttribute('style');
				})
			}
		}
	};
}


//空になったsubメニューボックス削除
function subEmpDelete() {
	subMenu = document.querySelectorAll('.sub-menu');
	//空のボックスがある。
	subMenu.forEach(function (e) {
		if (e.children.length == 0 && !e.classList.contains('emp-ul')) {
			e.remove();
		}
	});

	//サブメニューない▲アイコン削除
	document.querySelectorAll('a span.icon-slide').forEach(function (e) {
		if (e.closest('.box-item').querySelector('.sub-menu') == null) {
			e.remove();
		}
	});
}

//マウスオーバーの上下ボーダー表示
function rectOver(e, rect, elm_over) {
	if ((e.clientY - rect.top) < (elm_over.clientHeight / 2)) {
		//マウスカーソルの位置が要素の半分より上
		elm_over.style.borderTop = '2px solid blue';
		elm_over.style.borderBottom = '';
	} else {
		//マウスカーソルの位置が要素の半分より下
		elm_over.style.borderTop = '';
		elm_over.style.borderBottom = '2px solid blue';
	}
}

//ドロップ上下判定
function rectDrop(e, t, rect, elm_drag) {
	if ((e.clientY - rect.top) < (rect.height / 2)) {
		//マウスカーソルの位置が要素の半分より上
		t.parentNode.insertBefore(elm_drag, t);
	} else {
		//マウスカーソルの位置が要素の半分より下
		t.parentNode.insertBefore(elm_drag, t.nextElementSibling);
	}
}


//並べ替え確定
document.getElementById('confirm').addEventListener('click', function () {
	if (window.confirm('メニューの並びの変更を確定していいですか？')) {
		sortConfirm();
	}
});


//並びかえ確定
function sortConfirm() {
	let menuList = elem_box.innerHTML.trim();

	menuList = menuList.replace(/(\r?\n)+/g, "\n");//空行削除
	menuList = menuList.replace(/href="..\/(.*)\/"/g, 'href="<?= $base_path ?>$1/"');//パス修正

	const replaceArray = ['<button class="folder-rename">フォルダ名変更</button>',
		'<button class="folder-del">削除</button>',
		'<button class="btn-lock">ロック変更</button>',
		' title="ダブルクリックするとメニュー名を変更できます。"',
		'<ul class="sub-menu"></ul>',
		'<ul class="emp-ul sub-menu"></ul>',
		' class="lock"',
		' class=""',
		' style=""',
		'<span class="icon-slide"></span>',
		' draggable="true"'
	];

	replaceArray.forEach(function (value) {
		menuList = menuList.replaceAll(value, '');
	});

	menuList = menuList.replace(/<li/g, '\n<li');
	menuList = menuList.replace(/<ul/g, '\n<ul');
	menuList = menuList.replace(/<\/ul>/g, '\n</ul>');

	menuList = menuList.replace(/<span class="link-name">(.*)<\/span>/g, '');

	const formData = new FormData;
	formData.append('post_menu', menuList);

	fetch('menu_confirm.php', {
		method: 'POST',
		body: formData,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response.text();
		})
		.then(data => {
			alert('メニューの並びを変更しました。');
		})
		.catch((reason) => {
			alert('失敗しました～。')
		});
}

//リンク無効化
document.querySelectorAll('a').forEach(elm => {
	elm.addEventListener('click', e => {
		e.preventDefault();
	});
});

//ファルダ名変更
document.querySelectorAll('.folder-rename').forEach(elm => {
	elm.addEventListener('click', e => {
		let folderName = e.target.previousSibling.textContent;
		let menuId = e.target.parentNode.getAttribute('id');
		let folderReName = prompt('フォルダ名を変更して「ok」を押すと元には戻せません。（「p__」は必ず頭に付けて下さい。）', folderName);

		if (folderReName == null || folderName == folderReName) {//キャンセルまたは名前を変えずにokを押した場合

		} else if (folderReName == '') {
			alert('フォルダ名の値が空です');

		} else if (!/^p__/.test(folderReName)) {
			alert('フォルダ名の先頭に「p__」を付けて下さい。');

		} else if (!/^p__./.test(folderReName)) {
			alert('フォルダ名の先頭の「p__」の後に文字を記入してください。');

		} else {
			const formData = new FormData;
			formData.append('post_folder', folderName);
			formData.append('post_reName', folderReName);

			fetch('folder_rename.php', {
				method: 'POST',
				body: formData,
			}, { cache: "no-store" })

				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then(data => {
					//通信成功時の処理
					alert(data);
					if (data.match(/変更しました/)) {
						document.querySelector('#' + menuId + '>a').setAttribute('href', '../' + folderReName);
						document.querySelector('#' + menuId + '> span.link-name').textContent = folderReName;
					}
				})
				.then(() => {
					//locklistテーブルに登録があれば、修正した名前を変更する
					const formData1 = new FormData;
					formData1.append('post_folder', folderName);
					formData1.append('post_reName', folderReName);

					fetch('lockdata_edit.php', {
						method: 'POST',
						body: formData1,
					}, { cache: "no-store" })

						.then((response) => {
							if (!response.ok) {
								throw new Error();
							}
							return response.text();
						})
						.then(data => {
							//通信成功時の処理
							console.log('成功しました')
						})
						.catch((reason) => {
							alert('失敗しました～。')
						});

				})
				.catch((reason) => {
					alert('失敗しました～。')
				});

		}

	});
});


//フォルダ新規作成
document.getElementById('create').addEventListener('click', () => {
	const newFolder = prompt('新規にフォルダ名を作成します。「p__」の後に記入してください。', 'p__');
	let idList = [];
	let empId;

	box_items.forEach(elm =>{
		let idNum = elm.getAttribute('id').replace('item', '');
		idNum = Number(idNum);
		idList.push(idNum);
	});

	idList.sort(compareFunc);//並べ替え

	//空いているID値を検索
	for (let i = 1; i <= idList.length; i++) {
		if (!idList.includes(i)) {
			empId = 'item' + i;
			break;
		} else if (i == idList.length) {
			i++
			empId = 'item' + i;
		}
	}


	//ダイアログ返答が「はい」なら実行
	if (newFolder != null) {
		const formData = new FormData;
		formData.append('post_newFolder', newFolder);
		formData.append('post_empId', empId);

		fetch('folder_create.php', {
			method: 'POST',
			body: formData,
		}, { cache: "no-store" })

			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response.text();
			})
			.then(data => {
				//通信成功時の処理
				if (data.match(/新規作成しました/)) {
					window.location.reload();
				}
			})
			.catch((reason) => {
				alert('失敗しました～。')
			});
	};

});

//並べ替え関数
function compareFunc(a, b) {
	return a - b;
}


//ロック設定・解除
document.querySelectorAll('.btn-lock').forEach(elm => {
	elm.addEventListener('click', e => {
		if (window.confirm('閲覧ロックの設定を変更していいですか？')) {
			let folderName = e.target.parentNode.children[1].textContent;
			const formData = new FormData;
			formData.append('post_folder', folderName);

			fetch('page_lock.php', {
				method: 'POST',
				body: formData,
			}, { cache: "no-store" })
				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then(data => {
					//通信成功時の処理
					e.target.parentNode.children[0].classList.toggle('lock');
				})
				.catch((reason) => {
					alert('失敗しました～。')
				});
		};
	});
});


//フォルダ削除
document.querySelectorAll('.folder-del').forEach(elm => {
	elm.addEventListener('click', e => {
		// let chObj = '';
		// let listObj = e.target.closest('li');
		let listName = e.target.parentNode.children[0].textContent;
		let listFolder = e.target.parentNode.children[0].getAttribute('href').split('/')[1];

		if (window.confirm(listName + ' 【' + listFolder + '（フォルダ名）】を削除していいですか？\n（削除すると元に戻せません。）\n※削除した後は、一旦いまのメニューの並びが保存されます。')) {
			//メニュー操作
			if(e.target.parentNode.getAttribute('id')=='menu'){
				//第一階層メニュー
				e.target.closest('li').remove();

			}else if(e.target.closest('ul').children.length>1){
				//サブメニュー内に他にもメニューがある場合
				e.target.closest('li').remove();
			}else{
				//サブメニュー内にクリックしたメニューが1つだけの場合、サブメニューごと削除
				e.target.closest('ul.sub-menu').remove();
			}

			sortConfirm();//メニュー保存



			//フォルダ操作
			const formData = new FormData;
			formData.append('post_delFolder', listFolder);

			fetch('folder_delete.php', {
				method: 'POST',
				body: formData,
			}, { cache: "no-store" })
				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then(data => {
					//通信成功時の処理
					if (!data.match(/削除するフォルダがありません/)) {
						alert('削除しました。');

						subEmpDelete();//親メニューの▲を削除

						//データベースのlocklistテーブルに登録があれば削除する
						const formData2 = new FormData;
						formData2.append('post_delFolder', listFolder);

						fetch('lockdata_del.php', {
							method: 'POST',
							body: formData,
						}, { cache: "no-store" })
							.then((response) => {
								if (!response.ok) {
									throw new Error();
								}
								return response.text();
							})
							.then(data => {
								//通信成功時の処理
								//alert('DBの閲覧不可の登録を削除しました');
							})
							.catch((reason) => {
								alert('失敗しました～。')
							});

					} else {
						alert(data);
					}
				})
				.catch((reason) => {
					alert('失敗しました～。')
				});
		}
	})
})

//メニュー名変更
document.querySelectorAll('#menu li a').forEach(elm => {
	elm.addEventListener('dblclick', function (e) {
		let menuName = this.textContent;
		let menuId = this.closest('li').getAttribute('id');
		let folderName = this.getAttribute('href').split('/')[1];
		let menuReName = prompt('名前を変更して「ok」を押してください', menuName);
	
		if (menuName != menuReName && menuReName != '' && menuReName != null) {
	
			const formData3 = new FormData;
			formData3.append('post_menu', menuName);
			formData3.append('post_reName', menuReName);
			formData3.append('post_folder', folderName);
	
			fetch('file_rename.php', {
				method: 'POST',
				body: formData3,
			}, { cache: "no-store" })
				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then(data => {
					//通信成功時の処理
					alert(data);
					if (data.match(/変更しました/)) {
						document.getElementById(menuId).firstElementChild.textContent=menuReName;
					}
	
				})
				.catch((reason) => {
					alert('失敗しました～。1')
				});
	
		} else if (menuReName == '') {
			alert('メニュー名の値が空です');
		}
	
		e.stopPropagation();
	});
});


//全サブメニュー開閉
document.querySelectorAll('.btn-sub-close').forEach(elm => {
	elm.addEventListener('click', function () {
		document.querySelectorAll('.sub-menu').forEach(e=>{
			// e.classList.toggle('d-none');
			e.closest('.box-item').classList.toggle('s-close');
		});
	});
});

//「▼」アイコンクリックでサブメニューを開閉
document.addEventListener('click', function(e) {
	if(e.target && e.target.className=='icon-slide'){
		e.target.closest('.box-item').classList.toggle('s-close');
	}
});
