---
title: '15. データベースを準備する'
media_order: 'sqlite02.png,db_browser02.png,db_browser.png,db_browser1.png,db_browser3.png,db_browser4.png,sqlite_command.png,browse_data1.png,browse_data2.png,browse_data3.png,browse_data4.png,database_insert_into.png,shop_db.png,shop_db.png'
taxonomy:
    category:
        - docs
---

データベースを利用するためには、それなりの準備が必要です。Laravelから利用するための設定などを行い、いつ でもデータベースが使える状態にしましょう。

## モデルとデータベース
MVC (Model-View-Controller)の中でも、特に使いこなしが難しいのが「*モデル (Model)*」でしょう。モデルはデータの管理を行うところ。わかりやすくいえば、「データベースの処理」を担当する部分です。  
データベースの利用というのは、さまざまなアプローチがあります。また利用の仕方もアプリケーションによって千差万別です。  
MVCは「モデルでデータベースを扱う」というのが基本ですが、多くのフレームワーク では、漠然と「モデルというオブジェクトを用意して、そこにデータベースの処理を全部押し込めればいいだろう」と考えて設計しているように思えます。それは間違いではないでしょうが、ベストな方法かどうかはわかりません。

例えば、ID番号からコンテンツをもらって表示するだけのアプリと、ログインしてユーザーのIDとコンテンツの細かな情報を常にデータベースで照らし合わせながら動いてい る複雑なアプリとでは、データベースの役割もずいぶんと違います。  
ただデータベースから指定のIDのデータを貰うだけの「データの保管庫」としてデータベースを使っているようなものは、コントローラの中にほんの数行処理を書くだけでデータベース・アクセスは終わってしまうでしょう。そのためにモデルを作成して、それを設定して......などとやるのはかえって大変です。「もっとダイレクトにデータベー スを使わせてくれ」と思うでしょう。  
逆に、多数のテーブルを連携させて複雑なデータ処理を行っているような場合、コントローラでデータベースの処理を書いたらそれだけで数十行の処理になってしまうかもしれません。コントローラなのに処理の大半がデータベース関係というのでは「鬱陶しい。モデルに切り離してもっとわかりやすくまとめられるようにしてくれ!」となるでしょう。

データベースのアプローチというのは、「これ1つで万能」といったものはありません。 さまざまな用途に合わせて、いくつものアプローチが用意されている方が、複雑そうに 見えても実は楽なのです。

## Laravelのアプローチ
Laravelでは、データベース処理のためにいくつかの機能を用意しています。以下に簡単に整理しておきましょう。

### DB クラス(クエリビルダ)
もっともシンプルなアプローチは、「***DB***」クラスを利用する方法です。これは、データベースアクセスのための基本的な機能をまとめたクラスで、ここにあるメソッドを呼び 出すことでデータベースにアクセスできます。  
*このDBクラスではデータベースにアクセスするためのクエリを生成し、送信することができます*。SQLクエリを直接実行するのに近い感じですので、DBクラスを利用するこ とで格段にデータベース利用が楽になった、というほどのインパクトはないかもしれませんが、手軽にデータベースを利用するには最適な方法です。  
また、「***クエリビルダ***」と呼ばれる機能が用意されており、これを利用すると*メソッドを使ってデータベースにアクセスすることができます*。SQLよりもPHPらしい処理が作れるようになるでしょう。

### Eloquent (ORM)
これは、ORM(Object-Relational Mapping)と呼ばれる機能をLaravelに実装したものです。ORMは、データベースのデータとプログラミング言語のオブジェクトの間を取り持 つもので、*データベースのデータをシームレスに言語のオブジェクトに変換し、操作できるようにします*。  
Laravelに搭載されているEloquent(エロクアント)というORMを使うと、DBクラスなどよりはるかにPHPのオブジェクトらしいアプローチでデータベースを利用できます。  
ごく普通のSQLデータベースを扱う場合、DBクラスかEloquent ORMのどちらかを使うことになるでしょう。本書では、まずDBクラスを使ってデータベースの基本操作を学び、それからEloquent ORMの利用について説明をしていきます。


## MySQL/PostgreSQLDRE

おそらく利用ユーザー が多いのはMySQLとPostgreSQLでしょう。これらの設定項目についてここで整理しておきましょう。

サンプルとして、下記のshop.sqlをダウンロードをしてshopデータベースをMySQLに設置します。

[shop.sql](../../../sample/laravel/shop_db/shop.sql)

そうすると、下図のようなデータベースとテーブルが作成されます。  
これを利用してデータベースの操作の仕組みを説明していきます。
![](shop_db.png)
## DB利用のための手続き 
データベースを設置したら、利用できるように設定を行います。  
Laravelでは、データベースの利用に関する設定ファイルが用意されています。  
使用するデータベースの情報は、「**config**」フォルダにある「**database.php**」というファイルに用意されています。このファイルには、以下のようなスクリプトが記述されています(一部省略)。

<p class="tmp list"><span>リスト1</span>config/database.php</p>
初期値は、mysqlに設定されています。
```
<?php

return [

   'default' => env('DB_CONNECTION', 'mysql'),

   'connections' => [

       'sqlite' => [
           'driver' => 'sqlite',
           'database' => env('DB_DATABASE', 
                 database_path('database.sqlite')),
           'prefix' => '',
       ],

       'mysql' => [
           'driver' => 'mysql',
           'host' => env('DB_HOST', '127.0.0.1'),
           'port' => env('DB_PORT', '3306'),
           'database' => env('DB_DATABASE', 'forge'),
           'username' => env('DB_USERNAME', 'forge'),
           'password' => env('DB_PASSWORD', ''),
           'unix_socket' => env('DB_SOCKET', ''),
           'charset' => 'utf8mb4',
           'collation' => 'utf8mb4_unicode_ci',
           'prefix' => '',
           'strict' => true,
           'engine' => null,
       ],

       'pgsql' => [
           'driver' => 'pgsql',
           'host' => env('DB_HOST', '127.0.0.1'),
           'port' => env('DB_PORT', '5432'),
           'database' => env('DB_DATABASE', 'forge'),
           'username' => env('DB_USERNAME', 'forge'),
           'password' => env('DB_PASSWORD', ''),
           'charset' => 'utf8',
           'prefix' => '',
           'schema' => 'public',
           'sslmode' => 'prefer',
       ],

       'sqlsrv' => [
           'driver' => 'sqlsrv',
           'host' => env('DB_HOST', 'localhost'),
           'port' => env('DB_PORT', '1433'),
           'database' => env('DB_DATABASE', 'forge'),
           'username' => env('DB_USERNAME', 'forge'),
           'password' => env('DB_PASSWORD', ''),
           'charset' => 'utf8',
           'prefix' => '',
       ],

   ],

   ……以下略……

];
```

ここでは、配列の中にデータベース関連の設定がまとめられています。  
よく見ると、それぞれのデータベースごとに設定が用意されていることがわかるでしょう。これをもう少し整理すると以下のようになるでしょう。

### データベースの設定

```
<?php
return [
    'default' => env('DB_CONNECTION', 設定名 ),
    'connections' => [
        'sqlite' => [ ......SQLiteの設定...... ],
        'mysql' => [...MySQLの設定...... ],
        'pgsql' => [ ......PostgreSQLの設定... ],
        'sqlsrv' => [ ......SQL Serverの設定..... ],
    ],
    ......以下略......
];
```

'connections'という配列の中に、各データベースの設定がまとめられています。そし て、'default"というキーワードにenvという関数が用意されています。これは、Laravel の環境変数を設定する関数で、ここでは'DB CONNECTION'というキーワードの値を 変更しています。この値が、実際に使用されるデータベース設定となります。
デフォルトでは、'mysql"がDB_CONNECTIONに設定されています。これで、MySQL がデフォルトのデータベースに設定されることになるのです。




```
'driver' => 'mysql' または 'pgsql,
```
ドライバー名の指定です。これは、MySQLならば'mysql'、PostgreSQLなら'pgsql'と指定します。
```
'host' => env('DB_HOST', '127.0.0.1'), 'port' => env('DB_PORT', '3306' または 15432'),
```
データベースサーバーのホストの指定(IPアドレスまたはドメイン)と、使用ポートの指定です。ポート番号は、MySQLの場合は3306、PostgreSQLでは'5432"をデフォルトで使っています。
```
'database' => env('DB_DATABASE', 'forge'),
```
使用するデータベース名です。SQLiteではデータベース ファイルの名前ですが、MySQL/PostgreSQLはサーバーに用意されているデータベース名を指定します。
```
'username' => env('DB_USERNAME', 'forge'), 'password' => env('DB_PASSWORD', '"),
```
データベースにアクセスする際に使用するユーザー名とパスワードです。セキュリティの点から、パスワードは必ず設定するようにしましょう。
```
'unix_socket' => env('DB_SOCKET', ''),
```
MySQLの設定に用意されています。これは使用するソケットファイルを指定するものです。デフォルトでは空になっています。
```
'charset' => 'utf8mb4', 'collation' => 'utf8mb4_unicode_ci',
```
<p>使用するキャラクタエンコーディングの指定です。ユニコードを使っているなら ば、MySQLでは 'uff8mb4'、PostgreSQLは"utf8' としておきます。<br>
またMySQLの場合は、 collationに 'utf8mb4_unicode_ci' を指定しておきます。</p>
```
'prefix' => '',
```
これも登場しました。データベースのプレフィクスの指定です。特に必要なければ空のままでOKです。
```
'strict' => true, 'engine' => null,
```
いずれもMySQL用の設定です。'strict'は、ストリクトモードのON/OFF指定です。また 'engine'は使用するストレージエンジンの指定です。  
これらの多くはデフォルトのままで問題ありません。最低限必要となるのは、***host***、 ***database***、***username***、***password***の4つでしょう。  
これらは、それぞれの環境に合わせて設定変更する必要があります。


<p class="tmp list"><span>リスト2</span>config/database.php</p>

mysqlの項目の箇所をshop用に以下のように書き換えます。
```
'mysql' => [
	'driver' => 'mysql',
	'url' => env('DATABASE_URL'),
	'host' => env('DB_HOST', '127.0.0.1'),
	'port' => env('DB_PORT', '3306'),
	'database' => env('DB_DATABASE', 'shop'),
	'username' => env('DB_USERNAME', 'staff'),
	'password' => env('DB_PASSWORD', 'password'),
	'unix_socket' => env('DB_SOCKET', ''),
	'charset' => 'utf8mb4',
	'collation' => 'utf8mb4_unicode_ci',
	'prefix' => '',
	'prefix_indexes' => true,
	'strict' => true,
	'engine' => null,
	'options' => extension_loaded('pdo_mysql') ? array_filter([
		PDO::MYSQL_ATTR_SSL_CA => env('MYSQL_ATTR_SSL_CA'),
	]) : [],
],
```

## .envの環境変数について
これでデータベースの設定は完了しましたが、実はもう1つ設定しておかなければいけないものがあります。それは、Laravelの「***環境変数***」です。

Laravelでは、「.env」というファイルに環境変数がまとめられています。これは、Laravelの基本的な動作環境に関する変数です。  
このファイルを開き、「DB_CONNECTION」と「DB_DATABASE」という2つの項目を探して、以下のように修正して下さい。

<p class="tmp list"><span>リスト3</span>.env</p>
DB_DATABASEには、shopデータベースを指定します。
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=shop
DB_USERNAME=staff
DB_PASSWORD=password
```
これでデータベースの設定は完了です。


















