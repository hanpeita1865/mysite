---
title: Promise
taxonomy:
    category:
        - docs
---

PromiseとはJavaScriptにおいて、非同期処理の操作が完了したときに結果を返すものです。 結果には2通りあり、成功（完了や解決とも）と失敗（エラーや拒否とも）です。成功時には引数で渡される関数**resolve**を、失敗時には引数で渡される**reject**を呼び出すように記述します。


非同期処理とは、ある処理が実行されてから終わるまで待たずに、次に控えている別の処理を行うことです。

なぜこのような仕組みがあるのでしょうか？

JavaScriptはシングルスレッドでしか動かない性質があるため、複数の処理を並列で走らせることができません。 そのため効率的に処理をするために考えられた仕組みが非同期処理と呼ばれるものです。


## resolveメソッドとは

resolveメソッドとは、引数に渡した値で解決したPromiseを返す関数です。resolveメソッドがPromiseオブジェクトを返すことによって、さらにthenとcatchで繋ぐことができます。

<p class="tmp exp"><span>例1</span>resolveメソッドの使い方1</p>
<script async src="//jsfiddle.net/cqhm8wdx/embed/js,result/"></script>

resolveメソッドの引数へSUCCESSの文字列を渡して呼び出します。  
これがPromiseを返すので、thenメソッドの引数に渡したハンドラ（関数のこと）が呼び出されます。  
引数sにはSUCCESSの文字列が代入されており、結果としてコンソールにSUCCESSの文字が出力されます。

アロー関数を使わない場合は、下記になります。

<p class="tmp exp"><span>例1-1</span>アロー関数を使わない書き方</p>
<script async src="//jsfiddle.net/Ly43kw6q/1/embed/js,result/"></script>


これらだけでは非同期処理っぽくないので、少しコードを変えてみましょう。

<p class="tmp exp"><span>例2</span>resolveメソッドの使い方2</p>
<script async src="//jsfiddle.net/enabs86v/embed/js,result/"></script>

これで、1秒後にコンソールにSUCCESSの文字が出力されるようになりました。

アロー関数を使わない場合は、下記になります。
<p class="tmp exp"><span>例2-1</span>アロー関数を使わない書き方</p>
<script async src="//jsfiddle.net/d8ro0z1y/embed/js,result/"></script>

### resolveメソッドに複数の値を渡す方法

resolveメソッドに複数の値を渡すには、配列もしくはオブジェクトを使います。まずは、配列を使って複数の値を渡してみます。

<p class="tmp exp"><span>例3</span></p>
<script async src="//jsfiddle.net/f1so7pyg/embed/js,result/"></script>

コンソールに配列のすべての値が出力されます。次に、オブジェクトを使って複数の値を渡してみます。

<p class="tmp exp"><span>例4</span></p>
<script async src="//jsfiddle.net/80cs47kz/embed/js,result/"></script>




## コールバック関数地獄

コールバックは使い勝手がいい反面、使いすぎるとコードが非常に読みにくくなる欠点があります。また関数から関数を呼ぶ処理を繰り返しすぎると、あとで問題が発生したときに調べることが手間になりがちです。これをコールバック関数地獄と言います。

非同期処理のコールバック例
```
sampleFunction1(function(data1) {

    sampleFunction2(function(data2) {
        
        sampleFunction3(function(data3) {
            
            sampleFunction4(function(data4) {
                //処理
            });
            
        });
        
    });
    
});
```
JavaScriptにおける非同期処理のコールバック関数地獄はネストが深くなる上に、エラー処理が相まって、可読性を著しく下げる傾向があります。このコールバック地獄を避けるために考えられたの仕組みが、***Promise***です。

## Promiseの処理を連結させる方法
チェインを使って処理を連結させた例が以下コードになります。

コードの中身は、getNumber関数は渡された数字numを受け取り、numに対して3を2回加算するというものです。

.thenを3回連続で使用している箇所がありますが、これがチェインと呼ばれるものです。このように、Promiseでは複数の処理を連続で処理させることが可能です。


<p class="tmp exp"><span>例5</span></p>
<script async src="//jsfiddle.net/k0e3hug6/embed/js,result/"></script>


## allを使って複数の非同期処理を同時に行う
allを使うことで、複数の非同期処理を同時に実行することができます。

書き方は以下の通りです。

<p class="tmp"><span>書式1</span></p>
```
Promise.all(iterable).then(function(message) {
    // 結果を表示する処理
}
```

<p class="tmp exp"><span>例6</span></p>
<script async src="//jsfiddle.net/rbhv4tm9/embed/js,result/"></script>


allはすべての非同期処理がresolveされたタイミングで結果を返します。

上のサンプルの例ですと、promise1は300ms後, promise3は500ms後に処理されることになっていますが、1000ms後にresolveされるpromise2が完了したタイミングで結果を返します。

ですので上のサンプルコードは

* console.log("First");
* console.log("Second");
* setTimeout(function(){console.log("Third")}, 600);
* Promise.all([promise1, promise2, promise3])~

の順番で結果を返していることがわかります。


## catchを使ったエラーハンドリングのやり方

エラーハンドリングを行うために必要である、catchの使い方を説明します。  
catchを使うことで、チェインを実行している最中にエラーが発生してもエラーを捕まえることができます。  
下のコードでは2つ目のチェインに入った段階でエラーを発生させているので、3を加算した結果である「6」を返す前にエラーメッセージを表示させます。

<p class="tmp exp"><span>例7</span></p>
<script async src="//jsfiddle.net/0djtqpc4/embed/js,result/"></script>

Promiseをおさらいすると、以下のようになります。

* Promiseは処理が成功すればresolveを返し、失敗ならrejectを返す
* Promiseを使うと、ネストを深くせずに非同期処理のコールバック関数が書ける
* チェインを使うことで、複数の処理を連続して処理できるようになる
* allはすべての非同期処理が完了した時点で、resolveを返す
* catchを使い、エラーが発生した時点でエラーを返すようにできる

これらの特性から、非同期処理時はPromiseを使うようにすると、コード記述時にミスやエラーが発生する可能性を減らすことができます。



## 参考サイト

* [【JavaScript】初心者にもわかるPromiseの使い方プログラミング](https://techplay.jp/column/581)
* [JavaScriptのresolveメソッドの使い方を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/29267)