<?php
use DI\Container;
use Slim\Factory\AppFactory;
use Slim\Views\Twig;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

require 'admin/basepath.php';

$container = new Container();
$container->set("view",
    function() {
        global $basePath;
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"].$basePath."/templates");
        return $twig;
    }
);

$container->set("logger",
    function() {
        global $basePath;
        $logger = new Logger("slimmiddle");
        $fileHandler = new StreamHandler($_SERVER["DOCUMENT_ROOT"].$basePath."/logs/app.log");
        $logger->pushHandler($fileHandler);
        return $logger;
    }
);

//PDOインスタンスを生成する処理　追加箇所
$container->set("db",
    function(){
        //DB接続情報を表す変数
        $database='from_now';
        $dbUsername = "staff";
        $dbPassword = "password";

        //PDOインスタンスを生成。DB接続
        $db=new PDO('mysql:host=localhost:3306;dbname='.$database.';charset=utf8',$dbUsername, $dbPassword);//MySQLに接続

        //PDOエラー表示モードを例外モードに設定
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //プリペアドステートメントを有効に設定
        $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        //フェッチモードをカラム名のみの結果セットに設定
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        //PDOインスタンスをリターン
        return $db;
    }
);


$folderObj = [];//ディレクトリ格納用オブジェクト
$folderArray = [];//ページディレクトリ配列

//フォルダ構成をセット
$container->set("folderComp",
    function(){
        global $folderObj;
        globAll('../pages');
        return $folderObj;
    }
);


//マークダウン変換
$container->set("mark",
    function(){
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        global $basePath;
        global $folderObj;
        global $folderName;

        if(!empty($folderObj[$folderName])){

            $folderPath = $folderObj[$folderName];
            $folderPath1 = str_replace('..','',$folderPath);//「..」を削除　例)/pages/001.js/001.js_base/002.js_cls_obj_lecture

            $Extra = new ParsedownExtra();
    
            //マークダウンファイル取得
            $md = file_get_contents($_SERVER["DOCUMENT_ROOT"].$basePath.'/pages/'.$folderPath.'/markdown.md');
    
    
            //ページタイトル取得
            preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
            $title = $ArrayTitle[1];//ページタイトル
    
            //HTMLに変換
            $htmlData = $Extra->text($md);

            //画像のパスを変換
            $htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="'.$basePath.$folderPath1.'/upload/$2"$3>', $htmlData);
            //ファイルリンクのパスを変換
            $htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="'.$basePath.$folderPath1.'/upload/$2"$3>', $htmlData);

            //sampleのパスを変換
            $htmlData = preg_replace('/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="'.$basePath.$folderPath1.'/sample/$2" target="_blank">$4</a>', $htmlData);

            //iframeのパスを変換
            $htmlData = preg_replace('/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i','<iframe$1src="'.$basePath.$folderPath1.'/sample/$2"$3></iframe>', $htmlData);

            $markArray = ['html'=> $htmlData, 'title'=> $title];

        }else{
            $markArray = ['html'=> 'ページが存在しません。', 'title'=> ''];
        }
        return $markArray;
    }
);


function globAll($folder) {
    global $folderObj;
    global $folderArray;

    if (!is_file($folder)) {
        $res = glob($folder . '/*'); 

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {
                $folderNoNum = preg_replace('/^\d{3}./','', $lastDir);
                $folderObj[$folderNoNum] = $f;//「〇〇.」ディレクトリをオブジェクトに格納
                $folderArray[] = $f;//ページフォルダのディレクトリを配列に格納
   
                globAll($f);
            }
        }
    }
}


//マークダウン変換
function md2html($md)
{
    $Extra = new ParsedownExtra();
    $html = $Extra->text($md);

    return $html;
}

//プレビュー用
$container->set("preview",
    function(){
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        $Extra = new ParsedownExtra();

        global $basePath;
        global $folderObj;

 
        $md = $_REQUEST['report-p'];//記事原文
        $title = $_REQUEST['pagename-p'];//タイトル
        $folderPath = $_REQUEST['folderPath-p'];//パス
        $folderName = $_REQUEST['folder-p'];//フォルダ名

        $folderPath = $folderObj[$folderName];
        $folderPath1 = str_replace('..','',$folderPath);

        $htmlData = $Extra->text($md);

        //画像のパスを変換
        $htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="'.$basePath.$folderPath1.'/upload/$2"$3>', $htmlData);
        //ファイルリンクのパスを変換
        $htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="'.$basePath.$folderPath1.'/upload/$2"$3>', $htmlData);

        //sampleのパスを変換
        $htmlData = preg_replace('/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="'.$basePath.$folderPath1.'/sample/$2" target="_blank">$4</a>', $htmlData);

        //iframeのパスを変換
        $htmlData = preg_replace('/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i','<iframe$1src="'.$basePath.$folderPath1.'/sample/$2"$3></iframe>', $htmlData);


        $markArray = ['html'=> $htmlData, 'title'=> $title];

        return $markArray;
    }
);


AppFactory::setContainer($container);