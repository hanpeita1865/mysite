---
title: '08. スライドメニュー'
taxonomy:
    category:
        - docs
visible: true
---

まず，スライドメニューとはどのようなものか，次のサンプルで説明します．

<iframe width="100%" height="600" src="//jsfiddle.net/bjqnvc03/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

結果を見てみましょう．  
左上の三重線（形からハンバーガーといいます）をクリックしてみましょう．  
そうすると，左側からサイドメニューが現れます．  
このようにスライドしてメニューが現れるものをスライドメニューといいます．

HTMLを見てみましょう．  
上からメインコンテンツ，開閉用ボタン，スライドメニュー，オーバーレイが用意されています．  
オーバーレイはスライドメニューが表示されているとき，メインコンテンツを上から覆い，  
開閉用ボタンをクリックしなくても，コンテンツ（オーバーレイ）をクリックすれば，  
メニューを閉じることができるようにするため使用します．

CSSを見てみましょう．重要なスタイルだけ説明します．  
<div class="box-example">
<h3 class="h-example">図1</h3>
開閉ボタンの位置の固定
<img src="http://10.183.122.52:55503/3/img/slidemenu1.png">
</div>

<div class="box-example">
<h3 class="h-example">図2</h3>
開閉ボタンの形
<img src="http://10.183.122.52:55503/3/img/slidemenu2.png">
</div>

図1・2の方法で開閉ボタンの形をハンバーガーにします．  
開閉ボタンをクリックしたとき，スクリプトで<strong>.activeクラス</strong>を追加することで，  
ハンバーガーを×印に変形するようにします．  
そのときのスタイルが図3です．

<div class="box-example">
<h3 class="h-example">図3</h3>
開閉ボタンの変形
<img src="http://10.183.122.52:55503/3/img/slidemenu3.png">
</div>

図3の方法で開閉ボタンの形が×印になります．  
変形の速度は<strong>.menu-trigger span</strong>に記述されている，  
<strong>transitionプロパティ</strong>に示された0.5秒です．

<div class="box-example">
<h3 class="h-example">図4</h3>
スライドメニューの位置
<img src="http://10.183.122.52:55503/3/img/slidemenu4.png">
</div>

図4の青い点線内がwindowです．スライドメニューがwindow外にあることがわかります．  
このようにスライドメニューを使用しないときは，windowの外に隠しておきます．  
開閉ボタンをクリックしたとき，スクリプトで<strong>.openクラス</strong>を追加することで，  
<strong>transformプロパティ</strong>で設定した-200pxが0になり，メニューが現れます．  
また，変形の速度はnavの<strong>transitionプロパティ</strong>に示された0.5秒です．

開閉用ボタン，スライドメニュー，オーバーレイの3つのアイテムの重なり順を，  
<strong>z-indexプロパティ</strong>によって設定します．数値が大きくなるほど重なりの上になります．  
　　上　　z-index: 100;　　→　.menu-trigger  
　　中　　z-index: 10; 　　→　nav  
　　下　　z-index: 2; 　　 →　.overlay  

スクリプトを見てみましょう．
<div class="box-example">
<h3 class="h-example">開閉用ボタンをクリックしたとき</h3>
if ($(this).hasClass('active'))によって，開閉ボタンが<strong>.activeクラス</strong>を持っているか調べます．<br><br>
持っていたとき<br>
<strong>removeClass</strong>によって開閉ボタンから<strong>.activeクラス</strong>を，スライドメニューとオーバーレイから<strong>.openクラス</strong>を削除します．<br><br>
持っていないとき<br>
<strong>addClass</strong>によって開閉ボタンに<strong>.activeクラス</strong>を，スライドメニューとオーバーレイに<strong>.openクラス</strong>を追加します．
</div>

<div class="box-example">
<h3 class="h-example">オーバーレイをクリックしたとき</h3>
if ($(this).hasClass('open'))によって，オーバーレイが<strong>.openクラス</strong>を持っているか調べます．<br><br>
持っていたとき<br>
<strong>removeClass</strong>によって開閉ボタンから<strong>.activeクラス</strong>を，スライドメニューとオーバーレイから<strong>.openクラス</strong>を削除します．
</div>