*[page-title]:リソースコントローラとRESTful


Webの世界では、「<span class="green bold marker-yellow50">REST</span>」と呼ばれるサービスがあります。このRESTに対応した<span class="green bold marker-yellow50">（RESTful） サービス</span>を作成する方法について説明します。


## RESTfulとは？

Webアプリケーションというのは、ここまで作成してきたように、いくつかのWebペー ジがあり、そこにアクセスをするとアプリケーションの画面が表示され、そこでさまざまな作業などを行うような仕組みになっています。画面には各種の表示やインターフェイスとなるGUI部品が表示され、それらを操作していくわけです。

ところが、Webの世界では、こうした「画面に表示される部分」を持たないものもあります。「<span class="bold">Webサービス</span>」と呼ばれるものなどがそれです。これらは、サーバーにアクセスして必要な情報を取得したり、情報を送って保存したりできますが、しかし一般的なWebアプリに見られるような画面表示は持っていません。

こうしたWebサービスは、利用者が自分でWebブラウザからアクセスして利用するのではなく、<span class="red">他のプログラムがアクセスして利用する</span>ためのものと考えてよいでしょう。 こうしたWebサービスの分野でよく耳にするのが「<span class="green bold">REST</span>」あるいは「<span class="green bold">RESTful</span>」といった言葉です。


### REpresentational State Transfer
RESTというのは、「REpresentational State Transfer」の略で、分散型システムを構築するための考え方です。インターネットのあちこちにプログラムが分散して存在し、それらが相互にやり取りしながら動くようなシステムを考えたとき、どういう仕組みにしたらいいか、その一つの答えがRESTです。

RESTは、HTTPのメソッド(GETやPOSTなど)を使って決まったルールに従ったアドレスにアクセスすることで、必要な情報を取得したり、情報を保存したりできるようにします。HTTPですから、他のサーバーからアクセスして情報を取り出したりできるのです。

このRESTにもとづいて設計されているプログラムは「RESTful」である、と表現されます。RESTfulなサービスは、<span class="bold">情報の取得や送信など基本的な操作の方法が統一されている</span>ため、他のプログラムから簡単にアクセスしてサービスを利用できます。

![](upload/restful1.png "図　RESTは、HTTPのメソッドを使い、必要な情報をやり取りするための仕組みを提供する")


## マイグレーションの作成

では、実際に簡単なサンプルを作成しながらRESTfulサービス開発の手順を説明していくことにしましょう。  
ここでは、ごく簡単なデータベーステーブルを用意し、その情報を取り出したり操作したりするRESTfulサービスに近いものを作成してみます。まずは、サービスで利用するテーブルから作成していきましょう。

これは、マイグレーションファイルを作成して作っていくことにします。まずはマイグレーションファイルを作成しましょう。コマンドプロンプトまたはターミナルでプロ ジェクトのフォルダ（laravelapp」フォルダ）内にカレントディレクトリを移動し、以下のようにコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>マイグレーションファイルを作成</p>
```
php artisan make:migration create_restdata_table
```
これで、下図のように「database」内の「migrations」フォルダ内に、「<span class="red">xxxx_create_restdata_table. php</span>」(xxxxは任意の日時の値)というスクリプトファイルが作成されます。

![](upload/migration_restdataファイル作成.png){.photo-border}

### マイグレーションファイルの記述
では、作成されたマイグレーションファイルのスクリプトを記述しましょう。  
xxxx_ create_restdata_table.phpを開き、以下のように内容を記述して下さい。

<p class="tmp list"><span>リスト1-1</span>xxxx_ create_restdata_table.php（デフォルト）</p>
```
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('restdata', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('restdata');
    }
};
```

<p class="tmp list"><span>リスト1-2</span>xxxx_ create_restdata_table.php</p>
```
<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRestdataTable extends Migration
{
   public function up()
   {
       Schema::create('restdata', function (Blueprint $table) {
           $table->increments('id');
           $table->string('message');
           $table->string('url');
           $table->timestamps();
       });
   }

   public function down()
   {
       Schema::dropIfExists('restdata');
   }
}
```

マイグレーションクラスでは、<span class="red">up</span>でテーブル生成の処理、<span class="red">down</span>でテーブル削除の処理をするのが基本でした。  
テーブルの作成は既に何度か行いましたが、<span class="red">Schema::create</span>というメソッドを使って行います。この第2引数に指定したクロージャ内で、$tableのメソッドを呼び出してフィールドを設定していきます。ここでは、以下のような項目を用意しました。

|フィールド項目|内容|
|:--:|--|
|id|プライマリーキーとなるフィールドです。|
|message|メッセージを保管するものです。|
|url|関連するアドレスを保管するものです。|


ごくシンプルですが、これでよいでしょう。この3つの項目に加え、$table ->timestamps(); でcreated_atとupdated_atを追加してあります。  
downメソッドは、いつもの通りSchema::droplfexistsでテーブルを削除するようにし てあります。

### マイグレーションの実行
では、マイグレーションを実行しましょう。以下のようにコマンドプロンプトまたは ターミナルから実行して下さい。

<p class="tmp cmd"><span>コマンド</span>マイグレーションの実行</p>
```
php artisan migrate
```

「restdata」テーブルが作成されました。
![](upload/restdataテーブル.png "図　空のrestdataテーブル"){.photo-border}



## モデルの作成

ダミーとしていくつかレコードを用意しておく必要があります。が、シードを作成する前に、モデルを作っておくことにしましょう。 コマンドプロンプトまたはターミナルから以下のコマンドを実行して下さい。

<p class="tmp cmd"><span>コマンド</span>モデルの作成</p>
```
php artisan make:model Restdata
```

これで、「Restdata.php」というファイルが「app/Models」フォルダ内に作成されます。これが、今回のrestdataテーブルを扱うモデルとなります。
![](upload/Restdata.php作成.png){.photo-border}

### estdata モデルの記述
では、作成されたRestdata.phpを開き、スクリプトを記述しましょう。以下のように 内容を書き換えて下さい。

<p class="tmp list"><span>リスト2-1</span>Restdata.php</p>
```
<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Restdata extends Model
{
   protected $table = 'restdata';
   protected $guarded = array('id');
  
   public static $rules = array(
       'message' => 'required',
       'url' => 'required'
   );

   public function getData()
   {
       return $this->id . ':' . $this->message 
          . '(' . $this->url . ')';
   }

}
```

ここでは、クラスの最初に「$table」というメンバ変数を用意してあります。これは、テーブル名を指定するためのものです。Eloquentでは、テーブル名はモデル名の複数形になっていますが、今回は「restdata」という単数形複数形がわかりにくい名前なので、ここで は$tableを使って"restdata'テーブルを使うように指定してあります。

※なお、dataの単数形はdatumです。あえて単数形のモデル名というならRestdatumと なるでしょう。

その他は、既に使ったものばかりです。$rulesでバリデーションのルール設定を用意し、getDataで簡単なテキストを出力するようにしておきました。



## シードの作成

では、シードを用意しましょう。まずはシーダーファイルを作ります。コマンドプロンプトまたはターミナルから以下のようにコマンドを実行しましょう。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:seeder RestdataTableSeeder
```

これで、「database」内の「seeds」フォルダ内に「RestdataTableSeeder.php」というファイルが作成されます。

![](upload/RestdataTableSeeder.php作成.png "図　RestdataTableSeeder.php"){.photo-border}

<p class="tmp list"><span>リスト2-2</span>RestdataTableSeeder.php（デフォルト）</p>
```
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class RestdataTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
    }
}
```


### RestdataTableSeederの記述
では、作成されたシーダーファイルを記述しましょう。RestdataTableSeeder.phpを開き、以下のように記述しておきましょう。

<p class="tmp list"><span>リスト2-3</span>database/seeders/RestdataTableSeeder.php</p>
```
<?php
use Illuminate\Database\Seeder;
use App\Models\Restdata;

class RestdataTableSeeder extends Seeder
{
   public function run()
   {
       $param = [
           'message' => 'Google Japan',
           'url' => 'https://www.google.co.jp',
       ];
       $restdata = new Restdata;
       $restdata->fill($param)->save();
       $param = [
           'message' => 'Yahoo Japan',
           'url' => 'https://www.yahoo.co.jp',
       ];
       $restdata = new Restdata;
       $restdata->fill($param)->save();
       $param = [
           'message' => 'MSN Japan',
           'url' => 'http://www.msn.com/ja-jp',
       ];
       $restdata = new Restdata;
       $restdata->fill($param)->save();
   }
}
```

ここでは、ダミーとして3つのレコードを保存するようにしてあります。今回は、DBクラスではなく、先ほど作成したRestdataモデルクラスを使ってレコードを作成しています。

まず、保存する値を連想配列にまとめておき、new Restdataでインスタンスを作成後、 fillで連想配列の値を適用します。そして、saveで保存すれば作業完了です。

### Database Seeder の登録
作成したRestdataTableSeederクラスは、DatabaseSeederに登録をしておかないといけません。「seeder」内にある「DatabaseSeeder.php」を開き、以下のように修正して下さい。

<p class="tmp list"><span>リスト2-4</span>database/seeders/DatabaseSeeder.php</p>
```
<?php
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
   public function run()
   {
       $this->call(RestdataTableSeeder::class);
   }
}
```

これで、シードの実行時にRestdataTableSeederのrunが呼び出され、実行されるようになります。


## シードの実行

では、シードを実行しましょう。コマンドプロンプトまたはターミナルから以下のように実行して下さい。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan db:seed
```

<span class="red">RestdataTableSeeder</span>の<span class="red">run</span>が実行され、用意しておいた3つのダミーレコードがテーブルに登録されます。これで、データベース関連の準備は完了です。
![](upload/restdataテーブルseeder実行.png "図　restdataテーブルにダミーレコード挿入された"){.photo-border}



## RESTコントローラの作成

では、作成されたRestdataモデルを利用したRESTfulサービスを作成しましょう。サービスは、普通のWebアプリと同様、コントローラを作成して作ります。 コマンドプロンプトまたはターミナルから以下のようにコマンドを実行して下さい。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:controller RestappController --resource
```
これで、「Http」内の「Controllers」フォルダ内に「<span class="red">RestappController.php</span>」というファイルが作成されます。

![](upload/rest.controller作成.png "図　「RestappController.php」作成")

今回、コントローラを作成する際に「<span class="red">--resource</span>」というオプションを追記しました。 これは、「リソース」としてコントローラにメソッド類を追記しておくためのものです。

<div class="memo-box" markdown="1">
##### リソースについて
「リソース」というのは、CRUD関係の機能一式をセットにして登録し、扱えるように したものです。通常、コントローラでは1つ1つの機能をメソッドとして用意し、その ルート情報を1つずつ記述していきます。が、リソースとしてルート情報を登録すると、 CRUD関連のアクセスがすべて一括して使えるようになります。  
ただし、アクセスのアドレスやアクションメソッドは最初から決められた形になります。また一式まとめて作成されるため、それらのメソッドは最初から全て作成しておく必要があります。

※CRUDとは？～ Create（登録）、Read（読み出し）、Update（変更）、Delete（削除）の４つの機能のこと。
</div>


## リソースコントローラについて

さて、作成されたRestappController.phpを見てみましょう。これは、デフォルトでいくつものメソッドが用意されています。全スクリプトを挙げておくと以下のようになるでしょう(コメント類は省略してあります)。

<p class="tmp list"><span>リスト3-1</span>RestappController.php</p>
```
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RestappController extends Controller
{
   public function index()
   {
       //
   }

   public function create()
   {
       //
   }

   public function store(Request $request)
   {
       //
   }

   public function show($id)
   {
       //
   }

   public function edit($id)
   {
       //
   }

   public function update(Request $request, $id)
   {
       //
   }

   public function destroy($id)
   {
       //
   }
}
```

### リソースのアクション
このリソースコントローラに用意されているメソッド類は、RESTの基本的な操作に合わせて生成されています。用意されているメソッドについて簡単にまとめると以下のようになるでしょう。

|	操作|	メソッド|
|:--:|:--:|
|一覧表示|	index|
|新規作成|	create、 store|
|レコード表示|	show|
|更新処理|	edit、update|
|削除如理|	destroy|

既にCRUDの基本的な処理は作成しましたから、それぞれがどのような処理を用意すればいいか、だいたい想像がつくでしょう。基本的なプログラムの作りは、普通のコントローラと変わりないのです。ただ、メソッド名が最初から指定されている、という違いがあるだけです。

### ルート情報の追記
では、リソースコントローラに用意されている、これらのアクションメソッドのルー ト情報は、どのように用意すればいいのでしょうか。これは、実はとても簡単です。  
web.phpに、以下のような文を追記して下さい。RestappControllerの7つのアクション メソッドが全て、ルート登録されます。

<p class="tmp list"><span>リスト3-2</span>web.php</p>
```
use App\Http\Controllers\RestappController;

～省略～

Route::resource('rest', 'RestappController');
```

これで、/rest 下にCRUD関係のアクセスがまとめて登録されます。  
<span class="red">Route::resources</span>は、コントローラを作成する際、<span class="red">--resource</span>オプションを付けて生成された7つのアクションを一括して登録する働きをします。

|	アクション|	メソッド|
|:--|:--|
|/コントローラ|	index|
|/コントローラ/create|	create|
|/コントローラ|	store(POST送信)|
|/コントローラ/番号|	show(番号 = ID)|
|/コントローラ/番号/edit|	 edit(番号 = ID)|
|/コントローラ/番号|	update(番号 = ID、PUT/PATCH送信)|
|/コントローラ/番号|	delete(番号 = ID、DELETE送信)|

     
このようなアクセスを行うコントローラ（リソースコントローラ）をLaravelでは 「Resourceful(リソースフル)」である、と表現します。Resourcefulなコントローラでは、 CRUDの基本的なアクセスを一式セットで用意してくれるのです。


## indexおよびshowを作成する

では、コントローラのアクションメソッドを使ってみましょう。ここでは、レコード データを取得する<span class="bold">index</span>と<span class="bold">show</span>メソッドを用意してみます。

<p class="tmp list"><span>リスト4-1</span>RestappController.php</p>
```
//use App\Models\Restdata;　を追記

public function index()
{
   $items = Restdata::all();
   return $items->toArray();
}

public function show($id)
{
   $item = Restdata::find($id);
   return $item->toArray();
}
```


実際にアクセスをしてみましょう。
![](upload/restdataテーブルの値.png "図　restdataテーブルのレコード"){.photo-border}
/restにアクセスすると、登録された全レコードがJSON形式によるデータの配列として出力されます。
![](upload/restにアクセス.png "図 「/rest」にアクセス→すべてのレコードをJSON形式の配列として出力"){.photo-border}

また、/ rest/1というようにID番号をつけてアクセスすると、そのID番号のレコードがJSON形式で出力されます。
![](upload/rest_1にアクセス.png "図 「/rest/1」にアクセス→id=1のレコードがJSON形式で出力")


### JSON は配列を return する
ここでは、JSONデータを生成するための特別な作業は行っていません。ただ、Restdata:tallで取得したコレクションから、toArrayというメソッドを使って配列の形で レコード情報を取り出し、それをreturnしているだけです。  

実はLaravelでは、アクションメソッドで配列をreturnすると、自動的にその配列デー タをJSON形式に変換して出力してくれるようになっているのです。JSON形式であれば、 外部のサーバーからアクセスして、取得したデータを簡単に処理することができます。



## レコードの追加

レコードの追加や更新などは、やはりフォームなどのGUIが必要となります。が、可能であれば、そうしたフォームを他のコントロールなどからでも簡単に組み込んで利用できるようにしておきたいところです。そうすることで、レコード作成もサービスとして開放することができます。

では、サンプルのフォームテンプレートを作成し、それを他のコントローラから読み込んで利用する、ということをやってみましょう。

### create.blade.phpの作成
まずは、フォームのテンプレートを作成します。これは、「views」内に新たに「rest」と いうフォルダを作成し、その中に配置することにしましょう。フォルダを用意できたら、 「create.blade.php」という名前でファイルを作成して下さい。ソースコードは以下のように記述しておきます。

<p class="tmp list"><span>リスト4-2</span>create.blade.php</p>
```
<table>
<form action="/rest" method="post">
   {{ csrf_field() }}
   <tr><th>message: </th><td><input type="text" name="message"
       value="{{old('message')}}"></td></tr>
   <tr><th>url: </th><td><input type="text" name="url"
       value="{{old('url')}}"></td></tr>
   <tr><th></th><td><input type="submit" value="send"></td></tr>
</form>
</table>
```

見ればわかるように、フォームだけのテンプレートです。送信先は、/restを指定しておきます。Resourcefulでは、レコードの作成は/rest/createにGETアクセスしてフォームを表示し、/restにPOST送信して作成保存の処理が実行されるようになっています。

### create および store アクションの作成 ###
では、アクションの処理を作成しましょう。RestappController.phpを開き、「<span class="red">create</span>」と「<span class="red">store</span>」のアクションメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト4-3</span>RestappController.php</p>
```
public function create()
{
   return view('rest.create');
}

public function store(Request $request)
{
   $restdata = new Restdata;
   $form = $request->all();
   unset($form['_token']);
   $restdata->fill($form)->save();
   return redirect('/rest');
}
```

createアクションでは、先ほど作成したcreate.blade.phpのテンプレートを表示するようにしてあります。フォームだけですが、表示そのものは行えます。そしてPOST送信した先のstoreアクションでは、new Restdataを行い、送信されたフォームの情報を「<span class="red">fill</span>」で 適用して「<span class="red">save</span>」で保存しています。 これらは、既にやったことですから、改めて説明するまでもないでしょう。

![](upload/rest_createにアクセス.png "図 「/rest/create」にアクセスすると、フォームだけ表示される。"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/Webクリエイターボックス送信.png "図　データを記入して送信"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/Webクリエイターボックス登録.png "図　データが登録"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/resrdataテーブルWebクリエイターボックス登録確認.png "図　restdataテーブルにデータが登録されています。"){.photo-border}


## フォームを/hello/restに埋め込む

では、用意できた「/rest/create」のフォームを他のWebページに埋め込んで使ってみましょう。ここでは、「/hello/rest」というアクションを用意して、ここにフォームを埋め込んでみます。  
まず、テンプレートを作りましょう。「views」内の「hello」フォルダの中に「rest.blade.php」という名前でファイルを作って下さい。そして以下のように記述します。

<p class="tmp list"><span>リスト5-1</span>rest.blade.php</p>
```
<html>
<head>
   <title>hello/Rest</title>
   <style>
   body {font-size:16pt; color:#999; margin: 5px; }
   h1 { font-size:50pt; text-align:right; color:#f6f6f6;
       margin:-20px 0px -30px 0px; letter-spacing:-4pt; }
   th {background-color:#999; color:fff; padding:5px 10px; }
   td {border: solid 1px #aaa; color:#999; padding:5px 10px; }
   .content {margin:10px; }
   </style>
</head>
<body>
   <h1>Rest</h1>

   @include('rest.create')
  
</body>
</html>
```
ここでは、ボディ部分に「@include」というディレクティブが書かれています。これは、指定したテンプレートをその部分にインポートして出力するものでした。これにより、他のところにあるテンプレートをこのWebページの中に組み込んで表示することができます。  
続いて、HelloControllerクラスにrestアクションメソッドを追記しましょう。以下のようなものです。

<p class="tmp list"><span>リスト5-2</span>HelloController.php</p>
```
public function rest(Request $request)
{
   return view('hello.rest');
}
```

単純に、今作成したrest.blade.phpのテンプレートを使ってWebページを表示しているだけのものです。後は、「/hello/rest」のルート情報をweb.phpに以下のように追記するだ けです。

<p class="tmp list"><span>リスト5-3</span></p>
```
Route::get('hello/rest', [\App\Http\Controllers\HelloController::class,'rest']);
```

これで一通りできました。では、「/hello/rest」にアクセスしてみて下さい。「/rest/create」で表示されるフォームがページ内に組み込まれて表示されます。そのまま項目を記入し送信すれば、レコードが保存されます。

![](upload/日本映画専門チャンネル送信.png "図　「/hello/rest」にアクセスし、フォーム送信すると、レコードが追加される。")
<span class="arrow-down ml-5"></span>
![](upload/日本映画専門チャンネルテーブルに登録3.png "図　restdataテーブルに登録されました。")

ここでは新規作成の例を挙げましたが、更新や削除も同様に作成し、他のページなどから利用できるようになるでしょう。


## RESTfulサービスにするために

ここで利用したLaravelの機能は、正確にはResourcefulであって、RESTfulではありません。では、RESTfulにしていくためには、どのように実装を用意すべきなのでしょうか。

RESTfulでは、CRUDはすべて同じアドレスで、アクセスに使うHTTPメソッドの違いによって処理を分けるのが一般的です。HTTPメソッドのメソッドと、実行されるCRUDの関係を整理すると、以下のようになります。

|HTTP|CRUD|
|:--|:--|
|	GET|	Read。レコードの取得。|
|	POST|	 Create。レコードの新規作成。|
|	PUT|	 Update。レコードの更新。|
|	DELETE|	 Delete。レコードの削除。|

このような形で調整していくことでRESTfulなサービスになっていきます。よく見ると、これらはLaravelのResourcefulにすべて用意されていることに気がつくはずです。 Resourcefulでは、これらの他に、CreateとUpdateのフォームとなる部分を追加しているだけであって、すべて実装すればRESTfulとして機能するようになっているのです (RESTfulなサービスでは、入力のためのフォーム部分は不要ですから)。  
先ほど説明したRerourcefullのアクションを、RESTful対応という点でもう一度整理してみましょう。

##### RESTfulに必要なもの

|アクション|メソッド|
|:--|:--|
|	/コントローラ|	index|
|	/コントローラ|	 store(POST送信) |
|	/コントローラ/番号|	 show(番号 = ID)。|
|	/コントローラ/番号|	 update(番号 = ID、PUT/PATCH送信)|
|	 /コントローラ/番号|	 delete(番号 = ID、DELETE送信)|


##### いらないもの

|アクション|メソッド|
|:--|:--|
|	/コントローラ/create|	create(新規作成のフォーム) |
|	/コントローラ/番号/edit|	edit(番号 = ID。更新のフォーム)|

いかがですか。Resourcefulを実装していけば、自然とRESTfulなサービスが完成していくことがよくわかるでしょう。
