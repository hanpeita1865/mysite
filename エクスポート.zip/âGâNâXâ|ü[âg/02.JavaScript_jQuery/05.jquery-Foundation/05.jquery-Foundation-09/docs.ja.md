---
title: '05. ツールチップ'
media_order: 'icon1.png,icon2.png,icon3.png'
taxonomy:
    category:
        - docs
visible: true
---

まず，ツールチップとはどのようなものか，次のサンプルで説明します．

<iframe width="100%" height="350" src="//jsfiddle.net/rjav2uhz/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

結果を見てみましょう．  
アイコンが3つ表示されています．どれかのアイコンに，マウスをホバーしてみましょう．  
アイコンの上に吹き出しが表示されます．この吹き出しは，アイコンが何を表しているか説明しています．  
このように，何かわからないアイコンについて教えてくれるものを，ツールチップといいます．

HTMLを見てみましょう．  
ulタグ内にliタグが3つあります．それぞれのliタグ内には，アイコンの画像がセットされています．  
今回は，このimgタグのalt属性である文字列をスクリプトでツールチップに表示します．

CSSを見てみましょう．  
―　アイコンの設定　―  
ulタグ　　<strong>display: inline-block;</strong>　　アイコンを横並びにする．  
liタグ　　 <strong>border-radius: 75px;</strong>　　角丸の半径を幅・高さの半分にし，アイコンの背景を円形にする．

―　ツールチップの設定　―  
＃tooltip　　<strong>position: absolute;</strong>　　位置を自由に移動できる．  
　　　　　　　　　　　　　　　　　　　　　　　→　あとから位置をスクリプトで設定する．  
＃tooltip:after　　ツールチップの吹き出しの三角形部分の設定．  
　　CSSによる三角形の作成については，次のサイトがわかりやすいので，参考にしてください．  
　　[CSSだけで三角形を作ろう！](https://www.granfairs.com/blog/staff/make-triangle-with-css)

スクリプトを見てみましょう．  
liタグ（アイコン）をホバーしたときの動作の設定が書かれています．  
1．ツールチップをHTMLに追加  
　　.append() によってbody内にツールチップの要素を追加．  
　　　　↓  
　　.children() によってliタグの子要素であるimgタグを指定．  
　　　　↓  
　　.attr() によってimgタグのalt属性の文字列を返す．  
　　　　↓  
　　.html() によってツールチップの要素内にあるpにalt属性の文字列をセット．
```
<body>
	<div id="tooltip"><p>ここにalt属性の文字列</p></div>　←　これを.append() で追加した

	<ul>･･･</ul>
</body>
```

2．ツールチップの位置を設定  
―　縦方向の位置調整　―  
<strong>.css()</strong> によって＃tooltipに<strong>top: ○○px;</strong> を設定します．  
　　<strong>$(this).offset().top</strong>　　liタグ（アイコン）の上の位置  
　　ここからツールチップの高さと，吹き出しの三角形の高さ(18px)を引く．  

ツールチップの位置  
　　アイコンの上の位置から下に向かってマイナス方向，つまり上に向かって設定されます．

<strong>図1</strong>
<img src="http://10.183.122.52:55503/3/img/tooltip1.png">

―　横方向の位置調整　―  
<strong>.css()</strong> によって＃tooltipに<strong>left: ○○px;</strong> を設定します．  
　　<strong>$(this).offset().left</strong>　　でliタグ（アイコン）左の位置  
　　ここからツールチップの幅からアイコンの幅を引いたものの半分を引く．

ツールチップの位置  
　　　　ツールチップの幅　>　アイコンの幅  
　　　　アイコンの左の位置から右に向かってマイナス方向，つまり左に向かって設定されます．

<strong>図2</strong>
<img src="http://10.183.122.52:55503/3/img/tooltip2.png">
　　　　ツールチップの幅　<　アイコンの幅  
　　　　アイコンの左の位置から右に向かってプラス方向，つまり右に向かって設定されます．

<strong>図3</strong>
<img src="http://10.183.122.52:55503/3/img/tooltip3.png">

3．ツールチップをフェードインさせる  
.fadeIn() を使うだけです．

---

liタグ（アイコン）をホバーしていないときの動作も必要となります．  
clickやhoverなどイベント処理のファンクションのあとに，カンマ(,)で区切ってもう1つファンクションを記述すると，  
2番目のファンクションは「～していないときの処理」を行います．

<strong>図4</strong>
<img src="http://10.183.122.52:55503/3/img/tooltip4.png">

今回はアイコンをホバーしていないときは何もしないようにするため，  
.remove() でツールチップの要素を削除します．  
これで，ホバーしていないときはツールチップが表示されなくなります．