//--------------------------//
// 本日の予定と告知の設定     //
//-------------------------//

// トップの「企画から」表示
// /files/today/"今日の年月日".txt から引っ張ってくる

const todaySc = document.getElementById('today-schedule');
const kokuchi = document.getElementById('kokuchi');
const announceArea = document.getElementById('itemR2');

let file_name;
//let target;


file_name = getFileName();

//本日の予定 テキスト挿入
fetch('files/today/' + file_name + '.txt')
	.then((res) => {
		if (!res.ok) {
			errFunc();
		}
		return res.blob();
	})
	.then(response => response.text())
	.then(data => { // 本日のtextがある
		todaySc.innerHTML = data;
	});

//告知 テキスト挿入
let xhr = new XMLHttpRequest();

xhr.open("POST", "files/kokuchi/kokuchi.txt");
xhr.onreadystatechange  = function (e) {
	if (xhr.readyState === 4) {
	if (xhr.status === 200) {
		// 処理成功
		announceArea.classList.add('d-block');
		kokuchi.innerHTML = xhr.responseText;
	}else if(xhr.status === 404){
		//ファイルが存在しない
	} else {
		//
	}
	}
};
	
	xhr.send();
	


// 本日の予定のtxtが存在しない場合
function errFunc() {
	fetch('files/today/default.txt')
		.then((res) => {
			if (!res.ok) {
				console.log('default.txtがない');

			}
			return res.blob();
		})
		.then(response => response.text()) // (2) レスポンスデータを取得
		.then(data => { // (3)レスポンスデータを処理
			todaySc.innerHTML = data;
		});
}

// 告知のtxtが存在しない場合
function errFunc_kokuchi() {
	fetch('files/kokuchi/default.txt')
		.then((res) => {
			if (!res.ok) {
				console.log('default.txtがない');

			}
			return res.blob();
		})
		.then(response => response.text()) // (2) レスポンスデータを取得
		.then(data => { // (3)レスポンスデータを処理
			//kokuchi.innerHTML = data;
		});
}

//本日の日付取得（日付のパラメータをつけるとテストができる 例)?file_name=20220710）
function getFileName() {
	let param = [];
	let url = location.href;
	let ret;

	if (url.indexOf("?") != -1) {
		// 確認用：index.html?file_name=表示したい企画の年月日(yyyymmdd)
		param = getParam(url);
		ret = param["file_name"];
	} else {
		// 通常時：現在の日付(yyyymmdd)
		ret = getTodaysString();
	}

	return ret;
}

//日付パラメータつけての確認用
function getParam(str) {
	let params = str.split("?");
	let spparams = params[1].split("&");

	let paramArray = [];
	for (i = 0; i < spparams.length; i++) {
		vol = spparams[i].split("=");
		paramArray.push(vol[0]);
		paramArray[vol[0]] = vol[1];
	}

	return paramArray;
}

function getTodaysString() {
	let date = new Date();
	let formattedDate = [
		date.getFullYear(),
		('0' + (date.getMonth() + 1)).slice(-2),
		('0' + date.getDate()).slice(-2)
	].join('');
	return formattedDate;
}
