// トップのお知らせ表示の制御
// /files/news/news.csvから引っ張ってくる

function view_news_list(fillter, data) {

    const csvElem = document.getElementById('csv');
    let buf = "";//HTML挿入コード用

    // let dd = 7;  //New の掲載日数
    //let strId = "#csv"; //idの属性値

    csv = data.slice(1);//2行目以降

    let nymd = csv[0][0];//最新の日付?? 
    //console.log(nymd);
    //  コンテンツ追加
    //	value[0] = 更新日
    //	value[1] = 発行
    //	value[2] = カテゴリ
    //	value[3] = カテゴリURL
    //	value[4] = 記事
    //	value[5] = 記事URL
    //	value[6] = 鍵マーク
    //console.log(csv);

    csv.forEach(value => {

        if (value[0] != "") {
            let ymd = value[0];
            let arrayYmd = ymd.split(".");
            let y = String(Number(arrayYmd[0]));
            let m = String(Number(arrayYmd[1]));
            let d = String(Number(arrayYmd[2]));
            let day = new Date(y, m - 1, d);
            let week = ["日", "月", "火", "水", "木", "金", "土"];
            let w = week[day.getDay()];

            if (fillter != 'すべて' && fillter != value[1]) {
                return true;
            }

            buf += '<li>';
            buf += '<div class="news_date">';
            buf += '<span>' + m + "月" + d + "日 " + w + '</span>';
            buf += '</div>';
            buf += '<div class="news_logo">';
            buf += '<span';
            switch (value[1]) {
                case '企画': buf += ' class="top__box--plan">' + value[1]; break;
                case 'インフラ': buf += ' class="top__box--infrastructure">' + value[1]; break;
                case 'MCS': buf += ' class="top__box--mcs">' + value[1]; break;
                case 'キャリア': buf += ' class="top__box--mcs">' + value[1]; break;
                case 'ブログ': buf += ' class="top__box--blog">' + value[1]; break;
                case '営業': buf += ' class="top__box--sales">' + value[1]; break;
                case 'イベント': buf += ' class="top__box--events">' + value[1]; break;
                case 'イノベ': buf += ' class="top__box--innovative">' + value[1]; break;
                case 'サビマネ': buf += ' class="top__box--SM">' + value[1]; break;
                case '情報': buf += ' class="csv__box--info">' + value[1]; break;
                case '周知': buf += ' class="csv__box--know">' + value[1]; break;
                case 'NI 統括部': buf += ' class="csv__box--NI">' + value[1]; break;
                case 'キャリア規制': buf += ' class="top__box--mcs">ｷｬﾘｱ規制'; break;
                case 'キャリア周知': buf += ' class="top__box--mcs">ｷｬﾘｱ周知'; break;
                default: buf += ' class="top__box--etc">' + value[1]; break;
            }
            buf += '</span>';
            buf += '</div>';
            let bit = 0;
            if (value[6] == 1) {
                bit = bit + 1;
            }
            //					if (value[4] == 'ラベル／表示件名') {
            if (value[4] == 'ラベル／表示件名') {
                bit = bit + 4;
            } else if (value[0] == nymd) {
                bit = bit + 2;
            }
            switch (bit) {
                case 0: buf += '<div class="news_body">'; break;
                case 1: buf += '<div class="news_body-type1">'; break;
                case 2: buf += '<div class="news_body-type2">'; break;
                case 3: buf += '<div class="news_body-type3">'; break;
                case 4: buf += '<div class="news_body-type4">'; break;
                case 5: buf += '<div class="news_body-type5">'; break;
                default: buf += '<div class="news_body">'; break;
            }
            buf += '<div class="textoverflow">';
            buf += '<span>';
            buf += '<a href="' + value[5] + '" title="' + value[4] + '">' + value[4];
            buf += '</a>';
            buf += '</span>';
            //buf += '</div>';
            buf += '</div>';
            buf += '<div class="news_body-newimg">';
            if (bit == 1 || bit == 3 || bit == 5) {
                buf += '<div class="markKey"><span>&#x1f512;</span></div>';
            }
            if (bit == 4 || bit == 5) {
                buf += '<div class="markUpdate">Update</div>';
            } else if (bit == 2 || bit == 3) {
                buf += '<div class="markNew">New</div>';
            }
            buf += '</div>';//追加
            buf += '</div>';

            buf += '</div>';
            buf += '</div>';
            buf += '</li>\n';
        }
    });

    csvElem.innerHTML = buf;//お知らせのリストを挿入
}

