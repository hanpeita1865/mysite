---
title: プラグイン
media_order: 'plugin_add.png,theme_direct_install.png,plugin_list.png'
taxonomy:
    category:
        - docs
visible: true
---

## プラグインの追加

プラグインの管理画面の右上の追加ボタン![](plugin_add.png?classes=d-inline,my-0)をクリックすると、プラグインのリストが表示されます。  

![](plugin_list.png)

ただし、シンクラだと通信に制限がかかるのでリストは表示されず、真っ白になります。  
そのため、以下の操作をします。

[公式サイトプラグイン](https://getgrav.org/downloads/plugins)から直接ダウンロードしたzipファイルを、管理画面の「ツール」-「Direct install」のページを開いて、下図の緑枠内にあるファイルの選択でそのzipファイルを選択し、「Upload and Install」ボタンをクリックします。　
![](theme_direct_install.png)
画面上部に「インストールが成功しました。」の文字が表示されたら、インストールは完了です。