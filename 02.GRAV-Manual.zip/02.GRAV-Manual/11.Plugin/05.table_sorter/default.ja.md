---
title: Tablesorter
media_order: 'sitemap.png,table_sorter.png,table_sorter2.png'
taxonomy:
    category:
        - docs
tablesorter:
    active: true
    include_widgets: true
    table_nums: '1,2'
    args:
        2:
            theme: blue
            widgets:
                - zebra
                - filter
---

表にソート機能やフィルター機能などを追加するプラグインです。

## ソート機能

### 例

| 社員番号| 名前 | ふりがな| 入社年月日| 年齢 | 性別 |
| -------- | -------- | -------- | -------- | -------- |
| 136 | 山田太郎 | やまだたろう |	2001/06/01 | 28 | 男 |
| 138 | 小池百合子 | こいけゆりこ | 2005/08/01| 32 | 女 |
|140 | 鈴木一郎 | すずきいちろう |	1999/04/01 | 44 | 男 |
| 144 |	松井秀喜 | まついひでき |	2017/04/01 | 43 | 男 |
| 153 |	小田和正 |	おだかずまさ | 2014/09/01 | 27 | 男 |
| 176 |	藤田菜々子 |	ふじたななこ | 1997/04/01 | 45 | 女 |
| 192 |	黒田博樹 | くろだひろき |	2012/07/01 | 37 | 男 |



### 使用方法

ソート機能を入れたいテーブルがあるページの編集画面を開きます。  
タブの **上級者向け** - **コンテンツ** のページのヘッダーにコードを記入します。
<pre>
tablesorter:
    active: true
    table_nums: 1　<span class="comment">//何番目のテーブルにソート機能を設置するかを指定（table_numsを省くとページ内のテーブル全てに設置されます。）</span>
</pre>

![](table_sorter.png)

下記のように記述すると、最初開いたとき、1番目のテーブルの1列目が昇順で表示され、2番目のテーブルの5列目が降順で表示されます。
<pre>
tablesorter:
  active: true
  table_nums: '1,2'
  args:
  	1:
      sortList: [[0,0]]
    2:
      sortList: [[4,1]]
</pre>

**ヘッダー保存結果画像**

![](table_sorter2.png?classes=d-inline,mt-0)





## フィルター機能

[デモページ](https://www.perlkonig.com/demos/tablesorter)

### 例


| First Name | Last Name | Age | Total | Discount | Difference | Date |
| ---------- | --------- | --- | ----- | -------- | ---------- | ---- |
| Peter | Parker | 28 | $9.99 | 20.9% | +12.1 | Jul 6, 2006 8:14 AM |
| John | Hood | 33 | $19.99 | 25% | +12 | Dec 10, 2002 5:14 AM |
| Clark | Kent | 18 | $15.89 | 44% | -26 | Jan 12, 2003 11:14 AM |
| Bruce | Almighty | 45 | $153.19 | 44.7% | +77 | Jan 18, 2001 9:12 AM |
| Bruce | Evans | 22 | $13.19 | 11% | -100.9 |  Jan 18, 2007 9:12 AM |
| Bruce | Evans | 22 | $13.19 | 11% | 0 | Jan 18, 2007 9:12 AM |

2番目のテーブルにフィルター機能が付いて、また縞々になるよう下記で設定しています。

    tablesorter:
        active: true
        include_widgets: true
        table_nums: '1,2'
        args:
            2:
                theme: blue
                widgets:
                    - zebra
                    - filter


