---
title: 商品を検索、追加、編集する
media_order: 'insert.png,update.png'
taxonomy:
    category:
        - docs
---

## 商品を検索する

<http://localhost/php/shop/chapter6/search-input.php>

<iframe width="100%" height="300" src="http://localhost/php/shop/chapter6/search-input.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


##### search-input
```
商品名を入力してください。
<form action="search-output.php" method="post">
<input type="text" name="keyword">
<input type="submit" value="検索">
</form>
```

##### search-output
```
<table>
<tr><th>商品番号</th><th>商品名</th><th>商品価格</th></tr>
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
$sql=$pdo->prepare('select * from product where name=?');//書式1
$sql->execute([$_REQUEST['keyword']]);//書式2

foreach ($sql->fetchAll() as $row) {//書式3
	echo '<tr>';
	echo '<td>', $row['id'], '</td>';
	echo '<td>', $row['name'], '</td>';
	echo '<td>', $row['price'], '</td>';
	echo '</tr>';
	echo "\n";
}
?>
</table>
```

<p class="tmp"><span>書式1</span>prepareメソッド～SQL文の準備</p>
```
PDOの変数 ->prepare('SQL文')
```
prepareメソッドは、SQL文がセットされたPDOStatementインスタンスを返します。このインスタンスはSQL文を実行するために必要なので、変数に代入しておきます。ここでは$sqlという変数名にしました。


<p class="tmp"><span>書式2</span>excuteメソッド～SQL文の実行</p>
```
変数->execute([値]);
```

prepareメソッドに引数として渡したSQL文を実行するためには、PHPに用意されたPDOState mentクラスのexecuteメソッドを使います。  
既にprepareメソッドによってPDOStatementイン スタンスが作成されているので、インスタンスを代入した変数$sqlを用いれば、executeメソッドを実行することができます。

executeメソッドの引数には、SQL文のなかの「?」部分に設定する値を、配列にして渡します。   
配列にするのは、1つのSQL文内に複数箇所の?を配置することができるからです。  
前の方にある? から順番に、配列で指定した値が設定されます。

複数の?がある場合は、外側を[]で囲んだうえで、複数の値を「,」で区切って値,値, ...] のように並べます。?が1個だけの場合には、[値]のように外側を[]で囲むだけです。 ここではkeywordという名前のリクエストパラメータを使います。


<p class="tmp"><span>書式3</span>fetchAllメソッド～実行した結果の取得</p>
```
foreach (PDOの変数->fetchAll() as 結果を代入する変数)
```
SQLスクリプトをexecuteメソッドで実行した結果は、PDOStatementクラスのfetchAllメソッドで取得することができます。  
取得した結果を処理するときには、foreachループと組み合わせて、次のように記述します。  
（$sqlはPDOStatementインスタンスを代入した 変数です。）
```
foreach ($sql->fetchAll() as $row) {
・・・
}
```

## 商品を追加する

<http://localhost/php/shop/chapter6/insert-input.php>

<iframe width="100%" height="300" src="http://localhost/php/shop/chapter6/insert-input.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

##### insert-input.php
```
<p>商品を追加します。</p>
<form action="insert-output.php" method="post">
商品名<input type="text" name="name">
価格<input type="text" name="price">
<input type="submit" value="追加">
</form>
```

##### insert-output.php
```
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
$sql=$pdo->prepare('insert into product values(null, ?, ?)');
if ($sql->execute([$_REQUEST['name'], $_REQUEST['price']])) {
	echo '追加に成功しました。';
} else {
	echo '追加に失敗しました。';
}
?>
```


## 商品を変更する

<http://localhost/php/shop/chapter6/update-input.php>

<iframe width="100%" height="300" src="http://localhost/php/shop/chapter6/update-input.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

##### update-input.php
```
<table>
<tr><th>商品番号</th><th>商品名</th><th>商品価格</th></tr>
<?php
$pdo=new PDO(
	'mysql:host=localhost;dbname=shop;charset=utf8', 'staff', 'password'
);
foreach ($pdo->query('select * from product') as $row) {
	echo '<tr><form action="update-output.php" method="post">';
	echo '<input type="hidden" name="id" value="', $row['id'], '">';
	echo '<td>', $row['id'], '</td>';
	echo '<td>';
	echo '<input type="text" name="name" value="', $row['name'], '">';
	echo '</td>';
	echo '<td>';
	echo '<input type="text" name="price" value="', $row['price'], '">';
	echo '</td>';
	echo '<td><input type="submit" value="更新"></td>';
	echo '</form></tr>';
	echo "\n";
}
?>
</table>
```

##### update-output.php
```
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
$sql=$pdo->prepare('update product set name=?, price=? where id=?');
if (empty($_REQUEST['name'])) {
	echo '商品名を入力してください。';
} else
if (!preg_match('/[0-9]+/', $_REQUEST['price'])) {
	echo '商品価格を整数で入力してください。';
} else
if ($sql->execute(
	[htmlspecialchars($_REQUEST['name']), 
	$_REQUEST['price'], $_REQUEST['id']]
)) {
	echo '更新に成功しました。';
} else {
	echo '更新に失敗しました。';
}
?>
```

## 商品を削除する

<http://localhost/php/shop/chapter6/delete-input.php>

<iframe width="100%" height="450" src="http://localhost/php/shop/chapter6/delete-input.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

##### delete-input.php
```
<table>
<tr><th>商品番号</th><th>商品名</th><th>商品価格</th></tr>
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
foreach ($pdo->query('select * from product') as $row) {
	echo '<tr>';
	echo '<td>', $row['id'], '</td>';
	echo '<td>', $row['name'], '</td>';
	echo '<td>', $row['price'], '</td>';
	echo '<td>';
	echo '<a href="delete-output.php?id=', $row['id'], '">削除</a>';
	echo '</td>';
	echo '</tr>';
	echo "\n";
}
?>
</table>
```

##### delete-output.php
```
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
$sql=$pdo->prepare('delete from product where id=?');
if ($sql->execute([$_REQUEST['id']])) {
	echo '削除に成功しました。';
} else {
	echo '削除に失敗しました。';
}
?>
```


## 商品を追加・変更・削除を実行する

<http://localhost/php/shop/chapter6/edit3.php>

<iframe width="100%" height="450" src="http://localhost/php/shop/chapter6/edit3.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

##### edit3.php
```
<table>
<tr><th>商品番号</th><th>商品名</th><th>商品価格</th></tr>
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
if (isset($_REQUEST['command'])) {
	switch ($_REQUEST['command']) {
	case 'insert':
		if (empty($_REQUEST['name']) || 
			!preg_match('/[0-9]+/', $_REQUEST['price'])) break;
		$sql=$pdo->prepare('insert into product values(null,?,?)');
		$sql->execute(
			[htmlspecialchars($_REQUEST['name']), $_REQUEST['price']]);
		break;
	case 'update':
		if (empty($_REQUEST['name']) || 
			!preg_match('/[0-9]+/', $_REQUEST['price'])) break;
		$sql=$pdo->prepare(
			'update product set name=?, price=? where id=?');
		$sql->execute(
			[htmlspecialchars($_REQUEST['name']), $_REQUEST['price'], 
			$_REQUEST['id']]);
		break;
	case 'delete':
		$sql=$pdo->prepare('delete from product where id=?');
		$sql->execute([$_REQUEST['id']]);
		break;
	}
}
foreach ($pdo->query('select * from product') as $row) {
	echo '<tr>';
	echo '<form action="edit3.php" method="post">';
	echo '<input type="hidden" name="command" value="update">';
	echo '<input type="hidden" name="id" value="', $row['id'], '">';
	echo '<td>', $row['id'], '</td>';
	echo '<td>';
	echo '<input type="text" name="name" value="', $row['name'], '">';
	echo '</td>';
	echo '<td>';
	echo '<input type="text" name="price" value="', $row['price'], '">';
	echo '</td>';
	echo '<td><input type="submit" value="更新"></td>';
	echo '</form>';
	echo '<form action="edit3.php" method="post">';
	echo '<input type="hidden" name="command" value="delete">';
	echo '<input type="hidden" name="id" value="', $row['id'], '">';
	echo '<td><input type="submit" value="削除"></td>';
	echo '</form>';
	echo '</tr>';
	echo "\n";
}
?>
<tr>
<form action="edit3.php" method="post">
<input type="hidden" name="command" value="insert">
<td></td>
<td><input type="text" name="name"></td>
<td><input type="text" name="price"></td>
<td><input type="submit" value="追加"></td>
</form>
</tr>
</table>
```

