---
title: 01.モジュール
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    .t-caption {
    	font-size: 1.5rem;
        text-align: center;
        font-weight: bold;
        margin-bottom: .5rem;
    }
    .t-caption + table {margin-top: .5rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: blue;}
    .smp-box {
         margin: 2rem 0 3rem;
    }
   dl dt {
     font-weight: bold;   
    }
    .gray-box {
     	border: 1px solid gray;
        padding: 20px 30px;
        display: inline-block;
    }
    .w-400 {
      	width: 400px;
     }
    .comment {
      font-style: italic;
      color: green;
      font-size: 1rem;
    }
    h3 span {
      border-bottom: 3px solid green;   
    }
    h4 {margin-top: 3rem;}
</style>

<h2 class="h-type2">モジュールとは</h2>


プロパティを分野では、関連した機能をひとまとめにしたプログラムのことを、モジュールと呼びます。
Pythonには非常に多くのモジュールがあり、便利なモジュールの使い方を覚えれば、高機能なプログラムを簡単に作ることができます。
ちなみに、Pythonのモジュールは、定義や文が入った.pyファイルです。
そのため、自分で作ったプログラムをモジュールとして使うこともできます。

<h2 class="h-type2">モジュールを使う方法</h2>
組み込みでない関数を使うには、その関数の定義を含んだモジュールをインポートする必要があります。
Pythonにおいてはプログラムに必要なモジュールの機能を取り込むことをインポートと呼びます。

<p class="tmp"><span>書式1</span>モジュールのインポート</p>

	import モジュール名

<p class="tmp"><span>書式2</span>モジュール内の関係を呼び出し(引数無しの場合)</p>

	モジュール名.関数名

※先頭に「モジュール名」を付けること以外は、通常の関数呼び出しと同じです。

<p class="tmp"><span>書式3</span>モジュール内の関数を呼び出す(引数ありの場合)</p>

	モジュール名.関数名(引数1,引数1, …)



<p class="inpre"><span>インタプリタ</span>乱数を生成<br>randomというモジュールをインポートし、random関数を呼び出します。</p>
<pre>
>>> import random
>>> random.random()
0.14460925525960378<span class="comment">  # 乱数</span>
</pre>


<span class="red bold">randint関数</span> ～指定した範囲の整数を生成する。

<p class="tmp"><span>書式4</span>整数A以上、整数B以下の乱数を生成する</p>

	random.randint(整数A, 整数B)

<p class="inpre"><span>インタプリタ</span>randint関数を使って、1以上6以下の整数を生成します</p>
<pre>
>>> random.randint(1, 6)
5<span class="comment">  # 結果</span> 
>>> random.randint(1, 6)
2<span class="comment">  # 結果</span> 
>>> random.randint(1, 6)
2<span class="comment">  # 結果</span> 
</pre>



便利なモジュールですが、「random.randint(1, 6)」のように何度も書くのは大変です。<br>
そこで、次の書式のように書くことで、モジュールに別名を付けて利用できるようになります。<br>
モジュール名が長くて入力が大変なときに便利です。

<p class="tmp"><span>書式5</span>モジュールをインポートし、別名を付ける</p>

	import モジュール名 as 名前


<p class="inpre"><span>インタプリタ</span>randomモジュールをインポートし、「r」という別名を付ける</p>
<pre>
>>> import random as r
>>> r.randint(1, 6)
2 
>>> r.randint(1, 6)
5
>>>
</pre>


<h2 class="h-type2">モジュール名を省略できるようにする</h2>

非常に頻繫に使う機能の場合は、いっそモジュール名を下記のように省略して使うことが出来ます。

random.randint(1, 6) → randint(1, 6)

import文にfrom節を付けて、モジュール内の機能（関数、変数、クラスなど）をインポートします。


<p class="tmp"><span>書式6</span>モジュール内の機能をインポートして、モジュール名なしで使えるようにする</p>

	from モジュール名 import 機能名

<p class="inpre"><span>インタプリタ</span>モジュール名なしで使えるようにする</p>
<pre>
>>> from random import randint
>>> randint(1, 6)
2
>>> randint(1, 6)
3
</pre>



さらに短くする方法があります。<br>
import文にfrom節とasを組み合わせます。

<p class="tmp"><span>書式7</span>モジュール内の機能に別名を付けてインポートする</p>

	from モジュール名 import 機能名 as 名前


<p class="inpre"><span>インタプリタ</span>randomモジュールのradient関数をインポートし、「ri」という名前で使えるようにします</p>
<pre>
from random import randint as ri
>>> from random import randint as ri
>>> ri(1, 6)
1
>>> ri(1, 6)
2
>>> ri(1, 6)
</pre>

※注意点として、短い名前にすると、機能が区別しにくくなったり、複数の機能で名前が重複してしまったりする恐れがあります。



<h2 class="h-type2">randomモジュールの便利な機能</h2>

randomモジュールには乱数に関するいろいろな機能があります。


<span class="red bold">choice関数</span> ～ シーケンス（文字列、リスト、タプルなど）からランダムに要素を選ぶことができます。

<p class="tmp"><span>書式8</span>シーケンス（文字列、リスト、タプルなど）からランダムに要素を選んで返す</p>

	random.choice(シーケンス)　

<p class="inpre"><span>インタプリタ</span>3つの文字列を含むリストの中から、ランダムに要素を選びます</p>
<pre>
>>> import random
>>> flavor = ['バニラ', 'チョコレート', 'ストロベリー']
>>> random.choice(flavor)
'チョコレート'
>>> random.choice(flavor)
'ストロベリー'
>>> random.choice(flavor)
'バニラ'
>>> random.choice(flavor)
'チョコレート'
>>> random.choice(flavor)
'チョコレート'
</pre>

<span class="red bold">shuffle関数</span> ～ シーケンスが含む要素の位置をランダムに変更します。

<p class="tmp"><span>書式9</span>シーケンス（リスト）内に格納されている要素の位置をランダムに変更します</p>

	random.shuffle(シーケンス)

※引数に入るシーケンスは、ミュータブル（変更可能）である必要があります。<br>
リストはミュータブルなので、shuffle関数で処理できます。文字列やタプルはイミュータブル（変更不可能）なので、shuffle関数では処理できません。

<p class="inpre"><span>インタプリタ</span>13個の文字列を含むリストを、shuffle関数を使って混ぜ合わせます</p>
<pre>
>>> import random
>>> card = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
>>> random.shuffle(card)
>>> card
['9', '6', '8', '7', '5', '10', '3', '4', 'K', '2', 'Q', 'J', 'A']<span class="comment">  # シャッフルされた結果</span> 
</pre>












