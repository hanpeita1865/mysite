---
title: 06.集合
taxonomy:
    category:
        - docs
visible: true
---

集合はリストやタプルと同様に、データ構造の一つです。セット（set）とも呼ばれます。<br>
複数のデータをまとめる機能があるのはリストやタプルと同じですが、次のような特徴や利点があります。

<h3 class="h-type3">特徴</h3>
<ul class="mt-05">
    <li><span class="bold red">重複する要素は持たない</span> ～ 同一の要素は一つしか格納することができません。同一の要素を格納しようとするとしても自動的に一つになります。
        リストやタプルの場合は、同一の要素をいくつでも格納することができます。</li>
    <li><span class="bold red">要素の順序は指定できない</span> ～ 要素を取り出す順序は、格納した順序とは異なる可能性があります。
        リストやタプルの場合は、要素を格納する順序を指定することができます。</li>
    <li><span class="bold red">インデックスやスライスは使えない</span> ～ 要素を格納する順序が指定できないので、インデックスやスライスを使うことにあまり意味がないともいえます。リストやタプルの場合は、、インデックスやスライスが使えます。</li>
</ul>

<h3 class="h-type3">利点</h3>
<ul>
    <li><span class="bold red">要素の有無を高速に調べられる</span></li>
    <li><span class="bold red">集合用の特別な演算がある</span></li>
</ul>

※集合ではハッシュと呼ばれる手法を使って、要素を管理しています。ハッシュは要素の有無を調べたり、要素を検索したりすることを
　高速に行える手法です。
 
 
 
 <h2 class="h-type2">集合の作成</h2>

<p class="tmp"><span>書式1</span>集合の作成</p>
<pre>
{値, 値, …}
</pre>

※値は、それぞれ別の要素として登録されます。集合は変数に代入することもできます。

<p class="tmp"><span>書式2</span>集合の代入</p>
<pre>
変数 = {値, 値, …}
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> zoo = {'lion', 'tiger', 'elephant', 'giraffe'}
>>> zoo
{'giraffe', 'lion', 'elephant', 'tiger'}
</pre>

※同じ種類は一つだけ登録して、重複しないようにします。「重複する要素を持たない」という集合の特性を生かします。

<p class="tmp"><span>書式3</span>空の集合</p>
<pre>
zoo = set()
</pre>

※値を持たない空の集合を作成するには、{}ではなくset()と書きます。<br>
　{}と書くと空の辞書になります。

 <h2 class="h-type2">メンバーシップ・テスト演算子</h2>

メンバーシップ・テスト演算子（inとnot in）を集合に対しても適用することができます。特に集合はこれらの演算子を高速に実行することができます。

<p class="tmp"><span>書式4</span>集合とin演算子</p>
<pre>
要素 in 集合
</pre>

<p class="mt-05">指定した値の要素が含まれている場合は「True」、含まれていない場合は「False」を返します。</p>

<p class="tmp"><span>書式5</span>集合とnot in演算子</p>
<pre>
値 not in 集合
</pre>

<p class="mt-05">指定した値の要素が含まれていない場合は「True」、含まれている場合は「False」を返します。</p>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
<span class="comment">zoo = {'lion', 'tiger', 'elephant', 'giraffe'}//先ほど記述済</span>

>>> 'elephant' in zoo
True
>>> 'dog' in zoo
False
>>> 'cat' not in zoo
True
</pre>

<h3 class="h-type3">集合に要素の追加や削除</h3>
「|=演算子」を使います。複合代入演算子（+=や=）の一種です。集合には要素の順番という概念がないので、追加した要素が集合のどこに追加されるのかはわかりません。

<p class="tmp"><span>書式6</span>集合への要素の追加</p>
<pre>
集合 |= {要素}
</pre>

<p class="tmp"><span>書式7</span>複数要素の追加</p>
<pre>
集合 |= {要素, 要素, …}
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
<span class="comment">zoo = {'lion', 'tiger', 'elephant', 'giraffe'}//先ほど記述済</span>

>>> zoo |= {'snake'}
>>> zoo
{'<span class="bold red">snake</span>', 'elephant', 'tiger', 'giraffe', 'lion'}
</pre>

<p class="inpre"><span>インタプリタ</span>既にある要素を登録してみる</p>
<pre>
>>> zoo |= {'lion'}
>>> zoo
{'snake', 'elephant', 'tiger', 'giraffe', 'lion'}<span class="comment">  # 変化なし</span>
</pre>

<p class="tmp"><span>書式8</span>集合から要素の削除</p>
<pre>
集合 -= {要素}
</pre>

<p class="tmp"><span>書式9</span>複数要素の削除</p>
<pre>
集合 -= {要素, 要素, }
</pre>

<p class="inpre"><span>インタプリタ</span>'tiger'を削除</p>
<pre>
>>> zoo -= {'tiger'}
>>> zoo
{'snake', 'elephant', 'giraffe', 'lion'}<span class="comment">  # 'tiger'を削除されている</span>
</pre>

※集合に含まれていない要素を削除しようとしてもエラーにはなりませんが、集合は変化しません。




<h2 class="h-type2">演算子</h2>

<h3 class="h-type3">積集合を求める「&amp;」演算子</h3>
集合1と集合2が共通して含む要素を持つ集合（積集合）を返します。

<p class="tmp"><span>書式10</span>積集合</p>
<pre>
集合1 &amp; 集合2
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> zoo1 = {'lion', 'tiger', 'elephant', 'giraffe'}
>>> zoo2 = {'elephant', 'panda', 'snake', 'lion'}
>>> zoo1 &amp; zoo2
{'lion', 'elephant'}<span class="comment">  # zoo1とzoo2に共通して含まれる要素</span>
</pre>


<h3 class="h-type3">和集合を求める「|」演算子</h3>
集合1と集合2が含むすべての要素を持つ集合（和集合）を返します。

<p class="tmp"><span>書式11</span>和集合</p>
<pre>
集合1 | 集合2
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
<span class="comment">zoo1 = {'lion', 'tiger', 'elephant', 'giraffe'}//先ほど記述済</span>
<span class="comment">zoo2 = {'elephant', 'panda', 'snake', 'lion'}//先ほど記述済</span>

>>> zoo1 | zoo2
{'snake', 'elephant', 'tiger', 'panda', 'giraffe', 'lion'}<span class="comment">  # zoo1とzoo2の最低どちらか一方に含まれる全ての要素</span>
</pre>


<h3 class="h-type3">差集合を求める「-」演算子</h3>
集合1から集合2の要素を削除した集合（差集合）を返します。

<p class="tmp"><span>書式12</span>差集合</p>
<pre>
集合1 - 集合2
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
<span class="comment">zoo1 = {'lion', 'tiger', 'elephant', 'giraffe'}//先ほど記述済</span>
<span class="comment">zoo2 = {'elephant', 'panda', 'snake', 'lion'}//先ほど記述済</span>

>>> zoo1 - zoo2
{'giraffe', 'tiger'}<span class="comment">  # zoo1からzoo2の要素を削除した集合</span>
</pre>

<h3 class="h-type3">対称差を求める「^」演算子</h3>
集合1または集合2のどちらか一方だけが含む要素からなる集合（対称差）を返します。


<p class="tmp"><span>書式13</span>対称差</p>
<pre>
集合1 ^ 集合2
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
<span class="comment">zoo1 = {'lion', 'tiger', 'elephant', 'giraffe'}//先ほど記述済</span>
<span class="comment">zoo2 = {'elephant', 'panda', 'snake', 'lion'}//先ほど記述済</span>

>>> zoo1 ^ zoo2
{'snake', 'tiger', 'panda', 'giraffe'}<span class="comment">  # この4つはどちらか一方にだけ存在する（両方にあるのは含まない）</span>
</pre>




<h2 class="h-type2">集合に使用する演算子まとめ</h2>

<table>
    <thead>
        <tr>
            <th>演算子</th>
            <th class="text-left">働き</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>=|</td>
            <td class="text-left">要素の追加 </td>
        </tr>
        <tr>
            <td>=|</td>
            <td class="text-left">要素の追加 </td>
        </tr>
        <tr>
            <td>-=</td>
            <td class="text-left">要素の削除</td>
        </tr>
        <tr>
            <td>&amp;</td>
            <td class="text-left">積集合（集合1と集合2に共通する要素）</td>
        </tr>
        <tr>
            <td>=|</td>
            <td class="text-left">和集合（集合1と集合2が含むすべての要素）</td>
        </tr>
        <tr>
            <td>-</td>
            <td class="text-left">差集合（集合1から集合2を削除した要素）</td>
        </tr>
        <tr>
            <td>^</td>
            <td class="text-left">対称差（集合1または集合2のどちらか一方だけが含む要素）</td>
        </tr>
    </tbody>     
</table>


※「and」や「or」は、Ptyhonではbool型に対して使う論理演算子です。
   どのような演算子が使えるのかは、値の型によって異なります。
   






