---
title: '01. Web Storage'
media_order: 'index1.html,strage_02.png,strage_01.png,index2.html,index3.html,strage_01.png'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {
        margin-top: 0.5rem;
    }
    #body img {margin-top: 0;}
    section {margin-bottom: 4rem;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    dl dt {
        font-weight: bold;   
    }
    .w-400 {
        width: 400px;
    }
    h4 {margin-top: 3rem;}
    .hljs-comment,
    .comment {
        font-style: italic;
        color: green;
        font-size: 1rem;
        font-weight: normal;        
    }
</style>

<h2 class="h-type2">Web Storageとは</h2>

 Web Storageは、ユーザーのローカル環境（ブラウザ）にデータを保存するための仕組みです。 データの保存・上書き・削除・全クリアなどの操作は、JavaScriptで行うことができます。

Web Storageを利用すると、ユーザーごとにカスタマイズされた情報を提供することが可能となります。 この仕組みはクッキー（HTTP cookie）とよく似ていますが、クッキーに比べて保存できる容量が大きいため、 例えば、オフラインでもウェブアプリケーションを動作させられるだけの 必要十分なデータをユーザーのローカル環境に保存することなどが可能となります。

Web Storageには、sessionStorageとlocalStorageの２種類のストレージが用意されています。 どちらもキー（key）と値（value）をペアにしたデータのリストを ユーザーのローカル環境に保存するkey-value型のデータ保存形式である点は同じですが、 データの有効期限などが異なるので目的に応じて使い分けます。 


<table>
	<thead>
		<tr>
			<th></th>
			<th>別ウィンドウでのデータ共有</th>
            <th>データの有効</th>
            <th>データ量の上限</th>
            <th>サーバーへのデータ送信</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<th>cookie</th>
			<td>〇</td>
            <td>指定期限まで有効</td>
            <td>4KB</td>
            <td>サーバーへアクセスするたびに毎回自動送信</td>
		</tr>
		<tr>
			<th class="red">sessionStrage</th>
			<td>×</td>
            <td>ウィンドウやタブを閉じるまで有効</td>
            <td rowspan="2">1オリジン当たり5MB</td>
            <td rowspan="2">必要時のみスクリプトやフォームなどで送信</td>
		</tr>
		<tr>
			<th class="blue">localStrage</th>
			<td>〇</td>
            <td>永続的に有効</td>
 		</tr>
	</tbody>
</table>

※sessionStrageの場合、ストレージにキーと値を格納しても、別ウィンドウではそのキーと値は格納されない。

<span class="bold"> キーと値を<span class="red">sessionStrage</span>に格納</span>
![](strage_01.png "") 

<span class="bold">別ウィンドウを開き、<span class="red">sessionStrage</span>を確認（キーと値は空）</span>
![](strage_02.png "") 


<h3 class="h-type3">sessionStorageは、一回限りのセッションで有効なストレージ</h3>

<span class="red bold">sessionStorage</span>は、ウィンドウやタブ単位での一回限りのセッションで有効なストレージです。 ウィンドウやタブが開いている間のみデータが保存され、閉じるとデータが失われます。 同じドメインのサイトを別々のウィンドウで開いている場合には、それぞれが別のsessionStorageとなります。 クッキーとは異なり、ウィンドウ間でデータが共有されることはありません。

sessionStorageを利用する一例を挙げてみます。 例えば、2つのウィンドウで同じサイトを開きながら航空券を注文する場合、 クッキーでは買い物かご情報が混在してしまって、同じフライトのチケットを気づかずに2枚注文してしまう可能性があります。 

sessionStorageでは、それぞれが別のセッションとなるため、 別ウィンドウの買い物かご情報が混在してしまうことがありません。 


<h3 class="h-type3">localStorageは、オリジン単位でデータを永続的に保存するストレージ</h3>

<span class="blue bold">localStorage</span>は、オリジン単位でデータを永続的に保存するストレージです。 オリジンとは、「http://www.example.com:80」のような「プロトコル://ドメイン名:ポート番号」のことです。 オリジンが同じであれば別ウィンドウでもデータを共有でき、ブラウザを終了してもデータは失われません。 データ保存量の上限はブラウザへの推奨値が1オリジン当たり5MBとされており、 クッキーの4KBに比べるとより大きなデータを保存できるようになっています。

localStorageを利用する一例を挙げてみます。 例えば、ウェブメールにおけるメールの送受信データのような比較的大きなデータの場合、 クッキーでは保存できるデータ量に上限があるため、すべてのデータをローカル環境に保存することは困難です。 また、クッキーではユーザーがアクセスする度にデータがサーバーに送信されるため、セキュリティの観点からも好ましくありません。

localStorageでは、ローカル環境に5MBまでのデータを永続的に保存でき、 ユーザーのアクセスの度にデータがサーバーに送信されることがありません。 ウェブメールの例で言えば、localStorageなら送受信データをローカル環境に保存でき、 オフラインウェブアプリケーションと組み合わせることで、オフラインでのメール閲覧なども可能となるでしょう。 

<h2 class="h-type2">Web Storageの書き込みと読み込みの方法</h2>

<p class="tmp"><span>書式1</span>書き込みと読み込みの方法</p>

<pre>
<span class="red bold">sessionStorage.setItemc</span>( キー名 , 値 )
	<span class="comment">//セッションストレージに値を書き込みます。</span>

変数 = <span class="red bold">sessionStorage.getItem</span>( キー名 )
	<span class="comment">//セッションストレージから値を取り出し、変数に代入します。</span>
    
<span class="blue bold">localStorage.setItem</span>( キー名 , 値 )
	<span class="comment">//ローカルストレージに値を書き込みます。</span>

変数 = <span class="blue bold">localStorage.getItem</span>( キー名 )
	<span class="comment">//ローカルストレージから値を取り出し、変数に代入します。</span>
</pre>


<div class="box-example">
    <h3 class="h-example">例1</h3>
	それぞれのボタンを押すことで、<span class="red bold">sessionStorage</span>と<span class="blue bold">localStorage</span>に<span class="bold">キー</span>と<span class="bold">値</span>を格納、取得、削除を行います。
</div>

<iframe width="100%" height="100" src="jsother-foundation-01/index1.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<script async src="//jsfiddle.net/2sh6v9zk/3/embed/js,html/"></script>

 [例1 リンク](../../../javascript_jquery/jsother-foundation/jsother-foundation-01/index1.html "例1 リンク")


<h2 class="h-type2">配列をStorageに保存する</h2>

<p class="tmp"><span>書式2</span>toString()を使って配列を保存する</p>

<pre>
配列.<span class="bold red">toString</span>()
    <span class="comment">//配列の要素をコンマ「,」を使って繋げた文字列にします。</span>
    
配列 = 文字列.<span class="bold red">split</span>(",")
    <span class="comment">//コンマ「,」で区切られた文字列を分割して配列に格納します。 </span>
</pre>

toStringメソッドは、文字列でないものを文字列に変換するときに使われるメソッドです。

<div class="box-example">
    <h3 class="h-example">例2</h3>
	配列をストレージに書き込んだ後、読み出し配列に戻します。
</div>

<iframe width="100%" height="100" src="jsother-foundation-01/index2.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


    document.getElementById("btn").addEventListener("click",function(){

      //果物名を入れた配列fruitsを作成
      var fruits = ["リンゴ","ブドウ","レモン"];

      //配列をtoString()で文字列に変換し、変数str1に格納する
      var str1 = fruits.toString();
      alert(str1);

      //セッションストレージに変数str1をkey名「tostr」で書き込む
      sessionStorage.setItem("tostr" , str1 );

      //ストレージからkey名「tostr」のデータを変数str2に読み込む
      var str2 = sessionStorage.getItem("tostr");

      //配列arrを作成し、読み込んだデータを分割して格納する
      var arr = [];
      arr = str2.split(",");

      //配列の3番目の要素を表示
      alert( arr[2] );

    },false);

 [例2 リンク](../../../javascript_jquery/jsother-foundation/jsother-foundation-01/index2.html "例2 リンク")

上記の「配列の保存」ボタンを押すと、最初に「リンゴ,ブドウ,レモン」と表示されると思います。 配列の各要素がコンマで繋がれた文字列に変換されているのが分かります。

続いて「レモン」と表示されます。 配列arrの3番目の要素が、元の配列fruitsの3番目の要素と同じであることが確認できました。 つまり「配列を文字列に変換→Storageに書込→読込→配列に戻す」という処理が成功したことが分かります。

ただこの方法で問題なのは、配列の要素の中に半角コンマが含まれていると駄目な点です。 その場合はtoString()ではなく、for文を使って別の文字で繋いでいく必要があるでしょう。


<h2 class="h-type2">JSONを使って配列を保存する</h2>

<p class="tmp"><span>書式3</span>配列とJSON文字列との変換</p>
<pre>
JSON.<span class="red bold">stringify</span>( 配列 )
    <span class="comment">//JavaScriptオブジェクト（ここでは配列）をJSON文字列に変換する。</span>
    
JSON.parse( JSON文字列 )
    <span class="comment">//JSON文字列をJavaScriptオブジェクト（今回は配列）に変換する。</span> 
</pre>

※JSON.stringify() メソッドはある JavaScript の値を JSON 文字列に変換します。

※JSON.parse() メソッドは文字列を JSON として解析し、文字列によって記述されている JavaScript の値やオブジェクトを構築します


<div class="box-example">
    <h3 class="h-example">例3</h3>
	JSON文字列で配列に書き込んだ後、読み出します。
</div>

<iframe width="100%" height="100" src="jsother-foundation-01/index3.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

    document.getElementById("jsn").addEventListener("click",function(){

      //果物名を入れた配列fruitsを作成
      var fruits = new Array("リンゴ","ブドウ","レモン");

      //配列をJSON文字列に変換してアラート表示させる
      var jstr = JSON.stringify( fruits );
      alert( jstr );

      //JSON文字列をセッションストレージに書き込む
      sessionStorage.setItem( "jsons" , jstr );

      //ストレージから読み込んだJSON文字列を配列に戻す
      var arr = JSON.parse( sessionStorage.getItem("jsons") );

      //配列の2番目の要素をアラート表示
      alert( arr[1] );

    },false);


 [例3 リンク](../../../javascript_jquery/jsother-foundation/jsother-foundation-01/index3.html "例3 リンク")

ボタンを押すと、["リンゴ","ブドウ","レモン"]と表示されます。 これがJSON文字列で配列を表記したものです。これをStorageに書き込みます。

続いて「ブドウ」と表示されます。Storageから読み出して配列に戻し、配列arrに格納した2番目の要素は、 配列fruitsの2番目の要素と同じであることが確認できました。






