Vue.createApp({
  data() {
    return {
      colorClass: 'color',
      isChange: false
    };
  }
}).mount('#app');