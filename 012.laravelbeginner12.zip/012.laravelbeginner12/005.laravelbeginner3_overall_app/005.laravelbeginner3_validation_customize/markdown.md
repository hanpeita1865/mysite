*[page-title]:バリデーションのカスタマイズ


## フォームリクエストについて

validate メソッドは手軽ですが、コントローラー内に直接バリデーションを書く必要があり、誤って処理を書き換える危険や、見た目がスマートでないという問題があります。  
本来コントローラーはビジネスロジックを担うため、入力チェックは分離した方がよい。そのためLaravelには「<span class="bold green marker">フォームリクエスト</span>」という仕組みがあります。

### フォーム用拡張リクエスト

フォームリクエストは、Requestを拡張したクラスで、フォーム送信内容のチェックをリクエスト側で自動処理できる仕組みです。  
コントローラーに書くよりスマートで、バリデーション機能も組み込み済み。継承してカスタマイズすれば、エラーメッセージの日本語化など柔軟に対応できます。

<div markdown="1" class="flex-center">
![](upload/一般的なバリデーションとフォームリクエストの比較図.png "図　一般的なバリデーションはコントローラー内で実行されるが、フォームリクエストを使うとリクエスト内にバリデーション機能をもたせることができる")
</div>


## フォームリクエストバリデーション

では、実際にフォームリクエストによるバリデーションを作成してみましょう。これもartisanコマンドを使って作成できます。  
フォームリクエストは、「artisan make:request」というコマンドを使って作成します。ではターミナルから以下のようにコマンドを実行してください。
<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:request HelloRequest
```
![](upload/HelloRequestコマンド.png)

これで「HelloRequest」というフォームリクエストが作成されます。このスクリプトファイルは、「Http」内に作成される「Requests」というフォルダーの中に、「HelloRequest.php」というファイル名で作成されます。フォームリクエストは、基本的にすべてこの「Requests」フォルダー内に配置します。

![](upload/HelloRequestディレクトリ.png)


## HelloRequestクラスの基本コード

では、作成されたHelloRequest.phpがどのようになっているのか、ソースコードを確認してみましょう。デフォルトでは以下のようなコードが作成されています(※コメント類は省略)。

<p class="tmp list"><span>リスト5-32</span>Requests/HelloRequest.php（デフォルト）</p>
```
<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class HelloRequest extends FormRequest
{

  public function authorize(): bool
  {
    return false;
  }

  public function rules(): array
  {
    return [
      //
    ];
  }
}
```

フォームリクエストは FormRequest クラスを継承して作られ、リクエスト機能に加えてフォーム処理用のバリデーション機能が追加されています。

* **authorize**：このリクエストを使えるかどうかを判定する。true なら許可、false なら不許可（例外が発生）。
* **rules**：バリデーションルールを設定する。ここで返したルールに基づいて入力チェックが実行される。


### HelloRequestを修正する

では、実際にHelloRequestを修正してみましょう。ここでは、先にvalidateメソッドを使ってバリデーションを行ったときと同じ検証ルールを適用することにしましょう。  
HelloRequestクラスを以下のように修正してください。

<p class="tmp list"><span>リスト5-33</span>HelloRequest.php</p>
```
class HelloRequest extends FormRequest
{
  public function authorize()
  {
    if ($this->path() ==  'hello')
    {
      return true;
    } else {
      return false;
    }
  }

  public function rules()
  {
    return [
      'name' => 'required',
      'mail' => 'email',
      'age' => 'numeric|between:0,150',
    ];
  }
}
```
ここでは、まずauthorizeメソッドで、アクセスしたパスを $this->path で確認し、hello の場合だけ true を返して利用を許可し、それ以外は false で拒否。

rulesメソッドでは、name、mail、age に対するバリデーションルールを配列で返し、それぞれにチェックを適用しています。


### アクションを修正する

後は、POST送信時の処理を行うコントローラーのアクションを修正しておきましょう。  
HelloControllerクラスを以下のように修正してください。

<p class="tmp list"><span>リスト5-34</span>HelloController.php</p>
```
// use App\Http\Requests\HelloRequest; 追加

class HelloController extends Controller
{
  
  public function index(Request $request)
  {
    return view('hello.index', ['msg'=>'フォームを入力：']);
  }

  public function post(HelloRequest $request)
  {
    return view('hello.index', ['msg'=>'正しく入力されました！']);
  }
  
}
```
コントローラーのpostメソッドからバリデーション処理を削除しても、引数をHelloRequest $requestにすることで、自動的にHelloRequestの設定内容に基づいたバリデーションが実行されます。  
そのため、見た目上コントローラーにはバリデーション処理がなくても、機能は正しく働きます。
![](upload/HelloRequetバリデートが機能している.png){.photo-border}


## メッセージのカスタマイズ

フォームリクエストがわかったところで、もう少しカスタマイズをしてみましょう。これまでのエラーメッセージはすべて英語でした。日本語で表示させるには、FormRequestの「messages」というメソッドをオーバーライドします。  
HelloRequestクラスに、以下のようにメソッドを追加してください。

<p class="tmp list"><span>リスト5-35</span>HelloRequest.php</p>
```
public function messages()
{
  return [
    'name.required' => '名前は必ず入力して下さい。',
    'mail.email'  => 'メールアドレスが必要です。',
    'age.numeric' => '年齢を整数で記入下さい。',
    'age.between' => '年齢は０～150の間で入力下さい。',
  ];
}
```

追記したら、再度フォームを送信してみましょう。
![](upload/エラーメッセージを日本語で表示.png){.photo-border}

messages メソッドでバリデーション用のエラーメッセージを配列として設定すると、日本語で表示されるようになります。  
配列の形式は 「<span class="red">'項目名.ルール名' => 'メッセージ' </span>」で、各フィールド・ルールごとに指定します。  
複数ルールがある場合は、それぞれにメッセージを用意する必要があります。未設定のルールはデフォルトの英語メッセージが使用されます。


## Livewireのバリデーション

これまでのバリデーションは通常のフォーム送信を前提としていました。  
Livewireでも基本は同じで、フォーム送信時に validate メソッドを呼び出してチェックします。 
ただしLivewireでは、フォーム送信は実際にはAjax通信で行われるため、扱い方が少し異なります。

では、実際の例を見て違いを確かめましょう。まず、Livewire コンポーネントを使うように/helloのページを修正しておきます。  
helloapp.blade.phpの@section部分を以下のように修正してください。

<p class="tmp list"><span>リスト5-36</span>hello/index.blade.php</p>
```
@section('content')
  <p>Livewireコンポーネントの表示</p>
  @livewire('hello-component')
@endsection
```

これで、先に作成したHelloComponentコンポーネントが表示されるようになります。合わせて、HelloControllerクラスの indexメソッドもシンプルな形にしておきましょう。

<p class="tmp list"><span>リスト5-37</span>HelloController.php</p>
```
public function index(Request $request)
{
  return view('hello.index');
}
```

これでHelloComponent利用の準備はできました。後はLivewire コンポーネントを修正してバリデーションを使うようにするだけです。

### コンポーネントにバリデーションを実装する

では、HelloComponentのクラスから修正しましょう。app/Http/LivewireからHelloComponent.phpを開き、以下のように修正してください。

<p class="tmp list"><span>リスト5-38</span>Http/Livewire/HelloComponent.php</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class HelloComponent extends Component
{
  public $input = "";
  public $message = 'no message';

  protected $validate_rule = [
    'input' => 'required|min:5|max:255',
  ];

  public function updateMessage()
  {
    $this->validate($this->validate_rule);
    $this->message = 'Updated: ' . $this->input;
  }

  public function render()
  {
    return view('livewire.hello-component');
  }
}
```

$validate_rule にバリデーションルールをまとめ、updateMessage メソッド内で $this->validate($this->validate_rule) を呼ぶことでバリデーションを実行します。  
Livewireでは validate メソッドはコンポーネント自身に用意されており、引数にルールを渡すだけでチェックできます。  
バリデーションが成功すれば、message プロパティが input プロパティの値に更新されます。

では、テンプレートを修正しましょう。hello-component.blade.phpを開き、コードを以下のように修正してください。

<p class="tmp list"><span>リスト-39</span>hello/livewire/hello-component.blade.php</p>
```
<div>
  <ul>
    <li>{{ $message }}</li>
  </ul>
  <form wire:submit.prevent="updateMessage">
    <input type="text" wire:model="input">
    <button type="submit">Click</button>
    
    @error('input')
      <p style="font-size:10pt;">{{$message}}</sppan>
    @enderror
    
  </form>

</div>
```

<div markdown="1" class="d-flex">
![](upload/abc5文字未満.png){.photo-border}
![](upload/abcdefg5文字以上.png){.photo-border}
</div>

修正したら、/hello にアクセスして動作を確かめましょう。今回、入力フィールドには5~255文字のテキストを入力するようにしています。5文字未満だと、下にエラーメッセージが表示されます。問題ないテキストだとメッセージが更新されます。

## エラーの表示


`<form>` の `wire:submit.prevent="updateMessage"` により、送信時に updateMessage が呼ばれ、prevent によって preventDefault を自動で実行します。  
エラーが発生した場合は @error('input') … @enderror で、name="input" に対応するエラーメッセージを表示します。
```
@error('input')
  <p style="font-size:10pt;">{{$message}}</sppan>
@enderror
```

Livewireでもバリデーションチェックとエラーメッセージ表示は、通常のフォーム送信とほぼ同じ方法で実装可能です。