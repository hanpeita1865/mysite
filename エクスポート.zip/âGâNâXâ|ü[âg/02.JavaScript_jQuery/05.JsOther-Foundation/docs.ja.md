---
title: JavaScript/jQuery（その他）
taxonomy:
    category:
        - docs
child_type: docs
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<!--<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:12px 0 12px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
</style>-->
<style>
    #body-inner > ol > li {
     	font-weight: bold;
        color:#d3ac3f;
        font-family:'Fjalla One',sans-serif;
        font-size:1.2rem;
    }
    #body-inner > ol > li ol li {
        color: #555;
        font-weight: normal;
        font-size: 1rem;
        font-family: "Montserrat", "Helvetica", "Tahoma", "Geneva", "Arial", sans-serif;
    }
</style>


## 目次

1. Web Storage
1. Cookie
	1. jquery.cookie.js
1. jquery.cookie.js
1. FormData()、Ajax送信
1. Drag&Drop
1. メニュー
1. メソッド
    1. 特定の要素があるか判定
    1. URLを取得（location）
    1. パラメーター取得
    1. 文字列に～を含むかのチェック～match,test,indexOf,search,include
    1. 文字列操作～split,slice,trim,join
    1. 正規表現の使い方～
    1. 指定の要素が存在するかを判定
    1. sort()による配列・文字列・オブジェクトのソート方法
    1. オブジェクトの検索方法
    1. 要素で囲む/削除する～wrap/wrapAll/unwrap/wrapInner
    1. map()による配列操作【JS】
    1. 置換操作（replace）
    1. 部分一致したクラスを削除