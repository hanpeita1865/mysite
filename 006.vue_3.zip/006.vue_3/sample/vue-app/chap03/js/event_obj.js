Vue.createApp({
  methods: {
    onclick(e) {
      console.log(e)
    }
  }
}).mount('#app');