*[page-title]:XAMPP

参考サイト
: [【2022年版】Windowsに『XAMPP』をインストールする方法と最低限の設定【無料】](https://my-web-note.com/windows-xampp-install-setting/#xamppapachephpinfo)

