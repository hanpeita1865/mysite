*[page-title]:PHPデバッグ

参考サイト
: [【2022年版】Visual Studio CodeでPHP開発環境＋デバッグ作業でステップ実行できるようにする方法](https://my-web-note.com/vscode-php-develop-debug/)

## 拡張機能「PHP IntelliSense」をインストール＆設定

「PHP IntelliSense」をVSCodeにインストールする。


## VSCode側の「基本設定（setting.json）」を編集する

基本設定「[Ctrl] + [Shift] + [P]→Open Setting(JSON)」を開く。

![](upload/OpenSetting(JSON).png)

設定ファイル（JSON）に下記を追記する。
```
"php.validate.executablePath": "C:\\xampp\\php\\php.exe",
"php.validate.enable": false,
"php.suggest.basic": false,
```
![](upload/validate_setting.png)

設定は上から「php.exeのパス」「VSCode搭載のPHPコード検証機能を無効化」「VSCode搭載のIntelliSense機能候補提示の無効化」となります。

## 拡張機能「PHP Debug」「PHP Extension Pack」をインストール

「[PHP Debug](https://marketplace.visualstudio.com/items?itemName=xdebug.php-debug)」と「[PHP Extension Pack](https://marketplace.visualstudio.com/items?itemName=xdebug.php-pack)」をVSCodeにインストールする。

## VSCodeの基本設定にデバッグ用のPHPのパスを設定

設定ファイル（JSON）に下記を追記する。
```
"php.debug.executablePath": "C:\\xampp\\php\\php.exe",
```

![](upload/executablePath.png)

## PHP Debugを実行するためのDLLを取得

コマンドプロンプトでphp.exeのディレクトリを開いて『php -i | clip』を実行する。

![](upload/clip.png)
※「php -i | clip」を実行しても何も表示されません。ですが、出力された文字列は自動的にコピーされている状態です。※メモ帳で「Ctrl＋V」を押すとわかります

Xdebugの『[Installation Wizard](https://xdebug.org/wizard)』に「php -i | clip」を実行して、自動的にコピーされた文字列を貼り付けて「Analyse my phpinfo() output」を押す。

「Analyse my phpinfo() output」を押すと、追加する必要のあるDLLのダウンロードリンクが表示されるので、リンクをクリックしてDLLを取得します。

## php.iniを編集してDLLを追加
DLLをダウンロードしたページに格納先のディレクトリパスが記載されているので、それに従ってDLLを配置して下さい。

「C:\xampp\php\ext」にダウンロードしたDLLをコピーしました。
![](upload/xdebugファイル格納.png)

※ダウンロードページにはDLLを『「php_xdebug.dll」にリネームして下さい。』とありますが、変更しなくても問題ありません。

ダウンロードしたDLLのパスを「php.ini」の末尾に下記のように追記します。
![](upload/zend_extention.png)

## php.iniを編集して「PHP Debug」のリモートデバックを有効にする
次に「[PHP Debug](https://marketplace.visualstudio.com/items?itemName=xdebug.php-debug)」の「3. Enable remote debugging in your php.ini:」に記載されている内容をphp.iniに追記します。
![](upload/Xdebugv3.png)

XDebugのバージョンによって追記する内容が異なります。XDebugのバージョンの確認は「phpinfo()」で表示されるPHPの設定画面で確認可能です。
Xamppのダッシュボード（<http://localhost:7001/dashboard/>）を開いて、PHPinfoリンクをクリックします。
![](upload/phpinfoリンク.png)
この画面でバージョンが確認できます。
![](upload/Xdebugv3.2.0.png)
![](upload/xdebug_mode.png)
これでVSCodeでステップ実行可能なPHPのデバッグが可能になります。
～途中～