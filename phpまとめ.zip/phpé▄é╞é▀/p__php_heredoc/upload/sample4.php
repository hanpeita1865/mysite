<?php
 
// HTMLを丸ごと変数に格納
$html = <<<EOD
 
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ドキュメント</title>
</head>
<body>
<p>ヒアドキュメントで、<br>
テキスト出力も自由自在！！</p>
</body>
</html>
 
EOD;
 
echo $html;
?>