<?php
    $basePath = '/from_now_slim';
?>