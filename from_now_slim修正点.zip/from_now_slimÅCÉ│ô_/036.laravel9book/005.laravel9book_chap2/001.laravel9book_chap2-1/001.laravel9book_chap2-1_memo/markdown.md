*[page-title]:Chap2-1メモ

## 新規にプロジェクトを作成
新規にプロジェクトを作成します。プロジェクト名は「example-app5」
<p class="tmp cmd"><span>コマンド</span></p>
```
curl -s "https://laravel.build/example-app5?php=81" | bash
```
![](upload/laravel_project5新規作成.png)

「example-app5」作成完了
![](upload/project5作成.png){.photo-border}

### 「docker-compose.yml」コードを一部修正します

<div markdown="1" class="d-flex">
![](upload/phpMyAdminをdockerに追加.png "phpMyAdminコード追加"){.fig-top}
![](upload/mysqlポート変更.png "mysqlポート番号変更"){.fig-top}
</div>


### 環境設定作成

sail up -d を実行します。→ここのデーモン化のコマンド実行は必要ないかも。次の「docker compose up -d」コマンドで一緒に行われるみたいなので。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail up -d
```
![](upload/project5_sail_up_d実行.png)

docker compose up -d を実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
docker compose up -d
```
![](upload/project5_docker_compose_up_d実行.png)


### Chap2-1で行った処理を追加

example-app5プロジェクトに、下記のexample-app2で作成したファイルや修正したファイルを追加する。
```
resources\views\tweet
routes\web.php
database\factories
database\migrations
database\seeders
app\Http\Controllers\Sample\IndexController.php
app\Http\Controllers\Tweet\IndexController.php
app\Models\Tweet.php
```

データベースは「docker compose up -d」で作成されています。
![](upload/project5空のデータベース.png "図　空のproject5用データベース")

テーブルや中のデータを追加していきます。

マイグレーションでテーブル作成
<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan migrate
```

テーブルが作成されました。
![](upload/マイグレーションでテーブルが作成されました.png){.photo-border}

データを日本語形式に設定を変更します。
<p class="lang">config/app.php（112行目）</p>
```
// 'faker_locale' => 'en_US',
'faker_locale' => 'ja_JP', //追加
```

Tweetテーブルにシーダー実行
<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan db:seed --class=TweetsSeeder
```

Tweetテーブルにデータが挿入されました。
![](upload/シーダー実行後データ挿入.png){.photo-border}

このままサイトにアクセスするとエラーが表示されます。
![](upload/サイトにアクセスするとエラー表示される.png){.photo-border}

下記のコマンドを実行して設定を変更。
```
sail up -d//デーモン起動
sail root-shell//コンテナ側にルートでログインします。
chown sail:sail . -R//ファイル所有者をsailに変更します。「-R」オプションは再帰的に実行します
exit
```

再度アクセスすると表示することができます。  
http://localhost/

![](upload/設定変更後サイト表示成功.png "図　設定変更後サイト表示成功"){.photo-border}


### パーミッションエラー

sail up -d を実行すると、エラーになる
![](upload/sail_up_dパーミッションエラー.png)

参考サイト
: https://www.jinmusoftware.com/laravel-sail-permission-denied/

原因
: ファイルを開く権限がありません。<br>
作成されたLaravelのファイルの所有者が「root」になっています。root以外のユーザーはファイルを書き込む権限がありません。


対応策
: 対応策は3つあります。

1. Laravelディレクトリ・ファイルの所有者の変更
2. エラー対象のディレクトリ・ファイルのパーミッションの変更
3. 一般ユーザーでLaravelをインストールする


②エラー対象のディレクトリ・ファイルのパーミッションを変更します。誰でも書き込めるように権限を緩くします。  
誰でも書き込めるように権限を緩くします。

参考サイト
: https://stackoverflow.com/questions/70045403/permission-denied-when-running-sail-up

上の階層に移動して、下記のコマンドを実行します。

<p class="tmp"><span>書式</span></p>
```
chmod -R 775 プロジェクト名
```
![](upload/sail_up_dパーミッションエラー.png)
![](upload/sail_up_d_example-app9実行.png)

http://localhost/ に接続すると、表示できるようになった。


###  テーブル作成してデータ挿入

マイグレーションを実行
```
sail artisan migrate
```
![](upload/sail_migration_example-app9.png)

シーダーを実行
```
sail artisan db:seed
```
![](upload/example-app9sail_artisan.png)


## テーブル作成からデータ挿入までの流れまとめ

### データベースを作成する（インストール時点で最初からある）
Laravel Sailではアプリケーションと同名のデータベースが作成されます。


### 空のテーブルを作成する

<p class="tmp cmd"><span>コマンド</span>マイグレーション用テーブルファイル作成</p>
```
sail artisan make:migration テーブル名
```
database/migrationsの中にファイルが作成されます。  
database/migrations/～.php にカラムなどの作成コードを追記します。

<p class="tmp cmd"><span>コマンド</span> マイグレーション実行</p>
```
sail artisan migrate
```
設定したカラムがある空のテーブルが作成されます。


### シーディングを利用して開発用のデータを一括挿入

シーダーを作成します。

<p class="tmp cmd"><span>コマンド</span>シーダー用ファイル作成</p>
```
sail artisan make:seeder クラス名
```

database/seederディレクトリに指定したクラス名のphpファイルが作成されます。


<p class="tmp cmd"><span>コマンド</span>シーダーを実行</p>
```
sail artisan db:seed
```
開発用のデータが挿入されます。


<p class="tmp cmd"><span>コマンド</span>Eloquentモデルの作成</p>
```
sail artisan make:model クラス名
```

app/Modelsディレクトリ内に指定したクラス名のphpファイルが作成されます。


<p class="tmp cmd"><span>コマンド</span>Factoryを作成</p>
```
sail artisan make:factory クラス名Factory --model=クラス名

```

database/factoriesディレクトリ内にクラス名Factoryファイルが作成されます。  
このファイルのdefinitionメソッドに生成したいデータを記述します。


Factoryを利用してシーディングを行う

再度シーダーファイルを編集し、シーダーを実行します。
<p class="tmp cmd"><span>コマンド</span>シーダーを実行</p>
```
sail artisan db:seed
```

## 既存のプロジェクトをコピーする方法

プロジェクトをコピーします。

「chmod -R 775 プロジェクト名」 を実行します。

マイグレーションを実行します。
```
sail artisan migrate
```

シーダーを実行します。
```
sail artisan db:seed
```

これでデータベースにテーブルが作成され、その中にデータが挿入されます。
![](upload/example-app5にテーブルとデータ挿入.png){.photo-border}

これで「`sail up -d`」を実行します。

次が表示できていれば完了です。
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>　