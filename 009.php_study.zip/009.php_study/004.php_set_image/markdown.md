*[page-title]:画像の保存方法

## 新規登録フォームから画像を保存

### 画像保存処理

新規登録フォームから画像を保存できるように設定します。  

formタグに「`enctype="multipart/form-data"`」と「`<input type="file" name="image">`」を追加します。

<p class="tmp list"><span>リスト</span>insert-input.php</p>
```
・・・
<body>
    <p><a href="index.php">一覧に戻る</a></p>
    <form class="form-box" action="insert-output.php" method="post" enctype="multipart/form-data"><!-- 追加 -->
        <input type="hidden" name="token" value="<?= $token; ?>">
        <label for="name">商品名</label>
        <input id="name" type="text" name="name" value="<?php if (isset($_SESSION['name'])) {echo $_SESSION['name'];} ?>">
        <label for="local">生産地</label>
        <input id="local" type="text" name="local" value="<?php if (isset($_SESSION['local'])) {echo $_SESSION['local'];} ?>">
        <label for="price">価格</label>
        <input id="local" type="text" name="price" value="<?php if (isset($_SESSION['price'])) {echo $_SESSION['price'];} ?>">
        <input type="file" name="image"><!-- 追加 -->![](upload/画像選択.png)
        <input type="submit" value="新規追加">
    </form>
    <script src="js/admin.js"></script>
</body>
・・・
```

次のように、フォームへ画像ファイル選択欄が表示されました。
![](upload/画像選択.png){.photo-border}

データベースに画像のパスを登録するカラムを新規作成します。
![](upload/pathカラム.png){.photo-border}

選択して送信された画像のデータを受け取って、保存するまで処理を追加していきます。
<p class="tmp list"><span>リスト</span>insert-output</p>
```
・・・省略・・・

    //以下、処理続行
    $pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8','staff','password');
    $sql=$pdo->prepare('insert into products values(null, :name, :local, :price, :path)');//sql文に「:path」を追加

    $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
    $local = htmlspecialchars($_POST['local'], ENT_QUOTES, 'UTF-8');
    $price = htmlspecialchars($_POST['price'], ENT_QUOTES, 'UTF-8');
    $imgpath = $_FILES['image']['name'];//追加

    $sql->bindValue(':name', $name);
    $sql->bindValue(':local', $local);
    $sql->bindValue(':price', $price);
    $sql->bindValue(':path', $imgpath);//追加

    //セッション登録（name,local,price）
    require 'set-session.php';

    //バリデーション
    require 'validation.php';
    $errors = validation($_POST, $imgpath);//$imgpath追加

    //一時的保存にファイルがあるかかつ入力エラーがないか確認（追加）
    if (!empty($_FILES['image']['tmp_name']) && empty($errors)) {

        //保存用のフォルダがなければ作成する
        if(!file_exists('images')){
            mkdir('images');
        }

        //フォルダにファイルを一時的保存から移動して格納
        if(move_uploaded_file($_FILES['image']['tmp_name'], 'images/'.$_FILES['image']['name'])){
            //画像保存に成功
        }else{
            $errors[] = '画像保存に失敗しました。';
        }
    }

・・・省略・・・
```

### 画像データのバリデート

画像ファイル名に、不適合の文字や空白が含まれていないかと同じ画像ファイル名が存在しないかのチェック処理を追加します。

<p class="tmp list"><span>リスト</span>validation.php</p>
```
<?php
    function validation($request, $imgpath) 
    {
		
        ・・・

        //画像ファイルチェック
        if(preg_match('/\*|"|:|\?|<|>|\//', $imgpath)){
            $errors[] = '画像ファイル名に不適合の文字が含まれています。';
        }
        
        if(preg_match('/^\./', $imgpath)){
            $errors[] = '画像ファイル名に「.」の文字が先頭にあります。';
        }
        
        if(strpos($imgpath,' ') !== false || strpos($imgpath,'　') !== false){
            $errors[] = '画像ファイル名に空白があります。';
        }

        foreach (glob('images/*.*') as $file) {
            $nameAry[] = basename($file);//ファイル名だけを配列に格納
        }

        if(in_array($imgpath, $nameAry)){
            $errors[] = '同じ画像ファイル名が存在します';
        }

        return $errors; //$errorsを返す
    }
?>
```


## リダイレクト時の画像設定

バリデートにかかってリダイレクトされたときに、選択したファイルを選択した状態にする処理を設定します。

<p class="tmp list"><span>リスト</span>insert-input.php</p>
```
・・・
<body>
    <p><a href="index.php">一覧に戻る</a></p>
    <form class="form-box" action="insert-output.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="token" value="<?= $token; ?>">
        <label for="name">商品名</label>
        <input id="name" type="text" name="name" value="<?php if (isset($_SESSION['name'])) {echo $_SESSION['name'];} ?>">
        <label for="local">生産地</label>
        <input id="local" type="text" name="local" value="<?php if (isset($_SESSION['local'])) {echo $_SESSION['local'];} ?>">
        <label for="price">価格</label>
        <input id="local" type="text" name="price" value="<?php if (isset($_SESSION['price'])) {echo $_SESSION['price'];} ?>">
        <input type="file" name="image">
        <input id="image-base64" type="hidden" name="image-base64" value="<?php if (isset($_SESSION['image'])) {echo $_SESSION['image']['data'];} ?>"><!--追加-->
        <input id="image-name" type="hidden" name="image-name" value="<?php if (isset($_SESSION['image'])) {echo $_SESSION['image']['name'];} ?>"><!--追加-->
        <div id="image-preview"><img class="thumb" src=""></div><!--追加-->
        <input type="submit" value="新規追加">
    </form>
    <script src="js/admin.js"></script>
    <script src="js/script.js"></script>
</body>
・・・
```


<p class="tmp list"><span>リスト</span>script.js</p>
```
const fileInput = document.querySelector('input[type="file"]');
const img_base64 = document.getElementById('image-base64');
const img_preview = document.querySelector('#image-preview img');
const img_name = document.getElementById('image-name');
const blob = img_base64.value;//base64データ（初期値）
const imgName = img_name.value;//送信した画像ファイル名（初期値）


//blobが空でなければbase64を変換して「input type="file"」にデータをセットする
if(blob !== ''){
    const bin = atob(blob.replace(/^.*,/, ''));
    const buffer = new Uint8Array(bin.length).map((_,x)=>bin.charCodeAt(x));

    //typeを取得
    const separetedDate = blob.split(',');
    const mimeTypeData = separetedDate[0].match(/:(.*?);/);
    const typeData = mimeTypeData[1];

    //ファイルオブジェクトの作成
    const imgData = new File([buffer], imgName, {type: typeData});
    const dt = new DataTransfer();
    dt.items.add(imgData);
    document.getElementsByName("image")[0].files = dt.files;

    //キャプチャ表示
    img_preview.setAttribute('src', blob);
}


fileInput.addEventListener('change', function(e){

    img_preview.setAttribute('src', '');

    const file = e.target.files[0];//Fileオブジェクトを取得
    const reader = new FileReader();//オブジェクトを生成

    //ファイル情報をキャプチャする
    reader.onload = (function(file){
        return function(e){
            img_preview.setAttribute('src', e.target.result);
            img_base64.value = e.target.result;//追加
            img_name.value = '';  //追加
        };
    })(file);

    reader.readAsDataURL(file);
});
```


<p class="tmp list"><span>リスト</span>insert-output.php</p>
```
・・・   
   
    //一時的保存にファイルがあるか確認
    if (empty($_FILES['image']['tmp_name'])){
        $imgpath = '';
    }else{
        $imgpath = $_FILES['image']['name'];        
    }

    $sql->bindValue(':name', $name);
    $sql->bindValue(':local', $local);
    $sql->bindValue(':price', $price);

    //セッション登録（name,local,price）
    require 'set-session.php';

    //バリデーション
    require 'validation.php';
    $errors = validation($_POST, $imgpath);//入力エラーチェック

    //一時的保存にファイルがあるかかつ入力エラーがないか確認
    if (!empty($_FILES['image']['tmp_name']) && empty($errors)) {

        //保存用のフォルダがなければ作成する
        if(!file_exists('images')){
            mkdir('images');
        }

        //フォルダにファイルを一時的保存から移動して格納
        if(move_uploaded_file($_FILES['image']['tmp_name'], 'images/'.$_FILES['image']['name'])){
            //画像保存に成功
        }else{
            $errors[] = '画像保存に失敗しました。';
        }
    }

    $sql->bindValue(':path', $imgpath);


    if(!empty($errors)){
        //エラーがある
        $_SESSION['flash']['message'] = $errors;

        //画像と画像ファイル名をセッションに登録
        $_SESSION['image']['data'] =  $_POST['image-base64'];
        $_SESSION['image']['name'] = $imgpath;

        header('Location:insert-input.php');//入力画面に戻る
        exit();

・・・
```

<p class="tmp list"><span>リスト</span>delete-session.php</p>
```
<?php
//新規登録に成功　セッション削除
unset($_SESSION['name']);
unset($_SESSION['local']);
unset($_SESSION['price']);
unset($_SESSION['image']);//追加
?>
```

これで、画像を選択して、生産地だけ未記入にして、送信します。
![](upload/スイカ入力リダイレクト画像選択.png){.photo-border}
バリデートにかかって入力画面にリダイレクトされたときには、画像は選択された状態になっています。
![](upload/スイカ入力画像選択.png){.photo-border}

画像が未選択もバリデートに設定します。

<p class="tmp list"><span>リスト</span>validation.php</p>
```
・・・
if(empty($imgpath)){
    $errors[] = '画像が未選択です。';
}
・・・
```

未選択でリダイレクトされたときの入力フォームの表示は、次のようになります。
![](upload/画像未選択表示.png){.photo-border}

上記の赤枠内の表示をなくすためには、下記のimgタグの設定をしないようにします。
```
<div id="image-preview"><img class="thumb" src=""></div>
```

imgのsrcが空のときのスタイルを追加します。
```
img.thumb[src=""] {
    width: 0%;
}
```