*[page-title]:10-12. ノイズを増やしたり削除してみよう

## ダスト&スクラッチフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-12-1.jpg)](upload/10-12-1.jpg){.image}
</div>

## ノイズを軽減フィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-12-2.jpg)](upload/10-12-2.jpg){.image}
</div>

## その他のフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-12-3.jpg)](upload/10-12-3.jpg){.image}
</div>