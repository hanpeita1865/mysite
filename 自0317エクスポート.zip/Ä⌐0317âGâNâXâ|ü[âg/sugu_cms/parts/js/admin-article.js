// $(document).ready(function () {
//     const re1 = new RegExp('{{{', 'g');
//     const re2 = new RegExp('}}}', 'g');
//     $(".wysiwyg-area").each(function () {
//         let Id = $(this).attr("id");
//         $(this).text($("#" + Id).val().replace(re1, '').replace(re2, ''));
//     });
//     $(".wysiwyg-area").cleditor({
//         useCSS: true, /* なるべくstyle属性を使う */
//         docCSSFile: "%_relative_web_dir_%parts/css/sugu-site.css", /* 編集領域に適用するスタイルシート。Bの場合は site.css */
//         fonts: "Sans-Serif,Serif", /* フォント選択肢 */
//         bodyStyle: "margin:4px; font-size:1em; cursor:text", /* 入力欄スタイル */
//         width: "100%", /* 入力欄の幅 */
//         height: "450px", /* 入力欄の高さ */
//         styles: /* 段落タグ */
//             [["段落", "<p>"],
//             ["Header 2", "<h2>"], ["Header 3", "<h3>"], ["Header 4", "<h4>"],
//             ["div", "<div>"],
//             ["Header 1", "<h1>"],
//             ["Header 5", "<h5>"],
//             ["Header 6", "<h6>"]]
//     });
// });

var PanelClass = "rightclickmenupanel";    // 右クリックメニューパネル用のDIVのクラス（スタイル指定用）
var FormId = new Array();
//右クリックメニューを表示するフィールドにはクラス rightclickmenu-area を指定。
$('.rightclickmenu-area').each(function () {
    FormId.push($(this).attr("id"));
});
var myTags = new Array;
/* 【よく使うタグの指定】
・4行で設定ワンセットです。
・上から順に表示されます
・必要な設定を追加、削除、変更して下さい。
・2行目が右クリックメニューへの表示、3行目が実際に挿入されるコードです。
・実際に挿入されるコードについては以下のルールがあります。

[挿入コードの記載方法]
- HTMLタグを使用する場合は全体を {{{ と }}}で囲って下さい。
- __TEXT__ の位置に操作時に選択していたテキストが挿入されます。
- シングルクオートは使わないでください。
- 実際の改行は含めず1行で記載して下さい。
- 改行を挿入したい位置には「\\n」と記載して下さい。
- 閉じタグなどで使うスラッシュ（/）は、「\/」と記載して下さい。
*/
myTags.push(
    //1件分 ここから
    [
        '<u style="color: blue;">リンク（同じウィンドウ）<\/u>', //メニューへの表示（タグ可）
        '{{{<a href="■URL■" target="_top">__TEXT__<\/a>}}}' //実際に挿入されるコード
    ],
    //1件分 ここまで
    [
        '<u style="color: blue;">リンク（別ウィンドウ）<\/u>',
        '{{{<a href="■URL■" target="_blank">__TEXT__<\/a>}}}'
    ],
    [
        '&lt;p&gt;で囲う',
        '{{{<p>__TEXT__</p>}}}'
    ],
    [
        '<b>太字<\/b>',
        '{{{<b>__TEXT__<\/b>}}}'
    ],
    [
        '<b style="color: red;">太赤字<\/b>',
        '{{{<b style="color: red;">__TEXT__<\/b>}}}'
    ],
    [
        '<h2 style="margin: 0px auto;">大見出し<\/h2>',
        '{__TEXT__}\\n'
    ],
    [
        '<h3 style="margin: 0px auto;">中見出し<\/h3>',
        '[__TEXT__]\\n'
    ],
    [
        '<h4 style="margin: 0px auto;">小見出し<\/h4>',
        '(__TEXT__)\\n'
    ],
    [
        'HTMLタグ（動画/広告）',
        '{{{__TEXT__}}}'
    ]
);

var myAttachedTags = new Array;
var ImgTplt = new Array;
var FileTplt = new Array;
/* 【画像挿入タグの指定】（画像付製品のみ）
・記事内容への画像表示のための指定です。
・「先にアップロード（本文内に挿入）」ボタンでアップロードした後、「記事内容」欄の
 右クリックメニューから挿入できるようになります。
・左寄せにする、右寄せにする、拡大画像あり／なし等を必要に応じて指定して下さい。
・2行目が右クリックメニューへの表示、3行目が実際に挿入されるコードです。

[画像用HTMLタグの記載方法]
- HTMLタグを使用する場合は全体を {{{ と }}}で囲って下さい。
- __HREF__ の位置に画像のパスが挿入されます（拡大サイズ）。
- __THUMB__ の位置にサムネイル画像のパスが挿入されます。
- __ALT__ の位置に「画像の説明」欄の入力が表示されます。
- シングルクオートは使わないでください。
- 実際の改行は含めず1行で記載して下さい。
- 改行を挿入したい位置には「\\n」と記載して下さい。
- 閉じタグなどで使うスラッシュ（/）は、「\/」と記載して下さい。
*/

ImgTplt.push(
    [
        '<span style="display: inline-block;"><img src="__THUMB__" alt="__ALT__" style="width: 50px;" title="左寄せ"><\/span>',
        '{{{<a href="__HREF__" target="_blank"><img src="__THUMB__" alt="__ALT__" style="float:left;"><\/a>}}}'
    ],
    [
        '<span style="display: inline-block; width: 100%; text-align: center;"><img src="__THUMB__" alt="__ALT__" style="width: 50px;" title="上下で改行して中央"><\/span>',
        '\\n{{{<div style="text-align: center;"><a href="__HREF__" target="_blank"><img src="__THUMB__" alt="__ALT__"><\/a><\/div>\\n}}}'
    ],
    [
        '<span style="display: inline-block; width: 100%; text-align: right;"><img src="__THUMB__" alt="__ALT__" style="width: 50px;" title="右寄せ"><\/span>',
        '{{{<a href="__HREF__" target="_blank"><img src="__THUMB__" alt="__ALT__" style="float:right;"><\/a>}}}'
    ]
);
/* 【ファイルリンク挿入タグの指定】（画像付製品でファイルをアップロードしている場合と、添付ファイル付製品
・記事内容のテキストの間にアップロードしたファイルを表示したい場合の設定です。
・「先にアップロード（本文内に挿入）」ボタンでアップロードした後、「記事内容」欄の
 右クリックメニューから挿入できるようになります。
・2行目が右クリックメニューへの表示、3行目が実際に挿入されるコードです。

[ファイルリンク用HTMLタグの記載方法]
- HTMLタグを使用する場合は全体を {{{ と }}}で囲って下さい。
- __HREF__ の位置にファイルのパスが挿入されます（拡大サイズ）。
- __ICON__ の位置に、ファイル拡張子に応じたアイコン表示のためのクラス名（「gif」「png」など）が表示されます。
- __ALT__ の位置に「リンクテキスト」欄の入力が表示されます。
- シングルクオートは使わないでください。
- 実際の改行は含めず1行で記載して下さい。
- 改行を挿入したい位置には「\\n」と記載して下さい。
- 閉じタグなどで使うスラッシュ（/）は、「\/」と記載して下さい。
*/

/*ファイルリンク登録用を画像用に兼用*/
FileTplt.push(
    [
        '<span style="display: inline-block;"><img src="__HREF__" alt="__ALT__" style="width: 50px;" title="左寄せ"><\/span>',
        '{{{<a href="__HREF__" target="_blank"><img src="__HREF__" alt="__ALT__" style="float:left;"><\/a>}}}'
    ],
    [
        '<span style="display: inline-block; width: 100%; text-align: center;"><img src="__HREF__" alt="__ALT__" style="width: 50px;" title="上下で改行して中央"><\/span>',
        '{{{<div style="text-align: center;"><a href="__HREF__" target="_blank"><img src="__HREF__" alt="__ALT__" style="float:left;"><\/a><\/div>\\n}}}'
    ],
    [
        '<span style="display: inline-block; width: 100%; text-align: right;"><img src="__HREF__" alt="__ALT__" style="width: 50px;" title="右寄せ"><\/span>',
        '{{{<a href="__HREF__" target="_blank"><img src="__HREF__" alt="__ALT__" style="float:right;"><\/a>}}}'
    ],
    [
        //ファイルリンク用
        '<u style="color: blue;" class="filelink __ICON__">__ALT__<\/u>',
        '{{{<a href="__HREF__" target="_blank" class="filelink __ICON__">__ALT__<\/a>}}}'
    ]
);


// FileTplt.push(
// [
// 		'<u style="color: blue;" class="filelink __ICON__">__ALT__<\/u>',
// 		'{{{<a href="__HREF__" target="_blank" class="filelink __ICON__">__ALT__<\/a>}}}'
// ]
// );

myAttachedTags.push(
    [
        '<span style="display: block; text-align: right; font-size: 0.7em">x<\/span>',
        '__TEXT__'
    ]
);
$('a[id^="current_image_"][class~="current_image"]').each(function () {
    var myHref = $(this).attr("href");
    var myAlt = $(this).attr("title");
    var thumbSrc = $(this).find("img").first().attr("src");
    for (i = 0; i < ImgTplt.length; i++) {
        myAttachedTags.push(
            [
                ImgTplt[i][0].replace(/__THUMB__/g, thumbSrc).replace(/__ALT__/g, myAlt).replace(/__HREF__/g, myHref),
                ImgTplt[i][1].replace(/__THUMB__/g, thumbSrc).replace(/__ALT__/g, myAlt).replace(/__HREF__/g, myHref)
            ]
        );
    }
});
//画像が登録されていたら、クリアのタグも挿入
if (1 < myAttachedTags.length) {
    myTags.push(
        [
            '左右寄せのクリア',
            '\\n{{{<div' + ' style="clear: both;"></' + 'div>}}}\\n'
        ]
    );
}
$('a[id^="current_image_"][class~="current_file"]').each(function () {
    var myHref = encodeURI($(this).attr("href"));
    var myAlt = $(this).attr("title");
    var myClass = $(this).attr("class").replace(/\s*current_file\s*/, "").replace(/\s*filelink\s*/, "");
    for (i = 0; i < FileTplt.length; i++) {
        myAttachedTags.push(
            [
                FileTplt[i][0].replace(/__ALT__/g, myAlt).replace(/__HREF__/g, myHref).replace(/__ICON__/g, myClass),
                FileTplt[i][1].replace(/__ALT__/g, myAlt).replace(/__HREF__/g, myHref).replace(/__ICON__/g, myClass)
            ]
        );
    }
});
$('a[id^="current_file_"]').each(function () {
    var myHref = encodeURI($(this).attr("href"));
    var myAlt = $(this).attr("title");
    var myClass = $(this).attr("class").replace(/\s*current_file\s*/, "").replace(/\s*filelink\s*/, "");
    for (i = 0; i < FileTplt.length; i++) {
        myAttachedTags.push(
            [
                FileTplt[i][0].replace(/__ALT__/g, myAlt).replace(/__HREF__/g, myHref).replace(/__ICON__/g, myClass),
                FileTplt[i][1].replace(/__ALT__/g, myAlt).replace(/__HREF__/g, myHref).replace(/__ICON__/g, myClass)
            ]
        );
    }
});

/* 【タッチデバイスの対応】（通常は変更の必要ありません）
iPhone や iPad などのタッチデバイスでは、右クリックメニューを開くための長押しが、
ブラウザの初期設定の機能(選択/コピー/...)と競合するために、右クリックメニューの表示が入力を邪魔する事があります。
以下は、右クリックパネルを無効にするためのエントリです。
「'__ENABLE_USER_SELECT__'」の行は変更しないで下さい。
*/
var myUI = navigator.userAgent.toLowerCase();
if (myUI.indexOf('iphone') > 0 || myUI.indexOf('ipad') > 0 || myUI.indexOf('ipod') > 0 || myUI.indexOf('android') > 0) {
    myTags.unshift(
        [
            '<span style="display: block; text-align: right;">再読み込みするまで隠す<\/span>',
            '__ENABLE_USER_SELECT__'
        ]
    );
}


//閉じるボタン
myTags.unshift(
    [
        '<span style="display: block; text-align: right; font-size: 0.7em">x<\/span>',
        '__TEXT__'
    ]
);
var i;
var ParentPanel = document.getElementById("panels");
// for (i = 0; i < FormId.length; i++) {
//     if (document.getElementById(FormId[i])) {
//         makeTaglist(ParentPanel, FormId[i], PanelClass, myTags);
//         if (1 < myAttachedTags.length) {
//             makeAttachedItemsTaglist(ParentPanel, FormId[i], PanelClass, myAttachedTags);
//         }
//     }
// }

function set_value(MyName, MyItem, IfAppend) {
    var FM = document.forms[0];
    switch (IfAppend) {
        case 1: //追記
            eval("FM." + MyName + ".value += '" + MyItem + "'");
            break;
        default: //入れ替え（初期設定）
            eval("FM." + MyName + ".value = '" + MyItem + "'");
            break;
    }
}



//サムネイル画像切り替え
const current_image = document.querySelectorAll('img.current_image');
let thumbArray = {};//元画像格納用


//元画像配列に格納
current_image.forEach(function (e) {
    thumbArray[e.getAttribute('id')] = e.getAttribute('src');
});

//ファイルリンク用サムネイル設定
document.querySelectorAll('#filelist .filelink').forEach(function (e) {
    let fileHref = e.getAttribute('href');
    let fileId = e.getAttribute('id');

    let fileHtml = '<img src="' + fileHref + '" alt="" id="' + fileId + '" class="current_image">';
    e.innerHTML = fileHtml;
    e.classList.add('sugu-image-preview', 'pure-u-md-1-4');

    //配列に登録
    thumbArray[fileId] = fileHref;
});



//画像ファイル選択したときの サムネイル画像とアップロードボタンの表示設定
document.querySelectorAll('.sugu-input-image').forEach(function (elm) {

    let cureId = elm.getAttribute('id').replace('imagename', 'current_image_name,');

    if(cureId != 'current_image_name,4'){//タイトルファイルは省く　必要なかったら削除

        if(document.getElementById(cureId) != null){
            elm.closest('.sugu-form-wrapper').nextElementSibling.children[0].classList.add('d-none');
        }else{
            elm.closest('.sugu-form-wrapper').nextElementSibling.children[1].classList.add('d-none');
        }

        elm.addEventListener('change', function (e) {
            let file = e.target.files[0];//Fileオブジェクトを取得
            let reader = new FileReader(); //オブジェクトを生成
            let thumb_id = e.target.getAttribute('id').replace('imagename', 'current_thumbnail_');//サムネイル表示要素id値
            let a_id = e.target.getAttribute('id').replace('imagename', 'current_image_');//サムネイルのa要素id値

            if (thumb_id in thumbArray) {
                //元画像登録にある場合
                reader.onload = (function (file) {
                    return function (t) {
                        document.getElementById(thumb_id).setAttribute('src', t.target.result);
                    };
                })(file);

                reader.readAsDataURL(file);

                // elm.closest('.sugu-form-wrapper').nextElementSibling.children[0].classList.remove('d-none');//「先にアップロード」ボタン表示

            } else {
                //元画像登録にない場合
                if (e.target.closest('.sugu-form-wrapper').previousElementSibling != null) {
                    e.target.closest('.sugu-form-wrapper').previousElementSibling.remove();
                }

                reader.onload = (function (file) {
                    return function (t) {
                        const thumb_html = '<div class="pure-g"><div class="sugu-image-preview"><a href="" title="" id="' + a_id + '" class="current_image" target="_blank"><img src="' + t.target.result + '" alt="" id="' + thumb_id + '" class="current_image"></a></div></div>'
                        e.target.closest('.sugu-form-wrapper').insertAdjacentHTML('beforebegin', thumb_html);
                    };
                })(file);

                reader.readAsDataURL(file);
            }
        });
    }

});



//ファイルリンク用サムネイル切り替え
document.querySelectorAll('.sugu-input-file').forEach(function (elm) {
    elm.addEventListener('change', function (e) {
        let file = e.target.files[0];//Fileオブジェクトを取得
        let reader = new FileReader(); //オブジェクトを生成
        let thumb_id = e.target.getAttribute('id').replace('filename', 'current_new_');//サムネイル表示要素id値

        if (thumb_id in thumbArray) {

        } else {
            //元画像登録にない場合
            if (e.target.closest('.sugu-clearfix').firstElementChild.classList.contains('sugu-image-preview')) {
                reader.onload = (function (file) {
                    return function (t) {
                        console.log(t.target.result)
                        document.getElementById(thumb_id).setAttribute('src', t.target.result);
                    };
                })(file);

                reader.readAsDataURL(file);

            } else {
                //新規にサムネイルを表示
                reader.onload = (function (file) {
                    return function (t) {
                        const thumb_html = '<a href="' + t.target.result + '" class="filelink img sugu-image-preview pure-u-md-1-4" title="" target="_blank"><img src="' + t.target.result + '" alt="" id="' + thumb_id + '" class="current_image"></a>';

                        e.target.closest('.sugu-clearfix').insertAdjacentHTML('afterbegin', thumb_html);
                    };
                })(file);

                reader.readAsDataURL(file);
            }

        }
    })
});


//画像選択リセット
document.querySelectorAll('.picture-set .reset-thumb').forEach(function (elm) {
    elm.addEventListener('click', function (e) {
        const input_id = e.target.previousElementSibling.getAttribute('id');//inputタグのid値
        const thumb_id = input_id.replace('imagename', 'current_thumbnail_');//サムネイル表示要素のid値

        if (thumb_id in thumbArray) {
            //元画像登録にある場合
            document.getElementById(thumb_id).setAttribute('src', thumbArray[thumb_id]);
            elm.closest('.sugu-form-wrapper').nextElementSibling.children[0].classList.add('d-none');//「先にアップロード」ボタン非表示
        } else {
            // 〃 にない場合
            document.getElementById(thumb_id).setAttribute('src', '');
            e.target.closest('.sugu-form-wrapper').previousElementSibling.remove();

        }

        document.getElementById(input_id).value = '';
    });
});

//添付画像リセット
document.querySelectorAll('.tenpu-set .reset-thumb').forEach(function (elm) {
    elm.addEventListener('click', function (e) {
        e.target.closest('.sugu-clearfix').querySelector('.filelink').remove();
        e.target.previousElementSibling.value = '';
    });
});

//タイトル選択ファイルのリセット
document.getElementById('reset-title-file').addEventListener('click', function(e){
    e.target.previousElementSibling.value = '';
});


//基本項目詳細の開閉
//初期表示の時は開いた状態
const title_box = document.getElementById('subject');
const base_detail = document.getElementById('base-detail');

if(title_box.value==''){
    document.querySelector('.base-file-box').classList.remove('slideup');
    document.querySelector('.filename-group').classList.remove('slideup');
}

//基本項目詳細 クリックで開閉
document.getElementById('base-set').addEventListener('click', function() {
    this.children[0].classList.toggle('slideup');
    document.querySelector('.base-file-box').classList.toggle('slideup');
    document.querySelector('.filename-group').classList.toggle('slideup');

    if (document.querySelector('.base-file-box').classList.contains('slideup')) {
        this.children[0].setAttribute('title', 'クリックでタイトルリンク、ファイル名の入力欄を表示します');
        this.children[1].textContent = '（クリックでタイトルリンク、ファイル名の入力欄を表示します）';
    } else {
        this.children[0].setAttribute('title', '詳細入力欄を閉じます');
        this.lastChild.textContent = '（クリックで詳細入力欄を閉じます）';
    }
});

//記事内容の縮小
document.getElementById('content-slide').addEventListener('click', function () {
    this.children[0].classList.toggle('slideup');
    document.getElementById('kiji-detail').classList.toggle('box-slideup');

    if (this.children[0].classList.contains('slideup')) {
        this.children[0].setAttribute('title', 'クリックで高さを拡げます');
        this.lastChild.textContent = '（クリックで高さを拡げます）';
    } else {
        this.children[0].setAttribute('title', 'クリックで高さを縮める');
        this.lastChild.textContent = '（クリックで高さを縮めます）';
    }
});


//画像欄の開閉
document.getElementById('picture-slide').addEventListener('click', function () {
    this.children[0].classList.toggle('slideup');
    document.querySelector('.picture-set').classList.toggle('box-slideup');


    if (this.children[0].classList.contains('slideup')) {
        this.children[0].setAttribute('title', '画像ボックスを開きます');
        this.lastChild.textContent = '（クリックで開きます）';
    } else {
        this.children[0].setAttribute('title', '画像ボックスを閉じます');
        this.lastChild.textContent = '（クリックで閉じます）';
    }
});

//添付ファイルボックスを縮小
document.getElementById('tenpu-slide').addEventListener('click', function () {
    this.children[0].classList.toggle('slideup');
    this.closest('.heading-tenpu').nextElementSibling.classList.toggle('box-slideup');

    if (this.children[0].classList.contains('slideup')) {
        this.children[0].setAttribute('title', '添付ファイルボックスを全開にします');
        this.lastChild.textContent = '（クリックで全開にします）';
    } else {
        this.children[0].setAttribute('title', '添付ファイルボックスを縮小します');
        this.lastChild.textContent = '（クリックで縮小します）';
    }
});

document.getElementById('btn-kiji-memo').addEventListener('click', function () {
    document.getElementById('kiji-memo').classList.toggle('d-block');
});