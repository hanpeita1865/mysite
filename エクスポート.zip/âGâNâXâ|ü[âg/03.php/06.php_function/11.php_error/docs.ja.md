---
title: エラー表示対処
media_order: error01.png
---

## エラー表示・非表示の設定

エラー内容に下記のようなファイルのパスが表示されてしまい、サーバにアップした時に表示されてしまうのはちょっと嫌なところです。
![error01](error01.png "error01")

そこでPHPのエラーを表示しないようにする方法についてご紹介します。

### php.iniに指定
一番簡単な方法はphp.iniに記述する方法です。

<p class="tmp"><span>書式1</span>エラー出力をしない</p>
```
display_errors = off
```

<p class="tmp"><span>書式2</span>エラー出力をする</p>
```
display_errors = on
```
php.iniはドキュメントルートに設置します。ドキュメントルートとはWebサイトのindex.htmlがある場所ではないですよ。もう一つ上の階層です。


### PHPファイル内に指定
特定のPHPファイルだけでエラーの表示非表示の設定ができます。ファイルの先頭に次の記述をします。

<p class="tmp"><span>書式3</span>エラー出力をしない</p>
```
<?php
ini_set('display_errors', 0);
?>
```

### 参考サイト
* [【PHP】PHPのエラー表示をなくす方法](https://www.webdlab.com/labs/php-display_errors/)



## 「Notice: Undefined index」と表示されるとき

$_POSTや$_GET（フォーム入力値やURLパラメータ）から値を受け取る処理でよく発生します。原因は、そのスクリプトへの初回アクセス時と2回目以降のアクセスで処理を切り分けていないことが考えられます。たとえば、「送信する」ボタンをクリックした後にフォーム入力値を受け取るスクリプトの場合、そのスクリプトに最初にアクセスしたときは$_POSTには何も入っていないので、このエラーメッセージが表示されます。


<p class="tmp">初回アクセス時に「Notice: Undefined index」エラーが発生する</p>
```
<?php
echo $_POST["test"];
?>
```

<p class="tmp">フォーム入力値が入っている場合のみ処理を実行</p>
```
<?php
if (isset($_POST["test"])) {
    echo $_POST["test"];
}
?>
```

これにより、初回アクセス時は$_POSTを参照しないので、エラーメッセージは表示されなくなります。

このエラーメッセージはNoticeレベル（注意）なので、とりあえずの対処で先述したエラーメッセージを非表示にする方法を使う方法もあります。


### 参考サイト

* [「Notice: Undefined index」と表示されるとき](https://php1st.com/574)
* [Notice: Undefined indexエラーの原因と解決方法](https://qiita.com/wakahara3/items/bb7c8d7a1673b161abe7)




