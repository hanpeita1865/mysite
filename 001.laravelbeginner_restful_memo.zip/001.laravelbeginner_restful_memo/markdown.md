*[page-title]:リソースコントローラメモ（削除・更新）

作業環境
: C:\xampp\htdocs\laravelapp_validate

サイトURL
: <http://localhost:6002/rest> または、<http://localhost:8000/rest>


<p class="tb-caption"><span>表　リソースコントローラー一覧</span></p>
 No. | HTTPメソッド | URI | メソッド名| ルート名| 用途
 -------- | -------- | -------- | -------- | ------- | ------
1     | GET      | /rest     | index     | rest.index | 一覧ページ
2    | GET      | rest/create     | create     | rest.create | 新規登録ページ
3    | POST      | rest     | store     | rest.store | 送信されたデータを新規保存
4    | GET      | rest/{id値} | show    | rest.show | 詳細ページ
5    | GET      | rest/{id値}/edit | edit   | rest.edit | 編集ページ
6    | PUT/PATCH  | rest/{id値} | update    | rest.update | 編集更新
7    | DELETE | rest/{id値}  | destroy | rest.destroy | 削除



## レコードの表示

モデルから取得したレコードをテンプレートに送信して表示させます。

<p class="tmp list"><span>リスト1-1</span>RestappController.php</p>
```
public function index()
{
    $items = Restdata::all();
    return view('rest.index')->with('items', $items);//追加
}
```

rest/index.blade.phpを新規作成します。

<p class="tmp list"><span>リスト1-2</span>rest/index.blade.php</p>
```
<table>
@foreach($items as $item)
   <tr><th>message: </th><td>{{$item->message}}</td></tr>
   <tr><th>url: </th><td>{{$item->url}}</td></tr>
@endforeach
</table>
```

これで<http://localhost:6002/rest> にアクセスすると、レコードの一覧が表示されます。

![](upload/レコード一覧表示.png "図　レコード一覧表示"){.photo-border}


## レコードの追加（create、store）

参考書より

<p class="tmp list"><span>リスト2-1</span>RestappController.php</p>
```
//送信フォームの表示
public function create() {
    return view('rest.create');
}

//送信されたデータを新規保存
public function store(Request $request) {
    $restdata = new Restdata;
    $form = $request->all();//送信されたデータを格納
    unset($form['_token']);
    $restdata->fill($form)->save();//データベースに保存
    return redirect('/rest');
}
```

新規登録ページのテンプレートを作成します。

<p class="tmp list"><span>リスト2-2</span>create.blade.php</p>
```
<table>
    <form action="/rest" method="post">
        {{ csrf_field() }}
        <tr>
            <th>message: </th>
            <td><input type="text" name="message" value="{{old('message')}}"></td>
        </tr>
        <tr>
            <th>url: </th>
            <td><input type="text" name="url" value="{{old('url')}}"></td>
        </tr>
        <tr>
            <th></th>
            <td><input type="submit" value="send"></td>
        </tr>
    </form>
</table>
```

![](upload/restdata新規登録送信フォーム.png "図　新規登録送信フォーム"){.photo-border}

### 新規登録ボタンと「一覧ページに戻る」リンクを追加

一覧ページに新規登録ボタンを追加します。

<p class="tmp list"><span>リスト2-3</span>index.blade.php</p>
```
<form action="/rest/create" method="get">
    <input type="submit" value="新規登録">
</form>
```
![](upload/新規登録ボタン追加.png){.photo-border}


新規登録ページに「一覧ページに戻る」リンクを追加します。


<p class="tmp list"><span>リスト2-4</span>create.blade.php</p>
```
･･･
<a href="/rest">一覧ページに戻る</a>
```

![](upload/一覧ページに戻るリンク設置.png){.photo-border}



## レコードの削除（destroy）

参考サイト
: [【Laravel】ルーティングがすっきり！リソースコントローラの活用](https://shiku-hacker.com/learn-laravel-resource-controller/)

コントローラのdestroyメソッドに処理を追加します。

<p class="tmp list"><span>リスト3-1</span>RestappController.php</p>
```
//レコードの削除
public function destroy($id) {
    //追加	
    $deldata = Restdata::find($id);
    $deldata->delete();
    return redirect('/rest');
}
```

一覧ページに削除ボタンを設置します。  
actionのurlに削除するレコードのid値を記入。  
※rest/{id値}を指定するので、書き方としてはid値={{$item->id}}を{}で囲みます。

<p class="tmp list"><span>リスト3-2</span>rest/index.blade.php</p>
```
<table>
    @foreach($items as $item)
    <tr>
        <th>message: </th>
        <td>{{$item->message}}</td>
    </tr>
    <tr>
        <th>url: </th>
        <td>{{$item->url}}</td>
    </tr>
		<!--ここから追加-->
    <tr>
        <th></th>
        <td>
            <form action="/rest/{{{$item->id}}}" method="post">
                @csrf
                @method('DELETE')
                <input type="submit" value="削除">
            </form>
        </td>
    </tr>
		<!--ここまで追加-->
    @endforeach
</table>
```

各レコードに削除ボタンが設置されました。
![](upload/削除ボタン設置.png){.photo-border}

日刊スポーツの削除ボタンを押すと、レコードが削除されます。
![](upload/レコードが削除されたリストが表示.png){.photo-border}


## レコードの変更（edit、update）

編集ボタンを押すと、編集フォームに遷移してそこで更新するようにします。

<p class="tmp list"><span>リスト4-1</span>Restapp.Controller.php</p>
```
// 投稿編集ページを表示
public function edit($id) {
    $editdata = Restdata::find($id);
    return view('rest.edit')->with('editdata',$editdata);
}

//編集を更新
public function update(Request $request, $id) {
    $editdata = Restdata::find($id);
    $editdata->message = $request->message;
    $editdata->url = $request->url;
    $editdata->save();
    return redirect('/rest');
}
```

編集ボタンを設置します。

<p class="tmp list"><span>リスト4-2</span>rest/index.blade.php</p>
```
･･･
<td>
    <form action="/rest/{{{$item->id}}}/edit" method="get">
        <input type="submit" value="編集">
    </form>
</td>
･･･
```

![](upload/編集ボタンを設置.png){.photo-border}

編集ページを新規作成します。

<p class="tmp list"><span>リスト4-3</span>rest/edit.blade.php</p>
```
<form action="/rest/{{{$item->id}}}" method="post">
    @csrf
    @method('PUT')
    <label>message:</label>
    <input type="text" name="message" value="{{$item->message}}">
    <label>url: </label>
    <input type="text" name="url" value="{{$item->url}}">
    <input type="submit" value="編集更新">
</form>
```

編集ボタンをクリックすると、編集画面が表示されます。
![](upload/MSN_Japanの編集ボタンをクリック.png){.photo-border}
↓
![](upload/MSN編集画面変更前.png "図　編集画面変更前"){.photo-border}
↓　messageの値を書きかえて、編集更新ボタンをクリック。
![](upload/MSN編集画面変更後.png "図　編集画面変更後"){.photo-border}
↓　値が更新されました。
![](upload/MSNのデータが更新されました.png "図　MSNのmessageデータが更新されました"){.photo-border}


## 画像を新規登録できるように設定

現状のコントローラの新規投稿用メソッドに追加

<p class="tmp list"><span>リスト5-1</span>RestappController.php</p>
```
//送信されたデータを新規保存
public function store(Request $request) {
    $restdata = new Restdata;
    $form = $request->all();
    $image = $request->file('image');//画像ファイル　追加
    $path = $image->store('public/images');//指定したパスに画像データを保存　追加
    $path = str_replace('public/', '', $path);//ファイル名だけに置換　追加
		
    unset($form['_token']);
    $restdata->fill($form)->save();
    return redirect('/rest');
}
```

<span class="red">※「'public/」を置換したが、この処理をしなくてもいいやり方があるのかも。</span>

新規登録テンプレートに画像ファイル選択inputを追加する。

画像ファイルを送信する場合、formタグに「enctype="multipart/form-data"」を追加する必要があります。
<p class="tmp list"><span>リスト5-2</span>creae.blade.php</p>
```
<table>
	<form action="/rest" method="post" enctype="multipart/form-data">
		･･･
		<!--追加-->
		<tr>
			<th>画像アップロード</th>
			<td><input type="file" name="image"></td>
		</tr>
		･･･
```

![](upload/画像アップロードコントロール追加.png){.photo-border}

strage/app/public/imagesフォルダを作成します。
![](upload/strageディレクトリ.png){.photo-border}

restdataテーブルにpathカラムを追加します。
![](upload/restdataテーブルにpathカラム追加.png){.photo-border}

これで画像を選択して送信すると、画像ファイルは、下記に保存されています。
![](upload/画像ファイルはここに保存.png){.photo-border}



### 一覧ページに画像を表示する

テンプレートに画像表示の要素を追加します。

<p class="tmp list"><span>リスト5-3</span>index.blade.php</p>
```
･･･
<tr>
    <th>画像</th>
    <td><img src="/storage/images/{{$item->path}}" alt=""></td>
</tr>
･･･
```

シンボリックリンクを行います。
<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan storage:link
```
![](upload/シンボリックリンク.png)

シンボリックリンク設定後　publicにstrageディレクトリが追加されます。
![](upload/strageディレクトリ作成.png){.photo-border}

これで一覧ページにアクセスすると、画像が表示されます。
![](upload/一覧ページに画像表示.png){.photo-border}


## 画像削除の機能を追加

<p class="tmp list"><span>リスト6-1</span>RestappController.php</p>
```
･･･
use Illuminate\Support\Facades\Storage;
･･･

//レコードの削除
public function destroy($id) {
    $deldata = Restdata::find($id);

    if($deldata->path){
        Storage::disk('public')->delete('images/'.$deldata->path);//画像ファイル削除
    }

    $deldata->delete();
    return redirect('/rest');
}
```

これで一覧ページのレコードの削除ボタンをクリックすると、テーブルのレコードと画像ファイルが削除されます。


## 画像変更の設定追加

編集更新用テンプレートに画像用inputを追加します。

<p class="tmp list"><span>リスト7-1</span>edit.blade.php</p>
```
<form action="/rest/{{{$item->id}}}" method="post" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <label>message:</label>
    <input type="text" name="message" value="{{$item->message}}">
    <label>url: </label>
    <input type="text" name="url" value="{{$item->url}}">
    <input type="file" name="image"><!--追加-->
    <input type="submit" value="編集更新">
</form>
```

ファイル選択の項目が追加されました。
![](upload/編集画面にファイル選択追加.png "図　編集画面"){.photo-border}

編集時に画像が選択されていれば、現在のファイルを削除して、選択されたファイルを保存します。

<p class="tmp list"><span>リスト7-2</span>RestappController.php</p>
```
//編集を更新
public function update(Request $request, $id) {

    $editdata = Restdata::find($id);

    // 画像ファイルインスタンス取得
    $image = $request->file('image');

    if (isset($image)) {
        Storage::disk('public')->delete($editdata->path);//現在の画像ファイル削除

        $path = $image->store('public/images');//指定したパスに画像データを保存
        $path = str_replace('public/', '', $path);//ファイル名からpublicを置換
        $editdata->path = $path;
    }

    $editdata->message = $request->message;
    $editdata->url = $request->url;
    $editdata->save();
    return redirect('/rest');
}
```

一覧ページに画像表示を変更します。
<p class="tmp list"><span>リスト7-3</span>index.blade.php</p>
```
･･･
<tr>
    <th>画像</th>
    <td>
    @if ($item->path !=='')
        <img src="{{ \Storage::url($item->path) }}" width="25%">
    @else
        <!-- <img src="{{ \Storage::url('items/no_image.png') }}"> -->
    @endif
    </td>
</tr>
･･･
```


## トップページに一覧ページ設定

フォームではない一般の一覧ページをトップページに設定します。（普段はLaravelのトップページ）

コントローラを作成します。
![](upload/RestController作成.png)

restdataテーブルのデータを表示させるコードを記入します。
<p class="tmp list"><span>リスト</span>RestController.php</p>
```
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Restdata;

class RestController extends Controller
{
    public function __invoke(Request $request) {
        $rests = Restdata::all();

        return view('rest')
            ->with('items', $rests);
    }
}
```

テンプレートを作成します。

<p class="tmp list"><span>リスト</span>views/rest.blade.php</p>
```
<table>
    @foreach($items as $item)
    <tr>
        <th>message: </th>
        <td>{{$item->message}}</td>
    </tr>
    <tr>
        <th>url: </th>
        <td>{{$item->url}}</td>
    </tr>
    <tr>
        <th>画像</th>
        <td>
        @if ($item->path !=='')
            <img src="{{ \Storage::url($item->path) }}" width="25%">
        @else
            <!-- <img src="{{ \Storage::url('items/no_image.png') }}"> -->
        @endif
        </td>
    </tr>
    @endforeach
</table>
```


web.phpに追記します。
<p class="tmp list"><span>リスト</span>web.php</p>
```
Route::get('/', \App\Http\Controllers\RestController::class);
```

http://localhost:6002/ にアクセスすると表示できました。
![](upload/restトップページ表示.png){.photo-border}

通常は、Laravelのデフォルトのトップページにしておく方がいいので、web.phpの`Route::get('/', \App\Http\Controllers\RestController::class);`はコメントアウトして、デフォルトの下記のコードを生かすようにしておきます。
<p class="lang">web.php</p>
```
Route::get('/', function () {
    return view('welcome');
});
```