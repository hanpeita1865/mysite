<?php
require_once 'greeting.php'; // greeting.phpの読み込み
require_once 'calling.php'; // calling.phpの読み込み