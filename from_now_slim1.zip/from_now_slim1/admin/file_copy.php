<?php
    function globAll($ptn) {
        // 指定されたディレクトリを出力
        $array = explode('/', $ptn);

        if(preg_match('/^\d{2}./',$array[array_key_last($array)])){
            echo $ptn . "<br />";
            copy('../template/index.php', $ptn.'/index.php');
        }

        // 指定されたディレクトリ内の一覧を取得
        $res = glob($ptn.'/*');

        // 一覧をループ
        foreach ($res as $f) {
            // is_file() を使ってファイルかどうかを判定
            if (!is_file($f)) {
                // ディレクトリの場合（ファイルでない場合）は再度globAll()を実行
                globAll($f);
            }
        }
    }

    // 最初にディレクトリを指定する
    globAll('../pages');
?>