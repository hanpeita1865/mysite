*[page-title]:クリーンコード中級者入門


## Node.jsでコードの挙動を確認する方法

1. ターミナルを開きます。
2. 次のコードを入力します。
<p class="tmp cmd"><span>コマンド</span></p>
```
node 実行するファイル名
```
![](upload/node_bad.jsコマンド実行.png)

3. 実行した結果が表示されました。