*[page-title]:Bladeの構文


## 値の埋め込み

Bladeでは、<span class="bold red">{{ 値 }}</span> の形式で変数や関数の結果などを表示できます。  
この出力は自動的にHTMLエスケープされるため、タグなどは文字列として表示されます。  

エスケープせずにHTMLタグなどをそのまま表示したい場合は、<span class="bold green">{!! 値 !!}</span> を使います。

これらを使い分けることで、表示内容を安全かつ柔軟に制御できます。

では、以下のコードに修正して「/hello」にアクセスしてみてください。

<p class="tmp list"><span>リスト3-12</span>index.blade.php</p>
```
<body>
  <h1>Blade/Index</h1>
  <p>{{$msg}}</p>
  <p>{{12300*1.08}}</p>
  <p>{{date('Y-m-d H:i:s')}}</p>
  <p>{!!"This is <b>sample</b><i>message.</i>"!!}</p>
</body>
```

![](upload/HTMLコードを埋め込んで表示.png){.photo-border}

`{{ 12300 * 1.08 }}` → 計算結果を表示

`{{ date('Y-m-d H:i:s') }}` → 現在日時を表示

`{!! "This is <b>sample</b><i>message</i>" !!}` → HTMLタグを使った装飾付きの文字列を表示

Bladeでは、数式・関数・HTMLコードなどを簡単にテンプレート内に埋め込んで表示できます。


### Bladeのディレクティブとは

Bladeのディレクティブは、@ディレクティブ名 の形式で記述する特別な構文です。  
例：@csrf はフォーム用のCSRFトークンを自動生成するディレクティブ。

引数が必要な場合は 「**<span class="green">@ディレクティブ(引数)</span>**」 の形式で書きます。  
ディレクティブを使うことで、複雑な処理や構文をシンプルにテンプレート内へ埋め込むことができます。  
条件分岐やループなど、文法的な機能を持つディレクティブも用意されています。

<p class="tmp"><span>書式</span>ディレクティブ</p>
```php
@ディレクティブ(引数)
```

### @ifを利用

<p class="tmp list"><span>リスト3-13</span>index.blade.php</p>
<pre><code class="hljs xml"><span class="hljs-tag">&lt;<span class="hljs-name">body</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">h1</span>&gt;</span>Blade/Index<span class="hljs-tag">&lt;/<span class="hljs-name">h1</span>&gt;</span>
  <span class="marker-yellow">@if ($msg != '')</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>こんにちは、{{$msg}}さん。<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
  <span class="marker-yellow">@else</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>何か書いて下さい。<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
  <span class="marker-yellow">@endif</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">form</span> <span class="hljs-attr">method</span>=<span class="hljs-string">"POST"</span> <span class="hljs-attr">action</span>=<span class="hljs-string">"/hello"</span>&gt;</span>
    @csrf
    <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"text"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"msg"</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"submit"</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">form</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">body</span>&gt;</span></code></pre>

<p class="tmp list"><span>リスト3-14</span>HelloController.php</p>
```
class HelloController extends Controller
{
  
  public function index()
  {
    return view('hello.index', ['msg'=>'']);
  }

  public function post(Request $request)
  {
    return view('hello.index', ['msg'=>$request->msg]);
  }

}
```

修正したら、/helloにアクセスして動作を確認しましょう。アクセスすると、「何か書いてください」と表示されます。テキストを書いて送信すると、メッセージに変わります。何も送信されたテキストがないと$msgが空になり、@elseの表示がされるようになります。

<div markdown="1" class="d-flex">
![](upload/今日も暑いですねーを記入.png){.photo-border}
<span class="arrow-right mx-3 mt-5"></span>
![](upload/今日も暑いですねーを送信結果.png){.photo-border}
</div>

### Bladeの特殊なディレクティブ（条件分岐）

@ifのほかにも、条件分岐に使えるディレクティブが複数用意されています。  
どのディレクティブも、@ifと同様、オプションとして@elseを組み合わせて使用可能です。

これにより、柔軟な分岐処理をBladeテンプレート内で簡潔に記述できます。

<p class="tmp"><span>書式</span>条件が非成立のときに表示</p>
```
@unless(条件)
	…… 表示内容 ……
@endunless
```
@ifの逆の働きをするものです。@unlessは、条件がfalseの場合に表示を行い、trueの場合は表示をしません。  
@elseを用意した場合は、条件がtrueのときに表示されるようになります。


<p class="tmp"><span>書式</span>変数が空の場合に表示</p>
```
@empty( 変数)
	…… 表示内容 ……
@endempty
```
()に指定した変数が空の場合に表示を行うためのものです。@elseは、変数が空でない（値が設定されている）場合に表示されます。


<p class="tmp"><span>リスト</span>変数が定義済みの場合に表示</p>
```
@isset( 変数)
	…… 表示内容 ……
@endisset
```
@emptyと似ていますが、こちらは変数そのものが定義されているかどうかを確認するものです。  
変数が定義されている(そしてnullではない)場合に表示を行います。@elseを用意することで、変数が未定義だった場合の表示を用意できます。


### @issetで変数定義をチェックする

<p class="tmp list"><span>リスト3-15</span>index.blade.php</p>
```
<body>
  <h1>Blade/Index</h1>
  @isset ($msg)
  <p>「{{$msg}}」と送信されました。</p>
  @else
  <p>何か書いて下さい。</p>
  @endisset
  <form method="POST" action="/hello">
    @csrf
    <input type="text" name="msg">
    <input type="submit">
  </form>
</body>
```

<p class="tmp list"><span>リスト3-16</span>HelloController.php</p>
```
class HelloController extends Controller
{
  
  public function index()
  {
    return view('hello.index');
  }

  public function post(Request $request)
  {
    return view('hello.index', ['msg'=>$request->msg]);
  }
}
```

indexアクションでは値（例：$msg）を渡していないため、テンプレート側で$msgは未定義になります。  
そのため、@isset($msg)はfalseとなります。  

このように、値があるときだけ処理を行うために@issetを使うと、コードがシンプルになります。

記入して送信すると、通常通り表示されます。
<div markdown="1" class="d-flex">
![](upload/issetこんにちは.png){.photo-border}
<span class="arrow-right mx-3 mt-5"></span>
![](upload/issetこんにちは結果.png){.photo-border}
</div>

未記入のまま送信すると、元の表示のままになります。
<div markdown="1" class="d-flex">
![](upload/isset空白で送信.png){.photo-border}
<span class="arrow-right mx-3 mt-5"></span>
![](upload/isset空白で送信.png){.photo-border}
</div>


### 繰り返しのディレクティブ

<p class="tmp"><span>書式</span>for構文に相当するもの</p>
```
@for( 初期化;条件;後処理)
	…… 繰り返す表示 ……
@endfor
```

<p class="tmp"><span>書式</span>foreach構文に相当するもの</p>
```
@foreach($配列 as $変数)
	…… 繰り返す表示 ……
@endforeach
```

<p class="tmp"><span>書式</span>foreach-else構文に相当するもの</p>
```
@forelse($配列 as $変数)
	…… 繰り返す表示 ……
@empty
	…… $変数が空のときの表示 ……
@endforelse
```

これは、foreach構文にelseを追加した場合の処理に相当するものです。()の配列から順に値を取り出して処理を繰り返していく点は@foreachと同じです。値をすべて取り出し終えて取り出せなくなったとき、@emptyにある処理を実行して繰り返しを終えます。


<p class="tmp"><span>書式</span>while構文に相当するもの</p>
```
@while( 条件)
	…… 繰り返す処理 ……
@while
```

### 繰り返しディレクティブを利用する

<p class="tmp list"><span>リスト3-17</span>index.blade.php</p>
```
<body>
  <h1>Blade/Index</h1>
  <p>&#064;foreachディレクティブの例</p>
  <ol>
  @foreach($data as $item)
  <li>{{$item}}
  @endforeach
  </ol>
</body>
```

<p class="tmp list"><span>リスト3-18</span>HelloController.php</p>
```
public function index()
{
  $data = ['one', 'two', 'three', 'four', 'five'];
  return view('hello.index', ['data'=>$data]);
}
```

配列データのテンプレートへの受け渡しを行っています。  
$dataに「one」〜「five」の値を配列で代入し、view(['data' => $data])でテンプレートに渡しています。  
テンプレート側では、$dataとしてその配列を利用でき、リスト表示が可能になります。

![](upload/foreach_one_two.png){.photo-border}


### @break & @continue

<div markdown="1" class="th-none">
| | |
| :--: | -- |
|@break	|PHPのbreakに相当するものです。これが出力されると、その時点で繰り返しのディレクティブが中断されます。|
|@continue	|PHPのcontinueに相当するものです。|
</div>

<p class="tmp list"><span>リスト3-19</span>index.blade.php</p>
```mk
<body>
  <h1>Blade/Index</h1>
  <p>&#064;forディレクティブの例</p>
  <ol>
  @for ($i = 1;$i < 100;$i++)
  @if ($i % 2 == 1)
    @continue
  @elseif ($i <= 10)
  <li>No, {{$i}}
  @else
    @break
  @endif
  @endfor
  </ol>
</body>
```

:No,2~10まで偶数の番号だけが表示されます。
![](upload/break_continue.png){.photo-border}

### $loop変数の概要

Bladeの繰り返し処理では、$loopという特別なループ変数が使えます。  
$loopはオブジェクトで、ループ回数や現在のインデックスなど、繰り返しに関する様々な情報を取得できます。  
ループ処理をより柔軟に制御するために便利な機能です。

<div markdown="1" class="th-none">
| | |
| :--: | :--: |
|$loop->index	|現在のインデックス(ゼロから開始)|
|$loop->iteration	|現在の繰り返し数(1から開始)|
|$loop->remaining	|あと何回繰り返すか(残り回数)|
|$loop->count	|繰り返しで使っている配列の要素数|
|$loop->first	|最初の繰り返しかどうか(最初ならtrue)|
|$loop->last	|最後の繰り返しかどうか(最後ならtrue)|
|$loop->depth	|繰り返しのネスト数|
|$loop->parent	|ネストしている場合、親の繰り返しのループ変数を示す|
</div>

<p class="tmp list"><span>リスト3-20</span>index.blade.php</p>
<pre><code class="language-php hljs">&lt;body&gt;
  &lt;h1&gt;Blade/Index&lt;/h1&gt;
  &lt;p&gt;&amp;<span class="hljs-comment">#064;forディレクティブの例&lt;/p&gt;</span>
  @<span class="hljs-keyword">foreach</span> ($data <span class="hljs-keyword">as</span> $item)
    @<span class="hljs-keyword">if</span> (<span class="marker-yellow">$loop-&gt;first</span>)
      &lt;p&gt;※データ一覧&lt;/p&gt;&lt;ul&gt;
    @<span class="hljs-keyword">endif</span>
    &lt;li&gt;No,{{$loop-&gt;iteration}}. {{$item}}&lt;/li&gt;
    @<span class="hljs-keyword">if</span> (<span class="marker-yellow">$loop-&gt;last</span>)
      &lt;/ul&gt;&lt;p&gt;――ここまで&lt;/p&gt;
    @<span class="hljs-keyword">endif</span>
  @<span class="hljs-keyword">endforeach</span>
&lt;/body&gt;</code></pre>

![](upload/forディレクティブの例.png){.photo-border}


### @php ディレクティブについて

Bladeのディレクティブは制御構文のように使えますが、複雑な処理には限界があります。  
より柔軟な処理が必要な場合は、@php ... @endphpを使ってPHPコードを直接記述できます。  
これにより、テンプレート内でPHPの機能を活用することが可能になります。

<p class="tmp"><span>書式</span></p>
```
@php
	…… PHPのスクリプト ……
@endphp
```

#### @phpと@whileの併用

@whileなどのループディレクティブでは、変数の操作が必要になるため、@phpと組み合わせて使うと便利です。  
複雑な繰り返し処理もテンプレート内で柔軟に書けるようになります。

<p class="tmp list"><span>リスト3-21</span>index.blade.php</p>
```php
<body>
  <h1>Blade/Index</h1>
  <p>&#064;whileディレクティブの例</p>
  <ol>
    @php
      $counter = 0;
    @endphp
    @while ($counter < count($data))
      <li>{{$data[$counter]}}</li>
      @php
        $counter++;
      @endphp
    @endwhile
  </ol>
</body>
```
$counter = 0;で初期化し、@while($counter < count($data))で繰り返し、$counter++で進めることで配列を順に出力できます。  
@phpを使えば変数操作ができ、@whileと組み合わせてループ処理が可能になります。  

ただし、Bladeテンプレートは表示専用が基本。処理はコントローラーで行うべきです。  
@phpは必要最小限にとどめることが大切です。
![](upload/whileディレクティブの例.png){.photo-border}

