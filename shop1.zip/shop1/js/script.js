const fileInput = document.querySelector('input[type="file"]');
const img_base64 = document.getElementById('image-base64');
const img_preview = document.querySelector('#image-preview img');
const img_name = document.getElementById('image-name');
const blob = img_base64.value;//base64データ（初期値）
const imgName = img_name.value;//送信した画像ファイル名（初期値）


//blobが空でなければbase64を変換して「input type="file"」にデータをセットする
if(blob !== ''){
    const bin = atob(blob.replace(/^.*,/, ''));
    const buffer = new Uint8Array(bin.length).map((_,x)=>bin.charCodeAt(x));

    //typeを取得
    const separetedDate = blob.split(',');
    const mimeTypeData = separetedDate[0].match(/:(.*?);/);
    const typeData = mimeTypeData[1];

    //ファイルオブジェクトの作成
    const imgData = new File([buffer], imgName, {type: typeData});
    const dt = new DataTransfer();
    dt.items.add(imgData);
    document.getElementsByName("image")[0].files = dt.files;

    //キャプチャ表示
    img_preview.setAttribute('src', blob);
}


fileInput.addEventListener('change', function(e){

    img_preview.setAttribute('src', '');

    const file = e.target.files[0];//Fileオブジェクトを取得
    const reader = new FileReader();//オブジェクトを生成

    //ファイル情報をキャプチャする
    reader.onload = (function(file){
        return function(e){
            img_preview.setAttribute('src', e.target.result);
            img_base64.value = e.target.result;//追加
            img_name.value = '';  //追加
        };
    })(file);

    reader.readAsDataURL(file);
});