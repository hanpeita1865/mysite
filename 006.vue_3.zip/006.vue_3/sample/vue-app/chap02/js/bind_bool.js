Vue.createApp({
  data: function() {
    return {
      flag: true
    };
  }
}).mount('#app');