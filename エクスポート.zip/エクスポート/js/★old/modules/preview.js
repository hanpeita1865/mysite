//プレビュー用
export function previewSet() {

    let mokujiHight = 0;//プレビュー用
    let scrollVal = 0;
	let scrollNum = 0;//スクロール回数 最初は0回

    if ($('#mokuji').length) {
        mokujiHight = $('#mokuji').outerHeight();
    }

    const cookieExist = document.cookie.indexOf('previewScroll');
	const headingVal = $('h1').text();//h1見出し値

	if (cookieExist !== -1) {
		//Cookieがある
        cookieGet(headingVal, mokujiHight, scrollVal);
	}


    //スクロール値のcookieの値を取得
    function cookieGet(headingVal, mokujiHight, scrollVal){
        //データを1つずつに分ける
        let cookieArray = document.cookie.split(';');
        let scrollTop = cookieArray.filter(value => value.split('=')[0].match(/previewScroll/));
        let pageTitle = cookieArray.filter(value => value.split('=')[0].match(/previewTitle/));

        scrollVal = scrollTop.map(function (value) {
            return value.split('=')[1];
        });

        let titleVal = pageTitle.map(function (value) {
            return value.split('=')[1];
        });

        scrollVal = Number(scrollVal);

        if (titleVal == headingVal) {//プレビューページのタイトルとCookieに保存したタイトルが一致
            //スクロール位置の設定
            window.scrollTo(0, scrollVal + mokujiHight);
        }else{
            //Cookieの削除
            document.cookie = 'name="previewScroll"; max-age=0';
            document.cookie = 'name="previewTitle"; max-age=0';
        }
    }

	//スクロールの位置とページタイトルをクッキーに保存
	$(window).on("scroll", function () {
		// let scrollPos = $(window).scrollTop(); //トップからの位置

		try {

			if (scrollNum < 3) {
				scrollNum++;
				throw new Error('終了します');
			}

			let scrollPos = $(window).scrollTop() - mokujiHight; //トップからの位置（目次高さを除く）
			let pageTitle = $('h1').text();//ページタイトル

			document.cookie = 'previewScroll=' + scrollPos + '; max-age=43200';//半日（12時間）後に削除
			document.cookie = 'previewTitle=' + pageTitle + '; max-age=43200';// 〃

			scrollNum++;

            console.log('スクロール値をcookie保存')

		} catch (e) {
			console.log(e.message);
		}
	});
}