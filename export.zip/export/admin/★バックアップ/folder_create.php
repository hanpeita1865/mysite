<?php
    $newFolder = $_POST['post_newFolder'];

    //半角英数字記号かを判定
    if(preg_match("/^[!-~]+$/", $newFolder) ){
        $pagesGlob = glob('../pages/*');
        $num = sprintf('%03d', count($pagesGlob)+1);//番号を3桁に変更　例)01
    
        mkdir('../pages/'.$num.'.'.$newFolder);
        mkdir('../pages/'.$num.'.'.$newFolder.'/upload');
        file_put_contents( '../pages/'.$num.'.'.$newFolder.'/markdown.md', '*[page-title]:メニュー名');
    
        echo 'フォルダを新規作成しました。';
    }else{
        echo '半角英数字記号で入力してください。';
    }

    require 'folder_complist.php';
    file_put_contents("../templates/layouts/menu_list.twig", $menuCode);
?>