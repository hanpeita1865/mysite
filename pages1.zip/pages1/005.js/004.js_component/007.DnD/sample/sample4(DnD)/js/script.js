 
$(function(){  
    var obj = $("#DnDBox");
	
	//ドラッグしているファイルがドロップ領域に入ったとき
    obj.on('dragenter', function (e) {
        e.stopPropagation(); //イベントを停止する
        e.preventDefault(); //画面遷移を行わない
        $(this).css('border', '4px solid #000');
    });
	
	//ドラッグしているファイルがドロップ領域にある間
    obj.on('dragover', function (e) {  
        e.stopPropagation();  
        e.preventDefault();  
        $(this).css('border', '4px solid #000');  
    });
	
	//ドラッグしているファイルがドロップ領域にドロップされたとき
    obj.on('drop', function (e) {  
        $(this).css('border', '4px dashed #000');
		e.preventDefault(); 
		
		var dropFile = e.originalEvent.dataTransfer.files;//filesプロパティを変数に格納
		console.log(dropFile);//格納したファイルのfilesプロパティを表示
    });
});  