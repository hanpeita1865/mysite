---
title: テンプレートタグ(MT)
media_order: 'template_index_new.png,template_index_new2.png,template_index_new3.png'
taxonomy:
    category:
        - docs
tablesorter:
    active: true
    include_widgets: true
    table_nums: '1,2,3,4'
    args:
        1:
            widgets:
                - zebra
        2:
            widgets:
                - zebra
        3:
            widgets:
                - zebra
        4:
            widgets:
                - zebra
---

<style>
    table.tablesorter th {text-align: center;}
    table.tablesorter td {font-size: 0.9rem;}
</style>
## テンプレートタグ（MTタグ）の基本

「テンプレートタグ」とは、MTのテンプレートの中で使える有効な独自のタグのことです。  
「MTタグ」とよぶこともあります。  
テンプレートタグを組み合わせた言語のことを、「MTML」（Movable Type Markup Language）と呼びます。

テンプレートタグの主な役割は、データベースに保存したデータを取り出して、HTML等に出力することです。 
テンプレートが同じでも、データベースに保存されているデータによって、最終的に出力されるHTMLは変化します。  
テンプレートタグリファレンス（[http://www.movabletype.jp/documentation/appendices/tags/](http://www.movabletype.jp/documentation/appendices/tags/?target=_blank)） を参照すると、使用可能なテンプレートタグを閲覧できます。


### ファンクションタグとブロックタグ

テンプレートタグは、大きく分けて***ファンクションタグ***と***プロックタグ***の2つに分けられます。  
ファンクションタグとは、それ単体で何らかの値を出力するテンプレートタグです。  
データベースにあるデータと1対1で置き換わるようにできています。
例えば、**{c:green}&lt;$mt:BlogName$&gt;{/c}**であれば、「ブログ名」として管理画面で設定したテキストが出力されます。

一方のブロックタグは、ブロックの内部を繰り返したり、条件によってブロック内を出力するかどうかを変えるときに使います。  
ブロックタグの中に、ファンクションタグを入れたり、別のブロックタグを入れたりすることができます。  
例えば、**{c:green}&lt;mt:Entries&gt;～&lt;/mt:Entries&gt;{/c}**というブロックタグは、一連の記事を繰り返し出力する働きをします。  
このブロックの中では、記事の情報を出力する各種のファンクションタグや、記事関連のブロックタグを使うことができます。

ファンクションタグ/ブロックタグともに多数ありますが、それらをすべて記憶しておく必要はありません。  
「どのような情報を出力するためには、どのようなテンプレートタグを使うのか?」ということを大まかに覚えておいて、必要に応じてリファレンスを参照するとよいです。  
例えば、記事のことを英語では「entry」と呼ぶので、記事関連のテンプレートタグは MTEntry〇〇〇 のような名前になっています。


### テンプレートタグの表記ルール

テンプレートタグには、以下の表記ルールがあります。

1. テンプレートタグ名の先頭は、必ず「***MT***」が付きます。
2.  テンプレートタグ名は、大文字/小文字どちらで書いても構いません。また、大文字/小文字を混在させて書いても構いません。
3. 「MT」の後に「:」を入れても構いません。（入れなくても良いです）
4.  ファンクションタグでは、テンプレートタグ名の前後に「***$***」を入れても構いません（入れても良いです）。
5. ファンクションタグは、タグ名の前後に「$」を付ける代わりに、最後を「/>」で閉じても構いません（「>」だけで閉じても良いです）。
6.  ブロックタグは、HTMLのタグと同様に開始タグと終了タグから構成され、「***<テンプレートタグ名>～</テンプレートタグ名>***」のように書きます。

たとえば、「**{c:green}MTBlogName{/c}**」というファンクションタグは、以下のどの書き方でも動作します。

1. &lt;MTBLOGNAME&gt;
2. &lt;MTBlogName&gt;
3. &lt;mt:BlogName&gt;
4. &lt;$mt:BlogNames$&gt;
5. &lt;mt:BlogName/&gt;


ただ、テンプレートタグの表記方法は、統一しておいた方が良いでしょう。  
ちなみにMTに標準で付属するテーマでは、以下の表記方法で統一されています。

* 先頭の「MT」は小文字で書き、その後に「:」を付けます。
* 「MT」の後の部分は、単語の先頭文字を大文字にし、それ以外の文字を小文字にします。
* ファンクションタグでは、テンプレートタグ名の前後を「$」で囲みます。



### モディファイア

MTでは、HTMLタグの属性(アトリビュート)と似た仕組みとして、「***モディファイア***」があります。  
モディファイアには、テンプレートタグの動作をカスタマイズするものや、出力を変えるものなどがあります。  
たとえば、**{c:green}MTEntriesタグ{/c}**には、「**{c:green}lastn{/c}**」というモディファイアがあり、**{c:green}最新記事から何件を出力するか{/c}**を指定することができます。  
以下のように書くと、最新記事から5件だけ出力することができます。
<p class="tmp"><span>書式1</span>最新記事から5件だけ出力</p>
```
<mt:Entries lastn="5">～</mt:Entries>
```

1つのテンプレートタグに対して、モディファイアを複数指定することもできます。  
例えば、以下のように書くと、最新記事から5件を取り出し、それを日付の古い順に並べ替えて出力することができます。

<p class="tmp"><span>書式2</span>最新記事から5件を取り出し、それを日付の古い順に並べ替えて出力</p>
```
<mt:Entries lastn="5" sort_order="descend">～</mt:Entries>
```

#### グローバルモディファイア

モディファイアの中には、個々のテンプレートタグに独自のものと、すべてのテンプレートタグで共通に使えるものがあります。  
後者のモディファイアを総称して、「***グローバルモディファイア***」とよびます。

たとえば、出力からHTMLを削除する「**{c:green}remove_html{/c}**」や、空白を削除する「**{c:green}trim_to{/c}**」といったグローバルモディファイアがあります。  
テンプレートタグに独自なモディファイアの使い方は、個々のテンプレートタグのリファレンスのページで解説されています。  
一方、グローバルモディファイアの使い方は、  
グローバルモディファイアリファレンス([http://www.movabletype.jp/documentation/appendices/modifiers/](http://www.movabletype.jp/documentation/appendices/modifiers/?target=_blank))  
をみてください。



## コメント

テンプレートにコメントを書きたい場合、**{c:green}MTIgnore{/c}**というブロックタグを使います。  
HTMLのコメントと同様に、MTIgnoreタグのブロック内は無視され、結果のHTML等にも出力されません。

<p class="tmp"><span>書式3</span>MTIgnoreタグの書き方</p>

    <mt:Ignore>
    <h1>ここがコメントです</h1>
    </mt:Ignore>


MTIgnoreタグは注釈として利用する以外に、一時的にテンプレートタグやHTMLタグをオフにしたいときにも使用します。  
なお、MTIgnoreタグはブロックタグなので、入れ子にはできません。

### テンプレートタグの動作テスト


インデックステンプレートをファイル名をnew.htmlで新規作成します。
テンプレート名の欄に「最新記事」と入力して、内容に以下を入力します。

<p class="list tmp"><span>リスト1</span></p>
    <!DOCTYPE html>
    <html lang="ja">
        <head>
            <meta charset="utf-8">
            <title>最新記事</title>
        </head>
        <body>
            <ul>
            <mt:Entries lastn="5">
                <li><$mt:EntryTitle$></li>
            </mt:Entries>
            </ul>
        </body>
    </html>

![](template_index_new.png?classes=caption "図1　インデックステンプレートでnew.htmlを新規作成")

【保存】ボタンをクリックして、再構築をクリックして行った後、右サイドメニューのショートカットにある【公開されたテンプレートを確認】をクリックします。
![](template_index_new2.png?classes=caption "図2　クリックして表示確認")
そうすると、作成したテンプレートによる記事のタイトルが表示されています。(今はまだ記事が2件だけなので、ここでは2件しか表示されません。)
![](template_index_new3.png?classes=caption "図3　テンプレートによるnew.htmlの表示結果")

#### 解説
テンプレートのコードを見てもらうと、9行目と11行目には、「**[MTEntries](https://www.movabletype.jp/documentation/appendices/tags/entries.html)**」というブロックタグがあります。  
**{c:green}MTEntriesタグ{/c}**は、**{c:green}記事を順に読み込んで、それらの記事を繰り返しながら、ブロック内を出力する{/c}**働きをします。  
「lastn="5"」のモディファイアを指定していますので、記事を5件読み込んで、順に処理していく形になります。  
また、標準では記事は日付の新しい順に出力されます。  
そして、10行目には「**[MTEntryTitle](https://www.movabletype.jp/documentation/appendices/tags/entrytitle.html)**」というファンクションタグがあります。  
**{c:green}MTEntryTitleタグ{/c}**は、**{c:green}個々の記事のタイトルを出力する{/c}**働きをします。
結果として、このテンプレートを再構築すると、下記のような形のHTMLが出力されます。  
出力ファイル名を「new.html」にしましたので、「new.html」というファイル名で保存されます。

##### HTML（new.html）
    <!DOCTYPE html>
    <html lang="ja">
        <head>
            <meta charset="utf-8">
            <title>最新記事</title>
        </head>
        <body>
            <ul>
                <li>最新記事のタイトル</li>	
                <li>最新から1つ前の記事のタイトル</li>
                <li>最新から2つ前の記事のタイトル</li>
                <li>最新から3つ前の記事のタイトル</li>
                <li>最新から4つ前の記事のタイトル</li>		
            </ul>
        </body>
    </html>


補足
: テンプレートタグの動作テストをしたいときは、HTMLとしてのコメントとして出力します。  
つまり、HTMLのコメントで"&lt;!-- &lt;テンプレートタグ&gt; --&gt;"のようにします。  
こうすると、MTによる処理結果は、HTMLのコメントとして出力されます。  
そのため、ブラウザのソースを見れば、現状のHTMLデザインを壊さずにMTのテンプレートタグの結果を確認できます。

## よく使うテンプレートタグ

MovableTypeのテンプレートタグは400種類以上ありますが、よく使うものはその中の一部です。  
主なテンプレートタグの詳しい使い方は、[テンプレートタグリファレンス](https://www.movabletype.jp/documentation/appendices/tags/)を参照してください。


### ブログ/ウェブサイトの情報を出力

個々の**{c:orange}ブログの情報{/c}**を出力するには、**{c:orange}MTBlog系{/c}**のテンプレートタグを使います。 
また、**{c:purple}ウェブサイトの情報{/c}**は、**{c:purple}MTWebsite系{/c}**のテンプレートタグで出力します (表1参照) 。
ブログの中で、**{c:darkblue}親のウェブサイトの情報{/c}**を出力したいときも、**{c:darkblue}MTWebsite系{/c}**のテンプレートタグを使うことができます。


##### 表1　ウェブサイト/ブログの情報を出力するテンプレートタグ #####{.t-caption}

|出力する情報|ウェブサイト|	ブログ|
|--|--|--|
|ID	|[MTWebsiteID](https://www.movabletype.jp/documentation/appendices/tags/)	|[MTBlogID](https://www.movabletype.jp/documentation/appendices/tags/blogid.html)|
|名前|	[MTWebsiteName](https://www.movabletype.jp/documentation/appendices/tags/websitename.html)	|[MTBlogName](https://www.movabletype.jp/documentation/appendices/tags/blogname.html)|
|概要	|[MTWebsiteDescription](https://www.movabletype.jp/documentation/appendices/tags/websitedescription.html)|	[MTBlogDescription](https://www.movabletype.jp/documentation/appendices/tags/blogdescription.html)|
|トップページのアドレス|	[MTWebsiteURL](https://www.movabletype.jp/documentation/appendices/tags/)	|[MTBlogID](https://www.movabletype.jp/documentation/appendices/tags/blogid.html)|


### 記事/ウェブページの情報を出力

ウェブサイト/ブログ内の個々の記事を出力するには、***MTEntry系***のテンプレートタグを使います (表2参照)。  
記事アーカイブテンプレートでは、MTのシステムによって個々の記事の情報がセットされるため、MTEntry系 のテンプレートタグを直接使うことができます。  
一方、インデックステンプレートや記事以外のアーカイブテンプレートでは、*MTEntriesタグ*で記事を読み込んで、その中で*MTEntry系*のテンプレートタグを使います。  
インデックステンプレートの中でMTEntriesタグを使った場合、通常はウェブサイト/ブログ全体での最新記事が読み込まれます。一方、アーカイブテンプレートの中でMTEntriesタグを使った場合、個々のアーカイブに属する記事が読み込まれます。  
たとえば、ウェブサイトのインデックステンプレートに**{c:green}リスト2{/c}**のような部分を入れた場合、ウェブサイトの最新記事のタイトルが出力され、個々の記事にリンクします(通常は最新10件)。 また、ウェブページの情報を出力するには、***MTPage系***のテンプレートタグを使います（表2）。ウェブページアーカイブテンプレート内では、MTPage系のテンプレートタグを直接に使うことができます。それ以外のテンプレートでは、MTPagesタグでウェブページを読み込み、その中でMTPage系のテンプレートタグを使います。



##### 表2　記事/ウェブページの情報を出力するテンプレートタグ #####{.t-caption}

|出力する情報|記事|	ウェブページ|
|--|--|--|
|ID|[MTEntryID](https://www.movabletype.jp/documentation/appendices/tags/entryid.html)|[MTPageID](https://www.movabletype.jp/documentation/appendices/tags/pageid.html)|
|タイトル|[MTEntryTitle](https://www.movabletype.jp/documentation/appendices/tags/entrytitle.html)|[MTPageTitle](https://www.movabletype.jp/documentation/appendices/tags/pagetitle.html)|
|著者|	[MTEntryAuthorDisplayName](https://www.movabletype.jp/documentation/appendices/tags/entryauthordisplayname.html)|	[MTPageAuthorDisplayName](https://www.movabletype.jp/documentation/appendices/tags/pageauthordisplayname.html)|
|公開日|[MTEntryDate](https://www.movabletype.jp/documentation/appendices/tags/entrydate.html)|[MTPageDate](https://www.movabletype.jp/documentation/appendices/tags/pagedate.html)|
|本文|[MTEntryBody](https://www.movabletype.jp/documentation/appendices/tags/entrybody.html)|[MTPageBody](https://www.movabletype.jp/documentation/appendices/tags/pagebody.html)|
|続き|[MTEntryMore](https://www.movabletype.jp/documentation/appendices/tags/entrymore.html)|	[MTPageMore](https://www.movabletype.jp/documentation/appendices/tags/pagemore.html)|
|概要	|※[MTEntryExcerpt](https://www.movabletype.jp/documentation/appendices/tags/entryexcerpt.html)|※[MTPageExcerpt](https://www.movabletype.jp/documentation/appendices/tags/pageexcerpt.html)|
|アドレス|[MTEntryPermalink](https://www.movabletype.jp/documentation/appendices/tags/entrypermalink.html)|	[MTPagePermalink](https://www.movabletype.jp/documentation/appendices/tags/pagepermalink.html)|
|繰り返しの最初の記事/ウェブページの判断|[MTEntriesHeader](https://www.movabletype.jp/documentation/appendices/tags/entriesheader.html)|[MTPagesHeader](https://www.movabletype.jp/documentation/appendices/tags/pagesheader.html)|
|繰り返しの最後の記事/ウェブページの判断|[MTEntriesFooter](https://www.movabletype.jp/documentation/appendices/tags/entriesfooter.html)|[MTPagesFooter](https://www.movabletype.jp/documentation/appendices/tags/pagesfooter.html)|
|次の記事/ウェブページ|[MTEntryNext](https://www.movabletype.jp/documentation/appendices/tags/entrynext.html)|[MTPageNext](https://www.movabletype.jp/documentation/appendices/tags/pagenext.html)|
|前の記事/ウェブページ|[MTEntryPrevious](https://www.movabletype.jp/documentation/appendices/tags/entryprevious.html)|[MTPagePrevious](https://www.movabletype.jp/documentation/appendices/tags/pageprevious.html)|
|属するカテゴリ/フォルダ|[MTEntryCategory](https://www.movabletype.jp/documentation/appendices/tags/entrycategories.html)|	[MTPageFolder](https://www.movabletype.jp/documentation/appendices/tags/pagefolder.html)|
|付けたタグ|[MTEntryTags](https://www.movabletype.jp/documentation/appendices/tags/entrytags.html)|[MTPageTags](https://www.movabletype.jp/documentation/appendices/tags/pagetags.html)|
|画像等|[MTEntryAssets](https://www.movabletype.jp/documentation/appendices/tags/entryassets.html)|[MTPageAssets](https://www.movabletype.jp/documentation/appendices/tags/pageassets.html)|


<p class="tmp list"><span>リスト2</span>ウェブサイトの最新記事10件を出力する</p>
```
<ul>
<mt:Entries>
	<li><a href="<$mt:EntryPermalink$>"><$mt:EntryTitle$></a></li>
</mt:Entries>
</ul>
```

### カテゴリ/フォルダの情報の出力

カテゴリの情報を出力するには、***MTCategory系***のテンプレートタグを使います（表3）。 ウェブサイト(またはプログ)のすべてのカテゴリを一覧で表示できるようにするには、通常は、リスト3のようなテンプレートを組みます。*MTTopLevelCategoriesタグ*は、「最上位の階層のカテゴリを読み込んで順に出力する」テンプレートタグ(ブロックタグ)です。また、*MTSubCatsRecurseタグ*は、「カテゴリの階層を一段下って、 MTTopLevelCategoriesタグのプロックの先頭から処理をやり直す」テンプレートタグ(ファンクションタグです)。  
たとえば、カテゴリの一覧を順序なしリスト (ul/li要素)で出力する場合、**{c:green}リスト4{/c}**のようにテンプレートを組みます。

カテゴリアーカイブテンプレートの中でも、MTCategory系のテンプレートタグを使うことができます。この場合は、再構築中のカテゴリの情報が出力されます。 また、フォルダの情報を出力するには、***MTFolder系***のテンプレートタグを使います（表3）。

##### 表3　カテゴリ/フォルダの情報を出力するテンプレートタグ #####{.t-caption}

|出力する情報| カテゴリ|	フォルダ|
|--|--|--|
|	ID|	[MTCategoryID](https://www.movabletype.jp/documentation/appendices/tags/categoryid.html)|[MTFolderiD](https://www.movabletype.jp/documentation/appendices/tags/folderid.html)|
|	名前|	[MTCategoryLabel](https://www.movabletype.jp/documentation/appendices/tags/categorylabel.html)|	[MTFolderLabel](https://www.movabletype.jp/documentation/appendices/tags/folderlabel.html)|
|	概要|	[MTCategoryDescription](https://www.movabletype.jp/documentation/appendices/tags/categorydescription.html)|	[MTFolderDescription](https://www.movabletype.jp/documentation/appendices/tags/folderdescription.html)|
|	アーカイブページのアドレス|[MTCategoryArchiveLink](https://www.movabletype.jp/documentation/appendices/tags/categoryarchivelink.html)|	なし|


<p class="tmp list"><span>リスト3</span>ウェブサイト(ブログ)のすべてのカテゴリを出力する</p>
```
<mt:TopLevelCategories>
    <mt:SubCatsIsFirst>
    	最初のカテゴリの時に出力する内容
    </mt:SubCatsIsFirst>
    カテゴリの情報を出力
    <$mt:SubCatsRecurse$>
    <mt:SubCatsIsLast>
    	最後のカテゴリの時に出力する内容
    </mt:SubCatsIsLast>
</mt: TopLevel Categories>
```

<p class="tmp list"><span>リスト4</span>ウェブサイト(ブログ)のすべてのカテゴリを順序なしリストで出力する</p>
```
<mt: TopLevel Categories >
	<mt: SubCatsIsFirst><ul></mt: SubCatsIsFirst>
    <li><a href="<$mt:Category ArchiveLink $>"><$mt:Category Label $></a>
    <$mt: SubCatsRecurse$>
    </li>
	<mt: SubCats Islast></ul></mt: SubCats Islast>
</mt: TopLevel Categories>
```

### アイテムの情報の出力

アイテム(画像など)を出力するには、***MTAsset系***のテンプレートタグを使います（表4）。  
MTAssets タグのブロックの中で表4のテンプレートタグを使うと、{c:green}ウェブサイト（またはブログ）全体のアイテムを読み込んで、順に出力する{/c}ことができます。  
また、MTEntry Assets タグのブロックの中で表4のテンプレートタグを使って、{c:green}記事毎に追加したアイテムを出力する{/c}こともできます。


##### 表4　アイテムの情報を出力するテンプレートタグ  #####{.t-caption}
|出力する情報|	テンプレートタグ|
|--|--|
|ID|[MTAssetID](https://www.movabletype.jp/documentation/appendices/tags/assetid.html)| 
|名前|[MTLabel](https://www.movabletype.jp/documentation/appendices/tags/assetlabel.html)|
|アドレス|[MTAssetURL](https://www.movabletype.jp/documentation/appendices/tags/asseturl.html)| 
|サムネール画像のアドレス| [MTAssetThumbnailURL](https://www.movabletype.jp/documentation/appendices/tags/assetthumbnailurl.html)|












