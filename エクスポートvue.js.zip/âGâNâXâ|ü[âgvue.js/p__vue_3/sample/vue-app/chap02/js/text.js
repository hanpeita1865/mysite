Vue.createApp({
  data: function() {
    return {
      message:'皆さん、こんにちは！'
    };
  }
}).mount('#app');