<?php
$database='from_now';
$user='staff';
$password='password';

$pdo=new PDO('mysql:host=localhost:3309;dbname='.$database.';charset=utf8',$user, $password);
?>

<!DOCTYPE html>
<html lang="ja">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>管理画面｜</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/fork-awesome.min.css">
	<!--<link rel="stylesheet" href="../css/style.css">-->
    <link rel="stylesheet" href="../css/admin.css">
	<!-- <script src="../js/jquery.min.js"></script> -->
	<script>
	//閲覧不可ページ
	let lockArray = [
	<?php foreach ($pdo->query('select * from locklist') as $row): ?>
		'<?= $row['page'] ?>',
	<?php endforeach; ?>
	];
	</script>
</head>

<body>
	<main>
		<div class="container">
			<h1>管理画面</h1>
			<div id="backup-alert" class="alert alert-primary d-none" role="alert"><strong>アラート</strong> - バックアップを取得中です・・・</div>
			<ol>
				<li>メニューをドラック&amp;ドロップすると、並べ替えができます。</li>
				<li>メニュー名のリンクをダブルクリックすれば、メニュー名を変更できます。</li>
				<li>メニューをダブルクリックをすると空のサブメニュー用ボックスが作成されるので、そこにメニューをドラッグしてください。</li>
			</ol>
			<div class="sub-close-area">
				<button class="btn-sub-close open">全サブメニュー閉じる</button>
			</div>
			<ul id="menu" class="side-link">
            	<?php require '../templates/layouts/menu_list.twig' ?>
			</ul>
			<div class="sub-close-area">
				<button class="btn-sub-close open">全サブメニュー閉じる</button>
			</div>
            <div class="d-flex justify-content-between mb-3">
				<input type="button" value="新規フォルダ作成" class="btn-create" id="create">
				<input type="button" value="並べ替え確定" class="btn-confirm" id="btn-execution">
            </div>
			<!-- <button id="btn-execution">メニュー→フォルダ構成反映</button> -->
			<button id="btn-menu-rebuild">フォルダ構成→メニュー反映</button>
			<!-- <button id="btn-file-copy">ファイルコピー</button> -->
			<!-- <button id="btn-backup">バックアップ</button> -->

			<ul class="mt-3">
				<li class="text-danger">並べ替え実行中は、他の操作をしないでください。エラーの原因になります。</li>
				<li>削除を実行すると、自動的に「trush」フォルダにバックアップを取ります。</li>
				<li>pagesフォルダ内に直接ページ用のフォルダを格納した場合は、上記の「フォルダ構成→メニュー反映」を実行してください。ただし、同一のフォルダ名がないか注意する必要があります。</li>
				<li>フォルダ名に使用できる記号は「-」(ハイフン)「_」(下線)「.」 (ピリオド)のみです。</li>
			</ul>
    </main>
	<script>
		// // メニューを元にフォルダの再生成を実行
		// document.querySelector('#btn-execution').addEventListener('click', e=>{
		// 	menu_create();//メニューから配列を作成
		// 	folder_rebuilding(menuStr, 'menu-folder');//フォルダ再生成、menu_list.phpに保存
		// });
	</script>
	<script src="../js/admin.js"></script> 
</body>

</html>