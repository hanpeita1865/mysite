## Anternar Bookmarks

Você pode adicionar/remover bookmarks facilmente em qualquer posição. Você pode inclusive definir **Rótulos** para cada bookmark.

![Alternar](../images/printscreen-toggle.png)

> Dica: Use o Atalho de Teclado <kbd>Cmd</kbd> + <kbd>Alt</kbd> + <kbd>K</kbd>