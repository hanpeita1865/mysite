---
title: '25. ペジネーション'
media_order: 'pagenation_record.png,pagenation1.png,pagenation_order_age.png,pagenation_link_number.png,pagenation_app.png'
taxonomy:
    category:
        - docs
---

ペジネーションは、データベースに保管されているレコードを、一定数ごとに取り出し表示していく技術です。その基本的な使い方を覚えましょう。

## ペジネーションとは?
データベースで多量のデータを扱うようになると、考えなければならないのが「デー タの表示の仕方」です。これまでのように、allで全レコードを取得して表示する、といったやり方はできません。全レコードの中から、表示する部分だけを取り出して処理する 必要が生じます。

このように、レコードを一定数ずつ取り出して表示していくための仕組みが「ペジネーション」です。ペジネーションは、レコード全体をページ分けして表示するための機能を提要します。1ページ当たりいくつのレコードを表示するかを指定し、その数ごとに レコードを取り出して表示していきます。

また、ページ分けをしての表示は、前後のページに移動する機能も用意しなければいけません。でなければ、必要なレコードにたどり着けなくなってしまいますから。つまりペジネーションは、「ページ分けしてレコードを取得する機能」と「指定のページに表示を移動するための機能」の2つの機能によって実現されるもの、といえるでしょう。

![](pagenation_record.png?classes=caption "図1　ペジネーションは、レコード全体から指定のページに表示するものだけを取り出す機能。リンク などを使い、簡単に前後のページに移動できるようになっている。")


DBクラスとsimplePaginate
では、実際にペジネーションを使ってレコードを表示させてみましょう。ここでは、先に作成したHelloControllerのindexアクションメソッドを利用することにします。  
「Controllers」フォルダ内からHelloController.phpを開き、indexメソッドを以下のよう に修正して下さい。


<p class="tmp list"><span>リスト1</span>HelloController.php</p>
```
// use App\Customer;　を追記

public function index(Request $request)
{
   $items = DB::table('customers')->simplePaginate(5);
   return view('hello.index', ['items' => $items]);
}
```

ここでは、5項目ずつレコードを取り出して表示するようにしてあります。レコード の取得部分を見るとこうなっていますね。
```
$items = DB::table('customers')->simplePaginate(5);
```

テーブルは、DB::table('customers')というように指定してあります。そしてその中の 「simplePaginate」というメソッドを呼び出しています。これは以下のように利用します。

```
$変数 = DB::table(テーブル名)->simplePaginater 表示数 );
```

DB::tableでテーブルを指定し、その戻り値のインスタンスからsimplePaginateメソッドを呼び出します。これは引数に、1ページ当たりの表示レコード数を指定します。こ れで、1ページ分のレコードだけが取り出されます。

「ページ当たりのレコード数はわかった、ではページ数はどうやって設定するんだ?」 と思った人。ページ数の設定は必要ありません。このsimlePaginateの戻り値には、前後のページに移動するリンクの情報も含まれており、移動はそれらを使って作成されたリンクで行うようになっているのです。

## ページの表示を作成する
では、テンプレートを修正しましょう。「views」内の「hello」フォルダにあるindex. blade.phpを開き、以下のように記述して下さい。

<p class="tmp list"><span>リスト2</span>hello/index.blade.php</p>
```
@extends('layouts.helloapp')
<style>
   .pagination { font-size:10pt; }
   .pagination li { display:inline-block }
</style>
@section('title', 'Index')

@section('menubar')
   @parent
   インデックスページ
@endsection

@section('content')
   <table>
   <tr><th>Name</th><th>Mail</th><th>Age</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->name}}</td>
           <td>{{$item->mail}}</td>
           <td>{{$item->age}}</td>
       </tr>
   @endforeach
   </table>
   {{ $items->links() }}
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```

これで修正は完了です。/helloにアクセスをしてみて下さい。レコードデータが5項目だけ表示されます。その下には、「<<Previous」「Next>>」といったリンクが表示されます。 このリンクをクリックすることで前後のページに移動することができます。


![](pagenation1.png?classes=caption "図2　ペジネーションは、レコード全体から指定のページに表示するものだけを取り出す機能。リンク などを使い、簡単に前後のページに移動できるようになっている。")


### ページ移動の仕組み
ここでは、コントローラ側から受け取った$itemsから順に値を取り出して、テーブルを表示しています。そしてその下では、以下のような文が用意されています。
```
{{$items->links() }}
```
$itemsは、simplePaginateで取得したインスタンスです。ここから順に値を取り出してレコードの内容を出力しています。が、実はそれがすべてではありません。 $itemsには、 前後の移動のためのリンクを生成する機能も含まれています。それが、「links」というメ ソッドです。linksで得られた値を出力することで、以下のようなタグが生成されるのです。
```
<ul class="pagination">
	<li class="disabled"><span>&laquo; Previous</span></li> 
    <li><a href="http://localhost:8000/hello?page=2" rel="next">Next &raquo;</a></li> 
</ul>
```
次のページに移動するリンクを見てみると、href="http://localhost:8000/ hello?page=2"というように設定されています。/hello に ?page=番号 とパラメータを付けることで、表示するページを設定することができるのです。  
ということは、特定のページに移動する場合は、pageに番号を指定してアクセスすれ ばいいことがわかります。例えば、/hello?page=10とすれば、10ページ目を表示させることができます。

## DBクラスとモデル
ここでは、DBクラスを利用してページ移動をしました。これは、以下のように呼び出せばよかったんですね。
<p class="tmp"><span>書式1</span></p>
```
DB::table(テーブル名 )->simplePaginateページ番号 );
```
では、モデルを利用している場合はどうすればよいのでしょうか。実は、モデルもまったく同様にペジネーションを利用できます。例えば、ここではCustomerモデルクラスを使っていますが、
```
$items = Customer::simplePaginate(5);
```
このように実行すれば、まったく同様にページ単位でレコードを取得することができます。もちろん、linksメソッドで移動のリンクを生成することもできます。

### 並び順を設定する
このsimplePaginateは、基本的にはレコードを取得するgetなどの代わりとして利用するものと考えるとよいでしょう。ですから、データベースを扱う各種のメソッド(where やorderByなど)のメソッドももちろん併用することができます。

例えば、「年齢の若い順に並べ替えて表示する」という場合はどうすればいいでしょう か。

■DBクラス利用の場合 
```
$items = DB::table('customers')->orderBy('age', 'asc')
		->simplePaginate(5);
```

■モデル利用の場合 
```
$items = Customer::orderBy('age', 'asc')
		->simplePaginate(5);
```
このように、orderByを呼び出した後でsimplePaginateを呼び出せば、並び順を変更し た状態でページ分け表示することができます。  
注意したいのは、メソッドの呼び出し順です。simplePaginateは、常に一番最後に呼び出すようにします。間違えて、simplePaginate->orderByとやってしまうとエラーにな ります。

## ソート順を変更する
では、更に一歩進んで、「一覧リストの項目部分をクリックしたら、ソート順が変更される」という仕組みを考えてみましょう。例えば、「Name」のところをクリックしたら name順に、「Age」をクリックしたらage順にレコードが並び替わる、というものです。

もちろん、前後の移動のリンクをクリックすれば、指定した並び順でページ移動をします。  
これには、何らかの形でソートするフィールド名を伝えるようにしなければいけません。一番簡単なのは、クエリー文字列を使った方法でしょう。既にペジネーションでは 表示するページ番号をpage=1というようにして伝えています。これにsort=nameといった項目を追加して処理すればできそうですね。

### index アクションの修正
では、やってみましょう。まずコントローラ側の修正です。HelloControllerクラスの indexメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト3</span>HelloController.php</p>
```
public function index(Request $request)
{
   $sort = $request->sort;
   $items = Customer::orderBy($sort, 'asc')
      ->simplePaginate(5);
   $param = ['items' => $items, 'sort' => $sort];
   return view('hello.index', $param);
}

```

(コメント部分は、DBクラスを利用した場合の書き方)

ここでは、$request->sortの値を変数に取り出し、それをorderByの引数に指定しています。こうすることで、クエリー文字列としてsort=○○と渡されたフィールド名でレコードを並べ替えることができます。

### テンプレートの修正
続いて、テンプレートの修正です。「hello」内のindex.blade.phpを以下のように書き換えて下さい。

<p class="tmp list"><span>リスト4</span>hello/index.blade.php</p>
```
@extends('layouts.helloapp')
<style>
   .pagination { font-size:10pt; }
   .pagination li { display:inline-block }
   tr th a:link { color: white; }
   tr th a:visited { color: white; }
   tr th a:hover { color: white; }
   tr th a:active { color: white; }
</style>
@section('title', 'Index')

@section('menubar')
   @parent
   インデックスページ
@endsection

@section('content')
   <table>
   <tr>
       <th><a href="/hello?sort=name">name</a></th>
       <th><a href="/hello?sort=mail">mail</a></th>
       <th><a href="/hello?sort=age">age</a></th>
   </tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->name}}</td>
           <td>{{$item->mail}}</td>
           <td>{{$item->age}}</td>
       </tr>
   @endforeach
   </table>
   {{ $items->appends(['sort' => $sort])->links() }}
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```

![](pagenation_order_age.png?classes=caption "図3　レコードを表示しているテーブルの一番上にある項目名の部分をクリックすると、その項目でレコードを並べ替える。（ageをクリック）")


修正したら、/hello?sort=nameにアクセスしてみて下さい。レコードのデータがテー ブルにまとめて表示されますが、そのヘッダー部分にある「name」「mail」「age」といった ラベルをクリックすると、その項目でレコードを並べ替えます。また、下にある前後の ページ移動リンクも、設定した並べ替えの順番に従って実行されます。

### ソート用リンクの仕組み
ここでは、クリックしてレコードの並び順を変更するために、以下のような形でリンクを用意しています。
```
<a href="/hello?sort=name">name</a>
```
これは、name/順に並べ替えるリンクです。クエリー文字列に**sort=name**と指定してあります。HelloControllerのindexアクション側では、$request->sortの値を取り出して orderByしていましたから、これでname/順にソートしてレコードを取り出すことができます。

### links にパラメータを追加する
前後に移動するリンクを生成するlinksメソッドのところでは、以下のような書き方に変わっています。
```
{{ $items->appends(['sort' => $sort])->links() } }
```
ここで利用している「appends」というメソッドは、生成するリンクにパラメータを追加します。ここでは、**['sort' => $sort]**と引数に指定していますが、これにより、**sort=** ○○といったパラメータが追加された形でリンク先が設定されるようになります。

つまり、<a>タグのhrefに設定されるアドレスは、/hello?sort=&page=○○といっ た形になるわけです。これにより、表示するページ番号とソートするフィールド名をクエリー文字列でサーバーに送ることができます。
    
## paginateメソッドの利用
simplePaginateは、前後の移動を行う単純なリンクを持っていますが、ページ数が多い場合は、ページ番号のリンクも表示される「paginate」メソッドを利用することができ ます。  
HelloControllerのindexアクションメソッドを修正してみましょう。

<p class="tmp list"><span>リスト5</span>HelloController.php</p>
```
public function index(Request $request)
{
   $sort = $request->sort;
   $items = Customer::orderBy($sort, 'asc')
       ->paginate(5);
   $param = ['items' => $items, 'sort' => $sort];
   return view('hello.index', $param);
}
```

![](pagenation_link_number.png?classes=caption "図4　paginateを使うと、ページ番号のリンクが表示される。")
 

修正したら、/hello?sort=nameにアクセスしてみて下さい。今度は、前後の移動の記号の間にペー ジ番号が表示されるようになります。ページ数が多くなると、このほうが使いやすいですね。  
ここでは、simplePaginateメソッドを、ただpaginateに書き換えただけです。テンプレー ト側は一切変更はしていません。メソッドを替えるだけで、リンクまで表示が変わってしまうのですね。
    
## リンクのテンプレートを用意する
では、このページ移動のリンクをカスタマイズしたい場合はどうすればいいのでしょうか。実は、リンクを生成するlinksメソッドは、使用するテンプレートを指定すること ができます。linksの引数にテンプレート名を指定することで、そのテンプレートを利用してページ移動のリンクを生成させることができるのです。  
とはいっても、具体的にどのようにテンプレートを用意すればいいのかわからないでしょう。そこで、Laravelにデフォルトで用意されているテンプレートをファイルとして 追加し、利用できるようにしましょう。 コマンドプロンプトまたはターミナルから、以下のようにコマンドを実行して下さい。
    
<p class="tmp cmd"><span>コマンド1</span></p>
```
php artisan vendor:publish --tag=laravel-pagination
```
    
これで、「views」内に「vendor」というフォルダが作成され、更にその中に「pagination」 というフォルダが用意されます。このフォルダ内に、Laravelが利用するペジネーション用のテンプレートファイルが保存されます。  
標準では4種類のファイルが用意されています。「simple ~」で始まるものは simplePaginate用、simpleがついていないのがpaginate用です。それぞれ、defaultと bootstrap-4というものが用意されています。
    
これらのファイルをベースにして中身をカスタマイズし、linksで指定して実行すれば、カスタマイズされた表示を作成できます。
    
### simple-default.blade.phpの中身
では例として、もっとも単純なsimple-default.blade.phpテンプレートの中身がどうなっているか見てみましょう。

<p class="tmp list"><span>リスト6</span>vendor/pagenation/simple-default.blade.php</p>
```
@if ($paginator->hasPages())
   <ul class="pagination">
       {{-- Previous Page Link --}}
       @if ($paginator->onFirstPage())
           <li class="disabled"><span>
              @lang('pagination.previous')</span></li>
       @else
           <li><a href="{{ $paginator->previousPageUrl() }}"
              rel="prev">@lang('pagination.previous')</a></li>
       @endif

       {{-- Next Page Link --}}
       @if ($paginator->hasMorePages())
           <li><a href="{{ $paginator->nextPageUrl() }}" 
               rel="next">@lang('pagination.next')</a></li>
       @else
           <li class="disabled"><span>@lang('pagination.next')
               </span></li>
       @endif
   </ul>
@endif
```

$paginatorという変数にあるメソッドを多用しているのがわかります。この $paginatorは、paginateやsimplePaginateで返されたインスタンスです。変数名は違いますが（サンプルでは$items）、テンプレートに渡される際には$paginatorとして渡されるようになっています。変数名をSpaginatorに変更する必要はありません。
    
では、ここで使われているペジネーション独自のメソッドや値について整理しておきましょう。
```
$paginator->hasPages()
```
複数のページがあるかどうかをチェックします。あればtrue、なければfalseです。
```
$paginator->onFirstPage()
```
最初のページを表示しているかどうかをチェックします。最初のページならtrue、そ うでなければfalseです。
```
alang('pagination.previous')
```
国際化対応のリソースからpagination.previousという名前の値を取り出しています。
```
$paginator->hasMorePages()
```
現在のページより先にページがあればtrue、なければfalseを返します。
```
$paginator->previousPageUrl()
```
    
前のページのURLを返します。
```
alang('pagination.next')
```
国際化対応のリソースからpagination.nextという名前の値を取り出しています。
    
#### その他に用意されているメソッド
```
$paginator->currentPage());
```
現在開いているページ番号を返します。
    
```
$paginator->count();
```
ページに表示されているレコード数を返します。
    
```
$paginator->nextPageUrl()
```
次のページのURLを返します。
    
```
$paginator->url( 番号 )
```
引数に指定したページ番号のURLを返します。
    
これらを利用してテンプレートを作成していくことになります。 この他、simpleのついていないテンプレートファイルでは、「$elements」という変数も用意されています。これは、ページ番号の表示に使われるデータの配列で、配列の各 項目にはページ番号とリンクのURLが保管されています。default.blade.phpでは、この $elementsを使ってページ番号の表示を行う処理が用意されています。

## app.cssスタイルシートについて
ここまで、スタイルシートについては特に考えることなく進めてきましたが、ページ移動のリンクのデザインを考えるようになると、標準で用意されるスタイルシートにつ いても触れておかなければいけないでしょう。
    
Laravelでは、標準で/css/app.cssというスタイルシートが用意されています。これを利用することで、ある程度デザインされた表示を作ることができます。
ページのデザインを担当しているhelloapp.blade.phpの&lt;head&gt;部分に、以下のようにタグを追記してみて下さい。

<p class="tmp list"><span>リスト7</span>layouts/helloapp.blade.php</p>
```
<link rel="stylesheet" type="text/css" href="/css/app.css">
```
そして/hello?sort=nameにアクセスをすると、ページ移動のリンクがきれいにデザインされて表示されます。

![](pagenation_app.png?classes=caption "図4　app.cssを利用すると、ページ移動もきれいにデザインされる。")

app.cssは、「Bootstrap」というページデザインのためのライブラリのスタイルシートを内包しており、このBootstrapを利用したデザインがしやすいようになっています。




