<?php require '../header.php'; ?>
<?php
echo 'ようこそ、', $_REQUEST['user'], 'さん。';
?>
<?php require '../footer.php'; ?>
