<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>検索2</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <form action="search-output2.php" method="post">
        <label for="name">商品名</label>
        <input id="name" type="text" name="name">
        <label for="local">生産地</label>
        <input id="local" type="text" name="local">
        <input type="submit" value="検索">
    </form>
</body>
</html>