*[page-title]:関数・メソッド

