<?php require '../header.php'; ?>
<form action="check-output.php" method="post">
<p><input type="checkbox" name="mail">お買い得情報のメールを受け取る</p>
<p><input type="submit" value="確定"></p>
</form>
<?php require '../footer.php'; ?>
