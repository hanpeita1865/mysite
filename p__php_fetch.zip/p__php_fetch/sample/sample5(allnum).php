<?php

try {

  $pdo = new PDO('sqlite:db/fetch_db.sqlite3');

  $stmt = $pdo->prepare('SELECT * FROM users WHERE age >= 40');
  $stmt->execute();
  $result = $stmt->fetchAll(PDO::FETCH_NUM);

  print_r('<pre>');
  print_r($result);
  print_r('</pre>');
  
} catch (Exception $e) {
    error_log('障害が発生しており、ご迷惑をおかけしています。');
}

?>