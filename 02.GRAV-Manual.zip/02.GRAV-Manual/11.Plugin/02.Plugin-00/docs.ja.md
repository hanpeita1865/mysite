---
title: Breadcrumbs（パンくずリスト）
media_order: 'breadcrumbs1.png,bread_icon3.png'
taxonomy:
    category:
        - docs
visible: true
---

 <i class="fa fa-check-square text-primary"></i>（テンプレート設定済み）

ページにパンくずリストを表示することができるプラグインです。

Breadcrumbsの設定ページの **Icon Home**　に　**fa fa-home**　を入れれば<i class="fa fa-home"></i>のアイコンをつけられます。  
**breadcrumbs.yaml**でも設定できます。
 
### 管理画面
 
![](breadcrumbs1.png)
 

### breadcrumbs.yaml ### {.mb-0} 
<div>（user > plugins > breadcrumbs > breadcrumbs.yaml）</div>
 
    enabled: true
    show_all: true
    built_in_css: true
    include_home: true
    include_current: true
    icon_home: 'fa fa-home'
    icon_divider_classes: 'fa fa-angle-right'
    link_trailing: false
 
 
### サイト表示
 
 ![](bread_icon3.png)
 
