<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MenuService,
    MarkdownService,
};


require '../admin/basepath.php';

class EditController
{
    private EditService $editService;
    private FolderService $folderService;
    private MenuService $menuService;
    private MarkdownService $markdownService;
    private $container;


    public function __construct(EditService $editService, FolderService $folderService, MenuService $menuService, MarkdownService $markdownService, ContainerInterface $container)
    {
        $this->container = $container;
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->menuService = $menuService;
        $this->markdownService = $markdownService;
    }
    
    
    //マークダウン変換
    public function markData(Request $request, Response $response, array $args): Response
    {
        $config = $this->container->get('config');
        $basePath = $config['basePath'];
        $siteName = $config['siteName'];
        
        $flag = $request->getAttribute('flag');
        $motourl = $request->getAttribute('moto');
        $countIp = $request->getAttribute('countIp');
        

        try {
 
            $db = $this->editService->db(); //dbサービス

            $path = rtrim($request->getUri()->getPath(), '/');
            $folderName = basename($path);

            $folderObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）

            $searchMenu = $this->menuService->buildSearchMenu();//サービス（検索カテゴリーリスト取得）
            
            $json_searchMenu = json_encode($searchMenu, JSON_UNESCAPED_UNICODE);
            file_put_contents('../common/search/search_menu.json', $json_searchMenu);
                      
            $this->menuService->setCountIp($countIp);
            $this->menuService->loadLockData($db, $folderObj);//サービス（$lockData、$lockArrayの値をプロパティ設定）
            $menuData = $this->menuService->buildMenu('../pages', $folderName);//サービス（メニュー生成）

            $markData = $this->markdownService->getMarkdownData($folderObj, $folderName);//サービス（マークダウン変換済み）

            $htmlData = $markData['html'];
            $title = $markData['title'];
            
            $text = strip_tags($htmlData);//テスト
            $text = preg_replace('/\s+/u', '', $text);//テスト
            
            //テスト
            $titlePathObj = $this->folderService->getTitlePathList();
            
            if($flag==0){
                $htmlData = '<p>閲覧できないページです。</p>';
            }
            
            $assign["menuData"] = $menuData;
            $assign["folderObj"] = $folderObj;
            $assign["htmlData"] = $htmlData;
            $assign["title"] = $title;
            $assign["titlePathObj"] = $titlePathObj;//テスト
            $templatePath = "base.twig";
        }

        catch (PDOException $ex) {
            $assign["errorMsg"] = "データベース処理に失敗しました。もう一度始めからやり直してください。";
            $templatePath = "error.twig";
        }       

        $assign["countIp"] = $countIp;
        $assign["pathBase"] = $basePath;
        $assign["siteName"] = $siteName;

        $twig = $this->editService->view();
        
        $response = $twig->render($response, $templatePath, $assign);

        return $response;
    }



    //編集画面
    public function editData(Request $request, Response $response, array $args): Response
    {
        // $basePath = $this->container->get('basePath');
        $config = $this->container->get('config');
        $basePath = $config['basePath'];      
        
        $ipAddress = $_SERVER["REMOTE_ADDR"]; //取得したIPアドレス
        $folderName = basename($_SERVER['REQUEST_URI']); //フォルダ名

        //PDOインスタンスをコンテナから取得
        // $db = $this->container->get("db");
        $db = $this->editService->db(); //dbサービス
        $sql_ip = $db->prepare('select * from admin_ip where ip_address=?');
        $sql_ip->execute([$ipAddress]);

        $countIp = $sql_ip->rowCount();

        try {
            //例外判定
            if ($countIp == 0) {
                throw new Exception('管理者以外は編集できません');
            } else {

                $folderName = basename($_SERVER['REQUEST_URI']); //フォルダ名
                $this->container->set('folderName', $folderName);

                $folderObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）
                $folderDir = $folderObj[$_REQUEST['folder']];
                

                if (empty($_SERVER['HTTP_REFERER'])) {
                    //echo '未定義';
                    $motourl = '../p__base/'; //修正予定
                } else {
                    $motourl = $_SERVER['HTTP_REFERER']; //遷移元のURL
                }

                $mkData = file_get_contents($folderDir . '/markdown.md');
                // $mkData = htmlspecialchars($mkData, ENT_QUOTES);

                $twig = $this->editService->view();//viewサービス
                
                $filelist = $this->folderService->fileIcon();//サービス

                $assign["pathBase"] = $basePath;
                $assign["mkData"] = $mkData;
                $assign["edit"] = $_REQUEST['edit'];
                $assign["folder"] = $_REQUEST['folder'];
                $assign["folderPath"] = $_REQUEST['folderPath'];
                $assign["scroll"] = $_REQUEST['scroll'];
                $assign["motourl"] = $motourl;
                $assign["fileList"] = $filelist;
                $assign["folderDir"] = $folderDir;

                $response = $twig->render($response, "edit.twig", $assign);

                return $response;
            }
        } catch (Exception $ex) {
            echo $ex->getMessage();
            // header('Location:'. $motourl); //遷移元かトップに戻る
            exit;
        }

        return $response;
    }



    //編集保存
    public function markdownUpload(Request $request, Response $response, array $args): Response
    {
        file_put_contents($_POST['folderDir'].'/markdown.md', $_POST['report']);//mdファイル保存

        return $response;
    }




    //ファイル保存
    public function fileSave(Request $request, Response $response, array $args): Response
    {
        $uploadedFiles = $request->getUploadedFiles();
        $parsedBody = $request->getParsedBody();
        $folderDir = rtrim($parsedBody['folderDir'] ?? '', '/');

        // ファイルがアップロードされていない場合
        if (empty($uploadedFiles['hoge'])) {
            return $response->withStatus(400)->write('No file uploaded');
        }

        $file = $uploadedFiles['hoge'];
        $uploadDir = $folderDir . '/' . 'upload';

        // アップロードフォルダがなければ作成
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // 保存先ファイル名
        $filePath = $uploadDir . '/' . basename($file->getClientFilename());
        $file->moveTo($filePath);

        // ファイル一覧を更新日順で取得
        $files = glob($uploadDir . '/*');
        usort($files, fn($a, $b) => filemtime($a) - filemtime($b));

        $thmbSrc = str_replace('../../', '../', $folderDir); // サムネイルパス調整

        // ファイルアイコン分類表
        $fileTypes = [
            'excel' => ['xlsx', 'xls', 'xlsm', 'xlsb', 'xltx', 'xltm', 'xlt', 'xml', 'xlam', 'xla', 'xlw', 'xlr'],
            'text'  => ['txt'],
            'word'  => ['doc', 'docm', 'docx', 'dot', 'dotx'],
            'ppt'   => ['pptx'],
            'zip'   => ['zip'],
            'pdf'   => ['pdf'],
            'image' => ['png', 'jpg', 'jpeg', 'gif', 'svg', 'svgz', 'webp']
        ];

        $html = '';
        foreach ($files as $item) {
            $fileName = basename($item);
            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $type = $this->detectFileType($ext, $fileTypes);

            if ($type === 'image') {
                $html .= <<<HTML
                <li class="photo-list">
                    <span class="filename">{$fileName}</span>
                    <img src="{$thmbSrc}/upload/{$fileName}" alt="">
                    <button class="fileDelete">削除</button>
                    <button class="fileInsert">挿入</button>
                </li>
                HTML;
            } else {
                $html .= <<<HTML
                <li>
                    <span class="filename file_icon {$type}-icon">{$fileName}</span>
                    <button class="fileDelete">削除</button>
                    <button class="fileInsert">挿入</button>
                </li>
                HTML;
            }
        }

        $response->getBody()->write($html);
        return $response;
    }

    /**
     * 拡張子からファイル種別を判定する
     */
    private function detectFileType(string $ext, array $map): string
    {
        foreach ($map as $type => $exts) {
            if (in_array($ext, $exts, true)) {
                return $type;
            }
        }
        return 'other';
    }

    

    
    //ファイル削除
    public function fileDelete(Request $request, Response $response, array $args): Response
    {
        $parsedBody = $request->getParsedBody();
        $folderDir = rtrim($parsedBody['folderDir'] ?? '', '/');
        $fileName  = basename($parsedBody['item'] ?? '');

        if (empty($folderDir) || empty($fileName)) {
            return $response->withStatus(400)->write('Missing parameters');
        }

        // 削除対象ファイルのパスを作成
        $uploadDir = $folderDir . '/upload';
        $filePath = $uploadDir . '/' . $fileName;

        // ファイルが存在しなければエラー
        if (!file_exists($filePath)) {
            return $response->withStatus(404)->write('File not found');
        }

        // ファイル削除
        if (!unlink($filePath)) {
            return $response->withStatus(500)->write('Failed to delete file');
        }

        // 残りのファイル一覧を取得
        $files = glob($uploadDir . '/*');
        usort($files, fn($a, $b) => filemtime($a) - filemtime($b));

        $thmbSrc = str_replace('../../', '../', $folderDir); // サムネイルパス調整

        // ファイルアイコン分類表（fileSaveと共通）
        $fileTypes = [
            'excel' => ['xlsx', 'xls', 'xlsm', 'xlsb', 'xltx', 'xltm', 'xlt', 'xml', 'xlam', 'xla', 'xlw', 'xlr'],
            'text'  => ['txt'],
            'word'  => ['doc', 'docm', 'docx', 'dot', 'dotx'],
            'ppt'   => ['pptx'],
            'zip'   => ['zip'],
            'pdf'   => ['pdf'],
            'image' => ['png', 'jpg', 'jpeg', 'gif', 'svg', 'svgz', 'webp']
        ];

        // ファイル情報をJSON用に整形
        $fileList = [];
        foreach ($files as $item) {
            $name = basename($item);
            $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $type = $this->detectFileType($ext, $fileTypes);

            $fileList[] = [
                'name' => $name,
                'type' => $type,
                'url'  => $thmbSrc . '/upload/' . $name,
                'mtime' => date('Y-m-d H:i:s', filemtime($item))
            ];
        }

        // JSONとして返す（fileSaveと統一）
        $response->getBody()->write(json_encode([
            'message' => 'File deleted successfully',
            'files' => $fileList
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        return $response->withHeader('Content-Type', 'application/json');
    }


    public function save(Request $request, Response $response): Response {
        $data = (array)$request->getParsedBody();

        $result = $this->editService->save($data);

        $response->getBody()->write(
            $result ? "保存しました" : "保存失敗"
        );

        return $response;
    }
    

    public function helloWithContainer(Request $request, Response $response, array $args): Response
    {
        $db = $this->editService->db(); 
               
        $config = $this->container->get('config');
        $basePath = $config['basePath'];
        $siteName = $config['siteName'];
        
        $assign["name"] = "コンテーナ";
        $twig = $this->editService->view(); //viewサービス
        
        $response = $twig->render($response, "helloWithVals.html", $assign);
        return $response;
    }
    
    
    //テスト
    public function folderObjGet(Request $request, Response $response, array $args): Response
    {
        $folderObj = $this->folderService->getFolderComp();

        $payload = json_encode($folderObj, JSON_UNESCAPED_UNICODE);
        $response->getBody()->write($payload);
        return $response
            ->withHeader('Content-Type', 'application/json');
    }
    
    //テスト
    public function titlePathObjGet(Request $request, Response $response, array $args): Response
    {
        $titlePathObj = $this->folderService->getTitlePathList();

        $payload = json_encode($titlePathObj, JSON_UNESCAPED_UNICODE);
        $response->getBody()->write($payload);
        return $response
            ->withHeader('Content-Type', 'application/json');
    }
}
