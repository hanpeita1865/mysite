---
title: 07.辞書
taxonomy:
    category:
        - docs
visible: true
---

リスト、タプル、集合と同様にデータ構造の一つです。複数のデータをまとめる機能があるのは他のデータ構造と同じですが、次のような特徴があります。

<h3 class="h-type3">特徴</h3>

+ 格納する要素はキーと値のペアである
+ 重複したキーは持たない
+ 要素の順序は指定できない
+ インデクスやスライスは使用できない

<p class="tmp"><span>書式1</span>辞書の作成</p>
<pre>
{キー:値, キー:値, …}
</pre>

<p class="tmp"><span>書式2</span>辞書の代入</p>
<pre>
変数 = {キー:値, キー:値, …}
</pre>

<div class="box-example">
    <h3 class="h-example">例1</h3>
ピザ店のトッピングを管理するプログラムを作ってみます。トッピングの名前と価格をペアにして、辞書に格納します。<br>
次の表のようなトッピングの名前と価格を辞書に登録し、変数toppingに代入します。<br>キーは名前（文字列）、値は価格（数値）です。
    
<table class="w-400">
    <caption>変数toppingに代入する要素</caption>
    <thead>
        <tr>
            <th class="text-center">名前</th>
            <th class="text-center">価格（円）</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="text-center">bacon</td>
            <td class="text-center">210</td>
        </tr>
        <tr>
            <td class="text-center">mushroom</td>
            <td class="text-center">140</td>
        </tr>
        <tr>
            <td class="text-center">onion</td>
            <td class="text-center">100</td>
        </tr>
        <tr>
            <td class="text-center">tomato</td>
            <td class="text-center">130</td>
        </tr>
    </tbody>     
</table>
</div>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> topping = {'bacon':210, 'mushroom':140, 'onion':100, 'tomato':130}
>>> topping
{'bacon': 210, 'mushroom': 140, 'onion': 100, 'tomato': 130}
</pre>

※Pythonの文字列がイミュータブル（要素の追加、変更および削除不能）であることは、辞書のキーとして使う上で好都合です。実際よくキーとして使われます。

<p class="tmp"><span>書式3</span>辞書の要素の取得</p>
<pre>
辞書[キー]
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> topping['mushroom']
140
</pre>


for文を辞書に適用すると、すべてのキーを一つずつ取り出すことができます。

<p class="tmp"><span>書式4</span>for文によるキーの取得</p>
<pre>
for 変数 in 辞書
    処理
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> for key in topping:
...     print(key)
...
bacon
mushroom
onion
tomato
</pre>

すべてのキーと値のペアを取り出す場合は、辞書のitemメソッドを使います。

<p class="tmp"><span>書式5</span>キーと値の取得</p>
<pre>
for 変数A, 変数B in 辞書.items();
    処理
</pre>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> for key, value in topping.items():
...     print(key, value)
...
bacon 210
mushroom 140
onion 100
tomato 130
</pre>

<p class="tmp"><span>書式6</span>要素の追加または変更</p>
<pre>
辞書[キー] = 値
</pre>

<p class="inpre"><span>インタプリタ</span>要素の追加</p>
<pre>
>>> topping['cheese'] = 160
>>> topping
{'bacon': 210, 'mushroom': 140, 'onion': 100, 'tomato': 130, <span class="bold">'cheese': 160</span>}
</pre>

<p class="inpre"><span>インタプリタ</span>要素の変更</p>
<pre>
>>> topping['tomato'] = 200
>>> topping
{'bacon': 210, 'mushroom': 140, 'onion': 100, 'tomato': <span class="bold">200</span>, 'cheese': 160}
</pre>

<p class="tmp"><span>書式7</span>要素の削除</p>
<pre>
del 辞書[キー]
</pre>

<p class="inpre"><span>インタプリタ</span>要素の削除</p>
<pre>
>>> del topping['bacon']
>>> topping
{'mushroom': 140, 'onion': 100, 'tomato': 200, 'cheese': 160}<span class="comment">  # 「'bacon': 210」 が削除されている。</span>
</pre>

<h3 class="h-type3">可変長引数と辞書</h3>

可変長引数というのは、<span class="bold red">個数を変更することができる引数</span>のことです。位置引数の可変長引数をタプルとして受け取る方法はすでに学びました。<br>
ここでは、キーワード引数の可変長引数を辞書として受け取る方法を説明します。

<p class="tmp"><span>書式8</span>キーワード引数の可変長引数</p>
<pre>
def 関数名(<span class="red">**</span>引数):
    処理
</pre>

<div class="box-example">
    <h3 class="h-example">例2</h3>
キーワード引数を可変長引数で受け取る関数を定義します。<br>
定義したtest関数を下記の引数で呼び出してみます。<br>
①test(a=4, b=5)<br>
②test(a=4, b=5, c=6) <br>  
</div>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> def test(<span class="red">**</span>x):
...    print(x)
...
>>> test(a=4, b=5)
{'a': 4, 'b': 5}
>>> test(a=4, b=5, c=6)
{'a': 4, 'b': 5, 'c': 6}
</pre>

<div class="box-example">
    <h3 class="h-example">例3</h3>
	位置引数の可変長引数と、キーワード引数の可変長引数を併用してみます。
</div>

<p class="inpre"><span>インタプリタ</span></p>
<pre>
>>> def test2(<span class="red">*</span>x, <span class="red">**</span>y):
...     print(x)
...     print(y)
...
>>> test2(1, 2, 3)<span class="comment">  # 位置引数だけを渡す場合</span>
(1, 2, 3)
{}
>>> test2(a=4, b=5, c=6)<span class="comment">  # キーワード引数だけを渡す場合</span>
()
{'a': 4, 'b': 5, 'c': 6}
>>> test2(1, 2, 3, a=4, b=5, c=6)<span class="comment">  # 位置引数とキーワード引数の両方を渡す場合</span>
(1, 2, 3)
{'a': 4, 'b': 5, 'c': 6}
</pre>








