---
title: テンプレートからGRAVを設置
media_order: 'btn_ediit.png,skeleton_learn.png,daichi_yaml.png,logout.png,login.png,account_click.png,account_youser.png'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    .dl-side dt {float: left;}
    .dl-side dd {margin-left: 6.5rem;}
</style>

**{c:red}XAMPPがインストールされてることが必須になります。{/c}**

GRAVを公式サイトからダウンロードして使いたい方は、下記のリンクのページに移動してください。

[最初からGRAV本体を設置する](../grav_core)

すぐに使ってみたい方は下記のテンプレートダウンロードリンクからダウンロードしてください。  
（ファイルは勉強会で使用しているテンプレートと同じです。プラグインもいくつか追加しています。）

<a href="/grav-manual/grav-manual/start/grav-admin.zip" download="grav-admin.zip">テンプレートダウンロード</a>（zipファイル 15.56MB）


ダウンロードが済んだらファイルを解凍して　**C: / XAMPP / htdocsフォルダ** に設置してください。  


このテンプレートファイルは、赤枠で囲んでいるテーマが **learn2-with-git-sync-site** の**skeleton**のファイルをダウンロードし、こちらで使いやすいように設定したものです。

![](skeleton_learn.png?cropResize=400,400)

それでは設置したサイトをローカルで表示してみます。  
**http://localhost/grav-admin/**

他の人も見れるようにするには、localhostの箇所を自身のIPアドレスに変えてください。  
**http://IPアドレス/grav-admin/**

XAMPPでポート番号を設定してる場合は、IPアドレスのあとにポート番号をつけてください。  
**http://IPアドレス:ポート番号/grav-admin/**

表示できることが確認できましたら、管理画面を開いてみます。  
サイドメニューの下の方にある ![](btn_ediit.png?classes=d-inline,my-0) のボタンをクリックしてください。  
または、トップページにもどって、URL（http:// ～～ /grav-admin/）の後ろに**admin**と記述しENTERキーを押しても、管理画面を開くことが出来ます。

## アカウントの設定

テンプレートの初期アカウントは下記のように設定しています。

**{c:blue}初期アカウント（daici.yaml）{/c}**

<div class="dl-side" markdown="1">
ユーザー名
: daichi

パスワード
: Daichi1010

E-mail
: daichi@test.ne.jp

Fullname
: daichi

タイトル
: template
</div>

このままでも使用できますが、アカウントを変更する場合は、step1～step4の処理を行ってください。

{c:red}step1.{/c}
: user > accounts　にある**daichi.yaml**をコピペして、ファイル名を変更します。  
	（例えば、ファイル名をnttdata.yamlにすると、ユーザー名がnttdataになります。）
    ![](daichi_yaml.png?classes=d-inline,mb-0)
    
{c:green}step2.{/c}
: 管理画面ををログアウトして、再度ログインします。その時、ユーザ名を**追加したファイル名**でログインします。  
	ここではまだ初期アカウントのパスワード（**Daichi1010**）を入力してください。
    
<div class="d-flex justify-content-between" markdown="1">
<div markdown="1">
#### ログアウト #### 
![](logout.png)
</div>
<div markdown="1">
#### 再度ログイン #### 
![](login.png?cropResize=350,350)
</div>
</div>
    
{c:blue}step3.{/c}
: ログインしましたら、管理画面の左上のロゴ、ユーザー名、タイトルがある箇所をクリックし、アカウント設定画面を開きます。

![](account_click.png?cropResize=400,400&classes=d-inline)

{c:brown}step4.{/c}
: アカウント設定画面の赤枠のユーザー名は、追加したファイル名に変わっているのが確認できると思います。 （画像では初期値のままにしています） 
その他の緑の枠のパスワード、E-mail、フルネーム、タイトルを好みに変更して、右上の保存ボタンを押してください。    
ただし、パスワードは、少なくとも**1つの数字**、**小文字**、**大文字**を含む**8文字以上**で設定する必要があります。
![](account_youser.png?cropResize=600,600)

{c:darkslategray}step5.{/c}
: user > accounts　にある初期設定用のdaichi.yamlを削除してください。これでアカウントの再設定は完了です。

{c:purple}step6.{/c}
: 管理画面左下のログアウトのボタンをクリックし、再度ログインします。
	再設定したアカウントのユーザー名（またはEmail）とパスワードで入れたら再設定は成功です。















