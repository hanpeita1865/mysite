*[page-title]:配列の最初、最後、何番目の値を取得

参考サイト
: [PHPで配列の最後の値を取得する](https://qiita.com/rana_kualu/items/e780778413dba6eed422)
: [【PHP】array_key_last()で配列や連想配列の最後のキーを取得する！](https://sossy-blog.com/useful/5196/)
: [PHP マニュアル array_key_first](https://www.php.net/manual/ja/function.array-key-first.php)
: [PHP マニュアル array_key_last](https://www.php.net/manual/ja/function.array-key-last.php)

## 配列の最後を取得する

### end()
配列の内部ポインタを最終要素にセットする

<p class="tmp"><span>書式</span>end()</p>
```
end($array); 
```
<span class="red">※上記の「end()」は推奨しないとPHPマニュアルには書かれていました。なので次の「array_key_last」を使う方がいいかもしれません。</span>

### array_key_last()

与えられた array の最後のキーを返します。これは内部的な配列のポインタに影響を与えません。  
指定した配列の要素の最後のキーを取得する関数になります。（これは内部的な配列のポインタに影響を与えません??）

例えば、「[‘A’,’B’,’C’]」という配列にarray_key_last()を使用すると「2」が表示されるように、「最後のキー」を返り値として返すようになります。  
配列が空でなければ、 array の最後のキーを返します。 そうでなければ、null を返します。

そして、array_key_last()は連想配列の最後のキーを取得することができたり、2次元配列や3次元配列のような多次元配列の最後のキーを取得することができたりします。

<p class="tmp"><span>書式</span>array_key_last()</p>
```
array_key_last('最後のキーを取得したい配列')
```

#### 配列の最後のキーを取得する

<div class="exp">
	<p class="tmp"><span>例1-1</span></p>
	最後のキーと値を取得しています。
<iframe src="https://paiza.io/projects/e/TRZ8fqKW7_fp6xyCwafpbA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

#### 連想配列の最後のキーを取得する

<div class="exp">
	<p class="tmp"><span>例1-2</span></p>
	上記と同じく、最後のキーと値を取得しています。
<iframe src="https://paiza.io/projects/e/3cl-hA-ZqH1VMPCWLBI0kA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

#### 2次元配列の最後のキーを取得する

array_key_last()によって、2次元配列の中にある最後のキーを取得することができます。  
そして、2次元配列の中にある1次元配列の最後のキーを取得することができます。

<div class="exp">
	<p class="tmp"><span>例1-3</span></p>
	<iframe src="https://paiza.io/projects/e/ippaGlwBVIB76nXY5B3jAw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

## 配列の最初を取得する

配列の最初のキーを取得する場合は、<span class="green bold">array_key_first()</span>を使用します。  
array_key_first()とは、指定した配列の最初のキーを取得することができる関数となります。

※最初のキーは 0になるので、あまり使うことはない気はします。

<div class="exp">
	<p class="tmp"><span>例2-1</span></p>
	<iframe src="https://paiza.io/projects/e/K-k6dZo4x6NQ8tYifhhE7Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

## 配列の全てのキーを取得する

配列の全てのキーを取得する場合は、<span class="green bold">array_keys()</span>を使用します。

<div class="exp">
	<p class="tmp"><span>例3-1</span></p>
	<iframe src="https://paiza.io/projects/e/mmgChyWCd45GgVgs-jGtGg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


## 配列の最後から何番目の値を取得する
参考サイト
: [２次元配列の最後から○番目の要素を取り出す](https://teratail.com/questions/304002)

<div class="exp">
	<p class="tmp"><span>例4-1</span></p>
	関数を使って、後ろから2番目の値を取得しています。
<iframe src="https://paiza.io/projects/e/RI4AfnmbeEo2HQWoN0MFFg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>	
</div>
