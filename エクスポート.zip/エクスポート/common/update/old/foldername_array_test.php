<?php
require '../../admin/basepath.php';//$basePath ='/from_now_slim'

$folderArray = [];
globAll('../../pages');

function globAll($folder) {
    global $folderArray;
    global $basePath;

    $res = glob($folder . '/*'); 

    foreach ($res as $key => $f) {
        $dirArray = explode('/', $f);
        $lastDir = end($dirArray); //配列の最後の値

        //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
        if (preg_match('/^\d{3}./', $lastDir)) {
            // echo '<li>'.$lastDir.'</li>';
            list($num, $folderName) = explode(".", $lastDir);
            $f1 = str_replace('../..' , $basePath, $f);
            $folderArray[$folderName] = $f1;
            globAll($f);
        }
    }
}
// print_r($folderArray);
?>
