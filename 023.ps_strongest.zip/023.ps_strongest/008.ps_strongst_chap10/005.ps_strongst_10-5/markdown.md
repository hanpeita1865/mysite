*[page-title]:10-5. 顔を整形してみよう

## 顔立ちを調整する ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-05.jpg)](upload/10-05.jpg){.image}
</div>

