*[page-title]:Livewireによるフロントエンド


## Livewireとは?

Laravelでは、動的なUIをPHPだけで実現できる「<span class="bold green">Livewire</span>」というフレームワークを利用できます。  
Livewireは、Bladeテンプレートのシンプルさを保ちつつ、AJAXによる部分更新や双方向データバインディングを可能にし、<span class="marker-yellow50">**JavaScriptなしでリアクティブなWeb開発**</span>が行えます。

### Livewireの特徴

LivewireはLaravel専用のフレームワークで、PHPだけで動的なUIを実現できます。特徴は以下の通りです。  

* <span class="green">シンプル</span>
: JavaScript不要で、PHPだけで実装可能。

* <span class="green">リアクティブ</span>
: AJAXにより、必要な部分だけを自動で更新。

* <span class="green">双方向バインディング</span>
: フォームとデータが即時に同期。

* <span class="green">Laravelと統合</span>
: Bladeやルーティングなどとスムーズに連携可能。

これにより、従来のフロントエンドフレームワークを使わずに、直感的なUIを構築できます。


## Livewireプロジェクトの作成

Livewireを使ったLaravelアプリの開発方法には、<span class="bold red">新規プロジェクト作成</span>と<span class="bold red">既存プロジェクトへの導入</span>の2通りがあります。

### プロジェクト新規作成の場合

まずは新規作成の場合、Herdの「Quick Access」から「Open Sites」を開き、「Add」ボタンをクリックしてプロジェクトを追加します。  
その後、「Create New Site」画面で「New Laravel project」を選べば次に進み、スターターキットの選択画面になります。  
ここで「Livewire」を選んで次に進んでください。
![](upload/Livewire選択.png){.photo-border}

記入して次に進めば、プロジェクトが作成されます。
![](upload/Livewire_create_new_site.png){.photo-border}

### 既存プロジェクトにLivewireをインストールする場合

既存のLaravelプロジェクトにLivewireを追加するには、VSCodeでプロジェクトを開き、ターミナルで以下のコマンドを実行します。これにより、Livewireに必要なファイルが自動でプロジェクトに追加されます。
<p class="tmp cmd"><span>コマンド</span>Livewireインストール</p>
```
composer require livewire/livewire
```
![](upload/Livewireインストール.png)


##  Livewireコンポーネントを作る

作業環境
: C:\xampp\htdocs\livewireapp
: http://livewireapp.test/

Livewireの基本機能を体験するために、まずはサンプルを作成します。  
新しく作成した「livewireapp」プロジェクトをVSCodeで開いて準備しましょう。  
次に、ターミナルでLivewireコンポーネント作成コマンドを実行します。これでLivewireの使用準備が整います。

```
php artisan make:livewire HelloComponent
```
![](upload/livewire_Hello.png)

これで「HelloComponent」というLivewireコンポーネントが作成されます。

Livewireコンポーネントは、以下のようなコマンドで作ります。
<p class="tmp cmd"><span>コマンド</span>Livewireコンポーネント作成</p>
```
php artisan make:livewire コンポーネント名
```

このコマンドで、以下の2つのファイルが作成されます。
* app/Livewire/HelloComponent.php
* resources/views/livewire/hello-component.blade.php

<div markdown="1" class="d-flex">
![](upload/HelloComponentディレクトリ.png "図　HelloComponent.php"){.capside-top}
![](upload/hello-component_bladeディレクトリ.png "図　hello-component.blade.php"){.capside-top}
</div>

Livewireコンポーネントは、コード部分を「app/Livewire」に、表示テンプレートを「resources/views/livewire」に配置します。これが基本の構成です。


### コンポーネントのルート割り当て

Livewireコンポーネントを使うには、「routes/web.php」にルート設定を追記する必要があります。

<p class="tmp list"><span>リスト4-1</span>routes/web.php</p>
```
// use App\Livewire\HelloComponent; 追加

Route::get('/hello-component', HelloComponent::class);
```
HelloComponentを /hello-component に割り当てるには、通常のルート設定と同様に Route::get で指定するだけです。コントローラーと同じ書き方で使えます。


## Livewireコンポーネントクラス

Livewireコンポーネントの基本構成は以下のとおりです。

* クラスは App\Livewire に配置し、Livewire\Component を継承します。
* render() メソッドを定義し、view() 関数でテンプレートを返します。
* テンプレートは resources/views/livewire に置かれ、view('livewire.ファイル名') で指定します。

<p class="tmp list"><span>リスト4-2</span>app/Livewire/HelloComponent.php（デフォルト）</p>
```
<?php
namespace App\Livewire;

use Livewire\Component;

class HelloComponent extends Component
{
  public function render()
  {
    return view('livewire.hello-component');
  }
}
```

## Livewireコンポーネントのテンプレート

Livewireのテンプレートは hello-component.blade.php に記述されます。  
初期状態ではコメントが入っていますが、それを `<div>This is Livewire component !!</div>` に書き換えることで、メッセージを表示できます。  
シンプルな表示内容で、最初のサンプルとして適しています。

<p class="tmp list"><span>リスト4-3</span>resources/views/livewire/hello-component.blade.php</p>
```
<div>
  {{-- TheWhole word belongs to you. --}}
</div>
```

<p class="tmp list"><span>リスト4-4</span>resources/views/livewire/hello-component.blade.php</p>
```
<div>
  This is Livewire component!!
</div>
```

## Livewire コンポーネントを組み込む

作成したLivewireコンポーネントとHelloControllerの両方が使える状態にしておくことで、「laravelapp」または「livewireapp」のどちらでも作業を進められるようになります。使用するプロジェクトに応じて、必要な準備（コンポーネントやルート、テンプレートの設定など）を行ってください。

今度は、「laravel_3rdherdプロジェクト」にlivewireのコンポーネントを組み込んでみます。
![](upload/3rdwire_livewire.png)

作業環境
: C:\xampp\htdocs\laravel_3rdherd

indexxメソッドを修正。
<p class="tmp list"><span>リスト4-5</span>HelloController.php</p>
```
public function index()
{
  return view('hello.index');
}
```

<p class="tmp list"><span>リスト4-6</span>hello/index.blade.php</p>
```
@section('content')
  <p>Livewireコンポーネントの表示</p>
  @livewire('hello-component')
@endsection
```



HelloControllerのindexメソッドを修正してテンプレートhello.indexを表示するようにし、テンプレートindex.blade.phpでは@livewire('hello-component')を使ってLivewireコンポーネントを読み込むようにします。

これにより、ブラウザで<http://laravel_3rdherd.test/hello>にアクセスすると、Livewireコンポーネントのメッセージが表示されます。
![](upload/Livewireコンポーネントの表示.png){.photo-border}

### Livewire ディレクティブについて

Livewireコンポーネントは、`@livewire('コンポーネント名')`ディレクティブでテンプレートに埋め込めます。 
```mk
@livewire('hello-component')
```
クラス指定で、`@livewire(HelloComponent::class)`と書くことも可能で、どちらの書き方でも動作は同じです。使いやすい方法を選べば問題ありません。

### タグを使った埋込み

Livewireコンポーネントは、`<livewire:コンポーネント名 />`タグでも埋め込めます。  
```
<livewire:hello-component />
```
クラスは使わず、コンポーネント名を指定するだけで、@livewireディレクティブと同様に動作します。どちらの方法を使っても構いません。


## コンポーネントの値を表示する

Livewireコンポーネントでテンプレートに値を渡すには、クラス内にpublicなプロパティを定義します。  
今回は$messageプロパティを追加し、これをテンプレートで表示できるようにします。

<p class="tmp list"><span>リスト4-7</span>app/Livewire/HelloComponent.php</p>
```
class HelloComponent extends Component
{
  public $message = 'Hello, Livewire!';
 
  // コンポーネントのレンダリング処理
  public function render()
  {
    return view('livewire.hello-component');
  }
}
```

### テンプレートを修正する

<p class="tmp list"><span>リスト4-8</span>views/livewire/hello-component.blade.php</p>
```
<div>
  This is Livewire component!!
  <ul><li>{{ $message }}</li></ul>
</div>
```

Livewireでは、コンポーネントクラスのpublicプロパティはテンプレート内で`{{$message}}`のように簡単に表示できます。  
コントローラーのようにviewに値を渡す手間は不要で、直接アクセス可能です。今回も$messageをそのまま埋め込むだけで表示されます。
![](upload/Hello_Livewire.png){.photo-border}


## レンダリング時に値を渡す

Livewireでも、renderメソッド内でview()に引数を渡すことでテンプレートに値を渡せます。  
例えば['msg' => 'レンダリングで値を渡します。']のように記述すれば、テンプレート内で{{$msg}}として表示できます。コントローラーと同様の方法が使えるというわけです。

<p class="tmp list"><span>リスト4-9</span>app/Livewire/HelloComponent.php</p>
```
public function render()
{
  $ob = ['msg'=>'レンダリングで値を渡します。'];
  return view('livewire.hello-component', $ob);
}
```

<p class="tmp list"><span>リスト4-10</span>views/livewire/hello-component.blade.php</p>
```
<div>
  This is Livewire component!!
  <ul>
    <li>{{ $message }}</li>
    <li>{{ $msg }}</li>
  </ul>
</div>
```

![](upload/レンダリングで値を渡します.png){.photo-border}

このように、Livewireコンポーネントでは、viewを使った値の受け渡しも使えます。どちらのやり方も使えるようにしておきましょう。