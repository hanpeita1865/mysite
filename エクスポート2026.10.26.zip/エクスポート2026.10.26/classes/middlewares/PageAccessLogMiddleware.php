<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use SocymSlim\SlimMiddle\Services\FolderService;
use SocymSlim\SlimMiddle\Services\MarkdownService;
use Slim\Routing\RouteContext;
use Throwable;
use Monolog\Logger;


class PageAccessLogMiddleware implements MiddlewareInterface
{
    private Logger $logger;
    private FolderService $folderService;
    private MarkdownService $markdownService;

    public function __construct(
        Logger $accessLogger,
        MarkdownService $markdownService, 
        FolderService $folderService,
    )
    {
        $this->logger = $accessLogger;
        $this->folderService = $folderService;
        $this->markdownService = $markdownService;

    }

    public function process(
        ServerRequestInterface $request,
        RequestHandlerInterface $handler
    ): ResponseInterface {
        
        // $pageArea = $request->getAttribute('pageArea');//テスト
        
        // error_log('PageAccessLogMiddleware pageArea: ' . $pageArea);//テスト


        // 先にページ表示
        $response = $handler->handle($request);
        
        
        try {
            
            // Route取得
            $route = RouteContext::fromRequest(
                $request
            )->getRoute();

            $params = '';
            
            if ($route) {
                $params = $route->getArgument('params') ?? '';
            }

            $folderName = basename($params ?? '');

            $logData = $this->folderService->getAccessLogData($folderName);
            
            // ログ出力除外ユーザー
            $excludeUsers = [
                'U597583',
                'U590612',
                'U722587',
            ];

            // userが除外対象ならログ出力しない
            if (
                in_array(
                    $logData['user'] ?? '',
                    $excludeUsers,
                    true
                )
            ) {
                return $response;
            }

            $this->logger->info(
                'page_access',
                [
                    'user' => $logData['user'],
                    'title' => $logData['title'],
                    'path' => $logData['path'],
                ]
            );
                        
        
        } catch (Throwable $e) {

            // ログ失敗時は何もしない
            // ページ表示優先
        }

        return $response;
    }
}