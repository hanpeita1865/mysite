<?php session_start(); ?>
<?php require '../header.php'; ?>
<?php require 'menu.php'; ?>
<?php
unset($_SESSION['customer']);// 所定のセッションを削除
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', //データベースに接続
	'staff', 'password');

$sql=$pdo->prepare('select * from customer where login=? and password=?');//SQL文を設定
$sql->execute([$_REQUEST['login'], $_REQUEST['password']]);//SQL実行

foreach ($sql->fetchAll() as $row) {//データに登録されてか確認
	$_SESSION['customer']=[
		'id'=>$row['id'], 'name'=>$row['name'], 
		'address'=>$row['address'], 'login'=>$row['login'], 
		'password'=>$row['password']];
}
if (isset($_SESSION['customer'])) {//登録データがあるので、ログイン
	echo 'いらっしゃいませ、', $_SESSION['customer']['name'], 'さん。';
	
} else {//登録データがない
	echo 'ログイン名またはパスワードが違います。';
}
?>
<?php require '../footer.php'; ?>
