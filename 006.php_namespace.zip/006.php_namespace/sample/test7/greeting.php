<?php
namespace Asia\Japan\Kanto\Tokyo;

const Hello = 'やあ、こんにちは';
