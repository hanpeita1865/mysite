*[page-title]:Chap4-4 画像のアップロード機能を追加する

ワードパッドに記載済み「4-04 画像のアップロード機能を追加する」

一般に画像ファイルをデータベースに保存することは望ましくないため、サーバーの別の場所に格納し、データベースには画像ファイルへのパスを保存します。

<span class="bold green">Chap4-4 完成品まえ</span>
* \\wsl.localhost\Ubuntu-24.04\root\example-app17　ここのページの説明画像は、前のexample-app16になってます。
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>　データベース名は「example_app5」にしてます。
* ユーザー名「y-hirao@cc22.ne.jp」、パスワード「ryouma0305」
* MailPit <http://localhost:8025/>

## 画像投稿機能を実装しよう

ここまで作成したつぶやきアプリに画像投稿機能を追加実装してみましょう。 画像投稿における仕様は次の通りです。

* つぶやき投稿と一緒に画像を4枚まで投稿できる
* 投稿した画像は編集や単体での削除はできない
* つぶやきを削除すると画像も削除する

また画像をWebアプリケーションで保存するためには次の処理が必要です。

* ブラウザから投稿された画像を特定のパス（ディレクトリ）に格納する 
* データベースに画像を格納したパスを記録する

場合によっては、サムネイル画像用にリサイズした画像を生成して格納する必要もあるかもしれません。まずは画像を格納したパスを記録するデータベースを定義していきましょう。


### 画像用のテーブルを作成する
Artisanコマンドから新しいデータベースマイグレーションを作成します。

<p class="tmp cmd"><span>コマンド</span>画像用のテーブルを作成</p>
```
sail artisan make:migration createImagesTable
```

![](upload/画像用テーブル作成マイグレーション.png)

database/migrationsフォルダに「20XX_XX_XX_XXXXXX_create_images_table.php」という名前のファイルが生成されます。
![](upload/画像用マイグレーションファイル.png){.photo-border}

<p class="tmp list"><span>リスト</span>database/migrations/20XX_XX_XX_XXXXXX_create_images_table.php</p>
```
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('images', function (Blueprint $table) {
            $table->id();
            $table->string('name');//追加
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('images');
    }
};
```

ここではnameカラムを定義しました。このカラムに画像ファイルが格納されるパスを文字列で保存する想定です。  
また、今回は1つのつぶやきに対して最大4枚の画像が投稿されるため、画像テーブルとつぶやきテーブルを1対多でリレーションする必要があります。

![](upload/1対多交差テーブル.png "図　1対多交差テーブル")

ですので、交差テーブルを作成するマイグレーションも作成します。
<p class="tmp cmd"><span>コマンド</span>交差テーブル作成</p>
```
sail artisan make:migration createTweetImagesTable
```

![](upload/交差テーブルマイグレーション.png)

database/migrationsフォルダに 「20XX_XX_XX_XXXXXX_create_tweet_images_table.php」 が生成されます。 
![](upload/create_tweet_images_tableファイル作成.png){.photo-border}

交差テーブルのスキーマは 次のようになります。

<p class="tmp list"><span>リスト</span>20XX_XX_XX_XXXXXX_create_tweet_images_table.php</p>
```
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     */
    public function up(): void
    {
        Schema::create('tweet_images', function (Blueprint $table) {
            $table->foreignId('tweet_id')->constrained('tweets')->cascadeOnDelete();//追加
            $table->foreignId('image_id')->constrained('images')->cascadeOnDelete();//追加
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     */
    public function down(): void
    {
        Schema::dropIfExists('tweet_images');
    }
}
```

「<span class="bold green">foreignld</span>」はリレーショナルデータベースにおける外部キーであることを示し、「unsignedBigInteger」のエイリアスです。  
「<span class="red">->constrained</span>」と宣言することで外部キー制約になります。つまり、「`$table->foreignld('tweet_ id')->constrained('tweets')`」はtweetsテーブルに存在するidでなければtweet_idに格納できないことを表します。

続けて「<span class="red">->cascade On Delete</span>」 を宣言しています。 これは tweetsテー ブルでひも付いているidのレコードが削除された場合に、リレーショナルデータベースが外部キー制約されているレコードの振る舞いをどうするかを定義しています。この場合だと<span class="marker-yellow50">tweetsテーブルからレコードが削除された場合はtweet_imagesテーブルのひも付いたレコードも削除されます。</span>  
最後にマイグレーションを実行して反映しましょう。

<p class="tmp cmd"><span>コマンド</span>マイグレーション</p>
```
sail artisan migrate
```
![](upload/リレーショナルデータベースマイグレーション.png)
テーブルが作成されました。
![](upload/出来上がったリレーショナルデータベース.png){.photo-border}

できあがったテーブルは次のような構造になっています。

![](upload/出来上がったテーブル.png "図　出来上がったテーブル")


### 画像用のEloquentモデルを作成する

テーブルが作成できたので、続いては画像用のEloquentモデルを作成します。
<p class="tmp cmd"><span>コマンド</span>画像用のEloquentモデル作成</p>
```
sail artisan make:model Image -f
```
![](upload/画像用のEloquentモデルを作成.png)

オプション「-f」を利用してFactoryも一緒に生成しました 。
![](upload/ImagesFactoryファイル作成.png){.photo-border}

交差テーブル向けのモデルも作成します。交差テーブルは「--pivot」のオプションをつけることで作成できます。

<p class="tmp cmd"><span>コマンド</span>交差テーブル向けのモデル作成</p>
```
sail artisan make:model TweetImage --pivot
```
![](upload/交差テーブル向けのモデル作成.png)

![](upload/Tweetimageファイル作成.png){.photo-border}

PivotモデルはEloquentモデルとは異なり、継承しているクラスが <span class="red">Illuminate\Database\Eloquent\Relations\Pivot</span>になります。  
ここで作成したEloquentモデル、Pivotモデルは初期状態で問題ありません。  
開発データ用にFactoryクラスを編集します。

<p class="tmp list"><span>リスト</span>database/factories/ImageFactory.php</p>
```
<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Storage;//追加

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Image>
 */
class ImageFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        // ディレクトリがなければ作成する
        if (!Storage::exists('public/images')) {
            Storage::makeDirectory('public/images');
        }
        
        return [
            'name' => $this->faker->image(storage_path('app/public/images'), 640, 480, null, false)
        ];
    }
}
```

<span class="marker-yellow50">storageディレクトリは外部からアクセスできない領域になる</span>ので、storage/app/publicをpublicから参照できるようにシンボリックリンクを 作成する必要があります。  
LaravelではArtisanコマンドにシンボリックリンクを作成してくれるコマンドがあるので実行します。

<p class="tmp cmd"><span>コマンド</span>シンボリックリンク作成</p>
```
sail artisan storage:link
```
![](upload/sail_artisan_storagelink.png)

続いて、Tweetモデルから交差テーブルを利用したImageモデルとのひも付きを定義します。

<p class="tmp list"><span>リスト</span>app/Models/Tweet.php</p>
```
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tweet extends Model
{
    use HasFactory;
    protected $table = 'tweets';

    public function user() {
        return $this->belongsTo(User::class);
    }

    //追加
    public function images()
    {
        return $this->belongsToMany(Image::class, 'tweet_images')->using(TweetImage::class);
    }
}
```
これで多対多の関係でTweetlmageのPivotモデルを経由してImageモデルが取得できるようになります。ORMとしてデータベースのテーブル定義をそのまま反映しているので、多対多の関係となっていますが、今回のアプリケーションではImageが複数のTweetを持つことはないので、実質1対多として扱います。
実際の取得時の挙動は、画面表示を実装する際に見ていきましょう。  
それではTweetSeederを修正します。

<p class="tmp list"><span>リスト</span>database/seeders/TweetsSeeder.php</p>
```
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str; 
use App\Models\Tweet;
use App\Models\Image;//追加

class TweetsSeeder extends Seeder
{
    public function run() {
        //修正
        Tweet::factory()->count(10)->create()->each(fn($tweet) =>
            Image::factory()->count(4)->create()->each(fn($image) =>
                $tweet->images()->attach($image->id)
            )
        );
    }
}
```
TweetFactoryからデータを10件作成し、ImageFactoryから4件データを生成します。  
生成したtweetsレコードのデータからTweetモデルによりPivotモデルを経由してattachでImageldをひも付けて交差テーブルに保存します。  
このデータでは**10件のつぶやきレコード**と、そのつぶやきにそれぞれ**4件の画像**がひも付くようになります。  
Seederを実行してみましょう。

<p class="tmp cmd"><span>コマンド</span>Seeder実行</p>
```
sail artisan db:seed --class=TweetsSeeder
```
![](upload/class_tweet_seeder.png)

<span class="red">storage/app/public/images</span>に画像ファイルが生成され、それぞれimagesテーブル 、tweet_imagesテーブルにデータが追加されます。

![](upload/imagesフォルダに画像が作成された.png "図　imagesフォルダに画像が作成された"){.photo-border}

![](upload/imagesテーブル.png "図　imagesテーブル"){.photo-border}

![](upload/tweet_imagesテーブル.png "図　tweet_imagesテーブル"){.photo-border}


## つぶやき一覧に画像を表示する

開発用のデータが用意できたので、このデータを利用して画像を表示してみましょう。 まずつぶやき一覧取得処理で、つぶやきに対応する画像も一緒に取得できるようにしてみましょう。

<p class="tmp list"><span>リスト</span>app/Services/TweetService.php</p>
```
class TweetService
{
    public function getTweets()
    {
        return Tweet::with('images')->orderBy('created_at', 'DESC')->get();//with('images')->を追加
    }
```

ここで<span class="red">with()</span>をつけることでTweet取得時にまとめてImageも取得するようにSQLが実行されます。これは「<span class="bold green">Eager Loading</span>」と呼ばれる手法で、<span class="marker-yellow50">with()を指定しない場合はTweetからImageを呼び出す際にSQLが個別に実行される挙動になります</span>。N+1問題と呼ばれ、Tweetの数だけImageを取得するSQLが発行されてしまうため、with()を使って2回のSQLで済むようにします。  
Index Controllerにデバック用のコードを仕込んで確認してみましょう

<p class="tmp list"><span>リスト</span>app\Http\Controllers\Tweet\IndexController.php（あとで戻してください）</p>
```
･･･
$tweets = $tweetService->getTweets();
dump($tweets);//追加
app(\App\Exceptions\Handler::class)->render(request(), throw new \Error('dump report.'));//追加
return view('tweet.index')
		->with('tweets', $tweets);
    }
}
```
<http://localhost/tweet#debug>にアクセスするとレポート画面が表示され、Tweetモデルのプロパティのrelationsにimsgesとその配列が追加されていることが確認できます。

DUMPSタブの表示

![](upload/tweet_dunp1.png)
![](upload/tweet_dunp2.png)
![](upload/tweet_dunp3.png)

QUERIESタブを見るとwith()によって2回のSQL実行しかされていないことも確認できます。

QUERIESタブの表示
![](upload/QUERIESタブの表示.png)

確認が済んだら、IndexComtrollerを元の状態に戻しておきましょう。


## フロントエンドの作成

画像が取得できるようになったので、表示できるように作成していきます。  
今回はLaravel Breezeを導入した際に同梱されているJavaScriptフレー ムワークの「<span class="bold green">Alpine.js</span>」を利用して画像の拡大表示を実装します。

Alpine.js
: https://alpinejs.dev/

まず、画像の表示を行うコンポーネントを作成します。 resources/views/components/tweet/images.blade.php を作成して、 次のように記述します。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/images.blade.php</p>
```
@props([
    'images' => []
])

@if(count($images) > 0)
<div x-data="{}" class="px-2">
    <div class="flex justify-center -mx-2">
        @foreach($images as $image)
        <div class="w-1/6 px-2 mt-5">
            <div class="bg-gray-400">
                <a @click="$dispatch('img-modal', {  imgModalSrc: '{{ asset('storage/images/' . $image->name)  }}' })" class="cursor-pointer">
                    <img alt="{{ $image->name }}" class="object-fit w-full" src="{{ asset('storage/images/' . $image->name) }}">
                </a>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif
```

$imagesで画像の配列を受け取ってリスト表示します。  
<span class="red">@if(count($images) > 0) </span>としているので、 画像の投稿が1つ以上ある場合にリストを表示します。  
<span class="red">@click</span>はAlpine.jsのディレクティブで、x-on:click=の糖衣構文です。クリックイベントに関数を登録でき、ここでは$<span class="red">dispatch関数</span>を利用して<span class="red">img-modal</span>を起動させるためにイベントを実行します。

続けて次のようにコードを追加してimg-modalを実行します。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/images.blade.php</p>
```
@once
    <div x-data="{ imgModal : false, imgModalSrc : '' }">
        <div
            @img-modal.window="imgModal = true; imgModalSrc = $event.detail.imgModalSrc;"
            x-cloak
            x-show="imgModal"
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 transform"
            x-transition:enter-end="opacity-100 transform"
            x-transition:leave="transition ease-in duration-300"
            x-transition:leave-start="opacity-100 transform"
            x-transition:leave-end="opacity-0 transform"
            x-on:click.away="imgModalSrc = ''"
            class="p-2 fixed w-full h-100 inset-0 z-50 overflow-hidden flex justify-center items-center bg-black bg-opacity-75">
            <div @click.away="imgModal = ''" class="flex flex-col max-w-3xl max-h-full overflow-auto">
                <div class="z-50">
                    <button @click="imgModal = ''" class="float-right pt-2 pr-2 outline-none focus:outline-none">
                        <svg class="fill-current text-white h-5 w-5" xmlns="<http://www.w3.org/2000/svg>" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                    </button>
                </div>
                <div class="p-2">
                    <img
                        class="object-contain h-1/2-screen"
                        :alt="imgModalSrc"
                        :src="imgModalSrc">
                </div>
            </div>
        </div>
    </div>
    @push('css')
    <style>
        [x-cloak] { display: none !important; }
    </style>
    @endpush
@endonce
```

<span class="red">@once</span>はLaravelのディレクティブで、一度だけテンプレートに挿入させています。モーダルのコードが複数展開されてしまうと、展開された分だけモーダルが重複して表示されてしまうので、ここでは一度だけ追加されるように制御します。
このコンポーネントをつぶやき一覧から呼び出しましょう。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/list.blade.php</p>
```
@props([
    'tweets' => []
])
<div class="bg-white rounded-md shadow-lg mt-5 mb-5">
    <ul>
        @foreach($tweets as $tweet)
        <li class="border-b last:border-b-0 border-gray-200 p-4 flex items-start justify-between">
            <div>
                <span class="inline-block rounded-full text-gray-600 bg-gray-100 px-2 py-1 text-xs mb-2">{{ $tweet->user->name }}</span>
                <p class="text-gray-600">{!! nl2br(e($tweet->content)) !!}</p>
                <x-tweet.images :images="$tweet->images"/><!--追加-->
            </div>
            <div>
                <x-tweet.options :tweetId="$tweet->id" :userId="$tweet->user_id"></x-tweet.options>
            </div>
        </li>
        @endforeach
    </ul>
</div>
```

`<x-tweet.images images= "$tweet->images"/>` を追加しました。  
CSSの反映のため、`sail npm run dev`を実行する。（sail npm run developmentではだめ）

sail dockerには、nodeとnpmはもともとLaravelをインストールした時点で入ってたぽい。
![](upload/sailのnpmとnodeの確認.png)


ブラウザからアクセスすると次のように表示されます。
![](upload/モーダルのコードを追加.png){.photo-border}

画像をクリックするとモーダルで表示されます。この時点でモーダルのスタイルは効いてないみたい。なぜ・・・？
![](upload/モーダルで画像表示.png){.photo-border}

![](upload/モーダルスタイルが効いた場合の表示.png "モーダルスタイルが効いた場合の表示"){.fig-top}


## 画像投稿処理を作成する

続いてつぶやき投稿で画像も一緒に投稿できるように機能拡張していきます。

### 画像のバリデーション

まずはCreateRequestクラスにバリデーション定義を追加します。

<p class="tmp list"><span>リスト</span>app/Http/Requests/Tweet/CreateRequest.php</p>
```
<?php

namespace App\Http\Requests\Tweet;

use Illuminate\Foundation\Http\FormRequest;

class CreateRequest extends FormRequest
{
…省略…
    public function rules()
    {
        return [
            'tweet' => 'required|max:140',//, を追加
            'images' => 'array|max:4',//追加
            'images.*' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048'//追加
        ];
    }
    …省略…
    //追加
    public function images(): array
    {
        return $this->file('images', []);
    }
}
```
rulesに「images」と「images.*」を追加しました。 画像投稿は必須では ないが4件までの制限があるので、「<span class="red">array max:4</span>」を指定しています。  
配列の中身に対してのバリデーションは「.*」を使って宣言します。ここでは「<span class="marker-yellow50">画像</span>」であることと、「<span class="marker-yellow50">画像の形式</span>」および「<span class="marker-yellow50">ファイルサイズの上限</span>」を指定しています。ファイルサイズにおけるmaxの単位はKB(キロバイト) なので、2048は1 つの画像に付き2MBの制限であることを示しています。

画像の取得はファイル投稿なので、「$this->input」ではなく「<span class="red">$this ->file</span>」 から取得します。


### つぶやきと画像の一緒に保存する仕組みを作る。

次に画像を含めたつぶやきの保存処理を作成します。コントローラで処理を書くと、コントローラが肥大化し、つぶやき関連の処理もコントローラに散漫してしまうので、サービスクラスに実装しましょう。

<p class="tmp list"><span>リスト</span>app/Services/TweetService.php</p>
```
<?php

namespace App\Services;

use App\Models\Tweet;
use Carbon\Carbon;
use App\Models\Image;//追加
use Illuminate\Support\Facades\DB;//追加
use Illuminate\Support\Facades\Storage;//追加

class TweetService {

…省略…
    //追加
    public function saveTweet(int $userId, string $content, array $images)
    {
        DB::transaction(function () use ($userId, $content, $images) {
            $tweet = new Tweet;
            $tweet->user_id = $userId;
            $tweet->content = $content;
            $tweet->save();
            foreach ($images as $image) {
                Storage::putFile('public/images', $image);
                $imageModel = new Image();
                $imageModel->name = $image->hashName();
                $imageModel->save();
                $tweet->images()->attach($imageModel->id);
            }
        });
    }
}
```
DBファサードを利用してトランザクションを作成しています。 DBファサードのトランザクションはデータベースのトランザクションを管理します。  
トランザクションはRDBMS (リレーショナルデータベース) では一般的な機能です。 通常は1つのSQL操作を1コミットとしてデータベースに反映してい きますが、トランザクションを利用することで、 複数のSQL 操作をコミットのま とまりとして同時に反映できます。  
ここではつぶやきの保存と画像の保存を同時に行うので、 失敗した場合は すべてのデータベース操作をロールバック (もとに戻す) できるようにします。なお、use()は関数外で定義した変数を利用する際に使用します。

※トランザクション（英：transaction）とは、一連の処理をひとまとめにしたものです。（参考 【データベース】トランザクションとは<https://medium-company.com/%E3%83%88%E3%83%A9%E3%83%B3%E3%82%B6%E3%82%AF%E3%82%B7%E3%83%A7%E3%83%B3/）>


### 画像を実際に保存する

つぶやきを保存後に画像を1つずつ保存します。 ここの処理は次のような流れになっています。

1. 画像の名前をランダムに生成
2. storage/imagesディレクトリに 1で指定した名前の画像ファイルを保存
3. Eloquentモデルに格納先のパスと画像のファイル名を指定して保存 
4. Tweetモデルを経由してつぶやきと画像の交差テーブルにデータを保存

コントローラからサービスクラスを利用して保存できるように修正します。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/CreateController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tweet\CreateRequest;
use App\Models\Tweet;
use App\Services\TweetService;//追加

class CreateController extends Controller
{
    …省略…
    public function __invoke(CreateRequest $request, TweetService $tweetService)
    {//TweetService $tweetService追加
        //追加		
        $tweetService->saveTweet(
            $request->userId(),
            $request->tweet(),
            $request->images()
        );
        return redirect()->route('tweet.index');
    }
}
```

これでつぶやき投稿と画像保存を行う処理が作成できました。


### フロントエンドを変更する

画像を投稿するフォームコンポーネントを作成します。 resources/views/ components/tweet/form フォルダ内に「images.blade.php」を新規作成しましょう。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/form/images.blade.php</p>
```
<div x-data="inputFormHandler()" class="my-2">
    <template x-for="(field, i) in fields" :key="i">
        <div class="w-full flex my-2">
            <label :for="field.id" class="border border-gray-300 rounded-md p-2 w-full bg-white cursor-pointer">
                <input type="file" accept="image/*" class="sr-only" :id="field.id" name="images[]" @change="fields[i].file = $event.target.files[0]">
                <span x-text="field.file ? field.file.name : '画像を選択'" class="text-gray-700"></span>
            </label>
            <button type="reset" @click="removeField(i)" class="p-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-500 hover:text-red-700" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                </svg>
            </button>
        </div>
    </template>

    <template x-if="fields.length < 4">
        <button type="button" @click="addField()" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-gray-500 hover:bg-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd" />
            </svg>
            <span>画像を追加</span>
        </button>
    </template>
</div>
```

さらに、続けて次のようなスクリプトタグを追加します。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/form/images.blade.php</p>
```
<script>
function inputFormHandler() {
  return {
    fields: [],
    addField() {
      const i = this.fields.length;
      this.fields.push({
        file: '',
        id: `input-image-${i}`
      });
    },
    removeField(index) {
      this.fields.splice(index, 1);
    }
  }
}
</script>
```

追加したスクリプトタグは画像の投稿フォームの個数を制御しています。 addFieldは投稿フォームの追加、remove Fieldは削除です。  
画像投稿フォームを追加できるボタンの個数は、images.blade.phpの「x-if="fields.length < 4"」の部分で4つまでに制限しています。  
これで最大4件まで画像が投稿できるフォームが作成できましたので、post.blade.phpから呼び出しましょう。

<p class="tmp list"><span>リスト</span>resources/views/components/tweet/form/post.blade.php</p>
```
@auth
<div class="p-4">
    <form action="{{ route('tweet.create') }}" method="post" enctype="multipart/form-data"><!--enctype="multipart/form-data"を追加-->
        @csrf
        <div class="mt-1">
            <textarea name="tweet" rows="3" class="focus:ring-blue-400 focus:border-blue-400 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md p-2" placeholder="つぶやきを入力">
</textarea>
        </div>
        <p class="mt-2 text-sm text-gray-500">
            140文字まで
        </p>
        <x-tweet.form.images></x-tweet.form.images><!--追加-->

        @error('tweet')
        <x-alert.error>{{ $message }}</x-alert.error>
        @enderror
        …省略…
    </form>
</div>
@endauth
```

ここでformタグに注目してください。「<span class="red">enctype="multipart/form-data"</span>」を追加しています。これはHTMLの仕様で、POSTで送信する形式を表しています。  コンテンツの内容を表すMIME Typeを複数扱えるようにするための記述です。  
画像やファイルを投稿する際にはこの「enctype="multipart/form-data"」が必要です。  
それではブラウザで表示してみましょう。

※表示が崩れている場合は、「sail npm run dev」を実行して再表示してみてください。

http://localhost/tweet　に接続して画像を追加してみてください。

画像を追加しつぶやきを記入してつぶやきボタンをクリックします。
![](upload/画像とつぶやき追加.png){.photo-border}

つぶやきと画像が表示されました。容量が大きい画像だとつぶやきは保存されないみたい。

![](upload/つぶやきと画像を表示.png){.photo-border}


## 削除処理を実装する

最後につぶやき削除時に、画像も一緒に削除されるようにします。

<p class="tmp list"><span>リスト</span>app/Services/TweetService.php</p>
```
…省略…
class TweetService
{
    …省略…
    //追加
    public function deleteTweet(int $tweetId)
    {
        DB::transaction(function () use ($tweetId) {
            $tweet = Tweet::where('id', $tweetId)->firstOrFail();
            $tweet->images()->each(function ($image) use ($tweet){
                $filePath = 'public/images/' . $image->name;
                if(Storage::exists($filePath)){
                    Storage::delete($filePath);
                }
                $tweet->images()->detach($image->id);
                $image->delete();
            });
    
            $tweet->delete();
        });
    }
}
```

ここの処理は次の流れになっています。

1. 対象のつぶやきモデルを取得
2. つぶやきモデルにひも付いている画像を1件ずつ参照
3. 画像モデルからファイルパスを作成し、 File クラス(ファサード) を利用して画像の実体を確認
4. 画像があれば削除
5. つぶやきと画像のひも付けを detachで削除
6. 画像モデル (レコード) を削除

投稿処理と同様にコントローラからサービスクラスを呼び出して処理を行います。


<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/DeleteController.php（全文）</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use App\Models\Tweet;
use App\Services\TweetService;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;


class DeleteController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, TweetService $tweetService)
    {
        $tweetId = (int) $request->route('tweetId');
        if (!$tweetService->checkOwnTweet($request->user()->id, $tweetId)) {
            throw new AccessDeniedHttpException();
        }
        $tweetService->deleteTweet($tweetId);//追加
        return redirect()
            ->route('tweet.index')
            ->with('feedback.success', "つぶやきを削除しました");
    }
}
```

実際にブラウザから画像付きで投稿したつぶやきを削除すると、下記のstorage/app/public/imagesディレクトリから対象の画像が削除されます。
![](upload/public_imagesフォルダ画像表示.png "図　storage/app/public/images"){.photo-border}
これで画像投稿および削除が実装できました。


