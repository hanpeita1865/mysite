import { Api } from '../api.js';
import { show } from '../modalManager.js';
import { getAdminData } from '../adminData.js';

export function initFolderDelete({ soating, completeMsg, menu_create }) {

    document.querySelectorAll('.folder-del').forEach((elm) => {
        elm.addEventListener('click', (e) => {
            if (soating()) {
                show('soatWarn');
                return;
            }
            openDeleteModal(e, menu_create, completeMsg);
        });
    });
}



function openDeleteModal(e, menu_create, completeMsg) {

    const delmodal = document.getElementById('fdDelModal');
    const fdDelName = document.getElementById('folder-name');

    const menuId = e.target.closest('.box-item').getAttribute('id');
    delmodal.dataset.id = menuId;

    const listElm = e.target.closest('.box-item').querySelectorAll('li');
    const delListNum = listElm.length + 1;

    const listName = e.target.closest('.box-item').children[0].textContent;
    const listDir = e.target.closest('.box-item').children[0].getAttribute('href');
    
    const folderName = listDir.split('/').slice(-2)[0];
    fdDelName.innerHTML = `${listName}【${folderName}】`;

    menu_create();

    bindDeleteButtons(delListNum, folderName, completeMsg);
}



function bindDeleteButtons(delListNum, folderName, completeMsg) {

    const onlyBtn = document.getElementById('only-del');
    const allBtn = document.getElementById('all-del');

    onlyBtn.onclick = () => onlyDelete(delListNum, folderName, completeMsg);
    allBtn.onclick = () => allDelete(delListNum, folderName, completeMsg);
}



// --------------------
// 対象フォルダのみ削除
// --------------------

async function onlyDelete(delListNum, folderName, completeMsg) {

    const fd = new FormData();
    fd.append('eventName', '対象フォルダのみ削除');
    fd.append('folderName', folderName);

    const { adminFull } = getAdminData();

    try {
        const text = await Api.postText(adminFull + 'folderDelOnly', fd);

        if (!text.match(/エラー/)) {
            completeMsg('削除しました。');
            location.reload();
        } else {
            alert(text);
        }
    } catch {
        alert('削除に失敗しました。');
    }
}



// --------------------
// 配下も含めて削除
// --------------------

async function allDelete(delListNum, folderName, completeMsg) {

    const fd = new FormData();
    fd.append('eventName', '配下のフォルダも削除');
    fd.append('folderName', folderName);
    
    const { adminFull } = getAdminData();

    try {
        const text = await Api.postText(adminFull + 'del_allfolder', fd);

        if (!text.match(/エラー/)) {
            await lockdata_delete(folderName);
            completeMsg('削除しました。');
            
            location.reload();
            
        } else {
            alert(text);
        }
    } catch {
        alert('失敗しました');
    }
}

//lockデータ削除
async function lockdata_delete(folderName) {
    //データベースのlocklistテーブルに登録があれば削除する
    const formData = new FormData();
    formData.append('post_delFolder', folderName);
    formData.append('eventName', '配下のフォルダも削除');
    
    const { adminFull } = getAdminData();
    
    try {
        const text = await Api.postText(adminFull + 'lockdata_del', formData);

    } catch {
        alert('DBデータ削除に失敗しました～。');
    }
}
