*[page-title]:YouTube埋め込み

## YouTube動画を埋め込む

挿入する位置を指定して、ツールバーの<img src="upload/movie.png" class="figure-none">をクリックします。

YouTube動画のURLをコピーして入力欄に貼り付け、<kbd class="border">Enter</kbd>キーを押すか、<img src="upload/チェックボタン.png" class="figure-none">ボタンをクリックします。
![](upload/URL入力.png "図　YouTube動画のURLをコピー&ペーストします")

これで動画が挿入されます。ただ、編集画面では再生できません。確認画面に移動すると再生することができます。  
（デフォルトでは、画面サイズ 600px、中央寄せに設定しています）  
左上の<img src="upload/上にカーソル挿入.png" class="figure-none">ボタンをクリックすると、動画の上にカーソルが表示され、右下の<img src="upload/下にカーソル挿入.png" class="figure-none">ボタンをクリックすると、動画の下にカーソルが表示されます。  
![](upload/動画挿入.png "図　YouTube動画挿入デフォルトの表示")

## 横位置を変更

埋め込み動画のサイズや横位置を変更したい場合は、ツールに画像の時のような機能はないので、HTMLに直接コードを追加します。

<!--ここで注意して欲しいのは、挿入した動画の上下にまだテキストなどが何も記入されていないときは、動画を挿入した後、下の<kbd>&lt;div class="～"&gt;～&lt;/div&gt;</kbd>コードを追記する前に、左上の<img src="upload/上にカーソル挿入.png" class="figure-none">ボタンと右下の<img src="upload/下にカーソル挿入.png" class="figure-none">ボタンをクリックして、動画の上下に空の<kbd>&lt;p&gt;</kbd>をあらかじめ作成しておくとよいです。また、<kbd>&lt;div class="～"&gt;</kbd>を設置した後でも、HTMLに直接上下に空の<kbd>&lt;p&gt;</kbd>タグを記入してもいいです。  
これは、下記の<kbd class="border">&lt;div class="～"&gt;～&lt;/div&gt;</kbd>を追記した後に、カーソル挿入ボタンをクリックすると、<span class="red">作成した<kbd>&lt;div&gt;</kbd>の内側にテキストなどが記入されるため</span>の防止策です。  
なので、下記の<span class="red"><kbd>&lt;div&gt;</kbd>要素を追記した後は、<img src="upload/上にカーソル挿入.png" class="figure-none">ボタンと右下の<img src="upload/下にカーソル挿入.png" class="figure-none">ボタンは使用しないでください。</span>-->

<div class="gray-box" markdown="1">
📌 注意することとして、下記の<kbd class="border">&lt;div class="～"&gt;～&lt;/div&gt;</kbd>を追記した後に、カーソル挿入ボタン<img src="upload/上にカーソル挿入.png" class="figure-none">ボタンをクリックしてテキストなどを記入すると、<span class="red">作成した<kbd>&lt;div&gt;</kbd>の内側に記入されます。なので、下記の<span class="red"><kbd>&lt;div&gt;</kbd>要素を追記した後は、<img src="upload/上にカーソル挿入.png" class="figure-none">ボタンは使用しないでください。</span>  
後からテキストを記入する場合は、HTMLに直接空タグの<kbd>&lt;p&gt;&lt;/p&gt;</kbd>を挿入してください。
</div>

では、<img src="upload/source.png" class="figure-none">ボタンをクリックし、HTMLコード表示に切り替えてください。
![](upload/HTMLコード表示に切り替え.png "図　HTMLコード表示に切り替え")

次に、その動画埋め込みコード全体を<kbd class="border">&lt;div&gt;</kbd>要素で囲います。

左寄せにする場合は、<kbd class="border">&lt;div class="m-left"&gt;～&lt;/div&gt;</kbd>を追記します。
![](upload/左寄せコード.png "図　左寄せコード")

![](upload/動画挿入左寄せ.png "図　埋め込み動画を左寄せ")

右寄せにする場合は、<kbd class="border">&lt;div class="m-right"&gt;～&lt;/div&gt;</kbd>を追記します。
![](upload/右寄せコード.png "図　右寄せコード")

![](upload/動画挿入右寄せ.png "図　埋め込み動画を右寄せ")

## サイズを変更

横位置を変更した時と同じように、、HTMLに直接コードを追加します。  
<img src="upload/source.png" class="figure-none">ボタンをクリックし、HTMLコード表示に切り替えます。
例えば、450pxに変える場合は、次のようにコードを追記します。

![](upload/サイズを450pxに変更.png "図　動画サイズを450pxに変更するコード追加")

![](upload/動画挿入450px.png "図　動画サイズが450pxの表示結果")

サイズ変更用のクラスを下の表にまとめています。


<table>
	<tbody>
		<tr>
			<th>サイズ</th>
			<td class="text-center">800px</td>
			<td class="text-center">750px</td>
			<td class="text-center">700px</td>			
			<td class="text-center">650px</td>
			<td class="text-center">550px</td>
			<td class="text-center">500px</td>
			<td class="text-center">450px</td>
			<td class="text-center">400px</td>
			<td class="text-center">350px</td>
			<td class="text-center">画面幅いっぱい</td>
		</tr>
		<tr>
			<th>クラス名</th>
			<td>mw-800</td>
			<td>mw-750</td>
			<td>mw-700</td>			
			<td>mw-650</td>
			<td>mw-550</td>
			<td>mw-500</td>
			<td>mw-450</td>
			<td>mw-400</td>
			<td>mw-350</td>
			<td>mw-none</td>
		</tr>
	</tbody>
</table>

横位置とサイズの両方のクラスを記入するときは、次のようにクラスの間に半角スペースを取ります。
```
<div class="m-left mw-450">
```

## 横並び

動画を横並びにする方法です。  
同じやり方で、動画を2つ以上挿入します。 HTMLコードに切り替えて、下記のコードを追記します。  

![](upload/media-col2.png "図　2つ並べての表示コード")
![](upload/動画2カラム横並び表示.png "図　2つ並べて動画の表示")

3つ並べさせる場合は、クラス名を「media-col3」に変えると、次のように3つ並びに変わります。
![](upload/media-col3.png "図　3つ並べて動画の表示")

2つ並びのブレークポイントは、767px以下で1つ並びに切り替わります。  
3つ並びのブレークポイントは、991px以下で2つ並びに、767px以下で1つ並びに切り替わります 。