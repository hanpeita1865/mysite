*[page-title]:Ratchet（PHP）

参考サイト
: [PHPでWebSocket](https://qiita.com/toontoon/items/b8af85c409ead3290c5e)
: [LaravelでWebSocket](https://qiita.com/toontoon/items/5357460760607a3d432f)←おまけ

## 設定方法

まずディレクトリ（php_websocket）を作成した後、そこにcomposer.jsonを作成します。

次にPHPライブラリーの「<span class="green bold marker-yellow50">Ratchet</span>」をインストールします。

<p class="tmp cmd"><span>コマンド</span>Ratchetインストール</p>
```
composer require cboden/ratchet
```
![](upload/cboden_ratchet.png)
･･･省略･･･
![](upload/cboden_ratchet2.png)

ディレクトリ（php_websocket）の中に、srcフォルダをつくります。  

composer.jsonへ下記のように記述します。

<p class="tmp list"><span>リスト1-1</span>composer.json</p>
```
{
    "autoload" : {
        "psr-4" : {
            "App\\" : "src"
        }
    },
    "require": {
        "cboden/ratchet": "^0.4.4"
    }
}
```

コマンドラインで次を実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
composer dump-autoload
```
![](upload/dump-autoload.png)
これで修正したautoloadが反映されます

フォルダ構成は下記になります
```
`-- php_websocket
    |-- src
    |-- vendor
    `-- composer.json
```

## ファイル作成

#### (1) srcフォルダ配下にChat.phpを作成

<p class="tmp list"><span>リスト2-1</span>src/Chat.php</p>
```
<?php
namespace App;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements MessageComponentInterface {

    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    //webSocket接続できたら、自動的に実行される。
    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
    }

    //クライアントがデータを送信したら実行される。
    public function onMessage(ConnectionInterface $from, $msg) {
        foreach ($this->clients as $client) {
            $data = ['msg' => $msg];

            if ($from === $client) {
                $data['position'] = 'right';
            } else {
                $data['position'] = 'left';
            }

            $client->send(json_encode($data));//全クライアントへデータが送信される。
        }
    }

    //webSocket切断
    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }
}
```
webSocket接続できたら、自動的にonOpenが実行されます。今回は$this->clientsにコネクションを追加しています。  
クライアントがデータをsendしてきたら、自動的にonMessageが実行されます。今回はjsonを返すようにしています。


#### (2) srcフォルダ配下にwsServer.php作成


<p class="tmp list"><span>リスト2-2</span>src/wsServer.php</p>
```
<?php
namespace App;

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use App\Chat;

require dirname(__DIR__) . '\vendor\autoload.php';

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat()
            )
        ),
    8282
    );

$server->run();
```

webSocketのエントリポイントになります。  
「8282」は今回WebSocketで使うポートです。ファイヤーウォールで許可しているポートにしてください。
先ほど作成したChatクラスを与えて、WebSocketサーバーをrunします。


#### (3) HTTPサーバーの公開フォルダにws.html作成

<p class="tmp list"><span>リスト2-3</span>ws.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sample</title>
</head>
<body>
    <div class="container">
        <div id="msg_log" class="msg-log"></div>
        <div class="input-area">
            <textarea id="msg" class="msg"></textarea>
            <button class="btn" onclick="send();">送信</button>
        </div>
    </div>
    <script type="text/javascript">

        var conn = "";

        function open() {

            conn = new WebSocket('ws://localhost:8282');

            conn.onopen = function (e) {
            };

            conn.onerror = function (e) {
                alert("エラーが発生しました");
            };

            //データを受信
            conn.onmessage = function (e) {
                var data = JSON.parse(e.data);
                var divObj = document.createElement("DIV");
                if (data["position"] == "left") {
                    divObj.className = 'receive-msg-left';
                } else {
                    divObj.className = 'receive-msg-right';
                }
                var msgSplit = data["msg"].split('\n');
                for (var i in msgSplit) {
                    var msg = document.createTextNode(msgSplit[i]);
                    var rowObj = document.createElement("DIV");
                    rowObj.appendChild(msg);
                    divObj.appendChild(rowObj);
                }

                var msgLog = document.getElementById("msg_log");
                msgLog.appendChild(divObj);

                var br = document.createElement("BR");
                br.className = 'br';
                msgLog.appendChild(br);

                msgLog.scrollTop = msgLog.scrollHeight;

            };

            conn.onclose = function () {
                alert("切断しました");
                setTimeout(open, 5000);
            };
        }

        function send() {
            conn.send(document.getElementById("msg").value);//webSocketサーバーにデータ送信
        }

        function close() {
            conn.close();
        }

        open();

    </script>
</body>
</html>
```

`conn = new WebSocket('ws://localhost:8282');`で接続してます。8282は先ほどwsServer.phpに書いたポートです。  
`conn.send(document.getElementById("msg").value);`でwebSocketサーバーにデータ送信しています。  

「conn.onmessage」はwebSocketサーバーからsendがあった場合に自動的に実行されます。

<p class="tmp list"><span>リスト2-4</span>style.css</p>
```
@charset "UTF-8";

.container {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
}
.msg-log {
    width: 100%;
    height: 92%;
    vertical-align:top;
    box-sizing: border-box;
    padding: 0px;
    border: black solid 1px;
    overflow-y: scroll;
}
.input-area {
    width: 100%;
    box-sizing: border-box;
}
.msg {
    width: 90%;
    height: 8%;
    vertical-align:top;
    box-sizing: border-box;
    padding: 0px;
    float: left;
}
.btn {
    width: 10%;
    height: 8%;
    vertical-align:top;
    box-sizing: border-box;
    padding: 0px;
}
.receive-msg-left {
    border-radius: 10px;
    border: black solid 1px;
    padding: 10px;
    margin: 10px;
    display: inline-block;
    float: left;
}
.receive-msg-right {
    border-radius: 10px;
    border: black solid 1px;
    padding: 10px;
    margin: 10px;
    display: inline-block;
    float: right;
    background-color: #00FF00;
}
.br {
    clear: both;
}
```

## 動作確認
コマンドラインでsrcフォルダにcdして、先ほど作成したエントリーポイントファイル「wsServer.php」の名前を入れた次のコマンドを実行します。
<p class="tmp cmd"><span>コマンド</span>サーバー起動</p>
```
php wsServer.php
```
![](upload/php_wsServer.png)
これでWebSocketサーバーが起動しました

公開用の「ws.html」のサイトを表示します。  
<http://localhost:7001/test/php_websocket/ws.html>

初期表示は次のようになっています。
![](upload/wsチャット初期表示..png "図　チャット初期表示"){.photo-border}
もうひとつ表示させ並べてから動作確認してみます。
![](upload/WebSocketチャット動作確認.gif "図　チャット動作確認"){.photo-border}


