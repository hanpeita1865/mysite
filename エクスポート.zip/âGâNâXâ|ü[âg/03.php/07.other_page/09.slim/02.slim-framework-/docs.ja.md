---
title: 'Slim ver3スケルトン チュートリアル'
media_order: 'slim_toppage.png,hello_jhon.png,tickets_create.png,slim_database.png,tickets_create1.png,tickets_create2.png,tickets_list1.png,tickets_list2.png,tickets_list3.png,tickets_list4.png,not_found.png,tickets_edit1.png,tickets_delete1.png,tickets_delete2.png,tickets_delete0.png,tickets_delete3.png,tickets_list5.png'
---

* [インストール](#p1)
* [ルーティング](#p2)
* [ルーティングの追加](#p3)
* [新規作成](#p4)
* [データベースに保存する](#p5)
* [一覧表示](#p6)
* [PHP-View でパーシャルビュー](#p7)
* [編集用フォームの表示](#p8)
* [ルーティング関数にチケットデータを取得する処理を書く](#p9)
* [更新](#p10)
* [削除](#p11)
* [Controller クラスの導入](#p12)
* [重複した処理を共通化する](#p13)

## Slim の特徴
Slim は "マイクロフレームワーク" と呼ばれる、必要最低限の機能のみを提供し、その分速度が出るようにデザインされた軽量なフレームワークで、Symfony や Laravel のような、機能全部乗せで巨大な、いわゆるフルスタックフレームワークとは、導入の目的や用途も異なる場合が多いです。

つくろうとするアプリケーションがそれほど複雑でなく、同時アクセス数が比較的多く見込まれる場合には、マイクロフレームワークが適しているケースが多いです。


##  インストール ##{#p1}

Slimのバージョン3をインストールする場合
<p class="tmp cmd"><span>コマンド</span>インストール（Ver3）</p>
```
composer create-project slim/slim-skeleton:3.* Tutorial-First-Application
```


最新のSlimのバージョンをインストールする場合
<p class="tmp cmd"><span>コマンド</span>インストール（最新Ver）</p>
```
composer create-project slim/slim-skeleton Tutorial-First-Application
```

ビルトインウェブサーバーを利用する場合、下記のコマンドを実行して、<http://localhost:8080/> に接続してください。
```
php -S localhost:8080 -t public public/index.php
```

ここでは、Xamppにポート番号8001で設定したので、<http://localhost:8001/> に接続するとSlimのトップが開きます。

![](slim_toppage.png)



## ルーティング ##{#p2}

インストール直後は、以下のように「src/routes.php」はなっています。

<p class="list tmp"><span>リスト</span>src/routes.php</p>
```
<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;

return function (App $app) {
    $container = $app->getContainer();

    $app->get('/[{name}]', function (Request $request, Response $response, array $args) use ($container) {
        // Sample log message
        $container->get('logger')->info("Slim-Skeleton '/' route");

        // Render index view
        return $container->get('renderer')->render($response, 'index.phtml', $args);
    });
};

```

<http://localhost:8001/jhon>とURLの後尾に「jhon」と付けると、Try SlimFramework と表示されていた部分が、Hello John! に置き換わりました。

![](hello_jhon.png)

templates/index.phtml の中を見ると、以下のように条件分岐されており、 $name という変数が使われています（この変数に、URL の末尾に追加した文字列が格納されて表示されます）。

<p class="list tmp"><span>リスト</span>templates/index.phtml</p>
```
<?php if (isset($name)) : ?>
    <h2>Hello <?= htmlspecialchars($name); ?>!</h2>
<?php else: ?>
    <p>Try <a href="http://www.slimframework.com">SlimFramework</a></p>
<?php endif; ?>
```

## ルーティングの追加 ##{#p3}
今回は以下のルーティングを使用します。チケットの一覧表示、新規作成、1件表示、編集、削除が一通りできるようになります。

* GET /tickets - チケット一覧の表示
* GET /tickets/create - チケットの新規作成用フォームの表示
* POST /tickets - チケットの新規作成
* GET /tickets/{id} - チケットの表示
* GET /tickets/{id}/edit - チケット編集用フォームの表示
* PATCH /tickets/{id} - チケットの更新
* DELETE /tickets/{id} - チケットの削除

`$app->get('/[{name}]', ...)` の行より前に、以下のルーティングを追加してください。

<p class="list tmp"><span>リスト</span>routes.php</p>
```
// 一覧表示
$app->get('/tickets', function (Request $request, Response $response) {
});

// 新規作成用フォームの表示
$app->get('/tickets/create', function (Request $request, Response $response) {
});

// 新規作成
$app->post('/tickets', function (Request $request, Response $response) {
});

// 表示
$app->get('/tickets/{id}', function (Request $request, Response $response, array $args) {
});

// 編集用フォームの表示
$app->get('/tickets/{id}/edit', function (Request $request, Response $response, array $args) {
});

// 更新
$app->patch('/tickets/{id}', function (Request $request, Response $response, array $args) {
});

// 削除
$app->delete('/tickets/{id}', function (Request $request, Response $response, array $args) {
});

```

## 新規作成 ##{#p4}
### チケットの新規作成フォーム
まず最初に、チケットを作成するためのフォームをつくります。

新規作成用フォームを表示するためのルーティングを編集していきましょう。

<p class="list tmp"><span>リスト</span>routes.php</p>
```
// 新規作成用フォームの表示
$app->get('/tickets/create', function (Request $request, Response $response) {
    return $this->renderer->render($response, 'tickets/create.phtml');
});
```

続いて、テンプレートファイルを作成します。

templates ディレクトリの下に、tickets ディレクトリをつくり、そこに create.phtml というファイルをつくります

<p class="list tmp"><span>リスト</span>create.phtml</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8"/>
  <title>チケット管理</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body>
  <div class="container">
    <h1>チケット管理</h1>
    <form method="POST" action="/tickets">
      <div class="card">
        <div class="card-body">
          <h2 class="card-title">チケット作成</h2>
          <div class="card-text">
            <div class="form-group">
              <label for="subject">件名</label>
              <input type="text" name="subject" id="subject" class="form-control">
            </div>
          </div>
        </div>
        <div class="card-body">
          <button class="btn btn-primary">作成</button>
        </div>
      </div>
    </form>
  </div>
</body>
</html>
```

### 新規作成用のルート設定
では、新規作成用ルートの中身を実装していきます。

<p class="list tmp"><span>リスト</span>routes.php 新規作成</p>
```
// 新規作成
$app->post('/tickets', function (Request $request, Response $response) {
    $subject = $request->getParsedBodyParam('subject');
    // ここに保存の処理を書く
    // 保存が正常にできたら一覧ページへリダイレクトする
    return $response->withRedirect("/tickets");
});
```

正常にリダイレクトされたことが分かるように、一覧表示のレスポンスにも少し手を加えておきます。

<p class="list tmp"><span>リスト</span>routes.php 一覧表示</p>
```
$app->get('/tickets', function (Request $request, Response $response) {
    return $response->write('tickets');
});
```

<http://localhost:8001/tickets/create>

![](tickets_create.png)


これで、 新規作成フォームの「作成」ボタンを押すと、

1. 新規作成が行われる（未実装）
1. チケット一覧表示ページにリダイレクトされる
1. "tickets" と表示される

という流れになります。


Slim では基本的に以下のようにレスポンスを返します。

* 単なるテキスト $response->write()
* PHP View $this->renderer->render($response, $templatePath)
* リダイレクト $response->withRedirect($url)
* JSON $response->withJson($data)

場合に応じて使い分けてください。

## データベースに保存する ##{#p5}

ここでは、XAMPPにデータベースを設置しようと思います。

```
create database slim_tutorial default charset utf8mb4 collate utf8mb4_general_ci;
```

```
use slim_tutorial;
```

```
create table tickets(id int unsigned not null auto_increment, subject varchar(255) not null, primary key(id));
```

上記のSQL文を実行すると、以下のようにデータベースとテーブルが作成されます。

![](slim_database.png)


次に、src/settings.php を開いてください。

// database 以下を下記の場所に記述してください。

<p class="list tmp"><span>リスト</span>src/settings.php</p>
```
        // Monolog settings
        'logger' => [
            'name' => 'slim-app',
            'path' => isset($_ENV['docker']) ? 'php://stdout' : __DIR__ . '/../logs/app.log',
            'level' => \Monolog\Logger::DEBUG,
        ],

        // database
        'db' => [
            'host'   => 'localhost',
            'user'   => 'root',
            'pass'   => '',
            'dbname' => 'slim_tutorial'
        ],
    ],
];
```

### コンテナへの追加
続いて、 src/dependencies.php を開きます。

同様に、 //database 以下の行を、以下の場合に記述してください。


<p class="list tmp"><span>リスト</span>src/dependencies.php</p>
```

// monolog
$container['logger'] = function ($c) {
    $settings = $c->get('settings')['logger'];
    $logger = new Monolog\Logger($settings['name']);
    $logger->pushProcessor(new Monolog\Processor\UidProcessor());
    $logger->pushHandler(new Monolog\Handler\StreamHandler($settings['path'], $settings['level']));
    return $logger;
};

// database
$container['db'] = function ($c) {
    $db = $c['settings']['db'];
    $pdo = new PDO('mysql:host=' . $db['host'] . ';dbname=' . $db['dbname'],
        $db['user'], $db['pass']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    return $pdo;
};
```


### 保存処理を書く
src/routes.php にある、新規作成用ルートの処理に、データベースへの保存処理を追加します。

<p class="list tmp"><span>リスト</span>src/routes.php 保存処理</p>
```
// 新規作成
$app->post('/tickets', function (Request $request, Response $response) {
    $subject = $request->getParsedBodyParam('subject');
    // ここに保存の処理を書く
    $sql = 'INSERT INTO tickets (subject) values (:subject)';
    $stmt = $this->db->prepare($sql);
    $result = $stmt->execute(['subject' => $subject]);
    if (!$result) {
        throw new \Exception('could not save the ticket');
    }

    // 保存が正常にできたら一覧ページへリダイレクトする
    return $response->withRedirect("/tickets");
});
```

コンテナに登録した PDO のオブジェクトは、 $this->db でアクセスできます。

$this->db->prepare() でプリペアドステートメントを用意し、 $stmt->execute() で INSERT 文を実行する、という流れになります。

再度新規作成フォームから適当に件名を入力し、作成ボタンをクリックしてください。

tickets テーブルにレコードが生成されていたら成功です。


## 一覧表示 ##{#p6}

### View ファイルの作成

View ファイルをつくります。

templates/tickets/index.phtml というファイルを作成してください。

<p class="list tmp"><span>リスト</span>templates/tickets/index.phtml</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8"/>
  <title>チケット管理</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="container">
  <h1>チケット管理</h1>
  <div class="card">
    <div class="card-body">
      <h2 class="card-title">チケット一覧</h2>
      <div class="card-text">
        <ul class="list-group">
            <?php foreach ($tickets as $ticket): ?>
              <li class="list-group-item"><?= htmlspecialchars($ticket['subject'], ENT_QUOTES, 'UTF-8', false) ?></li>
            <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
</div>
</body>
</html>
```


### ルーティング関数にチケットの一覧を取得する処理を書く

src/routes.php を開いて、一覧表示用ルーティング関数に処理を追加していきます。

<p class="list tmp"><span>リスト</span>src/routes.php</p>
```
// 一覧表示
$app->get('/tickets', function (Request $request, Response $response) {
    $sql = 'SELECT * FROM tickets';
    $stmt = $this->db->query($sql);
    $tickets = [];
    while($row = $stmt->fetch()) {
        $tickets[] = $row;
    }
    $data = ['tickets' => $tickets];
    return $this->renderer->render($response, 'tickets/index.phtml', $data);
});
```
新規作成のところでは、 INSERT 文を使用しましたが、今度はデータの取得なので SELECT 文を使用します。

今回は SQL に渡すパラメータがないので、 prepare の代わりに query メソッドを使います。

また、データを取得するには fetch メソッドを使います。


### チケットを登録して表示されるか確認しましょう


<http://localhost:8001/tickets/create>に接続して、登録画面を開きます。

データを入力し、作成ボタンをクリックします。

![](tickets_create1.png)


登録したデータが表示されます。

![](tickets_create2.png)


### ヘルパー関数の定義
ページに文字列を表示する際に Slimでは、htmlspecialchars 関数を使わなければいけない、のですが、毎回こんな長ったらしい関数を書いてられない。というわけで、、この処理を関数化してしまいましょう。

まず、src/helpers.php というファイルを作成して、以下のように記述してください。

<p class="list tmp"><span>リスト</span>src/helpers.php</p>
```
<?php

if (!function_exists('e')) {
    function e(string $s): string {
        return htmlspecialchars($s, ENT_QUOTES, 'UTF-8', false);
    }
}
```

e という名前の関数が存在しなければ、新たに e という名前の関数を定義します。 PHP では、同名の関数を複数定義すると実行時エラーになってしまうので、このような措置が必要になります。

続いて、 composer.json に以下の記述を追加します（"autoload-dev"の上がいいんじゃないかと思います）。


<p class="list tmp"><span>リスト</span>composer.json</p>
```
"autoload": {
    "files": ["src/helpers.php"]
},
```

これは、アプリケーションの実行時に、自動的に PHP ファイルをロードして、中に書かれた関数を利用できるようにするための記述です。

最後に、ターミナルから以下のコマンドを実行します。

<p class="cmd tmp"><span>コマンド</span></p>
```
composer dump-autoload
```
これで、テンプレートでは以下のように短く書けるようになります。

```
<?php foreach ($tickets as $ticket): ?>
<li class="list-group-item"><?= e($ticket['subject']) ?></li>
<?php endforeach; ?>
```

まず、tickets/index.phtmlの該当箇所を変更してやります。

<p class="list tmp"><span>リスト</span>tickets/index.phtml（16-18行目）</p>
```
<div class="container">
  <h1>チケット管理</h1>
  <div class="card">
    <div class="card-body">
      <h2 class="card-title">チケット一覧</h2>
      <div class="card-text">
        <ul class="list-group">
            <?php foreach ($tickets as $ticket): ?>
                <li class="list-group-item"><?= e($ticket['subject']) ?></li>
            <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
</div>
</body>
</html>
```
ブラウザをリロードして、エラーにならないか確認してください。


### １件表示ページへのリンクを張る
リスト要素をクリックしたら当該チケットの詳細ページへ飛べるようにしていきます。

以下のように、a 要素を追加してリンクが表示されるようにしてください。

<p class="list tmp"><span>リスト</span>tickets/index.phtml（16-18行目）</p>
```
<?php foreach ($tickets as $ticket): ?>
	<li class="list-group-item"><a href="/tickets/<?= $ticket['id'] ?>"><?= e($ticket['subject']) ?></a></li>
<?php endforeach; ?>
```
![](tickets_list1.png)

リンクをクリックして、URLに `http://localhost:8001/tickets/id番号` となればOKです。

### 新規作成ページへのリンクを張る
ついでに、一覧表示ページに新規作成ページへのリンクを張りましょう。

<p class="list tmp"><span>リスト</span>tickets/index.phtml（15行目）</p>
```
<h2 class="card-title">チケット一覧</h2>
<div class="card-text">
<a href="/tickets/create">新規作成</a>
```

![](tickets_list2.png)


### 1件表示
いまはまだ１件表示用のルーティングに何も処理を書いていないので、真っ白なページが表示されています。

ここから、１件表示用の View を実装していきます。

#### View ファイルの作成
templates/tickets/show.phtml というファイルを作成し、以下のように記述してください。

<p class="list tmp"><span>リスト</span>templates/tickets/show.phtml </p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8"/>
  <title>チケット管理</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="container">
  <h1>チケット管理</h1>
  <div class="card">
    <div class="card-body">
      <h2 class="card-title">チケット詳細</h2>
      <div class="card-text">
        <table class="table table-bordered">
          <thead>
          <tr>
            <th>ID</th>
            <th>件名</th>
          </tr>
          </thead>
          <tbody>
          <tr>
            <td><?= e($ticket['id']) ?></td>
            <td><?= e($ticket['subject']) ?></td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>
```

$ticket という変数に、以下のような形式でデータが格納されていることを想定しています。
```
['id' => '1', 'subject' => 'データ名'],
```

### ルーティング関数にチケットデータを取得する処理を書く
続いて、 src/routes.php を開いて、１件表示用のルーティング関数に処理を追加していきます。

p class="list tmp"><span>リスト</span>src/routes.php</p>
```
// 表示
$app->get('/tickets/{id}', function (Request $request, Response $response, array $args) {
    $sql = 'SELECT * FROM tickets WHERE id = :id';
    $stmt = $this->db->prepare($sql);
    $stmt->execute(['id' => $args['id']]);
    $ticket = $stmt->fetch();
    if (!$ticket) {
        return $response->withStatus(404)->write('not found');
    }
    $data = ['ticket' => $ticket];
    return $this->renderer->render($response, 'tickets/show.phtml', $data);
});
```

一覧表示同様、 SELECT 文を使います。

今回は SQL に渡すパラメータがありますので、 prepare メソッドを使います。

{id} という名前付きプレースホルダーが定義されていて、URL に　1 という ID が指定されていれば、id=1 と渡ってきます。これはルーティング関数の第３引数にある $args の中に id というキーで格納されていますので、 $args['id'] で取得することができます。

SQL の実行の際に引数で渡してやりましょう。
```
$stmt->execute(['id' => $args['id']]);
```
一覧表示の際と同様、 fetch メソッドを使って、レコードを取り出します。
```
$ticket = $stmt->fetch();
```

### 表示の確認
#### データが存在する場合
では、一覧表示ページから、リンクをクリックしてみてください。  

「東京オリンピック2020」をクリックしてみます
![](tickets_list3.png)

そうすると、クリックしたデータが表示されます。

![](tickets_list4.png)

#### データが存在しない場合
もし、データが空なら（存在しない ID を指定した場合、など）、 HTTP ステータスコード 404 をブラウザに返してください。

```
return $response->withStatus(404)->write('not found');
```

ためしにブラウザのアドレスバーに <http://localhost:8001/tickets/10> と打ってみてください。

以下のように、「not found」と表示されます。
![](not_found.png)


## PHP-View でパーシャルビュー ##{#p7}
これまで templates 以下に 3 つの View ファイルをつくりました。

その都度、 <!DOCTYPE html> から書いていて、ヘッダーとフッターが重複しています。

多くのテンプレートエンジンに他のテンプレートをインクルードする機能が提供されていますが、 PHP-View にもありますので、共通部分をパーシャルビュー化していきます。

まず、 templates/header.phtml, templates/footer.phtml の2つのファイルを作成してください。

p class="list tmp"><span>リスト</span>templates/header.phtml,（ヘッダー）</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8"/>
  <title>チケット管理</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="container">
  <h1>チケット管理</h1>
```

p class="list tmp"><span>リスト</span>templates/footer.phtml,（フッター）</p>
```
</div>
</body>
</html>
```

では、 create.phtml, index.phtml, show.phtml それぞれのヘッダーフッター部分を以下のように書き換えます。

 create.phtmlの場合
 ```
 <?= $this->fetch('header.phtml') ?>
  <form method="POST" action="/tickets">
<!-- ~中略~ -->
  </form>
<?= $this->fetch('footer.phtml') ?>
 ```

fetch メソッドは、PHP-View のメインクラス（ていうかこれだけしかない）である PhpRenderer クラスのメソッドで、第2引数に連想配列を渡せば、パーシャルビューで使用する変数を定義できます。

```
<?= $this->fetch('partial.phtml', ['name' => $user->name]) ?>
```
ヘッダー・フッター以外にも、複数のページに表示するパーツがあれば、パーシャルビューを使って一元化することができます。


## 編集用フォームの表示 ##{#p8}
### View ファイルの作成
templates/tickets/edit.phtml というファイルを作成し、以下のように記述してください。

<p class="list tmp"><span>リスト</span>templates/tickets/edit.phtml</p>
```
<?= $this->fetch('header.phtml') ?>
  <form method="POST" action="/tickets/<?= e($ticket['id']) ?>">
    <input type="hidden" name="_METHOD" value="patch">
    <div class="card">
      <div class="card-body">
        <h2 class="card-title">チケット編集</h2>
        <div class="card-text">
          <div class="form-group">
            <label for="subject">件名</label>
            <input type="text" name="subject" id="subject" class="form-control" value="<?= e($ticket['subject']) ?>">
          </div>
        </div>
      </div>
      <div class="card-body">
        <button class="btn btn-primary">更新</button>
      </div>
    </div>
  </form>
<?= $this->fetch('footer.phtml') ?>
```

新規作成用フォームとの違い

* form 要素の action が違う
* hidden input 要素が追加されている
* 件名フィールドに value 属性がある

更新用のルーティングは
```
// 更新
$app->patch('/tickets/{id}', function (Request $request, Response $response, array $args) {
```
ですので、 action も /tickets/{id} となっていなくてはいけません（ id の部分には選択したチケットのIDが入ります）。

ポイントは下記で、
<p class="list tmp"><span>リスト</span>templates/tickets/edit.phtml</p>
```
<input type="hidden" name="_METHOD" value="patch">
```
「ルーティング」のところで GET/POST 以外の HTTP メソッドについて触れましたが、ブラウザからフォームデータを送るためには GET か POST でなければいけません。

そこで、擬似的に PUT や DELETE を指定するために、上記のように隠し要素に HTTP メソッド名を入れています（この場合は "patch"）。

この辺の仕組みはフレームワークによって異なりますが、Slim の場合は、 "_METHOD" というフォームデータを送るか、HTTP ヘッダーに "X-Http-Method-Override" というヘッダー要素を入れるかして対応します。


## ルーティング関数にチケットデータを取得する処理を書く ##{#p9}
src/routes.php を開いて、編集用フォームの表示のルーティング関数に処理を追加していきます。

<p class="list tmp"><span>リスト</span>src/routes.php</p>
```
// 編集用フォームの表示
$app->get('/tickets/{id}/edit', function (Request $request, Response $response, array $args) {
    $sql = 'SELECT * FROM tickets WHERE id = :id';
    $stmt = $this->db->prepare($sql);
    $stmt->execute(['id' => $args['id']]);
    $ticket = $stmt->fetch();
    if (!$ticket) {
        return $response->withStatus(404)->write('not found');
    }
    $data = ['ticket' => $ticket];
    return $this->renderer->render($response, 'tickets/edit.phtml', $data);
});
```

1件表示用のものとほぼ一緒です。

違うのは下記の部分（ファイル名）だけ、です。
```
 return $this->renderer->render($response, 'tickets/edit.phtml', $data);
```
では、 <http://localhost:8001/tickets/2/edit>を開いてみてください。

![](tickets_edit1.png)


## 更新 ##{#p10}
### ルーティング関数にチケットデータを更新する処理を書く
続いて、POSTされたデータを元に、データベースに保存されたデータを更新してみます。

更新用のルーティング関数をを以下のように書き換えます。

```
// 更新
$app->patch('/tickets/{id}', function (Request $request, Response $response, array $args) {
    $sql = 'SELECT * FROM tickets WHERE id = :id';
    $stmt = $this->db->prepare($sql);
    $stmt->execute(['id' => $args['id']]);
    $ticket = $stmt->fetch();
    if (!$ticket) {
        return $response->withStatus(404)->write('not found');
    }
    $ticket['subject'] = $request->getParsedBodyParam('subject');
    $stmt = $this->db->prepare('UPDATE tickets SET subject = :subject WHERE id = :id');
    $stmt->execute($ticket);
    return $response->withRedirect("/tickets");
});
```

1件表示と新規作成のミックス、みたいなかんじですね。

処理の流れは、

* URL の名前付きプレースホルダーから id を取得
* その id を持つチケットのレコードを取得（SELECT）
* subject を POST されたデータで 2 のレコードを更新（UPDATE）
* 一覧ページへリダイレクト

となります。


### 1件表示ページに編集ページへのリンクを張る
最後に仕上げです。

show.phtml に以下の HTML 要素を追加してください。
```
<tfoot>
    <tr>
        <td colspan="2">
        	<a href="/tickets/<?= e($ticket['id']) ?>/edit" class="btn btn-primary">編集</a>
        </td>
    </tr>
</tfoot>
```


## 削除 ##{#11}
最後の機能は削除です。

### View ファイルの編集
今回は、View の編集からやります。

show.phtml に以下の要素を追加してください。

削除ボタン
```
<a href="/tickets/<?= e($ticket['id']) ?>/edit" class="btn btn-primary">編集</a>
<button class="btn btn-danger" data-toggle="modal" data-target="#deleteModal">削除</button>
```

モーダルダイアログ
```
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
	<div class="modal-content">
	<div class="modal-header">
		<h5 class="modal-title">チケットの削除</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
		</button>
	</div>
	<div class="modal-body">
		<p>本当に削除してよろしいですか？</p>
	</div>
	<form method="post" action="/tickets/<?= e($ticket['id']) ?>">
		<input type="hidden" name="_METHOD" value="delete">
		<div class="modal-footer">
		<button type="submit" class="btn btn-danger">削除</button>
		<button type="button" class="btn btn-secondary" data-dismiss="modal">キャンセル</button>
		</div>
	</form>
	</div>
</div>
</div>
<?= $this->fetch('footer.phtml') ?>
```

ここでは "_METHOD" は "delete' です。
```
<input type="hidden" name="_METHOD" value="delete">
```
Bootstrap のモーダルダイアログを使いますので、 jquery と bootstrap の JS ファイルを読み込むようにします。

footer.phtml に入れてしまいましょう。
```
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
```


### ルーティング関数にチケットデータを削除する処理を書く

```
// 削除
$app->delete('/tickets/{id}', function (Request $request, Response $response, array $args) {
    $sql = 'SELECT * FROM tickets WHERE id = :id';
    $stmt = $this->db->prepare($sql);
    $stmt->execute(['id' => $args['id']]);
    $ticket = $stmt->fetch();
    if (!$ticket) {
        return $response->withStatus(404)->write('not found');
    }
    $stmt = $this->db->prepare('DELETE FROM tickets WHERE id = :id');
    $stmt->execute(['id' => $ticket['id']]);
    return $response->withRedirect("/tickets");
});
```

ポイントは DELETE 文ですね。
```
$stmt = $this->db->prepare('DELETE FROM tickets WHERE id = :id');
$stmt->execute(['id' => $ticket['id']]);
```
いちおう処理の流れを書いておくと、

* URL の名前付きプレースホルダーから id を取得
* その id を持つチケットのレコードを取得（SELECT）
* 2 のレコードを削除（DELETE）
* 一覧ページへリダイレクト

となります。


![](tickets_delete0.png)

![](tickets_delete1.png)

では、モーダルダイアログの「削除」ボタンをクリックしてみましょう。

![](tickets_delete2.png)

![](tickets_delete3.png)


次は、肥大化した routes.php をスリムにするため、Controller クラスを作成してみます。

## Controller クラスの導入 ##{#p12}
### 独自クラスを使うための準備
composer.json を開いて、以下の記述を追加します（"psr-4" のセクションです）。

<p class="list tmp"><span>リスト</span>composer.json</p>
```
    "autoload": {
        "psr-4": {
            "Classes\\": "src/classes/"
        },
        "files": ["src/helpers.php"]
    },

```
続いて、 src/classes というディレクトリを作成してください。

これで、 src/classes 配下に作成したPHPのクラスは、以下のように use 文を書くことで、他のPHPファイルから参照できるようになりました。

```
use Classes\SomeClass;
```

### Controller 抽象基底クラスの作成
抽象基底クラスとは、直接インスタンス化することはできず、継承した子クラスを通してのみ利用できるクラスのことです。

簡単な例を書くと、
```
// 抽象基底クラスの宣言
abstract class AbstractClass
{
    public function doSomething()
    {
        // 何かの処理
    }
}

// 継承した子クラス
class Child extends AbstractClass
{
}

// $abstractClass = new AbstractClass(); <-- エラー
$child = new Child(); // <-- OK
$child->doSomething(); // 抽象基底クラスの処理を実行可能
```

今回の修正の目的は、 src/routes.php にずらずらと処理を書いてきた結果、行数が多くなってしまったのと、処理の重複がいくつかあって、保守性が下がってしまう恐れがあるので、クラス化してオブジェクト指向プログラミングできるようにしていこう、というものです。

では、 src/classes の下に Controllers というディレクトリを作成し、Controller.php というファイルを追加してください。

<p class="list tmp"><span>リスト</span> src/classes/Controllers/Controller.php</p>
```

<?php

namespace Classes\Controllers;

use Psr\Container\ContainerInterface;
use Slim\Views\PhpRenderer;

abstract class Controller
{
    /** @var \PDO */
    protected $db;
    /** @var PhpRenderer */
    protected $renderer;

    public function __construct(ContainerInterface $container)
    {
        $this->db = $container['db'];
        $this->renderer = $container['renderer'];
    }
}
```
Slim Framework では、 Controller クラスのコンストラクタにコンテナを渡してくれるので、そこから必要なコンポーネントを受け取ってプロパティに入れます。

これらのオブジェクトに何が入っているかは、 src/dependencies.php を見てください（renderer と db の箇所を抜粋します）。


```
// view renderer
$container['renderer'] = function ($c) {
    $settings = $c->get('settings')['renderer'];
    return new Slim\Views\PhpRenderer($settings['template_path']);
};

// database
$container['db'] = function ($c) {
    $db = $c['settings']['db'];
    $pdo = new PDO('mysql:host=' . $db['host'] . ';dbname=' . $db['dbname'],
        $db['user'], $db['pass']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    return $pdo;
};
```

PhpRenderer クラスのインスタンスと PDO クラスのインスタンスがそれぞれ renderer と db に入ってきます（見て分かるとおり、厳密には関数が登録されていますが、これは最初にコンポーネントにアクセスされるとこの関数が呼び出され、戻り値を登録し直すようになっているので、あまり気にしなくて大丈夫と思います）。

今は、各関数の戻り値がコンテナに入っている、ということだけ覚えておいてください。

さて、これで、Controller クラスを継承したクラスから、 $this->db や $this->renderer という形で、それぞれ呼び出せるようになりましたので、各ルーティング関数を Controller クラスのメソッドに移動していきましょう。


### TicketsController クラスの作成
src/classes/Controllers の下に TicketsController.php というファイルを作成してください。

```
<?php

namespace Classes\Controllers;

use Slim\Http\Request;
use Slim\Http\Response;

class TicketsController extends Controller
{
    public function index(Request $request, Response $response)
    {
    }
}
```

### ルーティング関数から Controller クラスのメソッドへ処理を移す
一覧表示のルートを例に取って手順を示します。

現在の src/routes.php では以下のようになっています。
```
$app->get('/tickets', function (Request $request, Response $response) {
    $sql = 'SELECT * FROM tickets';
    $stmt = $this->db->query($sql);
    $tickets = [];
    while($row = $stmt->fetch()) {
        $tickets[] = $row;
    }
    $data = ['tickets' => $tickets];
    return $this->renderer->render($response, 'tickets/index.phtml', $data);
});
```
これを TicketsController クラスの index メソッドに移していきます。

<p class="list tmp"><span>リスト</span>TicketsController（一覧表示）</p>
```
    public function index(Request $request, Response $response)
    {
        $sql = 'SELECT * FROM tickets';
        $stmt = $this->db->query($sql);
        $tickets = [];
        while($row = $stmt->fetch()) {
            $tickets[] = $row;
        }
        $data = ['tickets' => $tickets];
        return $this->renderer->render($response, 'tickets/index.phtml', $data);
    }
```

続いて、 src/routes.php へ戻り、以下のように書き換えます。


<p class="list tmp"><span>リスト</span>src/routes.phpにuse 文を追加</p>
```
<?php

use Slim\Http\Request;
use Slim\Http\Response;
use Classes\Controllers\TicketsController;
```
ポイントは :index の部分で、を忘れないようにしてください。  
これで、いままでは  
「/tickets という URL に GET アクセスが来たら、第2引数に書かれた関数を実行する」  
という処理でしたが、

「/tickets という URL に GET アクセスが来たら、TicketsController クラスの index メソッドを実行する」  
というように変更されます。

getの第2引数を変更
```
// 一覧表示
$app->get('/tickets', TicketsController::class . ':index');
```

<http://localhost:8001/tickets>に接続して、同じように「チケット一覧」ページが表示できればOKです。  

![](tickets_list5.png)

うまく表示されない場合は、コマンドでキャッシュ削除を行ってください。


同じように、他のもTicketsController.phpへメソッドを移動して、routes.phpを以下のように書き換えて下さい。

<p class="list tmp"><span>リスト</span>src/routes.php</p>
```
<?php

use Slim\Http\Request;
use Slim\Http\Response;
use Classes\Controllers\TicketsController;

// Routes

// 一覧表示
$app->get('/tickets', TicketsController::class . ':index');

// 新規作成用フォームの表示
$app->get('/tickets/create', TicketsController::class . ':create');

// 新規作成
$app->post('/tickets', TicketsController::class . ':store');

// 表示
$app->get('/tickets/{id}', TicketsController::class . ':show');

// 編集用フォームの表示
$app->get('/tickets/{id}/edit', TicketsController::class . ':edit');

// 更新
$app->patch('/tickets/{id}', TicketsController::class . ':update');

// 削除
$app->delete('/tickets/{id}', TicketsController::class . ':delete');

$app->get('/[{name}]', function (Request $request, Response $response, array $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});
```



## 重複した処理を共通化する ##{#p13}
### チケットの取得処理を別メソッドに切り出す
TicketsController を見ると、以下の処理があちこちで使われていますので、これをメソッドに切り出します。

```
$sql = 'SELECT * FROM tickets WHERE id = :id';
$stmt = $this->db->prepare($sql);
$stmt->execute(['id' => $args['id']]);
$ticket = $stmt->fetch();
if (!$ticket) {
    return $response->withStatus(404)->write('not found');
}
```

最後の三行は重複してはいますが、レスポンスを返す処理なので呼び出し側に残しておいた方がいいですね。

```
    private function fetchTicket($id): array
    {
        $sql = 'SELECT * FROM tickets WHERE id = :id';
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $id]);
        $ticket = $stmt->fetch();
        if (!$ticket) {
            throw new \Exception('not found');
        }
        return $ticket;
    }
```

呼び出し側はこうなります（show メソッドを例に取ります）。
```
    public function show(Request $request, Response $response, array $args)
    {
        try {
            $ticket = $this->fetchTicket($args['id']);
        } catch (\Exception $e) {
            return $response->withStatus(404)->write($e->getMessage());
        }
        $data = ['ticket' => $ticket];
        return $this->renderer->render($response, 'tickets/show.phtml', $data);
    }
```
edit, update, delete も同様に置き換えてみてください。



<p class="list tmp"><span>リスト</span>TicketsController.php</p>
```
// 新規作成用フォームの表示
public function create(Request $request, Response $response) {
    return $this->renderer->render($response, 'tickets/create.phtml');
}

//新規作成
public function store(Request $request, Response $response) {
    $subject = $request->getParsedBodyParam('subject');
    // ここに保存の処理を書く
    $sql = 'INSERT INTO tickets (subject) values (:subject)';
    $stmt = $this->db->prepare($sql);
    $result = $stmt->execute(['subject' => $subject]);

    // 保存が正常にできたら一覧ページへリダイレクトする
    return $response->withRedirect("/tickets");
}

//表示
public function show(Request $request, Response $response, array $args){
    try {
        $ticket = $this->fetchTicket($args['id']);
    } catch (\Exception $e) {
        return $response->withStatus(404)->write($e->getMessage());
    }
    $data = ['ticket' => $ticket];
    return $this->renderer->render($response, 'tickets/show.phtml', $data);
}


//編集
public function edit(Request $request, Response $response, array $args) {
    try {
        $ticket = $this->fetchTicket($args['id']);
    } catch (\Exception $e) {
        return $response->withStatus(404)->write($e->getMessage());
    }

    $data = ['ticket' => $ticket];
    return $this->renderer->render($response, 'tickets/edit.phtml', $data);
}

//更新
public function update(Request $request, Response $response, array $args) {
    try {
        $ticket = $this->fetchTicket($args['id']);
    } catch (\Exception $e) {
        return $response->withStatus(404)->write($e->getMessage());
    }

    $ticket['subject'] = $request->getParsedBodyParam('subject');
    $stmt = $this->db->prepare('UPDATE tickets SET subject = :subject WHERE id = :id');
    $stmt->execute($ticket);
    return $response->withRedirect("/tickets");
}

//削除
public function delete(Request $request, Response $response, array $args) {
    try {
        $ticket = $this->fetchTicket($args['id']);
    } catch (\Exception $e) {
        return $response->withStatus(404)->write($e->getMessage());
    }

    $stmt = $this->db->prepare('DELETE FROM tickets WHERE id = :id');
    $stmt->execute(['id' => $ticket['id']]);
    return $response->withRedirect("/tickets");
}

private function fetchTicket($id): array
{
    $sql = 'SELECT * FROM tickets WHERE id = :id';
    $stmt = $this->db->prepare($sql);
    $stmt->execute(['id' => $id]);
    $ticket = $stmt->fetch();
    if (!$ticket) {
        throw new \Exception('not found');
    }
    return $ticket;
}
```
















