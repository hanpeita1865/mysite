<?php
require_once("vendor/autoload.php");
$loader = new \Twig\Loader\FilesystemLoader("templates");
$twig = new \Twig\Environment($loader);

//値を配列に格納
$assign["items"] = [
    'tokyo' => '東京',
    'shibuya' => '渋谷',
    'harajuku' => '原宿',
    'yoyogi' => '代々木',
];

echo $twig->render("keyValue.twig", $assign);

