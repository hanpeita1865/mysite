---
title: (移動済)例外処理(try...catch、throw)
taxonomy:
    category:
        - docs
visible: true
---

## 例外処理を付ける

<p class="tmp"><span>書式1</span>try...catch構文</p>
```
try {
   実行する処理
} catch ( 例外のクラス 変数 ) {
   実行する処理
} finally{
 実行する処理
}
```
* 例外が起こる可能性がある箇所をtryブロックで囲みます。
* 例外が発生しcatchブロックの引数の例外のクラスの型と同じときにcatchブロックの処理が行われます。
* PHP 5.5 以降ではfinallyブロックも指定できます。finallyブロックは例外のあるなしにかかわらず常に実行されます。
* 以下はPHPマニュアルの例外(exceptions)のリンクです。

<https://www.php.net/manual/ja/language.exceptions.php>


<p class="tmp"><span>書式2</span>throw文</p>
```
throw new 例外
```
* 任意の場所で例外を投げることができます。
* 例外は以下である必要があります。
	* Exceptionクラス
	* Exceptionクラスのサブクラス

try...catch構文とthrow文のサンプルです。  
$num2に0を設定すると、例外処理が実行され「エラーです」が付け足されます。
<!--
<iframe src="https://paiza.io/projects/e/gVzMc4SshnEvE6iAhBSzrA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
-->
<iframe src="https://paiza.io/projects/e/76_RguPPjAbu47zIAnWPqg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

* 6行目は、例外が起こる可能性がある関数をtryブロックで囲んでいます。
* 16行目は、throw文で例外を投げています。Javaと違いここでthrowが必要です。
* 9行目は、例外をcatchしメッセージを表示します。「エラーです」
* 12行目は、finallyブロックでメッセージが表示されます。「処理が終了しました」