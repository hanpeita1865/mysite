*[page-title]:Mapオブジェクトについてと使い方

参考サイト
: [mdn_web_docs Map](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Global_Objects/Map)
: [【JavaScript】オブジェクトより便利かも！？ Map を使ってみよう！](https://www.agent-grow.com/self20percent/2019/06/24/lets-use-map-in-js/)
: [Mapオブジェクトに関して](https://zenn.dev/oreo2990/articles/74ad47c58d299f)

## Mapとは?
Mapは、Objectに似たキーと値をもつデータのコレクションです。Objectとは主に下記のような違いがあります。

<div markdown="1" class="numbold">
1. キーにString以外を設定することができる
1. キーの列挙順が保証されている
1. 要素数の取得が簡単
1. 直接的に反復処理が可能
</div>


## Mapの主なメソッド

new Map()
: mapコンストラクターからインスタンス化を行い、 mapオブジェクトを作成できる。

map.set(key, value)
: .setメソッドの第1引数にキー、第2引数に値をそれぞれ渡して設定することができる。

map.get(key)
: .getメソッドで、引数として渡したキーの値を取得できる。

map.delete(key)
: .deleteメソッドで、引数として渡したキーの値を削除できる。

map.entries()
: .entriesメソッドで、mapの要素であるキーと値を含んだイテレーター(反復可能オブジェクト)を返す。

map.size
: .sizeメソッドで、mapの要素数を取得できる。

map.forEach((val,key)=>{})
: .forEachメソッドで、反復処理が実行可能。