<?php
require 'frat_create.php';//pages_copyにフラットなフォルダ構成を作成

require 'create.php';//フォルダ構成生成

require 'folder_complist.php';//メニュー生成
?>