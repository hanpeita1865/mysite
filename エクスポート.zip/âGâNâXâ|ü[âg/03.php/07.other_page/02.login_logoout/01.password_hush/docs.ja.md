---
title: パスワード暗号化
taxonomy:
    category:
        - docs
---

## 暗号化

参考サイト
: https://www.pnkts.net/2021/01/03/php-password


<p class="tmp list"><span>リスト</span>hash/index.phpl</p>
[新規タブ](../../../../sample/php/password/hash/index.php?target=_blank)
```
<?php
/**
 * デフォルトのアルゴリズムを使ってパスワードをハッシュします。
 * 現時点でのデフォルトは BCRYPT で、その結果は 60 文字になります。
 *
 * デフォルトは、今後変わる可能性があることに注意しましょう。結果が
 * 60 文字以上になっても対応できるようにしておきましょう (255 あたりが適切です)
 */
echo password_hash("Zenn", PASSWORD_DEFAULT);
?>
```

「Zenn」が「$2y$10$LatOkFeKsvQAeJJp6n1a8e79IuwTaCdgpdG5dsDUDyqJ69HzU3bdq」に変換されます。


<p class="tmp list"><span>リスト</span>hash/index1.php</p>
[新規タブ](../../../../sample/php/password/hash/index1.php?target=_blank)
```
<?php
/**
 * この例では、BCRYPT のコストをデフォルトより上げて、12 にします。
 * また、アルゴリズムを BCRYPT に変えたことにも注目しましょう。結果は常に 60 文字になります。
 */
$options = [
    'cost' => 12,
];
echo password_hash("ryouma1222", PASSWORD_BCRYPT, $options);
?>
```

「ryouma1222」が「$2y$12$Gr3OxQgmNNP9FewhmImWVu47BNOEvkLLheUMxIQdmGSJhwXdfmx6W」に変換されます。



<p class="tmp list"><span>リスト</span>hash/index3.php</p>
[新規タブ](../../../../sample/php/password/hash/index3.php?target=_blank)
```
<?php
$str = 'ryouma1222';
echo hash("sha256", $str);
?>
```
「ryouma1222」が「22569207e72e3207ef28af7b2fe2cf913fe6e676373fcb8e4233e7c7b8ee967b」に変換されます。

