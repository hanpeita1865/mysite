<template>
  <div class="container-fluid">
    <h1 class="text-danger">Index Page</h1>
    <NuxtLink to="/secondpage">Second Pageへ</NuxtLink>
  </div>
</template>
<script setup>
definePageMeta({
  layout: "custom",
});
</script>