---
title: '06. メニュー'
taxonomy:
    category:
        - docs
---

## ドロップダウンメニュー
(キーボード操作可能)  
**transitionend**を使用しています。  
[新規タブ](../../../sample/jQuery/sample(menu)1/index.html?target=_blank)

<iframe width="100%" height="500" src="//jsfiddle.net/qrejk76h/embedded/result,html,css,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## グローバルメニュー
(キーボード操作可能　新規ウィンドウメニュー有り 一つ目)  
**transitionend**を使用しています。  
[新規タブ](../../../sample/jquery/sample(menu_wintab)4/index.html?target=_blank)

<iframe width="100%" height="500" src="//jsfiddle.net/dx8rv9nq//embedded/result,html,css,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>



## サイドメニュー

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
外部ファイルからサイドメニューも読み込んでいます。  
サブメニューは、ページ内リンクのページと画面遷移するページの両方に対応しています。   
※ただし、サブメニューがある前提で作っているので、サブメニューがない場合は、サイドメニューは表示されません。

[新規タブ](../../../sample/jquery/sample(sidemenu)1/index.html?target=_blank)
<iframe width="100%" height="750" src="../../sample/jquery/sample(sidemenu)1/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


<div class="box-example" markdown="1">
### 例2 ### {.h-example}
サイドメニューがサブメニューのない第2階層までや、第4階層までサブメニューがある場合にも対応しています。

[新規タブ](../../../sample/jquery/sample(sidemenu)2/index.html?target=_blank)
<iframe width="100%" height="750" src="../../sample/jquery/sample(sidemenu)2/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

#### 読み込み時JS

```
//サイドメニュー読み込み
$.ajax({
	url: partsPath + 'side_menu.html',
	type: 'GET',
	dataType: 'html',
	cache: false
}).done(function(data){

	//---読み込み時のサブメニュー設定---//
	var url = location.href;//ページのURLを取得

	if ($(data).find('.sub-dropdown ul li a').length){//サブメニューがある場合(第3階層、第4階層がある)

		switch (dirLevel) {
			case 4:	// 第4階層
				var subLink = '.sub-dropdown ul li ul li a';
				break;
			default :// 第1,2,3階層
				var subLink = '.sub-dropdown > ul > li > a';
				break;
		}

		var dataAdd = $(data).find(subLink).each(function(){//読み込んだ時の先にクリックしたメニューの開閉とアクティブ処理
			var path = $(this).attr('href');//クリックしたサブメニューのパスを取得

			if(~url.indexOf(path)){
				$(this).closest('.sub-dropdown > ul').addClass('is-open');//is-openをつけて、メニューを開いておく
				//$(this).closest('ul').css('display','block');
				$(this).addClass('is-active');//サブメニューをアクティブにする
			}
		})

		var dataAdd1 = $(dataAdd).parents('.side-menu');

	}else{//サブメニューがない場合(第2階層まで)
		dataAdd1 = $(data);
	}

	$('#side-box').html(dataAdd1);//サブメニューを表示
```

#### クリックしたときの開閉処理

```
	//---サブメニューをクリックしたときの処理---//
	$('.sub-dropdown ul li a').click(function() {//サブメニューをクリックした場合(同一メニューは画面遷移しない)
		var url = location.href;//ページのURLを取得
		var path = $(this).prop('href');//クリックしたサブメニューのパスを取得		
		var pathname = path.split("#");//ハッシュの部分は取り除く

		$('.sub-dropdown ul li a').removeClass('is-active');
		$('.sub-dropdown ul').removeClass('is-open');

		if(!url.indexOf(pathname[0])){
			$(this).closest('ul').addClass('is-open');//is-openをつけて、メニューを開いておく
			$(this).addClass('is-active');//サブメニューをアクティブにする
		}	
	});


	$('.sub-dropdown').each(function(){	//サブメニューが8個を超えると、スクロールバーを表示		
		var listNum = $(this).find('ul li').length;
		if(listNum > 8){
			 $('.sub-dropdown ul').css('height','480px');
		}			
	})

	//------- アコーディオン -------//
	$('.sub-dropdown > a').on('click', function() {
		$(this).addClass('is-active');
		$(this).next('ul').toggleClass('is-open');
		$('li[class!="sub-dropdown"]').children('.side-menu__title').removeClass('is-active');

		return false;
	});	

```