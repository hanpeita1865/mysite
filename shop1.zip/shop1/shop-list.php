<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop1;charset=utf8', 'staff', 'password');

// foreach ($pdo->query('select * from products') as $row) {
// 	echo '<p>';
// 	echo $row['id'], ':';
// 	echo $row['name'], ':';
// 	echo $row['price'];
// 	echo '</p>';
// }

foreach ($pdo->query('select * from products') as $row): ?>
	<p><?= $row['id'] ?>:<?= $row['name'] ?>:<?= $row['price'] ?></p>
<?php endforeach ?>