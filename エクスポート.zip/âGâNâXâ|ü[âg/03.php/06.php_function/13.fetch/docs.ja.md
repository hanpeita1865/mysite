---
title: (移動済)fetch
taxonomy:
    category:
        - docs
media_order: 'データベースサンプル.png,fetchfetch_both.png,fetch_ascot.png,fetch_num.png,fetchAll_ascot.png,fetchAll_num.png'
---

## 参考サイト

* [わかっているようでわからない、PHPのFETCHを解説！](https://takablog06.com/php_fetch_for_beginner/)

データの取り方は主に４種類。でもよく使うのは２つ。
データを取ってくる方法は主に次の４つです。

※()にあるのは、公式のリンクとなっています。

 

* fetch・・・該当するデータを1行返す。(fetch)
* fetchAll・・・該当するすべてのデータを配列で返す。(fetchAll)
* fetchColumn・・・該当するデータから単一のカラムを返す。(fetchColumn)
* fetchObject・・・該当するデータを1行取得して、それをオブジェクトとして返す。(fetchObject)


このうち、よく使用されるのは「fetch」と「fetchAll」です。


<定義済み定数の種類>
: PDO::FETCH_ASSOC・・・結果セットに 返された際のカラム名で添字を付けた配列を返します。
: PDO::FETCH_BOTH (デフォルト)・・・結果セットに返された際のカラム名と 0 で始まるカラム番号で添字を付けた配列を返します。
: PDO::FETCH_NUM・・・結果セットに返された際の 0 から始まるカラム番号を添字とする配列を返します。
 
 ※上記で上記で紹介した定数は「fetch」と「fetchAll」で使用できる定数となります。
 
 ※またこれ以外にもまだまだ種類はたくさんありますが、今回はあえて３つに絞ってご紹介してます。
 
 ## データベースから取得
 
 ![%E3%83%87%E3%83%BC%E3%82%BF%E3%83%99%E3%83%BC%E3%82%B9%E3%82%B5%E3%83%B3%E3%83%97%E3%83%AB](%E3%83%87%E3%83%BC%E3%82%BF%E3%83%99%E3%83%BC%E3%82%B9%E3%82%B5%E3%83%B3%E3%83%97%E3%83%AB.png "%E3%83%87%E3%83%BC%E3%82%BF%E3%83%99%E3%83%BC%E3%82%B9%E3%82%B5%E3%83%B3%E3%83%97%E3%83%AB")
 
 ### fetch(PDO::FETCH_BOTH)
 ```
 $result = $stmt->fetch(PDO::FETCH_BOTH); 
 ```
 
 <p class="tmp">取得データ</p>
 ![fetchfetch_both](fetchfetch_both.png "fetchfetch_both")
 
 ### fetch(PDO::FETCH_ASSOC)
 
 ```
 $result = $stmt->fetch(PDO::FETCH_ASSOC); 
 ```
  <p class="tmp">取得データ</p>
 ![fetch_ascot](fetch_ascot.png "fetch_ascot")
 ```
 
 ### fetch(PDO::FETCH_NUM);
 
 $result = $stmt->fetch(PDO::FETCH_NUM); 
 ```
  <p class="tmp">取得データ</p>
 ![fetch_num](fetch_num.png "fetch_num")
 
 
 ## fetchAll
 
 ### fetchAll(PDO::FETCH_ASSOC)
 
 ```
 $result = $stmt->fetchAll(PDO::FETCH_ASSOC); 
 ```
 ![fetchAll_ascot](fetchAll_ascot.png "fetchAll_ascot")
 
 ### fetchAll(PDO::FETCH_NUM)
 
 ```
 $result = $stmt->fetchAll(PDO::FETCH_NUM); 
 ```
 ![fetchAll_num](fetchAll_num.png "fetchAll_num")
 
 
 
 
 