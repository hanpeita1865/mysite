---
title: Slim(フレームワーク)
taxonomy:
    category:
        - docs
media_order: 'slim_composer.png,slim_folder.png,slim_filelist.htm,hello_test.png,slim_started.png,hello_test.png'
---

世の中にあるフレームワークは軽量フレームワーク・フルスタックフレームワークの2種類に分類できると思われます。  
Slimは、軽量フレームワークです。

公式サイト
: <https://www.slimframework.com/>

## 軽量フレームワーク
軽量フレームワークはRequestやResponse処理、ミドルウェア、ルーティングの機能など最小限Webをフレームワークで管理するために必要な機能のみを提供してくれる。

最小限の機能のみしか提供されていないので、それ以外の実装はすべて、フレームワーク利用者がコンポーネント部品を作ることになる。

また、フレームワーク自体のカスタマイズ性も高く、開発者の使いたい環境にカスタマイズできる。


## 学習コスト
まず、フルスタックフレームワークは学習コストの壁がある。  
実装されている機能が多いということはその機能を把握しなければいけないという問題が出てくる。  
理解していない機能を使うとたちまちフレームワークのエラー画面に大量のエラーが出てそれをググりながら修正するという無駄しか出てこない。

それに比べて軽量フレームワークは最小限の機能しかないため、学習コストはほとんどない。  
Slim3フレームワークはリファレンス自体も1日あれば全て読めるだろう。

## 階層問題
フルスタックフレームワークは様々な階層を経由してプログラムが実行される。  
そのため、適切な階層でサービスプロバイダーやViewコンポーザの処理をしないといけない。  
その階層構造と実行順序を理解するまでにかなり時間がかかる。  

軽量フレームワークは通過する階層が浅いので、階層構造をあまり意識しまくても利用できる。


## 実装方法

任意の場所に、testSlimフォルダを作成する。ここでは、htdocsの直下に作成しました。

testSlimフォルダの中に、publicフォルダを作成し、そこにindex.phpを配置します。そして、下記のコードを記入します。

<p class="tmp list"><span>リスト</span>index.php</p>
```
<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require __DIR__ . '/../vendor/autoload.php';

$app = new \Slim\App;
$app->get('/hello/{name}', function (Request $request, Response $response) {
    $name = $request->getAttribute('name');
    $response->getBody()->write("Hello, $name");

    return $response;
});
$app->run();
```

最後にルートディレクトリ（testSlim）に戻って、以下のコマンドを実行してSlim3フレームワークのライブラリをcomposerを使ってダウンロードします。

![](slim_composer.png)

ダウンロードされたtestSlimの中のフォルダ構成は、以下のようになります。

![](slim_folder.png)

[testSlimフォルダ構成詳細](slim_filelist.htm?target=_blank)


これでSlim3に依存する6つのライブラリをダウンロードできたので、実際に実行してみます。  
実行するときには以下のコマンドを実行し、ビルトインウェブサーバーを起動します。

<p class="tmp cmd"><span>コマンド</span>ビルトインウェブサーバー</p>
```
php -S localhost:8080 -t public public/index.php
```

![](slim_started.png)


そして、 <http://localhost:8080/hello/test> にアクセスする。  
すると、「Hello, test」と表示されます。

![](hello_test.png)



## ルーティングテーブルをLaravel風にする
今の実装だとルーティングをindex.phpに全て記述してしまうため、エンドポイントが増えたときにindex.phpが肥大化するので、ルートディレクトリにRoutes.phpを置くことにする。

また、ルーティングテーブルにクロージャを書くと同様にルーティングテーブルが肥大化してしまうので、Controllerに投げるようにする。  
Controllerディレクトリをそのために作成する


public/index.php
```
<?php

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../Controller/SampleController.php';
require __DIR__ . '/../Routes.php';

```

Routes.php
```
<?php

$app = new \Slim\App;
$app->get('/hello/{name}', SampleController::class . ':index');
$app->run();
```

Controller/SampleController.php
```
<?php

use Slim\Http\Request;
use Slim\Http\Response;

class SampleController
{
    public function index(Request $request, Response $response)
    {
        $name = $request->getAttribute('name');
        $response->getBody()->write("Hello, $name");
        return $response;
    }
}
```

このようにルーティングテーブルを一つのエンドポイントごとに1行にまとめると使いやすくなる。  
ディレクトリ構成は以下の通りである。

```
.
├── Controller
│   └── SampleController.php
├── Routes.php
├── composer.json
├── composer.lock
├── public
│   └── index.php
└── vendor
    └── 省略
 ```

## WebAPIを作ってみよう
Slim3の特徴はなんといってもWebAPIの実装の容易さである。  
素早く安全なWebAPIを作るならSlim3を是非オススメする。

まず、Controller/SampleController.phpを少し修正してみる。  
WebAPIは最近ではjsonで一般的にやり取りされるので、送信データをjsonにする。  
といっても、元々SlimにはwithJson()メソッドがResponseオブジェクトにあるため、それを呼び出して配列を引数に取るだけで使える。

では早速、Controller/SampleController.phpを修正しよう！

Controller/SampleController.php
```
<?php

use Slim\Http\Request;
use Slim\Http\Response;

class SampleController
{
    public function index(Request $request, Response $response)
    {
        $name = $request->getAttribute('name');
        $response = $response->withJson(["response" => "Hello, $name"], 200);
        return $response;
    }
}
```

それではビルトインウェブサーバーを起動して実際に確認してみよう！  
以下のレスポンスデータが受け取れるはずだ。

これでWebAPIも作成できた。




## Viewにテンプレートエンジンを使う

***※Bladeは一旦保留***

Viewに関してはとくに今まで記載していなかったが、動的なWebページを作成する場合にテンプレートエンジンというPHPを直書きするのではなく、もう少し人間にわかりやすい形でViewを作成する方法がある。実際にはそのファイルを読み込む時にphpのプログラムにコンパイルする仕組みである。

今回はこのテンプレートエンジンの中でもBladeというLaravelに採用されているテンプレートエンジンをSlim3で読み込んでみる。


### Bladeの設定
まず、Bladeのライブラリをダウンロードします。

<p class="tmp cmd"><span>コマンド</span>Bladeインストール</p>
```
composer require rubellum/slim-blade-view
```
インストールが完了したら、

Routes.phpとController/SampleController.phpを書き換える。  
views/sample.blade.phpを新規で作成する。  
viewsとcacheディレクトリは新規で作成しとく！


Routes.php
```
<?php

$config = [
    'settings' => [
        'displayErrorDetails' => true, 
        'renderer'            => [
            'blade_template_path' => __DIR__ . '/views',
            'blade_cache_path'    => __DIR__ . '/cache', 
        ],
    ],
];

$app = new \Slim\App($config);

$container = $app->getContainer();

$container['view'] = function ($container) {
    return new \Slim\Views\Blade(
        $container['settings']['renderer']['blade_template_path'],
        $container['settings']['renderer']['blade_cache_path']
    );
};

$app->get('/hello/{name}', SampleController::class . ':index');

$app->run();
```

Controller/SampleController.php
```
<?php

use Slim\Container;
use Slim\Http\Request;
use Slim\Http\Response;

class SampleController
{
    private $app;

    public function __construct(Container $app)
    {
        $this->app = $app;
    }

    public function index(Request $request, Response $response)
    {
        $name = $request->getAttribute('name');
        $array = ['test' => "Hello, $name"];
        return $this->app->view->render($response, 'sample', $array);
    }
}
```

views/sample.blade.php
```
{{$test}}
```



