<?php
$post_dir = $_POST['post_dir'];
$post_redir = $_POST['post_redir'];

//フォルダ名変更
rename('../pages/' . $post_dir, '../pages/' . $post_redir);
echo 'フォルダ名を変更しました。';
?>
