<?php
use SocymSlim\SlimMiddle\controllers\SlimMiddleController;

use SocymSlim\SlimMiddle\controllers\AdminController;
use SocymSlim\SlimMiddle\controllers\EditController;
use SocymSlim\SlimMiddle\controllers\SearchController;
use SocymSlim\SlimMiddle\middlewares\UserCheck;

use SocymSlim\SlimMiddle\controllers\PreviewController;

use SocymSlim\SlimMiddle\middlewares\EventLog;

use SocymSlim\SlimMiddle\middlewares\RecordIPAddressToLog;
use SocymSlim\SlimMiddle\middlewares\RecordIPAddressBefore;
use SocymSlim\SlimMiddle\middlewares\CheckIPAddressBefore;
use SocymSlim\SlimMiddle\middlewares\FolderCount;
use SocymSlim\SlimMiddle\middlewares\PagesCopyEmptyCheck;

use SocymSlim\SlimMiddle\middlewares\CheckIPAddress;

require 'admin/basepath.php';

$app->setBasePath($basePath."/public");

$app->any("/pages/{folderName}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/{folderName6}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/{folderName6}/{folderName7}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/{folderName6}/{folderName7}/{folderName8}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/{folderName6}/{folderName7}/{folderName8}/{folderName9}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/{folderName6}/{folderName7}/{folderName8}/{folderName9}/{folderName10}/", EditController::class.":markData")->add(new CheckIPAddressBefore($container));//マークダウン変換


//プレビュー
$app->any("/preview1.php", PreviewController::class.":previewData");


//管理画面
$app->any("/admin", AdminController::class.":adminData")->add(new FolderCount($container))->add(new CheckIPAddressBefore($container))->add(new PagesCopyEmptyCheck($container));


//編集画面
$app->any("/edit", EditController::class.":editData");


//編集保存
$app->any("/markdown-upload", EditController::class.":markdownUpload");


//ファイル保存
$app->any("/file_save", EditController::class.":fileSave");


//ファイル削除
$app->any("/file_delete", EditController::class.":fileDelete");


//テスト
$app->any("/writeBody", AdminController::class.":testData");


//フォルダ新規作成
$app->any("/folder_create", AdminController::class.":folder_create")->add(new EventLog($container));


//メニュー名変更
$app->any("/file_rename", AdminController::class.":file_rename")->add(new EventLog($container));


//フォルダ名変更
$app->any("/folder_rename", AdminController::class.":folder_rename")->add(new EventLog($container));


//locklistテーブル変更
$app->any("/lockdata_edit", AdminController::class.":lockdata_edit")->add(new EventLog($container));


//ロック設定
$app->any("/page_lock", AdminController::class.":page_lock")->add(new EventLog($container));


//ロック解除
$app->any("/page_unlock", AdminController::class.":page_unlock")->add(new EventLog($container));


//フォルダのリスト取得
$app->any("/folder_list", AdminController::class.":folder_list")->add(new EventLog($container));


//lockデータ削除
$app->any("/lockdata_del", AdminController::class.":lockdata_del")->add(new EventLog($container));


//削除したフォルダをゴミ箱(trush)に移動
$app->any("/trush", AdminController::class.":trush")->add(new EventLog($container));


//フォルダ削除
$app->any("/folderDelOnly", AdminController::class.":folderDelOnly")->add(new EventLog($container));


//配下のフォルダも削除
$app->any("/del_allfolder", AdminController::class.":del_allfolder")->add(new EventLog($container));


//pagesバックアップ テスト
$app->any("/backup", AdminController::class.":backup");


//フォルダ数表示 テスト
$app->any("/folder_cnt", AdminController::class.":folder_cnt");


//並べ替え確定（フォルダの差分のみ移動）→「差分で並べ替え確定」ボタンをクリック
$app->any("/execution_sabun", AdminController::class.":execution_sabun")->add(new PagesCopyEmptyCheck($container));


//検索結果
$app->any("/search", SearchController::class.":searchResult");


//pages_copyフォルダのチェック
$app->any("/pagesCopyCheck", AdminController::class.":pagesCopyCheck")->add(new PagesCopyEmptyCheck($container));