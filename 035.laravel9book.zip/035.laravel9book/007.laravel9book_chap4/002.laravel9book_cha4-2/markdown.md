*[page-title]:Chap4-2 Queueを使って処理を非同期にする

Webサービスを作っていると、 処理の一部を非同期的に行いたいという要件がでてきます。このようなときにはQueueを利用します。

## Queueを使った非同期処理

<span class="bold">非同期処理を使うケース</span>

<div markdown="1" class="green-box">
* データの登録とその通知を分けたい。
* 画像の投稿とその画像を変換してサムネイルを作る処理を分けたい。
* ユーザーのアクセスとアクセス数のカウント処理を分けたい。
</div>

このような非同期処理に便利なのが「<span class="green bold">Queue</span>」です。  
Queueでは実行したい処理内容を<span class="red">Job</span>という形で積んでいき、順番に処理していきます。先にQueueに積まれたものから順番に実行されていく仕組みです。    また、Queueには再実行の設定や失敗したJobだけを積む機能なども付いています。  
ここでは、LaravelでどうやってQueueを活用して処理を非同期にするかを見ていきましょう。


### Jobクラス

LaravelではQueueから実行されるタスク一つの単位を「<span class="green bold">Job</span>」と呼びます。実装するには<span class="red">Jobクラス</span>を使います。このJobクラスに非同期で行いたい処理を書くことで、処理の一部をJobとして非同期に行うことができます。試しにJobクラスを作ってみましょう。次のコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>Jobクラス作成</p>
```
sail artisan make:job SampleJob
```
![](upload/sail_artisa_makejob.png){.phooto-border}

「app/Jobs/SampleJob.php」にjobクラスが作成されました。
![](upload/sail_artisa_makejobファイル作成.png){.photo-border}

<p class="tmp list"><span>リスト</span>①app/Jobs/SampleJob.php（デフォルト）</p>
```
<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SampleJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        //
    }
}
```

ここに処理を書いていきます。文字列を表示するプログラムを書いてみます。Jobの処理はhandleメソッドの内部に書きます。

<p class="tmp list"><span>リスト</span>app/Jobs/SampleJob.php</p>
```
    public function handle()
    {
        echo 'Jobを実行しました。';//追加
    }
```

次にこのJobを実行してみます。  
ここではLaravelの「<span class="green bold">tinker</span>」という機能を使ってJobを実行します。tinkerはArtisanで提供されているLaravelのREPL(Read Eval Print Loop) で、<span class="red">PHPのコードをコマンド入力で評価してくれる対話式シェル</span>です。  
Laravelのtinkerを起動しJobを実行してみましょう。まず、次のようにtinkerコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>tinker実行</p>
```
sail artisan tinker
```
次に「<span class="red">\Bus::dispatchSync();</span>」でjobを実行します。

<p class="tmp cmd"><span>コマンド</span>jobを実行</p>
```
\Bus::dispatchSync(new App\Jobs\SampleJob());
```
![](upload/jobを実行.png)

※tickerを終了するときは「<span class="red">q</span>」と入力します。

↑「を実行しました。」がなぜか文字化けしています。。

\Bus::dispatchSyncはTinker上でJobを即時実行する際に使用するメソッドです。これでJobが実行できました。  
しかし、これだけだとJobは非同期処理になっていません。Queueを使って非同期にJobを実行するために、次にLaravelの「<span class="green bold">Queue</span>」の機能について見ていきましょう。

## Queueを使ってJobクラスを実行する

では、JobクラスをQueueの機能を経由して実行していきます。まず、Queueの機能の設定を見てみましょう。

### Queueの設定

Queueの機能の設定は、config/queue.phpファイルに記述されています。

<p class="tmp list"><span>リスト</span>config/queue.php（デフォルト）</p>
```
<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Queue Connection Name
    |--------------------------------------------------------------------------
    |
    | Laravel's queue API supports an assortment of back-ends via a single
    | API, giving you convenient access to each back-end using the same
    | syntax for every one. Here you may define a default connection.
    |
    */

    'default' => env('QUEUE_CONNECTION', 'sync'),

    /*
    |--------------------------------------------------------------------------
    | Queue Connections
    |--------------------------------------------------------------------------
    |
    | Here you may configure the connection information for each server that
    | is used by your application. A default configuration has been added
    | for each back-end shipped with Laravel. You are free to add more.
    |
    | Drivers: "sync", "database", "beanstalkd", "sqs", "redis", "null"
    |
    */

    'connections' => [

        'sync' => [
            'driver' => 'sync',
        ],

        'database' => [
            'driver' => 'database',
            'table' => 'jobs',
            'queue' => 'default',
            'retry_after' => 90,
            'after_commit' => false,
        ],

        'beanstalkd' => [
            'driver' => 'beanstalkd',
            'host' => 'localhost',
            'queue' => 'default',
            'retry_after' => 90,
            'block_for' => 0,
            'after_commit' => false,
        ],

        'sqs' => [
            'driver' => 'sqs',
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'prefix' => env('SQS_PREFIX', 'https://sqs.us-east-1.amazonaws.com/your-account-id'),
            'queue' => env('SQS_QUEUE', 'default'),
            'suffix' => env('SQS_SUFFIX'),
            'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
            'after_commit' => false,
        ],

        'redis' => [
            'driver' => 'redis',
            'connection' => 'default',
            'queue' => env('REDIS_QUEUE', 'default'),
            'retry_after' => 90,
            'block_for' => null,
            'after_commit' => false,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Job Batching
    |--------------------------------------------------------------------------
    |
    | The following options configure the database and table that store job
    | batching information. These options can be updated to any database
    | connection and table which has been defined by your application.
    |
    */

    'batching' => [
        'database' => env('DB_CONNECTION', 'mysql'),
        'table' => 'job_batches',
    ],

    /*
    |--------------------------------------------------------------------------
    | Failed Queue Jobs
    |--------------------------------------------------------------------------
    |
    | These options configure the behavior of failed queue job logging so you
    | can control which database and table are used to store the jobs that
    | have failed. You may change them to any database / table you wish.
    |
    */

    'failed' => [
        'driver' => env('QUEUE_FAILED_DRIVER', 'database-uuids'),
        'database' => env('DB_CONNECTION', 'mysql'),
        'table' => 'failed_jobs',
    ],

];
```

![](upload/QUEUE_CONNECTION.png "config/queue.php")

![](upload/env既.png ".env（既存）")

「'default' => env('QUEUE_CONNECTION', 'sync'),」は、.envファイルに記述がある場合はそれを使用し、記述がない場合はQUEUE_CONNECTIONをsyncに設定するという意味です。  
envファイルのQUEUE_CONNECTIONは 「<span class="red">sync</span>」になっているはずなので、変更しなければQueueの設定は<span class="red">sync</span>となります。<span class="red">sync</span>は「<span class="red">JobをQueueに積まず、即時に実行する</span>」ということです。これだとQueueに積む意味がないので、基本的には開発中の段階で利用します。  
今回はQueueをデータベースで管理することにしますので、設定を変更しましょう。
envファイルのQUEUE_CONNECTIONの部分を「<span class="green bold">database</span>」に変更します。

![](upload/env変更.png ".env（変更）")

次にQueueに積まれるJobを管理するためのテーブルを作成します。これにより、データベースにjobsテーブルが追加されます。次のコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>Jobを管理するためのテーブルを作成</p>
```
sail artisan queue:table

sail artisan migrate
```
![](upload/sail_artisa_queuetable.png)

これで準備が整いました。

### Queue を使ってみる

それでは、再度tinkerを使ってJobを実行してみましょう。先ほどはdispatchSyncを使いましたが、今回は同期的に実行するわけではないので、dispatchを使います。

<p class="tmp cmd"><span>コマンド</span>dispatchを使用</p>
```
sail artisan tinker

\Bus::dispatch(new App\Jobs\SampleJob());
```
![](upload/dispatch.png)

今回はテキストが表示されなかったはずです。これはテキストを表示するJobが実行されず、データベースに保存され実行待ちになっているためです。ここで、データベースのjobsテーブを見てみるとdispatchしたJobが保存されているはずです。

jobsテーブルを確認して、レコードが追加されていれば成功です。  
それではこれを実行して見ましょう。 実行には 「<span class="red">queue:work</span>」コマンドを使います。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan queue:work
```
![](upload/sail_artisa_queuework.png)

積まれているJobが実行されたはずです。もう一度データベースのjobsを確認すると空になっているはずです。
![](upload/jobsを確認すると空.png)


## Queueを使ってメールを送信する

次にQueueの機能を使ってメールの送信を行っていきます。 前セクションでユーザーが登録したタイミングでほかのユーザーに通知する処理を作りましたが、その部分をQueueで処理するように変えていきます。  
このような処理はWebサービスを作っていると比較的よく出てくる処理です。仮にメールを送信するのに1通で100msかかるとすると、ユーザー100人にメールを送るには10秒かかることになってしまいます。ユーザーのリクエスト時にこの処理を行ってしまうと、登録のタイミングで10秒もユーザーを待たせてしまうことになってしまいます。こういう時こそQueueの出番です。

### メールの送信にQueueを使う

メールを送信する際にsendの代わりに<span class="green bold">queue</span>を使うことにより、即時にメールを送信せずにQueueに積むことができます。

<p class="tmp list"><span>リスト</span>app/Mail/NewUserIntroduction.php</p>
```
<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NewUserIntroduction extends Mailable implements ShouldQueue//「implements ShouldQueue」を追加
{
 ～省略～
}
```

この種類のメールは常にQueue を経由して送信するべきだとあらかじめわかっている場合は、メールクラスの方にShouldQueueインターフェースを実装させることで、Queueするべきだという印をつけることができます。ShouldQueueインターフェースはメソッドを何も持っていないので、「implements ShouldQueue」と書くだけでよいです。  
それでは早速実行してみましょう。queue:workコマンドを実行した状態で新規ユーザーを追加します。

<p class="tmp cmd"><span>コマンド</span>queue:work</p>
```
sail artisan queue:work
```
![](upload/queueworkコマンド2.png)

この状態で新しいユーザーを登録すると次のようになります。

![](upload/新しいユーザーを登録すると次のようになります.png)

メールの送信がJobと同様に非同期で実行されているのがわかります。①のapp/Jobs/SampleJob.php を見てもわかるとおり、最初に作成したSampleJobも、実はShouldQueueを実装していました。 Jobは基本的には非同期処理をするために作るものなので、 Should Queue を実装しています。
