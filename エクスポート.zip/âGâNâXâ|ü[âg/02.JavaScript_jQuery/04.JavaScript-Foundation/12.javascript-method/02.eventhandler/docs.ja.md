---
title: イベントハンドラ
---

<p class="tmp exp"><span>例1</span>onclick</p>
```
<input type="submit" value="送信" onclick="return check()">
```

## よく使われるイベントハンドラ
|イベントハンドラ	|説明|
|:--:|:--:|
|onClick	|クリックした時に発動|
|onDblClick	|ダブルクリックした時に発動|
|onChange	|フォームの入力値や選択値を変更した時に発動|
|onBlur	|フォーカスが外れた時に発動|
|onFocus	|フォーカスが当たった時に発動|
|onSelect	|入力フォームの値をマウスドラッグなどで選択した時に発動|
|onSelectStart	|入力フォームの値をマウスドラッグなどで選択しようとした時に発動|
|onSubmit	|submitボタンをクリックした時に発動|
|onReset	|resetボタンをクリックした時に発動|


