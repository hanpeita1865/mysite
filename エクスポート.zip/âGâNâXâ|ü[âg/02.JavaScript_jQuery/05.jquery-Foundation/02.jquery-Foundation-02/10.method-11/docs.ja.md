---
title: '10. アニメーション<br>（animate）'
taxonomy:
    category:
        - docs
visible: true
---

<style>
	p{letter-spacing:.06rem;}
</style>

<p>「animate()」は、特定のHTML要素のCSSプロパティを連続して変化させることでアニメーションを実現してくれます。</p>

<h2 class="h-type2">animate()メソッド</h2>

<dl class="dl-methodDetail">
	<dt><span>書式</span></dt>
	<dd>$(セレクタ).animate( params [,speed] [,easing] [,func] )</dd>
	<dt><span>機能</span></dt>
	<dd>$(セレクタ)のCSSプロパティを指定の値まで徐々に変化させる。</dd>
	<dt><span>引数</span></dt>
	<dd>
		<dl class="dl-methodDetailInner">
			<dt>params：</dt>
			<dd>変化させるCSSと値を指定します。配列で複数の指定が可能です。
            <ul>
                <li>スタイル名はキャメルケースで記述します。（font-size ⇒ fontSize、margin-left ⇒ marginLeft、等）</li>
				<li>値は数値（px、%、em）で記述しますが、例外として「show」、「hide」、「toggle」の使用ができます。</li>
                <li>値の先頭に「+=」、「-=」をつけることで現在値からの相対値指定が可能です。</li>
                <li>指定の値まで徐々に変化させるという性質上、非数値の値をとるもの（color、background-color、等）は基本的に使用できません。</li>
				<li>スタイルプロパティにはない、scrollTop（縦スクロール位置）とscrollLeft（横スクロール位置）もアニメーション化することが可能です。</li>
            </ul>
            </dd>
			<dt>speed：</dt>
			<dd>動作する時間を「slow」、「normal」、「fast」の文字列か、もしくは数値（ミリ秒単位）で指定します。</dd>
			<dt>easing：</dt>
			<dd>イージング（アニメーション中の動きの振る舞い）を指定します。<br>
            「linear」：一定のスピードでアニメーションが進みます。「swing」：始めと終わりは緩やかに、途中は速め（初期値）</dd>
			<dt>func：</dt>
			<dd>アニメーション完了後に実行する関数</dd>
		</dl>
	</dd>
</dl>
<div class="box-example">
	<h3 class="h-example">例1</h3>
	<p>ボタンを押すとボックスが左右へアニメーションする。</p>
</div>
<iframe width="100%" height="350" src="//jsfiddle.net/z36wgdnx/1/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

ボタンを押してみてください。  
幅、高さ150pxの赤いboxが大きさを変えながら左右に動きだします。

まず、HTMLではbuttonと赤いboxを設置しています。CSSは割愛します。

ではJavaScriptのコードを見てみましょう。  
ボタンを押すことで発動し、boxに対して6回の変化を行っています。  
このように同じオブジェクトに対して複数回の処理を行うときには、処理をドットでつなげるメソッドチェーンが便利です。  

1つ目の処理では、サイズを小さくして、位置を左基準で-100px移動させています。スピードはゆっくりです。  
2つ目の処理では、サイズを大きくして、位置を左基準で+200px移動させています。スピードは速くです。  
この処理を繰り返すことでアニメーションを実現しています。

---

<div class="box-example">
	<h3 class="h-example">例2</h3>
	<p>ボタンを押すたびにボックスの表示・非表示を切り替える。</p>
</div>
<iframe width="100%" height="350" src="//jsfiddle.net/u6w1ydgz/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

ボタンを押してみてください。  
押すたびに表示・非表示が切り替わりますが、上と下のボックスではアニメーションの緩急が異なっているのが分かると思います。

まず、HTMLではbuttonと青いbox（#1、#2）を設置しています。CSSは割愛します。

ではJavaScriptのコードを見てみましょう。  
ボタンを押すことで発動し、#1と#2に対して同じ変化を行っています。  
（幅、透明度、フォントサイズをtoggleで切り替えています。）  
しかし、#1の処理ではeasingに「linear」、#2の処理ではeasingに「swing」を指定しているので動きの緩急が異なっています。

---

<div class="box-example">
	<h3 class="h-example">例3</h3>
	<p>ページトップボタンを押すとトップまで滑らかにスクロールする。</p>
</div>
<iframe width="100%" height="400" src="//jsfiddle.net/jb1a2oh8/embedded/result,html,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

右下にページトップボタンを固定表示しています。  
ページを下までスクロールさせてからボタンを押してみてください。  
aタグのhref="#wrapper"で移動するときと違い、トップまで滑らかにスクロールするのが分かると思います。

まず、HTMLではコンテンツの一番下にaタグでボタンを設置しています。CSSはスタイル調整のみなので割愛します。

ではJavaScriptのコードを見てみましょう。  
aタグの#page-topを押すことで発動し、ページ全体のスクロール位置を0、つまりページ一番上（#wrapper）に変化させています。  
ここでanimateの対象としてbodyとhtml両方を指定しているのは、ブラウザによってscrollTopの効く対象が異なるためです。
