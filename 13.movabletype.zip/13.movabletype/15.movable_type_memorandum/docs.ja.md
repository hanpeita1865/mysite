---
title: 'Movable Type備忘録'
taxonomy:
    category:
        - docs
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<style>
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.4rem;}
	h2::after{content:"Contents";color:#d3ac3f;font-size:1.1rem;letter-spacing:.2rem;margin-left:5px;}
	ol{list-style:none;}
	ol li{position:relative;counter-increment:li;font-size:1.05rem;text-align:left;border-bottom:1px dashed #dcdee0;letter-spacing:.1rem;padding:0px 0 5px 10px;}
	ol li::before{content: counter(li, decimal-leading-zero);color:#d3ac3f;font-family:'Fjalla One',sans-serif;font-size:.8rem;margin-right:15px;}
	ol li::after{content:"";display:block;width:2px;height:2px;background:#d3ac3f;position:absolute;bottom:20px;left:26px;}
    dt {font-size: 1:05rem; font-weight: normal;}
</style>


## 目次

1. [文字列を配列に分割する方法](memorandum_01)
2. [MTタグ部分が空行になって出力される現象を解消する方法](memorandum_02)
3. [コンテンツタイプ使おうとして困ったこと](memorandum_03)
4. [Movable Type 7の設計のポイント](memorandum_04)
5. [指定した日時に公開する](memorandum_05)
6. [「コンテンツタイプ」利用法](memorandum_06)
7. [テンプレートの作成](memorandum_07)
8. [公開日からN日間はnewアイコンを表示する方法（jQuery）](memorandum_08)
9. [Movable Typeテンプレート処理](memorandum_09)



## 参考になるサイト

* [【MT】よく使うMovableTypeのタグまとめ](https://qiita.com/4cres/items/f2ea369ebfe111a8ed00)
* [MT7 r.4207 タグを含むテンプレートタグ](https://app.movabletype.jp/mt/mt-search.cgi?tag=MT7%20r.4207&SearchSortBy=title&SearchResultDisplay=ascend&blog_id=3)
* [Data API ドキュメント公式サイト](https://www.movabletype.jp/developers/data-api/getting-started/)
: Data API を使えば、CMSで管理しているデータを、サイト上で自由に呼び出したり、また、独自の管理画面やアプリの開発や、他のプラットフォームとの連携などを容易に行うことができます。
* 「Movable Type 7」関するサイト
  * [cly7796.netサイト制作に関するメモ書き](http://cly7796.net/wp/category/cms/movable-type/)
  * [Webolve -IT/Web総合情報サイト-](https://www.webolve.com/search/search.cgi?tag=Movable%20Type&IncludeBlogs=1&limit=20&button=)
  * [MD-Blog_Search](https://www.monster-dive.com/cgi-bin/cms/mt-search.cgi?IncludeBlogs=2&tag=Movable%20Type&limit=20)
  * [Hei Blog](https://hei-a.net/blog/tag/MT7/)


