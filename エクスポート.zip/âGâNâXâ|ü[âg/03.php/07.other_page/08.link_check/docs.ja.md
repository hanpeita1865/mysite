---
title: リンク切れチェック
taxonomy:
    category:
        - docs
---

チェック方法としては、下記のように file_get_contents 関数を利用して、URL先のサイトの内容を文字列に読み込み、結果が返ってくればリンク先が存在している、という判断をしています。  
が、すべての内容を取得すると処理が重くなってしまうため、先頭の1文字だけを取得しています。
また、file_get_contentsは、リクエスト先がないときに warning が発生してしまうので、@をつけてエラーメッセージを表示させないようにしています


<iframe src="https://paiza.io/projects/e/6W9wLWXX9qViPg9xyxuybw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## 参考サイト

* [【PHP】リンク先のURLが有効かどうかを確認する方法](https://cpoint-lab.co.jp/article/201801/1064/)