*[page-title]:7-2. 単一ファイルコンポーネント

<div markdown="1" class="note-box">
サンプルを使うときは、package.jsonなど一式を削除して、node ver18系でインストールした（p__vue_3\sample\vue-app\chap07\my-cli）からコピーして「npm i」を実行し、インストールしてください。
</div>

<span class="green bold">単一ファイルコンポーネント</span>とは、コンポーネントを構成するテンプレート、スタイル、ロジック をひとつのファイル(.vue ファイル)としてまとめたものを言います。 .vue ファイル化することで、 コンポーネントを構成する要素が一望できるので、コードの見通しは格段に改善します。 <span class="green bold">Single File Component</span> の頭文字から<span class="green bold">SFC</span>と呼ばれることもあります。

特に、コンポーネントの数が増える中規模以上のアプリでは見かける機会も増えてきます。 そもそも Vue CLI では .vue ファイルでの構成が既定なので、 プロジェクトの内容を理解するという意味でも.vue ファイルの理解は欠かせません。

## 7-2-1 単一ファイルコンポーネントの基本

・・・

<div markdown="1" class="note-box">
##### Volar
個々の要素が切り出され、 役割分担が明確になることで、 エディターによる構文ハイライトの恩恵 を受けやすい、というメリットもあります。 たとえば著者のお勧めは、 Visual Studio Code (以降 は VSCode)と、その Vue.js プラグイン 「Volar」との組み合わせです。  
下記からもインストールできます。
* [https://github.com/johnsoncodehk/volar](https://github.com/johnsoncodehk/volar)
* [https://marketplace.visualstudio.com/items?itemName=vue.volar](https://marketplace.visualstudio.com/items?itemName=vue.volar)

VSCode は、近年、開発者に人気の高いコードエディターで、 Windows、macOS、Linux と マルチな環境で動作することから、他の言語、 フレームワークでの開発でもよく利用されます。 VSCode での開発に慣れておくことは、他の環境での開発にも役立ちます。 そして、 Volar は Vue.js 公式に開発、保守されているツールで、 .vue ファイルに対して、以下のような機能を提供しています。
![](upload/vscode_volar.png)
</div>

・・・


## 7-2-2 ES2015のモジュール構文

<span class="green bold">モジュール</span>とは、アプリを機能単位に分割するためのしくみです。 アプリの規模が大きくなったとき、 すべてのコードをひとつのファイルにまとめるのは望ましい状態ではありません。 目的のコードを見つけにくくなりますし、なにより変数、 メソッドの競合リスクが増すからです。  
しかし、モジュールを利用することで、コードをファイル単位に分離できるようになります。  
加えて、分離されたコードは、それぞれ独立したスコープを持つので、 他モジュールへの影響を気にする必要はありません。 モジュールの外からアクセスできるのは、明示的にアクセスを許可した要素だけです。

![](upload/モジュールとは.png)

Vue CLI を利用する規模のアプリなのであれば、積極的に「<span class="green bold">モジュール</span>」を利用して、コードを機能単位 ―  Vue.js の世界であれば、<span class="red">コンポーネント</span>、<span class="red">プラグイン</span>の単位で分割管理していくことをお勧めします。

### モジュールの定義
JavaScript のモジュールは、<span class="red">ひとつのファイルとしてまとめる</span>のが基本です。たとえば以下は、定数 APP_TITLE、getTriangle 関数、Article クラスを、Appモジュールとしてまとめたものです。ファイル名がそのままモジュール名と見なされます。
![](upload/リスト7-2.png)

モジュールと言っても、ほぼこれまでのコードと同じです。 ただし、一点だけモジュール配下のメンバーは、 既定でモジュールの外には非公開となる点に注意してください。 モジュールの外からアクセスするには、 <span class="green bold">export</span> キーワードを付与して、 明示的にアクセスを許可しなければなりません。 この例であれば、 <span class="red">getTriangle関数</span>、 <span class="red">Articleクラス</span> が公開の対象で、<span class="red">定数 APP_TITLE</span> は App モジュールの中でしか利用できません ※1。

<span class="notes">※1 ただし、Article#getAppTitle メソッドは公開対象なので、これ経由で APP_TITLE を参照するのは問題ありません。</span>

### モジュールの利用
定義済みの App モジュールを、別のファイル(モジュール)から利用してみましょう。
![](upload/リスト7-3.png)
モジュールをインポートするのは、 import 命令の役割です (1)。
<p class="result"><span>結果</span></p>
![](upload/リスト7-3結果.png)

<p class="tmp"><span>書式</span></p>
```
import { member, ... } from module

member: インポートするメンバー
module : モジュール
```

モジュールは、現在の js ファイルからの<span class="red">相対パス</span>で表します。よって、もしApp モジュールがサブフォルダー「/lib」 に格納されている場合には、(1)も以下のように表します。
```
import { Article, getTriangle } from './lib/app.js';
```
App モジュールで <span class="green bold">export </span>していても、 import 側で明示的にインポートされなかったものには、アクセスできない点に注意してください。 たとえば、以下の宣言でアクセスできるのは Articleクラスだけです（getTriangle関数にはアクセスできません!）。
```
import { Article } from './App.js';
```

### 既定のサンプルコードを読み解く

以上の理解をもとに、7-1-2 項で作成したプロジェクトに含まれる App.vue、HelloWorld.vue、main、js を読み解いてみましょう。 いずれも&lt;script&gt;要素の内容のみ再掲します。
![](upload/リスト7-4.png)
ここでは、 default キーワードに注目です。 default は、 そのメンバー(ここではオブジェクトリテラル) モジュールの既定のメンバーであることを意味します。 名前は呼び出し側で付与するので、モジュール側では不要です。  
.vue ファイルに含まれるコンポーネント定義はひとつだけのはずなので、 default メンバーとして定義するのが通例です。  
このような default メンバーを呼び出しているのが、 以下のコードです。
![](upload/リスト7-5.png)
(1)で、<span class="red">HelloWorld. vue</span> の <span class="red">default</span> メンバーに、 <span class="red">HelloWorld </span>という名前でアクセスできるようになります。 太字の部分は、 呼び出しのために用いるモジュールの別名なので、 どんな名前を付けても構いません。ただし、一般的には、出自が明らかになるよう、 モジュール名そのまま(もしくは明らかな省略名)とするのが一般的です。

コンポーネント(.vue ファイル)の内容を確認できたところで、 アプリ本体の起動ファイル (エントリーポイント)となる main.js についても軽く確認しておきます。
![](upload/リスト7-6.png)
createAppメソッドでVue オブジェクトを生成し、 mountメソッドでマウント (起動)するという流れは、 これまでとほぼ同じですが、 以下の点が異なります。  
まず、<span class="red">createApp</span> は、これまでは 「<span class="red">Vue.createApp</span>」 のように、 クラスメソッドの形式で呼び出されていましたが、モジュールの世界では単に 「<span class="green bold">createApp</span>」 (vue モジュールの createApp 関数) です (1)。 また、モジュール配下の関数なので、あらかじめインポートしなければなりません(2)。 他にも、 h (5-4-3 項)、nextTick (10-1-3項)、 ref / reactive (6-1-2項) など、 これまで 「Vue. ~」 の形式で呼び出してきたものはすべて同様です ※1。  
createApp メソッドの引数 (3) にも注目です。 これまではコンポーネントオプションを意味するオ ブジェクトリテラルを渡してきた箇所ですが、 既に App コンポーネントを定義済みです。 このような場 合には、コンポーネントオブジェクトをそのまま受け取ることができます。

<p class="notes mt-3">※1  Composition API関係のメソッドはほとんどが該当します。</p>

## 7-2-3 Composition APIのシンタックスシュガー - setup属性 ･･･ちょっと難しくて理解できていない

.vue ファイルで Composition API を利用している場合、 6-1 節の知識はほぼそのまま転用できます(コードをモジュール化するだけです)。 たとえば以下は、リスト6-1を.vue ファイルで書き換えた例です。 

<p class="tmp list"><span>リスト7-7</span>my-composite/src/components/MyCounter.vue</p>
```
<template>
  <div>現在値は{{ current }}です！
  <input type="button" v-on:click="onclick" value="増やす" /></div>
</template>

<script>
import useCounter from '../composables/useCounter'

export default {
  name: 'MyCounter',
  props: [ 'init' ],
  setup(props) {
    //コンポジション関数からカウンター機能を取得
    const { current, onclick } = useCounter(props.init)
    return {
      current,
      onclick
    }	
  }
}
</script>
```

<p class="tmp list"><span>リスト7-8</span>my-composite/src/composables/useCounter.js</p>
```
import { ref } from 'vue'

export default function(init) {
    //データオブジェクト、イベントハンドラーを定義
    const current = ref(init);
    const onclick = () =>  {
      current.value++
    }

    return {
      current,
      onclick
    }
}
```
従来のコードを理解していれば、 機械的なルールのみで置き換えができるはずです。 しかし、機械的 であるということは定型的であるということ。 定型的なのであれば、 できるだけ書かずに済ませたいです。  
そのようなニーズに対応したシンタックスシュガーが <span class="green bold">setup 属性</span>です。 setup属性を利用することで、<span class="red">.vue ファイル配下での Composition API をよりシンプルに表現</span>できます。

### setup 属性の基本
以下は、リスト 7-7 を setup 属性を使って書き換えた例です (リスト7-7はそのまま利用できます)。
<p class="tmp list"><span>リスト7-9</span>my-composite/src/components/MyCounter.vue</p>
```
<script setup>
import { defineProps } from 'vue'
import useCounter from '../composables/useCounter'

const props = defineProps(['init']) //----(2)
const { current, onclick } = useCounter(props.init) //----(1)
</script>
```
<p class="result"><span>結果</span></p>
![](upload/現在値は0です.png)

<span class="green bold">setup シンタックスシュガー</span>を利用するには、 &lt;script&gt;要素に<span class="red"> setup 属性</span>を付与するだけです。 これで、&lt;script&gt;要素の配下はすべて<span class="red"> setup メソッド</span>の配下に書かれたものとみなされます。 コードの外観だけを見ても、 コンポーネントの外枠が取り払われて、 随分とスッキリしたことが感じ取れると思います。  
所詮はそれだけと言えばそれだけなのですが、 その性質上、 さまざまな注意点もあります。 これまでの記述に慣れていると、 新しい記述を理解するのは面倒だな、と思われるかもしれませんが、将来的 に 「<span class="red">.vue ファイル + Composition API </span>」が当たり前の記述になれば、今のうちに知っておいて損はありません。以下にポイントを押さえておきましょう。

★ちょっと難しいので一旦以下の(1)-(3)はとばす。

#### (1)トップレベルの宣言がレンダーオブジェクトの代わりに
<span class="green bold">&lt;script setup&gt;</span> 要素配下では、直下(トップレベル) で宣言された変数関数がテンプレートに対して無条件に公開されます。 この例であれば、<span class="red"> props</span>、<span class="red">current</span>、<span class="red">onclick</span> などがそれです。よって、以前は setup メソッドの戻り値として列挙していたレンダーオブジェクトの記述が不要になります。 トップレベルの変数が対象なので、 import されたメンバーもそのままテンプレートに公開されます。
![](upload/リスト7-10.png)

#### (2)プロパティを宣言する
コンポーネントの外枠がなくなったため、 props 宣言が消えています。 これは、新たに definePropsメソッドで宣言しておきましょう。 引数の記述ルールはprops オプションの場合と同じです。  
同様に、emits オプションがある場合は、 defineEmits メソッドで置き換えます。
![](upload/コードconst_emit.png)

defineEmits メソッドの戻り値は、 そのまま setup メソッドの context.emit メソッド(6-1-2 項)と 同じように利用できます ※。  
これら defineXxxxx メソッドは setup シンタックスシュガーでのみ利用できるコンパイラーマクロで す。ref / reactive メソッドとは異なり、 明示的なインポートは<span class="red bold">不要</span>です。

#### (3) &lt;script&gt;要素の制約
&lt;script setup&gt;要素を利用した場合、 &lt;script&gt;要素のルールに固有の変化が発生します。

* a. &lt;script&gt;要素 (setup なし) を併用できる ※
 * b. &lt;script&gt;要素で setup 属性と src属性を併用できない
    
&lt;script setup&gt; / &lt;script&gt; (setup なし)を併用する (a.) のは、以下のようなコードが含まれる場合です。

* inheritAttrs など、 setup 配下では表現できないコンポーネントオプションの宣言
* 名前付きエクスポートの宣言
* その他、モジュールスコープで一度だけ実行したいコード

setup 配下では表現できないコードを &lt;script&gt; (setup なし) で補うわけです。ただし、定義を分断 するくらいならば、 最初から &lt;script&gt; (setup なし) で統一したほうがシンプルかもしれません (この 辺のルールはプロジェクトとして統一することをお勧めします)。  
src属性との併用 (b.) は、 &lt;script setup&gt; の実行ルールが異なるがゆえの制約です。 setup 配下を 別ファイルに切り出した場合、 ツールが正しく認識できず、開発者にも混乱をもたらす可能性があるの で、これを禁止しています。


## 7-2-4 コンポーネントのローカルスタイル - Scoped CSS

7-2-1 項でも触れたように、 &lt;style&gt; 要素では scoped 属性を利用することで、 コンポーネントローカ ルな(=そのコンポーネントだけで有効な) スタイルを定義できます。 これを Scoped CSS と呼びま す。一般的には、アプリグローバルなスタイル定義は、コンポーネントとは別に定義すべきなので ※1、 &lt;style&gt; 要素には scoped 属性を付与するのが自然です。

<span class="notes">※1 あるいは、ルートコンポーネント (App.vue) でまとめておく場合もあります。</span>

### Scoped CSS の基本
まずは、実際に Scoped CSS を利用して、 その挙動を確認してみましょう。 修正した箇所は太字で示しています。index.html を編集しているのは、コンポーネント内で定義されたスタイルが、 外部に影響しないことを確認するためです。
![](upload/リスト7-11_7-12.png)

<p class="result"><span>結果</span></p>
![](upload/リスト7-11_7-12結果.png)

理解を深めるために、 Scoped CSS がどのように実現されているのか、 Vue.js によって生成されたコードを、ブラウザーのデベロッパーツールから確認してみましょう。
![](upload/リスト7-11_7-12デベロッパー.png)

Scoped CSS として指定したスタイル(1)には、セレクター式に [<span class="red">data-v-〜</span>] のような属性宣言が
加わっていることが確認できます。 同時に、コンポーネントで定義されたテンプレートの各要素 (2) にも、対応する data-v- ~属性が付与されています ※2。

<span class="notes">※2 [data-v-~]以降はランダムな文字列が生成されます。</span>

![](upload/scopedのしくみ.png)

これによって、コンポーネントだけに適用される (<span class="red">Scoped</span>) スタイルを実現しているわけです。

なので次のように「scoped」を取ると、コンポーネント以外の要素にもスタイルが適用される。
```
<style>
p {
  border: 1px solid Red;
  background-color:Yellow;
}
</style>
```

![](upload/scopedを取った表示結果.png "図 scopedを取った表示結果.")

### Scoped Style で利用できる特殊なセレクター
Scoped Style でのみ利用できる特殊なセレクター構文もあります。以下に、主なものをまとめておきます。

#### (1)子コンポーネントに適用するスタイルを定義する - deep 擬似セレクター 
Scoped Style の適用先は、厳密に現在のコンポーネントです。 つまり、コンポーネント配下に入れ子で子コンポーネントがあったとしても、そちらに影響が及ぶことはありません。  
たとえば以下は、入れ子になった App / Child コンポーネントの例です。 まずは <span class="red">deep擬似セレクター</span> を利用せずに、スタイルを指定してみます。
![](upload/リスト7-13.png)
![](upload/リスト7-14.png)

<p class="result"><span>結果</span></p>
![](upload/deep属性なし.png "図 deep属性適用無し")

<span class="temp">■適用した場合</span>
```
<style scoped>
:deep(.highlight) {
  border: 1px solid Red;
  background-color:Yellow;
}
</style>
```
deep 擬似セレクターを利用すれば、例外的に子コンポーネントまで波及するスタイルを適用できます。
<p class="result"><span>結果</span></p>
![](upload/deep属性あり.png "図 deep属性適用有り")

![](upload/deep属性ありコード.png)

#### （2）スロットに適用できるスタイルを定義する - :slotted 疑似セレクタ
既定では、スロットは現在のコンポーネントの守備範囲外です (あくまで親コンテンツによって管理されるコンテンツです)。よって、Scoped Style もスロットには適用されません。スロットにスタイル を適用するには、<span class="red">slotted 擬似セレクター</span>を付与してください。

<p class="lang">MyChild.vue</p>
```
<template>
  <p class="highlight">こんにちは、Vue.js！</p>
  <div>こんにちは、<slot class="highlight">ゲスト</slot>さん！</div>
</template>

<script>
export default {
  name: 'MyChild'
}
</script>

<style scoped>
:slotted(.highlight) {
  border: 1px solid Red;
  background-color:Yellow;
}
</style>
```
<p class="result"><span>結果</span></p>
![](upload/slottedを設定表示結果.png)

※上記の表示結果のように、下の方のタグにスタイルは反映させることができてます。

また下記のように「:slotted」を取った場合には、(スロットではなく) MyChild コンポーネント本来のテンプレートで定義された要素に対して、 スタイルが適用されたことが確認ます。
```
<style scoped>
.highlight {
  border: 1px solid Red;
  background-color:Yellow;
}
</style>
```
![](upload/slottedをとった結果表示.png "図 slottedをとった結果表示")

## 7-2-5 スタイルシートをモジュール化する - CSSモジュール


## 7-2-6 alt JS言語の活用 -TypeScript