<?php
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class PagesCopyEmptyCheck implements MiddlewareInterface
{
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $folder = glob('../pages_copy/*', GLOB_ONLYDIR);

        if(empty($folder)){
            $check='false';//空
        }else{
            $check='true';//フォルダが存在
        }

        $request = $request->withAttribute('check', $check);
        $response = $handler->handle($request);
        
        return $response;
    }
}