window.addEventListener('DOMContentLoaded', function () {

	document.addEventListener('drag', function (e) {
		console.log('drag');
	});

	document.addEventListener('dragend', function (e) {
		console.log('dragend');
	});

	document.addEventListener('dragenter', function (e) {
		console.log('dragenter');
	});

	document.addEventListener('dragexit', function (e) {
		console.log('dragexit');
	});

	document.addEventListener('dragleave', function (e) {
		console.log('dragleave');
	});

	document.addEventListener('dragover', function (e) {
		e.preventDefault();
		console.log('dragover');
	});

	document.addEventListener('dragstart', function (e) {
		console.log('dragstart');
	});

	document.addEventListener('drop', function (e) {
		e.preventDefault();
		console.log('drop');
	});
});