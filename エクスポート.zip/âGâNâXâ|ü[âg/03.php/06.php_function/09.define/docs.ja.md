---
title: (移動済)define関数
taxonomy:
    category:
        - docs
---

phpのdefineの使い方！定数を定義しよう

## phpのdefineとは
defineとはデファインとは読み、「定義する」「限定する」といった意味を持ちます。 PHPのdefine関数では定数を定義することができます。

定数あるいはデファインとは、一度宣言するとその後は値の更新ができない値のことをいいます。(逆に値を変えることができるものを変数と呼びます) プログラム中で書き換えられてしまうと困るような情報をdefine関数で宣言します。

## phpでdefineを使う場合
### defineの使い方

<p class="tmp"><span>書式1</span></p>
```
define(定数名, 値 [, 大文字と小文字の区別]);
```
定数名に利用できるのは変数と同じく英数字か_(アンダースコア)で、数字が使えるのは2文字目以降となります。 定数名は小文字を利用せず、大文字のみで定義するのが一般的です。  
なお、defineで定義した定数はプログラムのどこからでも呼び出すことが可能です。

<iframe src="https://paiza.io/projects/e/e5yLj3lq7-ApQMipGxHGEg?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

消費税はプログラム中で勝手に20%や30%に書き換えられると大変ですので、ここでは定数で宣言しています。 また、定数は変数と違って呼び出す際に$(ダラー)をつけない点に注意しましょう！

***※defineで定義した値は書き換えられません！***


## 配列定数の定義
PHP7以降ではdefineで配列を定義することができます。配列の定数なので配列定数と呼ばれます。

<iframe src="https://paiza.io/projects/e/L2rZhQs04TXGXB4bekAbtQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

また、配列だけでなく連想配列も定義することができます。
```
<?php

define('ANIMAL', array(
  '猿' => '300円',
  '鳥' => '200円',
  '犬' => '500円'
));
```

## const構文との違い
同じく定数定義できるものにconst構文があります。
```
const TAX = 1.08;
```
define関数とconst構文との違いは、define関数がプログラム内のどこからでも呼び出せるグローバルな定数を宣言できるのに対し、const構文は宣言したクラス内でしか使えないローカルな定数となっています。

そのため、プログラム全体からアクセスする可能性がある定数については、define関数で定義するようにしましょう。逆にそのクラス内でしか使わないような定数は、const構文を用いたほうがいいでしょう。