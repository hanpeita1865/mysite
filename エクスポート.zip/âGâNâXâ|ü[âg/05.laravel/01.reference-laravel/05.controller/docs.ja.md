---
title: '05. コントローラ'
media_order: 'hello_action.png,controller_para.png,hello_other.png,single_action.png,request_response.png,request_response2.png,HelloController.jpg,controller_web.png,hello_action.jpg,Request_url.png,single_action.png'
taxonomy:
    category:
        - docs
---

* [MVCとコントローラ](#p1)
* [MVC アーキテクチャ](#p2)
* [コントローラの作成](#p3)
* [アクションを追加する](#p4)
* [ルートパラメータの利用](#p5)
* [複数アクションの利用](#p6)
* [シングルアクションコントローラ](#p7)
* [リクエストとレスポンス](#p8)
* [Request および Response](#p9)

Webページの具体的な処理は、コントローラを使って行うのが基本です。コントローラは、MVCアーキテクチャの基本となるものです。

## MVCとコントローラ ## {#p1}
**ルーティング**は、アクセスしたアドレスを元に処理を割り振るための機能です。先ほど、**Route::get** を使って簡単なWebページを表示させてみましたが、もちろんルーティングはWebページを作って表示するためのものではありません。具体的に実行すべき処理は別に用意されていて、それを特定アドレスに割り振って呼び出すためのものです。  
では、呼び出される「具体的に実行すべき処理」というのは、どういうものか。それを実装するために用意されているのが「***コントローラ***」です。

![](controller_web.png?classes=caption "図1　Webアプリケーションにアクセスをすると、コントローラが処理を行う。必要に応じてビューや モデルを利用し、画面表示やデータベースのデータなどを受け取っていく。")

## MVC アーキテクチャ ## {#p2}

コントローラを知るには、まず「***MVC***」と呼ばれるアーキテクチャについて理解しなければいけません。 MVCは、「Model-View-Controller」の略です。これはアプリケーションの処理を、MVCの3つの要素の組み合わせとして構築していく考え方です。MVCは、それぞれ以下のような役割を果たします。

モデル(Model)
: データ処理全般を担当します。具体的には、データベースアクセスに関する処理全般を扱うものと考えてよいでしょう。

ビュー(View)
: 画面表示を担当します。表示に使うテンプレートなどがこれに相当します。 
 
コントローラ(Controller)
: 全体の制御を担当します。必要に応じてModelを使ってデータを取得したり、Viewを利用して画面表示を作成したりします。

モデル(Model)やビュー(View)は、特定の機能に特化したものです。これに対しコントローラ(Controller)は処理全体の制御を担当するものであり、プログラムの本体部分といってもよいものなのです。モデルやビューは、不要であれば用意しないでおくことも可能ですが、*コントローラは、ないと処理そのものが実行できません。*  
Laravelの開発は、まずコントローラを作るところから始まる、といってもよいでしょう。


## コントローラの作成 ## {#p3}
では、コントローラを作成してみましょう。コントローラは、PHPのスクリプトファイルとして作成します。テキストエディタ等でファイルを作成してもいいですが、ここでは*artisan(アーティザン)コマンド*を使って作成しましょう。  
コマンドプロンプトまたはターミナルで、プロジェクトフォルダの中にcdコマンドで移動して下さい。そして以下のようにコマンドを実行します。
<p class="tmp cmd"><span>コマンド</span>HelloController新規作成</p>
```
php artisan make:controller HelloController
```

これで、「*HelloController*」という名前のコントローラが作成されます。

ここでは、artisanコマンドというものを使いました。これは、以下のような形で実行します。

<p class="tmp"><span>書式1</span></p>
```
php artisan コマンド
```
今回使ったのは、「make:controller」というコマンドです。これは以下のように実行を します。
<p class="tmp"><span>書式2</span></p>
```
php artisan make:controller コントローラ名
```
これで、指定した名前でコントローラが作成されます。今回は、HelloControllerとい うコントローラを作成していました。  
コントローラは通常、「○○Controller」というように、名前の後に「Controller」を付けたものが使われます。

では、作成されたコントローラのファイルを見てみましょう。コントローラは、「**app**」フォルダの「**Http**」フォルダ内にある「***Controllers***」というフォルダの中に作成されます。
![](HelloController.jpg?classes=caption "図3　Controllersフォルダ")
このフォルダを開くと、その中に「*HelloController.php*」というファイルが見つかります。これが、作成したHelloControllerのスクリプトファイルです。


<p class="list tmp"><span>リスト2</span>app/Http/Controllers/HelloController.php（デフォルト）</p>
```
<?php

    namespace App\Http\Controllers;

    use Illuminate\Http\Request;

    class HelloController extends Controller
    {
       //
    }
```
これがコントローラの基本ソースコードになります。ポイントを整理していきましょう。

### Controllers 名前空間
コントローラは、クラスとして作成されます。このクラスは、**App\Http\Controllers** という*名前空間*に配置されます。名前空間というのは、*クラスを階層的に整理するための仕組み*です。フォルダを使って階層的にファイルを整理するのと同じようなものをイメージすればよいでしょう。

ここでは、App\Http\Controllersという名前空間を使っていますが、これはよく見るとどこかで見覚えのある名前が並んでいるのがわかります。そう、コントローラのファイルが置かれている場所は、「app」フォルダ内の「Http」フォルダの中にある「Controllers」 フォルダの中でした。このフォルダ構成に沿って名前空間が指定されていることがわかるでしょう。 この名前空間を指定しているのが最初の文です。
```
namespace App\Http\Controllers;
```
これは、コントローラクラスを作成する際の基本設定として覚えておきましょう。

### use によるクラスのインポート
次に記述されているのは、use文です。これは以下のように記述されています。  
```
use Illuminate\Http\Request;
```
ここでは、Illuminate\Httpパッケージ内に用意されている「***Request***」を使える状態にしています。まだこの段階ではRequestは不要ですが、これから多用することになるク ラスですので、デフォルトでuse文が追加されているのです。

#### クラスの定義
続いて、クラスの定義がされています。ここでは、HelloControllerクラスが以下のように定義されています。
```
class HelloController extends Controller
{
	//
}
```
コントローラクラスは、このようにControllerというクラスを継承して作成をします。 また名前は、既に触れたように「**○○Controller**」というものにしておきます。これは必須というわけではありませんが、クラスをわかりやすく整理する上で必要な命名ルールと考えて下さい。  
これで、コントローラクラスは用意できました。後は、ここに具体的な処理をメソッドとして追加していくだけです。


## アクションを追加する ## {#p4}

では、コントローラに処理を追加しましょう。  
コントローラに用意される処理は、「*アクション*」と呼ばれます。これはメソッドの形で用意されます。アクションは、*コントローラに用意される処理を行うためのもの*で、 複数を用意することができます。 では、HelloController.phpを以下のように書き換えて下さい。


<p class="list tmp"><span>リスト3</span>HelloController.php</p>
```
<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class HelloController extends Controller
{
  
   public function index() {

       return <<<EOF
<html>
<head>
<title>Hello/Index</title>
<style>
body {font-size:16pt; color:#999; }
h1 { font-size:100pt; text-align:right; color:#eee;
   margin:-40px 0px -50px 0px; }
</style>
</head>
<body>
   <h1>Index</h1>
   <p>これは、Helloコントローラのindexアクションです。</p>
</body>
</html>
EOF;

   }
}
```

ここでは、HelloControllerクラスの中に「*index*」というメソッドを追加しています。これが、アクションとして使われる*メソッド*です。  
アクションメソッドは、このindexのように引数を持たないメソッドとして用意されます（ただし、必要に応じて引数を用意する場合もあります。これについては後述しま す）。

アクションメソッドでは、returnでHTMLのソースコードを返しています。このようにreturnされた内容が、アクセスしたWebブラウザへ返され、それが表示されることになります。

### ルート情報の用意
これでコントローラにアクションは用意できましたが、これだけでは表示はされません。アクションを使うようにするためには、アクションにルートを割り当てる設定が必要です。  
「**routes**」フォルダの**web.php**を開き、先に追記した内容(ルーティング リスト4)を削除して下さい。 そして、以下の文を改めて追記しましょう。

<p class="tmp list"><span>リスト4</span>web.php</p>
```
Route::get('hello', [\App\Http\Controllers\HelloController::class,'index']);
```
Route::getを使って、ルート情報を設定しています。ここでは、第2引数には関数は使っていません。代わりに、"*HelloController@index*'というテキストが用意されています。  

コントローラを利用する場合は、このように第2引数に「呼び出すコントローラとアクション」を指定します。

~~これは、***'コントローラ名@アクション名'***というように、コントローラとアクションを@でつなげて記述します。~~ 

これにより、第1引数のアドレスにアクセスされると、第2引数に指定されたコントローラのアクションが実行されるようになります。  
ルート情報まで記述できたら、Webブラウザで/helloにアクセスをしてみましょう。 「Index」というタイトルの画面が表示されます。これがindexアクションによって作成されたWebページです。

<http://localhost:9051/hello>

![](hello_action.png?classes=caption "図4　～/helloにアクセス")




## ルートパラメータの利用 ## {#p5}
では、ルートパラメータはどのように利用することになるのでしょうか。これもアクションメソッドを修正して使ってみることにしましょう。  
HelloControllerクラスに以下のコードを追加して下さい。

<p class="tmp list"><span>リスト5</span>HelloController.php</p>
```

   public function rootPara($id='noname', $pass='unknown') {

      return <<<EOF
<html>
<head>
<title>Hello/Index</title>
<style>
body {font-size:16pt; color:#999; }
h1 { font-size:100pt; text-align:right; color:#eee;
   margin:-40px 0px -50px 0px; }
</style>
</head>
<body>
   <h1>Index</h1>
   <p>これは、Helloコントローラのindexアクションです。</p>
   <ul>
       <li>ID: {$id}</li>
       <li>PASS: {$pass}</li>
   </ul>
</body>
</html>
EOF;

   }
```

続いて、ルート情報の修正です。web.phpに追記した、~~HelloController@index~~ 「\App\Http\Controllers\HelloController::class,'index' 」への *Route::get文*を以下のように修正して下さい。  

<p class="tmp list"><span>リスト6</span>web.php</p>
```
Route::get('hello6/{id?}/{pass?}', [\App\Http\Controllers\HelloController::class,'rootPara']);
```

これで修正完了です。/hello6/taro/yamadaというように、/helloの後に2つのパラメー タを付けてアクセスしてみましょう。それらのパラメータの値が画面に表示されます。

<http://localhost:9051/hello6/taro/yamada>

![](controller_para.png?classes=caption "図5 「ID: taro」「PASS: yamada」とパラメータの値が表示される。")


### ルートパラメータの設定 
では、Route::get文から見てみましょう。ここでは以下のように第1引数が用意されていました。
```
'hello6/{id?}/{pass?}
```
***{id?}***と***{pass?}***の2つのパラメータが用意されています。いずれも?を付けて、任意パラメータとして用意してあります。Route::getのパラメータについては、先にRoute::get で設定したのとまったく同じことがわかります。

### アクションメソッドの設定
では、コントローラクラスに用意したアクションメソッドを見てみましょう。ここでは、以下のようにメソッドの定義が変更されています。
```
public function rootPara($id='noname', $pass="unknown') {......)
```
indexメソッドには、*$id*と*$pass*の2つの引数が追加されました。これが、ルートパラ メータに指定された*{id}*と*{pass}*の値を受け取るための引数になります。先にRoute::get の第2引数にクロージャとして処理を用意しましたが、あれがそのままアクションメソッドに置き換わっていることがわかるでしょう。  
今回は任意パラメータですので、それぞれの引数にはデフォルト値を指定してありま す。このあたりも、Route::getでルートパラメータを使ったときの無名関数の書き方と まったく同じです。


## 複数アクションの利用 ## {#p6}
コントローラには、複数のアクションを用意することができます。複数のアクションを用意した場合、どのようにアクセスされるのでしょうか。試してみましょう。
*HelloController.php*の*HelloControllerクラス*を以下のように修正しましょう。クラス以外にグローバル変数や関数も用意されていますので、それらも記述して下さい (namespace、useは省略しています)。

<p class="tmp list"><span>リスト7</span>HelloController.php</p>
```
global $head, $style, $body, $end;
$head = '<html><head>';
$style = <<<EOF
<style>
body {font-size:16pt; color:#999; }
h1 { font-size:100pt; text-align:right; color:#eee;
   margin:-40px 0px -50px 0px; }
</style>
EOF;
$body = '</head><body>';
$end = '</body></html>';

function tag($tag, $txt) {
   return "<{$tag}>" . $txt . "</{$tag}>";
}
```

<p class="tmp">HelloControllerクラスに追加</p>
```
public function multiAction() {
   global $head, $style, $body, $end;

   $html = $head . tag('title','Hello/Index') . $style . $body
       . tag('h1','Index') . tag('p','this is Index page')
       . '<a href="/hello8/other">go to Other page</a>'
       . $end;
   return $html;
}

public function other() {
   global $head, $style, $body, $end;

   $html = $head . tag('title','Hello/Other') . $style . $body
       . tag('h1','Other') . tag('p','this is Other page')
       . $end;
   return $html;
}
```


コントローラの記述ができたら、続けてルーティングも用意しておきましょう。*web.php*に用意した*HelloController@indexのルート情報*を削除し、以下の文を新たに追記し て下さい。  
<p class="tmp list"><span>リスト8</span>web.php</p>
```
Route::get('hello8', 'HelloController@index');
Route::get('hello8/other', 'HelloController@other');
```
修正ができたら、Webブラウザで/hello8にアクセスをしてみて下さい。そして、「go to Other page」のリンクをクリックしてみましょう。  
/hello/otherに移動し、以下のページの表示が現れます。

<http://localhost:9051/hello8>

![](hello_other.png?classes=caption "「go to Other page」のリンクをクリックすると、/hello8/otherのページ に移動する。")


<p>※<strong>注意</strong> XAMPPなどをルートパス用に設定しておかないと、リンクのページを開いたとき「ページが見つかりません」になります。<br>
「http://localhost/laravelapp/public/hello8」だとダメ、「http://localhost/hello8」で表示されるように設定しておく必要があります。</p>

### 複数ページの対応
ここでは、HelloControllerコントローラクラスに、「index」「other」という2つのアクションメソッドを用意してあります。そしてweb.phpにて、**/hello**に**index**を、**/hello/other**に**other**をそれぞれ割り当てています。  
ページが複数になっても、このように基本的な実装の仕方は何ら変わりはありません。 ただし、注意しておきたいのは、割り当てるアドレスです。

### アクションとアドレスの関係
ここでは、/helloと/hello/otherにアクションを割り当ててあります。基本的に、アドレスとコントローラまたはアクションの関連は、以下のように対応させるのが一般的です。
<pre>
http://アプリケーションのアドレス / コントローラ / アクション
</pre>
HelloControllerのindexアクションならば、/hello/indexとしておくのが一般的です。 ただし、Webの世界では、indexは省略してアクセスできるようにしておくのが一般的 ですので、/helloでアクセスできるようにしてあります。  
同じ考え方で、otherアクショ ンは/hello/otherに割り当ててあります。  
これは、「一般的にそうする」ということであって、そうしなければいけないわけでは ありません。例えば、アクションメソッドが、getNextPageActionみたいな名前であれば、 /hello/getnextpageactionとするより、アクション名を省略して/hello/nextとしておく、 といったことはあるでしょう。よりわかりやすいアドレスにするためにコントローラ名 やアクション名を少し修正するのはよくあることです。  
ただし、その構成をまるで変えてしまうのは混乱の元です。例えば、HelloController のindexアクションを、/welcome/homeに割り当てる、というようにまったく関連性の ないアドレスに割り当てることは推奨されないでしょう。ただし、その割り当て方に決まったルールがあり、それに基づいて割り当てているのであれば、問題はありません。  
ルートの設定を独自のやり方で割り当てること自体が問題なのではありません。問題なのは、「***割当方式が統一されない***」ことです。  
どのようなやり方であれ、アプリケーショ ン全体で首尾一貫していれば混乱はしません。

## シングルアクションコントローラ ## {#p7}
複数アクションを用意するのとは反対に、「1つのコントローラに1つのアクションだけしか用意しない」というような設計をすることもあります。このような場合には、「*シ ングルアクションコントローラ*」としてクラスを用意します。
シングルアクションコントローラは、特別なクラスというわけではありません。一般的なアクションメソッドの代わりに、「***_invoke***」というメソッドを使って処理を実装します。

<p class="tmp"><span>書式3</span>シングルアクションコントローラの基本形</p>
```
class コントローラ extends Controller
{
	public function__invoke() {
	...アクション処理......
    }
}
```
これ以外にアクションメソッドは用意しません。メソッドは追加できますが、それら はアクションとしての利用はできません。  
シングルアクションコントローラとして作成されたコントローラは、ルート情報の設定も少し変わってきます。
<p class="tmp"><span>書式4</span></p>
```
Route::get( 'アドレス', 'コントローラ名');
```
このように、コントローラ名だけを指定します。アクションの指定はしません。これにより、指定のアドレスにコントローラが割り当てられます。そしてそのアドレスにアクセスをすると、クラスの**_invoke**が呼び出され処理が実行される、というわけです。

### HelloController をシングルアクション化
では、実際にやってみましょう。HelloControllerクラスにシングルアクションコントローラを追加して下さい。

新規の場合、artisanコマンドで作成できます。

```
php artisan make:controller ShowProfile --invokable
```

<p class="tmp list"><span>リスト9</span>HelloController.php</p>
```
   public function __invoke() {

     return <<<EOF
<html>
<head>
<title>Hello</title>
<style>
body {font-size:16pt; color:#999; }
h1 { font-size:30pt; text-align:right; color:#eee;
  margin:-15px 0px 0px 0px; }
</style>
</head>
<body>
  <h1>Single Action</h1>
  <p>これは、シングルアクションコントローラのアクションです。</p>
</body>
</html>
EOF;

   }
```

コントローラの修正が終わったら、ルート情報です。web.phpを開き、HelloController のルート情報を削除して以下のリストを改めて追記します。
<p class="tmp list"><span>リスト10</span>web.php</p>
```
Route::get('hello10', 'HelloController@__invoke');
```
これで作業完了です。Webブラウザから/helloにアクセスをすると、「Single Action」 とタイトル表示されたWebページが表示されます。  
ここでは、割り当てるコントローラまたはアクションを示す第2引数には、コントローラ名だけしか記述されていません。  
これで、指定したコントローラの_invokeが呼び出されて処理が実行されるようになるのです。

<http://localhost:9051/hello10>

![](single_action.png)



## リクエストとレスポンス ## {#p8}
コントローラの基本的な使い方はだいぶわかってきたことでしょう。最後に、クライアントとサーバーの間のやり取りを管理する「***リクエスト(Request)***」と「***レスポンス (Response)***」について触れておきましょう。  
ここまで作成してきたアクションメソッドを見ると、引数も特に用意されておらず、 非常にあっさりとした構造でした。が、実際のWebアクセスというのは、内部で非常に 多くの情報をやり取りしています。  
既にPHPを使っている皆さんなら、アクセスに関する情報を取得するために、$_ REQUESTなどのグローバル変数を利用したことがあるでしょう。$_REQUESTは、リクエストに関する情報をまとめたものでした。 

クライアントからサーバーヘアクセスをしたとき、クライアントから送られてきた情報は「リクエスト」として扱われます。そしてサーバーからクライアントへ返送する情報は「レスポンス」として扱います。このリクエストとレスポンスをうまく扱うことが、 Webサイトへのアクセス処理にはとても重要なことでした。

このリクエストとレスポンスの情報は、Laravelでも利用することができます。これは、 **Illuminate\Http名前空間**に用意されている「**Request**」「**Response**」というクラスとして用 意されています。  
これらのオブジェクトには、リクエストまたはレスポンスに関する情報を保管するプ ロパティや、それらを操作するためのメソッドが用意されています。本格的な利用はも う少しLaravelを使いこなせるようになってから考えるとして、とりあえずこれらのオブジェクトがどんなものか、どう使うのかぐらいは覚えておきましょう。

![](request_response.png?classes=caption "図 クライアントからサーバーヘアクセスしたときの情報はリクエスト、サーバーからクライアント へと返送されるときの情報はレスポンスとしてまとめられている。")

## Request および Response ## {#p9}
では、実際にRequestおよびResponseオブジェクトを使ってみましょう。 HelloController.phpを以下のように修正して下さい。なお、今回はuse文などもすべて掲載しておきます。

<p class="tmp list"><span>リスト11</span>HelloController.php</p>
```
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;//追加

class HelloController extends Controller
{
 //コントローラークラス内に追加
   public function response(Request $request, Response $response) {

$html = <<<EOF
<html>
<head>
<title>Hello/Index</title>
<style>
body {font-size:16pt; color:#999; }
h1 { font-size:120pt; text-align:right; color:#fafafa;
  margin:-50px 0px -120px 0px; }
</style>
</head>
<body>
  <h1>Hello</h1>
  <h3>Request</h3>
  <pre>{$request}</pre>
  <h3>Response</h3>
  <pre>{$response}</pre>
</body>
</html>
EOF;
       $response->setContent($html);
       return $response;
   }

}
```

これで完成です。続いて、ルート情報の設定も行っておきましょう。web.phpに追記した文を削除し、新たに以下のリストを追加します。
<p class="list tmp"><span>リスト11-2</span>web.php</p>
```
Route::get('hello11', 'HelloController@response');
```
これで、/hello11にアクセスしたらHelloControllerのindexアクションが実行されるようになりました。  
では、/helloにWebブラウザからアクセスしてみましょう。クライアントからヘッダー 情報が、またレスポンスからはキャッシュコントロールや日付などの情報が得られてい るのがわかります。

<http://localhost:9051/hello11>

![](request_response2.png)



### アクションメソッドの引数定義
ここでは、まずRequestとResponseを利用するため、use文を追記してあります。
```
use Illuminate\Http\Request; 
use Illuminate\Http\Response;
```
Requestはデフォルトで用意されていましたので、それにResponseのuseを追加しています。これで両方のクラスが利用できるようになりました。  
これらの利用は、アクションメソッドで行います。indexを見ると、以下のような形 で定義されています。
```
public function index(Request $request, Response $response) {.......
```
引数に、RequestとResponseが用意されているのがわかります。このように、これらを引数に追加するだけでインスタンスが用意され、使えるようになります。

### Request の主なメソッド
では、Request/Responseの利用例として、いくつかのメソッドを紹介しておきましょう。まずはRequestからです。これは、アクセスしたURLに関するものがいくつか用意されているのでまとめておきましょう。
<p class="tmp"><span>書式5</span></p>
```
$request->url();
```

#### 例

$url = $request->url();  と　$urlを  <br>
public function index(Request $request, Response $response) { <br>
の中に追加してやると、アクセスしたURLが表示されます。

<p class="list tmp"><span>リスト12</span>web.php</p>
```
Route::get('hello12', 'HelloController@showUrl');
```


<p class="tmp list"><span>リスト13</span></p>
```
public function showUrl(Request $request, Response $response) {

   $url = $request->url();
   $response->setContent($url);
      return $response;
}
```
<http://localhost:9051/hello12>

![](Request_url.png)



*url*は、アクセスしたURLを返します。ただし、クエリー文字列(アドレスのあとに付けられる、?abc-xyzというようなテキスト)は省略されます。
<p class="tmp"><span>書式6</span></p>
```
$request->fullurl();
```
*fullUrl*は、アクセスしたアドレスを完全な形で返します(クエリー文字列も含まれます)。
<p class="tmp"><span>書式7</span></p>
```
$request->path();
```
*path*は、ドメイン下のパス部分だけを返します。

### Response の主なメソッド
続いてResponseです。こちらは、クライアントへ返送する際のステータスコード、表示コンテンツの設定などがあります。
<p class="tmp"><span>書式8</span></p>
```
$this->status();
```
アクセスに関するステータスコードを返します。これは正常にアクセスが終了していたら200になります。
<p class="tmp"><span>書式9</span></p>
```
$this->content(); $this->setContent(値);
```
コンテンツの取得・設定を行うものです。contentはコンテンツを取得し、setContent は引数の値にコンテンツを変更します。  
これらのオブジェクトは、これから先、Laravelを使いこなすにつれて利用価値が高まっていくことでしょう。まずは、ここに挙げたメソッドを使って、オブジェクトの使い方を覚えておきましょう。















