*[page-title]:Fork Awesome

公式サイト
: https://forkaweso.me/Fork-Awesome/
: [アイコンリスト](https://forkaweso.me/Fork-Awesome/icons/)

CDN
: `<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fork-awesome@1.2.0/css/fork-awesome.min.css" integrity="sha256-XoaMnoYC5TH6/+ihMEnospgm0J1PM/nioxbOUdnM8HY=" crossorigin="anonymous">`

CSSローカル設置した場合
```
<link rel="stylesheet" href="～/css/fork-awesome.min.css">
```

## クラスを設定し表示

```
	<p><i class="fa fa-camera-retro"></i> fa-camera-retro</p>
	<p><i class="fa fa-camera-retro fa-lg"></i> fa-lg</p>
	<p><i class="fa fa-camera-retro fa-2x"></i> fa-2x</p>
	```
#### 表示	
![](upload/fa_camera.png)


### リストの場合

```
<ul class="fa-ul">
	<li><i class="fa-li fa fa-check-square"></i>List icons</li>
	<li><i class="fa-li fa fa-check-square"></i>can be used</li>
	<li><i class="fa-li fa fa-spinner fa-spin"></i>as bullets</li>
	<li><i class="fa-li fa fa-square"></i>in lists</li>
</ul>
```

#### 表示
![](upload/fa_list.png)

## CSSにスタイルを設定

ホームのアイコンをスタイルシートに設定してみます。

<p class="tmp">CSS</p>
```
.icon-home {
	display: inline-block;
	font: normal normal normal 14px/1 ForkAwesome;
	font-size: inherit;
	text-rendering: auto;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
}

.icon-home:before {
	content: "\f015";
}
```

<p class="tmp">HTML</p>
```
<p><span class="icon-home">ホーム</span></p>
```

#### 表示
![](upload/fa_home.png)
