Vue.createApp({
  data: function() {
    return {
      email: 'Y-Suzuki@example.com'
    };
  }
}).mount('#app');