<?php
require_once("spyc.php"); // ()の部分にはspyc.phpを置いたパスを入れます
class spycTest {
    function testSpyc(){
        $yaml_output= spyc_load_file("yamlfile.yaml");// ()の部分にはyamlファイルがあるパスを入れます
        var_dump($yaml_output); // 結果を出力します。
    }
}

$taro = new spycTest();
$taro->testSpyc();

?>