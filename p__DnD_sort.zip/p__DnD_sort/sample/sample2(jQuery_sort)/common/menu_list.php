
<li id="item1" draggable="true">
    <a href="../p__test1/">メニュー1</a>
</li>
<li id="item2" draggable="true">
    <a href="../p__test2/">メニュー2</a>
    <ul class="sub-menu">
        <li id="item11" draggable="true">
        <a href="../p__test11/">メニュー11</a>
        </li>
        <li id="item12" draggable="true">
        <a href="../p__test12/">メニュー12</a>
    </ul>
</li>
<li id="item3" draggable="true">
    <a href="../p__test3/">メニュー3</a>
</li>
<li id="item4" draggable="true">
    <a href="../p__test4/">メニュー4</a>
</li>
<li id="item5" draggable="true">
    <a href="../p__test5/">メニュー5</a>
</li>
<li id="item6" draggable="true">
    <a href="../p__test6/">メニュー6</a>
</li>
<li id="item7" draggable="true">
    <a href="../p__test7/">メニュー7</a>
</li>
