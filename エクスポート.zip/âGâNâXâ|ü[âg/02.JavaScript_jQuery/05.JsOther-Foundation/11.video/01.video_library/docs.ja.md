---
title: 動画再生用ライブラリー
taxonomy:
    category:
        - docs
media_order: swap_theme.png
---

HTML5にvideoタグを挿入して動画を再生する場合、各ブラウザに備わっているプレイヤーでもいいとは思いますが、動画再生用のライブラリを使うことで、ブラウザーによって、ビデオコントロールパネル、ボタン、 Seekbarなどのスタイリングが違ってるのを、統一することができるという利点があります。  
また、見た目をカスタマイズしたり、イベント機能やプラグインも色々あるので便利です。

そこで、たくさんある動画再生ライブラリで、オープンソースで使えそうなのを調べてみました。  
（デモ用のcssやjsには、CDNを使ってよみこんでいます。）
まずは、Video.jsです。

## 1. Video.js

公式サイト
: <https://videojs.com/>
    
git
: [https://github.com/videojs/video.js](https://github.com/videojs/video.js)

オープンソースでは一番人気があり、ニュースサイトなどの動画でもたまに見かけたりします。
公式サイトによると、45万を超えるWebサイトで使用されていて、何百ものプラグインがあるそうです。  
テーマの切り替えで、スタイルを簡単に変更できるのもいいです。  公式ページトップのデモ画面右下にあるテーマ切り替えでそれぞれのスタイルを確認できます。![](swap_theme.png)

HLS動画の読み込みは、バージョン7以降では標準機能になっています。  
      
※中央にある再生ボタンは.、videoタグの「vjs-big-play-centered」のクラスをとると、左上に配置されます。
    
<a href="../../../sample/video/sample2(videojs)ieok/" target="_blank" class="external-link no-image">videojs（ver 7.12.4）デモ</a>
    
<iframe width="100%" height="450" src="../../../sample/video/sample2(videojs)ieok/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
    

    
HTML（Video.js）
```
<head>
	<meta charset="utf-8">
	<title>videojsデモ</title>
	<link href="https://vjs.zencdn.net/7.12.4/video-js.min.css" rel="stylesheet">
</head>

<body>
	<video id="my-video" class="video-js vjs-big-play-centered" controls preload="none" poster="video/thumb.png"
		data-setup='{"width": 640, "height": 360}'>
		<source src="video/sample.mp4" type="video/mp4">
	</video>

	<script src="https://vjs.zencdn.net/7.12.4/video.min.js"></script>
</body>
```
    
### video属性一覧
    
controls ～ 再生ボタンやボリューム調整ができるコントロールパネルを表示。
```
<video src="video/sample.mp4" controls></video>
```
    
autoplay ～ 自動再生
```
<video src="video/sample.mp4" autoplay muted></video>
```
chromeやsafariではmuted属性で音をミュートにしないと動きません。
    
loop ～ 繰り返し再生
```
<video src="video/sample.mp4" loop autoplay muted></video>
```
    
poster ～ 動画再生する前に静止画を表示。
```
<video src="video/sample.mp4" poster="thumb.png" controls></video>
```
    
preload ～ サイトを読み込むときに動画ファイルをダウンロードするか指定できる。
  
|	|説明|
|--|--|
|auto	|初期値。動画ファイル全体をダウンロードする|
|none	|事前のファイルダウンロード禁止にする（動画再生されたらダウンロード）|
|metadata	|長さやファイルサイズなどメタ情報だけをダウンロード|
    
### videojs関数で設定
    
data-setup属性を使用してプレーヤーのセットアップをトリガーしない場合は、videojs関数の2番目の引数としてプレーヤーオプションのオブジェクトを渡すことができます。
 
```
videojs('my-player', {
  controls: true,
  autoplay: false,
  preload: 'auto'
});
```
すべてのプレーヤーのデフォルトオプションはvideojs.optionsにあり、直接変更できます。 たとえば、すべてのプレーヤーに{autoplay：true}を設定するには：
 ```
videojs.options.autoplay = true;
```
をスクリプトに追記します。
    
参考　[https://docs.videojs.com/tutorial-setup.html](https://docs.videojs.com/tutorial-setup.html)

### Theme（テーマ）の変更
    
公式サイトのトップページにあるように、テーマを選択することが出来ます。
    
例えば、テーマを**{c:green}Forest{/c}**にする場合、  
`<link href="https://unpkg.com/@videojs/themes@1/dist/forest/index.css" rel="stylesheet" />`  
を追加で読み込んで、videoタグのクラスに、vjs-theme-forest を追記してやると下記のようにコントロールのスタイルが変わります。
    
<a href="../../../sample/video/sample3(videojs)ieok_theme/" target="_blank" class="external-link no-image">Forest(テーマ)デモ</a>
    
<iframe width="100%" height="450" src="../../../sample/video/sample3(videojs)ieok_theme/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

同じように、他のテーマについても専用のスタイルシートを読み込んで、videoタグに個々のクラスを追加してやります。
    
{c:orange}City{/c}
: `<link href="https://unpkg.com/@videojs/themes@1/dist/city/index.css" rel="stylesheet">`
: クラス: vjs-theme-city
    
{c:purple}Fantasy{/c}
: `<link href="https://unpkg.com/@videojs/themes@1/dist/fantasy/index.css" rel="stylesheet">`
: クラス: vjs-theme-fantasy
    
{c:deepskyblue}Sea{/c}
: `<link href="https://unpkg.com/@videojs/themes@1/dist/sea/index.css" rel="stylesheet">`
: クラス: vjs-theme-sea
    
    
## 2. Plyr

公式サイト
: <https://plyr.io/>

git
: <https://github.com/sampotts/plyr>
    
Plyrは、シンプルで高機能なHTML5メディアプレイヤーです。デザインが美しく、機能的です。  
ファイルサイズは軽量で、実装もシンプルで簡単です。  
以前、[国リハの紹介ビデオのページ](http://www.nvrcd.ac.jp/introduction/video-full/index.html)で使ったことがあります。  

vtt（字幕用テキストファイル）の読み込みが可能で、スクリーンリーダー（音声読み上げソフト）にも対応しています。  
ただ、現バージョンでは、IEに対応していませんでした。
    
    
<a href="../../../sample/video/sample(plyr)/" target="_blank" class="external-link no-image">Plyr（ver 3.5.0）デモ</a>    
※IE非対応 
<iframe width="100%" height="450" src="../../../sample/video/sample(plyr)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
    
HTML（ver 3.5.0）
```
<head>
    <meta charset="utf-8">
    <title>Plyr</title>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/plyr/3.5.0/plyr.css">
</head>

<body>
    <video id="player" controls poster="video/thumb.png">
        <source src="video/sample.mp4" type="video/mp4">
    </video>
</body>
<script src="//cdnjs.cloudflare.com/ajax/libs/plyr/3.5.0/plyr.min.js"></script>
<script type="text/javascript">
    const player = new Plyr('#player');
</script>
```

ver3.4.5をダウンロードして、<a href="../../../sample/video/plyr-3.4.5/demo/" target="_blank" class="external-link no-image">demo画面</a> 
では、一応表示できました。

また、バージョン2系を使えば、読み込み設定のスクリプトを
`const player = new Plyr('#player');`　から `plyr.setup();`に変更してやれば、IEでも使えます。
    

    
<a href="../../../sample/video/sample(plyr)ie/" target="_blank" class="external-link no-image">Plyr（ver2.0.18）デモ</a>    
    
    
HTML（ver2.0.18）
```
<head>
    <meta charset="utf-8">
    <title>Plyr ver2.0.18</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/plyr/2.0.18/plyr.css">

</head>

<body>
    <video id="player" controls poster="video/thumb.png">
        <source src="video/sample.mp4" type="video/mp4">
    </video>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/plyr/2.0.18/plyr.js"></script>
<script type="text/javascript">
    plyr.setup();
</script>
```
    
## 3. MediaElement.js

公式サイト
: <https://www.mediaelementjs.com/>
    
サイトでの情報も少なく、もしカスタマイズする場合は厳しいかもしれません。  
でも、操作してみて、大変シンプルで使いやすいと感じました。  
IEにも対応していました。
    

    
<a href="../../../sample/video/sample(MediaElement)/" target="_blank" class="external-link no-image">MediaElement.js（ver 4.2.6）デモ</a>    
    
<iframe width="100%" height="450" src="../../../sample/video/sample(MediaElement)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
    
HTML
```
<head>
    <meta charset="utf-8">
    <title>MediaElementデモ</title>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.16/mediaelementplayer.css" />
</head>

<body>
    <video id="player" width="640" height="360" type="video/mp4" poster="video/thumb.png">
        <source src="video/sample.mp4">
    </video>
    <script src="//cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.16/mediaelement-and-player.js"></script>
    <script type="text/javascript">
        var player = new MediaElementPlayer('player');
    </script>
</body>
```
    
## 4. Clapper

公式サイト
: <http://clappr.io/>
    
git
: <https://github.com/clappr/clappr>
    
シンプルでいいです。再生が終了したら、最初の画面に戻るようにデフォルトでなってる点もいいです。
ただ、キーボードでは操作できないので、サイトに組み込む場合、キーボードで操作できるように修正した方がいいかなと思います。
    
<a href="../../../sample/video/sample_clappr_ver0.4.5/" target="_blank" class="external-link no-image">Clapper（ver 0.4.5）デモ</a> 

※IE非対応
    
<iframe width="100%" height="450" src="../../../sample/video/sample_clappr_ver0.4.5/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTML（ver 0.4.5）
```
<head>
    <title>Clappr Playerデモ(Responsive)</title>
    <meta charset="UTF-8">
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/clappr/0.4.5/clappr.min.js"></script>
</head>

<body>
    <div id="player"></div>
    <script>
        var player = new Clappr.Player({
            source: "video/sample.mp4",
            parentId: "#player",
            poster: "video/thumb.png",
        });
    </script>
</body>
```

以前のバージョンを使えば、IEでも対応できました。

<a href="../../../sample/video/sample_clappr_ver0.2.86/" target="_blank" class="external-link no-image">Clapper（ver 0.2.86）デモ</a> 

HTML（ver 0.2.86）
```
<head>
    <title>デモ Clappr Player ver 0.2.86</title>
    <meta charset="UTF-8">
    <!-- Player -->
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/clappr/0.2.86/clappr.min.js"></script>
</head>

<body>
    <div id="player"></div>
    <script>
        var player = new Clappr.Player({
            source: "sample.mp4",
            parentId: "#player",
            poster: "thumb.png"
        });
    </script>
</body>
```
    
    
## 5. JPlayer
    
公式サイト
: <http://jplayer.org/>
    
デモ
: <http://jplayer.org/latest/demo-01-video/>
    
***
以上になります。

有料のものはたくさんありますが、フリーで目についたのはこの５つです。（他にもいいのがあるかもしれませんが）    
個人的に良さそうなのから順番に掲載しています。  
ひとつ目のvideojsが最新のバージョンでもIEに対応していて、またテーマを切り替えるだけでコントロールなどのスタイル変わるので、この中では一番いいかなと思いました。  
興味がありましたら、試しに使ってみて下さい。

