let simplemde = new SimpleMDE({
    element: document.getElementById("report-markdown"),
    forceSync: true,
    spellChecker: false,
    renderingConfig: {
        singleLineBreaks: false,
        codeSyntaxHighlighting: true,
    },
    insertTexts: {
        horizontalRule: ["", "\n\n-----\n\n"],
        //image: ["![](http://", ")"],
        //link: ["[", "](http://)"],
        // table: ["", "\n| Column 1 | Column 2 | Column 3 |\n| -------- | -------- | -------- |\n| Text     | Text      | Text     |\n\n"],
        table: ["", "\n Column 1 | Column 2 | Column 3 \n -------- | -------- | -------- \n Text     | Text      | Text     \n\n"],
    },
    toolbar: [
        'bold',
        {
            name: 'font-bold-color',
            className: 'fa fa-font tool-icon fa-bold fa-bold-red',
            title: '太字の色付文字',
        },
        {
            name: 'font-bold-arrow',
            className: 'fa bold-arrow',
            title: '太字の文字色のグループを開きます',
        },
        //'italic',
        // 'heading',
        '|',
        'quote',
        '|',
        'unordered-list',
        'ordered-list',
        '|',
        'link',
        'image',
        'table',
        {
            name: 'tb-side',
            className: 'fa fa-tbside',
            title: '横見出しテーブル',
        },
        {
            name: 'font-color',
            className: 'fa fa-font tool-icon fa-color fa-red',
            title: '文字色',
        },
        {
            name: 'font-color-arrow',
            className: 'fa color-arrow',
            title: '文字色のグループを開きます',
        },
        {
            name: 'text-mark',
            className: 'fa fa-font tool-icon fa-marker marker-yellow50',
            title: 'マーカー',
        },
        {
            name: 'font-marker-arrow',
            className: 'fa marker-arrow',
            title: 'マーカーのグループを開きます',
        },
        '|',
        {
            name: 'fa-strikethrough',
            className: 'fa fa-strikethrough',
            title: '取り消し線',
        },
        {
            name: 'div-mark"',
            className: 'fa fa-div-mark',
            title: 'div markdown="1"設置',
        },
        {
            name: 'tbCap',
            className: 'fa fa-tbCap',
            title: 'テーブルキャプション',
        },
        {
            name: 'details',
            className: 'fa fa-details',
            title: '<details><summary>～</summary></details>',
        },
        '|',
        {
            name: 'tag',
            className: 'fa tool-icon fa-tag',
            title: 'タグ',
        },
        {
            name: 'tag-arrow',
            className: 'fa tag-arrow',
            title: 'タグのグループを開きます',
        },

        // '|',
        // {
        //     name: 'emoji',
        //     className: 'fa fa-emoji',
        //     title: '絵文字参照サイトを開きます',
        // },
        '|',
        {
            name: 'today',
            className: 'fa fa-clock-o',
            title: '今日の日付',
        },
        '|',
        {
            name: 'ph-border',
            className: 'fa fa-object-group',
            title: '画像枠線',
        },
        {
            name: 'ph-border-check',
            className: 'fa ph-check',
            title: '画像枠線を挿入時に入れる',
        },
        '|',
        {
            name: 'fig-top',
            className: 'fa fa-fig-top',
            title: '画像の上にタイトル',
        },
        '|',
        {
            name: 'arrow-down',
            className: 'fa fa-arrow-down',
            title: '下矢印',
        },        
        // {
        //     name: 'upload"',
        //     className: 'fa fa-upload',
        //     title: 'uploadフォルダのパスを表示します。',
        // },

        '|',
        'fullscreen',
    ]
});

//文字色
const button_list = '<div class="icon-box color-group"><button class="fa fa-font fa-color fa-red" title="赤色"></button><button class="fa fa-font fa-color fa-blue" title="青色"></button><button class="fa fa-font fa-color fa-green" title="緑色"></button><button class="fa fa-font fa-color fa-purple" title="紫色"></button><button class="fa fa-font fa-color fa-orange" title="オレンジ色"></button><button class="fa fa-font fa-color fa-skyblue" title="水色"></button><button class="fa fa-font fa-color fa-gray" title="灰色"></button><button class="fa fa-font fa-color fa-white" title="白色"></div>';

$('.color-arrow').html(button_list);//読み込んだときに「div.color-arrow」の要素の中に挿入

//太字文字色
const button_list_bold = '<div class="icon-box bold-group"><button class="fa fa-font fa-bold fa-bold-red" title="赤太字"></button><button class="fa fa-font fa-bold fa-bold-blue" title="青太字"></button><button class="fa fa-font fa-bold fa-bold-green" title="緑太字"></button><button class="fa fa-font fa-bold fa-bold-purple" title="紫太字"></button><button class="fa fa-font fa-bold fa-bold-orange" title="オレンジ色太字"></button><button class="fa fa-font fa-bold fa-bold-skyblue" title="水色太字"></button><button class="fa fa-font fa-bold fa-bold-gray" title="灰色太字"></button><button class="fa fa-font fa-bold fa-bold-white" title="白太字"></button></button><button class="fa fa-font fa-bold fa-bold-green-marker" title="太字の緑文字 マーカー"></button></div>';

$('.bold-arrow').html(button_list_bold);

//色別マーカー
const button_list_marker = '<div class="icon-box marker-group"></button><button class="fa-font fa-marker marker-pink" title="ピンクマーカー"></button><button class="fa-font fa-marker marker-blue" title="青マーカー"></button><button class="fa-font fa-marker marker-yellow" title="黄色マーカー"></button><button class="fa-font fa-marker marker-green" title="緑マーカー"></button><button class="fa-font fa-marker marker-orange" title="オレンジマーカー"></button><button class="fa-font fa-marker marker-pink50" title="ピンクマーカー"></button><button class="fa-font fa-marker marker-blue50" title="青マーカー"></button><button class="fa-font fa-marker marker-yellow50" title="黄色マーカー"></button><button class="fa-font fa-marker marker-green50" title="緑マーカー"></button><button class="fa-font fa-marker marker-orange50" title="オレンジマーカー"></div>';

$('.marker-arrow').html(button_list_marker);

//タグ
const button_list_tag = '<div class="icon-box tag-group"><button class="fa fa-tag tmp" title="書式タグ"></button><button class="fa fa-tag tmpList" title="リストタグ"></button><button class="fa fa-tag cmd" title="コマンドタグ"></button><button class="fa fa-tag lang" title="言語タグ"></button><button class="fa fa-tag result" title="結果タグ"></button><button class="fa fa-tag exp" title="例タグ"></button><button class="fa fa-tag sql" title="SQLタグ"></button></div>';

// $('.fa-tag').html(button_list_tag);
$('.tag-arrow').html(button_list_tag);


//uploadフォルダパス表示
$(".fa-upload").click(function () {
    prompt('uploadフォルダのパスです。', 'uploadパス');
});



//拡大
$(".fa-arrows-alt").click(function () {
    $('a.fa.fa-preview').toggleClass('d-inline-block');
});

$('.fa-preview').on('click', function () {
    $('#btn-markpreview').trigger('click');
});


//マークダウンテキストエリアに![](img数字)の文字を挿入
$(".btn-markimg").click(function () {
    var valText = $(this).val();
    var line = simplemde.codemirror.getCursor().line;
    var ch = simplemde.codemirror.getCursor().ch;

    //文字列の挿入
    var text = '![](' + valText + ')';
    simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });

    $(this).hide();
});


//divを設置
$('.fa-div').on('click', function () {
    //選択した文字列の取得
    var selected = simplemde.codemirror.getSelection();
    //文字列の置き換え
    var text = '<div class="" markdown="1">\n' + selected + '\n</div>';
    simplemde.codemirror.replaceSelection(text);
});

//モーダルを設置
$('.fa-modal').on('click', function () {
    //選択した文字列の取得
    var selected = simplemde.codemirror.getSelection();
    //文字列の置き換え
    var text = '[![](img～){.wd350}](img～){.modal-win}';
    simplemde.codemirror.replaceSelection(text);
});

//YouTube動画を埋め込み
$('.fa-youtube').on('click', function () {
    tubeInput();
});

//テキストエリアの記事を削除
$('.fa-clear').on('click', function () {
    if (window.confirm('テキストエリアの記事を全部削除しますが、よろしいですか？')) {
        simplemde.value("");
        return true;
    } else {
        return false;
    }
});


function tubeInput() {
    // 入力ダイアログを表示 
    tubeUrl = window.prompt("You TubeのURLを入力してください。", "");

    var regexp = new RegExp(/www\.youtube\.com/);
    var result = regexp.test(tubeUrl);

    if (result) {
        //文字列の挿入

        var tubeUrl = tubeUrl.replace('watch?v=', 'embed/');

        var text = '<div class="embed-responsive embed-responsive-16by9">\n' +
            '<iframe class="embed-responsive-item" src="' + tubeUrl + '" allowfullscreen></iframe>\n' +
            '</div>';

        simplemde.codemirror.replaceSelection(text);
    }
}


//拡大
$(".fa-arrows-alt").click(function () {
    $('a.fa.fa-preview').toggleClass('d-inline-block');
    $('#update').toggleClass('screen-full');
});

$('.fa-preview').on('click', function () {
    $('#btn-markpreview').trigger('click');
});


//マークダウンテキストエリアに![](img数字)の文字を挿入
$(".btn-markimg").click(function () {
    let valText = $(this).val();
    let line = simplemde.codemirror.getCursor().line;
    let ch = simplemde.codemirror.getCursor().ch;

    //文字列の挿入
    let text = '![](' + valText + ')';
    simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });

    $(this).hide();
});

//マークダウンにファイルリンクや画像コードを挿入
$('ul#waitingList').on('click', '.fileInsert', function () {
    let valText = $(this).siblings('.filename').text();
    let line = simplemde.codemirror.getCursor().line;
    let ch = simplemde.codemirror.getCursor().ch;

    if ($(this).parent('li').hasClass('photo-list')) {
        //画像の挿入
        let bdCheck = '';
        if ($('.ph-check').hasClass('border-true')) {
            //チェック有り
            bdCheck = '{.photo-border}';
        }

        let text = '![]' + '(upload/' + valText + ')' + bdCheck;

        simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });
        alert('「' + valText + '」画像のコードを記入しました');
    } else {
        //文字列の挿入
        let text = '[' + valText + '](upload/' + valText + ')';
        simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });
        alert('「' + valText + '」 ファイルリンクを記入しました');
    }
    return false;
});


const colorAry = ['red', 'blue', 'green', 'purple', 'gray', 'white', 'skyblue', 'orange'];
const markerAry = ['marker-yellow50', 'marker-red50', 'marker-blue50', 'marker-green50', 'marker-gray50', 'marker-orange50', 'marker-yellow', 'marker-red', 'marker-blue', 'marker-green', 'marker-gray', 'marker-orange'];
const tagAry = ['tmp', 'tmpList', 'cmd', 'sql', 'lang', 'result', 'exp'];

const faColorAry = colorAry.map(function (value) {//配列の値に「fa-」をつける
    return 'fa-' + value;
});

const faBoldAry = colorAry.map(function (value) {//配列の値に「fa-bold-」をつける
    return 'fa-bold-' + value;
});


//フォント、タグ用（色、太字、黄色マーカー）
$('.fa-font, .fa-marker').on('click', function () {

    let faClsTwo = $(this).attr('class').split(' ').slice(-2)[0];//後ろから2番目のクラス 例）fa-color、fa-bold、fa-marker
    let faCls = $(this).attr('class').split(' ').slice(-1)[0];//例 fa-red、fa-bold-red、marker-yellow50
    let faClsAry = [];
    let faClsJoin = '';

    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    let text;
    let existCls = selected.replace(/^<span class="(.*)"(.*)<\/span>$/, '$1')
    let clsAry = existCls.split(' ');

    if (faClsTwo == 'fa-color' || faClsTwo == 'fa-bold') {
        faClsAry = faCls.split('-');
        faClsAry.splice(0, 1);//配列から「fa-」を取り除く 
        faClsJoin = faClsAry.join(' ');//クラスがないとき追加するクラス 例 red、bold red

        //既存の色クラスを削除する　※getIsDuplicateは重複があるか判定する独自関数
        if (getIsDuplicate(colorAry, faClsAry) && getIsDuplicate(colorAry, clsAry)) {
            clsAry = clsAry.filter(function (v) {
                return !colorAry.includes(v);
            });
        }

    } else if (faClsTwo == 'fa-marker') {
        //マーカー
        faClsAry = [faCls];
        faClsJoin = faCls;

        //既存のマーカークラスを削除する　※getIsDuplicateは重複があるか判定する独自関数
        if (getIsDuplicate(markerAry, faClsAry) && getIsDuplicate(markerAry, clsAry)) {
            clsAry = clsAry.filter(function (v) {
                return !markerAry.includes(v);
            });
        }

    } else if (faClsTwo == 'fa-tag') {
        //タグ
        faClsAry = [faCls];
        faClsJoin = faCls;

        //既存のマーカークラスを削除する　※getIsDuplicateは重複があるか判定する独自関数
        if (getIsDuplicate(tagAry, faClsAry) && getIsDuplicate(tagAry, clsAry)) {
            clsAry = clsAry.filter(function (v) {
                return !tagAry.includes(v);
            });
        }

    } else if (faClsTwo == 'fa-exp') {
        //タグ
        faClsAry = [faCls];
        faClsJoin = faCls;

        //既存のマーカークラスを削除する　※getIsDuplicateは重複があるか判定する独自関数
        if (getIsDuplicate(tagAry, faClsAry) && getIsDuplicate(tagAry, clsAry)) {
            clsAry = clsAry.filter(function (v) {
                return !tagAry.includes(v);
            });
        }
    }

    //clsArrayとfaClsAryの配列を統合する
    let clsAryAll = [...clsAry, ...faClsAry];
    //同じクラスを統合する
    let newClsAry = new Set(clsAryAll);
    newClsAry = [...newClsAry];
    let fontCls = newClsAry.join(' ');//結合してクラスを作成

    switch (existCls) {
        case selected://classなし
            text = '<span class="' + faClsJoin + '">' + selected + '</span>';
            break;
        case ''://classが空のとき
            text = '<span class="' + faClsJoin + '">' + selected + '</span>';
            break;
        default://classがあるとき
            text = selected.replace(/^<span class="(.*)"(.*)<\/span>$/, '<span class="' + fontCls + '"$2<\/span>')
            break;
    }

    simplemde.codemirror.replaceSelection(text);


    const toolIcon = '.tool-icon' + '.' + faClsTwo;

    //ツールバーのアイコンのクラスを削除
    faColorAry.forEach(value => {
        $(toolIcon).removeClass(value);
    });

    faBoldAry.forEach(value => {
        $(toolIcon).removeClass(value);
    });

    markerAry.forEach(value => {
        $(toolIcon).removeClass(value);
    });

    tagAry.forEach(value => {
        $(toolIcon).removeClass(value);
    });

    //ツールバーのアイコンにクリックしたアイコンのクラス追加
    $(toolIcon).addClass(faCls);

    timeReset();
});


//2つの配列の中に重複した要素があるか判定
function getIsDuplicate(arr1, arr2) {
    return [...arr1, ...arr2].filter(item => arr1.includes(item) && arr2.includes(item)).length > 0
}


//取り消し線
$('.fa-strikethrough').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //文字列の置き換え
    let text = '~~' + selected + '~~';
    simplemde.codemirror.replaceSelection(text);
});

//div設置
$('.fa-div').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //文字列の置き換え
    let text = '<div class="">\n' + selected + '\n</div>';
    simplemde.codemirror.replaceSelection(text);
});


//div class="markdown"設置
$('.fa-div-mark').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //文字列の置き換え
    let text = '<div markdown="1" class="">\n' + selected + '\n</div>';
    simplemde.codemirror.replaceSelection(text);
});


//例タグ設置
$('.exp').on('click', function () {
    //コード挿入
    let text = '<div class="exp" markdown="1">\n<p class="tmp"><span>例</span></p>\n</div>';
    simplemde.codemirror.replaceSelection(text);
});


//横見出しテーブル
$('.fa-tbside').on('click', function () {
    //コード挿入
    let text = '<table>\n\t<tbody>\n\t\t<tr>\n\t\t\t<th>Column 1</th>\n\t\t\t<td>Text</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<th>Column 2</th>\n\t\t\t<td>Text</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<th>Column 3</th>\n\t\t\t<td>Text</td>\n\t\t</tr>\n\t</tbody>\n</table>';
    simplemde.codemirror.replaceSelection(text);
});

//テーブルキャプション
$('.fa-tbCap').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //文字列の置き換え
    let text = '<p class="tb-caption"><span>表</span>' + selected + '</p>';
    simplemde.codemirror.replaceSelection(text);
});

//details
$('.fa-details').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //コード挿入
    let text = '<details><summary>タイトル</summary>\n\t' + selected + '\n</details>';
    simplemde.codemirror.replaceSelection(text);
});



//今日の日付
$('.fa-clock-o').on('click', function () {
    //日付を記入

    //現日時を取得
    let now = new Date();

    //現日時から年月日取得
    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    // 0～11で月を取得するので、1を足します。
    let day = now.getDate();
    //時間を取得
    let hour = now.getHours();
    //let min = now.getMinutes();
    let min = ("0" + now.getMinutes()).slice(-2) //分は2桁表示

    //現日時から曜日取得
    let week = now.getDay();
    //日曜日を0とし、0～6で曜日を取得するので、表示には変換が必要です。
    let convert = new Array("日", "月", "火", "水", "木", "金", "土");
    let today = +month + '/' + day + '（' + convert[week] + '）' + hour + ':' + min;

    simplemde.codemirror.replaceSelection(today);
});

//画像に枠線を付ける
$('.fa-object-group').on('click', function () {
    //枠線クラス設置
    let text = '{.photo-border}';
    simplemde.codemirror.replaceSelection(text);
});

//画像の上に見出しを付ける
$('.fa-fig-top').on('click', function () {
    //枠線クラス設置
    let text = '{.fig-top}';
    simplemde.codemirror.replaceSelection(text);
});

//下向き矢印挿入
$('.fa-arrow-down').on('click', function () {
    //コード挿入
    let text = '<span class="arrow-down-24 ms-5"></span>';
    simplemde.codemirror.replaceSelection(text);
});


//アイコングループ開閉
// $('.fa-bold-color, .text-mark, .fa-tag').on('click', function (e) {
//     $('.icon-box').not($(this).children('.icon-box')).removeClass('show');//クリックした以外のアイコングループは閉じる
//     $(this).children('.icon-box').toggleClass('show');
// });

//編集エリアの外をクリックすると、開いているアイコングループを閉じる
$(document).on('click', function (e) {
    if (!$(e.target).closest('.editor-toolbar, .CodeMirror-wrap').length) {
        $('.icon-box').removeClass('show');
    }
});

let timeId;
const openTime =8000;
const openReTime = 5000;

//グループボックス開閉
$('.color-arrow, .bold-arrow, .marker-arrow, .tag-arrow').on('click', function (e) {
    clearTimeout(timeId);
    timeId = setTimeout(main, openTime);
    
    $('.icon-box').not($(this).children('.icon-box')).removeClass('show');
    $(this).children('.icon-box').toggleClass('show');
});

function main() {
    $('.icon-box').removeClass('show');
}

function timeReset(){
    // clearTimeout(timeId);
    // timeId = setTimeout(main, openReTime);
    $('.icon-box').removeClass('show');
    event.stopPropagation();
}


//書式用タグ設置
$('.tmp').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //コード挿入
    let text = '<p class="tmp"><span>書式</span>' + selected + '</p>';
    simplemde.codemirror.replaceSelection(text);
    timeReset();
});

//リスト用タグ設置
$('.tmpList').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //コード挿入
    let text = '<p class="tmp list"><span>リスト</span>' + selected + '</p>';
    simplemde.codemirror.replaceSelection(text);
    timeReset();
});

//コマンド用タグ設置
$('.cmd').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //コード挿入
    let text = '<p class="tmp cmd"><span>コマンド</span>' + selected + '</p>';
    simplemde.codemirror.replaceSelection(text);
    timeReset();
});

//SQL用タグ設置
$('.sql').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //コード挿入
    let text = '<p class="tmp sql"><span>SQL文</span>' + selected + '</p>';
    simplemde.codemirror.replaceSelection(text);
    timeReset();
});

//言語用タグ設置
$('.lang').on('click', function () {
    //選択した文字列の取得
    let selected = simplemde.codemirror.getSelection();
    //コード挿入
    let text = '<p class="lang">' + selected + '</p>';
    simplemde.codemirror.replaceSelection(text);
    timeReset();
});

//結果用タグ設置
$('.result').on('click', function () {
    //コード挿入
    let text = '<p class="result"><span>結果</span></p>';
    simplemde.codemirror.replaceSelection(text);
    timeReset();
});

//枠線チェックボックス入り無し切り替え
$('.ph-check').on('click', function () {
    $(this).toggleClass('border-true');
});