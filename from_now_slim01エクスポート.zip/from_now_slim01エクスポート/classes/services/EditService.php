<?php
namespace SocymSlim\SlimMiddle\Services;
use Slim\Views\Twig;
use PDO;
use PDOException;
use Psr\Container\ContainerInterface;


class EditService {
    private $container;
    
    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }
    
    public function config(): array {
        return $this->container->get('config');
    }
    
    
    public function view(){
        $config = $this->container->get('config');
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"].$config["basePath"]."/templates");
        return $twig;        
    } 
    
    
    public function db() {
        $config = $this->container->get('config')['db'];
        $database   = $config['dbname'];
        $dbUsername = $config['user'];
        $dbPassword = $config['pass'];
        $host       = $config['host'];
        $port       = $config['port'];

        try {
            $dsn = "mysql:host={$host};port={$port};dbname={$database};charset=utf8";
            $db = new PDO($dsn, $dbUsername, $dbPassword);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $db;
        } catch (PDOException $e) {
            // Slim の ErrorMiddleware でも拾えるように例外を再スロー
            throw new PDOException($e->getMessage(), (int)$e->getCode());
        }
    }
}