$(function(){
    var dir = -1;
    var count = $("#slide-inner li").length;//画像の枚数
    var prev = count;
    var current = 1;
    var next = 2;
    var interval = 6000;//画像が切り替わる間隔
    var timer;// タイマー用の変数
	
    //ナビボタン設置
    for ( var i = 1 ; i <= count ; i++ ){
        $("#btn-navbox").append('<button value="'+i+'"><span class="sr-only">'+i+'枚目</span></button>'); //ナビボタンの作成
    }
  
    $("#btn-navbox button:first-child").addClass('target');//先頭のボタンの色を変える
	
    // SlideTimer();
    timer = setInterval(slideTimer, interval);

    var countup = function(){
      if(dir===-1){//正方向
          $("#slide-inner li:nth-child(" + current + ")").removeClass('active left');
          $("#slide-inner li:nth-child(" + next + ")").addClass('active');
          $("#slide-inner li:nth-child(" + next + ")").removeClass('left');

          prev = current;
          current = next;
          next = ++next;

          if(next > count){
              next = 1;
          }
      }else{//逆方向
          $("#slide-inner li:nth-child(" + current + ")").removeClass('active right');
          $("#slide-inner li:nth-child(" + prev + ")").addClass('active');
          $("#slide-inner li:nth-child(" + prev + ")").removeClass('right');

          next = current;
          current = prev;
          prev = --prev;

          if(prev < 1){
              prev = count;
          }
      }

        $('#slide').removeClass('btnOff');
        dir= -1;//正方向に戻す
    } 

    // slideTimer関数
    function slideTimer(){

        $('#slide').addClass('btnOff');

        if(dir===-1){//正方向
            $("#slide-inner li:nth-child(" + current + "),#slide-inner li:nth-child(" + next + ")" ).addClass('left');
            setTimeout(countup, 600);
            $("#btn-navbox button").removeClass("target");
            $("#btn-navbox button:nth-child("+ next +")").addClass("target");
        }else{//逆方向
            $("#slide-inner li:nth-child(" + current + "),#slide-inner li:nth-child(" + prev + ")" ).addClass('right');
            setTimeout(countup, 600);
            $("#btn-navbox button").removeClass("target");
            $("#btn-navbox button:nth-child("+ prev +")").addClass("target");
        }
    }
	
    // 前へボタン
    $(".slick-prev").click(function(){
        if (!$('#slide').hasClass('btnOff')){
            dir = 1;
            clearInterval(timer);
            slideTimer();
        }
    });
	
    // 次へボタン
    $(".slick-next").click(function(){
        if (!$('#slide').hasClass('btnOff')){
            dir= -1;
            clearInterval(timer);
            slideTimer();
        }
    });

	
    //ナビボタン
    $("#btn-navbox button").click(function(){
        current = $(this).val();
        prev = current-1;
        next = parseInt(current) + 1;

        if(next > count){
            next = 1;
        }
        if(prev < 1){
            prev = count;
        }

        dir= -1;
        $("#btn-navbox button").removeClass("target");
        $(this).addClass("target");
        $("#slide-inner li").removeClass('active');
        $("#slide-inner li:nth-child(" + current + ")" ).addClass('active');
        clearInterval(timer);
        timer = setInterval(slideTimer, interval);
    });
    
    //画像にマウスオーバー時は、スライド停止させる
    $('#slide').hover(function() {
        clearInterval(timer);
    }, function() {
        clearInterval(timer);
        timer = setInterval(slideTimer, interval);
    });
});
