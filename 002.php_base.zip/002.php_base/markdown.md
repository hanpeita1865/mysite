*[page-title]:PHPについて

PHPは1995年に生まれたプログラミング言語です。  
動的にWebページを生成することができるサーバーサイドのスクリプト言語で、他のプログラミング言語と比較して仕様や文法が簡単なため習得しやすいと言われています。またMySQLなどのデータベースとの連携が容易なことなどから、「<span class="red">WordPress</span>」を含めたWebアプリケーションの開発にもよく使われる有名なスクリプト言語でもあります。  

こういったWordPressなどのCMSのようにコードの知識なしでも使うことができるWebアプリケーションはありますが、PHPのプログラミングの知識を持つことで、よりオリジナルで自由なWebサイトを作ることができるようになります。

JavaScriptとPHPは、動的Webページ制作に使う点で共通している言語です。しかし、処理をする場所が異なっています。  
JavaScriptは、ユーザーが Webページ訪問時に利用したブラウザに合わせ、ユーザーの<span class="blue">パソコン上で処理</span>をするクライアントサイドのプログラミング言語です。対してPHPは、Webページの表示リクエストを受けた<span class="red">サーバー側で処理</span>をし、ユーザーのパソコンにデータを送信するサーバーサイドのプログラミング言語になっています。

これらの違いから、JavaScriptは訪問者それぞれに合ったWebページ表示をしたいときに利用され、PHPは訪問者全員に同じWebページ表示をしたいときに利用されます。また、JavaScriptとPHPの両方の機能を使いたいときは、同時に利用することも可能です。

<!--プログラミング言語には非常に多くの種類があり、言語ごとに得意とする分野があります。そのなかでPHPが得意とするのは、Webアプリケーションの開発です。Webアプリケーションとは、イ ンターネットなどのネットワークを介して利用するアプリケーションソフトウェアのことです。

プログラミング言語は、高機能なアプリケーションの作成に適した高度なものから、比較的簡単 なアプリケーションの作成に適した簡易的なものまでさまざまです。簡易的なプログラミング言語のことを「スクリプト言語」と呼ぶことがあり、スクリプト言語で書かれたプログラムのことを「スクリプト」と呼びます。PHPで記述したプログラムについては、プログラムという呼び方と、スクリプトという呼び方の、両方が使われています。-->

下記はPHPの公式マニュアルです。  
URL <http://php.net/manual/ja/index.php>



## リクエストとレスポンス
ユーザーがブラウザを操作すると、ブラウザはネットワークを介して、Webサーバに要求を送信します。この要求のことを「***リクエスト***」と呼びます。  
Webサーバはリクエストを受け取ると、Webアプリケーションの機能を提供するプログラムを実行し、実行結果を応答として、ネットワークを介してブラウザに送信します。この応答のことを「***レスポンス***」と呼びます。  
ユーザーとブラウザがいる側のことを「クライアントサイド」、Webサーバがいる側のことを 「サーバサイド」と呼ぶことがあります。PHP言語を使ったスクリプトは、<span class="red bold">サーバサイドで動作</span>します。

![](upload/request_response.jpg)


※リクエストとレスポンスは、HTTP (Hypertext Transfer Protocol) と呼ばれる通信プロトコ ルに基づいて行われます。通信プロトコルとは、ネットワーク上で通信を行うための取り決めのことです。  


## PHPが実現する機能
非常に簡潔なプログラムで、Webアプリケーションを構築できることがPHPの特徴です。例えば、ログインやログアウトといったユーザー認証機能を実現することができます。ユーザー認証は 多くのWebアプリケーションに必須な機能です。ショッピング・バンキング・ブログ・ SNSのいずれも、ユーザー認証機能を含んでいます。  

また、ネット通販などのショッピングサイトにおけるカート機能を実現することができます。 カートとは、これから注文する商品を決済するまで一時的に登録しておく機能で、多くのショッピングサイトがカートの機能を備えています。 これらの機能を実現するうえで重要なのは、次のような処理です。

* リクエストを解析する処理 
* データベースを操作する処理 
* レスポンスを生成する処理

![](upload/web_application.jpg)

ブラウザから送信されたリクエストを解析し、リクエストに対応した処理を行って、ブラウザに対してレスポンスを送信します。リクエストに対応した処理の典型的な例は、「<span class="red">データベースを操作する処理</span>」です。  
PHPはこれらの処理を簡潔に記述するための機能を備えています。そのため、PHPはWebアプ リケーションを実現するのに向いた言語となっています。


## HTMLとPHPの違い
PHPが<span class="bold">動的</span>にWebページを生成するのに対してHTMLは<span class="bold">静的</span>にWebページの表示を行います。「**静的なWebページ**」とはいつ誰が見ても同じように表示されるページで、一方の「<span class="red bold">動的なWebページ</span>」とはアクセスしたタイミングや状況によって表示内容が変わるページのことです。  
HTMLは、プログラムを記述するためのものではないので、<span class="bold">プログラミング言語</span>とは呼ばれません。  

固定内容のWebページを表示する場合は、HTMLファイルを使用します。HTMLファイルではできない、リクエスト内容に応じて変化する処理を行うためには、PHPスクリプトを利用します。




PHPの主な特徴として、<span class="red">HTMLで記述したファイルの中に埋め込んで使える</span>ことがあげられます。HTMLで記述された内容の途中にPHPのプログラムを記述するわけです。これによってPHP・HTMLを別々のファイルとして扱うのでなく、1つのファイルにまとめられるので便利です。  
例えば、こんな感じで記述します。

<p class="lang">select-for-input3.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PHP</title>
</head>
<body>
<p>購入数を選択してください。</p>
<form action="select-for-output.php" method="post">
<select name="count">
<?php
$i=0;
while ($i<10) {
    echo '<option value="', $i, '">', $i, '</option>';
    $i++;
}
?>
</select>
<p><input type="submit" value="確定"></p>
</form>
</body>
</html>
```

<p class="lang">select-for-output.php</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PHP</title>
</head>
<body>
<?php
echo $_REQUEST['count'], '個の商品をカートに追加しました。';
?>
</body>
</html>
```

#### 動作確認
<iframe width="100%" height="250" src="sample/shop/select-for-input3.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

## PHPスクリプトが動く仕組み
PHPスクリプトは、サーバサイドに配置します。ブラウザからWebサーバにリクエストが届くと、WebサーバはPHPスクリプトを実行して、実行結果をレスポンスとしてブラウザに返します。  
PHPスクリプトには、何でも好きな処理を組み込むことができます。リクエストの内容に応じて、多種多様なレスポンスを返すことができます。また、サーバサイドにあるファイルやデータベースを操作することによって、複雑な機能を実現することも可能です。

![](upload/how_works.jpg)


またPHPと共に、Webページ生成の際によく使われるプログラミング言語としてJavaScriptがあります。PHPがサーバーサイドの言語であるのに対し、JavaScriptはクライアントサイドの言語と言われます。簡単に言い換えると、<span class="red">PHPの処理</span>は「<span class="red bold">Webサーバー側</span>」で行われるのに対して、<span class="blue">JavaScriptの処理</span>はWebページを参照するユーザー側の「<span class="blue bold">ブラウザ上</span>」で行われます。  
サーバーサイドのPHPはサーバー側にあるMySQLなどのデータベースと連携することが可能です。

## 参考サイト

* [第1章 PHPが動く仕組み | GRAYCODE PHPプログラミング](https://gray-code.com/php/how-the-php-working/)
* [【2024年トレンド】PHPフレームワークおすすめ14選！API開発にも活用できるものを紹介](https://mid-works.com/columns/language/php/1114800)

