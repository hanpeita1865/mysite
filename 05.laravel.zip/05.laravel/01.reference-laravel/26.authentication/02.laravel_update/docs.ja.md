---
title: Laravelバージョンアップ方法
taxonomy:
    category:
        - docs
---

## 現在のバージョン確認

<p class="tmp cmd"><span>コマンド1</span>Laravelバージョン確認</p>
```
php artisan --version
```
または、インストールされてるツール一式全部のバージョンを確認したいときは

<p class="tmp cmd"><span>コマンド2</span>ツール一式全部のバージョン確認</p>
```
php artisan -v
```

補足で、Bladeに表示させたいときは、下記を記入します。
```
{{ App::VERSION() }}
```

## composer.jsonの編集

Laravelフォルダ直下の**composer.json**を編集する。

#### 変更前

```
{
    "name": "laravel/laravel",
    "type": "project",
    "description": "The Laravel Framework.",
    "keywords": [
        "framework",
        "laravel"
    ],
    "license": "MIT",
    "require": {
        "php": "^7.1.3",
        "fideloper/proxy": "^4.0",
        "laravel/framework": "5.8.*",
        "laravel/tinker": "^1.0"
    },
    ・・・・・
  ```  
    
  ##### 変更後(2021.02.27時点の最新版)
  ```
  {
    "name": "laravel/laravel",
    "type": "project",
    "description": "The Laravel Framework.",
    "keywords": [
        "framework",
        "laravel"
    ],
    "license": "MIT",
    "require": {
        "php": "^7.3|^8.0",
        "fideloper/proxy": "^4.4",
        "fruitcake/laravel-cors": "^2.0",
        "guzzlehttp/guzzle": "^7.0.1",
        "laravel/framework": "^8.12",
        "laravel/tinker": "^2.5",
        "laravel/ui": "^3.2"
    },
    ```
  
  
  
  <p class="tmp cmd"><span>コマンド3</span>アップデート</p>
  ```
 composer update
  ```
  
  
  
  
  
  
  
  
  