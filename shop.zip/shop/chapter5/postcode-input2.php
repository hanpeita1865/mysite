<?php require '../header.php'; ?>
<p>7桁の郵便番号をハイフンありで入力してください。</p>
<form action="postcode-output2.php" method="post">
<input type="text" name="postcode">
<input type="submit" value="確定">
</form>
<?php require '../footer.php'; ?>
