*[page-title]:第4章Slimのルーティング登録

## 4-1 リクエストの種類に合わせたルーティング登録

<div markdown="1" class="green-box">
* ルーティング登録は、HTTPメソッドと同名のAppクラスのメソッドを使って登録する
* GET以外のHTTPメソッドでのアクセスを試すには、Postmanを使おう。
</div>

<p class="tmp"><span>書式1</span>ルーティング登録</p>
```
$app->get(ルーティングパターン, 対応するコールバック関数);
```

このget()メソッドというのは、HTTPのGETメソッドに対応しています。もしルーティングパターン、例えば先ほどの「/firstslim/public/hello」に対応するURLにPOSTメソッドでアクセスした場合、**HttpMethodNotAllowedException** が発生し、エラーが表示されます。

このように、Slimのルーティングパターン登録は、HTTPの各メソッドに合わせて登録メソッドが異なります。下の表にどういったメソッドがあるのかまとめました。

<p class="tb-caption"><span>表4-1</span>HTTPメソッドごとのルーティング登録バリエーション</p>
|HTTPメソッド|Appクラスのメソッド|HTTPメソッドの意味|
|--|--|--|
|GET |$app-><span class="red bold">get</span>(･･･); |リソースの取得 |
|POST |$app-><span class="red bold">post</span>(･･･); |リソースの追加 |
|PUT |$app-><span class="red bold">put</span>(･･･); |リソースの更新 |
|DELETE |$app-><span class="red bold">delete</span>(･･･); |リソースの削除 |
|OPTIONS |$app-><span class="red bold">options</span>(･･･); |サポートするHTTPメソッドの取得 |
|PATCH |$app-><span class="red bold">patch</span>(･･･); |リソースの一部を更新 |

表を見てわかるように、HTTPメソッドと同名のルーティング登録メソッドが用意されています。メソッドの引数はすべて「･･･」と省略表記にしていますが、これらはすべて、get() と同じく「ルーティングパターン」「対応するコールバック関数」の2個の引数を必要とします。

この章では、「<span class="blue bold">slimroute</span>」のフォルダをプロジェクトとして作成していきます。

<p class="tmp list"><span>リスト4-1</span>slimroute/public/index.php</p>
```
<?php
use Slim\Factory\AppFactory;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;

$app->setBasePath("/slimroute/public");

require_once($_SERVER["DOCUMENT_ROOT"]."/slimroute/vendor/autoload.php");

$app = AppFactory::create();

$app->run();
```
これでプロジェクトが作成されました。以降、このプロジェクトにコードの追記やファイルの作成を行っていきます。


### POST処理のルーティング登録

プロジェクトが作成されたところで、POST処理に対するルーティング登録を行います。リスト4-2の

<p class="tmp list"><span>リスト4-2</span>slimroute/public/index.php</p>
```
～省略～
$app = AppFactory::create();
//ここから
$app->post("/slimroute/public/helloPost", //･･････(1)
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		print("POSTメソッドでHello World!");　//･･････(2)
		return $response;
	}
);
//ここまでを追記
$app->run();
```
<span class="red">※コードをコピペする時は、//･･････(1)と//･･････(2) を削除してから貼り付ける。そうしないと、エラーになります。（折り返しのあるコードにコメントを追記するとエラーになるみたい。）</span>

※`$app->setBasePath("/slimroute/public");`はなし。

リスト4-2の(1)では、Appのpost()メソッドを使ってルーティング登録を行っています。この記述は、表4-1にある通りPOSTメソッドでアクセスしてきた場合の処理を登録しています。  
ルーティングパターンは、/slimroute/public/helloPost ですので、この処理を呼び出すURLは、
`http://localhost:9810/slimroute/public/helloPost`  
になります。

ただし、直接ブラウザから上記URLにアクセスしてもダメです。というのは、ブラウザのアドレスバーに直接URLを入力した場合のアクセスは、GETメソッドでのアクセスとなるからです。この場合も、**HttpMethodNotAllowedException**が発生してしまいます。

そこで、POSTでアクセスするために、formタグを記述したHTML画面を1枚作成します。リスト4-3の showPostHellohtml をpublicフォルダ直下に作成してください。

<p class="tmp list"><span>リスト4-3</span>public/ showPostHellohtml </p>
```
<!DOCTYPE html>
<html lang="ja">
	<head>
		<meta charset="UTF-8">
		<title>/helloPostにPostするファイル</title>
	</head>
	<body>
		<form action="/slimroute/public/helloPost" method="post">
			<button type="submit">GO!</button>
		</form>
	</body>
</html>
```

formタグのあるshowPostHello.htmlを作成したら、下のURLからhtmlファイルを表示させてください。

<http://localhost:9810/slimroute/public/showPostHello.html>

下図のように、「GO!」ボタンが表示されます。
![](upload/go_button.png)
このボタンをクリックすると、リスト4-2の(1)の /slimroute/publc/helloPost のコールバック関数内の処理が実行され、下のような処理結果画面が表示されます。
![](upload/go_button2.png)

### Postman

前項ではPOSTメソッドでアクセスするためにわざわざformタグが記述されたhtmlファイルを作成しました。画面表示が連続するWebアプリケーションならいいのですが、例えば、Web APIなど、画面を伴わないWebアプリケーションで、POSTアクセスの確認のためにわざわざHTML画面を作成するのは手間です。さらに、GETとPOST以外のHTTPメソッドを確認する場合、そもそもformタグは使えません。そういった場合に便利なアプリとして <span class="green bold">Postman </span>があります。Postmanを使うと、手軽にHTTPアクセスの確認ができます。

公式サイト
: https://www.postman.com/

ツールバーで起動してるか確認した後、
![](upload/agent.png)

※表示がない場合、スタートボタンからPostmanを管理者で起動してください。

サインインして、workspace　➡　create a request をクリックします。
![](upload/postman_myworkspaceまとめ.png)

そうすると送信画面が開かれるので、、左端のセレクトボックスの「GET」を「<span class="green bold">POST</span>」に変更し、  
`http://localhost:9810/slimroute/public/helloPost` をEnter request URLの欄に入力します。「<span class="green bold">Send</span>」ボタンをクリックします。

![](upload/Postma_send.png)

そうすると、下パネルに「**POSTメソッドでHello World!**」が表示され、HttpMethodNotAllowedExceptionが発生していることが確認できます。

![](upload/Postma_send1.png)


## 4-2 ServerRequestInterfaceとResponseInterface

コールバック関数の引数と戻り値について説明します。

<div markdown="1" class="green-box">
* ルーティングコールバック関数の引数や戻り値は、PSR-7 インターフェース。
* Slimでは、PSR-7 の実装パッケージを別途インストールする必要があり、それには slim/psr7 がおすすめ。
* リクエストパラメータの取得は、$request のメソッドを利用する。
* レスポンスオブジェクトである $reqquest はイミュータブル。
* レスポンスボディへの文字列格納は、getBody() と write() を組み合わせる。
</div>


### リクエストパラメータの取得

コールバック関数の引数と戻り値を解説するにあたって、Slimでリクエストパラメータを取得する方法から話をはじめます。Slimでリクエストパラメータを取得する場合は、従来の$_GETや$_POSTは使いません。では、どのようにするのか、実際のコードで確認していきましょう。  
次のリスト4-4のコードをリスト4-2で作成したindex.phpの$app->run()の前に追記して下さい。

<p class="tmp list"><span>リスト4-4</span>slimroute/public/index.php</p>
```
～省略～

$app->post("/slimroute/public/showParams",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$postParams = $request->getParsedBody(); //･･････(1)
		$name = $postParams["name"]; //･･････(2)
		$age = $postParams["age"]; //･･････(2)
		print("送信されたパラメータ: 名前は".$name."で年齢が".$age);
		return $response;
	}
);
```
リスト4-4で追記したコードは、POSTデータとして送信されてきた名前を表すnameと年齢を表すageを取得して表示するというものです。  
ルーティングパターンは、/slimroute/public/showParamsです。

`http://localhost:9810/slimroute/public/showParams` をPostmanの送信URL欄に入力します。  

そして、下図のように設定変更や入力を行い、Sendボタンをクリックします。
![](upload/showParams1.png)

↓　そうすると送信されたデータが入ったテキストが表示されます。

![](upload/showParams2.png)

解説
: SlimでPOSTデータを取得するには、$_POST を使うのではなく、引数である $request のメソッド **<span class="text-red">getParsedBody() </span>**を使います。それがリスト4-4の(1)です。このメソッドの戻り値は、キーをリクエストパラメータとした連想配列ですので、リスト4-4の(2)のように、リクエストパラメータ名を指定することでPOSTデータを取得することができます。  
同様に、GETデータを取得する場合は、$requestのメソッド **<span class="text-red">getQueryParams()</span>** を使います。

### メモ

$_POST と $_GET の扱い
: リクエストパラメータを取得するのに、コールバック関数内で**$_POST**も**$_GET**も実は使えます。そういった意味で、getParsedBody() や getQueryParams() をわざわざ使う必要はないように思えますが、メリットもあります。例えば、GETでアクセスした場合、$_POST変数は空の連想配列として存在していますので、$_POST["name"]とするとエラーとなります。一方、getParsedBody()の戻り値はnullとなる仕様です。したがって、例えば<span class="green bold">戻り値を表す変数を$postParams とした場合、$postParams["name"]はエラーとなりません。</span>
: POSTでのアクセスの場合も同様で、$_GET["name"]はエラーとなりますが、getQueryParams()の戻り値はnullとなり、リクエストパラメータ名によるデータ取り出しはエラーとなりません。

### 引数 $request の正体

$request はどういう引数なのでしょうか。  
コールバック関数の引数$requestの型指定は、<span class="green bold">SeverRequestInterface</span>です。このSeverRequestInterfaceは、名前の通りインターフェースであり、HTTPリクエストに関するデータをすべて格納し、取り出せるように定義されたものです。といっても、このSeverRequestInterfaceは Slim オリジナルのインターフェースではなく、****PSR-7**** として定義されたインターフェースです。そのため、このインターフェースの完全修飾名は \Psr\Http\Message\SeverRequestInterface と、PSRから始まっているのです。

この[PSR](https://www.php-fig.org/psr/)（[Google翻訳](https://www-php--fig-org.translate.goog/psr/?_x_tr_sl=en&_x_tr_tl=ja&_x_tr_hl=ja&_x_tr_pto=nui,sc,elem)）には、規約ごとに通し番号が割り振られており、廃番になった番号も含めると、今のところ0～18まであります。例えば、PHPのコーディングスタイルに関する規約は、<span class="green bold">PSR-1</span>と<span class="green bold">PSR-2 </span>として定義されており、名前空間とオートロードに関する規約は、<span class="green bold">PSR-4</span>として定義されています。このうち、HTTPのやり取りに関するインターフェースが定義されたものが ****PSR-7**** てす。そのPSR-7で定義されたインターフェースのひとつが<span class="green bold">SeverRequestInterface</span>であり、そこに定義された主なメソッドを下の表4-2にまとめています。

<p class="tb-caption"><span>表4-2</span>SeverRequestInterfaceで定義された主なメソッド</p>
| メソッド名 | 引数 | 戻り値 | 説明 |
| -------- | -------- | -------- | -------- |
| <span class="green bold">getMethod</span>    | なし     | 文字列     | 現在のリクエストのHTTPメソッドを取得     |
| <span class="green bold">getUri</span>     | なし     | \Psr\Http\Message\UriInterface インスタンス    | 現在のリクエストのURL情報を取得     |
| <span class="green bold">getHeaders</span>     | なし     | 文字列の二次元配列     | 全リクエストエッダ情報を取得     |
| <span class="green bold">getHeader</span>     | ヘッダフィールド名     | 文字列の配列     | 引数で指定されたヘッダフィールドに関するリクエストヘッダ情報を取得     |
| <span class="green bold">hasHeader</span>| ヘッダフィールド名| true/false| 引数で指定されたヘッダフィールドに関する情報が存在すればtrue、なければfalseを取得|
| <span class="green bold">getBody</span>| なし| \Psr\Http\Message\UriInterface インスタンス| リクエストボディに関する情報を取得|
| <span class="green bold">getSeverParams</span>| なし| 連想配列| $_SEVERと同等の情報を取得|
| <span class="green bold">getCookieParams</span>| なし| 連想配列| $_Cookieと同等の情報を取得|
| <span class="red bold">getQueryParams</span>| なし| 連想配列| $_GETと同等の情報を取得|
| <span class="red bold">getParsedBody|</span> なし| 連想配列| $_POSTと同等の情報を取得|
| <span class="green bold">getUploadedFiles</span>| なし| 連想配列| $_FILESと同等の情報を取得|


### 引数 $response の正体


ルーティングコールバック関数にはもうひとつ引数として$responseがあります。この引数の型は \Psr\Http\Message\<span class="green bold">ResponseInterface</span>です。また、コールバック関数の戻り値の型も同じく ResponseInterfaceとなっています。実は、ResponseInterfaceも完全修飾名から分かるように、PSR-7で定義されたインターフェースです。このインターフェースで定義された主なメソッドを表4-3にまとめておきます。

<p class="tb-caption"><span>表4-3</span>ResponseInterfaceで定義された主なメソッド</p>
| メソッド名 | 引数 | 戻り値 | 説明 |
| -------- | -------- | -------- | -------- |
| <span class="green bold">getStatusCode</span>    | なし     | 整数値     | 現在のレスポンスのHTTPステータスコードを取得     |
| <span class="green bold">withStatus</span>    |  整数値 | \Psr\Http\Message\ResponseInterfaceインスタンス      | 引数で指定したHTTPステータスコードが格納された新たなResponseInterfaceインスタンスを取得     |
| <span class="green bold">getHeaders</span>    | なし     | 文字列の二次元配列     | 全レスポンスヘッダ情報を取得    |
| <span class="green bold">getHeader</span>    | ヘッダフィールド名     | 文字列の配列    | 引数で指定されたヘッダーフィールドに関するレスポンスヘッダ情報を取得     |
| <span class="green bold">hasHeader</span>    | ヘッダフィールド名    | true/false   | 引数で指定されたヘッダーフィールドに関する情報が存在すればtrue、なければfalseを取得    |
| <span class="green bold">withHeader</span>    | ヘッダフィールド名（第1引数）とその値（第2引数）     | \Psr\Http\Message\ResponseInterfaceインスタンス     | 引数で指定したヘッダー情報が格納された新たなResponseInterfase     |
| <span class="green bold">getBody</span>    | なし    | \Psr\Http\Message\StreamInterface インスタンス     | レスポンスボディに関する情報を取得    |






### コールバック関数中のprint()の正体

ここまで何度か紹介してきたように、コールバック関数の戻り値は ResponseInterfaceインスタンスです。しかも、4-2-3項の最後で解説したように、このResponseInterfaceインスタンスである $responseはイミュータブルですので、内容を変更できません。そこで、通常は withStatus()メソッドなどの新たなResponseInterfaceインスタンスを生成するメソッドを利用し、それらのメソッドによって生成されたResponseInterfaceインスタンスをリターンします。  
ただし、レスポンスボディ（レスポンスデータの本体部分）に関しては可変可能になっています。それを実際のコードを体験してみましょう。index.phpの$app->run()の前にリスト4-5のコードを追記して下さい。

<p class="tmp list"><span>リスト4-5</span>slimroute/public/index.php</p>
```
～省略～

$app->get("/slimroute/public/writeBody",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$content ="レスポンスボディに文字列を格納";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
);
```
修正が完了したら、ここまで登録した各ルーティングパターンのURLの「slimroute」を「slimroute2」に変更してアクセスしなおしてみて下さい

次のURLにアクセスして下さい。

<http://localhost:9810/slimroute2/public/writeBody>

そうすると「レスポンスボディに文字列を格納」と画面に表示されるはずです。

## 4-3 複数のHTTPメソッドに対応できるルーティング登録　any()、map()

ここまで、HTTPメソッドごとにルーティング登録メソッドが存在することを説明しました。  
Slimには、その他に複数のHTTPメソッドに対応したものが2個あります。

<div markdown="1" class="green-box">
* どのHTTPメソッドでも処理を行うルーティングを登録するには<span class="green bold">any()メソッド</span>を使う。
* 複数の選択されたHTTPメソッドでの処理を行うルーティングを登録するには、<span class="green bold">map()メソッド</span>を使う。
* map()でのルーティング登録では、第1引数にHTTPメソッドの配列を指定する。
</div>


### すべてのメソッドに対応した any()

どのHTTPメソッドでも処理を行うルーティングを登録する <span class="green bold">any()</span> メソッドです。

<p class="tmp list"><span>リスト4-6</span>slimroute/public/index.php</p>
```
～省略～

$app->any("/slimroute/public/helloAny",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$method = $request->getMethod();
		$content = $method."メソッドでHello World";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
);
```

次のURLにアクセスして下さい。

<http://localhost:9810/slimroute2/public/helloAny>

「GETメソッドでHello World」と画面に表示されます。

またPostmanを使って、Deleteメソッドでアクセスすると、
![](upload/helloAny_delete.png)

下記のように「DELETEメソッドでHello World」と表示されます。

![](upload/helloAny_delete1.png)

### アクセスするHTTPメソッドを選べる map()

HTTPメソッドを選択できる map() メソッドです。map()メソッドは引数が1個増え、次の構文となります。

<p class="tmp"><span>書式2</span>map()によるルーティング登録</p>
```
$app->map(HTTPメソッドの配列, ルーティングパターン, 対応するコールバック関数);
```

<p class="tmp list"><span>リスト4-7</span>slimroute/public/index.php</p>
```
～省略～

$app->map(["POST", "GET"], "/slimroute/public/helloMap", //----(1)
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$content = "POSTまたはGETメソッドでHello World";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
);
```
次のURLにアクセスして下さい。

http://localhost:9810/slimroute2/public/helloMap

「POSTまたはGETメソッドでHello World」と画面に表示されます。

Postmanを使って、「GET」「POST」のどちらで送信しても、下パネルに「POSTまたはGETメソッドでHello World」が表示されます。

(1)で$appのmap()メソッドを使ってルーティングを登録をしています。今まで第1引数として記述していたルーティングパターンが第2引数となり、\slimroute/public/helloMap を記述しています。第1引数として、<span class="red bold">["POST", "GET"]</span>と、HTTPメソッドを文字列として列挙した配列を記述しています。ここに記述されたメソッドのみアクセス可能となります。  
any()メソッドでは、この第1引数の部分がありません。




## 4-4. ルーティング登録を便利にする仕組み三種盛り

ルーティング登録を効率よく行う方法を三種紹介します。

<div markdown="1" class="green-box">
* ルーティングには、setBasePath()メソッドでルーティングパターンのベースパスを設定できる。
* ルーティンググループ登録を利用することで、ルーティングパターンを階層化できる。
* ルーティング登録パターンに続けて setName()メソッドを利用することで、ルーティングに名前をつけることができる。
</div>

### ルーティングパターンにベースパスを設定する
ここまでサンプルとして作成してきたルーティングパターンには、すべて/slimroute/publicが付いています。このようにルーティングパターンに接頭辞として一定のパスが付与されてしまう問題は、3-2-1項 Slimのフォルダ構成の中の**ドキュメントルートの変更**で説明している通り、publicフォルダをドキュメントルートとしない限りは、避けられません。

<span class="green bold">setBasePath()</span> は、接頭辞部分をまとめて設定できるメソッドです。  
例えば、次のコードをルーティング登録の前に記述しておくと、それ以降のルーティングパターンは差分だけで済むようになります。

```
$app->setBasePath("/slimroute/public");
```

### ルーティングパターンに階層構造を持たせる

Slimには、グループとしてまとめてルーティング登録できる方法があります。その場合は、Appクラスの<span class="green bold">group()</span>メソッドを使って、次の構文でまとめることができます。

[group()メソッド使い方ガイド](https://www.slimframework.com/docs/v4/objects/routing.html#route-groups)

<p class="tmp"><span>書式3</span>ルーティンググループ登録</p>
```
use Slim\Routing\RouteCollectorProxy; //追記

～省略～

$app->group(親ルーティングパターン, function(RouteCollectorProxy $group) {
	$group->any(子ルーティングパターン, コールバック関数);
}
```

/members に関する上記3つのルーティングパターンをまとめてルーティング登録する場合、以下のようなコードになります。

<p class="tmp list"><span>リスト</span>グループとしてまとめてルーティング登録</p>
```
$app->setBasePath("/slimroute/public");
$app->group("/members", function(RouteCollectorProxy $group) {
	$group->any("/showList", ･･･);
	$group->any("/entry", ･･･);
	$group->any("/showDetail", ･･･);
});
```

<div class="memo-box">
index.phpの75行目`$app->setBasePath("/slimroute/public");`のコメントアウトを取ってから、次からのリンクに接続してください。下記はslimroute2のファイルのURLです。
</div>

* http://localhost:9810/slimroute2/public/members/showList
	* 「グループ1（showList）を表示」と表示される
* http://localhost:9810/slimroute2/public/members/entry
	* 「グループ2（entry）を表示」と表示される
* http://localhost:9810/slimroute2/public/members/showDetail
	* 「グループ3（showDetail）を表示」と表示される

group()メソッドは引数を2個とります。第1引数が親ルーティングパターンで、各ルーティングパターンの共通部分を記述します。第2引数は、コールバック関数ですが、このコールバック関数内にそれぞれのルーティング登録を記述します。  
その際、Appクラスのルーティング登録メソッドを利用するのではなく、group()メソッドの第2引数のコールバック関数の引数として渡される \Slim\Routing\<span class="text-green">**RouteCollectionProxy** </span>インスタンスである $group のルーティング登録メソッドを使います。

※any()以外でもget()やpost()などの他のルーティング登録メソッドも使えます。

### ルーティングに名前を付ける ###{#4routingName}

ルーティング登録の際に、そのルーティングに名前をつけることができます。その場合は、ルーティング登録メソッドに続けて、**<span class="text-green">setName() </span>**メソッドを使います。

<p class="tmp"><span>書式4</span>ルーティングネーム</p>
```
$app->any(･･･)->setName(ルーティング名);
```

具体例では、次のようなコードになります。
```
$app->setBasePath("/slimroute/public");
$app->any("/members/showList", ･･･)->setName("showMemberListAction");
```

このような設定を行っておくと、showMembeListAction という名前を指定するだけで、次のようなパスパターンに自動的に展開できようになります。

```
slimroute/public/members/showList
```

http://localhost:9810/slimroute2/public/members/showList

function（関数）のように使うものかな･･･。



参考サイト（ルート名の項目の箇所）
: [http://www.y2sunlight.com/ground/doku.php?id=slim:4:routing](http://www.y2sunlight.com/ground/doku.php?id=slim:4:routing)

アプリケーションルートには名前を付けることができます。これは、RouteParser の urlFor() メソッドを使用して特定のルートへのURLをプログラムで生成したい場合に役立ちます。上記の各ルーティングメソッドは Slim\Route オブジェクトを返し、このオブジェクトは setName() メソッドを公開します。
```
$app->get('/hello/{name}', function ($request, $response, array $args) {
    $response->getBody()->write("Hello, " . $args['name']);
    return $response;
})->setName('helloName');
```
この名前付きルートのURLは、アプリケーション RouteParser の urlFor() メソッドを使用して生成できます。
```
$routeParser = $app->getRouteCollector()->getRouteParser();
echo $routeParser->urlFor('helloName', ['name' => 'Josh'], ['example' => 'name']);
 
// Outputs "/hello/Josh?example=name"
```
<http://localhost:9810/slimroute2/public/hello/Peter>に接続すると、  
「/slimroute/public/hello/Josh?example=nameHello, Peter」  
と表示されます。

RouteParser の urlFor() メソッドは、次の3つの引数を受け入れます：

$routeName ルート名。ルートの名前は、$route→setName('name') を介して設定できます。ルートマッピングメソッドは Route のインスタンスを返すため、ルートをマッピングした直後に名前を設定できます。  

例：$app→get('/', function(){…})→ setName('name')  
$data ルートパターンのプレースホルダーと置換値の連想配列。  
$queryParams 生成されたURLに追加されるクエリパラメータの連想配列。


## 4-5. ルーティングの外部ファイル化

ルーティング登録のコードを index.php とは別のファイルに記述する方法を紹介します。

<div markdown="1" class="green-box">
* ルーティング登録コードは、専用のファイルを記述する。
* index.phpでは、ルーティング登録ファイルを読み込む。
* ルーティング登録ファイルは、その機能に合わせて複数作成してもいい。
</div>

public/index.phpにルーティング登録を記述するというのは、index.phpの肥大化を招き、可読性の観点から現実的ではありません。そこで、通常は、ルーティングの登録のみを記述した外部ファイルを作成し、index.phpではそのファイルを読み込むようにします。では改造していきます。

<span class="blue bold">※（メモ）ここから「slimroute2」という新しいフォルダを使っていきます。コード内の「slimroute」も「slimroute2」に変えて下さい。</span>

まず、slimroute2フォルダ直下にroutes.phpを作成し、index.phpのルーティング登録を記述した部分と、SeverRequestInterface と ResponseInterface のuse文を丸々移動します。

<p class="tmp list"><span>リスト4-8</span>slmroute2/routes.php</p>
```
<?php
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Slim\Routing\RouteCollectorProxy; //group()メソッドを使うときに必要

$app->setBasePath("/slimroute2/public");

$app->post("/helloPost",
	～省略～
);

～その他のパスパターンも記述～

```

下記のコードをindex.phpの「$app = AppFactory::create();」と「$app->run();」の間に追記する。

<p class="tmp list"><span>リスト4-9</span>slmroute2/public/indexphp</p>
```
require_once($_SERVER["DOCUMENT_ROOT"]."/slimroute2/routes.php");
```

* http://localhost:9810/slimroute2/public/writeBody
* http://localhost:9810/slimroute2/public/helloAny
* http://localhost:9810/slimroute2/public/helloMap
* http://localhost:9810/slimroute2/public/members/showList
* http://localhost:9810/slimroute2/public/members/entry
* http://localhost:9810/slimroute2/public/members/showDetail

ここで行った改造のように、$app->get(･･･) などのルーティング登録記述を別ファイルとしてまとめ、リスト4-9のように index.phpではそのファイルをrequire_once()することで、ソースコードの可読性がよくなります。

その際、ルーティング情報が記述されたファイルをpublicフォルダではなく、もう一階層上のプロジェクトルートフォルダに作成することで、<span class="red bold">外部からルーティングファイルが直接読まれなくなります。</span>なお、use文も必要なものをそれぞれのファイルに記述します。でないとエラーとなるので注意してください。

### ルーティングファイルの分割

ルーティングファイルそのものを分割することも可能です。

例えば、管理者用処理のルーティング情報を記述した adminRoutes.php ファイル、会員用処理のルーティング情報を記述した memberRoutes.php ファイルとルーティングファイルを分割したいとします。

その場合、プロジェクトルートフォルダ内に、例えば routesフォルダを作成し、その中に adminRoutes.php ファイルと memberRoutes.php ファイルを配置します。

index.phpには、下記のコードを追記します。
<p class="tmp">public/index.php</p>
```
require_once($_SERVER["DOCUMENT_ROOT"]."/slimroute2/routes/adminRoutes.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/slimroute2/routes/memberRoutes.php");
```

## ルーティングプレースフォルダ

ルーティング登録では、そのURLにパラメータを埋め込むことができます。

<div markdown="1" class="green-box">
* Slimでは、クエリ情報の代わりにパラメータをURLに埋め込むことができる。
* URL中のパラメータをルーティングプレースホルダ―といい、波括弧を使う。
* 省略可能なプレースフォルダを記述する場合、[/{･･･}]と記述する。
</div>


URL1  `http://localhost:9810/slimroute2/public/showDetail?id=35`

上記のURLを下記のように、URLにID番号などを埋め込むことが出来ます。

URL2  `http://localhost:9810/slimroute2/public/showDetail/35`

このように、URL中にパラメータを埋め込む仕組みのことを、<span class="green bold">ルーティングプレースフォルダ</span>といい、下記の書式のように「/」と波括弧を使います。

<p class="tmp"><span>書式5</span>プレースフォルダを使ったルーティングパターン</p>
```
/･･･/{プレースフォルダ名}
```

<p class="tmp list"><span>リスト4-10</span>routes.php</p>
```
$app->get("/showDetail/{id}", //･･････(1) プレースホルダを使った記述
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        $id = $args["id"]; //･･････(2) パラメータを取り出す
		$content = "IDが".$id."の詳細です!";
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
);
```

追記が済んだら、先ほどの「/」の方のURL2（ <http://localhost:9810/slimroute2/public/showDetail/35>）にアクセスしてみて下さい。

そうすると、画面に「IDが35の詳細です!」と表示されるはずです。

この記述は、URL中の /{･･･} にあたる部分をパラメータとして扱い、コールバック関数の第３引数である $args に、URL中の値を自動的に格納してくれます。


### プレースフォルダは複数記述できる

これらのプレースフォルダはいくつでも使うことが出来ます。例えば、次のようなルーティングパターンです。
```
showList/{categoryId}/{tagId}/{listSize}
```
この場合は、$args["categoryId"]、$args["tagId"]、$args["listSize"] でそれぞれのパラメータを取得できます。

例として、  
http://localhost:9810/slimroute2/public/showList0/drink/low/50  
の場合、それぞれのパラメータは次のようになります。

パラメータの値
: $args["categoryId"] →** drink**
: $args["tagId"] → **low**
: $args["listSize"] → **50** 

<p class="tmp list"><span>リスト4-10-1</span>routes.php</p>
```
$app->get("/showList/{categoryId}/{tagId}/{listSize}",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$content = $args["categoryId"].'と'.$args["tagId"].'と'.$args["listSize"] ;
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
);
```

### オプションプレースホルダ

パラメータをオプション扱いにすることもできます。

例えば、前項のURLのうち、listSizeをオプションとし、省略可能だとします。

http://localhost:9810/slimroute2/public/showList1/food/high/side のように省略可能なプレースホルダを記述する場合は、次の書式のように、/{･･･} 全体を角括弧で囲みます。

<p class="tmp"><span>書式6</span>プレースホルダの省略</p>
```markdown
/･･･[/{･･･}]
```

listZizeを省略可能にするルーティングパターンは次のようになります。
```markdown
/showList/{categoryId}/{tagId}[/{listSize}]
```

<p class="tmp list"><span>リスト4-11</span>listSizeを省略可</p>
```
$app->get("/showList/{categoryId}/{tagId}[/{listSize}]",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$content = $args["categoryId"].'と'.$args["tagId"];
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
);
```


また、tagIdとlistSizeの２つをオプションとし、省略可能にする場合は、角括弧を入れ子にします。
```markdown
/showList/{categoryId}[/{tagId}[/{listSize}]]
```

<p class="tmp list"><span>リスト4-12</span>tagIdとlistSizeを省略可</p>
```
$app->get("/showList/{categoryId}[/{tagId}[/{listSize}]]",
	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
		$content = $args["categoryId"];
		$responseBody = $response->getBody();
		$responseBody->write($content);
		return $response;
	}
);
```

http://localhost:9810/slimroute2/public/showList2/side


## 4-7. リダイレクト ##{#4-7}

<div markdown="1" class="green-box">
* 特定のルーティングパターンで常にリダイレクトする場合は redirect() メソッドでリダイレクト登録を行う。
* コールバック関数で、状況に応じてリダイレクトを行う場合は、$response の widthHeader()メソッドと withStatus()メソッドを組み合わせて利用する。
</div>

リダイレクトさせるには、Appクラスの <span class="text-green">**redirect()**</span> メソッドを使います。

<p class="tmp"><span>書式7</span>リダイレクト登録</p>
```
$app->redirect(ルーティングパターン, リダイレクト先URL);
```

例として、以下はURLの末尾に/googleがあれば、Googleのサイトに遷移させるコードです。
<p class="tmp list"><span>リスト4-13</span>routes.php</p>
```
$app->redirect("/google", "https://www.google.com/");
```

http://localhost:9810/slimroute2/public/google


ところで、このリダイレクトルーティング登録は、デフォルトでは **302 リダイレクト**です。302リダイレクトというのは、一時的なリダイレクトを表します。

ページの移転や削除などで、「恒久的に」別の画面にリダイレクトする必要がある場合は、**<span class="text-green">301リダイレクト</span>**を使います。
その場合は、第3引数に301を記述し、下記のようにします。

<p class="tmp list"><span>リスト4-14</span>routes.php</p>
```
$app->redirect("/hey", "/slimroute2/public/helloAny", 301);
```

http://localhost:9810/slimroute2/public/hey にアクセスすると、瞬時にhttp://localhost:9810/slimroute2/public/helloAny に変わり、「GETメソッドでHello World」が表示されます。


### コールバック関数内でリダイレクト

前項では、該当URLにアクセスした場合、必ずリダイレクトされます。
一方、コールバック関数内で処理の結果としてリダイレクトさせることもできます。

<p class="tmp list"><span>リスト4-15</span>routes.php</p>
```
～省略～

$app->any("/redirectOrNot/{flg}", //･･････(1) ルーティングパターンではプレースホルダを使用しています
    function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        $flg = $args["flg"]; //･･････(2) パラメータを取得 
        if($flg == 0) { //･･････(3) この値が0でないか判定（0の場合はGoogleのページにリダイレクト） 
            $response = $response->withHeader("Location", "https://www.google.com/"); //･･････(4) リダイレクト記述
            $response = $response->withStatus(302); //･･････(5) リダイレクト 記述
        }
        else {
            $content = "リダイレクトは行いません";
            $responseBody = $response->getBody();
            $responseBody->write($content);
        }
        return $response;
    }
);
```
http://localhost:9810/slimroute2/public/redirectOrNot/2

上のURLにアクセスすると、「リダイレクトは行いません」と画面に表示されます。

また、下記のURLにアクセスすると、Googleのサイトが表示されます。

http://localhost:9810/slimroute2/public/redirectOrNot/0


下はリダイレクトを行う場合の書式です。
<p class="tmp"><span>書式8</span>リダイレクト処理</p>
```
$response = $response->withHeader("Location", "リダイレクト先URL");
$response = $response->withStatus(301か302);
return $response;
```

上記の書式では、わかりやすように3行にわたって記述していますが、これを次のように1行にまとめることも可能です。  

```
return $response->withHeader("Location", ･･･)->withStatus(･･･);
```
上記を使って、$flagが０の時の処理はこのようになります。
```
return $response->withHeader("Location", "https://www.google.com/")->withStatus(302);
```

**<span class="text-green">ただ可読性を重視すれば、3行で書く方がいいです。</span>**








