*[page-title]:Chap4 Laravelのさまざまな機能を使う

Laravelでは、 Webアプリケーションの構築を手助けするさまざまな機能が提供されています。  
ここではそれらを利用してメールをアレンジしたり、遅延処理や定期バッチ処理、 画像投稿処理などを追加してアプリケーションをより充実させてみましょう。

<div markdown="1" class="page-mokuji auto-mokuji"></div>
