Vue.createApp({
  data: function() {
    return {
      url: 'https://wings.msn.to/'
    };
  }
}).mount('#app');