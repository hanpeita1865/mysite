---
title: コールバック関数
taxonomy:
    category:
        - docs
---

## 基本的なコールバックの実行方法

「testFunc()」は2秒掛かる処理を行ってから「myCallback()」関数をコールバックして実行します。実行結果を見ると順番に関数が実行されているのが分かります

<iframe width="100%" height="300" src="//jsfiddle.net/3nj5wL48/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## 参考サイト

* [初めてのコールバック関数の書き方と応用例！](https://www.sejuku.net/blog/67743)