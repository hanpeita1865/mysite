const data = [
  {
    id: 1,
    name: "\u30E1\u30D0\u30EB",
    place: "\u5317\u6D77\u9053\u306E\u5357\u90E8\uFF5E\u4E5D\u5DDE\u306E\u6CBF\u5CB8\u90E8",
    season: "\u6625\u304B\u3089\u51AC"
  },
  {
    id: 2,
    name: "\u30A2\u30B8",
    place: "\u5168\u56FD\u5404\u5730",
    season: "\u521D\u590F\u304B\u3089\u6669\u590F"
  },
  {
    id: 3,
    name: "\u30AB\u30B5\u30B4",
    place: "\u65E5\u672C\u8FD1\u6D77\uFF5E\u592A\u5E73\u6D0B\u897F\u90E8",
    season: "\u51AC\u304B\u3089\u6625"
  },
  {
    id: 4,
    name: "\u30AD\u30B8\u30CF\u30BF",
    place: "\u65E5\u672C\u304B\u3089\u4E2D\u56FD\u6CBF\u5CB8",
    season: "\u6625\u304B\u3089\u590F"
  },
  {
    id: 5,
    name: "\u30B9\u30BA\u30AD",
    place: "\u5317\u6D77\u9053\u5357\u90E8\uFF5E\u4E5D\u5DDE\u306E\u6CBF\u5CB8\u90E8",
    season: "\u6625\u304B\u3089\u590F"
  },
  {
    id: 6,
    name: "\u30D6\u30EA",
    place: "\u5317\u6D77\u9053\uFF5E\u4E5D\u5DDE\u306E\u592A\u5E73\u6D0B\u5CB8",
    season: "\u51AC"
  }
];

export { data as d };
//# sourceMappingURL=data.12335034.mjs.map
