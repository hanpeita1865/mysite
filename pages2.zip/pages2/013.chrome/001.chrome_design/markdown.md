*[page-title]:テーマ変更

## Chromeの背景を変更

Chromeの設定画面を開き、デザインのテーマの横の別ウィンドウアイコンをクリックします。
![](upload/デザインテーマ.png)
そうするとテーマの画面が表示されます。その中にあるテーマを選択してやれば、Chromeの背景が変更されます。
![](upload/ウェブストアテーマ変更.png)
また、画面右下にあるペンアイコンをクリックしてからでも変更できます。デフォルトの背景に戻したいときは、Chrome クラシックを選択してください。
![](upload/ペンアイコン.png)

### FireFoxのテーマ変更

[Firefox のテーマを使用するには](https://support.mozilla.org/ja/kb/use-themes-change-look-of-firefox)