<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MenuService,
    LockService,
};
use SocymSlim\SlimMiddle\Config\AppConfig;
use SocymSlim\SlimMiddle\Config\PageArea;//追加



class AdminController
{
    private EditService $editService;
    private FolderService $folderService;
    private MenuService $menuService;
    private LockService $lockService;
    private AppConfig $config;
    
    public function __construct(
        EditService $editService, 
        FolderService $folderService, 
        MenuService $menuService, 
        LockService $lockService, 
        AppConfig $config
    ) 
    {
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->lockService = $lockService;
        $this->menuService = $menuService;
        $this->config = $config;
    }

    //---------------------
    // メニュー管理画面表示
    //---------------------

    public function adminData(Request $request, Response $response, array $args): Response
    {   
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        $folderCnt = $request->getAttribute('count');//pages内のフォルダ数       
        $basePath = $this->config->basePath;
        
        $folderName = basename($request->getUri()->getPath());

        $twig = $this->editService->view();
        
        $boxNum = 1;
        
        
        $pageArea = $request->getAttribute('pageArea');
        $pageDir = PageArea::getPageDir($pageArea);
        $adminDir = PageArea::getAdminDir($pageArea);
        $pageAreaName = PageArea::getDisplayName($pageArea);

        $folderObj = $this->folderService->getFolderCompCached($pageDir);
                
        $this->menuService->loadLockData(
            $this->editService->db(),
            $folderObj
        );
        
        $role = $_SESSION['auth_user']['role'] ?? 'guest';
        
        $menuData = $this->menuService->buildAdminMenu($pageDir, $boxNum, $role, $pageDir);//変更 $pageDirを引数にもう一つ追加   
                
        if (isset($_SESSION['auth_user'])) {
            $isUser = true;
        }else{
            $isUser = false;
        }

        $assign = [
            'menuData'  => $menuData,
            'folderCnt' => $folderCnt,
            'isUser' => $isUser,
            'pathBase' => $basePath,
            'folderName' => $folderName,
            'role' => $role,
            'csrfToken' => $_SESSION['csrf_token'],
            'pageArea' => $pageArea,
            'adminFull' => $basePath . $adminDir,
            'pageAreaName' => $pageAreaName,//追加
        ];
        
        $response = $twig->render($response, "admin.twig", $assign);

        return $response;
    }


    //---------------------
    // ユーザー管理画面表示
    //---------------------

    public function adminAccount(Request $request, Response $response, array $args): Response
    { 
        $basePath = $this->config->basePath;
        $folderName = basename($request->getUri()->getPath());
        
        $twig = $this->editService->view();
        
        $db = $this->editService->db();

        $users = $db->query("SELECT user_id, user_name, email FROM users WHERE role NOT IN ('admin', 'limited_editor')")
                    ->fetchAll(PDO::FETCH_ASSOC);
                    
        $limited_editor = $db->query("SELECT user_id, user_name, email FROM users WHERE role = 'limited_editor'")
                    ->fetchAll(PDO::FETCH_ASSOC); 
                    
        //管理者用
        $admins = $db->query("SELECT user_id, user_name, email FROM users WHERE role = 'admin'")
            ->fetchAll(PDO::FETCH_ASSOC);
                    
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        
        if (isset($_SESSION['auth_user'])) {
            $isUser = true;
        }else{
            $isUser = false;
        }
        
        $role = $_SESSION['auth_user']['role'] ?? 'guest';
        
        $pageArea = $request->getAttribute('pageArea');//追加
        $pageAreaName = PageArea::getDisplayName($pageArea);//追加
                
        $assign = [
            'isUser' => $isUser,
            'pathBase' => $basePath,
            'users' => $users,
            'admins' => $admins,
            'limited_editors' => $limited_editor,
            'csrf' => $_SESSION['csrf'],
            'flash' => $flash,
            'folderName' => $folderName,
            'role' => $role,
            'pageArea' => $pageArea,//追加
            'pageAreaName' => $pageAreaName,//追加
        ];

        $response = $twig->render($response, "adminAccount.twig", $assign);

        return $response;
    }        
    

    //---------------------
    // フォルダ新規作成
    //---------------------

    public function folder_create(Request $request, Response $response, array $args): Response
    {
        $data = $request->getParsedBody() ?? [];
        $newFolder = trim($data['post_newFolder'] ?? '');
        
        $pageArea = $request->getAttribute('pageArea');
        $pageDir = PageArea::getPageDir($pageArea);

        try {
            $this->folderService->createNewFolder($newFolder, $pageDir, $pageArea);

            $response->getBody()->write("フォルダ '{$newFolder}' を作成しました。");
            
            $this->menuService->rebuildMenuCaches();
            
            $this->folderService->clearTitlePathCache();
            
        } catch (\Throwable $e) {
            $response->getBody()->write('エラー: ' . $e->getMessage());
        }

        return $response;
    }


    //---------------------
    // ページ名変更
    //---------------------

    public function file_rename(Request $request, Response $response, array $args): Response
    {
        $parsedBody = $request->getParsedBody();
        $post_menu = $parsedBody['post_menu'] ?? '';
        $post_reMenu = $parsedBody['post_reName'] ?? '';
        $post_dirName = $parsedBody['post_dirName'] ?? '';
        $post_folderName = $parsedBody['post_folderName'] ?? '';
        
        $pageArea = $request->getAttribute('pageArea');
        $pageDir = PageArea::getPageDir($pageArea);

        try {
            $this->folderService->renameMenu($post_dirName, $post_menu, $post_reMenu, $post_folderName, $pageDir, $pageArea);
            $response->getBody()->write('メニュー名を「' . $post_reMenu . '」に変更しました。');
            
            $this->menuService->rebuildMenuCaches();
            
            $this->folderService->clearTitlePathCache();
            
        } catch (\Throwable $e) {
            $response->getBody()->write('エラー: ' . $e->getMessage());
        }

        return $response;
    }


    //---------------------
    // フォルダ名変更
    //---------------------

    public function folder_rename(Request $request, Response $response, array $args): Response
    {       
        $parsedBody = $request->getParsedBody();

        $post_dir = $parsedBody['post_dir'] ?? '';
        $post_redir = $parsedBody['post_redir'] ?? '';
        $post_name = $parsedBody['post_folderName'] ?? '';
        $post_rename = $parsedBody['post_folderReName'] ?? '';

        $responseData = [];
        
        $pageArea = $request->getAttribute('pageArea');
        $pageDir = PageArea::getPageDir($pageArea);

        try {
            $result = $this->folderService->renameFolder($post_dir, $post_redir, $post_name, $post_rename, $pageDir, $pageArea);
            $responseData = [
                'success' => true,
                'message' => $result // "フォルダ名を「xxx」に変更しました。" など
            ];
            
            $this->menuService->rebuildMenuCaches();
            
            $this->folderService->clearTitlePathCache();//追加　cache/titlePath.php削除
            
        } catch (\Throwable $e) {
            $responseData = [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }

        $response->getBody()->write(json_encode($responseData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        return $response->withHeader('Content-Type', 'application/json');
    }


    
    //---------------------
    // ロック設定
    //---------------------

    public function page_lock(Request $request, Response $response, array $args): Response
    {       
        $parsedBody = $request->getParsedBody();
        $folder = $parsedBody['folderName'] ?? '';
        $under_dir = $parsedBody['under_dir'] ?? '';
        
        $pageArea = $request->getAttribute('pageArea');

        try {
            $message = $this->lockService->addLock($folder, $under_dir, $pageArea);
            $result = ['success' => true, 'message' => $message];
            
            $this->menuService->rebuildMenuCaches();
            
        } catch (\Throwable $e) {
            $result = ['success' => false, 'message' => $e->getMessage()];
        }

        $response->getBody()->write(json_encode($result));
        return $response->withHeader('Content-Type', 'application/json');        
    }


    
    //---------------------
    // ロック解除
    //---------------------    

    public function page_unlock(Request $request, Response $response, array $args): Response
    {       
        $parsedBody = $request->getParsedBody();
        $folder = $parsedBody['folderName'] ?? '';
        
        $pageArea = $request->getAttribute('pageArea');

        try {
            $message = $this->lockService->removeLock($folder, $pageArea);

            $result = ['success' => true, 'message' => $message];
            
            $this->menuService->rebuildMenuCaches();
            
        } catch (\Throwable $e) {

            $result = ['success' => false, 'message' => $e->getMessage()];
        }

        $response->getBody()->write(json_encode($result));
        return $response->withHeader('Content-Type', 'application/json');
    }



    //---------------------
    // lockデータ削除
    //---------------------

    public function lockdata_del(Request $request, Response $response, array $args): Response
    {
        $parsedBody = $request->getParsedBody();
        $folder = $parsedBody['post_delFolder'] ?? '';
        
        $pageArea = $request->getAttribute('pageArea');

        try {
            $message = $this->lockService->deleteLockData($folder, $pageArea);
            
            $result = ['success' => true, 'message' => $message];
            
        } catch (\Throwable $e) {
            
            $result = ['success' => false, 'message' => $e->getMessage()];
        }

        $response->getBody()->write(json_encode($result));
        return $response->withHeader('Content-Type', 'application/json');
    }


    
    //------------------------------------
    // 削除したフォルダをゴミ箱(trush)に移動
    //------------------------------------

    public function trush(Request $request, Response $response, array $args): Response
    {
        $res = glob('../pages_copy' . '/*');
        date_default_timezone_set('Asia/Tokyo'); //日本時間にセット
        $dateTime = date('Y-m-d_H.i.s');

        sleep(3);

        foreach ($res as $item) {
            mkdir('../trush/' . $dateTime); //削除日時フォルダ
            $itemRe = str_replace('pages_copy', 'trush' . '/' . $dateTime, $item);

            if (rename($item, $itemRe)) {
                //移動しました。
            }
        }

        return $response;
    }



    //------------------------------------
    // 対象のフォルダのみ削除 folderDelOnly
    //------------------------------------

    public function folderDelOnly(Request $request, Response $response, array $args): Response
    {
        $pageArea = $request->getAttribute('pageArea');
        $pageDir = PageArea::getPageDir($pageArea);

        $folderObj = $this->folderService->getFolderComp($pageDir);

        $data = $request->getParsedBody() ?? [];
        $folderName = trim($data['folderName'] ?? '');

        if ($folderName === '' || !isset($folderObj[$folderName])) {
            throw new \RuntimeException('削除対象のフォルダが見つかりません。');
        }

        $delFolder = $folderObj[$folderName];

        $db = $this->editService->db();

        try {

            // 削除前バックアップ
            $backupPath = $this->folderService->createDeleteBackup(
                $delFolder,
                $folderName
            );

            $db->beginTransaction();

            // ロックデータ削除
            $this->lockService->deleteLockData(
                $folderName,
                $pageArea
            );

            // サブページ移動 + page_list削除
            $movedFiles = $this->folderService->subpageMove(
                $delFolder,
                $folderName,
                $pageArea
            );

            
            // 削除対象フォルダを削除
            $this->folderService->deleteDirectory($delFolder);

            
            // 削除成功用の保管場所へ移動
            $this->folderService->moveDeleteBackupToTrash(
                $backupPath,
                $folderName
            );


            // DB確定
            $db->commit();

            // キャッシュ再生成
            $this->menuService->rebuildMenuCaches();
            $this->folderService->clearTitlePathCache();

            return $response;

        } catch (\Throwable $e) {

            // DBを元に戻す
            if ($db->inTransaction()) {
                $db->rollBack();
            }

            // ファイルを元に戻す
            if (!empty($movedFiles)) {
                $this->folderService->restoreMovedFiles($movedFiles);
            }

            // バックアップを削除対象フォルダへ戻す
            if (isset($backupPath) && is_dir($backupPath)) {
                $this->folderService->restoreDeleteBackup(
                    $backupPath,
                    $delFolder
                );
            }

            error_log(
                '[folderDelOnly] ' . $e->getMessage()
            );

            throw $e;
        }
    }



    //--------------------------------------------------
    // 対象フォルダを中身ごとまとめて削除してメニュー再生成
    //--------------------------------------------------
        
    public function del_allfolder(Request $request, Response $response, array $args): Response
    {
        $pageArea = $request->getAttribute('pageArea');
        $pageDir = PageArea::getPageDir($pageArea);

        $folderObj = $this->folderService->getFolderComp($pageDir);

        $data = $request->getParsedBody() ?? [];
        $folderName = trim($data['folderName'] ?? '');

        if ($folderName === '' || !isset($folderObj[$folderName])) {
            throw new \RuntimeException('削除対象のフォルダが見つかりません。');
        }

        $delFolder = $folderObj[$folderName];

        $db = $this->editService->db();

        try {

            // 削除前バックアップ
            $backupPath = $this->folderService->createDeleteBackup(
                $delFolder,
                $folderName
            );

            // 配下フォルダの fdName 一覧を取得
            $deleteList = $this->folderService->getDeleteTargetFdNames(
                $delFolder,
                $pageDir
            );

            $db->beginTransaction();

            // 対象フォルダを中身ごと削除
            $this->folderService->deleteAllFolder(
                $delFolder,
                $deleteList,
                $pageArea
            );

            // 削除成功用の保管場所へ移動
            $this->folderService->moveDeleteBackupToTrash(
                $backupPath,
                $folderName
            );

            // DB確定
            $db->commit();

            // キャッシュ再生成
            $this->menuService->rebuildMenuCaches();
            $this->folderService->clearTitlePathCache();

            return $response;

        } catch (\Throwable $e) {

            // DBを元に戻す
            if ($db->inTransaction()) {
                $db->rollBack();
            }

            // バックアップを削除対象フォルダへ戻す
            if (isset($backupPath) && is_dir($backupPath)) {
                $this->folderService->restoreDeleteBackup(
                    $backupPath,
                    $delFolder
                );
            }

            error_log(
                '[del_allfolder] ' . $e->getMessage()
            );

            throw $e;
        }
    }




    //---------------------
    // 並び替え確定
    //---------------------
        
    public function sort_confirm(Request $request, Response $response): Response {

        $data = $request->getParsedBody();

        $sortHistory = json_decode(
            $data['dirObj'] ?? '[]',
            true
        );

        $menuArray = json_decode(
            $data['list'] ?? '[]',
            true
        );

        $pageArea = $request->getAttribute('pageArea');

        // PageAreaに応じたページディレクトリ
        $pageDir = PageArea::getPageDir($pageArea);

        // 並び替え
        $this->folderService->sortTogether($sortHistory, $pageDir);

        // 最新状態取得
        clearstatcache();

        $folderObj = $this->folderService->getFolderComp($pageDir);

        // 番号振り直し
        $this->folderService->dirNumReplace(
            $menuArray,
            $folderObj
        );

        // キャッシュ再生成（最後）
        $this->menuService->rebuildMenuCaches();

        $this->folderService->clearTitlePathCache();

        $response->getBody()->write(
            json_encode(['status' => 'success'])
        );

        return $response->withHeader(
            'Content-Type',
            'application/json'
        );
    }

    // public function sort_confirm(
    //     Request $request,
    //     Response $response
    // ): Response {

    //     $data = $request->getParsedBody();

    //     $sortHistory = json_decode(
    //         $data['dirObj'] ?? '[]',
    //         true
    //     );

    //     $menuArray = json_decode(
    //         $data['list'] ?? '[]',
    //         true
    //     );

    //     // 並び替え
    //     $this->folderService->sortTogether($sortHistory);

    //     // 最新状態取得
    //     clearstatcache();

    //     $folderObj = $this->folderService->getFolderComp();

    //     // 番号振り直し
    //     $this->folderService->dirNumReplace(
    //         $menuArray,
    //         $folderObj
    //     );

    //     // キャッシュ再生成（最後）
    //     $this->menuService->rebuildMenuCaches();
        
    //     $this->folderService->clearTitlePathCache();//追加　cache/titlePath.php削除

    //     $response->getBody()->write(
    //         json_encode(['status' => 'success'])
    //     );

    //     return $response->withHeader(
    //         'Content-Type',
    //         'application/json'
    //     );
    // }



    //------------------------
    // フォルダ使用中かチェック
    //------------------------
        
    public function folderUseCheck(Request $request, Response $response, array $args): Response {

        $pageArea = $request->getAttribute('pageArea');

        if (empty($pageArea)) {
            $data = $request->getParsedBody() ?? [];
            $pageArea = $data['pageArea'] ?? PageArea::NORMAL;
        }

        $pageDir = PageArea::getPageDir($pageArea);

        $pagesObj = $this->folderService->getFolderComp($pageDir);
        $folderCnt1 = count($pagesObj);

        $data = $request->getParsedBody() ?? [];
        $menuArray1 = json_decode($data['list'] ?? '[]');

        $menuObj = [];

        foreach ($menuArray1 as $val) {

            $dirArray = explode('/', $val);
            $lastDir = end($dirArray);

            $folderNoNum = preg_replace(
                '/^\d{3}\./',
                '',
                $lastDir
            );

            $menuObj[$folderNoNum] = $pageDir . '/' . $val;
        }

        $sabunFolder = array_diff($pagesObj, $menuObj);

        $array2 = [];
        $array3 = [];

        foreach ($sabunFolder as $value) {

            $array1 = explode('/', $value);
            $cnt = count($array1);

            if ($cnt == 3) {
                array_push($array2, $value);

            } else if ($cnt == 4 && !in_array($array1[2], $array2)) {
                array_push($array3, $value);

            } else if ($cnt >= 5) {

                // 第四階層以下は、第三階層にする
                $value = $array1[0] . '/' .
                        $array1[1] . '/' .
                        $array1[2] . '/' .
                        $array1[3];

                array_push($array3, $value);
            }
        }

        $res2 = array_unique($array2);
        $res3 = array_unique($array3);

        // 第三階層ディレクトリが第二階層にあれば、
        // 第三階層のディレクトリは削除
        foreach ($res2 as $value) {
            foreach ($res3 as $key => $item) {
                if (strpos($item, $value) !== false) {
                    unset($res3[$key]);
                }
            }
        }

        $res_merge = array_merge($res2, $res3);
        $content = "true";

        // フォルダ名が変更できるかチェック
        foreach ($res_merge as $sourceDir) {

            try {

                if (rename($sourceDir, $sourceDir . '00')) {
                    rename($sourceDir . '00', $sourceDir);

                } else {
                    throw new PDOException();
                }

            } catch (PDOException $e) {

                $content = "false";
            }
        }

        $response->getBody()->write($content);

        return $response;
    }

    // public function folderUseCheck(Request $request, Response $response, array $args): Response
    // {
    //     $pagesObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）
    //     $folderCnt1 = count($pagesObj);
    //     $menuArray1 = json_decode($_POST['list']);
    //     $menuObj = [];

    //     foreach ($menuArray1 as $val) {
    //         $dirArray = explode('/', $val);
    //         $lastDir = end($dirArray); //配列の最後の値
    //         $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
    //         $menuObj[$folderNoNum] = '../pages/'.$val;
    //     }

    //     $sabunFolder = array_diff($pagesObj, $menuObj);

    //     $array2 = [];
    //     $array3 = [];
        
    //     foreach ($sabunFolder as $value){
    //         $array1 = explode('/', $value);
    //         $cnt = count($array1);
            
    //         iF($cnt==3){
    //             array_push($array2, $value);
    //         } else if($cnt==4 && !in_array($array1[2], $array2)){
    //             array_push($array3, $value);
    //         } else if($cnt >= 5){
    //             //第四階層以下は、第三階層にする
    //             $value = $array1[0].'/'.$array1[1].'/'.$array1[2].'/'.$array1[3];
    //             array_push($array3, $value);               
    //         }
    //     }

    //     $res2 = array_unique($array2);//第二階層の差分ディレクトリ
    //     $res3 = array_unique($array3);//第三階層の差分ディレクトリ

    //     //第三階層ディレクトリが第二階層階層にあれば、第三階層のディレクトリは削除
    //     foreach ($res2 as $value){
    //         foreach ($res3 as $key => $item){
    //             if(strpos($item, $value) !== false){
    //                 unset($res3[$key]);
    //             }
    //         }
    //     }


    //     $res_merge = array_merge($res2, $res3);
    //     $content = "true";

    //     //フォルダ名が変更できるかチェック
    //     foreach($res_merge as $sourceDir){

    //         try{
    //             if(rename ( $sourceDir , $sourceDir.'00' )){
    //                 rename ( $sourceDir.'00' , $sourceDir );

    //             }else{
    //                 throw new PDOException();
    //             }

    //         }catch(PDOException $e){
    //             // echo $e->getMessage();
    //             $content = "false";

    //             // exit('処理を強制終了します。');//処理を強制終了

    //         }finally{
    //             // echo "処理が終了しました";
    //         }
    //     }

    //     $responseBody = $response->getBody();
    //     $responseBody->write($content);

    //     return $response;
    // }


    
    //pages内のディレクトリ一覧の連想配列を取得
    public function pagesDirGet(Request $request, Response $response, array $args): Response {

        $pageArea = $request->getAttribute('pageArea');

        if (empty($pageArea)) {
            $data = $request->getParsedBody() ?? [];
            $pageArea = $data['pageArea'] ?? PageArea::NORMAL;
        }

        $pageDir = PageArea::getPageDir($pageArea);

        $pagesAry = $this->folderService->getFolderComp($pageDir);

        $pagesJson = json_encode($pagesAry);

        $response->getBody()->write($pagesJson);

        return $response;
    }
    // public function pagesDirGet(Request $request, Response $response, array $args): Response
    // {
    //     $pagesAry = $this->folderService->getFolderComp();
    //     $pagesJson = json_encode($pagesAry);
    //     $responseBody = $response->getBody();
    //     $responseBody->write($pagesJson);

    //     return $response;
    // }


    //---------------------
    // 番号修正
    //---------------------

    public function num_replace(Request $request, Response $response, array $args): Response
    {
        $folderObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）      
        $data = $request->getParsedBody();
        //並べ替え予定のメニューの配列取得
        $menuArray = json_decode($data['list'] ?? '[]', true);
        sleep(2);
        //フォルダ番号修正
        $this->folderService->dirNumReplace($menuArray, $folderObj);

        return $response;
    }
    

}

