//編集保存
$('#upload').click(function(){
	howUpdate = 'click';
	file_submit(howUpdate);
	startReport = $('#report-markdown').val();
})

$(window).keydown(function (e) {
	howUpdate = 'key';

	if (e.ctrlKey) {
		//編集保存（Ctrl+S）
		if (e.keyCode === 83) {
			file_submit(howUpdate);
			startReport = $('#report-markdown').val();
			return false;
		}
	}
});


//ページに戻る前の編集したかチェック
$('.btn-return').on('click',function(){
	let report = $('#report-markdown').val();
	howUpdate = 'return';
	
	if(startReport!=report){
		if(window.confirm('編集内容は保存しますか?')){
			// window.alert('保存しました');
			file_submit(howUpdate);
			startReport = $('#report-markdown').val();
		}
		// else{
		// 	window.alert('キャンセルされました');
		// 	$('#return-form').onsubmit = function(){ return false }

		// 	return false;
		// }
	}
});


//マークダウンファイルを更新処理
function file_submit(howUpdate) {
	let markText = $('#report-markdown').val();
	let folderList = [];

	//入力データを送信
	$.ajax({
		// url: 'markdown-upload.php',
		// url: '../common/update/markdown-upload.php',
		url: '../public/markdown-upload',
		type: "POST",
		cache: false,
		// data: { report: markText, folderDir: folderDir },
		data: { report: markText, folderDir: folderDir },
	}).done(function (data) {
		//通信成功時の処理
		console.log(howUpdate)
		if(howUpdate!=='key'){//エンターキー以外
			// alert('入力内容を更新しました。');
			editComplete();
		}
		
	}).fail(function () {
		//通信失敗時の処理
		alert('入力内容のアップロードに失敗しました');
		return false;
	});
}


//ドラッグ&ドロップとたときの処理
let obj = $("#DnDBox");

//ドラッグしているファイルがドロップ領域に入ったとき
obj.on('dragenter', function (e) {
	e.stopPropagation();
	e.preventDefault();
	$(this).css('border', '4px solid #000');
});

//ドラッグしているファイルがドロップ領域にある間
obj.on('dragover', function (e) {
	e.stopPropagation();
	e.preventDefault();
	$(this).css('border', '4px solid #000');
});

//ドラッグしているファイルがドロップ領域にドロップされたとき
obj.on('drop', function (e) {
	try{
		$(this).css('border', '4px dashed #000');
		e.preventDefault();
		let folderList = [];
		let dropFile = e.originalEvent.dataTransfer.files[0];
		let fileName = e.originalEvent.dataTransfer.files[0].name;//選択したファイル名

		$('#waitingList li').each(function () {//ファイル一覧を変数に格納
			folderList.push($(this).children('.filename').text());
		});

		if (folderList.indexOf(fileName) != -1) {
			if (window.confirm(fileName + 'と同じ名前のファイルがあります。上書きしますか?')) {
				file_save(dropFile);
			}
		} else {
			file_save(dropFile);
		}

	} catch(error) {
		alert('ファイル保存に失敗しました。編集更新を実行した後、ブラウザーを更新して再度ファイル保存してみてください。')
	}
});


//uploadフォルダ内にファイルの登録、更新処理
$('input#file').change(function () {
	try{
		let fileName = $('input[type=file]')[0].files[0].name;//選択したファイル名

		if(fileName.match(/ |　/)){
			alert('ファイル名に空白があります')
		}else if (fileName.match(/\*|"|:|\?|<|>| |\//)) {
			alert('* " : ? < > / のいづれかの文字がファイル名に含まれているので保存できません。');

		}else if(fileName.match(/^\./)){
			alert('「.」がファイル名の先頭に存在するので保存できません。');
			
		}else if(fileName.match(/\\/)){
			alert('\\がファイル名に含まれているので保存できません。');
			
		}else{
			//ファイルを保存
			let folderList = [];
			let selectFile = $('input[type=file]')[0].files[0];
		
			$('#waitingList li').each(function () {//ファイル一覧を変数に格納
				folderList.push($(this).children('.filename').text());
			});
		
			if (folderList.indexOf(fileName) != -1) {
				if (window.confirm(fileName + 'と同じ名前のファイルがあります。上書きしますか???')) {
					file_save(selectFile);
				}
			} else {
				file_save(selectFile);
			}
		}

		$(this).val('');

	} catch(error) {
		alert('ファイル保存に失敗しました。編集更新を実行した後、ブラウザーを更新して再度ファイル保存してみてください。')
	}
});

function file_save(fileData) {
	let fd = new FormData();

	fd.append('hoge', fileData);
	fd.append('folderDir', folderDir);

	$.ajax({
		// url: '../common/update/file_save.php',
		url: '../public/file_save',
		type: 'POST',
		processData: false,
		contentType: false,
		cache: false,
		data: fd
	}).done(function (data) {
		//通信成功時の処理
		$('#waitingList').html(data);//保存ファイルリストを挿入
		alert('保存しました。')
		document.getElementById('DnDBox').removeAttribute('style');

	}).fail(function () {
		//通信失敗時の処理
		alert('失敗しました～。')
	});
}

//uploadフォルダ内のファイル削除
$('ul').on('click', '.fileDelete', function () {
	let delObj = $(this);
	let delName = $(this).siblings('.filename').text();

	if (window.confirm('「'+delName + '」を削除していいですか？')) {

		//削除ファイル名の変数delNameをfile_delete.phpに送信
		$.ajax({
			// url: "../common/update/file_delete.php",
			url: "../public/file_delete",
			type: "POST",
			cache: false,
			data: { item: delName, folderDir: folderDir }//ファイル名
		}).done(function (data) {
			console.log(data);
			
			//リストのファイル表示削除
			delObj.parent('li').remove();
			alert(delName + 'を削除しました。');

		}).fail(function () {
			alert(delName + 'の削除に失敗しました。');
		});

	} else {
		return false;
	}
});


function icon_inst() {
	//※test()メソッドは、正規表現と指定した文字列がマッチするかを調べます。 trueかfalseを返します.
	switch (true) {
		//PDFアイコン
		case /.pdf$/.test(fileName):
			fileClass = 'filename file_icon pdf-icon';
			break;
		//EXCELアイコン
		case /.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/.test(fileName):
			fileClass = 'filename file_icon excel-icon';
			break;
		//WORDアイコン
		case /.doc$|.docm$|.docx$|.dot$|.dotx$/.test(fileName):
			fileClass = 'filename file_icon word-icon';
			break;
		//ZIPアイコン
		case /.zip$/.test(fileName):
			fileClass = 'filename file_icon zip-icon';
			break;
		//TEXTアイコン
		case /.txt$/.test(fileName):
			fileClass = 'filename file_icon text-icon';
			break;
		//PowerPointアイコン
		case /.pptx$/.test(fileName):
			fileClass = 'filename file_icon pptx-icon';
			break;
		default:
			break;
	}
}


//プレビューボタンをクリック
$(".btn-preview").click(function () {

	let titleVal = $('h1').val();//タイトル名
	$('#title-p').val(titleVal);

	let reportVal = $('#report-markdown').val();//記事
	$('#report-p').val(reportVal);

	$('#form-preview').submit();
});



//編集更新完了モーダル
const editSuccess = document.getElementById('editSuccess');
const editSuccessModal = new bootstrap.Modal(document.getElementById('editSuccess'));

//モーダル　一定時間経過後消える処理
function modalHide() {
    return new Promise(function (resolve) {
        editSuccessModal.hide();
        resolve();
    })
}

async function editComplete(){
    await modalHide();

    editSuccessModal.show();

    editSuccess.addEventListener('shown.bs.modal', (e) => {
        setTimeout(function () {
            editSuccessModal.hide();
        }, 3000);
    });
}


