---
title: 変数の型を変換
taxonomy:
    category:
        - docs
---

## 数値→文字列に変換(toString)

最も簡単な方法としては、Number型である数値をそのままStringオブジェクトの引数にしてしまうことです。

<script async src="//jsfiddle.net/35cLjdy0/embed/js,css,result/"></script>

もう1つ簡単な方法としては、Numberオブジェクトのメソッドを活用するのがオススメです。  
同じように変数「num」を使うのですが、「 . (ドット)」で「toString()」メソッドを連結して文字列に変換しています。

<script async src="//jsfiddle.net/7h3z08pe/embed/js,result/"></script>

## 文字列→数値に変換(Number/parseInt)

先ほどの「数値→文字列」の変換と同じようにString型である文字列をNumberオブジェクトの引数として代入すれはOKです。

<script async src="//jsfiddle.net/yopew653/embed/js,result/"></script>

上記以外によく使う方法としては「parseInt()」があります。  
「parseInt()」の引数に文字列「123」を代入することで、そのまま数値へと変換することが出来るわけです。

<script async src="//jsfiddle.net/dqsuyr80/embed/js,result/"></script>

## 参考サイト

* [【Javascript入門】数値⇔文字列の変換(toString/Number/parseInt)](https://www.sejuku.net/blog/23998)