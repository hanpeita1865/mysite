<?php
$jsonData = file_get_contents('test.json');
$data = json_decode($jsonData, true);
print_r($data);

$data['name']='森 花子';
$data['furigana']='もり　はなこ';
$data['position']='マネージャー';

$jsonData = json_encode($data, JSON_UNESCAPED_UNICODE);

file_put_contents('test.json', $jsonData);
?>