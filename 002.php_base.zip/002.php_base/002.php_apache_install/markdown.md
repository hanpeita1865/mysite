*[page-title]:Apache+PHP+Xdebugのインストール



## Apacheインストール

参考サイト
: [Apache入門](https://www.javadrive.jp/apache/)
: [Windows11にApache+PHP8.3を導入する](https://zenn.dev/ichikawa_y/articles/windows-apache-php83)

### ダウンロード

Apacheのダウンロードを下記のサイトから行います。  
<http://httpd.apache.org/>

最新バージョンである「Apache httpd 2.4.63 Released」のブロックにある「Download」をクリックして下さい。
![](upload/Apache2.4.63Reeased.png){.photo-border}

Apache のダウンロード用ページが表示されます。今回は Windows 環境にインストールするので「Files for Microsoft Windows」をクリックして下さい。
![](upload/Apache2.4.63Reeased_windows指定.png){.photo-border}

Apache の公式サイトでは Windows 用のバイナリは用意されていないという説明が表示されます。代わりに配布してくれているサイトをいくつかリストアップしてくれていますので、この中から今回は「Apache Lounge」をクリックしました。
![](upload/Apache_oungeを選択.png){.photo-border}

Apache Lounge のサイトが表示されます。  
64bit 環境にインストールしますので「Apache 2.4.63-250207 Win64」の下に表示されているリンクをクリックします。  
これでダウンロードは完了です。
![](upload/Apache_Longeダウンロード.png){.photo-border}


### インストール

ダウンロードしたして解凍したファイルを展開して任意のディレクトリに配置して下さい。
今回は Cドライブの直下に「site」というフォルダを新規に作成し、その中に配置しました。
![](upload/site_Apacheフォルダ.png){.photo-border}

Apache のインストールは以上で完了です。


## Apacheの設定

### 設定ファイル(httpd.conf)の初期設定

Apache の設定ファイルである httpd.conf ファイルは「(インストールしたディレクトリ)\Apache24\conf\」ディレクトリに入っています。  
それでは httpd.conf ファイルを編集します。 
<div markdown="1" class="">
![](upload/httpd_confのサーバールートデフォルト.png){.figure-none}
</div>
↓ 次のように書き換えます。
![](upload/httpd_confのサーバールートかきかえ.png)

![](upload/Listen80.png)

ServerName を次のように追記します。
![](upload/ServerNameのコメントアウトをとる.png)

設定ファイルの修正が終わりましたら設定ファイルを保存しておいて下さい。


### Apacheの起動

まずはコンソールアプリケーションとして Apache を起動する方法です。実行ファイル( httpd.exe )の場所は「(Apacheをインストールしたディレクトリ)\Apache24\bin\httpd.exe」です。
![](upload/binフォルダ内.png){.photo-border}

起動するにはコマンドプロンプトを管理者として起動し、「(Apacheをインストールしたディレクトリ)\Apache24\bin\」ディレクトリまで移動してから <span class="red">httpd</span> と実行して下さい。 Apache が起動します。

Apache が起動しました。起動中、コマンドプロンプトは次のような状態となります。
![](upload/httpd実行中コマンド.png)

それでは Apache が起動しているか試してみます。ブラウザを立ち上げ「<http://localhost/>」へアクセスして下さい。次のように表示されれば Apache は正常に起動しています。

Xamppでlocahost:80を使用してる場合は、XampのApacheは停止しておきます。

下記のような、htdocsのindex.htmlが表示できたら成功です。
![](upload/It_works表示.png){.photo-border}

Apache を停止する場合は、 Apache を起動させたコマンドプロンプト上で Ctrl＋Cキー を押して下さい。


### Apacheをサービスとして登録する

次に Apache をサービスとして起動する方法です。まずはサービスとして登録を行ないます。 Apache が起動している場合は停止しておいて下さい。  
コマンドプロンプトを管理者として起動し、「(Apacheをインストールしたディレクトリ)\Apache24\bin\」ディレクトリまで移動してから次のように実行して下さい。

<p class="tmp cmd"><span>コマンド</span>サービスに登録</p>
```
httpd -k install
```
次のように表示されれば、サービスへの登録は成功です。
![](upload/アパッチをサービスに登録.png)

サービスの画面を表示するには、次のようにします。

スタートボタン上で右クリックし、「コンピューターの管理」をクリックします。
![](upload/コンピューターの管理をクリック.png){.photo-border}

サービスとアプリケーション内のサービスを開きます。
![](upload/コンピューターの管理のサービスとアプリケーション.png){.photo-border}

Apache24が起動しているのが確認できます。自動になってますが、手動にしておきます。
![](upload/サービス登録一覧.png){.photo-border}

プロパティの画面を開いて、手動に変えます。
![](upload/Apacheプロパティ画面.png)


その他のコマンドでのサービスの操作は、下記になります。

<p class="tmp cmd"><span>コマンド</span>サービスとして Apache を起動</p>
```
httpd -k start
```

<p class="tmp cmd"><span>コマンド</span>停止</p>
```
httpd -k stop
または
httpd -k shutdown
```

<p class="tmp cmd"><span>コマンド</span>再起動</p>
```
httpd -k restart
```


## ApaheからPHPを利用できるように設定する

### php_moduleモジュールを追加する

最初に PHP を利用するためのモジュールを追加します。今回は PHP 8 系を使用するので php_module を使用します。  

下記サイトからPHPのバージョンを指定し、ダウンロードします。  
<https://windows.php.net/download>

ここでは、8.2.28のバージョンをダウンロードしました。
![](upload/php8.2.28をダウンロード.png)

![](upload/php8.2.28ダウンロード完了.png){.photo-border}

上記のフォルダをsiteフォルダに格納して、フォルダ名をphpに変えます。

php.ini-developmentをphp.iniにファイル名を変えます。

phpフォルダ内にphp8apache2_4.dllがあるか確認してください。
![](upload/php8apache2_4.png)

httpd.confに下記コードを追記します。
![](upload/httpd_confにコード追加.png)
<p class="tmp list"><span>リスト</span>httpd.conf</p>
```
LoadModule php_module c:/site/php/php8apache2_4.dll

<FilesMatch "\.php$">
  AddHandler php-script .php
  AddType application/x-httpd-php .php
</FilesMatch>

PHPIniDir "c:/site/php"
```

PHPの表示を確認するので、htdocsフォルダ内に下記のコードを記入したphpinfo.phpファイルを格納してください。
<p class="tmp list"><span>リスト</span>phpinfo.php</p>
```
<?php
phpinfo();
?>
```

![](upload/phpinfo表示.png){.photo-border}


## Xdebugのインストール

今のところ、Xdebugはインストールされていません。
![](upload/Xdebugまだ.png)

では、Xdebugを設定していきます。

参考サイト
: [【2023年10月版】PHP8.2にXdebugをインストールする(環境: Windows11×Apache2.4)](https://laranote.jp/installing-xdebug-on-php8-2/)


<https://xdebug.org/wizard>にアクセスし、phpinfoのページを丸ごとコピーして、サイトのテキストエリアに貼り付けます。
![](upload/xdebud_wizard.png){.photo-border}

赤枠のボタンを押します。そうすると、xdebugのphpバージョンにあわせたdllファイルが生成されます。
![](upload/xdebug_dllファイル生成.png){.photo-border}

これをダウンロードして「C:\site\php\ext」に配置します。
![](upload/xdebug_dllファイルをextに格納.png){.photo-border}


### php.iniの編集

次に、php.iniを編集し、php_xdebug.dllをPHPから読み込むようにします。  
php.iniをテキストエディタで開いた後、最後尾に以下のように追加します。

```
[XDebug]
zend_extension = "C:\xampp\php\ext\php_xdebug-3.2.0-8.2-vs16-x86_64.dll"
xdebug.mode = debug
xdebug.start_with_request = yes
```

これでPHPを起動させた際に、php_xdebug.dllを読み込む準備が整いました。  
Apacheを再起動します。  

インストールできてました。
![](upload/with_Xdebud設置成功確認.png){.photo-border}


### デバッグの動作確認

次のファイルを作成して、htdocsに格納します。
<p class="tmp list"><span>リスト</span>hello.php</p>
```
<?php
date_default_timezone_set('Asia/Tokyo');
$d = getdate();
$h = $d["hours"];

if ($h < 6 && $h > 12)
  $msg = "Good morning!, ";
elseif ($h >= 12 && $h <= 18)
  $msg = "Good afternoon!, ";
elseif ($h >= 19 && $h <= 22)
  $msg = "Good evening!, ";
else
  $msg = "Good night!, ";

print_r($msg);
```

![](upload/hello.phpを格納.png){.photo-border}

<http://localhost/hello.php>にアクセスして表示させます。

VSCODEで開いて、ブレークポイントを設定します。
![](upload/hello.phpにブレークポイント設置.png)

デバッグの拡張機能を開いて実行します。成功すると設置したブレークポイントで処理が停止されます。
![](upload/デバッグできた.png)