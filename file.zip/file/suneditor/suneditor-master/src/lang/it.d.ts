import { Lang } from './Lang';

declare const it: Lang;

export default it;