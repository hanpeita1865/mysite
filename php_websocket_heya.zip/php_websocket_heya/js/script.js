const startBtn = document.getElementById('js-start');
const hideBtn = document.getElementById('js-recal');
const rest = [];
const members = [];

startBtn.addEventListener('click', () => {
	//既に部屋分けを実行していた場合、表示されている部屋分け結果を削除
	const resulrSpeace = document.getElementsByClassName('result');
	if (0 < resulrSpeace.length) {
		while (resulrSpeace.length) {
			resulrSpeace.item(0).remove();
		}
	}

	const resultRoom = document.getElementsByClassName('room-name');
	if (0 < resultRoom.length) {
		while (resultRoom.length) {
			resultRoom.item(0).remove();
		}
	}

	const resultList = document.getElementsByClassName('result-list')
	if (0 < resultList.length) {
		while (resultList.length) {
			resultList.item(0).remove();
		}
	}

	const resultName = document.getElementsByClassName('room-members');
	if (0 < resultName.length) {
		while (resultName.length) {
			resultName.item(0).remove();
		}
	}

	//名前リストと使用する会議室数の取得
	const name = document.getElementsByClassName('name');
	const room = document.getElementById('room-length').value;

	//出席者と欠席者のリスト作成	
	for (let i = 0; i < name.length; i++) {
		if (name[i].checked) {
			rest.push(name[i].value);
		} else {
			members.push(name[i].value);
		}
	}

	//使用する会議室に参加者をランダム配置
	const numberPerTeam = Math.floor(members.length / room);
	const moduloMembers = members.length % room;
	const s = members => {
		for (let i = members.length - 1; i > 0; i--) {
			const j = Math.floor(Math.random() * (i + 1));
			[members[i], members[j]] = [members[j], members[i]];
		}
		return members;
	}

	let roomDiv = [];
	const formData = new FormData;


	//部屋分け結果のHTMLを作成
	const roomNameList = ['制作2会議室', '制作3会議室', '制作4会議室', '制作6会議室', '制作7会議室', '制作8会議室', '制作9会議室']
	for (let i = 0; i < room; i++) {
		const grouping = s(members).splice(0, numberPerTeam + (i < moduloMembers));
		const result = document.createElement('div');
		result.classList.add('result');
		const roomName = document.createElement('p');
		result.classList.add('room-name');
		const resultList = document.createElement('ul');
		result.classList.add('result-list');
		const parent = document.getElementById('js-result');
		const number = document.createTextNode(roomNameList[i]);
		roomName.appendChild(number);
		parent.appendChild(result);
		result.appendChild(roomName);
		result.appendChild(resultList);


		// roomDiv[roomNameList[i]] = grouping;//部屋とメンバーを配列に格納
		// console.log('['+JSON.stringify(roomNameList[i]+','+grouping+']'))

		// formData.append(i, '['+JSON.stringify(roomNameList[i]+','+grouping+']'));


		for (let i = 0; i < grouping.length; i++) {
			const roomMembers = document.createElement('li');
			result.classList.add('room-members');
			const menberName = document.createTextNode(grouping[i]);
			roomMembers.appendChild(menberName);
			resultList.appendChild(roomMembers);
		}
	}

	let resultHtml = document.getElementById('js-result').innerHTML;//部屋分け結果HTML
	let resultObj = {type: 'result', html: resultHtml};
	let resultStr = JSON.stringify(resultObj);//文字列に変換

	//WebSocketに部屋分け結果を送信
	conn.send(resultStr);


	//データベースのresultテーブルに登録の送信用
	formData.append('result', resultHtml);

	//データベースに部屋分けリストを書き込み
	fetch('write_result.php', {
		method: 'POST',
		body: formData,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response.text();
		})
		.then(data => {
			//通信成功時の処理
			//alert('DBの閲覧不可の登録を削除しました');
			console.log('通信成功です。')
		})
		.catch((reason) => {
			alert('失敗しました～。')
		});


	// //初期状態から表示の変更
	// document.getElementById('js-result').style.display='flex';
	// document.getElementById('js-hide').remove();
	// startBtn.innerText='もう一度部屋分け';
});


// document.getElementById('js-reset').addEventListener('click', () => {
// 	location.reload();
// });

//リセット（データベースの部屋分けリスト削除）
document.getElementById('js-reset').addEventListener('click', () => {

	if (window.confirm('リセットしていいですか？')) {
		fetch('delete_result.php', {
			method: 'POST',
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response.text();
			})
			.then(data => {
				//通信成功時の処理
				// console.log('通信成功です。')
				document.getElementById('js-result').innerHTML ='';
				document.getElementById('js-hide').classList.remove('d-none');
			})
			.catch((reason) => {
				console.log('削除に失敗しました。')
			});
	}
});

//データベースに結果があるか確認

//データベースの部屋分けリストを読み込み
fetch('read_result.php', {
	method: 'POST',
}, { cache: "no-store" })
	.then((response) => {
		if (!response.ok) {
			throw new Error();
		}
		return response.text();
	})
	.then(data => {
		//通信成功時の処理
		// console.log('通信成功です。')
		data = data.replace(/\r?\n/g, '');//改行削除
		console.log(data)
		if(data !=''){
			document.getElementById('js-hide').classList.add('d-none');
			document.getElementById('js-result').innerHTML= data;
		}
	})
	.catch((reason) => {
		console.log('結果の読み込みに失敗しました。')
	});


