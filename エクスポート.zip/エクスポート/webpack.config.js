const path = require('path');

module.exports = {
    entry: "./js/modules/script.js",// メインとなるJavaScriptファイル（エントリーポイント）
    mode: "development",//開発モード
    devtool: "source-map",  // または 'inline-source-map' など

    // ファイルの出力設定
    output: {
        //  出力ファイルのディレクトリ名
        path: path.resolve(__dirname, './dist/js'),
        // 出力ファイル名
        filename: 'script.js'
    },
}