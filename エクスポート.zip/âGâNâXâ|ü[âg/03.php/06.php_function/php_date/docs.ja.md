---
title: 日時の設定・表示（date）
taxonomy:
    category:
        - docs
visible: true
---

<iframe src="https://paiza.io/projects/e/2qJuvtDYbkqks3tEqiqv2g?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>