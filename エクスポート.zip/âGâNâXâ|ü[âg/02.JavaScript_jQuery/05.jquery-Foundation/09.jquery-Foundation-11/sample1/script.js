$('button').on('click',function(){
	$.ajax({
		url: 'common/sample.html',
		type: 'GET',
		dataType: 'html',
		cache: false
	}).done(function(data){
		$('#hoge').html(data)
	});
})
