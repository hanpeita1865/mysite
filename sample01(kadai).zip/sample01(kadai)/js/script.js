const elm_gender = document.getElementById('gender');
const elm_local = document.getElementById('local');
let fSort = 'dsc';//ふりがなで並べ替え
let genderSlt = '';//性別
let localSlt = '';//都道府県名
let nameSearch = '';//名前検索値

//テーブルにデータ挿入
dataInsert();

//性別セレクトボックス選択
elm_gender.addEventListener('change', e=>{
    genderSlt = e.target.value;
    dataInsert();
});

//都道府県セレクトボックス選択
elm_local.addEventListener('change', e=>{
    localSlt = e.target.value;
    dataInsert();
});



//テーブルBody内データ挿入
function dataInsert(){

    fetch('files/customers.json') 
    .then((response) => {
        if (!response.ok) {
            throw new Error();
        }
        return response;
    })
    .then(response => response.json()) 
    .then(data => {
         //console.log(data)
    
         //データから抽出
        let dataFilter = data.filter(function(value){
            let regGender = new RegExp(genderSlt);//性別で抽出（値が空の場合は全て抽出）
            let regLocal = new RegExp(localSlt);//都道府県名で抽出（〃）
            return regGender.test(value.gender) && regLocal.test(value.place);
        });
    
        //console.log(dataFilter)
    
        //データ並べ替え
        let sortData = dataFilter.sort(function(a, b) {
            if(fSort == 'dsc'){
                //降順
                return (a.furigana > b.furigana) ? -1 : 1;
            }else{
                //昇順
                return (a.furigana < b.furigana) ? -1 : 1;
            }
        });
    
    
        // console.log(sortData)
    
        let codeBody = '';
        sortData.forEach(value => {
            codeBody += '<tr><td>'+value['name']+'</td><td>'+value['furigana']+'</td><td>'+value['gender']+'</td><td>'+value['place']+'</td><td>'+value['tel']+'</td><tr>';
        });
    
        document.querySelector('#customer tbody').innerHTML=codeBody;
    })
    .catch(() => {
        //エラー処理
        console.log('エラー');
    })
}



//セレクトボックス内に都道府県名を挿入
fetch('files/local_base.json') 
.then((response) => {
    if (!response.ok) {
        throw new Error();
    }
    return response;
})
.then(response => response.json()) 
.then(data => {

    let opt = '';
    data.forEach(value => {
        opt += '<option value="'+value.local_place+'">'+ value.local_place +'</option>';
    });

    document.getElementById('local').innerHTML=opt;
})
.catch(() => {
    //エラー処理
    console.log('エラー');
})