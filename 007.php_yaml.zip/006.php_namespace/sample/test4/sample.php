<?php
require_once 'greeting.php';
use Asia\Japan\Kanto\Tokyo;

echo Tokyo\hello(); // 出力結果：こんにちは