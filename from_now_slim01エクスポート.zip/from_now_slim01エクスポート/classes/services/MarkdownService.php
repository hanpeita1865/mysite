<?php
namespace SocymSlim\SlimMiddle\Services;

use ParsedownExtra;
use Psr\Container\ContainerInterface;

class MarkdownService
{
    private ContainerInterface $container;
    private ParsedownExtra $parser;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
        
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        $this->parser = new ParsedownExtra();
    }


    //-----------------------------//
    //   マークダウンをHTMLに変換   
    //----------------------------//
    
    public function getMarkdownData(array $folderObj, string $folderName): array
    {
        $config = $this->container->get('config');
        $basePath = $config['basePath'];

        // 対象フォルダが存在するか確認
        if (empty($folderObj[$folderName])) {
            return ['html' => 'ページが存在しません。', 'title' => ''];
        }

        $folderPath = $folderObj[$folderName];
        $folderPath1 = str_replace('..', '', $folderPath); // ".."を削除

        // Markdownファイルを読み込み
        $markdownFile = $_SERVER["DOCUMENT_ROOT"] . $basePath . $folderPath1 . '/markdown.md';
        
        if (!file_exists($markdownFile)) {
            return ['html' => 'Markdownファイルが見つかりません。', 'title' => ''];
        }

        $md = file_get_contents($markdownFile);

        // ページタイトルを抽出
        preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
        $title = $ArrayTitle[1] ?? '';

        // HTML変換
        $htmlData = $this->parser->text($md);

        // 画像・リンク・iframeなどのパスを変換
        $replacements = [
            ['/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="' . $basePath . $folderPath1 . '/upload/$2"$3>'],
            ['/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="' . $basePath . $folderPath1 . '/upload/$2"$3>'],
            ['/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="' . $basePath . $folderPath1 . '/sample/$2" target="_blank">$4</a>'],
            ['/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i', '<iframe$1src="' . $basePath . $folderPath1 . '/sample/$2"$3></iframe>']
        ];

        foreach ($replacements as [$pattern, $replacement]) {
            $htmlData = preg_replace($pattern, $replacement, $htmlData);
        }

        return [
            'html' => $htmlData,
            'title' => $title
        ];
    }
    
 
    
    //------------------------------
    //  検索結果用 マークダウン変換
    //------------------------------
    
    public function markSearch(array $mdArray, string $word, bool $fullText){
        
        $pattern = '/'.$word.'/';
        $wordNum = 0;
        $htmlData = '';
        
        foreach($mdArray as $val){

            $dirNonum = preg_replace('/\/\d{3}./','/',$val['dir']).'/';
            $dirNonum = preg_replace('/\.\.\//','',$dirNonum);

            //ページタイトル markdown.mdの先頭にあるpage-titleの値を、$ArrayTitleに格納。
            preg_match("/^\*\[page-title\]:\s*(.+)/", $val['md'], $ArrayTitle);

            if(!empty($ArrayTitle[1])){
                $title = $ArrayTitle[1];//ページタイトル
            }else{
                $title = '';
            }

            $html = $this->parser->text($val['md']);
            $text = strip_tags($html,"<pre><code>");//<pre><code>は残す
            $getWord = null;

            if($fullText){
                //全文検索
                if(preg_match_all($pattern, $text, $getWord)){
                    $sumWord = array_unique($getWord[0]);

                    if($fullText){
                        foreach ($sumWord as $value) {
                            $patternDiff = '/'.$value.'/';
                            $text = preg_replace($patternDiff, '<mark class="hilight">'.$value.'</mark>', $text);//検索文字にマークを付ける
                        }    
                    }
        
                    $htmlData = $htmlData.'<section><h3><a href="'.$dirNonum.'" >'.$title.'</a></h3><div class="search-text">'.$text.'</div></section>';
                    $wordNum++;
                }
            } else {
                //タイトル検索
                $htmlData = $htmlData.'<section><h3><a href="'.$dirNonum.'" >'.$title.'</a></h3><div class="search-text">'.$text.'</div></section>';
                $wordNum++;
            }
        }
        
        $htmlData = '<p id="search-number">「'.$word.'」の検索結果：<span id="word-num">'.$wordNum.'</span>ページ</p>'.$htmlData;

        $markData = ['html' => $htmlData];

        return $markData;
    }
    
    
    //------------------------------
    //  プレビュー用 マークダウン変換
    //------------------------------       
    public function getPreviewMarkData(array $folderObj): array
    {
        $config = $this->container->get('config');
        $basePath = $config['basePath'];

        $md = $_REQUEST['report-p']; //記事原文
        $title = $_REQUEST['pagename-p']; //タイトル
        $folderPath = $_REQUEST['folderPath-p']; //パス
        $folderName = $_REQUEST['folder-p']; //フォルダ名

        $folderPath = $folderObj[$folderName];
        $folderPath1 = str_replace('..', '', $folderPath);

        $htmlData = $this->parser->text($md);

        //画像のパスを変換
        $htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);
        //ファイルリンクのパスを変換
        $htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);

        //sampleのパスを変換
        $htmlData = preg_replace('/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="' . $basePath . $folderPath1 . '/sample/$2" target="_blank">$4</a>', $htmlData);

        //iframeのパスを変換
        $htmlData = preg_replace('/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i', '<iframe$1src="' . $basePath . $folderPath1 . '/sample/$2"$3></iframe>', $htmlData);

        $markArray = ['html' => $htmlData, 'title' => $title];

        return $markArray;    
    }
}
