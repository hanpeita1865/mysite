*[page-title]:3-4. データバインディング関連のディレクティブ

データバインディングの基本は、2-2-1 項を中心に既に解説しています。しかし、データバインディ ングはテンプレート開発の基本中の基本でもあり、それだけに奥深い世界でもあります。本節では、前 掲の理解を前提に、さらにバインディングの知識を深めていきます。

## 3-4-1 属性に値をバインドする -v-bind
まずは、属性に値をバインドする <span class="green bold">v-bind ディレクティブ</span>からです。v-bind の基本については 2-2-1 項も併せて参照してください。

### 複数の属性をまとめて指定する
v-bind ディレクティブには、「属性名:値 ,...」形式のオブジェクトを渡すことで、複数の属性を まとめてバインドすることもできます。たとえば以下は、&lt;input&gt; 要素に <span class="red">size</span>、<span class="red">maxlength</span>、<span class="red">required 属性</span>をまとめて設定する例です。

<p class="tmp list"><span>リスト3-65 / 3-66</span></p>
http://localhost:7008/chap03/bind_obj.html
![](upload/リスト3-65_3-66.png)

属性情報をハッシュとして渡す場合には、v-bind ディレクティブの引数(「v-bind:xxxxx」の「xxxxx」) は不要です。また、required 属性のように値を持たない(=固定である)属性を設定する場合には、 値は true としておきます (false の場合は属性は付与されません)。

<p class="result"><span>表示結果</span></p>
![](upload/bind_obj_表示結果.png)

HTML生成結果
![](upload/bind_obj_HTML生成結果.png)


<div markdown="1" class="note-box">
属性が重複した場合 タグ内の属性と v-bind ディレクティブで渡されたオブジェクト(属性)が重複した場合、あとで書かれたものが優先されます。たとえば(1)を以下のように書き換えてみましょう。
```
<input type="text" id="memo" size="100" v-bind="attrs" />
```
HTML生成結果
![](upload/bind_obj_HTML生成結果2.png)

この場合、size 属性が重複しますが、v-bind があとに書かれているので、size 属性の値は 20 (データオブジェクトの値)となります。  
一方、以下のように書き換えるとどうでしょう。

```
<input type="text" id="memo" v-bind="attrs" size="100" />
```
HTML生成結果
![](upload/bind_obj_HTML生成結果3.png)
今度は、元々書かれた size 属性の値 (100)が適用されます。v-bind 属性でオブジェクトをバインドする際には、<span class="marker-pink50">いずれを優先するかを意識して、記述の順序にも留意してください</span>。
</div>


### JavaScript 式から属性値を決定する
属性名をブラケットで括ることで、属性名を式の値から動的に生成することも可能です(動的引数 ※1)。たとえば以下は、入力値に応じて、&lt;img&gt; 要素の height および width 属性を設定する例です。

※1 ここでは v-bind を例にしていますが、「v-on: [event]="..."」のように、v-on でも同じように動的引数を利用できます。

<p class="tmp list"><span>リスト3-67 / 3-68</span></p>
http://localhost:7008/chap03/bind_dynamic.html
![](upload/リスト3-67_3-68.png)

初期表示
![](upload/bind_dynamic初期表示.png)

幅を200で入力すると、画像幅も変更される
![](upload/bind_dynamic値変更.png)

この例であれば、属性名(attr) を選択ボックスに、高さや幅(size)をテキストボックスに紐付け ているので、それぞれの値に応じて、画像の変化を確認できます。ポイントとなるのはリスト 3-67 の 太字部分の動的引数だけで、バインドの構文はこれまでにも見てきたものです。


<div markdown="1" class="note-box">
##### 属性名の制約

動的引数を用いる場合、以下のような記述は不可です。
![](upload/Note属性名の制約.png)
<!--
```
<img v-bind: ['value' + num]="...." /> //-----(1)空白/クォートが混在 
<img v-bind: [attrName ]="..." /> //-----(2)大文字が混在
```
-->
(1)、(2)はいずれも HTML 属性のルールに反するからです((2)は内部的にすべて小文字の attrname に変換され、結果「attrname は見つからない」というエラーになります)。(1)であれば 算出プロパティで置き換えるべきですし、(2)はそもそも大文字交じりの命名を避けてください。
</div>


## 3-4-2 文字列を HTML として埋め込む - v-html

テンプレートの文字列埋め込みは、初歩的な(そして、典型的な)脆弱性の一因になる可能性があります。たとえば、ユーザーが入力した文字列をそのまま表示するアプリがあったとします。そのアプリに対して、ユーザーがスクリプトを混入させたら、アプリ上では任意のコードを実行できることになってしまいます。

![](upload/入力値をそのままページに反映した場合.png)

これは、<span class="red">クロスサイトスクリプティング(XSS)</span>と呼ばれる脆弱性の、ごく簡単化した例です。 しかし、Vue.jsでは、式によるテキスト埋め込みにも、セキュリティ的な考慮がなされています。たとえば、以下の例を見てみましょう。

<p class="tmp list"><span>リスト3-69 / 3-70</span></p>
http://localhost:7008/chap03/html.html
![](upload/リスト3-69_3-70.png)

html.htmlの表示部分のコードを3-69にあるように下記のようにすると
```
<div id="app">
  <p>{{ message }}</p>
</div>
```
文字列がそのまま表示されてしまいます。

<p class="result"><span>表示結果</span></p>
![](upload/htmk_html表示結果.png)

次のように、HTML文字列をHTMLとしてページに反映されるようコードを書き換えると
```
<div id="app">
  <p v-html="message"></p>
</div>
```

<p class="result"><span>表示結果</span></p>
![](upload/htmk_html表示結果2.png)

<span class="green bold">v-html ディレクティブ</span>で指定された式の値は、エスケープされずにそのまま要素配下に埋め込まれることが確認できます。  
{{...}} 構文や v-text ディレクティブが要素オブジェクトの textContent プロパティを設定するのに対して、<span class="green bold">v-html ディレクティブ</span>は 、innerHTML プロパティを設定する、と考えるとわかりやすいかもしれません。

<div markdown="1" class="note-box">
##### 信頼できるコンテンツにだけ利用する
ただし、本項冒頭でも触れたように、不特定多数の一特に、ユーザーまたは外部サービスからの一入力を v-html ディレクティブで埋め込むのは、脆弱性の原因となります。v-html ディ レクティブは、信頼できる(=適切なエスケープ処理がなされていることがわかっている)コンテンツに対してのみ利用してください。
</div>


<div markdown="1" class="note-box">
##### テンプレート文字列ES2015
```
`…`
```
は、ES2015 で導入された文字列リテラルで、複数行にまたがる(= 改行文字を含んだ) 文字列を表現できます。リスト 3-70 でも message プロパティで利用していますが、
```
message: `<h3>WINGSプロジェクト</h3>
      <img src="https://www.web-deli.com/image/linkbanner_l.gif" alt="ロゴ" />`  
```   

このような長い文字列を表現するのに重宝します。 ちなみに、以下はテンプレート文字列を利用しなかった場合の記述です。
```
message: '<h3>WINGSプロジェクト</h3>\n' +
"<img src="https://www.web-deli.com/image/linkbanner_1.gif" alt="ロゴ" />'
```
クォート、「+」演算子、「\n」と余計な文字が入る分、見通しが悪くなっています。本書では今後もよく登場しますし、記法そのものに迷う点はないので、是非覚えておきましょう。
</div>

### 3-4-3 値を一度だけバインドする -v-once

<span class="green bold">v-once ディレクティブ</span>を利用することで、配下のコンテンツを<span class="red">一度だけ</span>描画します。コンテンツが 初期値から変更されないことがわかっているならば、v-once を利用することで、ページの更新性能を最適化できます。

たとえば以下は、テキストボックスへの入力内容を v-once ありとなしの &lt;div&gt; 要素にそれぞれ反映させる例です。  
確かに v-once 付きの <div> 要素(1)は、初期値から変化しないことが確認できます。

<p class="tmp list"><span>リスト3-71 / 3-72</span></p>
http://localhost:7008/chap03/once.html
![](upload/リスト3-71_3-72.png)

このようにすると、テキストボックスを変更しても、片方しか反映されない。
```
<div v-once>はじめまして、{{ name }} さん。</div>
<div>はじめまして、{{ name }} さん。</div>
```
↓
<p class="result"><span>結果</span></p>
![](upload/once表示結果1.png)


<div markdown="1" class="note-box">
特定の値が変更された時にだけバインドする 3.2 特定の値が変更された時にだけバインド処理を実行する v-memo ディレクティブもあります。 V-memo ディレクティブには、監視すべきプロパティを配列として列挙します。 たとえば以下は、name / age が変更された場合にのみ再描画します。
![](upload/v-memo_name_age.png)
</div>

ただし、一般的には v-memo を用いた最適化を施すことは稀です(監視すべき値を誤れば、そもそも意図した更新が為されず、潜在的なバグの原因となることすらあります)。利用するのは、 (たとえば)1000 件を超える巨大な表/リストで再描画を限定したいなど、ごく限られた状況 にすべきです。


## 3-4-4 要素にスタイルプロパティを設定する - v-bind:style 

v-bind:style ディレクティブを利用することで、インラインスタイルを設定できます。Vue.js でスタイルを設定する、最もシンプルな手段です。


<div markdown="1" class="note-box">
##### v-bind:styleの意味
説明の便宜上、独立したディレクティブのように呼んでいますが、v-bind:style とは v-bind ディレクティブで style 属性を設定しなさい、という意味です。ただし、その設定値は、他の属性 を設定する場合と異なるので、本書でも別物として解説しています。 style 属性へのバインドを、Vue.js では<span class="green bold">スタイルバインディング</span>と呼んでいます。
</div>

以下は、v-bind:style ディレクティブの具体的な例です。

<p class="tmp list"><span>リスト3-73 / 3-74</span></p>
http://localhost:7008/chap03/style.html
![](upload/リスト3-73_3-74.png)

※v-bindは省略表記できるので、単に「:style」としても同じ意味になります。

<p class="result"><span>表示結果</span></p>
![](upload/style_html表示結果.png)

スタイル情報は「スタイルプロパティ名:値 ,...」形式のオブジェクトとして指定します。ハイフン区切りのスタイルプロパティ名は、サンプルのようにキャメルケース記法で表記してください(ここ では background-color を backgroundColor としています)。


<div markdown="1" class="note-box">
ハイフン区切りのスタイルプロパティ名
 以下のように名前の前後をクォートで括れば、ハイフン区切りのままで記述することも可能です。
```
<div v-bind: style="{ background-color': 'Aqua', 'font-size': '1.5em'}">
```
</div>


### 複数のスタイル情報を適用する
v-bind:style ディレクティブには、配列形式で複数のオブジェクトを渡すこともできます。この場合、 オブジェクト(スタイル情報)は内部的に結合された状態で、要素に適用されます。オブジェクト間で 重複したスタイルプロパティは、後者が優先されます。

<p class="tmp list"><span>リスト3-75 / 3-76</span></p>
http://localhost:7008/chap03/style_multi.html
![](upload/リスト3-75_3-76.png)
![](upload/リスト3-75_3-76_HTML.png)

<p class="result"><span>表示結果</span></p>
![](upload/style_multi結果.png)

### ベンダープレフィックスを自動補完する
v-bind:style ディレクティブでは、ブラウザーの対応状況に応じてベンダープレフィックスを補完する機能を備えています。ベンダープレフィックスは、往々にしてスタイル指定を冗長にしますが、この機能を利用することでスタイル指定がシンプルになります。

<p class="tmp list"><span>リスト3-77 / 3-78</span></p>
http://localhost:7008/chap03/style_prefix.html

<p class="result"><span>表示結果</span></p>
![](upload/style_prefix.png)

ベンダープレフィックスが付いている
![](upload/style_prefixコード.png)


## 3-4-5 要素にスタイルクラスを設定する - v-bind:class

v-bind:style によるスタイルの操作は手軽で便利ですが、問題もあります。というのも、JavaScript コード(もしくはテンプレート)の中にスタイル情報が混在してしまうのです。スタイルを修正するために、スタイルとコードの双方を見なければならないのは、望ましい状態ではありません。

![](upload/v-bind_stylleの問題点.png)

そこで、基本的には v-bind:style はあくまで手軽なスタイル操作の手段と割り切り、本格的なアプリでは v-bind:class ディレクティブ※1 を利用すべきです。v-bind:class は、あらかじめ用意されたスタイルクラスを要素に割り当てるためのディレクティブです。 たとえば以下は、&lt;div&gt; 要素に対して small、color、frame クラスを割り当てる例です。

※1 v-bindは省略表記できるので、単に[:class]としても同じ意味です。

<p class="tmp list"><span>リスト3-79 / 3-80</span></p>
http://localhost:7008/chap03/class.html

```
<div class="small" v-bind:class="{ color, frame: isChange }">
    皆さん、こんにちは！
</div>
```
↓
HTML生成
![](upload/class_html.png)

<p class="result"><span>表示結果</span></p>
![](upload/class_html_表示.png)

v-bind:class ディレクティブは「クラス名:true または false, ...」形式のオブジェクトを受け取ります。これで、値が true であるクラスだけを有効にする、というわけです。  
v-bind:class は、静的な class 属性と併存できる点にも注目してください。今回のサンプルであれば、 class 属性 (small) と v-bind:class (color および frame) の結果がマージされた結果が描画されます。


<div markdown="1" class="note-box">
##### オブジェクトの省略構文 ES2015 
リスト 3-79 の太字の{ color, ... } は、{ color: color, ... }と表しても同じ意味です。 この記法は ES2015 で導入された構文で、オブジェクトリテラルではプロパティの名前と値と が等しい場合に、値を省略できます。
</div>

v-bind:class のさまざまな記法
v-bind:class ディレクティブには、ハッシュ形式で指定する他、以下のような設定方法があります。

<span class="bold">(1) 文字列配列として渡すスタイルクラス名を文字列の配列として渡すこともできます。</span>

<p class="tmp list"><span>リスト3-81 / 3-82</span></p>
http://localhost:7008/chap03/class_str.html

![](upload/リスト3-81_3-82_HTML.png)

↓ HTML生成
![](upload/class_str_HTML.png)

<p class="result"><span>表示結果</span></p>
![](upload/class_str表示.png)



<span class="bold">(2) 文字列またはオブジェクトの配列として渡す</span>
配列に「クラス名:true または false」形式のオブジェクトを混在させることもできます。  
スタイル リストの一部が条件によってオン/オフ変動する場合に利用できます。

<p class="tmp list"><span>リスト3-83 / 3-84</span></p>
http://localhost:7008/chap03/class_multi.html

![](upload/リスト3-83_3-84_HTML.png)

↓ HTML生成
![](upload/class_multi_HTML1.png)
<p class="result"><span>表示結果</span></p>
![](upload/class_multi表示.png)

isChange: <span class="red">false</span> にすると　frameクラスが付かない
![](upload/class_multi_HTML2.png)


## 3-4-6 {{...}} 構文による画面のチラツキを防ぐ - v-cloak

{{...}} 構文では、要素配下のテキストとして、バインド式を指定するという性質上、ページを起動した最初のタイミングで、一瞬だけ生の構文<span class="red">({{ ...}})</span>が表示されてしまうという問題があります。 これは、Vue.js が初期化処理を終えて、{{...}} を処理するまでのごくわずかなタイムラグによって生じる不具合です。たいていは本当にごく一瞬ですが、生のコードがエンドユーザーの目に触れるのは望ましい状態ではありません。
そこで利用するのが、<span class="green bold">v-cloak ディレクティブ</span>です。

<p class="tmp list"><span>リスト3-85 / 3-86</span></p>
http://localhost:7008/chap03/cloak.html

![](upload/リスト3-85_3-86_HTML.png)
↓ HTML生成
![](upload/リスト3-85_3-86_HTML1.png)

<p class="result"><span>表示結果</span></p>
![](upload/リスト3-85_3-86_表示.png)

v-cloak を利用する場合、まず、cloak.css のようなスタイルシートで v-cloak 属性付きの要素を非表示にします(1)。
Vue.js は、初期化のタイミングで v-cloak 属性(ディレクティブ)を見つけると、これを破棄します。 これによって、初期化前には非表示だった要素が、初期化を終えたタイミングで初めて、表示状態になるというわけです。これによって、初期化前に {{...}} 構文を含んだ要素がそのまま表示されてしまうのを防ぐことができます※4。


※4 別解として、v-text を利用しても構いません。v-text は属性なので、初期化前の式が露出することはありません。
