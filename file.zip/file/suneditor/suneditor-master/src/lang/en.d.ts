import { Lang } from './Lang';

declare const en: Lang;

export default en;