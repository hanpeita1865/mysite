Vue.createApp({
  data() {
    return {
      color: {
        backgroundColor: 'Aqua',
        color: 'Red'
      },
      size: {
        fontSize: '1.5em'
      }
    };
  }
}).mount('#app');