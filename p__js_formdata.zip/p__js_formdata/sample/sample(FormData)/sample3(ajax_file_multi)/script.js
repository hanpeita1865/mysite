
$(function(){
  var csv1,csv2;
  var path1 = "common/category.json";
  var path2 = "common/report.json";

  var d = $.Deferred();
	
  $.when(
    $.ajax({url:path1}).done(function(data){
		dataCate = data;
		d.resolve();
	}),
    $.ajax({url:path2}).done(function(data){
		dataRepo = data;
		d.resolve();
	})).done(function(data){
	  
      console.log(dataCate);
      console.log(dataRepo);

    });
});