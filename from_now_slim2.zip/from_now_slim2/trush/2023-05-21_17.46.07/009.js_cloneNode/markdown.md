*[page-title]:要素をコピー　cloneNode()

参考サイト
: [HTML要素を複製（コピー）する](https://gray-code.com/javascript/duplicate-html-element/)

特定のHTML要素を複製のポイント
: ・cloneNodeメソッドはtrueを渡すと子孫要素を含めて複製できる
: ・cloneNodeメソッドにfalseを渡すと子孫要素は含まずに複製できる
: ・複製したHTML要素は属性もそのまま複製されるため、id属性などの重複に注意する

<div class="exp">
<p class="tmp"><span>例</span></p>
<iframe width="100%" height="500" src="//jsfiddle.net/hirao/uxh9Lz57/4/embedded/js,html,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>