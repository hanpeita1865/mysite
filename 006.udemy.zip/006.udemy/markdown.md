*[page-title]:Udemy

### 目次

<div markdown="1" class="page-mokuji auto-mokuji"></div>


## よさそうな講座

### PHP

* [ちゃんと学ぶ、PHP 7/8入門講座](https://nttdatajp.udemy.com/course/php-master/)
* [【PHP中級】基礎だけ学ぶ PHPプログラミング講座Ⅱ データベースプログラミング編](https://nttdatajp.udemy.com/course/code-php-db/)
* [基礎だけ学ぶ PHPプログラミング講座](https://nttdatajp.udemy.com/course/code-php/)
* [【しっかり身につける】PHP基礎の学習後に見てほしいLaravel入門(Laravel12対応)](https://nttdatajp.udemy.com/course/laravel9/)
* [【Laravel】マルチログイン機能を構築し本格的なECサイトをつくってみよう【Breeze/tailwindcss】](https://nttdatajp.udemy.com/course/laravel-multi-ec/)
* [【Laravel11&12対応】クイズアプリを作りながら自力でアプリ開発する力を身につけよう【要件定義・設計〜実装まで】](https://nttdatajp.udemy.com/course/laravel_quiz_app/)


### Python

* [ちゃんと学ぶ、Python](https://nttdatajp.udemy.com/course/chanto-python/)

### その他

* [正規表現入門　作業効率アップに役立つ38個の方法](https://nttdatajp.udemy.com/course/38-bgtqc/)
* [映画1本分の学習時間で分かる！書ける！ 分析担当者のための正規表現入門](https://nttdatajp.udemy.com/course/regexp_with_drill/)