*[page-title]:VSCODE問題

<span class="bold green fz-12">問題１</span>　先頭行、最終行にカーソルを移動するキーの組み合わせをそれぞれ答えてください。
<div markdown="1" class="problem ml-5">
<label>先頭行
<input type="text" value="" autocomplete="off"></input>
</label>
<label>最終行
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<span class="bold green fz-12">問題2</span>　対の括弧にカーソルを移動するキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5">
<label>
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<span class="bold green fz-12">問題3</span>　カーソルがある行のコードを上や下の行に移動するキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5">
<label>上の行に移動と下の行に移動
<input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題4</span>　単語の先頭に移動するキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5">
<label>
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<span class="bold green fz-12">問題5</span>　空行を挿入するキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5 d-flex flex-column">
<label>カーソルがある行の下に空行を挿入します。
<input type="text" value="" autocomplete="off"></input>
</label>
<label>カーソルがある行の上に空行を挿入します。
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<span class="bold green fz-12">問題6</span>　カーソルがある行や選択した複数行を上や下にコピペするキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5 d-flex flex-column">
<label>上にコピペ
<input type="text" value="" autocomplete="off"></input>
</label>
<label>下にコピペ
<input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題7</span>　同じ単語やコードを一括して修正や削除するキーの組み合わせを答えてください。（マルチカーソル）
<div markdown="1" class="problem ml-5">
<label>
<input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題8</span>　単語やコードを一つずつ選択し一括して修正や削除を行うキーの組み合わせを答えてください。（マルチカーソル）
<div markdown="1" class="problem ml-5">
<label>
<input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題9</span>　カーソルがある行を丸ごと削除を行うキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5">
<label>
<input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題10</span>　カーソルがある位置の左側や右側の単語や記号を削除するキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5 d-flex flex-column">
<label>左側の単語や記号を削除
<input type="text" value="" autocomplete="off"></input>
</label>
<label>右側の単語や記号を削除
<input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題11</span>　行全体を選択するキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5">
<label>
<input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題12</span>　アンカーを使用した範囲選択のキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5 d-flex flex-column">
<label>アンカー設定
<input type="text" value="" autocomplete="off"></input> を押して <input type="text" value="" autocomplete="off"></input>
</label>
<label>範囲選択
<input type="text" value="" autocomplete="off"></input> を押して <input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題13</span>　HTMLコードで要素全体や要素の中のコードを選択するのにコマンドパレットに入力する文字を記入してください。
<div markdown="1" class="problem ml-5 d-flex flex-column">
<label>要素全体を選択
<input type="text" value="" autocomplete="off"></input> または <input type="text" value="" autocomplete="off"></input>
</label>
<label>要素の中を選択
<input type="text" value="" autocomplete="off"></input> または <input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題14</span>　単語や属性、親要素などを元にキーを押すごとに少しずつ選択範囲が拡大したり縮小したりさせるキーの組み合わせを記入してください。
<div markdown="1" class="problem ml-5 d-flex flex-column">
<label>選択範囲を拡大
<input type="text" value="" autocomplete="off"></input> または <input type="text" value="" autocomplete="off"></input>
</label>
<label>選択範囲を縮小
<input type="text" value="" autocomplete="off"></input> または <input type="text" value="" autocomplete="off"></input>
</label>
</div>


<span class="bold green fz-12">問題15</span>　差分ビューで変更した箇所を確認するキーの組み合わせを答えてください。
<div markdown="1" class="problem ml-5">
<label>
<input type="text" value="" autocomplete="off"></input> を押して <input type="text" value="" autocomplete="off"></input>
</label>
</div>





<details><summary>解答</summary>
	問題1 Ctrl+Home、Ctrl+End　問題2 Ctrl+Shift+¥　問題3 Alt+↑、Alt+↓　問題4 Ctrl+↓、Ctrl+↑　問題5 Ctrl+Enter、Ctrl+Shift+Enter　<br>
	問題6 Shift+Alt+↓、Shift+Alt+↑　問題7 Ctrl+Shift+L　問題8 Ctrl+D　問題9 Ctrl+Shift+K　問題10 Ctrl+BackSpace、Ctrl+Delete　<br>
	問題11 Ctrl+L　問題12 Ctrl+K を押して Ctrl+B、Ctrl+K を押して Ctrl+K　問題13 「バランス外」または「blanceout」、「バランス内」または「balancein」<br>
	問題14 Shift+Alt+←、Shift+Alt+→　問題15 Ctrl+K を押して D
</details>