<?php
namespace SocymSlim\SlimMiddle\Services;
use SocymSlim\SlimMiddle\Config\AppConfig;
use SocymSlim\SlimMiddle\Factory\ParsedownFactory;
use SocymSlim\SlimMiddle\Services\Markdown\HtmlSanitizer;
use SocymSlim\SlimMiddle\Services\Markdown\HtmlPathRewriter;


class ShortcutService {
    private AppConfig $config;
    private ParsedownFactory $parserFactory;
    private HtmlSanitizer $sanitizer;
    private HtmlPathRewriter $pathRewriter;
    
    public function __construct(AppConfig $config, ParsedownFactory $parserFactory, HtmlSanitizer $sanitizer, HtmlPathRewriter $pathRewriter) {
        $this->config = $config;
        $this->parserFactory = $parserFactory;
        $this->sanitizer     = $sanitizer;
        $this->pathRewriter  = $pathRewriter;
    }

        
    public function getList( $folderPath, string $type = 'windows') {

        $rootPath = $this->config->rootPath;

        $fileMap = [
            'windows' => 'win-shortcuts.json',
            'vscode' => 'vscode-shortcuts.json',
            'browser' => 'browser-shortcuts.json',
            'excel' => 'excel-shortcuts.json',
        ];
        
        
        $shortcuts = [];

        //--------------------------------
        // 共通ショートカットを読み込む
        //--------------------------------
        if ($type !== 'windows') {

            $commonPath = $rootPath . $folderPath . '/json/common-shortcuts.json';

            if (file_exists($commonPath)) {
                $common = json_decode(file_get_contents($commonPath), true) ?? [];
                $shortcuts = array_merge($shortcuts, $common);
            }
        }



        $fileName = $fileMap[$type] ?? 'win-shortcuts.json';
        $path = $rootPath . $folderPath . '/json/' . $fileName;

        
        // 各画面のショートカットを読み込む
        $fileName = $fileMap[$type] ?? 'win-shortcuts.json';
        $path = $rootPath . $folderPath . '/json/' . $fileName;

        if (file_exists($path)) {
            $data = json_decode(file_get_contents($path), true) ?? [];
            $shortcuts = array_merge($shortcuts, $data);
        }

        
        // カテゴリー毎にまとめる
        $grouped = [];

        foreach($shortcuts as $shortcut){

            $category = $shortcut['category'];

            if(!isset($grouped[$category])){
                $grouped[$category] = [];
            }

            $grouped[$category][] = $shortcut;
        }

        // カテゴリー順に並び替え
        $order = $this->categoryOrder[$type] ?? [];

        $sorted = [];

        foreach ($order as $category) {
            if (isset($grouped[$category])) {
                $sorted[$category] = $grouped[$category];
                unset($grouped[$category]);
            }
        }

        // 順番指定されていないカテゴリを最後に追加
        foreach ($grouped as $category => $items) {
            $sorted[$category] = $items;
        }

        return $sorted;
    }


    //--------------------------------
    // 詳細マークダウン変換
    //--------------------------------

    public function getShortcutDetail($id, $folderPath) {
        
        $rootPath = $this->config->rootPath;
        
        $path = $rootPath . $folderPath . '/detail/' . $id . '.md';

        // ファイル存在チェック
        if (!file_exists($path)) {
            return '<p>詳細情報がありません。</p>';
        }

        // Markdown取得
        $md = file_get_contents($path);

        // Markdownパーサー作成
        $parser = $this->parserFactory->create();

        // HTML変換
        $htmlData = $parser->text($md);
        
        //スクリプトタグなど除去
        $htmlData = $this->sanitizer->sanitize($htmlData);
        //src、hrefのパスを生成
        $htmlData = $this->pathRewriter->rewrite($htmlData, $folderPath);

        return $htmlData;
    }


    //カテゴリーの並び順
    private array $categoryOrder = [
        'browser' => [
            '基本操作（共通）',
            'タブ操作',
            'ページ操作',
            'ブックマーク',
            'スクロール',
            'ズーム',
            '履歴・ダウンロード',
            'ウィンドウ',
            'メニュー操作',
            '開発者ツール',
        ],
        'windows' => [
            '基本操作',
            'ウィンドウ操作',
            'ファイル・エクスプローラー操作',
            'テキスト入力・編集',
            'スクリーンショット',
            '便利機能',
        ],
        'vscode' => [
            '基本操作（共通）',
            '一般',
            '基本編集',
            '移動・検索',
            'マルチカーソル・選択',
            '高機能編集',
            'ファイル管理',
            '表示',
            'スクロール',
            'デバッグ',
        ],
        'excel' => [
            '基本操作（共通）',
            '入力・編集',
            '移動・選択',
            'セル・行・列操作',
            'シート操作',
            'リボン操作',
        ],
    ];    

}