<?php
namespace greet; // 名前空間を定義
function hello() {
        return 'こんにちは';
}
