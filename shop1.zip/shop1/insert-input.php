<?php
// セッションの開始
session_start();

// ワンタイムトークンの生成
$toke_byte = random_bytes(16);
$token = bin2hex($toke_byte);

// トークンをセッションに保存
$_SESSION['token'] = $token;

//フラッシュメッセージ
if (isset($_SESSION['flash'])) {
    $flash_messages = $_SESSION['flash']['message'];
}
unset($_SESSION['flash']);

if (isset($flash_messages)) {
    echo '<ul class="feedback">';
    foreach ((array)$flash_messages as $message) {
        echo '<li>'. $message .'</li>';
    }
    echo '</ul>';
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新規追加</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>    
    <p><a href="index.php">一覧に戻る</a></p>
    <form class="form-box" action="insert-output.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="token" value="<?= $token; ?>">
        <label for="name">商品名</label>
        <input id="name" type="text" name="name" value="<?php if (isset($_SESSION['name'])) {echo $_SESSION['name'];} ?>">
        <label for="local">生産地</label>
        <input id="local" type="text" name="local" value="<?php if (isset($_SESSION['local'])) {echo $_SESSION['local'];} ?>">
        <label for="price">価格</label>
        <input id="local" type="text" name="price" value="<?php if (isset($_SESSION['price'])) {echo $_SESSION['price'];} ?>">
        <input type="file" name="image">
        <input id="image-base64" type="hidden" name="image-base64" value="<?php if (isset($_SESSION['image'])) {echo $_SESSION['image']['data'];} ?>"><!--追加-->
        <input id="image-name" type="hidden" name="image-name" value="<?php if (isset($_SESSION['image'])) {echo $_SESSION['image']['name'];} ?>"><!--追加-->
        <div id="image-preview"><img class="thumb" src=""></div><!--追加-->
        <input type="submit" value="新規追加">
    </form>
    <script src="js/admin.js"></script>
    <script src="js/script.js"></script>
</body>
</html>
<?php require 'delete-session.php'; ?>