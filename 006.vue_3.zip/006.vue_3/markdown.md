*[page-title]:Vue.js3 実践入門

参考書サイト
: https://www.sbcr.jp/product/4815613365/
サポート情報→正誤情報、ダウロードをクリック

ダウンロードページ
: https://wings.msn.to/index.php/-/A-03/978-4-8156-1336-5/

参考書サンプル
: C:\xampp\htdocs\from_now\trunk\pages\p__vue_3\sample\vue-app

サンプルバックアップ用
: C:\xampp\htdocs\template_sample\★veu.js\ダウンロードVue.js3実践入門

スタイルガイド
: https://v3.ja.vuejs.org/style-guide/

Vue.js 公式サイト　ドキュメント
: https://v3.ja.vuejs.org/guide/introduction.html#vue-js-%E3%81%A8%E3%81%AF

Vue SFC Playground
: [オンラインで .vue ファイルをリアルタイムに実行するサイト](https://sfc.vuejs.org/#eNp9j81OwzAQhF9l8SUgNbG4RmklbrwBl72UZNOmin+064RD5HdnnSKEQOLmmdn5NN7MS4zNupBpTSc9TzGBUFriCf3kYuAEGzCNkGHk4KDS0wo9+j54SeDkAseSP1avNM8B3gLPw0P1hL6zd5yCVCRycT4nUgXQXZ9P27aXc+6sqt2dfFwSrLULA81HNJqj0aiz321zMPdVtTvH5ibB6+6ttPErEDQt7E7xdG3RaK4pRWmtlbEvv71JE/hi9dXw4tPkqCFx9TuHDyFWMJrDD4ZVcyWumfxATPwf89fpH27BZvTZ5E89TIOC)