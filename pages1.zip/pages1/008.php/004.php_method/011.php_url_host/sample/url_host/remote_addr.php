<?php
//ipアドレスを取得
echo $_SERVER['REMOTE_ADDR'];
?>