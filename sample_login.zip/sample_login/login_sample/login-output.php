<?php session_start(); ?>
<!-- <?php require 'menu.php'; ?> -->
<p><a href="./">トップ画面</a></p>
<?php
// unset($_SESSION['customer']);
$pdo = new PDO( 'sqlite:../database/shop.db' );//SQLite用
//$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 'staff', 'password');//MySQL用
//hirao ryouma1222でログイン
$sql=$pdo->prepare('select * from customer where login=? and password=?');

//パスワードハッシュ化
//$loginPass = hash("sha256", $_REQUEST['password']); ハッシュ化は一旦とりやめ

$loginPass = $_REQUEST['password'];

$sql->execute([$_REQUEST['login'], $loginPass]);
foreach ($sql->fetchAll() as $row) {
	$_SESSION['customer']=[
		'id'=>$row['id'], 'name'=>$row['name'], 
		'address'=>$row['address'], 'login'=>$row['login'], 
		'password'=>$row['password']];
}
if (isset($_SESSION['customer'])) {
	echo 'いらっしゃいませ、', $_SESSION['customer']['name'], 'さん。';
} else {
	echo 'ログイン名またはパスワードが違います。';
}
?>

