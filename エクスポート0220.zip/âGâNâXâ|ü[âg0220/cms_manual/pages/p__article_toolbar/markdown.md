*[page-title]:ツールバー説明

![](upload/ツールバーまとめ.png "図　ツールバー一覧")


| アイコン | 名称 | 機能 |
| -------- | -------- | -------- |
| Text     | Undo      | 操作の取り消し     |
| Text     | Redo      | 操作のやり直し（Undoした内容を元に戻す）     |
| Text     | Headind      | 見出しを選択する     |
| Text     | Bold      | 太字にする     |
| Text     | Strikethrouth      | 打ち消し線をつける  |
| Text     | Subscript      | 下付き文字をつける    |
| Text     | Superscript      | 上付き文字をつける    |
| Text     | Font Size     | 文字サイズを変更する     |
| Text     | Font Color      | 文字の色を設定する     |
| Text     | Font Background Color     | 文字の背景色を設定する     |
| Text     | Highlight      | 文字にマーカーを設定する。    |
| Text     | Text alignment     | 文字の横配置位置を設定する     |
| Text     | Bulleted List    | 箇条書きリスト（&lt;ul&gt;タグ）を追加する    |
| Text     | Numbered List    | 番号付きリスト（&lt;ol&gt;タグ）を追加する   |
| Text     | Decrease Indent     | インデントを削除する     |
| Text     | Increase Indent      | インデントを設定する     |
| Text     | Find and replace      | 検索と置換を実行する    |
| Text     | Select all      | 入力値を全て選択する    |
| Text     | Link      | リンクを挿入する     |
| Text     | Block quate     | Block quateを設置します    |
| Text     | Insert table      | テーブルを挿入します    |
| Text     | insert madia      | 動画を挿入します     |
| Text     | Horizonral line    | 水平線を追加します     |
| Text     | Source      | HTMLコードを表示します    |

