$(function() {
    /* 都道府県が選択された時 */
    $('#prefecture').change(function() {
      var area = $(this).val();
  
      /* 市区町村一覧クリア */
      $("#municipality").html('');
  
      /* 市区町村一覧APIに非同期通信 */
      $.ajax({
        type: 'GET',
        dataType: 'json',
        cache: false,
        url: "https://www.land.mlit.go.jp/webland/api/CitySearch?area=" + area
      }).done(function(data) {  /* 非同期通信成功時 */
        var buf = [];
  
        /* 取得した市区町村データを1件1件連結 */
        data.data.forEach( function( value ) {
          buf.push(value.name + '<br />');
        });
  
        /* 市区町村一覧出力 */
        $("#municipality").html(buf.join(""));
      });
    });
  });