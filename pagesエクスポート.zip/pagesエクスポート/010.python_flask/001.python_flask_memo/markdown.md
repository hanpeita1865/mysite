*[page-title]:Flask メモ


## render_template

作業環境
: C:\xampp\htdocs\test\python\flask\sample2

「render_template」を使います。ページのテンプレートは、templatesの中に入れます。

<p class="tmp list"><span>リスト</span>app.py</p>
<pre><code class="hljs python"><span class="hljs-keyword">from</span> flask <span class="hljs-keyword">import</span> Flask, <span class="marker-yellow">render_template</span>

app = Flask(__name__)

<span class="hljs-meta">@app.route('/')</span>
<span class="hljs-function"><span class="hljs-keyword">def</span> <span class="hljs-title">home</span><span class="hljs-params">()</span>:</span>
    <span class="hljs-keyword">return</span> <span class="marker-yellow">render_template</span>(<span class="hljs-string">'index.html'</span>)

<span class="hljs-keyword">if</span> __name__ == <span class="hljs-string">'__main__'</span>:
    app.run(debug=<span class="hljs-literal">True</span>)</code></pre>

<p class="tmp list"><span>リスト</span>templates/index.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><h1>Hello World!</h1></h1>
</body>
</html>
```

app.pyを実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
PS C:\xampp\htdocs\test\python\flask\sample2> python app.py
```

<http://127.0.0.1:5000/>にアクセスして、次のように表示されればOKです。

![](upload/sample2_HelloWorld表示.png){.photo-border}


## Pythonからデータを受け取る

作業環境
: C:\xampp\htdocs\test\python\flask\sample4

<p class="tmp list"><span>リスト</span>app.py</p>
```
from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_data', methods=['POST'])
def get_data():
    data_from_python = {'message': 'Hello from Python!'}
    return jsonify(data_from_python)

if __name__ == '__main__':
    app.run(debug=True)
```

<p class="tmp list"><span>リスト</span>templates/index.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Hello!!</p>
    <!-- <script src="script.js"></script> -->
     <script>
     document.addEventListener('DOMContentLoaded', function() {
        // AJAXリクエストを送信してデータを取得
        fetch('/get_data', {
            method: 'POST',
        })
            .then(response => response.json())
            .then(data => {
                // 受け取ったデータを表示
                console.log('Data from Python:', data);
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
</script>
</body>
</html>
```

※script.jsだと読み込みエラーになるので、index.htmlに直接scriptを記入しました。

app.pyを実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
PS C:\xampp\htdocs\test\python\flask\sample4> python app.py
```

<http://127.0.0.1:5000/>にアクセスすると、app.pyから送信された「{'message': 'Hello from Python!'}」のデータがコンソールに表示されます。
![](upload/dataがコンソールに表示.png){.photo-border}


## JSのPostしたデータをPythonで受信

作業環境
: C:\xampp\htdocs\test\python\flask\sample5

FormData()を使って、データをセットしてapp.pyに送信します。
<p class="tmp list"><span>リスト</span>templates/index.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Hello!!</p>
     <script>
     document.addEventListener('DOMContentLoaded', function() {
        const data = new FormData();
        data.set('hoge', 'Good Morning!!');

        fetch('/get_data', {
            method: 'POST',
            body: data
        })
            .then(response => response.json())
            .then(data => {
                // 受け取ったデータを表示
                console.log('Data from Python:', data);
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
</script>
</body>
</html>
```

「request.form.get('hoge')」でPostで送信されたデータを受け取ります。

<p class="tmp list"><span>リスト</span>app.py</p>
<pre><code class="hljs ruby">from flask import Flask, render_template, jsonify, request

app = Flask(__name_<span class="hljs-number">_</span>)

@app.route(<span class="hljs-string">'/'</span>)
<span class="hljs-function"><span class="hljs-keyword">def</span> <span class="hljs-title">index</span><span class="hljs-params">()</span></span>:
    <span class="hljs-keyword">return</span> render_template(<span class="hljs-string">'index.html'</span>)

@app.route(<span class="hljs-string">'/get_data'</span>, methods=[<span class="hljs-string">'POST'</span>])
<span class="hljs-function"><span class="hljs-keyword">def</span> <span class="hljs-title">get_data</span><span class="hljs-params">()</span></span>:
    <span class="marker-yellow">data1 = request.form.get(<span class="hljs-string">'hoge'</span>)</span>
    data_from_python = {<span class="hljs-string">'message'</span>: data1}
    <span class="hljs-keyword">return</span> jsonify(data_from_python)

<span class="hljs-keyword">if</span> __name_<span class="hljs-number">_</span> == <span class="hljs-string">'__main__'</span>:
    app.run(debug=True)</code></pre>


app.pyを実行して、<http://127.0.0.1:5000/>にアクセスします。

次のように、コンソールに「Good Morning!!」の値が返ってくればOKです。
![](upload/GoodMorningが返る.png){.photo-border}
