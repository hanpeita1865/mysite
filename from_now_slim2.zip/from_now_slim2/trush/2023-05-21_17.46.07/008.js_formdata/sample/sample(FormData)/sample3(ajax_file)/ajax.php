<?php
	//一時的保存にファイルがあるか確認
	//if (is_uploaded_file($_FILES['hoge']['tmp_name'])) {➡FormDataでファイルを送信した場合、下記の「!empty」方を使う。
	if (!empty($_FILES['hoge']['tmp_name'])) {
		
		//保存用のフォルダがなければ作成する
		if(!file_exists('upload')){
			mkdir('upload');
		}
		
		//保存先のファイルのパスを変数に取得。
		$file='upload/'.basename($_FILES['hoge']['name']);
		
		//フォルダにファイルを一時的保存から移動して格納
		move_uploaded_file($_FILES['hoge']['tmp_name'], $file);
	}
?>