import { Lang } from './Lang';

declare const ja: Lang;

export default ja;