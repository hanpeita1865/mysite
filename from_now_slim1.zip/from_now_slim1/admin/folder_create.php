<?php
    $newFolder = $_POST['post_newFolder'];
    $pagesGlob = glob('../pages/*');
    $num = sprintf('%02d', count($pagesGlob)+1);//番号を2桁に変更　例)01

    mkdir('../pages/'.$num.'.'.$newFolder);
    mkdir('../pages/'.$num.'.'.$newFolder.'/upload');
    file_put_contents( '../pages/'.$num.'.'.$newFolder.'/markdown.md', '*[page-title]:メニュー名');

    echo 'フォルダを新規作成しました。';
?>