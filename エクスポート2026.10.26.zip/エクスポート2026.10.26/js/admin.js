import { initModals, get, show, hide, exists } from './modules/modalManager.js';
import { Api } from './modules/api.js';
import { Dom } from './modules/dom.js';
import { Validation } from './modules/validation.js';

import { initFolderModal } from './modules/folder/modal.js';
import { createFolder } from './modules/folder/create.js';
import { renameFolder } from './modules/folder/rename.js';
import { initFolderDelete } from './modules/folder/delete.js';
import { initFolderLock } from './modules/folder/lock.js';
import { initPageRename } from './modules/folder/renamePage.js';
import { pagesDirGet, pagesSort } from './modules/sort/sortApi.js';
// import { initDragDrop } from './modules/dragDrop/dragDrop.js';
import { initDraft } from './modules/folder/draft.js';


document.addEventListener('DOMContentLoaded', () => {   
    // UI
    initModals();
    
    initFolderDelete({
        soating: () => soating,
        completeMsg,
        menu_create
    });
    
    initFolderLock({
        soating: () => soating,
        completeMsg
    });
    
    initPageRename({
        soating: () => soating,
        completeMsg,
        menu_create,
    });
        
    let soating = false;

    const modal = initFolderModal({
        soating: () => soating,
        openCreateModal,
        openRenameModal,
    });
    
    initDraft({
        soating: () => soating,
        completeMsg
    });
    

    // 新規フォルダ作成・フォルダ名変更の共通submit
    const folderModalSubmit = document.getElementById('folderModalSubmit');
    
    if(folderModalSubmit){
        
        folderModalSubmit.addEventListener('click', async () => {
    
            const input = document.getElementById('folderModalInput');
            const newName = input.value;
    
            const menu_obj = menu_create();
    
            const error = Validation.isValidFolderName(newName, menu_obj);
    
            if (error) {
                Dom.showMessage('#folderModalMsg', error);
                return;
            }
    
            try {
                let msg;
    
                if (modal.dataset.mode === 'create') {
    
                    msg = await createFolder(newName);
    
                } else if (modal.dataset.mode === 'rename') {
    
                    msg = await renameFolder({
                        newName,
                        oldName: modal.dataset.folderName,
                        menuId: modal.dataset.menuId,
                        menuObj: menu_obj
                    });
                }
    
                hide('folderModal');
                completeMsg(msg);
                
                location.reload();
    
            } catch (e) {
                alert(e.message);
            }
        });
    }
});

let currentFolderName = null;
let lastTriggerBtn = null;
const box_items = document.querySelectorAll('.box-item');
const elm_msgbox = document.getElementById('sort-msgbox');
let subMenu = document.querySelectorAll('.sub-menu');
let arrayStart = []; //デフォルトの並び順初期値
let menuJson = []; //メニューJson
let menuStr; //メニュー文字列
let soating = false; //並べ替え中か判定


let modalMode = null; // create or rename



//完了成功モーダル
const successMsg = document.getElementById('successModal');

//ロック設定用モーダル
const fdLockElm = document.getElementById('lockModal');


//並び順初期値格納
box_items.forEach(function (value) {
    arrayStart.push(value.getAttribute('id'));
});

const role = document.body.dataset.role;
const isAdmin = role === 'admin';

box_items.forEach((elm) => {
    //ボックスをダブルクリックして空のボックスを作成
    elm.addEventListener('dblclick', function (e) {
        let subLen = this.children.length;

        if (isAdmin) {
            
            if (elm == e.target) {
                if (subLen == 2) {
                    this.insertAdjacentHTML(
                        'beforeend',
                        '<ul class="emp-ul sub-menu"></ul>\n'
                    );
                    let obj = this.lastChild; //サブメニューul要素
                } else {
                    //サブメニュー開閉
                    this.closest('.box-item').classList.toggle('s-close');
                }
            }
        }   
    });


    
    if (isAdmin) {
        elm.setAttribute('draggable', 'true');
        sortDrop(elm);
    } else {
        elm.removeAttribute('draggable');
    }
    
    
    if (elm.children.length > 2) {
        elm.querySelector('a').insertAdjacentHTML(
            'beforeend',
            '<span class="icon-slide"></span>'
        );
    }
});

let dirObj = [];

//ボックス並べ替え
function sortDrop(elm) {
    elm.ondragstart = function (e) {
        e.dataTransfer.setData('text/plain', e.target.id);
    };

    let empBox = 1;
    
    //追加
    const pageArea = document.getElementById('app').dataset.pageArea;
    const pageDir = pageArea === 'normal' ? '../pages' : '../' + pageArea + '/pages';
    const pageUrl = pageDir.replace('..', '/public') + '/';
    // const pageDir = pageArea === 'manual' ? '../manual/pages' : '../pages';

    //ドラッグオーバー
    elm.ondragover = function (e) {
        e.preventDefault();

        if (elm == e.target.parentNode || elm == e.target) {
            if (e.target.classList.contains('emp-ul')) {
                e.stopPropagation(); //イベントを停止する
                e.preventDefault(); //画面遷移を行わない
                e.target.style.border = '4px solid green';
                empBox = e.target;
            } else if (e.target.closest('li').classList.contains('box-item')) {
                let rect = e.target.closest('li').getBoundingClientRect();
                let elm_over = this;

                rectOver(e, rect, elm_over); //ボーダー表示
            } else {
                let rect = e.target.getBoundingClientRect();
                let elm_over = e.target;

                rectOver(e, rect, elm_over); //ボーダー表示
            }
        }
    };

    //ドラッグリープ（ボックスから離れる）
    elm.ondragleave = function (e) {
        if (empBox != 1) {
            empBox.removeAttribute('style');
        }

        this.style.borderTop = '';
        this.style.borderBottom = '';
    };


    //ドロップ
    elm.ondrop = async function (e) {
        e.preventDefault();

        if (elm == e.target.parentNode || elm == e.target) {
            //2階層以下の複数実行防止

            let id = e.dataTransfer.getData('text/plain');
            const elm_drag = document.getElementById(id);
            let pagesDir = [];

            try {
                
                if (e.target.classList.contains('emp-ul')) {
                    //空のボックスに挿入

                    let id = e.dataTransfer.getData('text/plain');
                    let dropItem = document.getElementById(id);

                    e.target.removeAttribute('style');
                    e.preventDefault();

                    try {
                        e.target.appendChild(dropItem);
                        e.target
                            .closest('.box-item')
                            .firstElementChild.insertAdjacentHTML(
                                'beforeend',
                                '<span class="icon-slide"></span>'
                            );

                        dropItem.parentNode.classList.remove('emp-ul');
                        subEmpDelete();
                    } catch (error) {
                        console.error(error);
                        
                        dropItem.parentNode.classList.remove('emp-ul');
                        subEmpDelete();
                    }
                } else if (this.classList.contains('box-item')) {
                    //並べ替え

                    let rect = this.getBoundingClientRect();

                    rectDrop(e, e.currentTarget, rect, elm_drag); //挿入位置が上側か下側かを判定
                    subEmpDelete(); //空になった挿入用ボックス削除
                }
                
                box_items.forEach(function (t) {
                    t.removeAttribute('style');
                });


                pagesDir = await pagesDirGet();
                
                if (elm_msgbox.children.length == 0) {

                    elm_msgbox.insertAdjacentHTML(
                        'afterbegin',
                        '<p class="sort-text">並べ替えをすべて済ませた後、<br>「並べ替え確定」ボタンを押してください</p>'
                    );
                    soating = true;

                    dirObj = []; //並び替えの履歴を空にする
                }

                let targetName;
                let targetAfHref, targetBfHref, parentHref;
                let afAry, afAry1, afAry2;
                let bfAry, bfAry1, bfAry2;
                let bfPath, afPath, fdNameAf, pathBase;

                targetBfHref = elm_drag.firstElementChild.getAttribute('href');

                targetName = targetBfHref.split('/').slice(-2)[0];
                bfAry = targetBfHref.split('/');
                
                bfAry.splice(0, pageArea === 'normal' ? 3 : 4);
                bfAry.pop();

                bfAry1 = [...bfAry];
                bfAry1.shift();

                bfAry2 = bfAry1.map((value) => {
                    const path = pagesDir[value];

                    if (!path) {
                        console.warn('pagesDirに存在しないキー:', value);
                        return '';
                    }

                    return path.split('/').slice(-1)[0];
                });

                bfPath = pageDir + '/' + bfAry2.join('/');

                //pages直下に移動するか判定
                if (elm_drag.parentNode.classList.contains('side-link')) {

                    const path = pagesDir[targetName];

                    if (!path) {
                        throw new Error(
                            `pagesDirに存在しないキー: ${targetName}`
                        );
                    }

                    fdNameAf = path.split('/').slice(-1)[0];
                    
                    afPath = pageDir + '/' + fdNameAf;
                    
                    pathBase = '/' + targetBfHref.split('/')[1];
                    
                    targetAfHref = pathBase + pageUrl + '/' + targetName;
                    
                } else {
                    parentHref = elm_drag.parentNode
                        .closest('.box-item')
                        .firstElementChild.getAttribute('href');

                    targetAfHref = parentHref + targetName;

                    afAry = targetAfHref.split('/');
                    // afAry.splice(0, 3);
                    //修正
                    // afAry.splice(0, pageArea === 'manual' ? 4 : 3);
                    afAry.splice(0, 3);
                    
                    afAry1 = afAry.slice(1);


                    afAry2 = afAry1.map((value) => {
                        // console.log(pagesDir)
                        const path = pagesDir[value];

                        if (!path) {
                            console.warn('pagesDirに存在しないキー:', value);
                            return '';
                        }

                        return path.split('/').slice(-1)[0];
                    });

                    // afPath = '../pages/' + afAry2.join('/');
                    afPath = pageDir + '/' + afAry2.join('/');
                }

                targetAfHref = targetAfHref + '/';
                                
                if (bfPath !== afPath) {
                        
                    const lastItem = dirObj[dirObj.length - 1];

                    // 直前の移動履歴が同じフォルダの場合
                    if (
                        lastItem &&
                        lastItem.fdName === targetName &&
                        lastItem.to === bfPath
                    ) {
                        // 最初の移動元はそのままにして、
                        // 最終的な移動先だけ更新
                        lastItem.to = afPath;

                    } else {
                        // 別のフォルダの移動、または連続移動ではない場合
                        dirObj.push({
                            fdName: targetName,
                            from: bfPath,
                            to: afPath
                        });
                    }
                }
                
                elm_drag.firstElementChild.setAttribute('href', targetAfHref); //メニューのhref値を変更
                        
            } catch (error) {
                
                //ボーダー削除
                box_items.forEach(function (e) {
                    e.removeAttribute('style');
                });

                subMenu.forEach(function (e) {
                    e.removeAttribute('style');
                });
                
                console.error(error);
                
            }
        }
    };
    
}



//完了メッセージ（セッションのメッセージの有りで表示） 追加
document.addEventListener('DOMContentLoaded', () => {
    if (typeof flashMessage !== 'undefined' && flashMessage) {
        completeMsg(flashMessage);
    }
});



//空になったsubメニューボックス削除
function subEmpDelete() {
    subMenu = document.querySelectorAll('.sub-menu');
    //空のボックスがある。
    subMenu.forEach(function (e) {
        if (e.children.length == 0 && !e.classList.contains('emp-ul')) {
            e.remove();
        }
    });

    //サブメニューない▲アイコン削除
    document.querySelectorAll('a span.icon-slide').forEach(function (e) {
        if (e.closest('.box-item').querySelector('.sub-menu') == null) {
            e.remove();
        }
    });
}

//マウスオーバーの上下ボーダー表示
function rectOver(e, rect, elm_over) {
    if (e.clientY - rect.top < elm_over.clientHeight / 2) {
        //マウスカーソルの位置が要素の半分より上
        elm_over.style.borderTop = '2px solid blue';
        elm_over.style.borderBottom = '';
    } else {
        //マウスカーソルの位置が要素の半分より下
        elm_over.style.borderTop = '';
        elm_over.style.borderBottom = '2px solid blue';
    }
}

//ドロップ上下判定
function rectDrop(e, t, rect, elm_drag) {
    if (e.clientY - rect.top < rect.height / 2) {
        //マウスカーソルの位置が要素の半分より上
        t.parentNode.insertBefore(elm_drag, t);
    } else {
        //マウスカーソルの位置が要素の半分より下
        t.parentNode.insertBefore(elm_drag, t.nextElementSibling);
    }
}

let event_name = '';

//オブジェクトのキーに存在チェック関数
function isKeyExists(obj, key) {
    return key in obj;
}

//並べ替え関数
function compareFunc(a, b) {
    return a - b;
}



//--------------------//
// 全サブメニュー開閉  //
//------------------//

const btn_close = document.querySelectorAll('.btn-sub-close');

btn_close.forEach((elm) => {
    elm.addEventListener('click', function (e) {
        if (e.target.classList.contains('open') == true) {
            // 閉じる
            btn_close.forEach((t) => {
                t.classList.remove('open');
                t.textContent = '全サブメニュー開く';
            });

            document.querySelectorAll('.sub-menu').forEach((e) => {
                e.closest('.box-item').classList.add('s-close');
            });
        } else {
            // 開く
            btn_close.forEach((t) => {
                t.classList.add('open');
                t.textContent = '全サブメニュー閉じる';
            });

            document.querySelectorAll('.sub-menu').forEach((e) => {
                e.closest('.box-item').classList.remove('s-close');
            });
        }
    });
});

//「▼」アイコンクリックでサブメニューを開閉
document.querySelectorAll('.icon-slide').forEach((elm) => {
    elm.addEventListener('click', function (e) {
        e.target.closest('.box-item').classList.toggle('s-close');
        e.stopPropagation();
        e.preventDefault();
    });
});

//メニューから配列を作成
function menu_create() {
    const menu = document.getElementById('menu');
    let clone_element = menu.cloneNode(true); //メニューをコピー
    let menuArray = [];
    let menuObj = {};

    //コピーメニューからボタン削除
    clone_element.querySelectorAll('button').forEach((e) => {
        e.remove();
    });

    // //コピーメニューから.link-name要素を削除
    clone_element.querySelectorAll('.link-name').forEach((e) => {
        e.remove();
    });

    //コピー要素から属性の削除
    clone_element.querySelectorAll('li').forEach((e) => {
        e.removeAttribute('id'); //id属性の削除
        e.removeAttribute('class'); //class属性の削除
        e.removeAttribute('draggable'); //draggable属性の削除
    });

    let listElm = '#menu > li';
    //コピー要素の頭に番号を付与
    while (clone_element.querySelectorAll(listElm).length != 0) {
        let listNum = 1;

        clone_element.querySelectorAll(listElm).forEach((e, i) => {
            
            let num = String(listNum).padStart(3, '0');

            const link = e.querySelector(':scope > a');

            let listName =
                num +
                '.' +
                link.getAttribute('href').split('/').slice(-2)[0];

            link.remove();


            
            e.insertAdjacentHTML('afterbegin', '<a>' + listName + '</a>'); //リスト名を挿入

            if (listNum == e.parentNode.children.length) {
                listNum = 1;
            } else {
                listNum++;
            }
        });

        listElm = listElm + '> ul > li';
    }

    const menu_list = clone_element.querySelectorAll('#menu li');

    //コピー要素のメニューフォルダ名を配列に格納
    menu_list.forEach((e) => {
        let listParent = e.parentNode;//ul      
        let menuId = listParent.getAttribute('id');
        let menuTxt = e.children[0].textContent; //例)01.base
        let linkName = menuTxt.split('.')[1]; //例)base

        
        while (menuId !== 'menu') {

            // ul の親 li を取得
            const parentLi = listParent.parentElement;

            // 親 li の直下 a を取得
            const parentLink = parentLi.querySelector(':scope > a');

            if (parentLink) {
                menuTxt =
                    parentLink.textContent +
                    '/' +
                    menuTxt;
            }

            // 一つ上へ
            listParent = parentLi.parentElement;
            menuId = listParent.getAttribute('id');
        }

        menuArray.push(menuTxt); //メニュー配列に追加
        menuObj[linkName] = menuTxt; //メニューオブジェクトに追加
    });

    menuJson = menuArray; //メニュー配列
    menuStr = JSON.stringify(menuJson); //文字列に変換
    
    return  menuObj; //メニューオブジェクト
}



const btnSabun = document.querySelector('#btn-execution-sabun');

if(btnSabun){
    btnSabun.addEventListener('click', () => {

        pagesSort({
            dirObj,
            getMenuStr: () => menuStr,
            menu_create,
            completeMsg,
            elm_msgbox,
            setSoating: (val) => { soating = val }
        });

    });
}


//完了メッセージ用モーダル　一定時間経過後消える処理
function modalFdHide() {
    return new Promise(function (resolve) {
        hide('soatWarn');
        resolve();
    });
}

async function completeMsg(msg) {
    await modalFdHide();
    document.querySelector('#successModal .success-msg').textContent = msg;
    show('successModal');

    //修正
    successMsg.addEventListener('shown.bs.modal', () => {
        setTimeout(function () {
            if (successMsg.contains(document.activeElement)) {
                document.activeElement.blur();
            }

            hide('successModal');
        }, 3000);
    }, { once: true });
}




if(fdLockElm){
    //モーダルが閉じられたら
    fdLockElm.addEventListener('hidden.bs.modal', () => {
        if (lastTriggerBtn) {
            lastTriggerBtn.focus();
        }
    });    
}


//新規フォルダ作成用
function openCreateModal() {
    modalMode = 'create';

    document.getElementById('folderModalLabel').textContent = '新規フォルダ作成';
    document.getElementById('folderModalDesc').textContent = '新規にフォルダ名を作成します';
    document.getElementById('folderModalSubmit').textContent = '新規登録';
    document.getElementById('folderModalInput').value = '';
}

//フォルダ名変更
function openRenameModal(folderName) {
    modalMode = 'rename';

    document.getElementById('folderModalLabel').textContent = 'フォルダ名変更';
    document.getElementById('folderModalDesc').textContent = 'フォルダ名を変更します';
    document.getElementById('folderModalSubmit').textContent = '変更';
    document.getElementById('folderModalInput').value = folderName;
}

