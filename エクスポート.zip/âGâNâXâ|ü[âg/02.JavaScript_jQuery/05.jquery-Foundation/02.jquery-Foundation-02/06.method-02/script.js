$(function(){
	//初期状態 ボタンにchangeクラスがない ⇒ NTTデータの画像
  
  $('button').on('click',function(){
	  var hrefAttr = $('a').attr('href');
	  var hrefProp = $('a').prop('href');
	  
	  var imgfAttr = $('img').attr('src');
	  var imgProp = $('img').prop('src');
	  
	  console.log(hrefAttr);
	  
	  $('#input0').val(hrefAttr);
	  $('#input1').val(hrefProp);
	  $('#input2').val(imgfAttr);
	  $('#input3').val(imgProp);
	  
  });
});