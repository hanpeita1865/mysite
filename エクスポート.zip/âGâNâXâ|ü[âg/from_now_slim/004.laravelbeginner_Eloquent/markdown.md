*[page-title]:Eloquentの基本

Laravelには、「<span class="green bold marker-yellow50">Eloquent</span>」という ORM (ObjectRerational Mapping)機能が用意されています。ORMを活用することで、<span class="marker-yellow30">PHPのオブジェクトを扱う感覚でデータベースを利用できます</span>。Eloquentの基本的な使い方をここでは解説します。

※ ORMとは、データベースのレコードをプログラミング言語のオブジェクトとして扱えるようにするための仕組みです。  


## ORMとは？

前章で、DBクラスを利用したデータベースアクセスについて説明をしました。 DB::selectなどを利用した場合は、SQLクエリ文を作らなければならず、ちょっと大変でしたが、クエリビルダを利用するとメソッドの呼び出しだけでほとんどのデータベース アクセスが行えます。これは非常に便利です。  

が、取り出したレコードは、それほど便利な形で得られるわけではありません。DBクラスを利用してレコードを取得すると、レコードの値を連想配列としてまとめたものが、 更に配列やコレクションとしてまとめられています。これはこれで、レコードの内容がわかっていれば扱いはそう面倒ではありません。

ただ、あまりPHPらしい感じではないのも確かでしょう。データベースのテーブルやレコードというのは、PHPのクラスなどとは基本的な仕組みが違います。構造そのものが異なっているのです。まったく構造の異なるレコードをPHPの中に取り込もうとすると、「全部、データは連想配列にまとめてしまえ」となるのはやむを得ないことでしょう。

もし、テーブルをPHPのクラスのように定義して、レコードをクラスのインスタンスのように扱えたなら、ずいぶんとPHPらしい処理になると思いませんか？ そうなれば、データベースを扱うときも、「PHPとは異なる構造のデータ」ということを意識することなく扱うことができます。  
が、そのためには、<span class="red">データベースとPHPのオブジェクトの間の橋渡しをしてくれる仕組みが必要</span>です。それが、「<span class="green bold marker-yellow50">ORM</span>」と呼ばれる機能なのです。

![](upload/eroquent1.png "図1　ORMを使うことで、データベースのレコードをPHPのクラス【インスタンス】に変換し、シームレスに処理できるようになる。")

### ORM は異なる構造を橋渡しする
<span class="green bold marker-yellow50">ORM</span>は、「Object-Relational Mapping」の略です。これは、互換性のないデータを自動的に変換して、相互にデータをやり取りできるようにするための仕組みです。  

ORMにより、データベースから取り出されたレコードは、PHPのオブジェクトの形に変換して渡されるようになります。反対にPHPからデータベースに渡すときは、PHPオブジェクトがレコードに変換して渡されます。このように、相互にデータ構造を変換することで、<sup>※1</sup>シームレスにデータのやり取りが行えるよになるのです。

<div class="gray-box" markdown="1">
※1 シームレス～
: ITの分野では、サービスやシステム、ソフトウェアなどが複数の要素や複数の異なる提供主体の組み合わせで構成されているとき、利用者側から見てそれぞれの違いを認識・意識せずに一体的に利用できる状態のことを「シームレス」であるという。  
複数の要素を状況に応じて使い分けたり切り替えたりしなければならないときに自動的に切り替え処理などを行い、利用者が使い分けを意識しなくてもいいことも「シームレス」という。
</div>

### Eloquent とモデル
Laravelには、「<span class="red">Eloquent</span>」（エロクアント）というORMが用意されています。「モデル」と 呼ばれるクラスを定義し、これを利用してデータベース操作を行うように設計されています。  
モデルは、テーブルの内容を定義したクラスです。そのテーブル内にあるフィールドをプロパティとして持たせており、テーブルとフィールドをモデルクラスとインスタンスを扱う感覚で操作できます。


## モデルを作成する

では早速、Eloquentを利用してみましょう。ここでは、前章で作成したcustomersテーブルを操作するモデル「Customer」を作成してみましょう。  
モデルの作成は、コマンドを使って行います。コマンドプロンプトまたはターミナルで以下のようにコマンドを実行して下さい。

<p class="tmp cmd"><span>コマンド</span>モデル作成</p>
```
php artisan make:model Customer
```
![](upload/Customerモデル作成.png)

これで、Customerという名前のモデルが作成されます。プロジェクトフォルダの「<span class="red">app/Models</span>」フォルダの中を見て下さい。そこに「<span class="red">Customer.php</span>」というファイルが作成されているのが わかります。モデルクラスは、このように「app/Models」フォルダ内に配置されるのが基本です。

![](upload/Customerモデル作成ファイル確認.png){.photo-border}

<p class="tmp"><span>書式1</span>モデルの作成のartisanコマンド</p>
```
php artisan make:model モデル名
```


<div markdown="1" class="line-box">
#### テーブルのモデルは単数形?
Laravelでは、「テーブル名は<span class="red">複数形</span>、モデルは<span class="red">単数形</span>」という命名規則があります。 これにしたがって名前をつけることで、テーブルとモデルを自動的に関連付けて動くようになっています。

##### 命名規則一覧

例1) usersテーブル

|種類|名前|	複数or単数|	記法|
|--|--|--|--|
|テーブル名|users_table|複数|	スネークケース|
|モデル名|UserData|単数|	アッパーキャメル|
|migration名|xxx_crate_users_table|単数|	スネークケース|
|seeder名|UsersTableSeeder|－－－|	アッパーキャメル|
|Controllers名|UserDataController|－－－|	アッパーキャメル|
|views名|users_add|－－－|	スネークケース|

例2) login_recordsテーブルの場合

|種類|名前|複数or単数|記法|
|--|--|--|--|
|テーブル名|	login_records	|複数形|スネークケース|
|モデル名|	LoginRecord	|単数形|アッパーキャメルケース|
|コントローラ|LoginRecordsController	|（今回は）複数形|アッパーキャメル|


</div>


### モデルクラスのソースコード 

では、作成されたCustomer.phpの中身がどうなっているか見てみましょう。デフォルトでは以下のようなソースコードが記述されています。

<p class="tmp list"><span>リスト1-1</span>Customer.phpデフォルト</p>
```
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
}
```


## CustomerControllerを作成する

では、このCustomerモデルを利用するコントローラーを作成しましょう。コントローラは、artisan make:controllerコマンドで作成できました。では、コマンドラインまたは ターミナルから以下のように実行して下さい。

<p class="tmp cmd"><span>コマンド2-1</span>モデルを利用するコントローラーの作成</p>
```
php artisan make:controller CustomerController
```

![](upload/モデルを利用するコントローラー作成.png)

これで、CustomerController.phpが作成されます。
![](upload/Customer.contoroller作成.png){.photo-border}

作成されたスクリプトファイルを開き、ソースコードを記述しましょう。今回は、indexアクションだけを用意しておくことにします。

<p class="tmp list"><span>リスト2-2</span>CustomerController.php</p>
```
<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
   public function index(Request $request)
   {
       $items = Customer::all();
       return view('customer.index', ['items' => $items]);
   }
}
```
作成したソースコードの内容については後述するとして、まずはindexアクションを完成して使えるようにしましょう。


## index.blade.phpを作成する

続いて、indexアクション用のテンプレートを作成します。「views」内に、「customer」という名前でフォルダを作成して下さい。その中に「index.blade.php」ファイルを作り、以下のように記述をします。

<p class="tmp list"><span>リスト3-1</span>resources/views/customer/index.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Customer.index')

@section('menubar')
   @parent
   インデックスページ
@endsection

@section('content')
   <table>
   <tr><th>Name</th><th>Address</th><th>Login</th><th>password</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->name}}</td>
           <td>{{$item->address}}</td>
           <td>{{$item->login}}</td>
           <td>{{$item->password}}</td>
       </tr>
   @endforeach
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```
ここでは、$itemsとして受け取ったレコードデータを順に出力しています。基本的な やり方は、前章でDBクラスを利用して行ったのと同じです。

### ルート情報を追加する
最後にルート情報を記述しておきましょう。web.phpを開き、以下の文を追記してお いて下さい。

<p class="tmp list"><span>リスト3-2</span>web.php</p>
```
Route::get('customer', 'CustomerController@index');
```

記述したら、、/customerにアクセスしてみましょう。customersテーブルにあるレコードが一覧表示されています。

<http://localhost:8000/customer>

![](upload/cusrtomer接続.png "図2「/customer」にアクセスすると、テーブルの一覧が表示される。"){.photo-border}



### Customerモデルで全レコードを得る
では、今回作成したCustomerControllerのindexアクションで行っている処理を見てみましょう。ここでは、customersテーブルの全レコードを取得していますが、それを行っているのが以下の文です。

```
$items = Customer::all();
```

Customerクラスの「<span class="red">all</span>」メソッドを呼び出しています。これだけで、全レコードを取得することができます。

取得されたレコードは、「Illuminate\Database\Eloquent」名前空間のCollectionクラスのインスタンスとして得られます。これは名前の通り、レコード管理専用のコレクションクラスです。一般的なコレクションと同様、foreachなどを使い順に値を取り出して処理することができます。

テンプレート側では、コレクションから繰り返しを使ってオブジェクトを取得し、そこからフィールドの値を取り出して表示しています。この辺りの流れは、前章でDBクラスを利用して行ったのとほとんど同じです。


## Customerクラスにメソッドを追加する

ただし、DBクラスの場合と決定的に違うのは、「コレクションにまとめられているのは、<span class="red">配列など</span>ではなく、<span class="red bold">モデルクラスのインスタンス</span>である」という点です。今回の例でいえば、1つ1つのレコードはすべてCustomerクラスのインスタンスとしてまとめられているのです。  
モデルクラスのインスタンスですから、例えばクラスにプロパティやメソッドを追加することで独自に拡張していくことができます。実際にやってみましょう。

### Customerクラスの拡張
では、Customer.phpのCustomerクラスに、以下のようなメソッドを追記してみて下さい。これは、id、 name、address を文字列にまとめて返します。

<p class="tmp list"><span>リスト4-1</span>/app/Models/Customer.php</p>
```
public function getData()
{
   return $this->id . ': ' . $this->name . ' (' . $this->address . ')';
}
```
続いて、index.blade.phpの@section('content)ディレクティブを以下のように修正しましょう。

<p class="tmp list"><span>リスト4-2</span>indexData.blade.php</p>
```
@section('content')
   <table>
   <tr><th>Data</th></tr>
   @foreach ($items as $item)
       <tr>
           <td>{{$item->getData()}}</td>
       </tr>
   @endforeach
   </table>
@endsection
```

修正ができたら、「/customerData」にアクセスしてください。  

<http://localhost:8000/customerData>

今回は、「Data」と いう項目に、レコードがまとめて表示されます。  

![](upload/cusrtomerData接続.png "図 「/customerData」にアクセスすると、id, name, addressがまとめて表示される"){.photo-border}

ここでは、<span class="red">{{$item->getData()}}</span> というようにしてgetDataの値を出力しています。これで、id、name、addressをまとめて出力しています。

モデルを利用する場合は、このように<span class="marker-yellow30 bold">簡単に処理を追加し拡張していくことができます</span>。DBクラスのようにただのオブジェクトや配列では、こんな具合に簡単に拡張することはできないでしょう。


## IDによる検索

レコードの操作では、IDを使って特定のレコードを取り出すことがよくあります。こうした「IDによるレコード検索」を行うのに用意されているのが「<span class="green bold marker-yellow50">find</span>」メソッドです。

<p class="tmp"><span>書式2</span>findメソッド</p>
```
$変数 = モデルクラス :: find( 整数 );
```

「find」は、このようにモデルクラスの静的メソッドとして呼び出します。引数には、検索するID番号を指定します。非常にシンプルなメソッドですから、使い方はすぐにわかるでしょう。

「find」は、テーブルの「id」フィールドから指定の番号のものを検索します。Eloquentでは、 テーブルのプライマリキーは「id」という整数値のフィールドであるという前提でfindを実行します。プライマリキーのフィールド名がidでないとうまく動かないので注意が必要です。


<div markdown="1" class="memo-box">
##### id以外のプライマリキーは?
ここでは、最初からidという名前でプライマリキーフィールドを用意していましたが、 もし、id以外の名前でフィールドを用意してしまった場合はどうすればよいのでしょうか。  
この場合は、モデルのプライマリキーの値を変更してやります。モデルクラスに $primaryKeyというプロパティを用意し、これにフィールド名を設定して下さい。これでプライマリキーのフィールド名を変更できます。
</div>

### /find アクションを作る
では、実際にfindを使ってみましょう。今回は、/findアクションという検索用のペー ジを作成してfindを使ってみることにします。まず、テンプレートを用意しましょう。 「views」内の「customer」フォルダ内に「<span class="red">find.blade.php</span>」を作成して下さい。ソースコードは 以下のようにしておきます。

<p class="tmp list"><span>リスト4-3</span>find.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Customer.find')

@section('menubar')
   @parent
   検索ページ
@endsection

@section('content')
   <form action="/customer/find" method="post">
   {{ csrf_field() }}
   <input type="text" name="input" value="{{$input}}">
   <input type="submit" value="find">
   </form>
   @if (isset($item))
   <table>
   <tr><th>Data</th></tr>
   <tr>
      <td>{{$item->getData()}}</td>
   </tr>
   </table>
   @endif
@endsection

@section('footer')
copyright 2017 tuyano.
@endsection
```

ここでは、&lt;input type="text" name="input"&gt;という入力フィールドが1つあるだけのシンプルなフォームを用意しておきました。そして$itemという値が用意されていたら、それをテーブルに表示するようにしてあります。

### Customer Controllerの修正
では、CustomerControllerにアクションを追加しましょう。以下のメソッドをクラスに追記して下さい。

<p class="tmp list"><span>リスト4-4</span>CustomerController.php</p>
```
public function find(Request $request)
{
   return view('customer.find',['input' => '']);
}

public function search(Request $request)
{
   $item = Customer::find($request->input);
   $param = ['input' => $request->input, 'item' => $item];
   return view('customer.find', $param);
}
```

findは、<span class="marker-yellow50">/findにGETアクセスしたときの処理</span>、searchは、<span class="marker-yellow50">POST送信されたときの処理</span>となっています。searchでは、送信されたinputフィールドの値を引数に指定してfindメ ソッドを呼び出しています。
```
$item = Customer::find($request->input);
```
IDによる検索は、たったこれだけです。これで$itemには、検索されたCustomerインスタンスが代入されます。もし見つからなかった場合は、$itemはnullのままになります。

### ルート情報の追加
最後にルート情報を追記しましょう。web.phpに以下の文を追加して下さい。

<p class="tmp list"><span>リスト4-5</span></p>
```
Route::get('customer/find', 'CustomerController@find');
Route::post('customer/find', 'CustomerController@search');
```
これで「/find」の完成です。「/customer/find」にアクセスしてください。

<http://localhost:8000/customer/find>

フィールドからID番号を送信して下さい。そのIDのレコードが表示されます。

![](upload/customer_find接続.png "図 「/customer/find」にアクセス"){.photo-border}

<p class="d-flex align-items-center"><span class="arrow-down ml-5 mr-3"></span>フィールドからID番号を送信すると、</p>
![](upload/customer_find_id番号入力.png){.photo-border}

<p class="d-flex align-items-center"><span class="arrow-down ml-5 mr-3"></span>そのIDのレコードが表示されます。</p>
![](upload/customer_find_id番号入力結果表示.png){.photo-border}

<p class="d-flex align-items-center"><span class="arrow-down ml-5 mr-3"></span>続けて、ID番号を変更して送信すると、変更したレコードが表示されます。</p>
![](upload/customer_find_id番号入力8.png){.photo-border}



