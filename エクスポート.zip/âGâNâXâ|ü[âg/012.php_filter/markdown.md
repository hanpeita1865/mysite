*[page-title]:配列の要素をフィルタリングする array_filter

参考サイト
: [PHP マニュアル array_filter](https://www.php.net/manual/ja/function.array-filter.php)
: [【PHP】array_filterの使い方と配列の要素をフィルタリングする方法](https://webukatu.com/wordpress/blog/31990/)

## array_filterについて

array_filterはコールバック関数を用いて、配列をフィルタリングすることができます。  
連想配列であってもフィルタリングすることが可能なので、非常に便利です。  
また、フラグを指定すれば、配列のキーだけを抽出したり、キーと値の両方を抽出したりすることができるので、使い方を覚えておくといいでしょう。

## 基本
<p class="tmp"><span>書式</span>array_filter</p>
```
array_filter(配列, コールバック関数, フラグ)
```
上記のコードのように、第1引数には配列を指定し、第2引数にはコールバック関数を指定します。  
そして、第3引数には「ARRAY_FILTER_USE_KEY」や「ARRAY_FILTER_USE_BOTH」などのフラグを指定することができます。  
第3引数を指定しない場合は、値のみをコールバック関数の引数として渡します。



例1は、基本的な使い方です。

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	配列から3以上の値を抽出する
	<iframe src="https://paiza.io/projects/e/ZD59xLC9ZUfsYZr8SrYgjg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

## 連想配列をフィルタリングする

array_filterは配列をフィルタリングすることができる関数ですが、連想配列の場合は実装できるのでしょうか？  
結論から言うと、array_filterは連想配列でもフィルタリングすることが可能です。

<div class="exp">
	<p class="tmp"><span>例2</span>連想配列をフィルタリング</p>
	<iframe src="https://paiza.io/projects/e/5__PfWdJ66Fw-cEFmW4AMw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>



<div class="exp">
	<p class="tmp"><span>例3</span></p>
	配列から偶数と奇数の値を抽出する
	<iframe src="https://paiza.io/projects/e/n_NVWMDC_D_PZ1cZaPFNQg?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>
</div>

## フラグを指定する方法

array_filterで第3引数のフラグ「<span class="red">ARRAY_FILTER_USE_KEY</span>」と「<span class="red">ARRAY_FILTER_USE_BOTH</span>」を指定する方法を解説していきます。

### ARRAY_FILTER_USE_KEYを指定する
まずは、ARRAY_FILTER_USE_KEYを指定する方法です。  
ARRAY_FILTER_USE_KEYは、<span class="marker-yellow50 bold">配列のキーだけ</span>をコールバック関数に渡す役割があります。

<div class="exp">
	<p class="tmp"><span>例4</span></p>
	<iframe src="https://paiza.io/projects/e/xdXm8kMDVWeypq0SwMI0Zw?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>
</div>

### ARRAY_FILTER_USE_BOTHを指定する
ARRAY_FILTER_USE_BOTHは、<span class="marker-yellow50 bold">配列の値とキーの両方</span>をコールバック関数に渡す役割があります。

<div class="exp">
	<p class="tmp"><span>例5</span></p>
	<iframe src="https://paiza.io/projects/e/3rSKGoAsI6lSubeCKH5H0A?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

