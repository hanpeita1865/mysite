---
title: GRAVについて
taxonomy:
    category:
        - docs
---

<style>
    li p {
    	margin: 0.5rem 0;   
    }
</style>
Grav（グラヴ）は2014年に開発されたCMSです。ブログ等に特化したものではなく、どのサイトにも使われるように開発されました。
GravはGravity（重力）の略から名付けられました。

[GRAV公式サイト](https://getgrav.org/)

## GRAVの特徴

* Gravは、**ファイルベース**のCMSでセットアップも簡単です。
* ページ自体は、**Markdown**で記述し、[プラグイン](https://getgrav.org/downloads/plugins)も導入できることから拡張性にも優れています。
* [テーマ](https://getgrav.org/downloads/themes)も100種類以上あるので、目的に合わせて使い分けすることが出来ます。
	 * [Learn2デモ](https://demo.hibbittsdesign.org/grav-learn2-git-sync/)
	 * [Quark Open Publishingデモ](http://demo.hibbittsdesign.org/grav-open-publishing-quark/)
	 * [multiverseデモ](http://www.peaceofmindwebsite.com/skeletons/multiverse/)
	 * [Solarizeデモ](https://behold.metamotive.co.nz/solarize)
	 * [Bootstrapデモ](https://demo.getgrav.org/bootstrap-skeleton/)
	 * [Afterburner2デモ](https://demo.getgrav.org/afterburner2-skeleton/)
	 * [Introspectデモ](https://aisbergg.github.io/grav-demo/introspect/pages/home/)
	 * [gatewayデモ](https://demo.getgrav.org/gateway-skeleton/)


     
	
* WordPressと比べて機能は劣りますが、資料をまとめたりするのにとても有効です。
* テーマをデザインするときは、PHPには一切触らず、PHPの代わりに、テーマ作成専用の言語**Twig（ツイグ）**を使います。Twigはテーマ作成専用ですから、テーマを作ることが楽になります。
* Gravで書いた記事などは全部、普通のファイルに保存されます。  
MySQLなどのデータベースを使ってませんので、FTPでフォルダーをまるごとコピーすれば、サイトの移管は簡単に完了できます。

公式サイトにある「learn page」は、英語版になるのでGoogleで翻訳したものを見るのがいいです。

[GRAV使い方（英語版）](https://learn.getgrav.org/16)

[GRAV使い方（Googleで翻訳）](https://translate.google.co.jp/translate?sl=auto&tl=ja&u=https%3A%2F%2Flearn.getgrav.org%2F16%2Fbasics%2Fwhat-is-grav)