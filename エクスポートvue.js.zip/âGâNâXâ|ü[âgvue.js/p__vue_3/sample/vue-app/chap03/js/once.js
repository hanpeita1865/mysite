Vue.createApp({
  data() {
    return {
      name: '匿名'
    };
  }
}).mount('#app');