*[page-title]:配列の差を計算する array_diff

参考サイト
: [PHP マニュアル array_diff](https://www.php.net/manual/ja/function.array-diff.php)

array を他の配列と比較し、 array の要素の中で他の配列には存在しないものだけを返します。
<p class="tmp"><span>書式</span>array_diff</p>
```
array_diff($array1, $array2)
```
$array1: 比較元の配列。  
$array2: 比較対象の配列。

<div class="exp">
	<p class="tmp"><span>例1</span>array_diff() の例</p>
	<iframe src="https://paiza.io/projects/e/EV13AW9LRRSxjLcyd86bkQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

注意
: <span class="red bold">この関数は n 次元配列の一つの次元しかチェックしません。</span> もちろん、array_diff($array1[0], $array2[0]); のようにすることでより深い次元でのチェックもできます。