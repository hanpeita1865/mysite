<?php
require 'database_access.php';

$sql=$pdo->prepare('delete from result');
if ($sql->execute()) {
    echo '削除しました。';
}else{
    echo '削除に失敗しました。';
}