<?php

$folder = $_POST['folder'];

globFlat($folder);

$path2 = str_replace('pages','pages_copy', $folder);

if (rename($folder, $path2)) {
    echo "OK";
} else {
    echo "移動エラー";
}

function globFlat($folder) {
    // print_r($folder);
    // echo '<br>';

    //「pages」フォルダが存在するか判定
    if (!is_file($folder)) {

        $res = glob($folder . '/*'); //「/」があるディレクトリを配列に格納

        foreach ($res as $f) {
            $dirArray = explode('/', $f);//「/」で分割して配列化
            $lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {

                //フォルダ直下に「markdown.md」がある
                if (file_exists($f.'/markdown.md')) {
                    $md = file_get_contents($f.'/markdown.md'); //マークダウンの内容を変数に格納
                    preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);//ページ名を取得
                }

                //移動
                $path1 = $f;
                $path2 = '../pages_copy/'.$lastDir;

                //ディレクトリ($f)内に〇〇.フォルダがあるか判定
                $res1 = glob($f . '/*');

                $numBool = false;
                foreach ($res1 as $f1) {
                    $dirArray1 = explode('/', $f1);
                    $lastDir1 = end($dirArray1);
                    if (preg_match('/^\d{3}./', $lastDir1)) {//フォルダ名に〇〇.が先頭に付いてるか判定
                        $numBool = true;
                    }
                }


                if(!$numBool){
                    //フォルダ内に〇〇.フォルダがない → pages_copyフォルダに移動
                    if (file_exists($path1)) {
                        // echo $path1;
                        if (rename($path1, $path2)) {
                            // echo "OK";
                            globFlat($folder);
                        } else {
                            echo "移動エラー";
                        }
                    }

                }else{
                    //フォルダ内に〇〇.フォルダがある → 再帰処理
                    globFlat($f);
                }

            }
        }
    }
}
?>
