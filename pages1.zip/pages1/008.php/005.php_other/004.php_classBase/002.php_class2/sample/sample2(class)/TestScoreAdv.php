<?php
class TestScoreAdv
{
	//名前プロパティ。
	public $name = "";
	//数学点数プロパティ。
	public $math = 0;
	//英語点数プロパティ。
	public $english = 0;
	//国語点数プロパティ。
	public $japanese = 0;

	//【1】全データを受け取ってプロパティに格納するメソッド。
	public function setData(string $name, int $math, int $english, int $japanese): void
	{
		$this->name = $name;//たろう
		$this->math = $math;//87
		$this->english = $english;//92
		$this->japanese = $japanese;//74
	}

	//【2】合計点を計算するメソッド。
	public function calcSum(): int
	{
		$sum = $this->math + $this->english + $this->japanese;//253 合計
		return $sum;
	}

	//【3】平均点を計算するメソッド。
	public function calcAve(): float
	{
		$sum = $this->calcSum();
		$ave = $sum / 3;//253/3=84.333 平均
		return $ave;
	}
	
	//【4】名前、合計、平均を表示するメソッド。
	public function printScore(): void
	{
		$sum = $this->calcSum();//253 合計
		$ave = $this->calcAve();//253/3=84.333 平均
		print($this->name."さんの合計: ".$sum." 平均: ".$ave."<br>");
	}
}

