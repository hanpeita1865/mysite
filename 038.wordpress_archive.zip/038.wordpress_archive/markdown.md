*[page-title]:Archiveページの作成

archive-news.phpのテンプレートを作成します。

<p class="tmp list"><span>リスト</span>archive-news.php</p>
```
<?php get_header(); ?>
<main class="main">
	<p>archive-news.php</p>
  <article class="">
    <ul class="">
      <!-- 記事のループ処理開始 -->
      <?php
        if( wp_is_mobile() ){
          $num = 3; // スマホの表示数(全件は-1)
        } else {
          $num = 5; // PCの表示数(全件は-1)
        }
        $paged = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = [
          'post_type' => 'post', // 投稿タイプのスラッグ(通常投稿なので'post')
          'paged' => $paged, // ページネーションがある場合に必要
          'posts_per_page' => $num, // 表示件数
        ];
        $wp_query = new WP_Query($args);
        if (have_posts()): while (have_posts()): the_post();
      ?>
      <li class="">
        <!-- 記事へのリンク -->
        <a href="<?php the_permalink(); ?>" class="">
          <!-- アイキャッチ -->
          <div class="">
            <?php the_post_thumbnail('post-thumbnail', array('alt' => the_title_attribute('echo=0'))); ?>
          </div>
          <p class="">
            <!-- 投稿日 -->
            <time datetime="<?php the_time('Y.n.j'); ?>">
              <?php the_time('Y.m.d'); ?>
            </time>
          </p>

          <h2 class="">
            <!-- タイトル -->
            <?php the_title(); ?>
          </h2>
          <div class="">
            <!-- 本文の抜粋 -->
            <?php the_excerpt(); ?>
          </div>
        </a>
      </li>
      <?php endwhile; else: ?>
      <p>まだ記事がありません</p>
      <?php endif ?>
      <?php wp_reset_postdata(); ?>
      <!-- 記事のループ処理終了 -->
    </ul>
  </article>
</main>
<?php get_footer(); ?>
```

<p class="tmp list"><span>リスト</span>function.php</p>
```
function add_news()
{
    $name = "ニュース";

    $labels = [
        'name' => $name,
        'manu_name' => $name,
        'all_items' => $name . '一覧',
        'add_new' => $name . '追加',
        'singular_name' => $name,
        'not_found' => $name . 'は見つかりませんでした'
    ];

    $args = [
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,//静的URLで一覧ページを表示
        'menu_position' => 5,
        'show_in_rest' => true,//グーテンベルグ使用
    ];

    register_post_type('news', $args);
}

add_action('init', 'add_news');
```

<http://localhost:7001/wordpress/news/ >にアクセスすると、「archive-news.php」のテンプレートを使ったページが表示されます。
![](upload/Archive-newsページ.png){.photo-border}