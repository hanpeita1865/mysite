*[page-title]:Socket.IO


参考サイト
[Socket.IOで始めるリアルタイム双方向通信](https://zenn.dev/knockknock/articles/518ce150336703)

WebSocketは、リアルタイムかつ双方向通信を実現するプロトコルです。WebSocket通信では、コネクション確立時にHTTPからWebSocketへプロトコルを切り替えます。このWebSocketを簡単に利用することができるライブラリ「<span class="green bold marker-yellow50">Socket.IO</span>」を使って、簡単なチャットツールを作ってみます。

Socket.IO公式サイト
: <https://socket.io/>

## 設定

まずは、Node.jsでWebサーバを構築するためにExpressインストールします。

<p class="tmp cmd"><span>コマンド</span>Expressをインストール</p>
```
npm install express@4
```

Express公式サイト
: <https://expressjs.com/ja/>

次にSocket.IOをインストールします。
<p class="tmp cmd"><span>コマンド</span>Socket.IOインストール</p>
```
npm install --save socket.io
```

JavaScriptでWebサーバの処理を記述します。

<p class="tmp list"><span>リスト1</span>server.js</p>
```
const path = require("path");
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

// 接続したユーザーに対するイベント
io.on('connection', (socket) => {

  // chat messageイベントを受信
  socket.on('chat message', (msg) => {
  
    // ユーザーにchat messageイベントでメッセージを送信
    io.emit('chat message', msg);
    
  });
  
  socket.on('disconnect', () => {
  });
});

// ポート3001番でサーバを起動します。
server.listen(3001, () => {
  console.log('listening on *:3001');
});
```

HTMLを作成して、データの送受信処理を記述します。

<p class="tmp list"><span>リスト2</span>public/index.html</p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>Socket.IOで始めるリアルタイム双方向通信</title>
</head>
<body>
<ul id="messages"></ul>
<form id="form" action="">
    <input id="input" autocomplete="off" /><button>Send</button>
</form>
<script src="/socket.io.min.js"></script>
<script>
    var socket = io();

    var messages = document.getElementById('messages');
    var form = document.getElementById('form');
    var input = document.getElementById('input');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (input.value) {
            socket.emit('chat message', input.value);
            input.value = '';
        }
    });

    socket.on('chat message', function(msg) {
        var item = document.createElement('li');
        item.textContent = msg;
        messages.appendChild(item);
        window.scrollTo(0, document.body.scrollHeight);
    });
</script>
</body>
</html>
```

クライアント側のSocket.IOのJavascriptを「`node_modules/socket.io/client-dist/<span class="red">socket.io.min.js</span>`」より、HTMLから読み込むためにpublicディレクトリにコピペしてください。

全体のディレクトリ構造は以下のようになります。
```
├── node_modules
├── package-lock.json
├── package.json
├── public
│   ├── index.html
│   └── socket.io.min.js
└── server.js
```

Node.jsでserver.jsを実行し、Webサーバアプリケーションを起動します。
<p class="tmp cmd"><span>コマンド</span>サーバ起動</p>
```
node server.js
```

ブラウザを2つ立ち上げて、<http://localhost:3001/>にアクセスします。
![](upload/Animation3.gif){.photo-border}

これで、WebSocketを使って、リアルタイムで双方向通信ができるようになりました。テキストフィールドに入力したテキストが、リアルタイムに反映されるかと思います。

例えばAWS上で、Node.jsで実行することで、Webコンテンツとして公開することができます。

