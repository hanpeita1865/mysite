import { getAdminData } from '../adminData.js';
import { Api } from '../api.js';


//pages内のディレクトリを配列で取得
export function pagesDirGet() {

    const { pageArea, adminFull } = getAdminData();

    const fd = new FormData();
    fd.append('pageArea', pageArea);
    
    return Api.postJSON(adminFull + 'pagesDirGet', fd);
}



function useCheck(menuStr) {

    const { pageArea, adminFull } = getAdminData();

    const fd = new FormData();
    fd.append('list', menuStr);
    fd.append('pageArea', pageArea);

    return Api.postText(adminFull + 'pagesDirGet', fd);
}



export async function pagesSort({
    dirObj,
    getMenuStr,
    menu_create,
    completeMsg,
    elm_msgbox,
    setSoating,
}) {
    
    const { pageArea, adminFull } = getAdminData();
    
    menu_create();
    
    const menuStr = getMenuStr(); 
    
    const check = await useCheck(menuStr);

    if (check === 'false') {
        alert('フォルダが使用中のため並び替えできません');
        return false;
    }

    if (!window.confirm('並べ替えの確定をしていいですか？')) {
        return;
    }

    setSoating(true);

    elm_msgbox.insertAdjacentHTML(
        'afterbegin',
        '<p class="sort-text text-primary">並べ替え確定中です。他の操作はしないでください。</p>'
    );
    

    let fd = new FormData();
    fd.append('list', menuStr);
    fd.append('dirObj', JSON.stringify(dirObj));
    fd.append('pageArea', pageArea);
    

    try {
        const response = await fetch(adminFull + 'sort_confirm', {
            method: 'post',
            body: fd,
        });

        const data = await response.text();
        const regexp = /エラー|失敗|強制終了/;

        if (!regexp.test(data)) {
            setSoating(false);
            completeMsg('並び替えが完了しました。');
        } else {
            alert(
                '並び替えは完了しましたが一部失敗しました\n' + data
            );
        }

    } catch {
        alert('並び替え中にエラーが発生しました。');
    } finally {
        elm_msgbox.innerHTML = '';

    }
}