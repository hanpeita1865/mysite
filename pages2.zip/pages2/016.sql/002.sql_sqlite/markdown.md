*[page-title]:SQLite操作

データベースには、下記のように二つのタイプのものがあります。

<span class="blue">サーバータイプのもの(MySQLやPostgreSQLなど</span>
: データベースにアクセスする専用のサーバープログラムを起動し、Webサーバーとデータベースサーバの間で通信してデータのやり取りを行うタイプです。

<span class="red">エンジンタイプのもの(SQLiteなど</span>
: データベースファイルに直接アクセスするエンジンプログラムです。非常に小さいため、スマホなどにも組み込むことができます。

## SQLiteについて

### メリット

* 動作が軽い。
* ファイルが一つだけなので、バックアップや復元が簡単。
* サーバ側でデータベースを用意する必要がない。　（← 一番のメリットはこれ）
		
MySQLやMariaDBはサーバー管理画面でデータベースの作成やユーザー名・パスワードの設定を事前にしておく必要があります。  
しかし、SQLiteならその必要がない。

### デメリット

* パスワードが存在しない。
    * データベースファイルが設置してあるディレクトリに.ataccessで制限をかけたり、ドキュメントルートより上位の階層に設置することで簡単にカバーできます。
* 複数の同時書き込みができない。

MySQLなどとの使い分け方として、ちょっとした社内で使用するようなサイトや、検証を行うときなどに有効です。

### SQLite を用意する。
とはいえ、データベースを利用する場合には、PHPのプログラムだけでなく、直接デー タベースにアクセスしてデータベースの操作を行う必要が生じます。SQLiteのインス トールは面倒なものではありませんので、Windowsユーザーはインストールだけ行って おくとよいでしょう。 SQLiteは、以下のアドレスで公開されています。

<http://www.sqlite.org/download.html>

![](sqlite02.png?classes=caption "図 SQLiteのダウンロードページ。ここから、Precompiled Binariesをダウンロードする。")

ここでは、SQLiteのソースコードからドキュメント、バイナリファイルまで一通りを 配布しています。プログラムは、「***Precompiled Binaries for Windows***」というところにアップロードされています。ここから、使っているOS用のバイナリファイルをダウンロードして下さい。64 bit Windowsを使っているなら、「***sqlite-dill-win64-x64-xxx.zip***」(xxxはバー ジョン番号)をダウンロードして下さい。

ダウンロードしたzipファイルを展開すると、「sqlite3.dll」というファイルがあります。 これが、SQLiteの本体です。これを、環境変数pathに設定されている場所に保存します。 どこかわからない場合は、「Windows」フォルダ内の「system32」フォルダの中に入れて下さい。これでSQLiteが使えるようになります。


## データベースの作成方法

<span class="red bold">DB Browser for SQLite</span>を使うと便利。

ダウンロードページ  
[https://sqlitebrowser.org/dl/](https://sqlitebrowser.org/dl/)  
※インストールしなくてもよい **DB Browser for SQLite - .zip (no installer) for 64-bit Windows**  
をダウンロードする。

### 起動方法
DB Browser for SQLite」のフォルダを任意の場所に設置した後、その中にある**DB Browser for SQLite.exe**をダブルクリックして起動します。

### 使い方

「[DB Browser for SQLiteの使い方](https://www.dbonline.jp/sqlite-db-browser/)」のサイトを参考にする。



## データベースへの接続

### MySQLの場合

	$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 'staff', 'password');


### SQLiteの場合

	$pdo = new PDO( 'sqlite:db/shop.sqlite3' );//SQLite用に変更
    
    
試しに参考書の付録のDBをSQliteに変更して、ローカルに設置しました。


商品追加画面
: [http://10.189.201.217:55514/php/product_sqlite/insert-input.php](http://10.189.201.217:55514/php/product_sqlite/insert-input.php)


商品編集画面
: [http://10.189.201.217:55514/php/product_sqlite/update-input.php](http://10.189.201.217:55514/php/product_sqlite/update-input.php)


商品削除画面
: [http://10.189.201.217:55514/php/product_sqlite/delete-input.php](http://10.189.201.217:55514/php/product_sqlite/delete-input.php)


## サンプル1（レスポンシブBBS）

この「[レスポンシブBBS](https://www.1-firststep.com/archives/2934#link-scroll-2)」というサイトにあるサンプルをダウンロードして、ローカルに設置してみました。

<div class="exp">
	<p class="tmp"><span>例1-1</span><a href="sample/responsive-bbs/" target="_blank">新規タブ</a></p>
「レスポンシブBBS」サイトトップページ
<iframe width="100%" height="750" src="sample/responsive-bbs/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例1-2</span>「レスポンシブBBS」ログイン画面<a href="sample/responsive-bbs/login.php" target="_blank">新規タブ</a></p>
ユーザ名はtani、パスワードは0000です。
<iframe width="100%" height="450" src="sample/responsive-bbs/login.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


<!--
サンプルでは、接続は下記のようになってた。  

$this->pdo = new PDO( "sqlite:". {c:red}dirname( __FILE__ ){/c} ."/../db/responsive_bbs.sqlite3" );


<pre>
dirname関数 ～ 親ディレクトリのパスを表示。

__FILE__ は、PHPにあらかじめ用意された定数で、PHPファイルのフルパスとファイル名が格納されています。
</pre>

例)
<pre>
&lt;?php
echo dirname(__FILE__) . "\n";
echo __FILE__ . "\n";
echo __DIR__;
?&gt;
</pre>

**表示結果**
<pre>
/Applications/MAMP/htdocs
/Applications/MAMP/htdocs/dirname.php
/Applications/MAMP/htdocs
</pre>
-->


## サンプル2（PHP超入門 Shop用データ）

参考書「PHP超入門」に付いてたサンプルのデータベース「shop.sql」のデータを、SQLiteに変換して表示させました。

<div class="exp">
	<p class="tmp"><span>例2-1</span>「shop」データの表示画面<a href="sample/sample_shop1/all4.php" target="_blank">新規タブ</a></p>
ユーザ名はtani、パスワードは0000です。
<iframe width="100%" height="400" src="sample/sample_shop1/all4.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


<p class="mb-05"><span class="tmp list">リスト2-1</span><span class="bold">all.phpを編集</span></p>

    <table>
    <tr><th>商品番号</th><th>商品名</th><th>価格</th></tr>
    <?php
    //$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 'staff', 'password');

    $pdo = new PDO( 'sqlite:db/shop.sqlite3' );//SQLite用に変更

    foreach ($pdo->query('select * from product') as $row) {
        echo '<tr>';
        echo '<td>', $row['id'], '</td>';
        echo '<td>', $row['name'], '</td>';
        echo '<td>', $row['price'], '</td>';
        echo '</tr>';
        echo "\n";
    }
    ?>
    </table>



## PRIMARY KEYの設定 ##{#p6}

カラムに PRIMARY KEY 制約を設定すると、そのカラムが主キー(プライマリーキー)であることをあらわします。主キーは1つまたは複数のカラムの組み合わせに対して設定し、テーブルの中で1つだけ存在します。  
***主キーが設定されたカラムでは他のデータと重複する値を取ることはできません***。

<p class="tmp"><span>書式</span> PRIMARY KEY設定のSQL文</p>
```
CREATE TABLE テーブル名(カラム名 PRIMARY KEY, ...);
```

<p class="tmp"><span>書式</span> 複数カラムへのPRIMARY KEY設定のSQL文</p>
```
CREATE TABLE テーブル名(カラム名1, カラム名2, ... ,
  PRIMARY KEY(カラム名1, カラム名2, ...));
```

実際に、カラムにプライマリキーを設定したテーブルを作成してみます。 
下記のリストのコードをSQL画面に貼り付けて、実行してください。

<p class="tmp list"><span>リスト</span></p>
```
create table user(id int primary key, name text);
```
そうすると、userテーブルが作成され、カラムidにプライマリキーが設定されます。
![](upload/primary_key1.png)

これで、同じidを持つレコードは登録できないようになります。

##  AUTOINCREMENTの設定 ##{#p7}

データ型が **INTEGER** のカラムに対して PRIMARY KEY 制約を設定した場合、新しいデータを追加する時に対象のカラムの値を省略すると、 AUTOINCREMENT 制約を設定した時と同じように自動的に数値が格納されます。

※連番が自動的に割り振られるのはカラムに対して ***INTEGER PRIMARY KEY*** と記述した場合だけです。 INT PRIMARY KEY ではこのような特別な動作はしません。

以下のSQL文を実行してみます。
<p class="tmp list"><span>リスト</span></p>
```
create table user_a(id integer primary key, name text);
```
user_aテーブルが作成され、カラムidにはintegerが設定されています。
![](primary_key2.png)

ツールバーのレコード追加ボタンをクリックすると、idに自動的に番号が入ります。
![](primary_key3.png)

なお PRIMARY KEY 制約が設定されたカラムには同じ値を重複して格納することはできませんが、データを削除するとそのデータのカラムに格納されていた値は、別のデータを追加する時に指定することができます。

例えば現在 PRIMARY KEY 制約が設定されたカラムに格納されている値が 9 のデータを削除したあと、新しいデータとして PRIMARY KEY 制約が設定されたカラムに 9 を指定してデータを追加することができます。


## SQLで独自のテーブルビューを作成と出力 ##{#p8}

ファイル格納場所  
: C:\xampp\htdocs\from_now\trunk\pages\p__sqlite\sample\sample_taisei


### テーブルビューを作成

##### 4つのテーブル(employee、charge_master、depart_master、position_master)を組み合わせたSQLコード
```
select id,name,furigana,position_name,depart_name,charge_name,profile,mail from employee left outer join charge_master on employee.charge = charge_master.id_charge 
left outer join position_master on employee.position = position_master.id_position 
left outer join depart_master on employee.depart = depart_master.id_depart order by id_depart
```
「Execute SQL」タブをクリックし、SQL記入欄を表示します。  
上記のSQLのコードを貼り付けて、実行ボタンを押します。

![](upload/sql_join1.png)

そうすると、下の画面にSQLで作成したテーブルが表示されます。

![](upload/sql_join2.png)

viewを保存アイコンの「Save as view」を選択し、クリックします。

![](upload/sql_join3.png)

ボックスが表示されるので、viewの名前を記入しOKを押します。

![](upload/sql_join4.png)

これでviewの保存が出来ました。  

![](sql_view1.png)

「社員関連view」の上で右クリックし、「Browse Table」を選択すると、社員関連テーブルが表示されます。

![](upload/sql_view5.png)

<p class="text-center">↓</p>
![](upload/sql_view4.png)

### JSONファイルを出力する

メニューバーの「ファイル」- 「Export」- 「Table(s) to JSON」をクリックします。 

![](upload/sql_json1.png)

リスト一覧から「社員関連」を選択し、「Save」をクリックします。

![](upload/sql_json2.png)

これで指定したフォルダに、社員関連用SQLで作成したテーブルのデータが書かれたJSONファイルが作成されます。  
コードは以下のように連想配列で記入されています。

##### 社員関連データJSONファイル #####{.text-center}
![](upload/sql_json3.png)


## 参考サイト

[PRIMARY KEY制約の使い方](https://www.dbonline.jp/sqlite/table/index6.html)






