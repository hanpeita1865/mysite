---
title: '07. Quill'
media_order: fx.png
taxonomy:
    category:
        - docs
---

## 概要

[Quill 公式サイト](https://quilljs.com/?target)

Quillは、**<sup>{c:red}※注1{/c}</sup>クロスブラウザ**、**<sup>{c:red}※注2{/c}</sup>クロスプラットフォーム**に強みを置くエディタで、オープンソースのWYSIWYGエディタです。

JavaScriptで作られていて、Webサイト上で手軽にWYSIWYG(見たまま)対応のテキスト編集機能を提供することができます。  
デスクトップだけではなくタブレットやスマートフォンにも対応しています。開発者が利用可能なパワフルなAPIを提供していることも特徴です。

Quillの編集機能は、テキストのサイズやフォントの種類の変更、アンダーライン、ボールド、イタリックなどテキスト装飾、各種箇条書き、画像や動画の埋め込み機能を提供しています。

そのほか、ソースコードのシンタックスハイライト(highlight.jsを使用しているため、highlight.jsに対応しているプログラミング言語は全てシンタックスハイライト可能)や、 LaTeXの数式を美しく表示することもできます。


<sup>{c:red}※注1{/c}</sup> クロスブラウザ
: WebサイトやWebアプリケーションが、どのWebブラウザでも同じ表示、同じ動作を再現できる状態のことである。

<sup>{c:red}※注2{/c}</sup> クロスプラットフォーム
: OSやソフトウェアが異なるシステムのアーキテクチャ（コンピュータ システムの論理的構造）に対応していることである。

<div class="box-example" markdown="1">
### 例0 ### {.h-example}
Quillのデフォルトの画面を表示させています。スタイルの #editor { height: 450px;}は独自に追加しています。
[新規タブ](../../../sample/sample0(Quill)/index.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/sample0(Quill)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

##### HTML
<pre>
&lt;!DOCTYPE html&gt;
&lt;html lang="ja"&gt;
&lt;head&gt;
	&lt;title&gt;例0 Quillデフォルト&lt;/title&gt;
	&lt;meta charset="UTF-8"&gt;
	&lt;meta http-equiv="X-UA-Compatible" content="IE=edge"&gt;
	&lt;meta name="viewport" content="width=device-width"&gt;
	&lt;link rel="stylesheet" href="css/quill.snow.css"&gt;
	&lt;style&gt;
		#editor {
		  height: 450px;
		}
	&lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;div id="editor"&gt;
	&lt;p&gt;Hello World!&lt;/p&gt;
&lt;/div&gt;
&lt;script src="js/quill.min.js"&gt;&lt;/script&gt;
&lt;script&gt;
	var quill = new Quill('#editor', {
		theme: 'snow'
	});
&lt;/script&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>   
</div>

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
Quillのツールバーに全部のアイコンを表示させています。[新規タブ](../../../sample/sample1(Quill)/index.html?target=_blank)

![](fx.png?classes=d-inline,m-0) 数式記入例

	\left( \sum_{k=1}^n a_k^2 \right) \left( \sum_{k=1}^n b_k^2 \right)

<iframe width="100%" height="550" src="../../sample/sample1(Quill)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

## テーブル機能を追加（quill-better-table）

クイルのテーブルを改善するためのモジュールで、より便利な機能がサポートされています。

**codepenデモ**
[https://codepen.io/soccerloway/pen/WWJowj](https://codepen.io/soccerloway/pen/WWJowj)



### 使用法

#### JS、CSSの読み込み

<pre>
&lt;link href="css/quill.snow.min.css" rel="stylesheet"&gt;
<span class="text-danger">&lt;link href="css/quill-better-table.css" rel="stylesheet"&gt;</span><strong>追加</strong>
&lt;script src="js/quill.min.js" type="text/javascript"&gt;&lt;/script&gt;
<span class="text-danger">&lt;script src="js/quill-better-table.min.js"&gt;&lt;/script&gt;</span><strong>追加</strong>
</pre>

##### ES2015(ES6)


	/*import QuillBetterTable from 'quill-better-table' ←jsで読み込むので必要ない??*/

    Quill.register({
      'modules/better-table': QuillBetterTable
    }, true)

    window.onload = () => {
      const quill = new Quill('#editor-wrapper', {
        theme: 'snow',
        modules: {
          table: false,  // disable table module
          'better-table': {
            operationMenu: {
              items: {
                unmergeCells: {
                  text: 'Another unmerge cells name'
                }
              }
            }
          },
          keyboard: {
            bindings: QuillBetterTable.keyboardBindings
          }
        }
      })

      document.body.querySelector('#insert-table')
        .onclick = () => {
          let tableModule = quill.getModule('better-table')
          tableModule.insertTable(3, 3)
        }
    }

### モジュールメソッド
最初に、 quill.getModuleによってクイルベターテーブルモジュールを取得できます

<p class="tmp"><span>書式</span></p>

	let module = quill.getModule('better-table')

module.getTable（range = quill.getSelection（））
TableContainer、TableRow、TableCell、指定された範囲のオフセットを持つ配列を取得します。

#### module.getTable(range = quill.getSelection())
TableContainer、TableRow、TableCell、指定された範囲のオフセットを持つ配列を取得します。

<p class="tmp"><span>書式</span></p>

    module.getTable()  //標準 current selection
    module.getTable(range) //[TableContainer, TableRow, TableCell, 0]

#### module.insertTable（行：数値、列：数値）

現在の位置にテーブルを挿入

	module.insertTable(3, 3) 


### モジュールオプション
quill-better-tableは現在、操作オプションのみを提供します。

    const quill = new Quill('#editor', { 
        theme: 'snow',
        modules: { 
            table: false,
            'better-table': {
                operationMenu: {
                    items: {
                        unmergeCells: {
                            text: 'Another unmerge cells name'
                        }
                    },
                    color: {
                        colors: ['#fff', 'red', 'rgb(0, 0, 0)'],
                        text: 'Background Colors'
                    }
                }
            }, keyboard: {
                    bindings: QuillBetterTable.keyboardBindings
            }
        }
    })
    
#### operationMenu
OperationMenuは、右クリックメニューの操作リストを構成します。

#### operationMenu.items
operationMenuは、すべての操作をデフォルトとして表示します。 falseは操作を削除します。

<p class="tmp"><span>書式</span></p>

    items: {
        operationKey: {
            text: 'foo'
        }, operationKey: false
    } 
     
operationKeyはoperationKeyの名前です。以下のリストがあります。

* insertColumnRight
* insertColumnLeft
* insertRowUp
* insertRowDown
* セルを結合します
* unmergeCells
* deleteColumn
* deleteRow
* deleteTable

メニューテキストの変更が必要になる場合がありますが、 operationKey.text変更できます。

#### operationMenu.color
背景色はオプションで、デフォルトは非表示です。 この機能が必要な場合は、この構成を使用してください。

color: {
        colors: ['#fff', 'red', 'rgb(0, 0, 0)'], 
        text: 'Background Colors'
    } 


<div class="box-example" markdown="1">
### 例2 ### {.h-example}
quill-better-tableを使って、テーブルの機能を追加しています。insert tableボタンでテーブルを表示し、右クリックのリストからセルの追加が出来ます。[新規タブ](../../../sample/sample2(Quill)/index.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/sample2(Quill)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


<div class="box-example" markdown="1">
### 例3 ### {.h-example}
通常のツールバーにquill-better-tableの機能を追加しています。insert tableボタンだけを表示するようにしています。[新規タブ](../../../sample/sample3(Quill)/index.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/sample3(Quill)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

## 画像のリサイズの機能を追加（image-resize）

画像のサイズを変更できるQuillリッチテキストエディター用のモジュール。

また、 quillのコピー＆ペーストとドラッグ/ドロップを可能にするモジュールであるquill-image-drop-moduleも参照してください。

**codepen**
[https://codepen.io/knekk/pen/odwELZ](https://codepen.io/knekk/pen/odwELZ)

### 使い方

#### JS、CSSの読み込み
<pre>
&lt;link rel='stylesheet' href='css/quill.snow.css'&gt;
&lt;script src='js/jquery.min.js'&gt;&lt;/script&gt;
&lt;script src='js/quill.min.js'&gt;&lt;/script&gt;
<span class="text-danger">&lt;script src='js/image-resize.min.js'&gt;&lt;/script&gt;</span><strong>追加</strong>
</pre>

##### ES2015(ES6)

    const quill = new Quill(editor, {
        // ...
        modules: {
            // ...
            imageResize: {
                // See optional "config" below
            }
        }
    });
    
### 構成

デフォルトのエクスペリエンスでは、次のように空のオブジェクトを渡します。

    var quill = new Quill(editor, {
        // ...
        modules: {
            // ...
            ImageResize: {}
        }
    });
    
機能はモジュールに分割されており、お好きなように組み合わせることができます。 たとえば、デフォルトではすべてのモジュールが含まれます。

    const quill = new Quill(editor, {
        // ...
        modules: {
            // ...
            ImageResize: {
                modules: [ 'Resize', 'DisplaySize', 'Toolbar' ]
            }
        }
    });
    
***
    
各モジュールについて以下に説明します。

#### Resize -画像のサイズを変更します

画像の角にハンドルを追加し、マウスでドラッグして画像のサイズを変更できます。  
ルックアンドフィールはオプションで制御できます。

    var quill = new Quill(editor, {
        // ...
        modules: {
            // ...
            ImageResize: {
                // ...
                handleStyles: {
                    backgroundColor: 'black',
                    border: 'none',
                    color: white
                    // other camelCase styles for size display
                }
            }
        }
    });

#### DisplaySize表示ピクセルサイズ

画像の右下付近の画像のサイズをピクセル単位で表示します。  
ルックアンドフィールはオプションで制御できます。

    var quill = new Quill(editor, {
        // ...
        modules: {
            // ...
            ImageResize: {
                // ...
                displayStyles: {
                    backgroundColor: 'black',
                    border: 'none',
                    color: white
                    // other camelCase styles for size display
                }
            }
        }
    });

#### Toolbar -画像配置ツール

画像の下にツールバーを表示し、ユーザーは画像の配置を選択できます。  
ルックアンドフィールはオプションで制御できます。

    var quill = new Quill(editor, {
        // ...
        modules: {
            // ...
            ImageResize: {
                // ...
                toolbarStyles: {
                    backgroundColor: 'black',
                    border: 'none',
                    color: white
                    // other camelCase styles for size display
                },
                toolbarButtonStyles: {
                    // ...
                },
                toolbarButtonSvgStyles: {
                    // ...
                },
            }
        }
    });


#### BaseModule独自のカスタムモジュールを含める
BaseModuleクラスを拡張し、モジュールセットアップに含めることで、独自のモジュールを作成できます。

例えば

    import { Resize, BaseModule } from 'quill-image-resize-module';

    class MyModule extends BaseModule {
        // See src/modules/BaseModule.js for documentation on the various lifecycle callbacks
    }

    var quill = new Quill(editor, {
        // ...
        modules: {
            // ...
            ImageResize: {
                modules: [ MyModule, Resize ],
                // ...
            }
        }
    });


<div class="box-example" markdown="1">
### 例4 ### {.h-example}
Quill Image Resizeの機能のデモです。配置した画像を選択すると枠が表示され、サイズの調整ができます。[新規タブ](../../../sample/sample4(Quill)/index.html?target=_blank)

<iframe width="100%" height="750" src="../../sample/sample4(Quill)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>







