*[page-title]:Reactの利用


## React利用のプロジェクト

LaravelでReactを使うには、Herdでプロジェクト作成時に「React」スターターキットを選ぶだけで簡単に設定できます。  
これにより、Reactが組み込まれたLaravelプロジェクト（例：reactapp）が自動で構築され、すぐに開発を始められます。

いつものようにHerdの画面のメニューにから「Sites」を選択し、上部の「Add」をクリックします。次の画面で「New Laravel project」を選択し「Next」をクリックします。  
![](upload/Reactボタンを選択.png){.photo-border}

ここではプロジェクト名を「laravel_3rdReact」にしました。
![](upload/Raactプロジェクト名記入.png){.photo-border}


サイト
: http://laravel_3rdreact.test/

プロジェクトディレクトリ
: C:\xampp\htdocs\laravel_3rdreact

### Reactプロジェクトの構成

ReactをLaravelで使う場合、画面表示は以下の構成で作られます。

* **<span class="red">app.blade.php</span>**：Bladeのベースレイアウトで、Reactのエントリーポイントを読み込む。
* **<span class="red">app.tsx</span>**：Reactのベースコンポーネント。実際の表示はせず、ページコンポーネントを切り替える役割。
* **<span class="red">pages/フォルダー</span>**：個別のReactページコンポーネントを格納。

この3つの連携により、LaravelにReactを組み込んだ画面表示が実現されます。


### ルートの設定(トップページ)

ルート定義 web.php では、トップページ / にアクセスすると以下が実行されます。
<p class="tmp list"><span>リスト4-27</span>web.php</p>
```
Route::get('/', function () {
  return Inertia::render('welcome');
})->name('home');
```
この Inertia::render('Welcome') は、LaravelとReactを連携させるInertiaライブラリを使って、Welcome というReactページコンポーネントを表示する処理です。


## app.blade.phpのベースレイアウト

web.phpのRoute::get('/', ~)では、Inertia::render()でReactのページコンポーネントを表示しています。  
ただし、これはページの一部（コンテンツ）なので、全体のレイアウトが必要です。その役割を担うのがapp.blade.phpです。  
viewsフォルダにはこのテンプレートだけが用意されており、ページ全体の土台として使われています。

<p class="tmp list"><span>リスト4-28</span>views/app.blade.php（デフォルト）</p>
```
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" @class(['dark' => ($appearance ?? 'system') == 'dark'])>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        {{-- Inline script to detect system dark mode preference and apply it immediately --}}
        <script>
            (function() {
                const appearance = '{{ $appearance ?? "system" }}';

                if (appearance === 'system') {
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

                    if (prefersDark) {
                        document.documentElement.classList.add('dark');
                    }
                }
            })();
        </script>

        {{-- Inline style to set the HTML background color based on our theme in app.css --}}
        <style>
            html {
                background-color: oklch(1 0 0);
            }

            html.dark {
                background-color: oklch(0.145 0 0);
            }
        </style>

        <title inertia>{{ config('app.name', 'Laravel') }}</title>

        <link rel="icon" href="/favicon.ico" sizes="any">
        <link rel="icon" href="/favicon.svg" type="image/svg+xml">
        <link rel="apple-touch-icon" href="/apple-touch-icon.png">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        @routes
        @viteReactRefresh
        @vite(['resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"])
        @inertiaHead
    </head>
    <body class="font-sans antialiased">
        @inertia
    </body>
</html>
```

app.blade.phpのコードはシンプルですが、InertiaとReact連携用のディレクティブが含まれています。  
`<head>`には、<span class="bold green">@routes</span>、<span class="bold green">@viteReactRefresh</span>、<span class="bold green">@vite(...)</span>、<span class="bold green">@inertiaHead</span>があり、必要なスクリプトやReactのコンポーネントを読み込む役割を担います。  
```
@routes
@viteReactRefresh
@vite(['resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"])
@inertiaHead
```

`<body>`の<span class="bold red">@inertia</span>は、Inertia::renderで指定されたReactコンポーネントを表示する場所です。表示処理はこれだけで完結します。
<pre><code class="language-html hljs xml"><span class="hljs-tag">&lt;<span class="hljs-name">body</span> <span class="hljs-attr">class</span>=<span class="hljs-string">"font-sans antialiased"</span>&gt;</span>
    <span class="marker-yellow">@inertia</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">body</span>&gt;</span></code></pre>

### なぜ、appがデフォルトページか?

アプリアクセス時にデフォルトでapp.blade.phpが表示されるのは、app/Http/Middleware/HandleInertiaRequests.phpミドルウェアがInertiaの設定を行っているためです。  
HandleInertiaRequestsミドルウェアでは、<span class="marker-yellow50">$rootViewに'app'</span>が指定されており、その設定によって<span class="bold red">app.blade.php</span>がアプリのベーステンプレートとして自動的に使われます。


<p class="tmp list"><span>リスト4-29</span>app/Http/Middleware/HandleInertiaRequests.php（デフォルト）</p>
<pre><code class="hljs php"><span class="hljs-meta">&lt;?php</span>

<span class="hljs-keyword">namespace</span> <span class="hljs-title">App</span>\<span class="hljs-title">Http</span>\<span class="hljs-title">Middleware</span>;

<span class="hljs-keyword">use</span> <span class="hljs-title">Illuminate</span>\<span class="hljs-title">Foundation</span>\<span class="hljs-title">Inspiring</span>;
<span class="hljs-keyword">use</span> <span class="hljs-title">Illuminate</span>\<span class="hljs-title">Http</span>\<span class="hljs-title">Request</span>;
<span class="hljs-keyword">use</span> <span class="hljs-title">Inertia</span>\<span class="hljs-title">Middleware</span>;
<span class="hljs-keyword">use</span> <span class="hljs-title">Tighten</span>\<span class="hljs-title">Ziggy</span>\<span class="hljs-title">Ziggy</span>;

<span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">HandleInertiaRequests</span> <span class="hljs-keyword">extends</span> <span class="hljs-title">Middleware</span>
</span>{
  <span class="hljs-keyword">protected</span> <span class="marker-yellow">$rootView = <span class="hljs-string">'app'</span></span>;

  <span class="hljs-keyword">public</span> <span class="hljs-function"><span class="hljs-keyword">function</span> <span class="hljs-title">version</span><span class="hljs-params">(Request $request)</span>: ?<span class="hljs-title">string</span>
  </span>{
    <span class="hljs-keyword">return</span> <span class="hljs-keyword">parent</span>::version($request);
  }

  <span class="hljs-keyword">public</span> <span class="hljs-function"><span class="hljs-keyword">function</span> <span class="hljs-title">share</span><span class="hljs-params">(Request $request)</span>: <span class="hljs-title">array</span>
  </span>{
    [$message, $author] = str(Inspiring::quotes()-&gt;random())-&gt;explode(<span class="hljs-string">'-'</span>);

    <span class="hljs-keyword">return</span> [
      ...<span class="hljs-keyword">parent</span>::share($request),
      ……略……
    ];
  }
}</code></pre>

## Reactコンポーネントの内容

では、ページに埋め込まれるReactコンポーネントを見てみましょう。まずは、ベースとなっている app.tsxです。これは以下のように記述されています。

<p class="tmp list"><span>リスト4-30</span>resources/js/app.tsx（デフォルト）</p>
```
import '../css/app.css';

import { createInertiaApp } from '@inertiajs/react';
import { resolvePageComponent } 
  from 'laravel-vite-plugin/inertia-helpers';
import { createRoot } from 'react-dom/client';
import { initializeTheme } from './hooks/use-appearance';

const appName = import.meta.env.VITE_APP_NAME || 'Laravel';

createInertiaApp({
  title: (title) => `${title} - ${appName}`,
  resolve: (name) => resolvePageComponent(
    `./pages/${name}.tsx`, 
    import.meta.glob('./pages/**/*.tsx')),
  setup({ el, App, props }) {
    const root = createRoot(el);

    root.render(<App {...props} />);
  },
  progress: {
    color: '#4B5563',
  },
});

// This will set light / dark mode on load...
initializeTheme();
```

createInertiaApp関数は、ReactとInertiaの連携設定を行い、resolveでページ名に対応するpages内の.tsxコンポーネントを読み込みます。  

例えばトップページでは、ルート設定によりWelcomeが渡され、Welcome.tsxが表示されます。

### Welcomeコンポーネントをチェックする

Welcome.tsxはReactの基本的な関数コンポーネントで、JSXでHTMLを返します。  
pagesフォルダー内のコンポーネントはすべて通常のReactコンポーネントであり、ここに追加すればapp.tsxを通してページとして表示されます。

<p class="tmp list"><span>リスト4-31</span>resources/js/pages/welcome.tsx（デフォルト）</p>
```
import { type SharedData } from '@/types';
import { Head, Link } from '@inertiajs/react';

export default function Welcome() {
  const { auth } = usePage<SharedData>().props;

  return (
    <>
      <Head title="Welcome">
        ……略……
      </Head>
      <div className="……">
        ……略……
     </div>
    </>
  );
}
```

## Reactコンポーネントを表示する

では、実際にReactコンポーネントを作成してみましょう。

Reactの「hello.tsx」コンポーネントを「pages」フォルダー内に作成し、HeadでHTMLタイトルを設定、本文にメッセージを表示します。  
web.phpで/helloルートをInertia::render('hello')に割り当てることで、アクセス時にこのコンポーネントが表示されます。  
（またビルドしてないので表示されません。）

<p class="tmp list"><span>リスト4-32</span>pages/hello.tsx</p>
```
import { JSX } from 'react';
import { Head } from '@inertiajs/react';

export default function Hello(): JSX.Element {
  return (
    <>
      <Head title="Hello" />
      <div className="p-10">
        <h1 className="text-3xl pb-5">Hello!</h1>
        <p className="text-lg">
          これはReactのコンポーネントです。
        </p>
      </div>
    </>
  );
}
```

<p class="tmp list"><span>リスト4-33</span>web.php</p>
```
Route::get('/hello', function () {
  return Inertia::render('hello');
});
```

### ビルドと表示

Reactコンポーネントを利用するには、npm run buildでビルドが必要です。

npmはNode.jsに内蔵されたパッケージ管理ツールで、Reactもこれで管理されます。  
ビルドによりコンポーネントがコンパイルされ、アプリで使えるJavaScriptコードになります。

<p class="tmp cmd"><span>コマンド</span>ビルド</p>
```
npm run build
```
![](upload/helloのビルド実行.png)

ビルドが完了したので、/helloにアクセスしてください。作成したHelloコンポーネントが表示されるでしょう。
![](upload/reactでhello表示.png){.photo-border}


## ステートを利用する

これで、Reactコンポーネントの使い方がわかりました。では、もう少しReactコンポーネントの基本的な機能を試してみましょう。Reactの基本といえば、ステートですね。では、
hello.tsxを書き換え、ステートを利用するようにしてみましょう。

<p class="tmp list"><span>リスト4-34</span>pages/hello.tsx</p>
```
import { JSX, useState } from 'react';
import { Head } from '@inertiajs/react';

export default function Hello(): JSX.Element {
  const [inputValue, setInputValue] = useState('');
  const [message, setMessage] = useState('Hello!!');
  
  // フォーム送信時の処理
  const handleSubmit = (e:{preventDefault:()=>void;})=>{
    e.preventDefault();
    setMessage('こんにちは、' + inputValue + 'さん！');
  };

  return (
    <div style={{padding: '20px'}}>
      <Head title="Hello" />
      <h1 style={{
        fontSize:'30px', paddingBottom:'10px'
      }}>Hello Page</h1>
      <p style={{
        fontSize:'20px'
      }}>{message}</p>
      <form onSubmit={handleSubmit} 
          style={{ marginTop: '20px' }}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="名前を入力"
          style={{ 
            padding:'8px', fontSize:'16px', width:'300px'
          }}
        />
        <button type="submit" style={{
          padding:'8px 16px', marginLeft:'10px', 
          background:'blue', color:'white',
        }}>
          送信
        </button>
      </form>
    </div>
  );
};
```

修正が済んだら、npm run buildを実行して、/helloにアクセスしてください。
![](upload/HelloPage表示.png){.photo-border}
名前を記入して送信。
![](upload/木村タロー記入.png){.photo-border}
記入した名前が表示されます。
![](upload/木村タロー記入送信後表示.png){.photo-border}


### ステートをチェック

では、コードを見てみましょう。ここでは、2つのステートが用意されています。以下の部分です。
```
const [inputValue, setInputValue] = useState('');
const [message, setMessage] = useState('Hello !! ');
```

この inputValue は入力フィールドの値を管理し、messageは表示メッセージを管理します。入力フィールドの`<input>`を見ると、以下のように記述されています
```
<input

type="text"
value={inputValue}
onChange={(e) => setInputValue(e.target.value)}
```

valueにinputValueを設定し、onChangeでその値をsetInputValueにより更新しています。

そしてフォームでは、以下のようにしてフォーム送信の設定をしています。
```
<form onSubmit={handleSubmit}
```

これでフォーム送信時にはhandleSubmitが呼び出されるようになります。では、このhandleSubmitではどのような処理を行っているでしょうか。
```mk
const handleSubmit = (e:{preventĐefault:()=>void;}) => {
	e.preventĐefault();
	setMessage('こんにちは、'+inputValue +'さん!’);
	
};
```

preventDefaultでフォーム送信イベントを消費し、それからsetMessageでmessageを更新しています。これでメッセージの内容が新しくなります。  
ざっと見ればわかるように、ステート関係ではReactの機能がそのまま動作していることがわかります。Laravel内で動いていることをまったく感じさせません。

<!--
handleSubmitはフォーム送信を防ぎ、setMessageでメッセージを更新し、Reactのステート機能がLaravel内でもそのまま動作しています。
-->

## Laravelバックエンドとの通信

LaravelとReactを連携させるには、Laravel側にAPIを作成し、Reactからアクセスしてデータを送受信します。

web.phpを開き、以下のコードを追記してください。

<p class="tmp list"><span>リスト4-35</span>web.php</p>
```
Route::post('/update-message', function () {
    $max = request()->number;
    $total = 0;
    for ($i = 0;$i <= $max;$i++) {
        $total += $i;
    }
    return response()->json(['message'=>'total: ' . $total]);
});
```

Laravelで/update-message APIを作成し、request()->numberで送信された値を取得して合計を計算し、response()->json()で['message' => 'total:'.$total]をJSONとして返し、クライアントはmessageを利用します。


### Helloコンポーネントを修正する

では、APIを利用するようにコンポーネントを修正しましょう。Hello.tsxを開き、以下のようにコードを書き換えてください。

<p class="tmp list"><span>リスト4-36</span>hello.tsx</p>
```
import React, { JSX, useState } from 'react';
import { Head } from '@inertiajs/react';
import axios from 'axios';

export default function Hello(): JSX.Element {
  const [inputValue, setInputValue] = useState(0);
  const [serverMessage, setServerMessage] 
      = useState('type a number:');

  // フォーム送信時の処理
  const handleSubmit = (e:{preventDefault:()=>void;}) => {
    e.preventDefault();
    axios.post('/update-message', { number: inputValue })
      .then(response => {
        console.log(response);
        setServerMessage(response.data.message);
      })
      .catch(error => {
        console.error('Error updating message:', error);
      });
  };

  return (
    <div style={{padding: '20px'}}>
      <Head title="Welcome" />
      <h1 style={{
        fontSize:'30px', paddingBottom:'10px'
      }}>Welcome Page</h1>
      <p style={{
        fontSize:'20px'
      }}>{serverMessage}</p>
      <form onSubmit={handleSubmit} style={{
        marginTop: '20px'
      }}>
        <input
          type="number"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="新しいメッセージを入力"
          style={{
            padding:'8px', fontSize:'16px', width:'300px'
          }}
        />
        <button type="submit" style={{
          padding:'8px 16px', marginLeft:'10px', 
          background:'blue', color:'white',
        }}>
          送信
        </button>
      </form>
    </div>
  );
};
```

修正したらnpmコマンドでビルドし、/helloにアクセスしましょう。整数を入力してボタンをクリックすれば、ゼロからその数字までの合計が計算し得られます。
![](upload/1234を入力して送信.png){.photo-border}

### axiosによるAPIアクセス

handleSubmitでは、React標準搭載のHTTP通信ライブラリaxiosを使ってAPIアクセスを行っています。

> axiosは、JavaScriptからHTTPアクセスを行うためのライブラリで、さまざまなフレームワークで使われています。  
> React のプロジェクトにも標準で組み込まれており、クライアントからバックエンドへの通信は axiosを利用するのが基本となっています。

```
axios.post('/update-message', { number: inputValue })
  .then(response => {
    console.log(response);
    setServerMessage(response.data.message);
  })
  .catch(error => {
    console.error('Error updating message:', error);
  });
```

これは整理すると、以下のように実行していることがわかります。
```
axios.post(アクセス先,渡す値).then(完了後の処理).catch(エラー処理);
```

完了後はsetServerMessageでメッセージ更新、エラー時はconsole.errorで出力します。  

axiosは使いやすく、Reactでは基本的な使い方を覚えておくべきです。