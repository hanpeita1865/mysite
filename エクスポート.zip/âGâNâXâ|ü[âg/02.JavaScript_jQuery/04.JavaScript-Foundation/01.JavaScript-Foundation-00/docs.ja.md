---
title: '01. 概略'
taxonomy:
    category:
        - docs
visible: true
---

<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
<style>
	h1 span{font-family:'Fjalla One',sans-serif;font-weight:normal;margin-right:10px;}
	h2{font-size:1.8rem;font-weight:bold;letter-spacing:.02rem;}
	h3{font-size:1.2rem;font-weight:bold;letter-spacing:.01rem;margin-bottom:10px;}
	h3::before{content:"★";color:#d3ac3f;margin-right:5px;}
	p{letter-spacing:.05rem;}
	ul{letter-spacing:.05rem;}
	pre{background:#242424;margin:10px 0 80px 0;}
</style>
---

<h2 class="h-type2">JavaScriptとは</h2>
ブラウザで実行されるクライアントプログラム。HTMLの操作がおもな役割。  

---

<h2 class="h-type2">JavaScriptの機能</h2>
* HTML要素の操作
* 実行条件の指定
* webサーバとの通信

などがあります。

---

<h2 class="h-type2">JavaScriptとjQueryの違い</h2>
JavaScriptコードをより容易に記述できるようにするために設計された軽量なJavaScriptライブラリがjQueryです。  
jQueryで実現できることはJavaScriptでも実現が可能です。

---

<h2 class="h-type2">JavaScriptを使うには</h2>
JavaScriptのコードはHTMLファイルに直接記述するか、別ファイルに記述してHTMLファイルから読み込んで実行します。

<!--
## jQueryを使うには
以下のサンプルのようにHTMLファイルのscriptタグから読んであげます。  
jQueryファイルを読み込むことで、同じくHTMLから読み込んでいるjsファイル内でjQueryが使えるようになります。
### ダウンロードする場合
```
<html>
	<head>
		<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
	</head>
	<body>
		<script type="text/javascript" src="js/main.js"></script>
	</body>
</html>
```
### ダウンロードしない場合（CDNにホストされているjQueryファイルの読み込み）
```
<html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	</head>
	<body>
		<script type="text/javascript" src="js/main.js"></script>
	</body>
</html>
```
-->