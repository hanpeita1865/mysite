*[page-title]:MySQL操作

<!--
## カラムを追加する

<p class="tmp"><span>書式1</span>ALTER TABLE ~ ADD</p>

```
ALTER TABLE テーブル名 ADD 新規カラム名 型情報 オプション;
```
テーブルにカラムを追加するには、テーブルの構造を変更する「ALTER TABLE」を使います。  
例えば「user」テーブルに対して、NULLを許可しない「nickname」というカラムを追加する場合は以下のようになります。
```
ALTER TABLE user ADD nickname varchar(255) NOT NULL;
```

## 追加するカラムの順序を指定する

また、追加するカラムの位置を指定することもできます。位置の指定には、「AFTER」と「FIRST」を使います。

<p class="tmp"><span>書式2</span>～AFTER～,～FIRST</p>
```
ALTER TABLE テーブル名 ADD 新規カラム名 型情報 AFTER 既存カラム名;
ALTER TABLE テーブル名 ADD 新規カラム名 型情報 FIRST;
```

```
ALTER TABLE compatible ADD comp_server_remarks varchar(300) AFTER comp_server;
```

「FIRST」を使えば一番の最初のカラムに、「AFTER」を使えば指定カラムの後に新規カラムが追加されます。

## 複数カラムを一括で追加する

さらに、括弧でくくることで複数のカラムを一括で追加することもできます。
<p class="tmp"><span>書式3</span>一括追加</p>
```
ALTER TABLE テーブル名 ADD (新規カラム名１ 型情報, 新規カラム名２ 型情報, ...);
```

追加するカラムは括弧でくくられ、カンマ「,」区切りで複数記述できます。  
「user」テーブルに、「mail」と「tel」の２つを追加する場合は以下のようなクエリになります。
```
ALTER TABLE user ADD (mail text, tel tinytext);
```

また、追加されたカラムは「ALTER TABLE ~ CHANGE」で名前や型情報を変更することもできます。
-->

## データベースを登録

試しに、shop1という名前のデータベースを作成してみます。  
ユーザ名「staff」、パスワード「password」で設定し、「localhost」に設置します。

<p class="tmp sql"><span>SQL文</span>shop1.sql</p>
```
drop database if exists shop1;
create database shop1 default character set utf8 collate utf8_general_ci;
grant all on shop1.* to 'staff'@'localhost' identified by 'password';
use shop1;
```

phpMyAdminのSQLのパネルに上記のコードを貼り付けて実行ボタンを押すと、名前が「shop1」で空のデータベースが作成されます。

![](upload/shop1データベースをSQLで作成.png){.photo-border}
　↓
![](upload/shop1データベース作成完了.png){.photo-border}


### データベース作成コードの解説

#### データベースの削除

shop1.sqlの最初は、shop1データベースが既に存在する場合に、shop1データベースを削除する処理です。
<p class="tmp sql"><span>SQL文</span>shop1データベース削除</p>
```
drop database if exists shop1;
```

<div markdown="1" class="tmp-box">
<span class="red">drop database</span>は、データベースを削除するSQLのコマンド(命令)です。<span class="red">if exists</span>は、「指定するデータベースが存在する場合に」という条件を表します。

<p class="tmp"><span>SQL書式</span>データベース削除</p>
```
drop database if exists データベース名;
```

</div>
#### データベースの作成

次に、shop1データベースを作成します。
<p class="tmp sql"><span>SQL文</span>shop1データベース作成</p>
```
create database shop1 default character set utf8 collate utf8_general_ci;
```

<div markdown="1" class="tmp-box">
「<span class="red">create database</span>」は、データベースを作成するコマンドです。続けて指定する名前で、デー タベースを作成します。  
「<span class="red">default character set</span>」は、データベースで用いる文字コードを表します。ここではUTF-8 を表す「utf8」を指定します。  
「<span class="red">collate</span>」は、データベースにおいて行を並べる順番を決めるための方式を表します。  
ここでは UTF-8を用いた方式の1つである、「`utf8_general_ci`」 を指定します。

※MySQLにおけるcollateの 詳細は、「[http://dev.mysql.com/doc/refman/5.6/ja/charset-collations.html](http://dev.mysql.com/doc/refman/5.6/ja/charset-collations.html)」などに記載さ れています。

<p class="tmp"><span>SQL書式</span>データベース作成</p>
```
create database データベース名 default character set utf8 collate utf8_general_ci;
```

</div>
#### ユーザーの作成
続いて、shop1データベースを使用するためのユーザーを作成します。  
ここでは「localhost」というホストにおける「staff」というユーザー、「password」というパスワードを指定しています。  
<p class="tmp sql"><span>SQL文</span>shop1用ユーザーの作成</p>
```
grant all on shop1.* to 'staff'@'localhost' identified by 'password';
```

<div markdown="1" class="tmp-box">
「<span class="red">grant</span>」は、ユーザーに対してデータベースを操作する権限を与えるためのコマンドです。  
指定 したユーザーが存在しない場合には、新たにユーザーの作成も行います。 
上記のSQL文では、all on shop1.* は、 shop1データベースの全てのテーブルに対して、全ての権限を与えることを表します。
to以下は、ユーザー名とホスト名です。  
staffというユーザーが既に存在する場合は権限を設定し、存在 しない場合は、新規にユーザーを追加すると同時に権限を設定します。  
<span class="red">identified by</span>以下は、ユーザーがデータベースにログインするためのパスワードです。

<p class="tmp"><span>SQL書式</span>権限を設定</p>
```
grant all on データベース名.* to 'ユーザー名'@'ホスト名' identified by 'パスワード';
```
</div>

#### データベースへの接続
最後に、作成したshop1データベースに接続します。 

<p class="tmp sql"><span>SQL文</span>データベースへ接続</p>
```
use shop1;
```
「<span class="red">use</span>」は、データベースに接続するためのコマンドです。ここではshop1データベースに接続します。  




## テーブルを作成

カラムに、「id、name、price」があるテープル「products」を作成します。
<p class="tmp sql"><span>SQL文</span>テーブル作成</p>
```
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
)
```
<div markdown="1" class="memo-box">
##### プライマリーキー（主キー：PRIMARY KEY）とは
リレーショナルデータベース（RDB）において、行（レコード）を一意に識別するために利用する列（カラム）です。重複することなく、NULL値も持たないため、各レコードの識別に適しています。
</div>

実行すると、データベースshop1の中にproductsテーブルが作成されました。idカラムにはプライマリーキーが設定されています。  


![](upload/prodcts_table.png){.photo-border}


### データの追加

<p class="tmp"><span>SQL書式</span>データ追加</p>
```
insert into テーブル名 values (列1の値, 列2の値, ...)
```

nameとpriceに「りんご、100」と「みかん、80」のデータを追加してみます。  
下記のコードを入力して実行します。  
<p class="tmp sql"><span>SQL文</span>複数レコード追加</p>
```
INSERT INTO products(name, price) VALUES('りんご', 100), ('みかん', 80);
```

productsテーブルにデータが追加されました。
![](upload/insert1.png "図　りんごとみかんのレコード追加"){.photo-border}

レコードをひとつだけ追加する場合は、次のように記入すれば追加できます。
<p class="tmp sql"><span>SQL文</span>一つのレコードを追加</p>
```
INSERT INTO products values(null, 'すいか', 250);
```
![](upload/すいか、250を追加.png "図　すいかのレコードのみ追加"){.photo-border}

id値は自動的に割り振られます。これはidカラムに「AUTO_INCREMENT」が設定されているためです。
![](upload/idにAUTO_INCREMENT.png "図　テーブル構造"){.photo-border}


### 検索する

<span class="bold green">where句</span>は、SQLのselect文において検索の条件を指定する機能です。whereに続けて条件式を記述します。例えば、name列が「みかん」である行を検索するには、次のように書きます。
```
where name='みかん'
```

「<span class="red">=</span>」は比較を行うSQLの演算子です。この例では、nameとみかんが等しいかどうかを調べます。等しければ、条件が成立したことになります。  


<p class="tmp"><span>SQL書式</span>where</p>
```
where 列名='検索キーワード'
```

商品名の「みかん」で検索してみます。
<p class="tmp sql"><span>SQL文</span></p>
```
select * from products where name='みかん';
```

テーブルに商品名がみかんのレコードが表示されます。
![](upload/みかんで検索.png "図　name値をみかんで検索結果"){.photo-border}

id値で検索してみます
<p class="tmp sql"><span>SQL文</span></p>
```
select * from products where id=3;
```

id値 3のレコードが表示されます。
![](upload/id値で検索結果.png  "図　id値3の検索結果"){.photo-border}


### 部分一致で検索

商品名などを部分一致で商品を検索することができます。
<p class="tmp"><span>SQL書式</span>部分一致検索</p>
```
select * from テーブル名 where カラム名 like '%検索文字/%';
```

たとえば、次のproductsテーブルで生産地を「山」で検索すると、生産地が和歌山と山形のレコードが抽出されます。
<p class="tmp sql"><span>SQL文</span></p>
```
select * from products where local like '%山%';
```
![](upload/productsテーブル7レコード.png){.figure-none .d-block .border .mt-3}
　↓
![](upload/生産地を山で検索.png  "図　生産地に山がつくレコード抽出"){.photo-border}

### データの更新

<p class="tmp"><span>SQL書式</span>update</p>
```
update テーブル名 set 列名=値 where 列名=値
```

更新するレコードを指定するには、次のようにwhere句を記述します。この場合は、idが2の「みかん、80」を「もも、900」に更新してみます。

<p class="tmp sql"><span>SQL文</span>データ更新</p>
```
update products set name='もも', price=900 where id=2
```
データが更新されました。

![](upload/もも、900に更新.png "図　データ更新後"){.photo-border}



### データを削除する

<p class="tmp"><span>SQL書式</span>delete</p>
```
delete from テーブル名 where 列名=値
```

1行目のりんごがあるレコードを削除する場合は、以下のように記述します。
<p class="tmp sql"><span>SQL文</span></p>
```
delete from products where id=1
```

id=1のデータが削除されました。
![](upload/レコードりんご削除.png "図　データ削除後"){.photo-border}


<div markdown="1" class="memo-box">
##### <span class="blue">SQLインジェクション</span>
SQLインジェクションとは、開発者が意図しないSQLスクリプトを実行させることにより、データベースを不正に操作することです。  
SQLインジェクションは、スクリプトに適切なセキュリティ対策を施すことによって防止することができます。注意すべきなのは、ユーザーが入力した情報をSQL文に含める場合です。例えば以下の例では、ユーザーが入力した商品名をSQLスクリプトに含めています。
```
select * from product where name like ?
```
また以下の例では、ユーザーが入力した商品名や価格を、SQL文に含めています。
```
insert into product values(null, ?, ?)
```
このようにユーザーの入力情報をSQL文に含めるときには、単純に文字列として結合してはいけません。ユーザーの入力情報に悪意のあるSQL文が含まれていると、データベースの不正な操作を許してしまう可能性があります。 

PDOを使用する場合には、<span class="red">prepareメソッド</span>と<span class="red">executeメソッド</span>を使用することが、SQLインジェクションの防止になります。SQL文に値を埋め込む際には、文字列を結合してSQL文を作成するのではなく、これらのメソッドを使用してください。
</div>



## 参考サイト

* [テーブルに格納されているデータの編集と削除](https://www.javadrive.jp/phpmyadmin/data/index2.html)