<?php
print_r($_POST['data']);
$data = $_POST['data'];

// $json = json_encode($_REQUEST['data'], JSON_UNESCAPED_UNICODE); //json形式に変換

file_put_contents('data.json', $data); //ファイルに出力





