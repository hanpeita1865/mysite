*[page-title]:Chap4-3 スケジューラーで定期的なバッチ処理を行う

<span class="bold green">Chap4-3 完成品</span>
* \\wsl.localhost\Ubuntu-24.04\root\example-app14
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>　データベース名は「example_app5」にしてます。
* ユーザー名「y-hirao@cc22.ne.jp」、パスワード「ryouma0305」
* MailPit <http://localhost:8025/>

---
メモ
: 編集や削除のリンクをクリックしても遷移しないのは、details summaryタグのbeforeのスタイルに問題があるようなので、下記のスタイルをコメントアウトしました。そうすると、編集画面や削除画面に遷移できるようになった。
![](upload/tweet-optionコード.png "resources\views\components\tweet\options.blade.php"){.fig-top}

---
ここではLaravelのスケジューラーの機能について見ていきます。 スケジューラーを使うと特定の時間に特定の処理を実行することができます。


## スケジューラーを利用する

スケジューラーはユーザーのアクセスとは直接関係のない処理を実行する時に便利です。たとえば次のような用途でよく使われます。

<div markdown="1" class="green-box">
* 毎分データを他のサービスに同期する
* 毎時特定のユーザーにメールを送る
* 毎日データを集計してデータベースを更新する
</div>

またスケジューラーでは、処理一つ一つを「コマンド」という単位で管理していくと便利なので、まずはコマンドの作り方について見ていきましょう。

### Laravelのコマンドを作成する

Laravelにはコマンドを作って実行する機能があります。  
これまでもmigrationコマンドやtinkerコマンドなど、複数のコマンドを使ってきました。Laravelではこのコマンドを自作することができます。
まずは「<span class="red">SampleCommand</span>」というコマンドを作ってみましょう。

<p class="tmp cmd"><span>コマンド</span>コマンドを自作</p>
```
sail artisan make:command SampleCommand
```
![](upload/コマンドを自作.png)

これでapp/Conssole/Commands以下に「SampleCommand」というクラスが作られます。

![](upload/SampleCommand.php作成.png){.photo-border}

<p class="tmp list"><span>リスト</span>app/Console/Commands/SampleCommand.php（デフォルト）</p>
```
<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class SampleCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:sample-command';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        //
    }
}
```

$signnatureの部分にコマンドの名前、$descriptionの部分にコマンドの説明文を書きます。
またhandleの部分にコマンドの実処理を書いていきます。


<p class="tmp list"><span>リスト</span>app/Console/Commands/SampleCommand.php</p>
```
<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class SampleCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sample-command';//変更

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sample Command';//変更

    /**
     * Create a new command instance.
     *
     * @return void
     */
    //追加
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        //追加
        echo 'このコマンドはサンプルです。';
        return 0;
    }
}
```
コマンドを作ったら、コマンド一覧を表示してみましょう。
Laravelが提供しているコマンドに加え、さきほど作ったsample-commandも表示されます。

<p class="tmp list"><span>リスト</span>コマンド一覧表示</p>
```
sail artisan list
```
![](upload/コマンド一覧を表示.png "コマンド一覧")

「<span class="red">sample-command</span>」を実行してみましょう。

<p class="tmp cmd"><span>コマンド</span>自作コマンド実行</p>
```
sail artisan sample-command
```
次のように表示されるはずです。
![](upload/sample-command実行.png)

## スケジューラーを実行する

コマンドの作り方がわかったら、次にスケジューラーを使ってみましょう。次の2つの手順でスケジューラーを動かして行きます。

1. いつ、何のコマンドを実行するか、スケジューラーに登録する
2. スケジューラーを実行する

スケジューラーの実行の仕方にはいろいろな方法があります。今回はスケジューラーの実行自体もコマンド経由で実行しますが、本番のサービスを提供する場合には、常にスケジューラーを実行するために他の手段が必要になります。

### スケジューラーに登録する

Laravelのスケジューラーに実行内容を登録していきます。「<span class="red">app/Console/Kernel.php</span>の<span class="red">scheduleメソッド</span>」に登録内容を記述していきます。

<p class="tmp list"><span>リスト</span>app/Console/Kernel.php</p>
```
<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // 追加				
        // 毎分
        $schedule->command('sample-command')->everyMinute();
        // 毎時
        $schedule->command('sample-command')->hourly();
        // 毎時8分
        $schedule->command('sample-command')->hourlyAt(8);
        // 毎日
        $schedule->command('sample-command')->daily();
        // 毎日13時
        $schedule->command('sample-command')->dailyAt('13:00');
        // 毎日3:15(cron表記)
        $schedule->command('sample-command')->cron('15 3 * * *');
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
```

今回は先ほどのsample-commandをさまざまな方法で登録してみました。毎分、毎時、毎日といった便利な関数もありますし、cronフォーマットで記述することもできます。今回は先ほどのsample-commandをさまざまな方法で登録してみました。毎分、毎時、毎日といった便利な関数もありますし、cronフォーマットで記述することもできます。


実際に登録されているスケジュールはschedule:listコマンドで確認することができます。

<p class="tmp cmd"><span>コマンド</span>スケジュール確認</p>
```
sail artisan schedule:list
```

![](upload/スケジュール確認.png "スケジュール")

ここで注意したいのはタイムゾーンの設定です。デフォルトではUTC(協定世界時)になっているので、登録したスケジュールを日本時間で実行するにはタイムゾーンの設定を変更する必要があります。「**config/app.php**」ファイルの**timezone**を<span class="red">Asia/Tokyo</span>に変更します。

![](upload/config_app_timezone変更前.png "timezone変更前")
↓

config/app.php（変更後）
```
    */

    'timezone' => 'Asia/Tokyo',

    /*
```


### スケジューラーを実行する

スケジュールを登録したので、早速実行してみましょう。  
Laravelにはスケジュールを実行するコマンドも用意されています。次のコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span>スケジュール実行</p>
```
sail artisan schedule:run
```

![](upload/スケジュール実行.png)

schedule:runでは、スケジューラーを起動し、スケジュールされたコマンドを1つだけ実行したらスケジューラーを終了します。「Running ['artisan' sample-command]」と表示されれば成功です。  
しかし、スケジューラーの出力はデフォルトだと/dev/nullに捨てられているので、コマンドによって実際にテキストが表示されたかどうかはわかりません。これだと困るので、スケジューラーにはスケジュールの実行結果の出力先を設定する機能があります。  
今回はメールでスケジュールの結果を送信するようにしてみましょう。毎日実行されるコマンドの実行結果をメールで送信というのは、実際にもよくあるケースです。  
今回は機能を試すために毎分のスケジュールにメール送信を追加してみます。

<p class="tmp list"><span>リスト</span>app/Console/Kernel.php</p>
```
<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // 毎分
        $schedule->command('sample-command')->everyMinute()
            ->emailOutputTo('info@example.com');
    }
	～省略～
}
```

再度、コマンドを実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan schedule:run
```
![](upload/再度スケジュール実行.png)

MailPitでメールを確認してみましょう。
![](upload/MailPitでメールを確認1.png)

　　↓

本文を開いてみると、次のようになっています。本文内に「このコマンドはサンプルです。」とあれば成功です。
![](upload/MailPitでメールを確認本文.png)

## 前日のつぶやきのハイライトをメールで送る

では、より実践的な機能として、前の日に投稿されたつぶやきの数を集計して、ユーザーにメールで送信する機能を作ってみましょう。  
まずはつぶやきの数を集計して、メールをユーザーに送信するコマンドを作成します。


### メールを作成する

最初に送信するメールのクラスを作ります。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:mail DailyTweetCount
```

![](upload/送信するメールのクラス作成.png)

「app/Mail/DailyTweetCount.php」 が生成されます。

![](upload/DailyTweetCount.php作成.png)

次のように変更しましょう。

<p class="tmp list"><span>リスト</span>app/Mail/DailyTweetCount.php</p>
```
<?php

namespace App\Mail;

use App\Models\User;//追加
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class DailyTweetCount extends Mailable implements ShouldQueue {//「implements ShouldQueue」追加
    use Queueable, SerializesModels;

    public User $toUser;//追加
    public int $count;//追加

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(User $toUser, int $count){ //「User $toUser, int $count」 追加
        $this->toUser = $toUser;//追加
        $this->count = $count;//追加
    }

    public function content(): Content
    {
        return new Content(
            markdown: 'email.daily_tweet_count',//変更
        );
    }
		
    ～省略～
}
```

次に、 メールクラスから呼び出すメールのviewをMarkdown形式で書いていきます。resources/views/emailフォルダにdaily_tweet_count.blade.phpを作成して、次を記述しましょう。

<p class="tmp list"><span>リスト</span>resources/views/email/daily_tweet_count.blade.php</p>
```
@component('mail::message')

{{ $toUser->name }}さんこんにちは！

昨日は{{ $count }}件のつぶやきが追加されましたよ！最新のつぶやきを見に行きましょう。

@component('mail::button', ['url' => route('tweet.index')])
    つぶやきを見に行く
@endcomponent

@endcomponent
```

送信先のユーザーと1日分のつぶやき数を受け取って、ユーザーにつぶやき数を知らせるとともに、訪問を促します。これでメールの作成は終わりです。

### メールの送信機能を作成する

次にコマンドからメールを送信する部分を作っていきます。 

<p class="tmp cmd"><span>コマンド</span>メールを送信部分作成</p>
```
sail artisan make:command SendDailyTweetCountMail
```
![](upload/メールを送信部分作成.png)

これでapp/Console/Commands以下にSendDailyTweetCount Mailというクラスが作られます。 

![](upload/SendDailyTweetCountMailというクラス.png)

このファイルへ次のように追記しましょう。

<p class="tmp list"><span>リスト</span>app/Console/Commands/SendDailyTweetCountMail.php</p>
```
<?php

namespace App\Console\Commands;

use App\Mail\DailyTweetCount;
use App\Models\User;
use App\Services\TweetService;
use Illuminate\Console\Command;
use Illuminate\Contracts\Mail\Mailer;

class SendDailyTweetCountMail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'mail:send-daily-tweet-count-mail';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '前日のつぶやき数を集計してつぶやきを促すメールを送ります。';

    private TweetService $tweetService;
    private Mailer $mailer;
 
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TweetService $tweetService, Mailer $mailer)
    {
        parent::__construct();
        $this->tweetService = $tweetService;
        $this->mailer = $mailer;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $tweetCount = $this->tweetService->countYesterdayTweets();

        $users = User::get();

        foreach ($users as $user) {
            $this->mailer->to($user->email)
                ->send(new DailyTweetCount($user, $tweetCount));
        }

        return 0;
    }
}
```

さらに「TweetService.php」に次のように変更します。

<p class="tmp list"><span>リスト</span>app/Services/TweetService.php（全文）</p>
```
<?php

namespace App\Services;

use App\Models\Tweet;
use Carbon\Carbon;//追加

class TweetService
{
    public function getTweets()
    {
        return Tweet::orderBy('created_at', 'DESC')->get();
    }

    // 自分のtweetかどうかをチェックするメソッド
    public function checkOwnTweet(int $userId, int $tweetId): bool
    {
        $tweet = Tweet::where('id', $tweetId)->first();
        if (!$tweet) {
            return false;
        }

        return $tweet->user_id === $userId;
    }

    //追加
    public function countYesterdayTweets(): int
    {
        return Tweet::whereDate('created_at', '>=', Carbon::yesterday()->toDateTimeString())
            ->whereDate('created_at', '<', Carbon::today()->toDateTimeString())
            ->count();
    }
}
```

これでコマンドが完成です。しかし、このままコマンドを実行しても、昨日のつぶやきがないため0件になってしまい確認できません。  
つぶやきのファクトリーを変更して、昨日のつぶやきを入れてあげましょう。

<p class="tmp list"><span>リスト</span>database/factories/TweetFactory.php（全文）</p>
```
<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Carbon\Carbon;//追加

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Tweet>
 */
class TweetFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */

    public function definition(): array
    {
        return [
            'user_id' => 1, // つぶやきを投稿したユーザーのIDをデフォルトで1とする
            'content' => $this->faker->realText(100),
            'created_at' => Carbon::now()->yesterday()//追加
        ];
    }
}
```

seedのデータを入れなおして、コマンドを実行してみます。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan migrate:fresh --seed
```
![](upload/migratefresh--seedス.png)

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan mail:send-daily-tweet-count-mail
```
![](upload/send-daily-tweet-count-mail.png)

次のように送信できたら成功です。

<span class="red">※MailPitに送信できていない場合</span>
: メールが即座に受け取れない場合、メールの送信がQueueに積まれている場合があるので、.envのQUEUE_CONNECTIONを「<span class="red">sync</span>」に変更してからコマンドを実行するか、Queueに積まれたメール送信をsail artisan queue:workで実行してください。

![](upload/昨日は10件のつぶやきが追加されました.png)

送信が確認するときには「sync」にしています。
![](upload/envのコードはもどした方がいいのか.png)


## スケジュールに登録する

あとは毎日これが実行されるように、スケジュールを登録します。

<p class="tmp list"><span>リスト</span>app/Console/Kernel.php（全文）</p>
```
<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('mail:send-daily-tweet-count-mail')
            ->dailyAt('11:00');
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
```

これで、毎日11時に前日に作られたつぶやきの数を数えてメール送信する スケジュールを作成することができました。
なお、 先ほどマイグレーションとシーディングをやり直しているため、ここまで に登録したユーザーもデータベースから削除されています。 ログインができなくなるため、再度「<http://localhost/register>」 からユーザーを登録しておいてください。




