*[page-title]:async、await関数

参考サイト
: [非同期関数](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Statements/async_function)
: [async/await 入門（JavaScript）](https://qiita.com/soarflat/items/1a9613e023200bbebcb3)
: [非同期処理:Promise/Async Function](https://jsprimer.net/basic/async/)

非同期関数は async キーワードで宣言され、その中で await キーワードを使うことができます。 async および await キーワードを使用することで、プロミスベースの非同期の動作を、プロミスチェーンを明示的に構成する必要なく、よりすっきりとした方法で書くことができます。

```
function resolveAfter2Seconds() {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve('resolved');
    }, 2000);
  });
}

async function asyncCall() {
  console.log('calling');
  const result = await resolveAfter2Seconds();
  console.log(result);
  // expected output: "resolved"
}

asyncCall();
```

<div class="exp">
	<p class="tmp"><span>例</span></p>
	<script async src="//jsfiddle.net/hirao/xau3f6zp/4/embed/js,result/"></script>
</div>

<div class="exp">
	<p class="tmp"><span>例</span>asyncとawaitの使い方</p>
<iframe src="https://paiza.io/projects/e/sVtI4GKBgGBUocdbr63cqQ?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>
</div>