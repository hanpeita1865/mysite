---
title: '09. フェードイン、フェードアウト<br>（fadeIn、fadeOut、fadeToggle）'
taxonomy:
    category:
        - docs
visible: true
---

<style>
	p{letter-spacing:.06rem;}
	iframe{margin-bottom:2.5rem;}
</style>

<p>fadeIn()、fadeOut()メソッドは指定した要素の透過度を制御して、フェードイン／フェードアウトのアニメーションをつけて表示／非表示を切り替えます。</p>

<h2 class="h-type2">要素をフェードインさせる fadeIn() メソッド</h2>

<dl class="dl-methodDetail">
	<dt><span>書式</span></dt>
	<dd>$(セレクタ).fadeIn([speed][,func])</dd>
	<dt><span>機能</span></dt>
	<dd>$(セレクタ)をフェードアニメーションをつけて表示します。</dd>
	<dt><span>引数</span></dt>
	<dd>
		<dl class="dl-methodDetailInner">
			<dt>speed：</dt>
			<dd>フェード動作する時間を「slow」、「normal」、「fast」の文字列か、もしくは数値（ミリ秒単位）で指定します。</dd>
			<dt>func：</dt>
			<dd>フェードインアニメーション完了後に実行する関数</dd>
		</dl>
	</dd>
</dl>
<div class="box-example">
	<h3 class="h-example">例1</h3>
	<p>3秒間かけてフェードイン表示させたい場合は次のように記述します。</p>
</div>
<iframe width="100%" height="200" src="//jsfiddle.net/osadahrs/c2brp7zd/8/embedded/html,css,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<div class="box-example">
	<h3 class="h-example">例2</h3>
	<p>「fadeIn()」を実装する場合、何らかのイベント処理と一緒に記述するのが一般的です。イベントというのは、メニューをクリックしたら…とか、指定の位置にマウスカーソルを重ねたら…などによる処理です。</p>
	<p>この例では、button要素をマウスでクリックした時のイベント処理を記述しています。</p>
</div>
<iframe width="100%" height="250" src="//jsfiddle.net/osadahrs/c2brp7zd/22/embedded/html,css,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<h2 class="h-type2">要素をフェードアウトさせる fadeOut() メソッド</h2>

<dl class="dl-methodDetail">
	<dt><span>書式</span></dt>
	<dd>$(セレクタ).fadeOut([speed][,func])</dd>
	<dt><span>機能</span></dt>
	<dd>$(セレクタ)をフェードアニメーションをつけて表示します。</dd>
	<dt><span>引数</span></dt>
	<dd>
		<dl class="dl-methodDetailInner">
			<dt>speed：</dt>
			<dd>フェード動作する時間を「slow」、「normal」、「fast」の文字列か、もしくは数値（ミリ秒単位）で指定します。</dd>
			<dt>func：</dt>
			<dd>フェードインアニメーション完了後に実行する関数</dd>
		</dl>
	</dd>
</dl>

<div class="box-example">
	<h3 class="h-example">例3</h3>
	<p>3秒間かけてフェーアウトさせたい場合は次のように記述します。</p>
	<p>例では、h1要素を3秒かけてフェードアウトさせています。</p>
</div>
<iframe width="100%" height="200" src="//jsfiddle.net/osadahrs/c2brp7zd/24/embedded/html,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<h2 class="h-type2">フェードイン・アウトの実現 fadeToggle()メソッド</h2>
<p>今度は、フェードイン・アウトを簡単に繰り返すことができるメソッドについて見ていきましょう。
利用するのは「fadeToggle()」メソッドで、こちらも使い方はfadeIn()とほとんど同じなので便利です。</p>
<div class="box-example">
	<h3 class="h-example">例4</h3>
	<p>クリックイベント処理内に「fadeToggle()」を実行しているので、ボタンをクリックするたびにh1要素がフェードイン、フェードアウトを繰り返します。</p>
</div>
<iframe width="100%" height="200" src="//jsfiddle.net/osadahrs/c2brp7zd/28/embedded/html,css,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>