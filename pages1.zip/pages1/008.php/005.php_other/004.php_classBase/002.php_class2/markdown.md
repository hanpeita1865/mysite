*[page-title]:クラスについての解説2

## クラスの作成

参考サイト
: [第13回 PHPの「クラス」と「インスタンス」――「オブジェクト指向」の基礎中の基礎](https://atmarkit.itmedia.co.jp/ait/articles/1712/14/news011.html)

サンプル格納場所
: C:\xampp\htdocs\from_now_slim\pages\008.php\005.php_other\004.php_classBase\002.php_class2\sample\sample1(class)

<span class="green bold">※参考サイトを開いて、サンプルコードを見ながら学習すると、わかりやすいです。</span>

下記は、関数もクラスも使っていないコードです。
<p class="tmp list"><span>リスト1</span>calcTestScore.php</p>
![](upload/calcTestScore.php.png)

[calcTestScore.php（新規タブ）](sample/sample1(class)/calcTestScore.php)

これは、たろうさんとはなこさんの数学英語国語の各教科の合計と平均を計算し、表示するプログラムです。特に難しい部分はありません。ただ、合計の計算、平均の計算、それらの表示という処理部分、つまり6～8行目と14～16行目がほぼ同じソースコードであり、無駄です。

無駄な部分に<span class="green bold">関数</span>を使ってみたのが、次のコードになります。
<p class="tmp list"><span>リスト2</span>calcTestScore2.php</p>
![](upload/calcTestScore2.php.png)

[calcTestScore2.php（新規タブ）](sample/sample1(class)/calcTestScore2.php)

合計の計算、平均の計算、それらの表示という処理部分を関数printScore()とし、実行部分では、その関数を利用しています。

### 変数をまとめてみる

関数として処理を共通化したリスト2ですが、まだソースコード中に似たような行があります。それは、各変数を用意している9～12行目と15～18行目です。こちらはあくまで変数の用意ですので、処理ではなくデータです。処理は関数として共通化できますがデータはどうでしょうか。

そこで少し考えます。

ここで用意しているのは、たろうさんの名前と数学英語国語の点数です。同様にはなこさんの名前と数英国の点数です。名前と数英国の点数というのはバラバラで存在するデータではなく、これらがワンセットとしてたろうさんのデータであり、はなこさんのデータです。ところが、リスト2ではバラバラの変数として記述されています。

これらの変数をワンセットのカタマリとして記述できれば理想であり、そういった記述方法が用意されています。それが、<span class="purple bold">クラス</span>です（後述するようにクラスの役割はそれだけではありません）。

クラスは別ファイルとして記述するのが一般的です。以下のTestScore.phpを作成してください。なお、このファイルは実行部分がありませんので、実行しても何も表示されません。

<p class="tmp list"><span>リスト3</span>TestScore.php</p>
![](upload/TestScore.php.png)

これがクラスです。

ワンセットとしたい変数を波かっこで囲みます。ここでは名前と数英国の点数です。その際、変数にはpublicを付けます。publicが何を意味するかは次回以降で解説する予定です。このようにして囲まれた波かっこ内に記述します。

<p class="tmp"><span>書式</span>クラス</p>
```
class クラス名 {･･･}
```

クラスは、慣例的に以下の3点に従った記述方法を採ります。

* クラス名はアルファベットの大文字で始めるキャメル記法（<span class="red">アッパーキャメル記法</span>）で記述する。
* クラスとファイルの対応関係は1対1とする。つまり、1つのクラスは1つのphpファイルに記述し、そのファイルにはそのクラス以外のコードは記述しない。
* クラスを記述するphpファイルのファイル名は、「<span class="red">クラス名.php</span>」とする。

## クラスをつかってみる

下記のリスト4では、$taroと$hanakoにインスタンスの変数を格納して、関数printScore()の引数に使用しています。
<p class="tmp list"><span>リスト4</span>useTestScore2.php</p>
![](upload/TestScore.php2.png)

[useTestScore2.php（新規タブ）](sample/sample1(class)/useTestScore2.php)

<p class="tmp"><span>書式</span>クラスのnew</p>
```
インスタンスを格納する変数 = new クラス名();
```

<div markdown="1" class="memo-box">
この「クラス名()」の前にnewを記述することで生成されたものを「インスタンス」といいます。  
インスタンス内の変数を利用するには「->」を記述します。ここで注意したいのは「->」の次の変数名、つまりインスタンス内の変数には「$」は付かないということです。

例えば、「$taro->name」で1つの変数のように扱うということです。そのため、この「$taro->name」に対して値を代入することもできますし、その値を利用することもできます。
</div>

### クラスは処理を含めることができる

このクラスの役割はデータをまとめるだけでなく、処理も含めることができます。

では、TestScoreクラスをそのように改良したTestScoreWithMethodクラスを作成してみましょう。クラス作成のルールにのっとって、これは、TestScoreWithMethod.phpファイルに記述します。
<p class="tmp list"><span>リスト5</span>TestScoreWithMethod.php</p>
![](upload/TestScoreWithMethod.php.png)

これが、クラスの形です。クラスにはデータと処理を一緒に含めることができます。そして、データは変数と、処理は関数と同じ記述方法です（ただしpublicが付きます）。ただ、名称が変わります。クラス内のデータ部、つまり変数のことを「<span class="blue bold">プロパティ</span>」、処理部、つまり関数のことを「<span class="green bold">メソッド</span>」といいます。そして、プロパティとメソッドを合わせて「<span class="red bold">メンバ</span>」といいます。

構文としてまとめると以下のようになります。

<p class="tmp"><span>書式</span>クラス構文</p>
```.php
class クラス名
{
　　public 変数名;  ← プロパティ
　　　　：
　　public function メソッド名(引数)　←メソッド
　　{
　　　　処理;
　　}
　　　　：
}
```

では、TestScoreWithMethodクラスを使うように実行部分を書き換えてみましょう。

<p class="tmp list"><span>リスト6</span>useTestScoreWithMethod.php</p>
![](upload/useTestScoreWithMethod.php.png)

表示処理を行っていたprintScore()がTestScoreWithMethodクラスのメソッドになったので、単にprintScore()と記述するのではなく、「$taro->printScore()」や「$hanako->printScore()」という記述になっています。これは、それぞれ$taroインスタンスのメソッドprintScore()、$hanakoインスタンスのメソッドprintScore()を呼び出す記述です。

このように、メソッドもプロパティと同様に「変数名->メンバ名」でアクセスできます。もしメソッドに引数が必要でしたら、()内に記述することで渡すことができます。

[useTestScoreWithMethod.php（新規タブ）](sample/sample1(class)/useTestScoreWithMethod.php)



## クラスに複数のメソッドを記述

参考サイト
: [第14回 PHP 7.2リリース＆PHPのアクセス修飾子、アクセサメソッド、カプセル化、コンストラクタ](https://atmarkit.itmedia.co.jp/ait/articles/1802/08/news010.html)

格納場所
: C:\xampp\htdocs\from_now_slim\pages\008.php\005.php_other\004.php_classBase\002.php_class2\sample\sample2(class)


リスト5のTestScoreWithMethodクラスで、処理部分をメソッドとしてクラスに含めたとはいえ、リスト6の実行処理部分（useTestScoreWithMethod.php）は相変わらずスッキリしません。

これをもう少しコンパクトに記述できるように、クラス側を改良しましょう。

さらに、現状、数英国の合計と平均を表示しているだけの処理をもう少し拡張し、「たろうさん」と「はなこさん」の合計の平均、平均の平均も表示しましょう。そのためには、それぞれの合計値と平均値を取得するメソッドが必要になります。

そのように改良したクラスが次のTestScoreAdvクラスになります。

<p class="tmp list"><span>リスト7</span>TestScoreAdv.php</p>
![](upload/TestScoreAdv.php.png)
メソッドが4個に増えました。当然ですが、このように1つのクラスに複数のメソッドを記述しても全く問題ありません。それぞれのメソッドの内容は下記の通りです。

setData()（【1】）  
: プロパティのデータをまとめて受け取れるメソッドです。<br>
TestScoreやTestScoreWithMethodではプロパティそれぞれに実行部分で値を代入する必要がありました。それをまとめて行うメソッドです。そのため、プロパティと同一個数、同一内容の引数を記述し、メソッド内では引数の内容をプロパティに格納する処理を記述しています。

calcSum()（【2】）
: 合計値を計算するメソッドです。<br>
メソッドは基本的に関数と同様の記述方法をとるので、このメソッドのように戻り値が必要なものは、メソッドの末尾にreturnを記述し値を返却します。ここではプロパティの3教科の点数を足し算し、その結果を返しています。

calcAve()（【3】）
: 平均値を計算するメソッドです。<br>
平均値は、当たり前ですが合計値を個数で割った値です。ということは事前に合計値を計算しておく必要があります。このメソッド内部でプロパティの足し算を行ってもいいのですが、せっかく合計値を計算するメソッドを別に用意しているので、それを呼び出して使います。それが32行目です。プロパティ同様に自分自身のメソッドを呼び出すのにも、「$this」を使います。<br>
またcalcSum()同様、戻り値が必要なので、メソッド末尾にreturnを記述しています。

printScore()（【4】）
: TestScoreWithMethodクラス同様に合計値と平均値を表示するメソッドです。

※TestScoreWithMethodクラスとの違いは、表示する合計値と平均値をこのメソッド内で計算するのではなく、calcSum()とcalcAve()を呼び出してその値を利用していることです。


### データと処理がワンセットだと便利

クラス側が記述できたので、このTestScoreAdvを利用するuseTestScoreAdv.phpを記述し、実行しましょう。
<p class="tmp list"><span>リスト8</span>useTestScoreAdv.php</p>
![](upload/useTestScoreAdv.php.png)


[useTestScoreAdv.php（新規タブ）](sample/sample2(class)/useTestScoreAdv.php)

$taroを生成してからprintScore()までがはるかにコンパクトになりました。$hanakoに関しても同じです。

さらに、例えばたろうさんなら、6行目で$taroに一度データをセットしておくだけで、7行目で表示したり、15行目で合計値を取得したり、24行目で平均値を取得したりすることができます。<span class="red">メソッドさえ作成しておけばデータの取り出しは自由自在です</span>。

これが関数の場合だと、下記のようにその都度引数でデータを渡す必要があります。（クラスだと最初にデータをセットしておけば、処理の記述が楽です。）
```
$taroSum = calcSum($math, …);
```
このようにクラスを利用した「<span class="green bold">オブジェクト指向プログラミング</span>」は、データと処理がワンセットとなっているため、さまざまな利点があります。