<?php
namespace App;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements MessageComponentInterface {

    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    //webSocket接続できたら、自動的に実行される。
    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
    }

    //クライアントがデータを送信したら実行される。
    public function onMessage(ConnectionInterface $from, $msg) {
         foreach ($this->clients as $client) {
            // $data = ['msg' => $msg];
            $data = ['msg' => $msg];
            // $msgJson = json_decode($msg , true);
            // $data = $msgJson['id'];
            // $data = ['id' => $msgJson['id']];

            // if ($from === $client) {
            //     $data['position'] = 'right';
            // } else {
            //     $data['position'] = 'left';
            // }

            $client->send(json_encode($data));//全クライアントへデータが送信される。
        }
    }

    //webSocket切断
    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }
}
