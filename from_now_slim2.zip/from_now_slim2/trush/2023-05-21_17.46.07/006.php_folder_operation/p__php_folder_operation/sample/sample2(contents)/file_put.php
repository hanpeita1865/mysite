<?php
$file = "foo.txt";//書き込むファイル名
$string = "Hello1, PHP";//書き込む文字列
file_put_contents($file, $string);
?>