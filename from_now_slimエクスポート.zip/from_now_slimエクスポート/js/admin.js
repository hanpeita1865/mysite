const elem_box = document.getElementById('menu');
const box_items = document.querySelectorAll('.box-item');
const elem_reset = document.getElementById('reset');
const elm_container = document.querySelector('.container');
const elm_msgbox = document.getElementById('sort-msgbox');
let subMenu = document.querySelectorAll('.sub-menu');
let arrayStart = [];//デフォルトの並び順初期値
let menuJson = [];//メニューJson
let menuStr;//メニュー文字列
let menu_obj = {};//メニューオブジェクト
let list_elm;

let soating = false;//並べ替え中か判定

//並べ替え中警告のモーダル
const soatWarn = document.getElementById('soatWarn');
const soatModal = new bootstrap.Modal(document.getElementById('soatWarn'));

//完了成功モーダル
const successMsg = document.getElementById('successModal');
const successMsgModal = new bootstrap.Modal(document.getElementById('successModal'));

//削除用モーダル
const fdDelElm = document.getElementById('fdDelModal');
const fdDelModal = new bootstrap.Modal(document.getElementById('fdDelModal'));

//ロック設定用モーダル
const fdLockElm = document.getElementById('lockModal');
const fdLockModal = new bootstrap.Modal(document.getElementById('lockModal'));


//フォルダ構成をメニューに反映（初期表示）
// folder_complist_menu();


//並び順初期値格納
box_items.forEach(function (value) {
	arrayStart.push(value.getAttribute('id'));
});

box_items.forEach(elm => {
	//ボックスをダブルクリックして空のボックスを作成
	elm.addEventListener('dblclick', function (e) {

		let subLen = this.children.length;

		if (elm == e.target) {//2階層以下の複数実行防止

			//サブメニューの空ボックスを作成
			if (subLen == 5) {
				this.insertAdjacentHTML('beforeend', '<ul class="emp-ul sub-menu"></ul>\n');
				obj = this.lastChild;//サブメニューul要素

			} else {
				//サブメニュー開閉
				this.closest('.box-item').classList.toggle('s-close');
			}
		}
	})

	elm.setAttribute('draggable', 'true');

	let href = elm.querySelector('a').getAttribute('href');
	let folderName = href.split('/').slice(-2)[0];

	//ロックされてるリストか判定
	if(elm.querySelector('a').classList.contains('lock') || elm.querySelector('a').classList.contains('all-lock')){
		//ロック設定あり
		elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="unlock">ロック解除</button>');
	}else{
		elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="btn-lock" data-bs-toggle="modal">ロック設定</button>');
	}

	elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="folder-del" data-bs-toggle="modal" data-bs-target="#fdDelModal">削除</button>');
	elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="folder-rename" data-bs-toggle="modal" data-bs-target="#fdChangeModal">フォルダ名変更</button>');
	elm.querySelector('a').insertAdjacentHTML('afterend', '<span class="link-name">' + folderName + '</span>');
	elm.querySelector('a').setAttribute('title', 'クリックするとメニュー名を変更できます。');

	if (elm.children.length > 5) {
		elm.querySelector('a').insertAdjacentHTML('beforeend', '<span class="icon-slide"></span>');
	}

	sortDrop(elm);
});


dirObj = [];

//ボックス並べ替え
function sortDrop(elm) {

	elm.ondragstart = function (e) {
		e.dataTransfer.setData('text/plain', e.target.id);
	};

	let empBox = 1;

	//ドラッグオーバー
	elm.ondragover = function (e) {
		e.preventDefault();

		if (elm == e.target.parentNode || elm == e.target) {

			if (e.target.classList.contains('emp-ul')) {
				e.stopPropagation(); //イベントを停止する
				e.preventDefault(); //画面遷移を行わない
				e.target.style.border = '4px solid green';
				empBox = e.target;

			} else if (e.target.closest('li').classList.contains('box-item')) {
				let rect = e.target.closest('li').getBoundingClientRect();
				let elm_over = this

				rectOver(e, rect, elm_over);//ボーダー表示

			} else {
				let rect = e.target.getBoundingClientRect();
				let elm_over = e.target;

				rectOver(e, rect, elm_over);//ボーダー表示
			}
		}
	};

	//ドラッグリープ（ボックスから離れる）
	elm.ondragleave = function (e) {
		if (empBox != 1) {
			empBox.removeAttribute('style');
		}

		this.style.borderTop = '';
		this.style.borderBottom = '';
	}

	//ドロップ
	elm.ondrop = async function (e) {
		e.preventDefault();

		if (elm == e.target.parentNode || elm == e.target) {//2階層以下の複数実行防止

			let id = e.dataTransfer.getData('text/plain');
			const elm_drag = document.getElementById(id);

			try {
				if (e.target.classList.contains('emp-ul')) {//空のボックスに挿入

					let id = e.dataTransfer.getData('text/plain');
					let dropItem = document.getElementById(id);

					e.target.removeAttribute('style');
					e.preventDefault();

					try {

						e.target.appendChild(dropItem);
						e.target.closest('.box-item').firstElementChild.insertAdjacentHTML('beforeend', '<span class="icon-slide"></span>');

						dropItem.parentNode.classList.remove('emp-ul');
						subEmpDelete();

					} catch (error) {

						dropItem.parentNode.classList.remove('emp-ul');
						subEmpDelete();
					}

				} else if (this.classList.contains('box-item')) { //並べ替え

					let rect = this.getBoundingClientRect();

					rectDrop(e, e.currentTarget, rect, elm_drag);//挿入位置が上側か下側かを判定
					subEmpDelete();//空になった挿入用ボックス削除
				}

				box_items.forEach(function (t) {
					t.removeAttribute('style');
				});

				document.querySelectorAll('.side-link li a').forEach(e => {
					let folderName = e.getAttribute('href').split('/').slice(-2)[0];
				})

				if (elm_msgbox.children.length == 0) {

					pagesDir = await pagesDirGet();

					elm_msgbox.insertAdjacentHTML("afterbegin", '<p class="sort-text">並べ替えをすべて済ませた後、<br>「並べ替え確定」ボタンを押してください</p>');
					soating = true;

					dirObj = [];//並び替えの履歴を空にする
				}

			} catch (error) {

				//ボーダー削除
				box_items.forEach(function (e) {
					e.removeAttribute('style');
				});

				subMenu.forEach(function (e) {
					e.removeAttribute('style');
				})

			} finally{
				console.log('ドラッグ完了');

				let targetName;
				let targetAfHref;
				let targetBfHref;

				targetBfHref = elm_drag.firstElementChild.getAttribute('href');

				targetName = targetBfHref.split('/').slice(-2)[0];
				bfAry = targetBfHref.split('/');
				bfAry.splice('0','3');
				bfAry.pop();

				bfAry1 = bfAry;
				bfAry1.shift();

				bfAry2 = bfAry1.map(value => {
					let fdNameBf = pagesDir[value].split('/').slice(-1)[0];
					return fdNameBf;
				})

				bfPath = '../pages/'+ bfAry2.join('/');

				//pages直下に移動するか判定
				if(elm_drag.parentNode.classList.contains('side-link')){

					let fdNameAf = pagesDir[targetName].split('/').slice(-1)[0];
					afPath = '../pages/'+ fdNameAf;

					let pathBase = '/'+ targetBfHref.split('/')[1];

					targetAfHref = pathBase + '/public/pages/' + targetName;
					
				}else{

					let parentHref =  elm_drag.parentNode.closest('.box-item').firstElementChild.getAttribute('href');
				
					targetAfHref = parentHref + targetName;

					afAry = targetAfHref.split('/');
					afAry.splice('0','3');

					afAry1 = afAry;
					afAry1.shift();

					afAry2 = afAry1.map(value => {
						let fdNameAf = pagesDir[value].split('/').slice(-1)[0];
						return fdNameAf;
					})
					
					afPath = '../pages/'+ afAry2.join('/');
				}

				targetAfHref = targetAfHref + '/';
				dirObj.push( {fdName: targetName, bfDir: bfPath, afDir: afPath} );//移動前ディレクトリと移動後ディレクトリを追加
				elm_drag.firstElementChild.setAttribute('href', targetAfHref);//メニューのhref値を変更
			}
		}
	};
}


//空になったsubメニューボックス削除
function subEmpDelete() {
	subMenu = document.querySelectorAll('.sub-menu');
	//空のボックスがある。
	subMenu.forEach(function (e) {
		if (e.children.length == 0 && !e.classList.contains('emp-ul')) {
			e.remove();
		}
	});

	//サブメニューない▲アイコン削除
	document.querySelectorAll('a span.icon-slide').forEach(function (e) {
		if (e.closest('.box-item').querySelector('.sub-menu') == null) {
			e.remove();
		}
	});
}

//マウスオーバーの上下ボーダー表示
function rectOver(e, rect, elm_over) {
	if ((e.clientY - rect.top) < (elm_over.clientHeight / 2)) {
		//マウスカーソルの位置が要素の半分より上
		elm_over.style.borderTop = '2px solid blue';
		elm_over.style.borderBottom = '';
	} else {
		//マウスカーソルの位置が要素の半分より下
		elm_over.style.borderTop = '';
		elm_over.style.borderBottom = '2px solid blue';
	}
}


//ドロップ上下判定
function rectDrop(e, t, rect, elm_drag) {
	if ((e.clientY - rect.top) < (rect.height / 2)) {
		//マウスカーソルの位置が要素の半分より上
		t.parentNode.insertBefore(elm_drag, t);
	} else {
		//マウスカーソルの位置が要素の半分より下
		t.parentNode.insertBefore(elm_drag, t.nextElementSibling);
	}
}


//リンク無効化
// document.querySelectorAll('a').forEach(elm => {
// 	elm.addEventListener('click', e => {
// 		e.preventDefault();
// 	});
// });


event_name = '';



//--------------------//
//  フォルダ新規作成  //
//------------------//

const btn_crt_fd = document.getElementById('btn-create-folder');
const fdcrt_msg = document.getElementById('folder-create-message');
const fd_modal = document.getElementById('fdCreateModal');
const create_modal = new bootstrap.Modal(document.getElementById('fdCreateModal'));
const fdname = document.getElementById('create-folder');

btn_crt_fd.addEventListener('click', function(){

	//メニューから配列を作成
	menu_create();

	let newFd = fdname.value;

	if (newFd == '') {
		fdcrt_msg.innerHTML = 'フォルダ名の値が空です';

	} else if (newFd.match(/\.|\*|"|:|\?|<|>|\//)) {
		fdcrt_msg.innerHTML = '. * " : ? < > / のいづれかの文字が含まれています。';

	} else if(!newFd.match(/^[!-~]+$/)) {
		fdcrt_msg.innerHTML = '英数字以外の文字や空白またはその他の使用できない文字が含まれています。';

	} else if (newFd.match(/\\/)) {
		fdcrt_msg.innerHTML = '「\」がフォルダ名に含まれています。';

	} else if (isKeyExists(menu_obj, newFd)) {
		fdcrt_msg.innerHTML = '同じフォルダ名があります。';

	} else {
		create_modal.hide();

		const eventName = 'フォルダ新規作成';
		const formData = new FormData;
		formData.append('post_newFolder', newFd);//フォルダ名
		formData.append('eventName', eventName);//イベント処理名

		fetch('../public/folder_create', {//フォルダ新規作成
			method: 'POST',
			body: formData,
		}, { cache: "no-store" })

			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response.text();
			})
			.then(data => {
				//通信成功時の処理
				if(data==''){
					completeMsg('フォルダを新規作成しました。');
				}else{
					//新規投稿できなかった
					alert(data);
				}
				
				location.reload();//リロード
			})
			.catch((reason) => {
				alert('失敗しましたよ～。')
			});
	} 
});

fd_modal.addEventListener('hidden.bs.modal', event => {
    fdname.value = '';  
})

fd_modal.addEventListener('show.bs.modal', event => {
	if(soating == true){
		//並べ替え中　警告アラート
		soatModal.show();
		return false;
	} 
})

// function folderCreate(){

// 	if(soating == true){
// 		//並べ替え中　警告アラート
// 		soatModal.show();
// 		return false;
// 	}
// }


//オブジェクトのキーに存在チェック関数
function isKeyExists(obj, key) {
	return key in obj;
}


//並べ替え関数
function compareFunc(a, b) {
	return a - b;
}


//--------------------//
//  ロック設定・解除  //
//------------------//

function folder_lock(e){

	if(soating == true){
		//並べ替え中　警告アラート
		soatModal.show();
		return false;

	}


	if (e.target && e.target.classList.contains("btn-lock")) {

		lockDialog = document.getElementById('lockModal');
		onlylock_elm = document.getElementById('only-lock');
		alllock_elm = document.getElementById('all-lock');
		cancellock_elm = document.getElementById('cancel-lock');
		lockname_elm = document.getElementById('folder-name-lock');
		menulockId = e.target.parentNode.getAttribute('id');
		lockDialog.dataset.id = menulockId;//ダイアログにロックフォルダのidをデータ属性に設定
		lock_elm = e.target;

		//配下のリスト
		const list_elm = e.target.parentNode.querySelectorAll('li');
		lockListNum = list_elm.length+1;

		let listName = e.target.parentNode.children[0].textContent;//メニュー名
		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
		folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide

		lockname_elm.innerHTML = listName + '【' + folderName + '】';

		if(lockListNum==1){
			document.getElementById('all-lock').classList.add('d-none');
		}else{
			document.getElementById('all-lock').classList.remove('d-none');
		}

		fdLockModal.show();

	} else if (e.target && e.target.classList.contains("unlock")) {

		lock_elm = e.target;
		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
		folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide

		let fd = new FormData();
		fd.append('eventName', 'ロック解除');
		fd.append('folderName', folderName);
	
		fetch('../public/page_unlock', {
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {
				alert('ロックを解除しました。');
				lock_elm.parentNode.children[0].classList.remove('lock','all-lock');
				lock_elm.classList.remove('unlock');
				lock_elm.classList.add('btn-lock');
				lock_elm.textContent='ロック設定';
			})
			.catch(() => {
				console.log('エラー')
			})
	}
}



//単独でロック追加
document.getElementById('only-lock').addEventListener('click', function (e) {

	let fd = new FormData();
	fd.append('eventName', event_name);
	fd.append('folderName', folderName);
	fd.append('under_dir', 'only');

	fetch('../public/page_lock', {
		method: 'post',
		body: fd,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response;
		})
		.then(response => response.text())
		.then(data => {

			lock_elm.parentNode.children[0].classList.add('lock');
			lock_elm.classList.remove('btn-lock');
			lock_elm.classList.add('unlock');
			lock_elm.textContent='ロック解除';

			alert('ロックを追加しました。');
		})
		.catch(() => {
			console.log('エラー')
		})
})


//配下もロック追加
document.getElementById('all-lock').addEventListener('click', function (e) {
	let fd = new FormData();
	fd.append('eventName', event_name);
	fd.append('folderName', folderName);
	fd.append('under_dir', 'all');

	fetch('../public/page_lock', {
		method: 'post',
		body: fd,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response;
		})
		.then(response => response.text())
		.then(data => {

			lock_elm.parentNode.children[0].classList.add('all-lock');
			lock_elm.classList.remove('btn-lock');
			lock_elm.classList.add('unlock');
			lock_elm.textContent='ロック解除';

			alert('ロックを追加しました。');
		})
		.catch(() => {
			console.log('エラー')
		})
})






//--------------------//
//   メニュー名変更   //
//------------------//

function menu_rename(e){

	e.preventDefault();

	if(soating == true){
		//並べ替え中　警告アラート
		soatModal.show();

		return false;
	}

	let menuName = e.target.textContent;//例）メニュー名111
	let menuId = e.target.closest('li').getAttribute('id');
	let folderName = e.target.getAttribute('href').split('/').slice(-2)[0];//フォルダ名
	let folderDir = e.target.getAttribute('href');//パス


			let menuReName = prompt('名前を変更して「ok」を押してください', menuName);
	
			if (menuName != menuReName && menuReName != '' && menuReName != null) {
	
				menu_create();//メニュー配列
				let dirName = menu_obj[folderName];//変更前のディレクトリ
				const eventName = 'メニュー名変更';
	
				let formData = new FormData;
				formData.append('post_menu', menuName);//変更前メニュー名
				formData.append('post_reName', menuReName);//変更後メニュー名
				formData.append('post_dir', folderDir);//パス
				formData.append('post_dirName', dirName);//パス（番号付き）
				formData.append('eventName', eventName);//イベント処理名
	
				fetch('../public/file_rename', {
					method: 'POST',
					body: formData,
				}, { cache: "no-store" })
					.then((response) => {
						if (!response.ok) {
							throw new Error();
						}
						return response.text();
					})
					.then(data => {
						//通信成功時の処理
						alert(data);
						if (data.match(/変更しました/)) {
							document.getElementById(menuId).firstElementChild.textContent = menuReName;
						}
	
					})
					.catch((reason) => {
						console.log('メニュー名変更に失敗しました。')
					});
	
			} else if (menuReName == '') {
				alert('メニュー名の値が空です');
			}
};




//--------------------//
// 全サブメニュー開閉  //
//------------------//

const btn_close = document.querySelectorAll('.btn-sub-close');

btn_close.forEach(elm => {
	elm.addEventListener('click', function (e) {

		if (e.target.classList.contains('open') == true) {
			// 閉じる
			btn_close.forEach(t => {
				t.classList.remove('open');
				t.textContent = '全サブメニュー開く';
			})

			document.querySelectorAll('.sub-menu').forEach(e => {
				e.closest('.box-item').classList.add('s-close');
			});
		} else {
			// 開く
			btn_close.forEach(t => {
				t.classList.add('open');
				t.textContent = '全サブメニュー閉じる';
			})

			document.querySelectorAll('.sub-menu').forEach(e => {
				e.closest('.box-item').classList.remove('s-close');
			});
		}
	});
});

//「▼」アイコンクリックでサブメニューを開閉
document.querySelectorAll('.icon-slide').forEach(elm => {
	elm.addEventListener('click', function (e) {
		e.target.closest('.box-item').classList.toggle('s-close');
	});
});



//メニューから配列を作成　JS only
function menu_create() {
	const menu = document.getElementById('menu');
	let clone_element = menu.cloneNode(true);//メニューをコピー
	let menuArray = [];
	let menuObj = {};


	//コピーメニューからボタン削除
	clone_element.querySelectorAll('button').forEach(e => {
		e.remove();
	})

	// //コピーメニューから.link-name要素を削除
	clone_element.querySelectorAll('.link-name').forEach(e => {
		e.remove();
	})

	//コピー要素から属性の削除
	clone_element.querySelectorAll('li').forEach(e => {
		e.removeAttribute('id');//id属性の削除
		e.removeAttribute('class');//class属性の削除
		e.removeAttribute('draggable');//draggable属性の削除
	})

	let listElm = '#menu > li';
	//コピー要素の頭に番号を付与
	while (clone_element.querySelectorAll(listElm).length != 0) {
		let listNum = 1;

		clone_element.querySelectorAll(listElm).forEach((e, i) => {
			let num = String(listNum).padStart(3, '0');
			//href値の最後尾のフォルダ名を取り出し番号を再設置
			let listName = num + '.' + e.children[0].getAttribute('href').split('/').slice(-2)[0];

			e.children[0].remove();//a要素を削除
			// e.children[0].remove();//link-name要素を削除
			e.insertAdjacentHTML("afterbegin", '<a>' + listName + '</a>');//リスト名を挿入

			if (listNum == e.parentNode.children.length) {
				listNum = 1;
			} else {
				listNum++;
			}
		});

		listElm = listElm + '> ul > li';
	}


	const menu_list = clone_element.querySelectorAll('#menu li');

	//コピー要素のメニューフォルダ名を配列に格納
	menu_list.forEach((e) => {
		let listParent = e.parentNode;
		let menuId = listParent.getAttribute('id');
		let menuTxt = e.children[0].textContent;//例)01.base
		let linkName = menuTxt.split('.')[1];//例)base

		while (menuId != 'menu') {
			if (listParent.childNodes[0] != '') {
				menuTxt = listParent.previousElementSibling.textContent + '/' + menuTxt;
			}

			listParent = listParent.parentNode;
			menuId = listParent.getAttribute('id');
		}

		menuArray.push(menuTxt)//メニュー配列に追加
		menuObj[linkName] = menuTxt;//メニューオブジェクトに追加
	})

	menuJson = menuArray;//メニュー配列
	menuStr = JSON.stringify(menuJson);//文字列に変換
	menu_obj = menuObj;//メニューオブジェクト
}



//削除したフォルダをゴミ箱(trush)に移動
function folder_trush() {
	let fd = new FormData();
	fd.append('eventName', event_name);

	fetch('../public/trush', {
		// fetch('../admin/trush.php',{cache: "no-store"})
		method: 'post',
		body: fd,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response;
		})
		.then((data) => {

		})
		.catch((reason) => {
			// エラー
		});
}






//--------------------//
//  フォルダ名変更    //
//------------------//

const btn_chg_fd = document.getElementById('btn-change-folder');
const fdchg_msg = document.getElementById('folder-change-message');
const fdchg_modal = document.getElementById('fdChangeModal');
const chg_modal = new bootstrap.Modal(document.getElementById('fdChangeModal'));
const fdname_elm = document.getElementById('change-folder');


btn_chg_fd.addEventListener('click', function(){

	//メニューから配列を作成
	menu_create();

	let folderReName = fdname_elm.value;

	if (folderReName == '') {
		fdchg_msg.innerHTML = 'フォルダ名の値が空です';

	} else if(folderChgName==folderReName){
		fdchg_msg.innerHTML = '同じフォルダ名のままです。';

	} else if (folderReName.match(/\.|\*|"|:|\?|<|>|\//)) {
		fdchg_msg.innerHTML = '. * " : ? < > / のいづれかの文字が含まれています。';

	} else if(!folderReName.match(/^[!-~]+$/)) {
		fdchg_msg.innerHTML = '英数字以外の文字や空白またはその他の使用できない文字が含まれています。';

	} else if (folderReName.match(/\\/)) {
		fdchg_msg.innerHTML = '「\」がフォルダ名に含まれています。';

	} else if (isKeyExists(menu_obj, folderReName)) {
		fdchg_msg.innerHTML = '同じフォルダ名があります。';

	} else {
		chg_modal.hide();

		let dirName = menu_obj[folderChgName];//変更前のディレクトリ
		let dirReName = dirName.replace(folderChgName, folderReName);//変更後のディレクトリ


		if (!isKeyExists(menu_obj, folderReName)) {

			const eventName = 'フォルダ名変更';
			const formData = new FormData;
			formData.append('post_dir', dirName);
			formData.append('post_redir', dirReName);
			formData.append('post_folderName', folderChgName);
			formData.append('post_folderReName', folderReName);
			formData.append('eventName', eventName);//イベント処理名

			fetch('../public/folder_rename', {//フォルダ名変更
				method: 'POST',
				body: formData,
			}, { cache: "no-store" })

				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then((data) => {

					if (data=='') {
						//フォルダ名テキスト変更
						document.querySelector('#' + menuChgId + ' .link-name').textContent = folderReName;//メニューのフォルダ名変更
						let href = document.getElementById(menuChgId).firstElementChild.getAttribute('href');//href値のフォルダ名を変更
						let hrefArray = href.split('/');
						hrefArray.splice(-2, 1, folderReName);
						let hrefRe = hrefArray.join('/');
						document.getElementById(menuChgId).firstElementChild.setAttribute('href', hrefRe);

						completeMsg('フォルダ名を変更しました。');

					} else {
						alert(data)
					}
				})

				.catch((reason) => {
					alert('失敗しましたよ～。')
				});
			}
	}
})

function folderRename(e) {

	if(soating == true){
		//並べ替え中　警告アラート
		soatModal.show();

		return false;
	}

	folderChgName = e.target.previousSibling.textContent;
	fdname_elm.value = folderChgName;
	menuChgId = e.target.parentNode.getAttribute('id');
	document.getElementById('folder-change-message').textContent = '';
}






//--------------------//
//    バックアップ    //
//------------------//

// document.getElementById('btn-backup').addEventListener('click', () => {
// 	//pagesフォルダのバックアップ
// 	if (window.confirm('バックアップを取りますか?')) {
// 		const backup_elm = document.getElementById('backup-alert');

// 		fetch('../public/backup', {
// 			method: 'post'
// 		}, { cache: "no-store" })
// 			.then((response) => {
// 				if (!response.ok) {
// 					throw new Error();
// 				}
// 				return response;
// 			})
// 			.then(response => response.text())
// 			.then(data => {
// 				alert('pages_backupフォルダにバックアップを取りました。')
// 			})
// 			.catch(() => {
// 				//エラー
// 				console.log('エラー')
// 			})
// 	}
// })


//--------------------//
//    フォルダ削除    //
//------------------//

const delmodal_elm = document.getElementById('fdDelModal');
const del_modal = new bootstrap.Modal(document.getElementById('fdDelModal'));
const fdDelName_elm = document.getElementById('folder-name');

function folder_del(e){

	if(soating == true){
		//並べ替え中　警告アラート
		soatModal.show();
		return false;

	}else{
		boolSub = e.target.parentNode.lastElementChild.classList.contains('sub-menu');

		if(boolSub==true){
			document.getElementById('all-del').classList.remove('d-none');
		}else{
			document.getElementById('all-del').classList.add('d-none');
		}
	}


	dialog = document.getElementById('fdDelModal');
	only_elm = document.getElementById('only-del');
	all_elm = document.getElementById('all-del');
	menuId = e.target.parentNode.getAttribute('id');
	delmodal_elm.dataset.id = menuId;//ダイアログに削除フォルダのidをデータ属性に設定

	//削除リスト数
	const list_elm = e.target.parentNode.querySelectorAll('li');
	delListNum = list_elm.length+1;

	let listName = e.target.parentNode.children[0].textContent;//メニュー名
	let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
	folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide

	fdDelName_elm.innerHTML = listName + '【' + folderName + '】';

	menu_create();//メニュー配列
	only_delete();//対象フォルダのみ削除
	all_delete();//配下のフォルダも削除
}





//-------------------------//
// ダイアログ（フォルダ削除）//
//------------------------//

//対象フォルダのみ削除
function only_delete(){
	only_elm.addEventListener('click', function () {
		const event_name = '対象フォルダのみ削除';
		let fd = new FormData();
		fd.append('eventName', event_name);
		fd.append('folderName', folderName);

		fetch('../public/folderDelOnly', {
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {
				//DBのlockリストデータ削除
				lockdata_delete(folderName);

				//配下にリストがあるか判定
				if(delListNum==1){
					//フォルダカウント数変更
					let fdcount = Number(document.querySelector('#folder-count dd').textContent);//削除前のフォルダ数
					fdcount = fdcount - 1;
					document.querySelector('#folder-count dd').innerHTML = fdcount;//削除後のフォルダ数に差し替え
					let fdId = document.getElementById('fdDelModal').dataset.id;
					let fdId_elm = document.getElementById(fdId);

					// 前後にリストがあるか判定
					if(fdId_elm.previousElementSibling || fdId_elm.nextElementSibling){
						//前後にリストあり
						fdId_elm.remove();//メニューから削除したフォルダのリストを削除

					}else{
						//前後にリストなし
						fdId_elm.parentNode.remove();//メニューから削除したフォルダのリストの親のulごと削除
					}

				}else{

				}
				completeMsg('削除しました。');
				location.reload();//リロード

			})
			.catch(() => {
				console.log('エラー')
			})
	});
}


//配下のフォルダも削除
function all_delete(){
	all_elm.addEventListener('click', function () {

		const event_name = '配下のフォルダも削除';
	
		let fd = new FormData();
		fd.append('eventName', event_name);
		fd.append('folderName', folderName);
	
		fetch('../public/del_allfolder', {
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {
				let fdId = document.getElementById('fdDelModal').dataset.id;
				let fdId_elm = document.getElementById(fdId);
	
				//前後にリストがあるか判定
				if(fdId_elm.previousElementSibling || fdId_elm.nextElementSibling){
					// 他リスト有り
					fdId_elm.remove();//メニューから削除したフォルダのリストを削除
				}else{
					//他リストなし
					fdId_elm.parentNode.remove();//メニューから削除したフォルダのリストの親のulごと削除
				}
	
				//DBのlockリストデータ削除
				lockdata_delete(folderName);
				//フォルダカウント数変更
				let fdcount = Number(document.querySelector('#folder-count dd').textContent);//削除前のフォルダ数
				fdcount = fdcount - delListNum;
				document.querySelector('#folder-count dd').innerHTML = fdcount;//削除後のフォルダ数に差し替え

				completeMsg('削除しました。');
				location.reload();//リロード
			})
			.catch(() => {
				console.log('エラー')
			})
	});
}



//lockデータ削除 
function lockdata_delete(folderName) {

	//データベースのlocklistテーブルに登録があれば削除する
	const formData = new FormData;
	formData.append('post_delFolder', folderName);
	formData.append('eventName', event_name);

	fetch('../public/lockdata_del', {
		method: 'POST',
		body: formData,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response.text();
		})
		.then(data => {
			//通信成功時の処理
			// alert(data);
			//alert('DBの閲覧不可の登録を削除しました');
		})
		.catch((reason) => {
			alert('DBデータ削除に失敗しました～。')
		});
}






//------------------------//
//      並び替え確定      //
//----------------------//

//フォルダ使用中かチェック用関数
function useCheck() {
	return new Promise(function (resolve) {

		menu_create();//メニューから配列を作成

		let fd = new FormData();
		fd.append('list', menuStr);//メニューを格納
		
		resolve(fetch('../public/folderUseCheck', {
			method: 'post',
			body: fd,
		},  { cache: "no-store" })
			.then(response => response.text())
			.then(data => {
				return data;
			}));
	})
}


//pages内のディレクトリ連想配列取得
function pagesDirGet() {
	return new Promise(function (resolve) {

		resolve(fetch('../public/pagesDirGet', {
			method: 'post',
		},  { cache: "no-store" })
			.then(response => response.text())
			.then(data => {
				let array = JSON.parse(data);
				return array;
			}));
	})
}



//------------------------//
//      並び替え確定      //
//----------------------//

async function pagesSort(dirObj){

	let check2 = await useCheck();

	//ファイルやフォルダが使用されている場合、処理停止。
	if(check2=='false'){
		alert('フォルダ（ファイル）が使用されていたり、開かれてたりすると並べ替えができないことがあります。確認してみてください。');

		return false;

		window.location.reload();
	}
	

	if (window.confirm('並べ替えの確定をしていいですか？')) {
		event_name = '並べ替え確定';
		elm_msgbox.insertAdjacentHTML("afterbegin", '<p class="sort-text text-primary">並べ替え確定中です。他の操作はしないでください。</p>');
		
		soating = true;//並べ替え中
		menu_create();//メニューから配列を作成

		let fd = new FormData();
		fd.append('list', menuStr);//メニューを格納

		dirObjStr = JSON.stringify(dirObj);
		fd.append('dirObj', dirObjStr);//並べ替え履歴配列を格納

		fetch('../public/sort_confirm', {
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {
				const regexp = new RegExp(/エラー|失敗|強制終了/);

				if(!regexp.test(data)){
					soating = false;
					completeMsg('並び替えが完了しました。');

				}else{

					alert('並び替えが完了しました。一部フォルダの移動に失敗しました。'+data)

					document.getElementById('warning').innerHTML = data;
				}

				document.getElementById('sort-msgbox').innerHTML = '';

			})
			.catch(() => {
				alert('並び替え中にエラーが発生しました。')
				document.getElementById('sort-msgbox').innerHTML = '';
			})
			.finally(() => {

				fetch('../public/num_replace', {
					method: 'post',
					body: fd,
				}, { cache: "no-store" })
					.then((response) => {
						if (!response.ok) {
							throw new Error();
						}
						return response;
					})
					.then(response => response.text())
					.then(data => {
						// window.location.reload();
					});
			})
		}
}



//並べ替え確定実行
document.querySelector('#btn-execution-sabun').addEventListener('click', e => {
	pagesSort(dirObj);
});



//完了メッセージ用モーダル　一定時間経過後消える処理
function modalFdHide() {
	return new Promise(function (resolve) {
		soatModal.hide();
		resolve();
	})
}

async function completeMsg(msg){
	await modalFdHide();
	document.querySelector('#successModal .success-msg').textContent = msg;
	successMsgModal.show();

	successMsg.addEventListener('shown.bs.modal', (e) => {
		setTimeout(function () {
			successMsgModal.hide();
		}, 3000);
	});
}



//フォルダ名変更
document.querySelectorAll('.folder-rename').forEach((elm, i) => {
	elm.addEventListener('click', e => {
		folderRename(e);
	});
});

fdchg_modal.addEventListener('shown.bs.modal', e => {
    document.getElementById("change-folder").focus();
})



//新規フォルダ作成 テキスト欄にフォーカス移動
fd_modal.addEventListener('shown.bs.modal', event => {
    document.getElementById("create-folder").focus();
})


//フォルダ削除
document.querySelectorAll('.folder-del').forEach((elm, i) => {
	elm.addEventListener('click', e => {
		folder_del(e);
	});
});


//ロック設定
document.querySelectorAll('.btn-lock').forEach((elm, i) => {
	elm.addEventListener('click', e => {
		folder_lock(e);
	});
});


//ロック解除
document.querySelectorAll('.unlock').forEach((elm, i) => {
	elm.addEventListener('click', e => {
		folder_lock(e);
	});
});


//メニュー名変更
document.querySelectorAll('#menu li a').forEach(elm => {
	elm.addEventListener('click', function (e) {
		menu_rename(e);
	});
});