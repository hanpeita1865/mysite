---
title: ' Frontend Edit Button（管理画面表示ボタン）'
media_order: 'Edit_Button.png,btn_ediit.png'
taxonomy:
    category:
        - docs
visible: true
---

 <i class="fa fa-check-square text-primary"></i>（テンプレート設定済み）

user > plugins > frontend-edit-button > templates > partials > **edit-button.html.twig**  
の16行目の **{{ 'PLUGIN_FRONTEND_EDIT_BUTTON.BUTTON_TEXT'|t }}** の**{{  }}**内のテキストを変えればボタンの文字が変えられます。


例えば、「管理画面へ」に変更する場合、
<pre>
{{ '管理画面へ'|t }}
</pre>

にします。

**表示変更後 →**　![](btn_ediit.png?classes=d-inline,my-0,ml-2)

ボタンの位置設定は、Frontend Edit Buttonの設定画面の**Label Position**の値を変えます。  
（左下の場合 → Bottom Left、 右上の場合 → Top Right  など）

![](Edit_Button.png)


 

 