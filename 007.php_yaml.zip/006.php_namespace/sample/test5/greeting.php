<?php
namespace Asia\Japan\Kanto\Tokyo;
class hoge {
        function hello() {
                return 'こんにちは';
        }
}
