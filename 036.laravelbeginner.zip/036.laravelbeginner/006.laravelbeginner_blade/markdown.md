*[page-title]:07. Bladeテンプレートを使う

Laravelには、「<span class="green bold">Blade</span>」という独自のテンプレートエンジンが用意されています。このテンプレートの基本的な書き方を覚えましょう。そしてフォーム送信などの基本的な処理が行えるようになりましょう。

## Bladeを使う
PHPスクリプトファイルをそのままテンプレートとして使うのは、わかりやすくていいのですが、記述が煩雑になってしまうきらいがあります。ちょっと値を表示するだけでも、**<?php echo 00; ?>**などと書かなければならないのですから。 また、PHPタグが&lt;&gt;を使っており、一般的なHTMLのタグと同じ形式になっているため、HTMLの作成ツールなどを使うとタグの構造が崩れたりしてしまいますし、ページをいくつかに分割してまとめてレイアウトするような機能もありません。全部、HTMLとPHPで手作業でレイアウトしていくしかないのです。  

Laravelに独自に用意されている「<span class="green bold">Blade（ブレード）</span>」というテンプレートエンジンは、非常に効率的にレイアウトを作成していくための機能を持っています。テンプレートを 継承して新たなテンプレートを定義したり、レイアウトの一部をセクションとしてはめ込むなどしてレイアウトを作っていくことができます。Laravelを利用しているなら、ぜひBladeを使ってテンプレート作成をできるようになりたいところです。


### テンプレートを作る
では、実際にBladeテンプレートを作って利用してみることにしましょう。Bladeテン プレートも、PHPテンプレートと同様、「**resources**」内の「**veiws**」フォルダの中に配置し ます。  
「views」内に作成した「hello」フォルダの中に、「<span class="red">index.blade.php</span>」という名前でファイルを作成してください。これがBladeのテンプレートファイルです。Bladeは、このように「<span class="red bold">○○.blade.php</span>」という名前でファイルを用意します。 作成したindex.blade.phpには、以下のようにソースコードを記述してください。

<p class="tmp list"><span>リスト1</span>index.blade.php</p> 
```
<html>
<head>
   <title>Hello/Index</title>
</head>
<body>
   <h1>Blade/Index</h1>
   <p>{{$msg}}</p>
</body>
</html>
```
基本的な部分は、普通のHTMLそのままです。ただし、よく見ると、&lt;p&gt;タグの部分に、<span class="red"> {{$msg}}</span>が用意されています。これは、変数「<span class="red">$msg</span>」を埋め込んだものです。Bladeでは、<span class="blue bold">{{$ 変数}}</span>というようにして変数をテンプレート内に埋め込むことができます。


### アクションの修正

さきほどの「HelloController.php」とは別に説明しやすいようにもう一つコントローラーを作成しておきましょう。  
ファイル名は任意でいいので、とりあえず「Hello2Controller.php」とします。

artisanコマンドを実行してコントローラーを作成します。
```
php artisan make:controller Hello2Controller
```

![](upload/hello2Controllerファイル作成.png)

では、続いてコントローラのアクションメソッドを作成しましょう。 indexアクショ ンメソッドを以下のように追記して下さい。
<p class="tmp list"><span>リスト2</span>HelloController.php</p>
```
public function index()
{
   $data = [
       'msg'=>'これはBladeを利用したサンプルです。',
   ];
   return view('hello.index', $data);
}
```

web.phpにルート情報を追記します。
<p class="tmp list"><span>リスト3</span>web.php</p>
```
Route::get('hello2', [\App\Http\Controllers\Hello2Controller::class,'index']);
```


これで完成です。/hello2 にアクセスすると、hello/index.blade.phpテンプレートを使って画面が表示されます。（テンプレートは前項で作成したのを使っています）
![](upload/hello2にアクセス.png){.photo-border}

<div class="memo-box" markdown="1">
##### index.phpとindex.blade.php、どっちを使うの?
index.blade.phpを使ってページの表示ができましたが、ちょっと考えてみて下さい。 ここでは、「Bladeテンプレートを使う」といった設定は一切行っていません。そして、こ れまで使っていたindex.phpもそのままになっています。それなのに、view('hello.index' ~ ) と実行すると、index.blade.phpを使って画面の表示がされました。
Laravelでは、Bladeテンプレートがあると、それが優先して読み込まれます。テンプレート名を'index'と指定してあるなら、index.phpではなく、<span class="red bold">index.blade.php</span>が使われるのです。このファイルがない場合には、<span class="blue bold">index.php</span>が使われます。このため、同名のファイル「○○.php]「○○.blade.php」があれば、「○○.blade.php」が使われます。
</div>


## フォームを利用する
基本的なWebページの表示ができるようになったところで、次は「<span class="red">フォーム送信</span>」を行ってみましょう。フォームは、ユーザーからの入力を受けて処理をする際の基本となるものです。  
これも実際にサンプルを作りながら説明しましょう。まずは、テンプレート側からです。index.blade.phpの&lt;body&gt;タグ部分を以下のように修正して下さい。

<p class="tmp list"><span>リスト4</span>form.blade.php</p>
```
<body>
   <h1>Blade/Index</h1>
   <p>{{$msg}}</p>
   <form method="POST" action="/hello2Form">
       {{ csrf_field() }}
       <input type="text" name="msg">
       <input type="submit">
   </form>
</body>
```
ここでは、**&lt;form method="POST" action="/hello"&gt;**という形でフォームを用意して あります。/helloformにPOST送信されたときの処理を用意すれば、そこで送られたフォームを処理できるようになります。 ここでの最大のポイントは、&lt;form&gt;タグの次にある文です。
```
{{ csrf_field() }}
```
*csrf_field* を呼び出しています。これは「**ヘルパ関数**」と呼ばれ、テンプレートで必要になるコードの生成を手助けしてくれるものです。


### CSRF対策について
「<span class="red">csrf_field</span>」は、CSRF対策のために用意されたヘルパ関数です。 CSRFは、「Cross Site Request Forgery」と呼ばれる、Webサイト攻撃の一つです。スクリプトなどを使い、外部からフォームを送信するもので、フォームに大量のコンテンツを送りつけたりするのに用いられています。  

<p class="markdown">csrf_fieldは、「<span class="red">トークン</span>」と呼ばれるランダムな文字列を非表示フィールドとして追加します。そして、このトークンの値が正しいフォームだけを受け付けるようにします。 こうすることで、用意されたフォームからの送信かどうか見分けることができるようになり、フォーム以外からの送信を受け付けないようにします。<br>
Laravelでは、CSRF対策がなされていないフォームの送信は、例外が発生して受け付けられないようになっています。したがって、<span class="marker-yellow30">フォームを利用する際には、必ず「csrf_ field」をフォーム内に用意しておく</span>必要があります。</p>

![](upload/blade_02.png "図 CSRFは外部からプログラムなどによってフォームを送信する攻撃。用意されたフォームかど うか見分ける工夫が必要になる。")


### アクションの用意
では、コントローラにアクションを用意しましょう。今回は、/helloFormにアクセスしたときの表示と、フォームを送信したときの処理の2つのアクションが必要となります。  
Hello2Controller.phpを開き、Hello2Controllerクラスを以下のように修正して下さい (namespace、useは省略)。
    
<p class="tmp list"><span>リスト5</span>Hello2Controller.php</p>
```
class Hello2Controller extends Controller {
	public function index()
	{
			$data = [
					'msg'=>'お名前を入力下さい。',
			];
			return view('hello.form', $data);
	}

	public function post(Request $request)
	{
			$msg = $request->msg;
			$data = [
					'msg'=>'こんにちは、' . $msg . 'さん！',
			];
			return view('hello.form', $data);
	}
}
```

<p class="tmp list"><span>リスト</span>web.php</p>
```
Route::get('hello2', [\App\Http\Controllers\Hello2Controller::class,'index']);
Route::post('hello2', [\App\Http\Controllers\Hello2Controller::class,'post']);
```

<!--
![](blade_03.png?classes=caption "図　リスト5のPOSTのルート設定をすると、フォームに名前を入力して送信したら、「こんにちは、○○さん!」と表示される。")
-->

1. 「/hello2Form」にアクセスします。
![](upload/hello2Formアクセス表示.png){.photo-border}

2. 名前を入力して「送信」ボタンを押します。
![](upload/hello2Form名前を入力.png){.photo-border}

3. 「こんにちは、〇〇〇〇さん！」と表示されます。
![](upload/hello2Form名前が表示.png){.photo-border}

※引き続き名前を入力して送信できます。


<!--リスト5のPOSTのルート設定をすると、フォームに名前を入力して送信したら、「こんにちは、○○さん!」と表示されます。-->


解説）  
formメソッドは、/helloFormにアクセスした際の処理です。  
postメソッドが、/helloFormにPOST送信されたときの処理です。ここではRequestインス タンスを引数に用意してあります。そして、以下のようにフォームの内容を取り出しています。
```
$msg = $request->msg;
```
リスト4で「**name="msg"**」を指定してあったフィールドの値は、リスト5のように「**$request->msg**」で取り出すことができます。フォームで送信された値は、すべてnameのプロパティとして取り出せるようになっています。
    

POST送信は、「**Route::post**」というメソッドで設定します。メソッド名が違うだけで、 使い方はRoute::getと同じです。割り当てるアドレスと、呼び出すアクションをそれぞれ 引数に指定します。  
ここでは、「/hello2Form」にHelloControllerクラスのpostメソッドを割り当ててあります。同じアドレスでも、GETとPOSTというようにアクセスするメソッドの種類が違えば両方共に 使うことができます。