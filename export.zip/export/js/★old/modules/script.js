import { previewSet } from "./preview";//プレビュー表示
import { menu_comp } from "./menu_complete";//メニュ設定
// import { markedConfig } from "./mk_compile";//マークダウン変換
import { modaal_comp } from "./modaal_complete";//モダール設定
import { figure_comp } from "./figure";//画像figure設定
import { modalwin } from "./modalwin";//モーダルウィンドウ設定
import { pagetop } from "./pagetop";//ページトップ
import { barLayout } from "./simplebar_layout";//simplebar、レイアウト


//マークダウン読み込みを最初に実行
// markedConfig(); 

//画像にfigureとfigcaptionを設置
figure_comp();

//メニュー設定
menu_comp();

//SimpleBar、レイアウト
barLayout();

//プレビュー
previewSet();

//ページトップ
pagetop();

//マークダウン用モーダルウィンドウ
modalwin();

//モダール設定
modaal_comp();

//replaceAllを独自に作成
// function replaceAll(org, search, replace) {
// 	return org.split(search).join(replace);
// }

