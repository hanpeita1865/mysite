const elem_box = document.getElementById('menu');
const box_items = document.querySelectorAll('.box-item');
const elem_reset = document.getElementById('reset');
const elm_container = document.querySelector('.container');
const elm_msgbox = document.getElementById('sort-msgbox');
let subMenu = document.querySelectorAll('.sub-menu');
let arrayStart = [];//デフォルトの並び順初期値
let menuJson = [];//メニューJson
let menuStr;//メニュー文字列
let menu_obj = {};//メニューオブジェクト
let list_elm;

//フォルダ構成をメニューに反映（初期表示）
// folder_complist_menu();


//並び順初期値格納
box_items.forEach(function (value) {
	arrayStart.push(value.getAttribute('id'));
});

box_items.forEach(elm => {
	//ボックスをダブルクリックして空のボックスを作成
	elm.addEventListener('dblclick', function (e) {

		let subLen = this.children.length;

		if (elm == e.target) {//2階層以下の複数実行防止

			//サブメニューの空ボックスを作成
			if (subLen == 5) {
				this.insertAdjacentHTML('beforeend', '<ul class="emp-ul sub-menu"></ul>\n');
				obj = this.lastChild;//サブメニューul要素

			} else {
				//サブメニュー開閉
				this.closest('.box-item').classList.toggle('s-close');
			}
		}
	})

	elm.setAttribute('draggable', 'true');

	let href = elm.querySelector('a').getAttribute('href');
	let folderName = href.split('/').slice(-2)[0];

	//ロックされてるリストか判定
	if(elm.querySelector('a').classList.contains('lock') || elm.querySelector('a').classList.contains('all-lock')){
		//ロック設定あり
		elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="unlock">ロック解除</button>');
	}else{
		elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="btn-lock" data-toggle="modal" data-target="#lockModal">ロック設定</button>');
	}

	elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="folder-del" data-toggle="modal" data-target="#fdDelModal">削除</button>');
	elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="folder-rename">フォルダ名変更</button>');
	elm.querySelector('a').insertAdjacentHTML('afterend', '<span class="link-name">' + folderName + '</span>');
	elm.querySelector('a').setAttribute('title', 'クリックするとメニュー名を変更できます。');

	if (elm.children.length > 5) {
		elm.querySelector('a').insertAdjacentHTML('beforeend', '<span class="icon-slide"></span>');
	}

	sortDrop(elm);
});

//ボックス並べ替え
function sortDrop(elm) {
	elm.ondragstart = function (e) {
		e.dataTransfer.setData('text/plain', e.target.id);
	};

	let empBox = 1;

	//ドラッグオーバー
	elm.ondragover = function (e) {
		e.preventDefault();

		if (elm == e.target.parentNode || elm == e.target) {

			if (e.target.classList.contains('emp-ul')) {
				e.stopPropagation(); //イベントを停止する
				e.preventDefault(); //画面遷移を行わない
				e.target.style.border = '4px solid green';
				empBox = e.target;

			} else if (e.target.closest('li').classList.contains('box-item')) {
				let rect = e.target.closest('li').getBoundingClientRect();
				let elm_over = this

				rectOver(e, rect, elm_over);//ボーダー表示

			} else {
				let rect = e.target.getBoundingClientRect();
				let elm_over = e.target;

				rectOver(e, rect, elm_over);//ボーダー表示
			}
		}
	};

	//ドラッグリープ（ボックスから離れる）
	elm.ondragleave = function (e) {
		if (empBox != 1) {
			empBox.removeAttribute('style');
		}

		this.style.borderTop = '';
		this.style.borderBottom = '';
	}

	//ドロップ
	elm.ondrop = function (e) {
		e.preventDefault();

		if (elm == e.target.parentNode || elm == e.target) {//2階層以下の複数実行防止

			let id = e.dataTransfer.getData('text/plain');
			const elm_drag = document.getElementById(id);

			try {
				if (e.target.classList.contains('emp-ul')) {//空のボックスに挿入

					let id = e.dataTransfer.getData('text/plain');
					let dropItem = document.getElementById(id);

					e.target.removeAttribute('style');
					e.preventDefault();

					try {

						e.target.appendChild(dropItem);
						e.target.closest('.box-item').firstElementChild.insertAdjacentHTML('beforeend', '<span class="icon-slide"></span>');

						dropItem.parentNode.classList.remove('emp-ul');
						subEmpDelete();

					} catch (error) {
						// console.log('エラー');
						dropItem.parentNode.classList.remove('emp-ul');
						subEmpDelete();
					}

				} else if (this.classList.contains('box-item')) { //並べ替え

					let rect = this.getBoundingClientRect();

					rectDrop(e, e.currentTarget, rect, elm_drag);//挿入位置が上側か下側かを判定
					subEmpDelete();//空になった挿入用ボックス削除
				}

				box_items.forEach(function (t) {
					t.removeAttribute('style');
				});

				document.querySelectorAll('.side-link li a').forEach(e => {
					let folderName = e.getAttribute('href').split('/').slice(-2)[0];
				})

				// menu_create();//メニューから配列を作成
				// folder_rebuilding(menuStr);//フォルダ再生成、menu_list.phpに保存

				if (elm_msgbox.children.length == 0) {
					elm_msgbox.insertAdjacentHTML("afterbegin", '<p class="sort-text">並べ替えをすべて済ませた後、<br>「並べ替え確定」ボタンを押してください</p>');
				}

			} catch (error) {
				// console.log('エラー')
				//ボーダー削除
				box_items.forEach(function (e) {
					e.removeAttribute('style');
				});

				subMenu.forEach(function (e) {
					e.removeAttribute('style');
				})
			}
		}
	};
}


//空になったsubメニューボックス削除
function subEmpDelete() {
	subMenu = document.querySelectorAll('.sub-menu');
	//空のボックスがある。
	subMenu.forEach(function (e) {
		if (e.children.length == 0 && !e.classList.contains('emp-ul')) {
			e.remove();
		}
	});

	//サブメニューない▲アイコン削除
	document.querySelectorAll('a span.icon-slide').forEach(function (e) {
		if (e.closest('.box-item').querySelector('.sub-menu') == null) {
			e.remove();
		}
	});
}

//マウスオーバーの上下ボーダー表示
function rectOver(e, rect, elm_over) {
	if ((e.clientY - rect.top) < (elm_over.clientHeight / 2)) {
		//マウスカーソルの位置が要素の半分より上
		elm_over.style.borderTop = '2px solid blue';
		elm_over.style.borderBottom = '';
	} else {
		//マウスカーソルの位置が要素の半分より下
		elm_over.style.borderTop = '';
		elm_over.style.borderBottom = '2px solid blue';
	}
}


//ドロップ上下判定
function rectDrop(e, t, rect, elm_drag) {
	if ((e.clientY - rect.top) < (rect.height / 2)) {
		//マウスカーソルの位置が要素の半分より上
		t.parentNode.insertBefore(elm_drag, t);
	} else {
		//マウスカーソルの位置が要素の半分より下
		t.parentNode.insertBefore(elm_drag, t.nextElementSibling);
	}
}


//リンク無効化
// document.querySelectorAll('a').forEach(elm => {
// 	elm.addEventListener('click', e => {
// 		e.preventDefault();
// 	});
// });


event_name = '';



//--------------------//
//    並べ替え確定    //
//------------------//
// document.querySelector('#btn-execution').addEventListener('click', e => {
// 	//let answer = window.prompt('並べ替えの確定をしていいですか？ 自動的に並べ替え前のバックアップを取ります。（「none」を入力すると、バックアップは取りません。）');
// 	if (window.confirm('並べ替えの確定をしていいですか？')) {
// 		event_name = '並べ替え確定';
// 		elm_msgbox.insertAdjacentHTML("afterbegin", '<p class="sort-text text-primary">並べ替え確定中です。他の操作はしないでください。</p>');
// 		menu_create();//メニューから配列を作成
// 		folder_rebuilding(menuStr, 'menu-folder');//フォルダ再生成、menu_list.twigに保存
// 	}
// });



//--------------------//
//  フォルダ新規作成  //
//------------------//
document.getElementById('create').addEventListener('click', () => {
	const newFolder = prompt('新規にフォルダ名を作成します。');

	//ダイアログ返答が「はい」なら実行
	if (newFolder != null) {

		//メニューから配列を作成
		menu_create();

		if (newFolder.match(/\.|\*|"|:|\?|<|>|\//)) {
			alert('. * " : ? < > / のいづれかの文字が新しいフォルダ名に含まれているので保存できません。');

		} else if (newFolder.match(/\\/)) {
			alert('「\」が新しいフォルダ名に存在するので保存できません。');

		} else if (newFolder == '') {
			alert('フォルダ名の値が空です');

		} else if (isKeyExists(menu_obj, newFolder)) {
			alert('同じフォルダ名があります。')

		} else {

			const eventName = 'フォルダ新規作成';
			const formData = new FormData;
			formData.append('post_newFolder', newFolder);//フォルダ名
			formData.append('eventName', eventName);//イベント処理名

			fetch('../public/folder_create', {//フォルダ新規作成
				method: 'POST',
				body: formData,
			}, { cache: "no-store" })

				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then(data => {
					//通信成功時の処理
					// let lastNum = document.getElementById('menu').lastElementChild.getAttribute('id').replace('item', '');
					// let newNum = Number(lastNum)+1;

					// newNum = ('000' + newNum).slice(-3);//id値の番号

					// //メニュー 新規リスト用HTML
					// let listHtml = '<li id="item'+ newNum +'" class="box-item" draggable="true"><a href="/from_now_slim/public/pages/'+ newFolder +'/" title="クリックするとメニュー名を変更できます。">メニュー名</a><span class="link-name">'+ newFolder +'</span><button class="folder-rename">フォルダ名変更</button><button class="folder-del" data-toggle="modal" data-target="#fdDelModal">削除</button><button class="btn-lock" data-toggle="modal" data-target="#lockModal">ロック変更</button></li>';
					
					// document.getElementById('menu').insertAdjacentHTML("beforeend", listHtml);

					// menu_rename();//メニュー名変更 再実行
					// // folder_del();//フォルダ削除 再実行
									
					// //フォルダカウント数変更
					// let fdcount = Number(document.querySelector('#folder-count dd').textContent);//削除前のフォルダ数
					// fdcount = fdcount + 1;
					// document.querySelector('#folder-count dd').innerHTML = fdcount;//削除後のフォルダ数に差し替え

					alert('フォルダを新規作成しました。')

					location.reload();//リロード
				})
				.catch((reason) => {
					alert('失敗しましたよ～。')
				});

		}
	};
});


//オブジェクトのキーに存在チェック関数
function isKeyExists(obj, key) {
	return key in obj;
}


//並べ替え関数
function compareFunc(a, b) {
	return a - b;
}


//--------------------//
//  ロック設定・解除  //
//------------------//
// document.querySelectorAll('.btn-lock').forEach(elm => {
// 	elm.addEventListener('click', e => {
// 		if (window.confirm('閲覧ロックの設定を変更していいですか？')) {
// 			let folderName = e.target.parentNode.children[1].textContent;
// 			const formData = new FormData;
// 			formData.append('post_folder', folderName);
// 			formData.append('eventName', event_name);

// 			fetch('../public/page_lock', {
// 				method: 'POST',
// 				body: formData,
// 			}, { cache: "no-store" })
// 				.then((response) => {
// 					if (!response.ok) {
// 						throw new Error();
// 					}
// 					return response.text();
// 				})
// 				.then(data => {
// 					//通信成功時の処理
// 					e.target.parentNode.children[0].classList.toggle('lock');
// 					alert(data);
// 				})
// 				.catch((reason) => {
// 					alert('失敗しました～。')
// 				});
// 		};
// 	});
// });


//ロックと解除を切り替えるクリックイベント
document.addEventListener('click', (e) => {
	if (e.target && e.target.classList.contains("btn-lock")) {

		lockDialog = document.getElementById('lockModal');
		onlylock_elm = document.getElementById('only-lock');
		alllock_elm = document.getElementById('all-lock');
		cancellock_elm = document.getElementById('cancel-lock');
		lockname_elm = document.getElementById('folder-name-lock');
		menulockId = e.target.parentNode.getAttribute('id');
		lockDialog.dataset.id = menulockId;//ダイアログにロックフォルダのidをデータ属性に設定
		lock_elm = e.target;

		//配下のリスト
		const list_elm = e.target.parentNode.querySelectorAll('li');
		lockListNum = list_elm.length+1;

		let listName = e.target.parentNode.children[0].textContent;//メニュー名
		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
		folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide

		lockname_elm.innerHTML = listName + '【' + folderName + '】';

		if(lockListNum==1){
			document.getElementById('all-lock').classList.add('d-none');
		}else{
			document.getElementById('all-lock').classList.remove('d-none');
		}

	} else if (e.target && e.target.classList.contains("unlock")) {

		lock_elm = e.target;
		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
		folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide

		let fd = new FormData();
		fd.append('eventName', 'ロック解除');
		fd.append('folderName', folderName);
	
		fetch('../public/page_unlock', {
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {
				alert('ロックを解除しました。');
				lock_elm.parentNode.children[0].classList.remove('lock','all-lock');
				lock_elm.classList.remove('unlock');
				lock_elm.classList.add('btn-lock');
				lock_elm.textContent='ロック設定';
				lock_elm.dataset.toggle = 'modal';
				lock_elm.dataset.target = '#lockModal';

			})
			.catch(() => {
				console.log('エラー')
			})
	}
});


// document.querySelectorAll('.btn-lock').forEach(elm => {
// 	elm.addEventListener('click', e => {

// 		lockDialog = document.getElementById('lockModal');
// 		// const btn = document.getElementById('btn');
// 		onlylock_elm = document.getElementById('only-lock');
// 		alllock_elm = document.getElementById('all-lock');
// 		cancellock_elm = document.getElementById('cancel-lock');
// 		lockname_elm = document.getElementById('folder-name-lock');
// 		menulockId = e.target.parentNode.getAttribute('id');
// 		lockDialog.dataset.id = menulockId;//ダイアログにロックフォルダのidをデータ属性に設定
// 		lock_elm = e.target;

// 		//配下のリスト
// 		const list_elm = e.target.parentNode.querySelectorAll('li');
// 		lockListNum = list_elm.length+1;

// 		let listName = e.target.parentNode.children[0].textContent;//メニュー名
// 		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
// 		folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide

// 		lockname_elm.innerHTML = listName + '【' + folderName + '】';

// 		if(lockListNum==1){
// 			document.getElementById('all-lock').classList.add('d-none');
// 		}else{
// 			document.getElementById('all-lock').classList.remove('d-none');
// 		}
		
// 	});
// });


//単独でロック追加
document.getElementById('only-lock').addEventListener('click', function (e) {
	let fd = new FormData();
	fd.append('eventName', event_name);
	fd.append('folderName', folderName);
	fd.append('under_dir', 'only');

	fetch('../public/page_lock', {
		method: 'post',
		body: fd,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response;
		})
		.then(response => response.text())
		.then(data => {

			lock_elm.parentNode.children[0].classList.add('lock');
			lock_elm.classList.remove('btn-lock');
			lock_elm.classList.add('unlock');
			lock_elm.textContent='ロック解除';
			lock_elm.dataset.toggle = '';
			lock_elm.dataset.target = '';

			alert('ロックを追加しました。');
		})
		.catch(() => {
			console.log('エラー')
		})
})


//配下もロック追加
document.getElementById('all-lock').addEventListener('click', function (e) {
	let fd = new FormData();
	fd.append('eventName', event_name);
	fd.append('folderName', folderName);
	fd.append('under_dir', 'all');

	fetch('../public/page_lock', {
		method: 'post',
		body: fd,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response;
		})
		.then(response => response.text())
		.then(data => {

			lock_elm.parentNode.children[0].classList.add('all-lock');
			lock_elm.classList.remove('btn-lock');
			lock_elm.classList.add('unlock');
			lock_elm.textContent='ロック解除';
			lock_elm.dataset.toggle = '';
			lock_elm.dataset.target = '';

			alert('ロックを追加しました。');
		})
		.catch(() => {
			console.log('エラー')
		})
})


//ロック解除
// document.querySelectorAll('.unlock').forEach(elm => {
// 	elm.addEventListener('click', function (e) {

// 		lock_elm = e.target;
// 		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
// 		folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide

// 		let fd = new FormData();
// 		fd.append('eventName', 'ロック解除');
// 		fd.append('folderName', folderName);
// 		console.log('ロック解除')
	
// 		fetch('../public/page_unlock', {
// 			method: 'post',
// 			body: fd,
// 		}, { cache: "no-store" })
// 			.then((response) => {
// 				if (!response.ok) {
// 					throw new Error();
// 				}
// 				return response;
// 			})
// 			.then(response => response.text())
// 			.then(data => {
// 				alert('ロックを解除しました。');
// 				lock_elm.parentNode.children[0].classList.remove('lock','all-lock');
// 				lock_elm.classList.remove('unlock');
// 				lock_elm.classList.add('btn-lock');
// 				lock_elm.textContent='ロック設定';
// 				lock_elm.dataset.toggle = 'modal';
// 				lock_elm.dataset.target = '#lockModal';

// 			})
// 			.catch(() => {
// 				console.log('エラー')
// 			})
// 	});
// });








//--------------------//
//   以前 フォルダ削除    //⇒不要
//------------------//
// document.querySelectorAll('.folder-del222').forEach(elm => {
// 	elm.addEventListener('click', e => {

// 		let listName = e.target.parentNode.children[0].textContent;//メニュー名
// 		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
// 		let folderName = listDir.split('/').slice(-2)[0];//フォルダ名
// 		let answer = window.prompt(listName + '【' + folderName + 'フォルダ】を削除していいですか？（「all」を入力すると、配下のページも削除できます。）', listName + '（' + folderName + 'フォルダ）');
// 		event_name = 'フォルダ削除';

// 		// 入力に応じて条件分岐
// 		if (answer === 'all') {
// 			e.target.closest('li').remove();
// 			alert('「' + listName + '」ページと配下のページを削除します。');

// 		} else if (answer === listName + '（' + folderName + 'フォルダ）') {
// 			//子要素を親要素の直後に移動して、親要素自体は削除する
// 			if (e.target.parentNode.children[5] != null) {
// 				Array.from(e.target.parentNode.children[5].children).forEach(obj => {
// 					e.target.parentNode.parentNode.insertBefore(obj, e.target.parentNode.nextSibling);
// 				});
// 			}

// 			e.target.closest('li').remove();
// 			// alert('「'+listName+'」ページを削除しました。');

// 		} else {
// 			alert('キャンセルしました。');
// 		}

// 		if (answer === 'all' || answer === listName + '（' + folderName + 'フォルダ）') {
// 			// if(elm_msgbox.children.length==0){
// 			elm_msgbox.insertAdjacentHTML("afterbegin", '<p class="sort-text">ページ（フォルダ）削除中です。<br>他の操作はしないでください。</p>');
// 			// }

// 			//メニューから配列を作成
// 			menu_create();
// 			//lockデータベースから削除
// 			lockdata_delete(folderName)
// 			//フォルダ再構成、menu_list.twigに保存
// 			folder_rebuilding(menuStr, 'menu-delete');
// 		}
// 	})
// })


//--------------------//
//   メニュー名変更   //
//------------------//

menu_rename();

function menu_rename(){
	document.querySelectorAll('#menu li a').forEach(elm => {
		elm.addEventListener('click', function (e) {
			let menuName = this.textContent;//例）メニュー名111
			let menuId = this.closest('li').getAttribute('id');
			let folderName = this.getAttribute('href').split('/').slice(-2)[0];//フォルダ名
			let folderDir = this.getAttribute('href');//パス
			let menuReName = prompt('名前を変更して「ok」を押してください', menuName);
	
			if (menuName != menuReName && menuReName != '' && menuReName != null) {
	
				menu_create();//メニュー配列
				let dirName = menu_obj[folderName];//変更前のディレクトリ
				// console.log(dirName);
				const eventName = 'メニュー名変更';
	
				let formData = new FormData;
				formData.append('post_menu', menuName);//変更前メニュー名
				formData.append('post_reName', menuReName);//変更後メニュー名
				formData.append('post_dir', folderDir);//パス
				formData.append('post_dirName', dirName);//パス（番号付き）
				formData.append('eventName', eventName);//イベント処理名
	
				fetch('../public/file_rename', {
					method: 'POST',
					body: formData,
				}, { cache: "no-store" })
					.then((response) => {
						if (!response.ok) {
							throw new Error();
						}
						return response.text();
					})
					.then(data => {
						//通信成功時の処理
						alert(data);
						if (data.match(/変更しました/)) {
							document.getElementById(menuId).firstElementChild.textContent = menuReName;
						}
	
					})
					.catch((reason) => {
						console.log('メニュー名変更に失敗しました。')
					});
	
			} else if (menuReName == '') {
				alert('メニュー名の値が空です');
			}
	
			//e.stopPropagation();
			e.preventDefault();
		});
	});
};




//--------------------//
// 全サブメニュー開閉  //
//------------------//

const btn_close = document.querySelectorAll('.btn-sub-close');

btn_close.forEach(elm => {
	elm.addEventListener('click', function (e) {

		if (e.target.classList.contains('open') == true) {
			// 閉じる
			btn_close.forEach(t => {
				t.classList.remove('open');
				t.textContent = '全サブメニュー開く';
			})

			document.querySelectorAll('.sub-menu').forEach(e => {
				e.closest('.box-item').classList.add('s-close');
			});
		} else {
			// 開く
			btn_close.forEach(t => {
				t.classList.add('open');
				t.textContent = '全サブメニュー閉じる';
			})

			document.querySelectorAll('.sub-menu').forEach(e => {
				e.closest('.box-item').classList.remove('s-close');
			});
		}
	});
});

//「▼」アイコンクリックでサブメニューを開閉
// document.addEventListener('click', function (e) {
// 	if (e.target && e.target.className == 'icon-slide') {
// 		e.target.closest('.box-item').classList.toggle('s-close');
// 	}
// });

//「▼」アイコンクリックでサブメニューを開閉
document.querySelectorAll('.icon-slide').forEach(elm => {
	elm.addEventListener('click', function (e) {
		e.target.closest('.box-item').classList.toggle('s-close');
	});
});



//メニューから配列を作成　JS only
function menu_create() {
	const menu = document.getElementById('menu');
	let clone_element = menu.cloneNode(true);//メニューをコピー
	let menuArray = [];
	let menuObj = {};

	// console.log(clone_element)

	//コピーメニューからボタン削除
	clone_element.querySelectorAll('button').forEach(e => {
		e.remove();
	})

	// //コピーメニューから.link-name要素を削除
	clone_element.querySelectorAll('.link-name').forEach(e => {
		e.remove();
	})

	//コピー要素から属性の削除
	clone_element.querySelectorAll('li').forEach(e => {
		e.removeAttribute('id');//id属性の削除
		e.removeAttribute('class');//class属性の削除
		e.removeAttribute('draggable');//draggable属性の削除
	})

	let listElm = '#menu > li';
	//コピー要素の頭に番号を付与
	while (clone_element.querySelectorAll(listElm).length != 0) {
		let listNum = 1;

		clone_element.querySelectorAll(listElm).forEach((e, i) => {
			let num = String(listNum).padStart(3, '0');
			//href値の最後尾のフォルダ名を取り出し番号を再設置
			let listName = num + '.' + e.children[0].getAttribute('href').split('/').slice(-2)[0];

			e.children[0].remove();//a要素を削除
			// e.children[0].remove();//link-name要素を削除
			e.insertAdjacentHTML("afterbegin", '<a>' + listName + '</a>');//リスト名を挿入

			if (listNum == e.parentNode.children.length) {
				listNum = 1;
			} else {
				listNum++;
			}
		});

		listElm = listElm + '> ul > li';
	}


	const menu_list = clone_element.querySelectorAll('#menu li');

	//コピー要素のメニューフォルダ名を配列に格納
	menu_list.forEach((e) => {
		let listParent = e.parentNode;
		let menuId = listParent.getAttribute('id');
		let menuTxt = e.children[0].textContent;//例)01.base
		let linkName = menuTxt.split('.')[1];//例)base

		while (menuId != 'menu') {
			if (listParent.childNodes[0] != '') {
				menuTxt = listParent.previousElementSibling.textContent + '/' + menuTxt;
			}

			listParent = listParent.parentNode;
			menuId = listParent.getAttribute('id');
		}

		menuArray.push(menuTxt)//メニュー配列に追加
		menuObj[linkName] = menuTxt;//メニューオブジェクトに追加
	})

	menuJson = menuArray;//メニュー配列
	menuStr = JSON.stringify(menuJson);//文字列に変換
	menu_obj = menuObj;//メニューオブジェクト
}


//フォルダ再生成（フォルダのリスト取得と重複チェックを含む）
function folder_rebuilding(menuStr, check, answer) {

	let fd = new FormData();
	fd.append('eventName', event_name);

	fetch('../public/folder_list', { //フォルダのリストを取得
		method: 'post',
		body: fd,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response;
		})
		.then(response => response.text())
		.then(data => {

			let ul_element = document.createElement('ul');//ul要素を生成
			ul_element.innerHTML = data;//メニューのコピー挿入

			//番号を削除
			list_elm = ul_element.childNodes;//フォルダのリスト
			let listArray = Array.from(list_elm).map(e => {
				let name = e.textContent.replace(/^\d{3}./, '');
				return name;
			})

			// console.log(list_elm)

			check_folderCreate(list_elm, check, answer)//フォルダのチェック及びフォルダ再生成
		})
		.catch(() => {
			//エラー
		})
}

//削除したフォルダをゴミ箱(trush)に移動
function folder_trush() {
	let fd = new FormData();
	fd.append('eventName', event_name);

	fetch('../public/trush', {
		// fetch('../admin/trush.php',{cache: "no-store"})
		method: 'post',
		body: fd,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response;
		})
		.then((data) => {

		})
		.catch((reason) => {
			// エラー
		});
}

//フォルダのチェック及びフォルダ再生成　
function check_folderCreate(list_elm, check, answer) {

	let checkBool = true;//チェック値（初期値）
	let nameArray = [];//フォルダ名を配列に格納
	let overRap = [];//重複してるフォルダを取得
	let message = [];


	//重複フォルダのチェック
	list_elm.forEach(e => {
		let nameRep = e.textContent.replace(/^\d{3}./, '');
		if (nameArray.includes(nameRep)) {
			//同じフォルダがある
			if (!overRap.includes(nameRep)) {
				overRap.push(nameRep);
			}
		} else {
			nameArray.push(nameRep);//フォルダリスト配列  ['test1111', 'test2', ...]
		}
	});

	//フォルダ名に重複があるかチェック
	if (overRap.length != 0) {
		let rapText = '';
		overRap.forEach((e, i) => {
			if (i == 0) {
				rapText = e;
			} else {
				rapText = rapText + '、' + e;
			}
		});
		// alert(rapText + 'フォルダが複数あります。確認してください。');
		message.push(rapText + 'フォルダが複数あります。確認してください。');
		checkBool = false;
	}

	let menu_list = menuJson.map(e => {
		return e.split('/').slice(-1)[0];;
	});


	// //メニュー → フォルダ 存在チェック
	// if(check=='menu-folder'){
	// 	nameArray.forEach(e=>{
	// 		let hasKey = Object.keys(menu_obj).some(x => x == e);//「e」が「menu_obj」のキーに存在するか判定
	// 		if(!hasKey){
	// 			message.push('メニューの'+e+'はフォルダに存在しません。確認してください。')
	// 			checkBool = false;
	// 		}
	// 	});
	// }

	// //フォルダ → メニュー 存在チェック
	// if(check=='folder-menu'){
	//     nameArray.forEach(e=>{
	//         if(!menu_list.includes(e)){
	//             alert(e+'フォルダはメニューに存在しません。確認してください。');
	// 			message.push(e+'フォルダはメニューに存在しません。確認してください。')
	//             checkBool = false;
	//         }
	//     });
	// }

	if (checkBool) {

		//メニューとフォルダに問題がなければ実行
		let fd = new FormData();
		fd.append('folder', '../pages');
		fd.append('list', menuStr);//メニューを格納
		fd.append('eventName', event_name);

		fetch('../public/sort_complete', {//並べ替え実行
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {

				console.log(data)

				if(data==''){
					alert('並び替えを確定しました。')
				}else{
					alert('並び替えに失敗しました。移動できなかったフォルダがあります。')
					document.getElementById('warning').innerHTML = data;
				}

				document.getElementById('sort-msgbox').innerHTML = '';

			})
			.catch(() => {
				//エラー
				console.log('エラー')
				document.getElementById('sort-msgbox').innerHTML = '';
			})

	} else {
		console.log(message)
		let msgHtml = '';

		message.forEach(e => {
			msgHtml = msgHtml + ' ' + e;
		})
		alert(msgHtml);
	}
}


//--------------------//
//  フォルダ名変更    //
//------------------//
document.querySelectorAll('.folder-rename').forEach((elm, i) => {

	elm.addEventListener('click', e => {
		let folderName = e.target.previousSibling.textContent;
		let menuId = e.target.parentNode.getAttribute('id');
		let folderReName = prompt('フォルダ名を変更して「ok」を押すと元には戻せません。）', folderName);

		menu_create();//メニュー配列

		if (folderReName == null || folderName == folderReName) {//キャンセルまたは名前を変えずにokを押した場合

		} else if (folderReName.match(/\.|\*|"|:|\?|<|>|\//)) {
			alert('. * " : ? < > / のいづれかの文字が新しいフォルダ名に含まれているので保存できません。');

		} else if (folderReName.match(/\\/)) {
			alert('「\」が新しいフォルダ名に存在するので保存できません。');

		} else if (folderReName == '') {
			alert('フォルダ名の値が空です');

		} else if (isKeyExists(menu_obj, folderReName)) {
			alert('同じフォルダ名があります。')
		} else {

			let dirName = menu_obj[folderName];//変更前のディレクトリ
			let dirReName = dirName.replace(folderName, folderReName);//変更後のディレクトリ

			if (!isKeyExists(menu_obj, folderReName)) {
				const eventName = 'フォルダ名変更';
				const formData = new FormData;
				formData.append('post_dir', dirName);
				formData.append('post_redir', dirReName);
				formData.append('post_folderName', folderName);
				formData.append('post_folderReName', folderReName);
				formData.append('eventName', eventName);//イベント処理名

				fetch('../public/folder_rename', {//フォルダ名変更
					// fetch('../admin/folder_rename.php', {//フォルダ名変更
					method: 'POST',
					body: formData,
				}, { cache: "no-store" })

					.then((response) => {
						if (!response.ok) {
							throw new Error();
						}
						return response.text();
					})
					.then((data) => {

						if (data.match(/フォルダ名を変更しました。/)) {
							//フォルダ名テキスト変更
							e.target.previousSibling.textContent = folderReName;
							//href値のフォルダ名を変更
							let href = document.getElementById(menuId).firstElementChild.getAttribute('href');
							let hrefArray = href.split('/');
							hrefArray.splice(-2, 1, folderReName);
							let hrefRe = hrefArray.join('/');
							document.getElementById(menuId).firstElementChild.setAttribute('href', hrefRe);

							alert('フォルダ名を変更しました。')

						} else {
							alert(data)
						}
					})

					.catch((reason) => {
						alert('失敗しましたよ～。')
					});
			}
		}
	});
});








//--------------------//
//     ロック設定     //
//------------------//

// document.querySelectorAll('.folder-del').forEach(elm => {
// 	elm.addEventListener('click', e => {

// 		const dialog = document.getElementById('fdDelModal');
// 		const btn = document.getElementById('btn');
// 		const only_elm = document.getElementById('only-del');
// 		const all_elm = document.getElementById('all-del');
// 		const cancel_elm = document.getElementById('cancel-del');
// 		const name_elm = document.getElementById('folder-name');
// 		menuId = e.target.parentNode.getAttribute('id');
// 		dialog.dataset.id = menuId;//ダイアログに削除フォルダのidをデータ属性に設定

// 		let listName = e.target.parentNode.children[0].textContent;//メニュー名
// 		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
// 		folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide

// 		name_elm.innerHTML = listName + '【' + folderName + '】';

// 		menu_create();//メニュー配列

// 	});
// });


//--------------------//
//    バックアップ    //
//------------------//

// document.getElementById('btn-backup').addEventListener('click', () => {
// 	//pagesフォルダのバックアップ
// 	if (window.confirm('バックアップを取りますか?')) {
// 		const backup_elm = document.getElementById('backup-alert');

// 		fetch('../public/backup', {
// 			method: 'post'
// 		}, { cache: "no-store" })
// 			.then((response) => {
// 				if (!response.ok) {
// 					throw new Error();
// 				}
// 				return response;
// 			})
// 			.then(response => response.text())
// 			.then(data => {
// 				alert('pages_backupフォルダにバックアップを取りました。')
// 			})
// 			.catch(() => {
// 				//エラー
// 				console.log('エラー')
// 			})
// 	}
// })


//--------------------//
//    フォルダ削除    //
//------------------//

folder_del();

function folder_del(){
	document.querySelectorAll('.folder-del').forEach(elm => {
		elm.addEventListener('click', e => {
	
			dialog = document.getElementById('fdDelModal');
			only_elm = document.getElementById('only-del');
			all_elm = document.getElementById('all-del');
			// const cancel_elm = document.getElementById('cancel-del');
			name_elm = document.getElementById('folder-name');
			menuId = e.target.parentNode.getAttribute('id');
			dialog.dataset.id = menuId;//ダイアログに削除フォルダのidをデータ属性に設定
	
			//削除リスト数
			const list_elm = e.target.parentNode.querySelectorAll('li');
			delListNum = list_elm.length+1;
	
			let listName = e.target.parentNode.children[0].textContent;//メニュー名
			let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
			folderName = listDir.split('/').slice(-2)[0];//フォルダ名　例)guide
	
			name_elm.innerHTML = listName + '【' + folderName + '】';
	
			menu_create();//メニュー配列
			only_delete();//対象フォルダのみ削除
			all_delete();//配下のフォルダも削除
	
		});
	});
}



//-------------------------//
// ダイアログ（フォルダ削除）//
//------------------------//

//対象フォルダのみ削除
function only_delete(){
	only_elm.addEventListener('click', function () {
		const event_name = '対象フォルダのみ削除';
		let fd = new FormData();
		fd.append('eventName', event_name);
		fd.append('folderName', folderName);

		fetch('../public/folderDelOnly', {
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {
				//DBのlockリストデータ削除
				lockdata_delete(folderName);

				//配下にリストがあるか判定
				if(delListNum==1){
					//フォルダカウント数変更
					let fdcount = Number(document.querySelector('#folder-count dd').textContent);//削除前のフォルダ数
					fdcount = fdcount - 1;
					document.querySelector('#folder-count dd').innerHTML = fdcount;//削除後のフォルダ数に差し替え
					let fdId = document.getElementById('fdDelModal').dataset.id;
					let fdId_elm = document.getElementById(fdId);

					// 前後にリストがあるか判定
					if(fdId_elm.previousElementSibling || fdId_elm.nextElementSibling){
						//前後にリストあり
						fdId_elm.remove();//メニューから削除したフォルダのリストを削除
						alert('削除しました。');
					}else{
						//前後にリストなし
						fdId_elm.parentNode.remove();//メニューから削除したフォルダのリストの親のulごと削除
						alert('削除しました。');
					}

				}else{
					alert('削除しました。');
					// location.reload();//リロード
				}
			})
			.catch(() => {
				console.log('エラー')
			})
	});
}


//配下のフォルダも削除
function all_delete(){
	all_elm.addEventListener('click', function () {

		const event_name = '配下のフォルダも削除';
	
		let fd = new FormData();
		fd.append('eventName', event_name);
		fd.append('folderName', folderName);
	
		fetch('../public/del_allfolder', {
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {
				let fdId = document.getElementById('fdDelModal').dataset.id;
				let fdId_elm = document.getElementById(fdId);
	
				//前後にリストがあるか判定
				if(fdId_elm.previousElementSibling || fdId_elm.nextElementSibling){
					// 他リスト有り
					fdId_elm.remove();//メニューから削除したフォルダのリストを削除
				}else{
					//他リストなし
					fdId_elm.parentNode.remove();//メニューから削除したフォルダのリストの親のulごと削除
				}
	
				//DBのlockリストデータ削除
				lockdata_delete(folderName);
				//フォルダカウント数変更
				let fdcount = Number(document.querySelector('#folder-count dd').textContent);//削除前のフォルダ数
				fdcount = fdcount - delListNum;
				document.querySelector('#folder-count dd').innerHTML = fdcount;//削除後のフォルダ数に差し替え
				alert('削除しました。');
			})
			.catch(() => {
				console.log('エラー')
			})
	});
}



//lockデータ削除 
function lockdata_delete(folderName) {

	//データベースのlocklistテーブルに登録があれば削除する
	const formData = new FormData;
	formData.append('post_delFolder', folderName);
	formData.append('eventName', event_name);

	fetch('../public/lockdata_del', {
		method: 'POST',
		body: formData,
	}, { cache: "no-store" })
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response.text();
		})
		.then(data => {
			//通信成功時の処理
			// alert(data);
			//alert('DBの閲覧不可の登録を削除しました');
		})
		.catch((reason) => {
			alert('DBデータ削除に失敗しました～。')
		});
}



//--------------------//
//  フォルダ数表示    //
//------------------//

// document.getElementById('btn-numFolder').addEventListener('click', e => {
// 	// console.log('フォルダ数表示')

// 	fetch('../public/folder_cnt', {
// 		method: 'post',
// 		// body: fd,
// 	}, { cache: "no-store" })
// 		.then((response) => {
// 			if (!response.ok) {
// 				throw new Error();
// 			}
// 			return response;
// 		})
// 		.then(response => response.text())
// 		.then(data => {
// 			// console.log(data);
// 			document.querySelector('#folder-count dd').innerHTML=data;
// 		})
// 		.catch(() => {
// 			console.log('エラー')
// 		})
// })



//------------------------//
//  pages_copyのフォルダを//テスト
//  pagesにもどす        //
//----------------------//

// document.getElementById('btn-pagescopy_rest').addEventListener('click', e => {

// 	menu_create();

// 	let fd = new FormData();
// 	fd.append('list', menuStr);//メニューを格納

// 	fetch('../public/pagescopy_rest', {
// 		method: 'post',
// 		body: fd,
// 	}, { cache: "no-store" })
// 		.then((response) => {
// 			if (!response.ok) {
// 				throw new Error();
// 			}
// 			return response;
// 		})
// 		.then(response => response.text())
// 		.then(data => {
// 			// console.log(data);
// 		})
// 		.catch(() => {
// 			console.log('エラー')
// 		})
// })


//------------------------//
//   差分で並び替え確定    //
//----------------------//

document.querySelector('#btn-execution-sabun').addEventListener('click', e => {
	if (window.confirm('並べ替えの確定をしていいですか？')) {
		event_name = '並べ替え確定';
		elm_msgbox.insertAdjacentHTML("afterbegin", '<p class="sort-text text-primary">並べ替え確定中です。他の操作はしないでください。</p>');
		menu_create();//メニューから配列を作成

		let fd = new FormData();
		fd.append('list', menuStr);//メニューを格納

		fetch('../public/execution_sabun', {
			method: 'post',
			body: fd,
		}, { cache: "no-store" })
			.then((response) => {
				if (!response.ok) {
					throw new Error();
				}
				return response;
			})
			.then(response => response.text())
			.then(data => {
				console.log(data);

				if(data==''){
					alert('並び替えを確定しました。')
				}else{
					alert('並び替え中にエラーが発生しました。pages_copy内にファルダが残ってないか確認してください。エラーの原因として、VSCODEなどのLiveSeverなどでファイルにアクセスしてることも考えられるので、VSCODEを一旦閉じて再度並べ替えを実行してください。')
					document.getElementById('warning').innerHTML = data;
				}

				document.getElementById('sort-msgbox').innerHTML = '';

			})
			.catch(() => {
				console.log('エラー')
				alert('並べ替え処理でエラーになりました。')
				document.getElementById('sort-msgbox').innerHTML = '';
			})
		}
});

