$(function () {
	console.log('しおり設定');

	let scrollPos = $(window).scrollTop(); //トップからの位置

	

});
