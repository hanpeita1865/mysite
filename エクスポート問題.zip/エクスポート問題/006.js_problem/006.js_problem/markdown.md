*[page-title]:問題（JS）

<span class="bold green fz-12">問題１</span>　クラスについてです。空欄に当てはまるコードを記入してください。
![](upload/myName2.png)

<div markdown="1" class="problem">
<div markdown="1">
<label for="1-1">①</label>
<input id="1-1" type="text" name="1-1" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="1-2" for="1-2">②</label>
<input id="1-2" type="text" name="1-2" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="1-3" for="1-3">③</label>
<input id="1-3" type="text" name="1-3" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="1-4" for="1-4">④</label>
<input id="1-4" type="text" name="1-4" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="1-5" for="1-5">⑤</label>
<input id="1-5" type="text" name="1-5" value="" autocomplete="off"></input>
</div>
</div>

<details><summary>解答</summary>
	① class　② construct(name, age)　③ set myName(value)　④ get myName()　⑤ new User
</details>


<span class="bold green fz-12">問題2</span>　クラス継承についてです。①と②は問題1と同じになります。③には、UserクラスからManクラスに継承されるコードを記入してください。
![](upload/extendsMan2.png)
<div markdown="1" class="problem">
<div markdown="1">
<label for="2-1">①</label>
<input id="2-1" type="text" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="2-2">②</label>
<input id="2-2" type="text"  value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="2-3">③</label>
<input id="2-3" type="text" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="2-4">④</label>
<input id="2-4" type="text" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="2-5">⑤</label>
<input id="2-5" type="text" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="2-6">⑥</label>
<input id="2-6" type="text" value="" autocomplete="off"></input>
</div>
</div>

<details><summary>解答</summary>
	① class　② construct(name, age)　③ class　④  extends User　⑤ new Man　⑥ taro.speak()
</details>


<span class="bold green fz-12">問題3</span>　当てはまる正規表現を記入してください。

<div markdown="1" class="problem-column">
<div markdown="1">
<label for="3-1">① x、y、zのいずれかの文字を含む</label>
<input id="3-1" type="text" name="3-1" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="3-2">② p～wまでのいずれかの文字を含む。</label>
<input id="3-2" type="text" name="3-2" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="3-3">③ 「2025年」か「令和7年」かどうか</label>
<input id="3-3" type="text" name="3-3" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="3-4" for="3-3">④ 文字が郵便番号（「-」を含む）かどうか　例）731-5101</label>
<input id="3-4" type="text" name="3-4" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="3-5">⑤ すべての文字が数字の場合はfalseになり、1文字でも数字以外が入るとtrueになる。</label>
<input id="3-5" type="text" name="3-5" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="3-6">⑥ すべての文字がアルファベット（小文字、大文字）の場合はfalseになり、1文字でもアルファベット以外が入るとtrueになる。</label>
<input id="3-6" type="text" name="3-6" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="3-7">⑦ 「user-」から始まり数字がその後に付く　例）〇user-21　×user-ab　duser-21</label>
<input id="3-7" type="text" name="3-7" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="3-8">⑧ 「smart」のあとに「phone」が続かない場合のみマッチします。　例）×smartphone　〇smartwatch</label>
<input id="3-8" type="text" name="3-8" value="" autocomplete="off"></input>
</div>
</div>

<details><summary>解答</summary>
	① [xyz]　② [p-w]　③ (2025|令和7)年	　④ ^[0-9]{3}-[0-9]{4}$　⑤ [^0-9]+　⑥ [^a-zA-Z]+　⑦ ^user-\d　⑧ smart(?!phone)
</details>



<span class="bold green fz-12">問題4</span>　左のコードを実行すると、実行結果が1番目→3番目→2番目となります。1番目→2番目→3番目と実行されるよう右側の空欄に当てはまるコードを記入してください。
<div markdown="1" class="d-flex">
![](upload/Promise問題修正前.png)
![](upload/Promise問題記入欄.png){.ml-5}
</div>

<div markdown="1" class="problem">
<div markdown="1">
<label for="4-1">①</label>
<input id="4-1" type="text" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label  for="4-2">②</label>
<input id="4-2" type="text" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label id="4-3">③</label>
<input id="4-3" type="text" value="" autocomplete="off"></input>
</div>
</div>

<details><summary>解答</summary>
	① new Promise((resolve)　② resolve();　③ ).then(()
</details>


<span class="bold green fz-12">問題5</span>　下記のコードが正常に動作するよう空欄に当てはまるコードを記入してください。
![](upload/async_await問題.png)

<div markdown="1" class="problem">
<div markdown="1">
<label for="5-1">①</label>
<input id="5-1" type="text" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="5-2">②</label>
<input id="5-2" type="text"  value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="5-3">③</label>
<input id="5-3" type="text" value="" autocomplete="off"></input>
</div>
<div markdown="1">
<label for="5-4">④</label>
<input id="5-4" type="text" value="" autocomplete="off"></input>
</div>
</div>

<details><summary>解答</summary>
	① new Promise　② resolve　③ async	　④ await
</details>