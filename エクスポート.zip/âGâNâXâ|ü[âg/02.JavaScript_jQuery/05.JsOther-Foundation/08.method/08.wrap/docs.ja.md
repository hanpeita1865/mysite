---
title: 要素で囲む/削除する(wrap/wrapAll/unwrap/wrapInner)
taxonomy:
    category:
        - docs
---

## 個別に要素で囲む/削除する(wrap/unwrap)

「**wrap()**」は、指定したHTML要素で対象の要素を囲むことができるメソッドになります。  
これは言い換えると、対象となる要素の「親要素」を作ることができると考えることもできるでしょう。

<p class="tmp"><span>書式1</span></p>
```
$('対象要素').wrap( HTML要素 )
```

逆に削除したい場合は、「**unwrap()**」を使います。  
対象の外側にある要素…つまり「親要素」を削除することができます。

<p class="tmp"><span>書式2</span></p>
```
$('対象要素').unwrap();
```

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
個別に要素(タグ)で囲む/削除するサンプルです。wrapメソッドとunwrapメソッドを使用します。
[sample(wrap)1](../../../../sample/jquery/sample(wrap)1/index.html?target=_blank)
</div>
<iframe width="100%" height="300" src="//jsfiddle.net/0b4m8gup/2/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>



## まとめて要素で囲む/削除する(wrapAll/unwrap)

「wrapAll()」は、対象の要素が複数ある場合にまとめて親要素で囲むことが出来る便利なメソッドになります。

記述方法は【 対象要素.wrapAll( 囲みたい要素 ) 】のように、これまで同様で引数へ囲みたい要素を指定すればOKです。

#### HTML
```
<p>サンプルテキスト１</p>
<p>サンプルテキスト２</p>
<p>サンプルテキスト３</p>

<script>
$('p').wrapAll('<div>');
</script>
```
#### 実行後のHTML
```
<div>
	<p>サンプルテキスト１</p>
	<p>サンプルテキスト２</p>
	<p>サンプルテキスト３</p>
</div>
```

<div class="box-example" markdown="1">
### 例2 ### {.h-example}
まとめて要素(タグ)で囲む/削除するサンプルです。wrapAllメソッドとunwrapメソッドを使用しています。
[sample(wrap)2](../../../../sample/jquery/sample(wrap)2/index.html?target=_blank)
</div>
<iframe width="100%" height="300" src="//jsfiddle.net/a2rvb0ke/1/embedded/result,html,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>



## 「wrapInner()」で特定の子要素を囲む方法

「wrapInner()」は少し特殊なのですが、対象の子要素をすべてまとめて任意の要素で囲むことができるメソッドになります。

#### HTML
```
<div>
	<p>サンプルテキスト１</p>
	<p>サンプルテキスト２</p>
	<p>サンプルテキスト３</p>
</div>

<script>
$('div').wrapInner('<div id="main">');
</script>
```

#### 実行後のHTML
```
<div>
	<div id="main">
		<p>サンプルテキスト１</p>
		<p>サンプルテキスト２</p>
		<p>サンプルテキスト３</p>
	</div>
</div>
```

今度は、p要素の中のテキストをspan要素で囲みます。

#### HTML
```
<p>サンプルテキスト</p>
 
<script>
$('p').wrapInner('<span class="text">');
</script>
```
#### 実行後のHTML
```
<p><span class="text">サンプルテキスト</span></p>
```


## 参考サイト

* [jQuery 要素で囲む/削除する(wrap/wrapAll/unwrap/wrapInner)](https://itsakura.com/jquery-wrap-unwrap)
* [【jQuery入門】wrap() / wrapAll() / wrapInner()で要素を囲む方法！](https://www.sejuku.net/blog/37949)

