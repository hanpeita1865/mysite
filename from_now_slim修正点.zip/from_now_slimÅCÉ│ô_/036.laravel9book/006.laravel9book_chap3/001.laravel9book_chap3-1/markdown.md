*[page-title]:Chpa3-1 サービスコンテナを理解する（example-app9）


<span class="bold green">Chap3-1 完成品</span>
* \\wsl.localhost\Ubuntu-24.04\root\example-app9
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>　データベース名は「example_app5」にしてます。

## サービスコンテナとは

サービスコンテナはLaravelの中でも重要な仕組みのひとつで、大きく2つの役割があります。

1. クラスの依存関係の管理
2. 依存性の注入


### 依存と依存性の注入

#### 依存性の注入とは?

略して「<span class="green bold">DI</span>」とも言われます。  
ひとことで表現すると、「<span class="red">クラス内で使うインスタンスをクラス外から受け取る（注入する）こと</span>」です。
![](upload/依存性の注入.png)

##  Laravelのサービスコンテナ

まず、appディレクトリの下にServicesディレクトリを作成し、その中にTweetService.phpを作成します。

<p class="tmp list"><span>リスト</span>app/Services/TweetService.php（新規作成）</p>
```
<?php

namespace App\Services;

use App\Models\Tweet;

class TweetService
{
    public function getTweets()
    {
        return Tweet::orderBy('created_at', 'DESC')->get();//追加
    }
}
```


作成したTweettServiceクラスをつぶやき一覧表示のシングルアクションコントローラで利用してみます。

<span class="bold">変更前</span>
<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/IndexController.php</p>
```
class IndexController extends Controller
{
    public function __invoke(Request $request)
    {
        $tweets = Tweet::orderBy('created_at', 'DESC')->get(); 
        return view('tweet.index')
            ->with('tweets', $tweets);
    }
}
```

作成したTweetServiceクラスをつぶやき一覧表表示のシングルアクションコントローラで利用してみます。

<span class="bold">変更後</span>

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/IndexController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use App\Services\TweetService;//TweettServiceのインポート
use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function __invoke(Request $request)
    {
        $tweetService = new TweetService();//TweettSServiceのインスタンスを作成
        $tweets = $tweetService->getTweets();//つぶやきの一覧を取得
        return view('tweet.index')
            ->with('tweets', $tweets);
    }
}
```

つぶやき一覧表示のシングルアクションコントローラでTweetService クラスを利用するために、 「use App\Services\TweetService;」を冒頭につける のを忘れないようにしましょう。  
ブラウザで<http://localhost/tweet>を閲覧してみると、表示は何も変わっていないことが確認できます。


このように新たに TweetServiceクラスを作成して利用することにより、「つぶやき一覧表示のシングルアクションコントローラがTweetServiceクラスに 依存している状態」 になりました。


### TweetServiceクラスを外部から受け取る

<p class="tmp list"><span>リスト</span>routes/web.php（すでに記述済み）</p>
```
Route::get('/tweet', \App\Http\Controllers\Tweet\IndexController::class)-> name('tweet.index');
```

つぶやき一覧のシングルアクションコントローラを書き換えてみましょう。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/IndexController.php</p>
```
public function __invoke(Request $request, TweetService $tweetService)
{
    $tweets = $tweetService->getTweets();
    return view('tweet.index')
        ->with('tweets', $tweets);
}
```

つぶやき一覧のシングルアクションコントローラの__invoke メソッドで「<span class="red">$tweetService</span>」 を受け取るように書き換えました。  
「<span class="red">$tweetService = new TweetService(); </span>」 は削除しています。  
これだけだとエラーが発生しそうに見えるかもしれませんが、 再度<http:// localhost/tweet>を表示してみると、エラーは発生せずに表示も変わっていないことがわかります。  
つぶやき一覧のシングルアクションコントローラがTweetServiceクラスのオブジェクトを受け取った、つまり「<span class="green bold">依存性の注入</span>」 がされたことになります。


#### サービスコンテナの機能

ここでは、「依存性の注入」 が行われました。 特に何も設定 を行わないと、Laravelのサービスコンテナはコンストラクタやメソッドの引数で設定された型宣言を自動的に判断し、それに対応するクラスをインスタンス化し、自動でそのインスタンスを注入してくれます。

ここでは、つぶやき一覧のシングルアクションコントローラに「use App\ Services\TweetService;」でTweetService クラスを明示的に設定していたため、__invoke メソッドの引数に設定された TweetService $tweet ServiceからLaravelのサービスコンテナがクラスを自動的に判別、 Tweet Serviceクラスのインスタンスを生成して、 $tweetService に注入したという動きです。

![](upload/サービスコンテナの動き.png)

このようにコンストラクタやメソッドの引数に型宣言を記述することで、それに対応するクラスなどを判別し、インスタンス化したオブジェクトを設定する仕組みは「<span class="green bold">DIコンテナ</span>」とも呼ばれます。LaravelのサービスコンテナはDIコンテナの役割も持っていると言えます。

DIとDIコンテナは一緒に語られることも多いため混同しがちですが、DIは 前述したとおり「依存するクラスをクラスの内部でインスタンス化するのではなく、外部でインスタンス化したオブジェクトを受け取るようにすること」それ自体を指します。「<span class="green bold">DIコンテナ</span>」はそれを自動的に解決する仕組みと分けて捉えておきましょう。

#### サービスコンテナのメリット

Laravelのサービスコンテナが「依存性の注入」を強力にサポートしてくれることを利用し、 TweetServiceのように処理を別のクラスに切り出していくアプローチは、各クラスにおいて直接クラスに依存しない状態にすることができます。   
これはテストの観点からもよいアプローチなので、積極的に取り入れましょう。また、 <span class="blue bold"> 「CHAPTER4-04 画像のアップロード機能を追加する」</span>ではつぶやき投稿、つぶやきの削除の処理を TweetServiceに移動していきますので、実装の際はあわせて確認してみましょう。


#### クラスの依存関係の管理

実は元々のつぶやきアプリを作成する中ですでにLaravelのサービスコンテナを利用しています。 つぶやきを投稿する機能を作成する際に、 CreateRequestを作成し、CreateControllerの__invokeメソッドの引数に指定していました。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/CreateController.php（すでに記述済み）</p>
```
public function __invoke(CreateRequest $request)
{
    $tweet = new Tweet;
    $tweet->content = $request->tweet();
    $tweet->save();
    return redirect()->route('tweet.index');
}
```

すでにここでもLaravelのサービスコンテナによる 「依存性の注入」が 行われていたことがわかります。 また、このCreateRequestクラスは Illuminate\Foundation\Http\Form Requestを継承したクラスです。  
TweetService では Tweetモデルに依存しているだけでしたが、 Illuminate/Foundation/Http/FormRequestではより多くのクラスに依存していることがクラス冒頭のuseの箇所を見てもわかります。

<p class="tmp list"><span>リスト</span>vendor/laravel/framework/src/Illuminate/Foundation/Http/FormRequest.php</p>
```
namespace Illuminate\Foundation\Http;

use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\Access\Response;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Validation\Factory as ValidationFactory;
use Illuminate\Contracts\Validation\ValidatesWhenResolved;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Illuminate\Validation\ValidatesWhenResolvedTrait;
use Illuminate\Validation\ValidationException;

･･･省略･･･
```

それぞれのクラスは「依存性の注入」により、インスタンス化されたオブジェ クトがそれぞれ注入されます。 また Requestごとにどのようなパラメータが 渡ってくるかなどは異なるでしょうが、それらRequestごとの違いを判断して、どのようにインスタンスを生成するかなども細かく設定されており、リクエストごとに適切な$requestのオブジェクトが生成されて注入されてきます。  
このように、各状況に応じたインスタンスの生成を行い、「依存性の注入」を行うという部分が、Laravelのサービスコンテナのもう一つの役割である「クラスの依存関係の管理」です。

<span class="blue bold">「CHAPTER5-03 Laravelで構築したアプリケーションをデプロイする」</span>では、本番環境とその他の環境で生成するインスタンスを変更する実装を行いますので、あわせて確認してみましょう。  
Laravelのサービスコンテナはほかにも様々な機能がありますので、ぜひここで学んだことをベースに、公式ドキュメントなどでさらに理解を深めていきましょう。
