*[page-title]:指定した配列の要素にコールバック関数を適用 array_map

参考サイト
: [PHP マニュアル array_map](https://www.php.net/manual/ja/function.array-map.php)

<p class="tmp"><span>書式</span></p>
```
array_map(callback, $array,  arrays)
```
callback: 配列の各要素に適用する callable。複数の配列に zip 操作を行うために、 callback に null を渡すことができます。 array のみが与えられた場合、 array_map() は、入力された配列を返します。  

array: コールバック関数を適用する配列。

arrays: callback に渡す引数を指定する配列の可変リスト。

<div class="exp">
	<p class="tmp"><span>例1</span>array_map() の例</p>
	<iframe src="https://paiza.io/projects/e/8vuOIhcdc9pI7U6eOcuY1w?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例2</span></p>
	<iframe src="https://paiza.io/projects/e/urfyXJT0QKQZC61iHDJ0iA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>