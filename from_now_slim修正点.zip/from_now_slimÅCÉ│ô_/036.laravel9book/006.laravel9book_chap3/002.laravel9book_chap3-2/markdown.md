*[page-title]:Chap3-2 アプリケーションにログイン機能を追加する（example-app10）

ログイン機能はWebアプリケーションを構築する上でなくてはならない機能です。

<span class="bold green">Chap3-2 完成品</span>
* \\wsl.localhost\Ubuntu-24.04\root\example-app10
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>　データベース名は「example_app5」にしてます。

## ログイン機能の実装

ログイン機能を作ることによって次のようなことができるようになります。

<div markdown="1" class="bold green">
1. つぶやきを保存するときに誰がつぶやいたかを一緒に保存する。
2. 自分のつぶやきだけを編集・削除できるようにする。
</div>

ここでは、Laravelと連携してログイン機能を提供するパッケージ「Laravel Breeze」を使ってログイン機能を実装します。


## Laravel Breezeを利用する

「Laravel Breeze」はLaravel を使ったユーザー登録、ログイン、パスワードの再設定等の認証に関わる基本的な機能を手軽に提供してくれるパッケージです。

<span class="red">※インストールすると、web.phpの内容が消去されるので、コピーしておきましょう。★重要</span>

<p class="tmp cmd"><span>コマンド</span>Breezeインストール</p>
```
sail composer require laravel/breeze --dev
```
![](upload/Breezeインストール.png)

インストールしたら、次のartisanコマンドを実行して、Laravel Breezeの動作に必要なコード群を生成します。

<p class="tmp cmd"><span>コマンド</span>Laravel Breezeの動作に必要なコード群を生成</p>
```
sail artisan breeze:install
```
![](upload/Laravel_Breezeの動作に必要なコード群を生成.png)

新しく生成されたweb.phpのコードは、次のようになりました。

<p class="tmp list"><span>リスト</span>routes/web.php（デフォルト）</p>
```
<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
```
<span class="red">※事前に保存してたweb.phpのコードは下記です。</span>


<p class="tmp list"><span>リスト</span>web.phpバックアップコード</p>
```
Route::get('/sample', [\App\Http\Controllers\Sample\IndexController::class,'show']);
Route::get('/sample/{id}', [\App\Http\Controllers\Sample\IndexController::class,'showId']);
Route::get('/tweet', \App\Http\Controllers\Tweet\IndexController::class) ->name('tweet.index');
Route::post('/tweet/create', \App\Http\Controllers\Tweet\CreateController::class) ->name('tweet.create');
Route::get('/tweet/update/{tweetId}', \App\Http\Controllers\Tweet\Update\IndexController::class)->name('tweet.update.index')->where('tweetId', '[0-9]+');
Route::put('/tweet/update/{tweetId}', \App\Http\Controllers\Tweet\Update\PutController::class)->name('tweet.update.put')->where('tweetId', '[0-9]+');
Route::delete('/tweet/delete/{tweetId}', \App\Http\Controllers\Tweet\DeleteController::class)->name('tweet.delete');
```

Laravel BreezeではLaravelによるサーバーサイドのロジックだけではなく、ログインに必要なフォーム等のフロントエンドの部分の機能も提供されます。  
すでに、先ほどのコマンドによってフロントエンドのコードが書き換わっているので、このフロントエンドのコードを反映させるために次のコマンドを実行します。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail npm install
sail npm run dev
```
![](upload/po-to5173.png)

<http://localhost/>にアクセスして、右上に「Login」「Register」が表示されていればOKです。
![](upload/「Login」「Register」が表示されていればOKです.png)

Laravel Breezeをインストールすると、フロントエンドのリッチなUIのためにCSSやJavaScriptが追加されます。これらをビルドすると巨大なCSSファイルとJavaScriptファイルが生成されますので、gitでコードを管理している場合は.gitignoreファイルに次のコードを追記することをおすすめします。

<p class="tmp list"><span>リスト</span>.gitignoreファイルへ追記</p>
```
/public/css
/public/js
```

※gitの箇所は、今のとこはスルーしてよい。

#### ユーザー登録

トップページの右上のRegisterをクリックすると、スタイルの読み込みエラーにになります。

ログイン画面ではスタイルが効いていない。
![](upload/ユーザ登録cssエラー.png)

対応方法
: [【Laravel】authのlogin画面にCSSが効かない問題の解決法！](https://tech.amefure.com/php-laravel-auth-css)

「resources」＞「views」＞「layouts」のapp.blade.phpにbootstrap.css読み込み追加
```
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
```
![](upload/app.blade.phpにbootstrap.css読み込み追加.png)

configファイルにhostからアクセスできるよう設定する
```
server: {
  host: true
}
```

<p class="tmp list"><span>リスト</span>vite.config.js</p>
```
import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
	//追加
    server: {
        hmr: {
            host: 'localhost',
        },
    },
    plugins: [
        laravel({
            input: [
                'resources/css/app.css',
                'resources/js/app.js',
            ],
            refresh: true,
        }),
    ],
});
```


再度、<http://localhost/register>にアクセスするとスタイル崩れなく表示されました。
![](upload/localhost_register.png)

パスワードを設定して、ログインすると、次の画面が表示されます。
![](upload/yourelogin.png){.photo-border}

Password 「ryouma0719」

## ログインについて理解する

Laravel Breezeによって、ログインに関連する機能に必要なコードは一通り揃っているので、新たに書く必要はないですが、中身を理解していないと機能を追加する場面などで応用できません。

ログインについて理解するには「ルーティング」、「ミドルウェア」、「ガード」、「例外」の4つを押さえておきましょう。
これらが理解できると、「ログイン時に閲覧可未ログイン時には閲覧不可のページがどのように実装されているのか」「ログインせずにそのようなページにアクセスした場合にどうやってログインページにリダイレクトされるのか」、といったことがわかるようになります。それでは順に見ていきましょう。

### ルーティング
ログイン関係のコードはどのようにルーティングされてControllerが選ばれているのかをまずは見ていきましょう。routes/web.phpを見るとroutes/auth.phpというファイルを読み込んでいる箇所が見つかります。ログイン関係のコードはこのroutes/auth.php内に書かれており、ここには登録、ログイン、パスワードの変更、メールアドレスの認証、ログアウトまでが書かれています。  

<p class="tmp list"><span>リスト</span>routes/auth.php</p>
```
・・・
Route::middleware('guest')->group(function () {
    Route::get('register', [RegisteredUserController::class, 'create'])
        ->name('register');

    Route::post('register', [RegisteredUserController::class, 'store']);

    Route::get('login', [AuthenticatedSessionController::class, 'create'])
        ->name('login');

    Route::post('login', [AuthenticatedSessionController::class, 'store']);

    Route::get('forgot-password', [PasswordResetLinkController::class, 'create'])
        ->name('password.request');

    Route::post('forgot-password', [PasswordResetLinkController::class, 'store'])
        ->name('password.email');

    Route::get('reset-password/{token}', [NewPasswordController::class, 'create'])
        ->name('password.reset');

    Route::post('reset-password', [NewPasswordController::class, 'store'])
        ->name('password.store');
});
・・・
```

例として登録フォームの表示を担う/registerの部分のルーティングを見てみましょう。

![](upload/auth_registerコード.png "routes/auth.php（register部分）"){.fig-top}

ここには「<span class="red">/registerにアクセスしたらRegisteredUserControllerクラス の createという関数を呼び出してください</span>」 という処理が記述されていますが、それと同時に 「<span class="red">guestというミドルウェアを通してください</span>」という処理も 一緒に記述してあります。 では、ミドルウェアについて見てみましょう。

## ミドルウェア
ミドルウェアは、Controllerで実行される所定の処理の前後に、追加的に処理を挟みこむときに使います。  
試しに新しいミドルウェアを追加してみましょう。以下のコマンドでミドルウェアを追加できます。

<p class="tmp cmd"><span>コマンド</span>ミドルウェア追加</p>
```
sail artisan make:middleware SampleMiddleware
```
![](upload/SampleMiddleware作成.png){.photo-border}

「app/Http/Middleware/SampleMiddleware.php」が生成され、中に次のようなコードが書かれているはずです。
![](upload/SampleMiddlewareファイル作成.png)

<p class="tmp list"><span>リスト</span>app/Http/Middleware/SampleMiddleware.php</p>
```
public function handle(Request $request, Closure $next): Response
{
    return $next($request);
}
```

### ミドルウェアの登録

ミドルウェアを使うためには、app/Http/Kernel.php ファイルに新しく作ったミドルウェアを登録する必要があります。ミドルウェアを登録する形式は2つあり、アプリケーション全体に作用させたい場合には<span class="green bold">グローバルミドルウェア</span>、特定のルートに対してだけ作用させたい場合には<span class="purple bold">ルートミドルウェア</span>として登録します。ルートミドルウェアを登録するときには、ミドルウェアを呼び出すためのエイリアスを登録します。


<p class="tmp list"><span>リスト</span>app/Http/Kernel.php</p>
```
class Kernel extends HttpKernel
{
        protected $middleware = [
            /** アプリケーション全体に作用させたいミドルウェアを登録するときはここに記述する **/
        ];

        protected $routeMiddleware = [
           /** 特定のルートについてのみ作用させたいミドルウェアを登録するときにはここに記述する **/
           'sample' => \App\Http\Middleware\SampleMiddleware::class // 例
        ]
}
```

今回のSampleMiddleware の例ではsampleがミドルウェアのエイリアスになります。このエイリアスをルーティングの際に指定することで、そのルートについてだけミドルウェアを作用させることができます。

### ミドルウェアの実装
ミドルウェアを実装する場合は、どこに書くかで実行されるタイミングが変わります。Controllerが実行したい所定の処理は$next($request)の部分で実行されるので、その前に処理を差し込むか後に差し込むかで、元々の処理の前後どちらにも処理を追加することができます

<p class="tmp list"><span>リスト</span>app\Http\Middleware\SampleMiddleware.php</p>
```
public function handle(Request $request, Closure $next, ...$guards)
{
    /** 前に処理をはさみたい場合ここに記述する **/
    return $next($request);
    /** 後に処理をはさみたい場合ここに記述する **/
}
```

前に処理を挟むミドルウェアは 次のようなシーンで使われます。

<span class="bold">●前に処理を挟むミドルウェアを使用するケースの例</span>
<div markdown="1" class="green-box">
* メンテナンスモードのときはすべてのアクセスをリダイレクトする
* ログインしているユーザーのみにアクセスを制限する
* 特定のIPアドレスからのみアクセスできるようにアクセスを制限する
* ユーザーからのリクエストされたデータに一律で変換を追加する
</div>


後に処理を挟むミドルウェアは 次のようなシーンで使います。

<span class="bold">●後に処理を挟むミドルウェアを使用するケースの例</span>
<div markdown="1" class="green-box">
* すべてのHTTPレスポンスに必ず特定のレスポンスヘッダーをつけるよ うにする
* すべてのHTTPレスポンスに付随するCookieを暗号化する
</div>

また、両方に処理を挟むミドルウェアというものもときには必要になるかもしれません次のようなものが思いつきます。

<span class="bold">●前後両方に処理を挟むミドルウェアを使用するケースの例</span>
<div markdown="1" class="green-box">
* 処理の実行時間を計測してログとして出力する
</div>

## ログインし処理で使われているミドルウェア

#### <span class="marker-yellow50">guest</span>

「guestはapp/Kernal.php」ファイルを見ると 「<span class="red">\App\Http\Middleware\ RedirectlfAuthenticated:class</span>」 のエイリアスになっていることがわかります。処理を見てみると「ガード」を使ってログイン状況を確認し、ログインしていた場合はHOMEに飛ばすという処理になっています。「ガード」については後ほど説明します。  
このミドルウェアをルートに指定することによって、指定されたルートではログインしている場合に問答無用でHOMEに飛ばされることになります。  
この処理はまだ登録していないユーザーのためのページに使います。例えば、すでに登録していてログインしている人は再度登録する必要がないので、このミドルウェアを登録しておくと、登録画面は表示されずホーム画面に飛ばされるということです。

<span class="bold red">「ガード」を使ってログイン状況を確認 → ログインしていた場合はHOMEに飛ばす（登録画面は表示されない）</span>

#### <span class="marker-yellow50">auth</span>

「authはKernel.php」ファイルを見ると「<span class="red">\App\Http\Middleware\Authenticate::class</span>」が指定されています。このクラスのHandle関数を見ると、ログインしているかどうか確認し、ログインしていない場合はAuthentication Exception の例外を発生させるように記述されています。これにより、ログインしていないときはログイン画面に飛ばされるようになります。AuthenticationExceptionをThrowするとログイン画面に飛ばされる部分は後ほど説明します。  ログインしているユーザーしかアクセスできないページにはこのミドルウェアを登録します。  
まとめると、guestとauthは対になるミドルウェアになっています。

![](upload/guestとauthの処理の流れ.png "図　guestとauthの処理の流れ")

![](upload/Kernal.phpコード.png "図　Kernal.php")
![](upload/Auuthernticate.phpコード.png "図　Auuthernticate.php（デフォルト）")
![](upload/RedirectAuthenticated.phpコード.png "図　RedirectAuthenticated.php（デフォルト）")




#### ガード 

<span class="red">ガードはユーザーがログインしているかどうかを制御する機能を提供しています。</span>複雑なアプリケーションを作らない限りはあまり触ることがない機能ですが、ログイン関係の機能を触るときには時々目にするので、軽く見ておきましょう。
ガードの設定はconfig/auth.phpに書かれており、ログイン状態の管理の仕方を複数種類設定することができます。たとえばユーザーだけではなく管理者用のページを作ることを考えていて、メインのユーザーと管理画面のユーザーではデータの取得情報もログイン情報の管理も分けたいといった場合、このガードを追加することで実現できます。

<p class="tmp list"><span>リスト</span>config/auth.php</p>
```
'guards' => [
    'web' => [
        'driver' => 'session',
        'provider' => 'users',
    ],

    'api' => [
        'driver' => 'token',
        'provider' => 'users',
        'hash' => false,
    ],
],

'providers' => [
    'users' => [
        'driver' => 'eloquent',
        'model' => App\Models\User::class,
    ],
],
```

※'api' =>[]を追加しました。

<p class="tmp list"><span>リスト</span>config/auth.php</p>
```
'defaults' => [
    'guard' => 'web',
    'passwords' => 'users',
],
```

webが指定されているので、このアプリケーションでログインを実装すると、特に指定しない場合は、webの設定が使われることになります。


ここでdriverの部分はログイン状態をどう管理するかを指定していて、providerの部分はログイン情報と合致したユーザー情報をどうやって取得するかが書いてあります。  
また、providersの箇所でデータの取得方法を複数設定することが可能です。  
今回、webガードについて見てみると、providersの方にusersはdriverとしてeloquentを指定しているので、ログイン情報はEloquentのモデルを使って取得されるということがわかります。  
また、そもそも複数あるguardのうちどれが使われいてるのか、ということについてはdefaultsが指定されています。


#### <span class="marker-yellow50">例外</span>

前述したように、未ログイン時にログイン画面にリダイレクトされる処理はAuthenticationExceptionクラスを使って実装されています。詳しく見てみましょう。  
Laravelのアプリケーション内で発生するExceptionでCatchされていないものはすべてapp/Exceptions/Handler.phpでCatchされます。app/Exceptions/Handler.phpクラスの親クラスllluminate/Foundation/Exceptions/Handler.phpのrender関数には、Exceptionの種類ごとにどのような処理を記述するかが書いてあります。AuthenticationExceptionがThrowされた場合は、ログイン画面にリダイレクトするように書かれています

vendor/laravel/framework/src/Illuminate/Foundation/Exceptions/Handler.php
<p class="tmp list"><span>リスト</span>render関数（Illuminate\Foundation\Exceptions\Handler.php）</p>
```
/**
    * Render an exception into an HTTP response.
    *
    * @param  \Illuminate\Http\Request  $request
    * @param  \Throwable  $e
    * @return \Symfony\Component\HttpFoundation\Response
    *
    * @throws \Throwable
    */
		
public function render($request, Throwable $e)
{
    if (method_exists($e, 'render') && $response = $e->render($request)) {
        return Router::toResponse($request, $response);
    }

    if ($e instanceof Responsable) {
        return $e->toResponse($request);
    }

    $e = $this->prepareException($this->mapException($e));

    if ($response = $this->renderViaCallbacks($request, $e)) {
        return $response;
    }

    return match (true) {
        $e instanceof HttpResponseException => $e->getResponse(),
        $e instanceof AuthenticationException => $this->unauthenticated($request, $e), // ここがログインしていないときの例外処理
        $e instanceof ValidationException => $this->convertValidationExceptionToResponse($e, $request),
        default => $this->renderExceptionResponse($request, $e),
    };
}
```

「vendor/laravel/framework/src/Illuminate/Foundation/Exceptions/Handler.php」のメソッドをオーバーライドすることで、データがない場合には404ステータスの画面を返すなど、ログイン以外についても様々なカスタマイズができます。中規模以上の開発をするとききにはかなり重要なファイルになるでしょう

#### Laravelがサポートしている例外
Laravelのアプリケーション内で特定の例外を発生させると、先ほどの仕組みでLaravelは例外をキャッチし、自動でエラー画面を表示してくれます。  
Illuminate/Foundation/Exceptions/Handler.phpのprepareExceptionでは特定の例外を変換して、Laravelのデフォルトの例外処理用に変換しています

<p class="tmp list"><span>リスト</span>vendor/laravel/framework/src/Illuminate/Foundation/Exceptions/Handler.php</p>
```
/**
    * Prepare exception for rendering.
    *
    * @param  \Throwable  $e
    * @return \Throwable
    */
		
protected function prepareException(Throwable $e)
{
	return match (true) {
		$e instanceof BackedEnumCaseNotFoundException => new NotFoundHttpException($e->getMessage(), $e),
		$e instanceof ModelNotFoundException => new NotFoundHttpException($e->getMessage(), $e),
		$e instanceof AuthorizationException && $e->hasStatus() => new HttpException(
			$e->status(),
			$e->response()?->message() ?: (Response::$statusTexts[$e->status()] ?? 'Whoops, looks like something went wrong.'),
			$e
		),
		$e instanceof AuthorizationException && !$e->hasStatus() => new AccessDeniedHttpException($e->getMessage(), $e),
		$e instanceof TokenMismatchException => new HttpException(419, $e->getMessage(), $e),
		$e instanceof SuspiciousOperationException => new NotFoundHttpException('Bad hostname provided.', $e),
		$e instanceof RecordsNotFoundException => new NotFoundHttpException('Not found.', $e),
		default => $e,
	};
}
```

ここで該当するExceptionはすべてXXXHttpExceptionに変換されます。このクラスはLaravel内で使われているSymfonyというライブラリ内のクラスですが、それぞれHTTPレスポンスに対応した例外で、Exceptionクラスがステータスコードを持っています。たとえばNotFoundHttpExceptionは、404 not foundステータスと対応しています。  
また、このXXXHttpExceptionはprepareResponse関数内でLaravelのレスポンスに変換されエラー画面が表示されます

<p class="tmp list"><span>リスト</span>vendor/laravel/framework/src/Illuminate/Foundation/Exceptions/Handler.php</p>
```
/**
* Render an exception into /**
* Prepare a response for the given exception.
*
* @param  \Illuminate\Http\Request  $request
* @param      hrowable  $e
* @return \Symfony\Component\HttpFoundation\Response
*/

	protected function prepareResponse($request, Throwable $e)
	{
		// ここでLaravel用のエラーレスポンスに変換される
		if (!$this->isHttpException($e) && config('app.debug')) {
			return $this->toIlluminateResponse($this->convertExceptionToResponse($e), $e)->prepare($request);
		}

		if (!$this->isHttpException($e)) {
			$e = new HttpException(500, $e->getMessage(), $e);
		}

		return $this->toIlluminateResponse(
			$this->renderHttpException($e),
			$e
		)->prepare($request);
	}
```
つまり、<span class="marker-yellow50">Laravelアプリケーション内でXXXHttpExceptionを発生させると、Laravel側で適切なエラー画面に変換して表示される</span>ということです。これは便利ですね。


## ログイン機能をつぶやきアプリと連携する

ログイン機能が付いたことにより、つぶやきとともに投稿したユーザーの情報を保存することで、 さまざまな機能を実装することができます。 今回は次の3つを実装することで、ログインユーザーの取得から可能になる機能への活用を見ていきます。

1. ログインしているユーザーのみ書き込みができるようにする
2. ログインしているユーザーの情報をつぶやきとともに保存する
3. 自分がつぶやいたものだけを編集、削除できるようにする


#### 登録・ログイン後のページを変更する

デフォルトでは登録・ログイン後に「/dashboard」のパスに遷移するようになっているので、つぶやきアプリのトップページに遷移できるように変更します。

<p class="tmp list"><span>リスト</span>app/Providers/RouteServiceProvider.php</p>
```
public const HOME = '/tweet';
```

## ログインユーザーのみ書き込み可にする

つぶやきを書き込むルーティングにauthエイリアスのmiddlewareを指定します。

<p class="tmp list"><span>リスト</span>routes/web.php</p>
```
Route::post('/tweet/create', \App\Http\Controllers\Tweet\CreateController::class)
    ->middleware('auth')//追加
    ->name('tweet.create');
```

これでログインしていないときに書き込みをしようとすると、ログイン画面にリダイレクトされるはずです。  
しかし、これだけだと投稿フォームは表示されているので、ログインしていない人にも投稿フォームが表示されてしまっていて、不親切です。

ログアウトしてても投稿フォームが表示される。

viewを書き換えて、ログインしている人にだけ投稿フォームが表示されるようにしてみましょう。

<p class="tmp list"><span>リスト</span>resources/views/tweet/index.blade.php</p>
```
@auth
    <div>
        <p>投稿フォーム</p>
        @if (session('feedback.success'))
            <p style="color: green">{{ session('feedback.success') }}</p>
        @endif
        <form action="{{ route('tweet.create') }}" method="post">
            @csrf
            <label for="tweet-content">つぶやき</label>
            <span>140文字まで</span>
            <textarea id="tweet-content" type="text" name="tweet" placeholder="つぶやきを入力"></textarea>
            @error('tweet')
            <p style="color: red;">{{ $message }}</p>
            @enderror
            <button type="submit">投稿</button>
        </form>
    </div>
@endauth
```

これでログインしているときのみ投稿フォームが表示されるようになります。

ログイン時
![](upload/つぶやきログイン時.png){.photo-border}
ログインなし
![](upload/つぶやきログインなし時.png){.photo-border}

編集や削除ボタンはまだ表示される・・・。

## ログインユーザーの情報を保存する

### tweetsテーブルにユーザーIDを追加する

つぶやきを誰が投稿したのかわかるように、tweetsテーブルにユーザーIDを追加していきます。  
次のartisanコマンドを使ってマイグレーションを追加します。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:migration add_user_id_to_tweets
```

![](upload/add_user_id_to_tweets.png){.photo-border}

ファイルが追加されました。
![](upload/add_user_id_to_tweetsファイル作成.png)

<p class="lang">database/migrations/YYYY_～_add_user_id_to_tweets.php（デフォルト）</p>
```
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('tweets', function (Blueprint $table) {
            //
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('tweets', function (Blueprint $table) {
            //
        });
    }
};
```

<p class="tmp list"><span>リスト</span>database/migrations/YYYY_～_add_user_id_to_tweets.php</p>
```
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddUserIdToTweets extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('tweets', function (Blueprint $table) {
            //追加
            $table->unsignedBigInteger('user_id')->after('id');
            
            // usersテーブルのidカラムにuser_idカラムを関連付けます。
            $table->foreign('user_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('tweets', function (Blueprint $table) {
            //追加
            $table->dropForeign('tweets_user_id_foreign');
            $table->dropColumn('user_id');
        });
    }
}
```

### Seederにユーザーを追加

さきほどの変更によって、Tweetには必ず投稿者が必要になりました。  
今までは投稿者が必要なかったので、その部分のSeederを修正しなければいけません。 

seeders/UserFactories.phpはすでにあるはずなので、これを使っていきます。  
Seederの方はないので、database/seeders/UsersSeeder.phpを作っていきます。  
次のartisanコマンドを実行してください。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:seeder UsersSeeder
```
![](upload/sail_artisan_makeseeder_UsersSeeder.png)

![](upload/UserSeeder作成.png)


<p class="lang">database/seeders/UsersSeeder.php（デフォルト）</p>
```
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
    }
}
```

作成されたファイルに実行部分を記述します。

<p class="tmp list"><span>リスト</span>database/seeders/UsersSeeder.php</p>
```
<?php

namespace Database\Seeders;

use App\Models\User;//追加
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(): void
    {
        User::factory()->create();//追加
    }
}
```

Tweetのシーディングの方もUserIdを登録するように変更します。

<p class="tmp list"><span>リスト</span>database/factories/TweetFactory.php</p>
```
<?php

namespace Database\Factories;

use App\Models\Tweet;
use Illuminate\Database\Eloquent\Factories\Factory;

class TweetFactory extends Factory
{
    protected $model = Tweet::class;

    public function definition()
    {
        return [
            'user_id' => 1, // つぶやきを投稿したユーザーのIDをデフォルトで1とする 追加
            'content' => $this->faker->realText(100)
        ];
    }
}
```

これらの変更を終えたら、UsersSeederクラスをDatabaseSeederに登録することで実行されます。  
実行の順序を考えると、ユーザーが先に作られて、その後にユーザーIDを持ったつぶやきが作られるはずなので、Users Seeder TweetsSeederの順番に実行されるように登録します。

<p class="tmp list"><span>リスト</span>database/seeders/DatabaseSeeder.php</p>
```
<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $this->call([
            UsersSeeder::class,
            TweetsSeeder::class
        ]);
    }
}
```

次のartisanコマンドを実行するとマイグレーションとシーディングを最初からやり直すことができます。
<p class="tmp cmd"><span>コマンド</span>マイグレーション</p>
```
sail artisan migrate:fresh --seed
```
マイグレーションとシーディングをやり直すと、ここまでに登録したユーザーもデータベースから削除されます。ログインができなくなるため、終わったら
再度「<http://localhost/register>」からユーザーを登録しましょう。

## つぶやきにユーザーのIDを保存する

次につぶやきをしたユーザのIDを保存していきます。  
ユーザー情報については、Requestクラスから取得することができます。

<p class="tmp list"><span>リスト</span>app/Http/Requests/Tweet/CreateRequest.php</p>
```
<?php

namespace App\Http\Requests\Tweet;

use Illuminate\Foundation\Http\FormRequest;

class CreateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'tweet' => 'required|max:140'
        ];
    }

    // Requestクラスのuser関数で今自分がログインしているユーザーが取得できる  追加
    public function userId(): int
    {
        return $this->user()->id;
    }

    public function tweet(): string
    {
        return $this->input('tweet');
    }
}
```

<span class="red">Requestクラスのuser 関数は今ログインしているユーザーの情報を返してくれます。</span>ガードのところで説明しましたが、今はwebガードがデフォルトで設定されており、providerの設定からusersテーブルの情報をEloquentモデルにして返してくれるようになっています。  
こちらのidを、つぶやきを保存するときの他の情報と一緒に保存します。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/CreateController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tweet\CreateRequest;
use App\Models\Tweet;

class CreateController extends Controller
{
    public function __invoke(CreateRequest $request)
    {
        $tweet = new Tweet;
        $tweet->user_id = $request->userId(); // ここでUserIdを保存している　追加
        $tweet->content = $request->tweet();
        $tweet->save();
        return redirect()->route('tweet.index');
    }
}
```
これでつぶやきと一緒に、つぶやいたユーザーのIDを保存することができます。



### つぶやきの表示に投稿者の情報を追加する

せっかくつぶやきに投稿者のIDを追加したので、つぶやきアプリで誰がつぶやいたものかわかるるようにしてみましょう。
まず、UserモデルからTweetモデルへの関連付けを行います。

<p class="tmp list"><span>リスト</span>app/Models/User.php</p>
```
<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    …省略…

	//追加
    public function tweets()
    {
        return $this->hasMany(Tweet::class);
    }
}
```

次にTweetモデルからUserモデルへの関連付けを行います。

<p class="tmp list"><span>リスト</span>app/Models/Tweet.php</p>
```
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tweet extends Model
{
    use HasFactory;
	//追加
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
```

これでモデル同士で関連するモデルのデータを取得することができるようになりました。
最後に、つぶやきを表示している部分にユーザー情報を表示します。
index.blade.phpのつぶやきの部分につぶやいたユーザーの名前を追加します。

<p class="tmp list"><span>リスト</span>resources/views/tweet/index.blade.php</p>
```
<!doctype html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>つぶやきアプリ</title>
</head>
<body>
    <h1>つぶやきアプリ</h1>
    @auth
    <div>
        <p>投稿フォーム</p>
        @if (session('feedback.success'))
            <p style="color: green">{{ session('feedback.success') }}</p>
        @endif
        <form action="{{ route('tweet.create') }}" method="post">
            @csrf
            <label for="tweet-content">つぶやき</label>
            <span>140文字まで</span>
            <textarea id="tweet-content" type="text" name="tweet" placeholder="つぶやきを入力"></textarea>
            @error('tweet')
            <p style="color: red;">{{ $message }}</p>
            @enderror
            <button type="submit">投稿</button>
        </form>
    </div>
    @endauth
    <div>
    @foreach($tweets as $tweet)
        <details>
              <summary>{{ $tweet->content }} by {{ $tweet->user->name }}</summary><!--追加変更-->
            <div>
                <a href="{{ route('tweet.update.index', ['tweetId' => $tweet->id]) }}">編集</a>
                <form action="{{ route('tweet.delete', ['tweetId' => $tweet->id]) }}" method="post">
                    @method('DELETE')
                    @csrf
                    <button type="submit">削除</button>
                </form>
            </div>
        </details>
    @endforeach
    </div>
</body>
</html>
```

これでブラウザで表示してみましょう。
だれがつぶやいたのか確認できるようになっています。

![](upload/投稿フォームに投稿者を表示png.png){.photo-border}


## 自分の投稿だけを編集・削除可にする

ログインしているかどうかのチェックは投稿フォームのところで先ほど実装しましたが、その中でも「適切なユーザーとしてログインしているか」はまた別の問題です。  
今回はログインしているかどうかをチェックするだけでなく、「つぶやきの作成者と同じユーザーでログインしているか」を確認していきます。


### ルーティングを書き換える

まず、編集画面、削除画面などのユーザー情報が必要な画面については、ログインしていないとアクセスできないようにルーティングを書き換えます。

<p class="tmp list"><span>リスト</span>routes/web.php</p>
```
･･･
Route::get('/tweet', \App\Http\Controllers\Tweet\IndexController::class)->name('tweet.index');
Route::middleware('auth')->group(function () {//追加
    Route::post('/tweet/create', \App\Http\Controllers\Tweet\CreateController::class)
        ->name('tweet.create'); //->middleware('auth')は削除
    Route::get('/tweet/update/{tweetId}', \App\Http\Controllers\Tweet\Update\IndexController::class)->name('tweet.update.index');
    Route::put('/tweet/update/{tweetId}', \App\Http\Controllers\Tweet\Update\PutController::class)->name('tweet.update.put');
    Route::delete('/tweet/delete/{tweetId}', \App\Http\Controllers\Tweet\DeleteController::class)->name('tweet.delete');
});//追加
･･･
```

Route::middleware()を使うと複数のルートにミドルウェアを指定することができます。


### 追加する機能

次に、つぶやきの編集の部分に以下の処理を追加して、つぶやきの作成者しか編集できないように変更します。

* つぶやきの情報から作成者のユーザーIDを取得する
* ログインユーザー情報からユーザーIDを取得する
* ユーザーIDが合致するか確認する


今回は、Serviceクラスに上記のコードを実装していきます。

<p class="tmp list"><span>リスト</span>app/Services/TweetService.php</p>
```
<?php

namespace App\Services;

use App\Models\Tweet;

class TweetService
{
    public function getTweets()
    {
        return Tweet::orderBy('created_at', 'DESC')->get();
    }
    // 自分のtweetかどうかをチェックするメソッド
    public function checkOwnTweet(int $userId, int $tweetId): bool
    {
        $tweet = Tweet::where('id', $tweetId)->first();
        if (!$tweet) {
            return false;
        }

        return $tweet->user_id === $userId;
    }
}
```

このサービスクラスを使って、IndexController.phpの実装を進めていきます。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/<span class="red">Update</span>/IndexController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet\Update;

use App\Http\Controllers\Controller;
use App\Models\Tweet;
use App\Services\TweetService;//追加
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;//追加

class IndexController extends Controller
{
		//invoke内引数追加（TweetService $tweetService）
    public function __invoke(Request $request, TweetService $tweetService)
    {

        $tweetId = (int) $request->route('tweetId');
        //追加
        if (!$tweetService->checkOwnTweet($request->user()->id, $tweetId)) {
            throw new AccessDeniedHttpException();
        }
        
        $tweet = Tweet::where('id', $tweetId)->firstOrFail();
        return view('tweet.update')->with('tweet', $tweet);
    }
}
```

これで、他人が投稿したつぶやきの編集画面にアクセスすると、<span class="red">AccessDeniedHttpException</span>が投げられ、403が表示されます。

![](upload/update1_forbidden.png){.photo-border}


「更新」と「削除」の部分にも同様の処理を追加します。

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/Update/PutController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet\Update;

use App\Http\Controllers\Controller;
use App\Http\Requests\Tweet\UpdateRequest;
use App\Models\Tweet;
use App\Services\TweetService;//追加
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;//追加

class PutController extends Controller {
    public function __invoke(UpdateRequest $request, TweetService $tweetService) {//追加変更
        //追加
        if (!$tweetService->checkOwnTweet($request->user()->id, $request->id())) {
            throw new AccessDeniedHttpException();
        }
				
        $tweet = Tweet::where('id', $request->id())->firstOrFail();
        $tweet->content = $request->tweet();
        $tweet->save();
        return redirect()
            ->route('tweet.update.index', ['tweetId' => $tweet->id])
            ->with('feedback.success', "つぶやきを編集しました");
    }
}
```

<p class="tmp list"><span>リスト</span>app/Http/Controllers/Tweet/DeleteController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet;

use App\Http\Controllers\Controller;
use App\Models\Tweet;
use App\Services\TweetService;//追加
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;//追加

class DeleteController extends Controller {
    public function __invoke(Request $request, TweetService $tweetService) {//追加変更
		
        $tweetId = (int) $request->route('tweetId');
        //追加
        if (!$tweetService->checkOwnTweet($request->user()->id, $tweetId)) {
            throw new AccessDeniedHttpException();
        }
				
        $tweet = Tweet::where('id', $tweetId)->firstOrFail();
        $tweet->delete();
        return redirect()
            ->route('tweet.index')
            ->with('feedback.success', "つぶやきを削除しました");
    }
}
```

また、このままだと、編集や削除の権限がない人にもボタンが表示されてしまうので、ボタン自体も非表示にします。

<p class="tmp list"><span>リスト</span>resources/views/tweet/index.blade.php</p>
```
<!doctype html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>つぶやきアプリ</title>
</head>
<body>
    <h1>つぶやきアプリ</h1>
    @auth
    <div>
        <p>投稿フォーム</p>
        @if (session('feedback.success'))
            <p style="color: green">{{ session('feedback.success') }}</p>
        @endif
        <form action="{{ route('tweet.create') }}" method="post">
            @csrf
            <label for="tweet-content">つぶやき</label>
            <span>140文字まで</span>
            <textarea id="tweet-content" type="text" name="tweet" placeholder="つぶやきを入力"></textarea>
            @error('tweet')
            <p style="color: red;">{{ $message }}</p>
            @enderror
            <button type="submit">投稿</button>
        </form>
    </div>
    @endauth
    <div>
    @foreach($tweets as $tweet)
        <details>
            <summary>{{ $tweet->content }} by {{ $tweet->user->name }}</summary>
            @if(\Illuminate\Support\Facades\Auth::id() === $tweet->user_id)<!--追加-->
                <div>
                    <a href="{{ route('tweet.update.index', ['tweetId' => $tweet->id]) }}">編集</a>
                    <form action="{{ route('tweet.delete', ['tweetId' => $tweet->id]) }}" method="post">
                        @method('DELETE')
                        @csrf
                        <button type="submit">削除</button>
                    </form>
                </div>
            @else<!--追加-->
                編集できません
            @endif
        </details>
    @endforeach
    </div>
</body>
</html>
```

これで、つぶやきの作成者のみが編集と削除をできるようになりました。
![](upload/作成者のみが編集と削除可能n.png)

