---
title: '09. ファンクションの書き方'
taxonomy:
    category:
        - docs
visible: true
---

functionによって関数を独自に作ることができます．関数とはプログラムの中で繰り返し行われる処理を，1つにまとめたものです．

<h2 class="h-type2">関数の定義と呼び出し</h2>

### 関数の定義

ファンクションの書き方です。

<p class="tmp"><span>書式1</span></p>

```
function 関数名(引数){
    ここに処理を記入;
    return 戻り値;
}
```

上記のように関数を定義します．詳しく見ていきましょう．  
「関数名」は呼び出す際に使います。関数名に使える文字は，変数と同様です．「引数」は，処理に必要な情報を呼び出し元から受け取るときに使います．「パラメータ」ともいいます．  
「return」によって関数の処理を終了し，呼び出し元の処理を続けます．あとに書かれる「戻り値」は指定した1つの値を呼び出し元に返します．戻り値がない場合は，returnを省略できます．  
「引数」と「戻り値」については，文章だけではわかりづらいので，次の関数の呼び出しを見ながら説明します．

### 関数の呼び出し

時：分：秒を秒数に変換する関数を定義してみましょう．

<iframe width="100%" height="300" src="//jsfiddle.net/k3h8n6t4/9/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

関数を呼び出すには関数名を指定するだけです．呼び出したtoSecondsの後に数値が書かれていますが，これが引数に受け渡されます．この場合，hourは2，minは34，secは56を受け取ります．変数secondsを結果に表示すると，関数toSecondsで処理された数値になっています．これは戻り値がtoSeconds(2, 34, 56)に値を返しているためです．

---


<h2 class="h-type2">グローバル変数とローカル変数</h2>

グローバル変数はプログラム全体に有効な値ですが，関数内でvarで定義した変数はローカル変数となり，関数内部だけで有効になります．グローバル変数とローカル変数の名前が同じでも，別の変数として扱われます．次のコードはその例です．

<iframe width="100%" height="500" src="//jsfiddle.net/k3h8n6t4/6/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

結果を見ると，  
関数showNum()を実行すると，関数内で出力したaは2となっていますが，実行後に関数外で出力したaは2が代入されず，はじめの1のままとなっています．一方bは，関数内で出力すると2となり，実行後も2が代入されています．  
これは，関数内でaをvarで定義したことでローカル変数となり，関数外のaとは違う変数となったためです．bは関数内でvarで定義されていないため，関数外のbと同じ変数です.

---

<h2 class="h-type2">無名関数</h2>

無名関数は関数の名前を省略したものです．変数に入れておくことができます。

<p class="tmp"><span>書式2</span></p>

```
var func = function(引数){
    ここに処理を記入;
    return 戻り値;
}

func(); //関数の呼び出し
```

また，無名関数は関数の引数に指定することができます．例としてsetTimeout関数の引数に無名関数を指定してみましょう．setTimeout関数は，setTimeout(関数名，時間)と記入され，設定した時間（ミリ秒）が経過すると，関数を呼び出す関数です．

<iframe width="100%" height="150" src="//jsfiddle.net/wcjpL34z/3/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

このコードを実行すると，3秒後にアラートが出ます．  
1度しか使わない関数にわざわざ名前を付け別の関数の引数に指定すると，コードが長くなりますし，使用した名前が他に使えない，大きいプログラムだとロスになるなどの問題があります．こんなときに無名関数が便利です．