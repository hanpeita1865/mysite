---
title: '02. CSSのプロパティの取得や変更<br>（css）'
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">CSSのプロパティの取得</h2>

.css()というjQueryメソッドを使って，CSSのプロパティを取得できます．

<p class="tmp"><span>書式1</span>CSSのプロパティを取得する</p>
```
対象要素.css(”取得したいプロパティ”);
---

複数取得したい場合は，それぞれのプロパティを角括弧[ ]で囲みます．

対象要素.css([”プロパティ1”, ”プロパティ2”, ”プロパティ3”, ･･･]);
```

<div class="box-example">
<h3 class="h-example">例1</h3>
CSSのプロパティを取得し，コンソールに表示する．
</div>

<iframe width="100%" height="430" src="//jsfiddle.net/wtfcsy8r/embedded/html,css,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLとCSSを見てみましょう．  
高さ50px，幅50pxで背景色が赤色の＃boxが表示されるようになっています．

ではJavaScriptのコードを見てみましょう．  
property1に，＃boxから背景色を取得したものを格納しています．  
property2に，＃boxから高さ・幅・背景色を取得したものを格納しています．  
コンソールにproperty1，property2をそれぞれ表示しています．

結果を確認します．  
Consoleの1行目はプロパティを1つ取得した場合です．今回は背景色を取得しましたが，CSSで設定した通りの値が表示されています（ただし，表示は10進数です）．  
2行目はプロパティを複数取得した場合です．Objectをクリックしてみましょう．DOM内に取得したプロパティが表示されています．

---

<h2 class="h-type2">CSSのプロパティの変更</h2>

.css()を使って，CSSのプロパティを変更することもできます．

<p class="tmp"><span>書式2</span>CSSのプロパティを変更する</p>
```
対象要素.css(”変更したいプロパティ”，”値”);
---

複数変更したい場合は，それぞれのプロパティを波括弧{ }で囲みます．
また，プロパティと値はコロンで区切ります．

対象要素.css({”プロパティ1”: ”値”, ”プロパティ2”: ”値”, ”プロパティ3”: ”値”, ･･･});
```
<font color="Red">注：取得の場合は角括弧[ ]なので注意しましょう．</font>

<div class="box-example">
<h3 class="h-example">例2</h3>
あらかじめ記述してあるCSSのプロパティを変更する．
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/c31m90fe/embedded/html,css,result,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLとCSSを見てみましょう．  
高さ50px，幅50pxで背景色が赤色のbox1，同じ大きさで背景色が青色のbox2が表示されるようになっています．

先に結果を確認します．  
＃box1は青色，＃box2は赤色で大きくなり，HTMLとCSSの設定とは異なります．  
これはJavaScriptのコードによって変更されたためです．

ではJavaScriptのコードを見てみましょう．  
＃box1の背景色を青色に設定しています．  
＃box2の高さ・幅を75pxに，背景色を赤色に設定しています．

---

<h2 class="h-type2">CSSのプロパティの追加</h2>

CSSのプロパティの変更と同じ書式で，.css()を使って，CSSのプロパティを追加できます．

<div class="box-example">
<h3 class="h-example">例3</h3>
新たにCSSのプロパティを追加する．
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/c31m90fe/1/embedded/result,js,html,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLとCSSを見てみましょう．  
CSSのプロパティの変更で使ったものと同じです。

先に結果を確認します．  
＃box1と＃box2の間にCSSで設定していない余白が入っています．  
これはJavaScriptのコードによってプロパティが追加されたためです．

ではJavaScriptのコードを見てみましょう．  
＃box1の下に余白10pxを設定しています．