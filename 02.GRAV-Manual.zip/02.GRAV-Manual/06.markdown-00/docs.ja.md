---
title: マークダウン記法について
media_order: 'wheelchair.png,image_folder.png,icon_btn_image.png,page_madia_image.png,grav_toolbar.png,grav_toolbar3.png,page_media.png,google.png'
taxonomy:
    category:
        - docs
visible: true
---

<style>
	.toolbar a {
        color: #000;
       text-decoration: underline;
    }
    .toolbar a:hover {
       font-weight: bold;
       color: darkblue;
    }
</style>

**Markdown（マークダウン）**は、文章を記述するための記法（マークアップ言語）の一つです。<br>
メールやチャットを記述する時のように書きやすくて読みやすいプレーンテキストをある程度見栄えのするHTML文書へ変換できるフォーマットです


文章の装飾が自動的に行われるので見た目の調整に取られる時間が減り、コンテンツの作成に集中できるようになります。

以下に基本的なマークダウンの記述の仕方をご紹介します。
中には、GRAV独自の仕様のマークダウンも含んでいます。

## ツールバーアイコンやマークダウンの機能について

### ツールバーアイコン

![](grav_toolbar3.png?classes=d-inline,my-0)

<div class="container toolbar">
<div class="row">
<div class="col-4">
<p><a href="#headword"><p><span  class="fa fa-header fa-border mr-3"></span>見出し</a></p>
<p><a href="#bold"><span  class="fa fa-bold fa-border mr-3"></span>強調（太字）</a></p>
<p><a href="#bold"><span  class="fa fa-italic fa-border mr-3"></span>斜体（イタリック体）</a></p>
<p><a href="#strike"><p><span  class="fa fa-strikethrough fa-border mr-3"></span>取り消し線</a></p>
<p><a href="#link"><span  class="fa fa-link fa-border mr-3"></span>リンク</a></p>
<p><a href="#picture"><span  class="fa fa-picture-o fa-border mr-3"></span>画像埋め込み</a></p>
</div>

<div class="col-8">
<p><a href="#quote"><span  class="fa fa-quote-right fa-border mr-3"></span>引用</a></p>
<p><a href="#list-ul"><span  class="fa fa-list fa-border mr-3"></span>リスト（ul）</a></p>
<p><a href="#list-ol"><span  class="fa fa-list-ol fa-border mr-3"></span>リスト（ol）</a></p>
<p><span  class="fa fa-code fa-border mr-3"></span>エディタ</p>
<p><span  class="fa fa-eye fa-border mr-3"></span>プレビュー</p>
<p><span  class="fa fa-expand fa-border mr-3"></span>全画面</p>
</div>
</div>
</div>

### その他のマークダウンの機能

<div class="container toolbar" markdown="1">
<div class="row" markdown="1">
<div class="col-4" markdown="1">

[定義リスト](#list-dl)（ツールバーにありません）

[テーブル](#table)（ツールバーにありません）

[コードの挿入](#code)（ツールバーにありません）

[折りたたみ](#details)（ツールバーにありません）

[水平線](#line)（ツールバーにありません）

</div>

<div class="col-8" markdown="1">

[テキストに色を設定](#text-color)（プラグイン使用）

[テキストの通知ブロックを生成](#text-block)（プラグイン使用）

[画像にキャプションを設定](../plugin/img_caption)（プラグイン使用）

[Markdown Extra](#extra)（デフォルトは無効になってます）

</div>
</div>
</div>


## 文字の入力

### 下記のように入力すると、改行されずに横並びに表示されます。


<p class="write"><span>記入例</span></p>

    あいうえお
    かきくけこ


<p class="comp"><span>HTML変換</span></p>

    <p>あいうえお
    かきくけこ</p>

<p class="result"><span>結果</span></p>

あいうえお
かきくけこ


### 行末に半角スペース2つ入れることで、行に改行をつけることができます。

<p class="write"><span>記入例</span></p>

    あいうえお  
    かきくけこ


<p class="comp"><span>HTML変換</span></p>

    <p>あいうえお<br>
    かきくけこ</p>

<p class="result"><span>結果</span></p>

あいうえお  
かきくけこ

### 段落を付ける場合は、行間に一行スペースを入れます。

<p class="write"><span>記入例</span></p>

    あいうえお

    かきくけこ


<p class="comp"><span>HTML変換</span></p>

    <p>あいうえお</p>
    <p>かきくけこ</p>


<p class="result"><span>結果</span></p>

あいうえお

かきくけこ



## <span  class="fa fa-header fa-border mr-3"></span>見出し ## {#headword}

<p class="write"><span>記入例</span></p>

~~~markdown
### これはH3タグです
#### これはH4タグです
##### これはH5タグです
~~~

<p class="comp"><span>HTML変換</span></p>

    <h3>これはH3タグです</h3>
    <h4>これはH4タグです</h4>
    <h5>これはH5タグです</h5>


<p class="result"><span>結果</span></p>

### これはH3タグです

#### これはH4タグです

##### これはH5タグです




## <span  class="fa fa-bold fa-border mr-3"></span><span  class="fa fa-italic fa-border pull-left"></span>斜体・強調 ## {#bold}

<p>_ か * で囲むとHTMLのemタグになり、斜体（イタリック体）になります。<br>
__ か ** で囲むとHTMLのstrongタグになり、太字になります。</p>

<p class="write"><span>記入例</span></p>

    HTMLの*emタグ*になります
    HTMLの**strongタグ**になります


<p class="comp"><span>HTML変換</span></p>

    <p>HTMLの<em>emタグ</em>になります</p>
    <p>HTMLの<strong>strongタグ</strong>になります</p>

<p class="result"><span>結果</span></p>
HTMLの*emタグ*になります

HTMLの**strongタグ**になります


## 取り消し線 ##{#strike}


打ち消し線を使うには ~~ で囲みます。

<p class="write"><span>記入例</span></p>

	今日は、~~晴れています。~~曇っています。


<p class="comp"><span>HTML変換</span></p>

    <p>今日は、<del>晴れています。</del>曇っています。</p>


<p class="result"><span>結果</span></p>
今日は、~~晴れています。~~曇っています。




## <span  class="fa fa-link fa-border mr-3"></span>リンク ## {#link}

<p>ツールバーの<span  class="fa fa-link fa-border mr-3"></span>アイコンをクリックすると</p>

    []()

が表示されるので、それを元に整形すると簡単に設定できます。

<p class="tmp"><span>書式</span></p>


    [リンクテキスト](URL)

    [リンクテキスト](URL "タイトル")　　※タイトル付き
    
    ※<URL>だけでもでもリンクになります。



<p class="write"><span>記入例</span></p>

<pre>
<span class="comment">// 内部リンク</span>
[HTML5トップページ](../../html5-foundation) のページに移動します。

<span class="comment">// 新規ウィンドウの場合</span>
[Google](http://google.com<strong class="text-red">?target=_blank</strong>)

<p class="mt-1">※「<strong>External Links</strong>」プラグインを入れれば、「<strong class="text-danger">?target=_blank</strong>」を付けなくても新規ウィンドウになります。</p>

<span class="comment">// URLを「&lt;&gt;」で囲むだけでも、リンクになります。</span>
&lt;http://google.com&gt;
</pre>


<p class="result"><span>結果</span></p>


 [HTML5トップページ](../../html5-foundation) のページに移動します。


[Google](http://google.com?target=_blank)

<http://google.com>


### クラス属性設置

<p class="write"><span>記入例</span></p>
<pre>
 [HTML5トップページ](../../html5-foundation<span class="text-danger bold">?classes=button,big</span>)
 
 <span class="comment">//リンクの場合は、後ろに {.クラス名}をつけても設定できます。</span>
 [Google](http://google.com) {.exclude}
</pre>


<p class="comp"><span>HTML変換</span></p>

	<a href="../../html5-foundation" class="button big">HTML5トップページ</a>

	<a href="http://google.com" class="exclude">Google</a>


<p class="result"><span>結果</span></p>

[HTML5トップページ](../../html5-foundation?classes=button,big)

 [Google](http://google.com) {.exclude}




### ID属性設置

<p class="write"><span>記入例</span></p>
<pre>
[HTML5トップページ](../../html5-foundation<span class="text-danger bold">?id=important-button</span>)
</pre>

<p class="comp"><span>HTML変換</span></p>

	<a href="../../html5-foundation" id="important-button">HTML5トップページ</a>



### 属性の組み合わせ

<p class="write"><span>記入例</span></p>
<pre>
[HTML5トップページ](../../html5-foundation?target=_blank<span class="text-danger bold">&</span>classes=button)
</pre>


<p class="comp"><span>HTML変換</span></p>

	<a href="../../html5-foundation" target="_blank" class="button">HTML5トップページ</a>



## <span  class="fa fa-picture-o fa-border mr-3"></span>画像埋め込み ## {#picture}


### 画像登録方法

各ページごとの最下部にある登録エリアに画像を**{c:red}ドラッグ&ドロップ{/c}**するか、登録エリア内を**{c:red}クリック{/c}**して選択し、画像を登録してください。

![](page_media.png)


### 登録した画像を表示させる

<p>ツールバーの<span  class="fa fa-picture-o fa-border"></span>アイコンをクリックすると</p>
<pre>
![](http://)
</pre>
が表示されるので、それを元に整形すると簡単に設定できます。


<p class="tmp"><span>書式</span></p>

<pre>
<span class="comment">//タイトル無しの画像を埋め込む</span>
<strong>![代替テキスト](画像のURL)</strong>

<span class="comment">//タイトル有りの画像を埋め込む</span>
<strong>![代替テキスト](画像のURL "画像タイトル")</strong>
</pre>



<p class="write"><span>記入例</span></p>
<pre>
&#33;[](wheelchair.png)
</pre>

<p class="comp"><span>HTML変換</span></p>

<pre>
&lt;img alt="" src="wheelchair.png"&gt;
</pre>

<p class="result"><span>結果</span></p>

![](wheelchair.png)

※上記の場合は、原寸大で表示されます。

別の方法で、登録した画像横の
![](icon_btn_image.png?classes=d-inline,my-0)
アイコンをクリックしても、下記の図のように登録した画像のマークダウンを記入することができます。（こっちの方が多分楽だと思います。）

![](page_madia_image.png)

### 画像にリンクを貼る

<p class="write"><span>記入例</span></p>
<pre>
[![](google.png)](https://www.google.co.jp/)
</pre>

<p class="result"><span>結果</span></p>

[![](google.png)](https://www.google.co.jp/)

### 画像を別ウィンドウで表示

<p class="write"><span>記入例</span></p>
<pre>
[![](google.png)](google.png?target=_blank)
</pre>

<p class="result"><span>結果</span></p>

[![](google.png)](google.png?target=_blank)


### 画像のサイズを設定
<p class="write"><span>記入例</span></p>
<pre>
![](wheelchair.png<span class="text-danger bold">?cropResize=200,200</span>)
</pre>

<p class="result"><span>結果</span></p>

![](wheelchair.png?cropResize=200,200)


### 単一クラス属性
<p class="write"><span>記入例</span></p>
<pre>
![](wheelchair.png<span class="text-danger bold">?classes=w-25</span>)
</pre>

<p class="comp"><span>HTML変換</span></p>

	<img alt="" class="w-25" src="wheelchair.png">


<p class="result"><span>結果</span></p>

![](wheelchair.png?classes=w-25)


### 複数のクラス属性
<p class="write"><span>記入例</span></p>
<pre>
![](wheelchair.png<span class="text-red bold">?classes=w-25,photo1</span>)
</pre>

<p class="comp"><span>HTML変換</span></p>

	<img alt="" class="w-25 photo1" src="wheelchair.png">



### 画像サイズとクラス属性の両方を設定
<p class="write"><span>記入例</span>間に「&amp;」を入れる</p>
<pre>
![](wheelchair.png<span class="text-danger bold">?cropResize=200&amp;classes=shadow</span>)
</pre>

<p class="result"><span>結果</span></p>

![](wheelchair.png?cropResize=200&classes=shadow)


### id属性
<p class="write"><span>記入例</span></p>
<pre>
![](wheelchair.png<span class="text-danger bold">?id=box01</span>)
</pre>



### 共通の画像

共通て使用したい画像があれば、下記のようにimagesフォルダを任意の場所に作成してそこに登録してください。

#### 例

![](image_folder.png)

<p class="write"><span>記入例</span></p>
<pre>
![](../../images/8372.png)
</pre>

<p class="comp"><span>HTML変換</span></p>
<pre>
&lt;img alt="" src="../../8372.png"&gt;
</pre>



## <span  class="fa fa-quote-left fa-border mr-3"></span>引用 ## {#quote}

文頭に>を置くことで引用になります。<br>
複数行にまたがる場合、改行のたびにこの記号を置く必要があります。<br>
引用の上下にはリストと同じく空行がないと正しく表示されません

**※ 後述のmarkdown-noticesプラグインで使用するスタイルとほぼ同じなので、使用することはないかも。**

<p class="write"><span>記入例</span></p>

    > これは引用文章です。<br>
    > これは引用文章です。


<p class="comp"><span>HTML変換</span></p>

```html
<blockquote>
    <p>これは引用文章です。<br>
    これは引用文章です。</p>
</blockquote>
```

<p class="result"><span>結果</span></p>

> これは引用文章です。<br>
> これは引用文章です。
> 

<p class="write"><span>記入例</span>引用はネストしたり、引用のなかでMarkdownを使用することもできる。</p>
```
> 文化庁によれば、適切な「引用」と認められるためには、以下の要件が必要とされる。 
>> * ア 既に公表されている著作物であること
>> * イ 「公正な慣行」に合致すること
>> * ウ 報道，批評，研究などの引用の目的上「正当な範囲内」であること
>> * エ 引用部分とそれ以外の部分の「主従関係」が明確であること
>> * オ カギ括弧などにより「引用部分」が明確になっていること
>> * カ 引用を行う「必然性」があること
>> * キ 「出所の明示」が必要（コピー以外はその慣行があるとき）
>> 
>> <cite>— 文化庁 (2010)、§8. 著作物等の「例外的な無断利用」ができる場合 ⑧ ア、「引用」（第32条第1項）</cite>
>
> <cite>[Wikipedia](https://ja.wikipedia.org/wiki/%E5%BC%95%E7%94%A8)より</cite>
```

<p class="result"><span>結果</span></p>
> 文化庁によれば、適切な「引用」と認められるためには、以下の要件が必要とされる。 
>> * ア 既に公表されている著作物であること
>> * イ 「公正な慣行」に合致すること
>> * ウ 報道，批評，研究などの引用の目的上「正当な範囲内」であること
>> * エ 引用部分とそれ以外の部分の「主従関係」が明確であること
>> * オ カギ括弧などにより「引用部分」が明確になっていること
>> * カ 引用を行う「必然性」があること
>> * キ 「出所の明示」が必要（コピー以外はその慣行があるとき）
>> 
>> <cite>— 文化庁 (2010)、§8. 著作物等の「例外的な無断利用」ができる場合 ⑧ ア、「引用」（第32条第1項）</cite>
>
> <cite>[Wikipedia](https://ja.wikipedia.org/wiki/%E5%BC%95%E7%94%A8)より</cite>


## リスト

### <span  class="fa fa-list fa-border mr-3"></span>Disc型（ul） ###{#list-ul}

文頭に「&#42;」「+」「-」のいずれかを入れるとDisc型リストになります<br>
リストを挿入する際は、 リストの上下に空行がないと正しく表示されません。また「&#42;」「+」「-」の後にはスペースが必要です

<p class="write"><span>記入例</span></p>

    * パイナップル
    * メロン
    * オレンジ


<p class="comp"><span>HTML変換</span></p>

    <ul>
        <li>パイナップル</li>
        <li>メロン</li>
        <li>オレンジ</li>
    </ul>

<p class="result"><span>結果</span></p>

* パイナップル
* メロン
* オレンジ


### <span  class="fa fa-list-ol fa-border mr-3"></span>Decimal型（ol） ### {#list-ol}

文頭に「数字.」を入れるとDecimal型リストになります<br>
後からの挿入/移動を考慮して、1. 2. 3. と順番にするのではなく、1. 1. 1. という風に同じ数字にしておくといい具合です。<br>
リストを挿入する際は、 リストの上下に空行がないと正しく表示されません。また「数字.」の後にはスペースが必要です

<p class="write"><span>記入例</span></p>

    1. 山梨県
    1. 香川県
    1. 石川県

<p class="comp"><span>HTML変換</span></p>

    <ol>
        <li>山梨県</li>
        <li>香川県</li>
        <li>石川県</li>
    </ol>

<p class="result"><span>結果</span></p>

1. 山梨県
1. 香川県
1. 石川県






## 定義リスト ## {#list-dl}

**Markdown Extra**を有効にしている場合は、定義リストを記入例のようにマークダウンで記述できます。  
<i class="fa fa-check-square text-primary"></i>（テンプレートは設定済み）  
無効に設定している場合は、HTMLのdl要素で記述してください。

<p class="write"><span>記入例</span></p>

    フルーツ
    : りんご、バナナ、みかん

    野菜
    : レタス、大根、じゃがいも

<p class="comp"><span>HTML変換</span></p>

    <dl>
        <dt>フルーツ</dt>
        <dd>りんご、バナナ、みかん</dd>
        <dt>野菜</dt>
        <dd>レタス、大根、じゃがいも</dd>
    </dl>

<p class="result"><span>結果</span></p>

フルーツ
: りんご、バナナ、みかん

野菜
: レタス、大根、じゃがいも



## <span  class="fa fa-table fa-border mr-3"></span>テーブル ## {#table}

<p class="write"><span>記入例</span></p>

```markdown
| Column 1 | Column 2 | Column 3 |
| -------- | -------- | -------- |
| Text     | Text     | Text     |
```

<p class="comp"><span>HTML変換</span></p>

    <table>
        <thead>
            <tr>
                <th>Column 1</th>
                <th>Column 2</th>
                <th>Column 3</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Text</td>
                <td>Text</td>
                <td>Text</td>
            </tr>
        </tbody>
    </table>


<p class="result"><span>結果</span></p>

| Column 1 | Column 2 | Column 3 |
| -------- | -------- | -------- |
| Text     | Text     | Text     |


<p class="write"><span>記入例</span></p>

「:」（コロン）を入れることで列全体を左寄せ（初期値）、右寄せ、中央寄せに設定できます。

```markdown
| 左寄せ | 中央寄せ |右寄せ |
|:-----------|:------------:|------------:|
| This       | This        | This         |
| column     | column      | column       |
| will       | will        | will         |
| be         | be          | be           |
| left       | right       | center       |
| aligned    | aligned     | aligned      |
```

<p class="result"><span>結果</span></p>

| 左寄せ | 中央寄せ |右寄せ |
|:-----------|:------------:|------------:|
| This       | This        | This         |
| column     | column      | column       |
| will       | will        | will         |
| be         | be          | be           |
| left       | center    | right        |
| aligned    | aligned     | aligned      |



## コードの挿入 ## {#code}

「 `（バッククオート）」 を使用して以下のように投稿するとシンタックスハイライトが適用されます。<br>
コードブロック上下に空行を挿入しないと正しく表示されません。


<p class="write"><span>記入例</span></p>

<pre>
<span class="text-red bold">&#096;&#096;&#096;</span>
main #news h2 {
	position: relative;
	background-color: #ffc000;
	color: #652f00;
	padding: 0.8rem 0.8rem 0.8rem 5.7rem;
	margin: 0;
	font-size: 2rem;
}
<span class="text-red bold">&#096;&#096;&#096;</span>
</pre>


コード全体にTabキーでインデントを付けるか、半角スペース4つでも、コード挿入になります。

<pre>
<span class="comment">↓ Tabキーでインデントを入れる</span>
	main #news h2 {
		position: relative;
		background-color: #ffc000;
		color: #652f00;
		padding: 0.8rem 0.8rem 0.8rem 5.7rem;
		margin: 0;
		font-size: 2rem;
	}
</pre>




<p class="result"><span>結果</span></p>


```
main #news h2 {
	position: relative;
	background-color: #ffc000;
	color: #652f00;
	padding: 0.8rem 0.8rem 0.8rem 5.7rem;
	margin: 0;
	font-size: 2rem;
}
```


## 折りたたみ ## {#details} 

追加情報としたい内容を、detailsタグで囲みます。そして、要約として表示したい文章やコードをsummaryタグで記載します。タイトルをクリックすると内容が表示される設定になります。


<p class="tmp"><span>書式</span></p>

```html
<details><summary>タイトル</summary>
表示内容
</details>
```

<p class="write"><span>記入例</span></p>

    <details><summary>マークダウンの特徴</summary>
    簡単で覚えやすい記述です。
    文章の構造を明示でき、Markdownそのままでも理解できます。  
    対応アプリを使うことでより快適に読み書きできます。拡張子は「.md」になります。
    </details>


<p class="result"><span>結果</span></p>
<details><summary>マークダウンの特徴</summary>
簡単で覚えやすい記述です。
文章の構造を明示でき、Markdownそのままでも理解できます。  
対応アプリを使うことでより快適に読み書きできます。拡張子は「.md」になります。
</details>



## 水平線 ## {#line}

下記はすべて水平線で表示されます。
<pre>
* * *
***
*****
- - -
---------------------------------------
</pre>


<p class="result"><span>結果</span></p>

* * *
***
*****
- - -
---------------------------------------




## テキストに色を設定（プラグイン） ## {#text-color}

**プラグイン{c:red}Markdown Color{/c}**をインストールすると、Markdownの文章に文字色の設定ができます。  
<i class="fa fa-check-square text-primary"></i>（テンプレートは設定済み）

### 使い方

<strong class="text-red bold">{c:カラー名}テキスト{/c}</strong> 、もしくは <strong class="text-red bold">{c:#16進数カラーコード}テキスト{/c}</strong>で色を指定します。

<p class="write"><span>記入例</span></p>

```markdown
{c:red}あいうえお{/c}{c:blue}かきくけこ{/c}{c:#33FF66}さしすせそ{/c}
```


<p class="result"><span>結果</span></p>

{c:red}あいうえお{/c}{c:blue}かきくけこ{/c}{c:#33FF66}さしすせそ{/c}

太字にしたいときは、下記のように「****」を入れてください。

<p class="write"><span>記入例</span></p>

<pre>
**{c:red}あいうえお{/c}**{c:blue}かきくけこ{/c}{c:#33FF66}さしすせそ{/c}
</pre>

<p class="result"><span>結果</span></p>

**{c:red}あいうえお{/c}**{c:blue}かきくけこ{/c}{c:#33FF66}さしすせそ{/c}


### テーブルにも設定できます。

<p class="write"><span>記入例</span></p>
<pre>
| Column 1 | Column 2 | Column 3 |
| -------- | -------- | -------- |
| **{c:red}Text{/c}** | Text  | **{c:blue}Text{/c}** |
</pre>

| Column 1 | Column 2 | Column 3 |
| -------- | -------- | -------- |
| **{c:red}Text{/c}** | Text  | **{c:blue}Text{/c}** |



## テキストの通知ブロックを生成（プラグイン） ## {#text-block}

**プラグイン{c:red}markdown-notices{/c}**を使用すると、 markdownを介してテキストの通知ブロックを生成できます。  
<i class="fa fa-check-square text-primary"></i>（テンプレートは設定済み）

### 使い方

 user > plugins > markdown-notices > **markdown-notices.yaml**

 **markdown-notices.yaml** 内の下記の箇所で色は設定できます。
<pre>
level_classes: [yellow, red, blue, green]
</pre>

文章の頭に「&#33; 」（&#33;の後に半角スペース）を付けます。  色の種類は「&#33;」の数で設定します。

* 「&#33; 」 →　黄色
* 「&#33;&#33; 」 →　赤
* 「&#33;&#33;&#33; 」 →　青
* 「&#33;&#33;&#33; 」 →　緑

<p class="write"><span>記入例</span></p>
<pre>
! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris feugiat quam erat, ut iaculis diam posuere nec. ! Vestibulum eu condimentum urna. Vestibulum feugiat odio ut sodales porta. Donec sit amet ante mi. Donec lobortis ! orci dolor. Donec tristique volutpat ultricies. 
</pre>

! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris feugiat quam erat, ut iaculis diam posuere nec. ! Vestibulum eu condimentum urna. Vestibulum feugiat odio ut sodales porta. Donec sit amet ante mi. Donec lobortis ! orci dolor. Donec tristique volutpat ultricies. 

<p class="write"><span>記入例</span></p>
<pre>
!! Lorem ipsum dolor sit amet, **consectetur adipiscing** elit. Mauris feugiat quam erat, ut iaculis diam posuere nec. 
</pre>

!! Lorem ipsum dolor sit amet, **consectetur adipiscing** elit. Mauris feugiat quam erat, ut iaculis diam posuere nec.




## テーブルや見出しなどのマークダウンにクラスやidを設定する ## {#extra}

**{c:red}Markdown Extra{/c}を有効にすることによって、マークダウンのテーブルや見出しなどにクラスを当てらます。**

下記のファイルの48行目の「extra: {c:red}false{/c}」 を「extra: {c:red}true{/c}」に変更すれば有効になります。

/ user / config / **system.yaml**

<pre>
  markdown:
    <span class="text-red">extra: true</span>
    auto_line_breaks: false
    auto_url_links: false
    escape_markup: false
    special_chars:
</pre>

<i class="fa fa-check-square text-primary"></i>（テンプレートは設定済み）



### テーブルの外側のdivにclassやidを設定

&lt;div&gt;に **{c:red}markdown="1"{/c}** を入れることで設定できます。

<p class="write"><span>記入例</span></p>
<pre>
&lt;div class="table table-p1" id="test" markdown="1"&gt;
| タイトル1 | タイトル2 |
|--------|--------|
| AAA  | AAA |
| BBB  | BBB |
&lt;/div&gt;
</pre>

<p class="comp"><span>HTML変換</span></p>

```html
<div class="table table-p1" id="test">
	<table>
		<thead>
			<tr>
			<th>タイトル1</th>
			<th>タイトル2</th>
			</tr>
		</thead>
		<tbody>
			<tr>
			<td>AAA</td>
			<td>AAA</td>
			</tr>
			<tr>
			<td>BBB</td>
			<td>BBB</td>
			</tr>
		</tbody>
	</table>
</div>
```

<p class="result"><span>結果</span></p>
<div class="table table-p1" id="test" markdown="1">
| タイトル1 | タイトル2 |
|--------|--------|
| AAA  | AAA |
| BBB  | BBB |
</div>


### テーブルにタイトルを付ける

<p class="write"><span>記入例</span></p>
<pre>
&lt;div class="table table-p1" markdown="1"&gt;
#### テーブルタイトル #### {.tb-caption} 
| タイトル1 | タイトル2 |
|--------|--------|
| AAA  | AAA |
| BBB  | BBB |
&lt;/div&gt;
</pre>

クラスtb-captionのスタイルは、custom.cssに記述しています。

<details><summary>.tb-captionのスタイル</summary>
<pre>
.tb-caption {
    margin-top: 2rem;
    margin-bottom: 0.2rem;
    font-size: 1.2rem;
    text-align: center;
    font-weight: bold;
}
</pre>
</details>


<p class="result"><span>結果</span></p>
<div class="table table-p1" markdown="1">
#### テーブルタイトル #### {.tb-caption} 
| タイトル1 | タイトル2 |
|--------|--------|
| AAA  | AAA |
| BBB  | BBB |
</div>

### 見出しにID属性を設定

<p class="write"><span>記入例</span></p>
<pre>
### 見出しタイプ3 ### {#main} 
</pre>

<p class="comp"><span>HTML変換</span></p>
<pre>
&lt;h3 id="main"&gt;見出しタイプ3&lt;/h3&gt;
</pre>

<p class="result"><span>結果</span></p>

### 見出しタイプ3 ### {#main} 

### 見出しにID属性とクラス属性の両方を設定

<p class="write"><span>記入例</span></p>
<pre>
### 見出しタイプ3 ### {#main .type1} 
</pre>

<p class="comp"><span>HTML変換</span></p>
<pre>
&lt;h3 id="main" class="type1"&gt;見出しタイプ3&lt;/h3&gt;
</pre>




※　Markdown Extra についての詳しい記入の仕方は、下記のサイトを参考にしてください。

* [php Markdown Extra](https://michelf.ca/projects/php-markdown/extra/?target=_blank)（英語版）
* [php Markdown Extra](https://translate.google.com/translate?hl=ja&sl=auto&tl=ja&u=https%3A%2F%2Fmichelf.ca%2Fprojects%2Fphp-markdown%2Fextra%2F?target=_blank)（Googleで翻訳）







