---
title: テーマの種類
media_order: theme5_pro.png
taxonomy:
    category:
        - docs
visible: true
---

## プロフェッショナル ウェブサイト 1.11

バナー画像、水平型のナビゲーションなど、ホームページ用途に適したデザインです。あらかじめ用意されたページをカスタマイズして、簡単にウェブサイトを作成できます。

### トップページ

[新規タブ](../../../sample/movable/theme_professional/index.html?target=_blank)

<iframe width="100%" height="700" src="../../sample/movable/theme_professional/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
