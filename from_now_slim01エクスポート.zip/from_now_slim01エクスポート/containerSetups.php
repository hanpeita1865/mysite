<?php
use DI\Container;
use Slim\Factory\AppFactory;
use Slim\Views\Twig;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Formatter\LineFormatter;
use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\middlewares\CheckIPAddressBefore;
use SocymSlim\SlimMiddle\Services\EditService;

require 'admin/basepath.php';

$container = new Container();

error_reporting(0);

require_once('vendor/autoload.php');

use Spatie\Async\Pool;


//サービステスト
// return [
//     EditService::class => function (ContainerInterface $c) {
//         return new EditService();
//     },
// ];

// サービステスト
// $container->set(EditService::class, function (ContainerInterface $c) {
//     return new EditService();
// });





// $container->set('basePath', '/from_now_slim_01');

// $container->set('siteName', 'from_now_slim');


//-------------------//
// 　　 共 通        //
//------------------//

//サービステスト（一旦コメントアウト）
// $container->set(
//     "view",
//     function () {
//         global $basePath;
//         $twig = Twig::create($_SERVER["DOCUMENT_ROOT"] . $basePath . "/templates");
//         return $twig;
//     }
// );

$container->set(
    "logger",
    function () {
        global $basePath;

        // $logger = new Logger("slimmiddle");
        // $fileHandler = new StreamHandler($_SERVER["DOCUMENT_ROOT"].$basePath."/logs/app.log");
        // $logger->pushHandler($fileHandler);

        //日本時間にセット
        date_default_timezone_set('Asia/Tokyo');

        $logger = new Logger('logger');
        $custom_handler = new StreamHandler($_SERVER["DOCUMENT_ROOT"] . $basePath . "/logs/app.log", Logger::INFO);

        // 時間表示のフォーマット設定
        $date_format = 'Y-n-d H:i:s';

        // ログのフォーマットを設定
        $format = '[%datetime%] %level_name%: %message%' . PHP_EOL;

        // 第三引数は「ログ内のインライン改行を有効にするかどうか」の設定
        // 今回は意味は無いが、有効にしておいた方が使いやすいのでtrueに
        $formatter = new LineFormatter($format, $date_format, true);

        $custom_handler->setFormatter($formatter);

        $logger->pushHandler($custom_handler);
        return $logger;
    }
);

//PDOインスタンスを生成する処理
// $container->set(
//     "db",
//     function () {
//         //DB接続情報を表す変数
//         $database = 'from_now';
//         $dbUsername = "staff";
//         $dbPassword = "password";

//         //PDOインスタンスを生成。DB接続
//         $db = new PDO('mysql:host=localhost:3306;dbname=' . $database . ';charset=utf8', $dbUsername, $dbPassword); //MySQLに接続
        
//         //SQLite用
//         // $db = new PDO( 'sqlite:../db/from_now.sqlite3' );

//         //PDOエラー表示モードを例外モードに設定
//         $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//         //プリペアドステートメントを有効に設定
//         $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
//         //フェッチモードをカラム名のみの結果セットに設定
//         $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
//         //PDOインスタンスをリターン
//         return $db;
//     }
// );


//dbサービステスト
// $container->set('db', function (ContainerInterface $c) {
//     $settings = [
//         'driver' => 'mysql',
//         'host' => 'localhost:3306',
//         'dbname' => 'from_now',
//         'username' => 'staff',
//         'password' => 'password',
//         'charset' => 'utf8mb4',
//     ];

//     $dsn = "{$settings['driver']}:host={$settings['host']};dbname={$settings['dbname']};charset={$settings['charset']}";
//     $pdo = new PDO($dsn, $settings['username'], $settings['password']);
   
//     //PDOエラー表示モードを例外モードに設定
//     $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
//     //プリペアドステートメントを有効に設定
//     $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
//     //フェッチモードをカラム名のみの結果セットに設定
//     $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
//     return $pdo;
// });



$folderObj = []; //ディレクトリ格納用オブジェクト
$folderArray = []; //ページディレクトリ配列

//フォルダ構成をセット
$container->set(
    "folderComp",
    function () {
        return globAll('../pages');
    }
);


//検索用メニュー
$container->set(
    "searchMenu",
    function () {
        return globFirst('../pages');
        // return 'テスト';
    }
);





//-------------------//
// 　  ページ用      //
//-----------------//

//サーチ用
$container->set(
    "markHtml",
    function ($c) {
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        $mdArray = $c->get('mdArray');
        
        $word = htmlspecialchars($_REQUEST['word']);
        $cate = '../pages/'.$_REQUEST['cate'];//検索対象カテゴリー
        $case = '';

        $pattern = '/'.$word.'/';

        $Extra = new ParsedownExtra();

        $wordNum = 0;

            foreach($mdArray as $val){

                $dirNonum = preg_replace('/\/\d{3}./','/',$val['dir']).'/';
                $dirNonum = preg_replace('/\.\.\//','',$dirNonum);

                //ページタイトル markdown.mdの先頭にあるpage-titleの値を、$ArrayTitleに格納。
                preg_match("/^\*\[page-title\]:\s*(.+)/", $val['md'], $ArrayTitle);

                if(!empty($ArrayTitle[1])){
                    $title = $ArrayTitle[1];//ページタイトル
                }else{
                    $title = '';
                }


                $html = $Extra->text($val['md']);
                $text = strip_tags($html,"<pre><code>");//<pre><code>は残す

                $getWord = null;
        
                if(preg_match_all($pattern, $text, $getWord)){
        
                    $sumWord = array_unique($getWord[0]);
        
                    foreach ($sumWord as $value) {
                        $patternDiff = '/'.$value.'/';
                        $text = preg_replace($patternDiff, '<mark class="hilight">'.$value.'</mark>', $text);//検索文字にマークを付ける
                    }              
        
                    $htmlData = $htmlData.'<section><h3><a href="'.$dirNonum.'" >'.$title.'</a></h3><div class="search-text">'.$text.'</div></section>';

                    $wordNum++;
                }
            }


            $htmlData = '<p id="search-number">「'.$word.'」の検索結果：<span id="word-num">'.$wordNum.'</span>ページ</p>'.$htmlData;

            $markData = ['html' => $htmlData];

        return $markData;
    }
);


//マークダウン変換
$container->set(
    "mark",
    function ($c) {
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        $basePath = $c->get('basePath');
        $folderObj = $c->get('folderObj');
        $folderName = $c->get('folderName');

        if (!empty($folderObj[$folderName])) {

            $folderPath = $folderObj[$folderName];

            $folderPath1 = str_replace('..', '', $folderPath); //「..」を削除　例)/pages/001.js/001.js_base/002.js_cls_obj_lecture

            $Extra = new ParsedownExtra();

            //マークダウンファイル取得
            $md = file_get_contents($_SERVER["DOCUMENT_ROOT"] . $basePath . '/pages/' . $folderPath . '/markdown.md');

            //ページタイトル取得
            preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
            $title = $ArrayTitle[1]; //ページタイトル

            //HTMLに変換
            $htmlData = $Extra->text($md);

            //画像のパスを変換
            $htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);
            //ファイルリンクのパスを変換
            $htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);

            //sampleのパスを変換
            $htmlData = preg_replace('/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="' . $basePath . $folderPath1 . '/sample/$2" target="_blank">$4</a>', $htmlData);

            //iframeのパスを変換
            $htmlData = preg_replace('/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i', '<iframe$1src="' . $basePath . $folderPath1 . '/sample/$2"$3></iframe>', $htmlData);

            $markArray = ['html' => $htmlData, 'title' => $title];
        } else {
            $markArray = ['html' => 'ページが存在しません。', 'title' => ''];
        }
        return $markArray;
    }
);


//メニュー生成
$container->set(
    "menuComp",
    function ($c) {
        $boxNum = 1;
        $menuData = globMenu('../pages', $c, $boxNum);

        return $menuData;
    }
);


//メニュー生成　管理画面用
$container->set(
    "menuCompAdmin",
    function ($c) {      
        $boxNum = 1;
        $menuData = globMenu('../pages', $c, $boxNum);

        return $menuData;
    }
);



//プレビュー用
$container->set(
    "preview",
    function ($c) {
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        $Extra = new ParsedownExtra();
        $basePath = $c->get('basePath');
        $folderObj = $c->get('folderObj');

        $md = $_REQUEST['report-p']; //記事原文
        $title = $_REQUEST['pagename-p']; //タイトル
        $folderPath = $_REQUEST['folderPath-p']; //パス
        $folderName = $_REQUEST['folder-p']; //フォルダ名

        $folderPath = $folderObj[$folderName];
        $folderPath1 = str_replace('..', '', $folderPath);

        $htmlData = $Extra->text($md);

        //画像のパスを変換
        $htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);
        //ファイルリンクのパスを変換
        $htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="' . $basePath . $folderPath1 . '/upload/$2"$3>', $htmlData);

        //sampleのパスを変換
        $htmlData = preg_replace('/<a(.*)href="sample\/(.*)"(.*)>(.*)<\/a>/i', '<a $1 href="' . $basePath . $folderPath1 . '/sample/$2" target="_blank">$4</a>', $htmlData);

        //iframeのパスを変換
        $htmlData = preg_replace('/<iframe(.*)src="sample\/(.*)"(.*)><\/iframe>/i', '<iframe$1src="' . $basePath . $folderPath1 . '/sample/$2"$3></iframe>', $htmlData);


        $markArray = ['html' => $htmlData, 'title' => $title];

        return $markArray;
    }
);


//ファイルアイコン設定 → サービスに移動
$container->set(
    "fileIcon",
    function () {
        //更新日付順表示
        $sort_by_lastmod = function ($a, $b) {
            return  filemtime($a) - filemtime($b);
        };

        //フォルダ構成をオブジェクトで取得
        // $folderObj = $this->container->get("folderComp");

        $folderObj = fileGlobe();
        $folderDir = $folderObj[$_REQUEST['folder']];
        $totalList = '';

        $files = glob($folderDir . '/upload/*');
        usort($files, $sort_by_lastmod);

        if (empty($files)) {
            $fileList = '';
        } else {
            foreach ($files as $item) {
                $file_name = basename($item); //ファイル名だけを抜き出す
                $fileClass = '';
                $photo = false;

                switch (1) {
                        //エクセル
                    case preg_match('/.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/', $file_name):
                        $fileClass = 'file_icon excel-icon';
                        break;
                        //テキスト
                    case preg_match('/.txt$/', $file_name):
                        $fileClass = 'file_icon text-icon';
                        break;
                        //ワード
                    case preg_match('/.doc$|.docm$|.docx$|.dot$|.dotx$/', $file_name):
                        $fileClass = 'file_icon word-icon';
                        break;
                        //パワーポイント
                    case preg_match('/.pptx$/', $file_name):
                        $fileClass = 'file_icon pptx-icon';
                        break;
                        //zipファイル
                    case preg_match('/.zip$/', $file_name):
                        $fileClass = 'file_icon zip-icon';
                        break;
                        //PDFファイル
                    case preg_match('/.pdf$/', $file_name):
                        $fileClass = 'file_icon pdf-icon';
                        break;
                        //画像
                    case preg_match('/.png$|.PNG$|.jpg$|.jpeg$|.JPG$|.JPEG$|..svg$|.svgz$|.gif$|.webp$/', $file_name):
                        $fileClass = 'file_icon pdf-icon';
                        $photo = true;
                        break;
                }

                if (!$photo == true) {
                    $fileList = '<li class="file-list"><span class="filename ' . $fileClass . '">' . $file_name . '</span><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                } else {
                    $fileList = '<li class="photo-list"><span class="filename">' . $file_name . '</span><img src="' . $folderDir . '/upload/' . $file_name . '" alt=""><button class="fileDelete">削除</button><button class="fileInsert">挿入</button></li>';
                }

                $totalList = $totalList . $fileList;
            }
        }

        // return $fileList;
        return $totalList;
    }
);




//-------------------//
// 　  管理画面用    //
//-----------------//

// //フォルダオブジェクト取得
// $container->set(
//     "folderObjGet",
//     function () {
//         $folderObj = fileGlobe();
//         return $folderObj;
//     }
// );


//対象フォルダを中身ごとまとめて削除
$container->set(
    "del_allfolder",
    function () {
        // global $delFolder;
        $delFolder = $c->get('delFolder');
        //trushにバックアップ
        trush_backup($delFolder);
        //フォルダ中身ごと削除
        remove_directory($delFolder);
        $delAry = explode('/', $delFolder);// 「/」で区切って配列化
        array_pop($delAry);
        $parent = implode('/', $delAry);//例) ../pages
        numberReset($parent);//番号を再設定
    }
);


//pagesバックアップ
$container->set(
    "pages_backup",
    function () {
        copy_pages('../pages');
    }
);



//中のページのフォルダを上の階層に移動する
$container->set(
    "subpage_move",
    function ($c) {
        // global $delFolder;//例)../pages/042.aaa
        $delFolder = $c->get('delFolder');
        $delAry = explode('/', $delFolder);// 「/」で区切って配列化
        $delFd = end($delAry);//例)042.aaa　配列の最後の値を取得
        $num = explode('.', $delFd)[0];//例)042

        array_pop($delAry);//配列の最後の要素（例 042.aaa）を削除
        $parent = implode('/', $delAry);//配列を「/」で結合　例) ../pages

        move_sabpages($delFolder, $delFd, $num, $parent);
    }
);




//-------------------//
// 　  　検索用      //
//-----------------//





//検索セレクトリスト
$container->set(
    "select_list",
    function ($c) {
        return globSearch($c->get('searchFolder'));
    }
);


function globSearch($folder, &$folderArray = [])
{
    $folderObj = [];

    if (!is_file($folder)) {
        $res = glob($folder . '/*');

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {
                $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
                $folderObj[$folderNoNum] = $f; //「〇〇.」ディレクトリをオブジェクトに格納
                $folderArray[] = $f; //ページフォルダのディレクトリを配列に格納

                // 再帰して子ディレクトリを統合
                $folderObj = array_merge($folderObj, globSearch($f, $folderArray));
            }
        }
    }
    
    return $folderObj;
}




//-------------------//
// 　    関 数       //
//-----------------//

function globAll($folder, &$folderArray = [])
{
    $folderObj = [];

    if (!is_file($folder)) {
        $res = glob($folder . '/*');

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {
                $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
                $folderObj[$folderNoNum] = $f; //「〇〇.」ディレクトリをオブジェクトに格納
                $folderArray[] = $f; //ページフォルダのディレクトリを配列に格納

                 // 再帰して子ディレクトリを統合
                $folderObj = array_merge($folderObj, globAll($f, $folderArray));

            }        
        }
    }
    
    return $folderObj;
}


//第一階層のフォルダのみ取得
function globFirst($folder)
{
    $folderFirst = [];

    if (!is_file($folder)) {
        $res = glob($folder . '/*');

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値
            $ArrayTitle = [];

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {

                $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);

                if (file_exists($f . '/markdown.md')) {
                    $md = file_get_contents($f . '/markdown.md'); //マークダウンの内容を変数に格納
                    
                    if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle)) {

                        $listExplode = explode('/', $f);
                        $lastList = end($listExplode);

                        $folderFirst[$folderNoNum] = $lastList;
                    }
                }
            }
        }
    }
    
    return $folderFirst;
}



//メニュー生成関数
function globMenu($folder, $container, &$boxNum)
{
    $basePath = $container->get('basePath');
    $siteName = $container->get('siteName');
    $countIp = $container->get('countIp');
    $folderName = $container->get('folderName');
    $lockData = $container->get('lockData');
    $lockArray = $container->get('lockArray');   

    $menuCode = '';


    if (!is_file($folder)) {
        $res = glob($folder . '/*');

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {

                $path = str_replace('../pages/', '', $f) . '/'; //リストのパス
                $pathRe = preg_replace('/^\d{3}./', '', $path);
                $pathRe = preg_replace('/\/\d{3}./', '/', $pathRe);

                if (file_exists($f . '/markdown.md')) {

                    $md = file_get_contents($f . '/markdown.md'); //マークダウンの内容を変数に格納
                    if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle)) {
                        $title = $ArrayTitle[1];
                    }

                    $lastDir = preg_replace('/^\d{3}./', '', $lastDir);


                    if($countIp==1){//管理者

                        if (array_key_exists($lastDir, $lockData)) {//DBのlock_listにデータ有り
                            //ロックあり
                            if($lockData[$lastDir][0]=='all'){
                                $lockCls = 'all-lock';
                            }else{
                                $lockCls = 'lock';
                            }

                            $menuCode .= sprintf(
                                '<li id="item%d" class="box-item"><a href="%s" class="%s">%s</a>',
                                $boxNum,
                                $basePath . '/public/pages/' . $pathRe,
                                $lockCls,
                                htmlspecialchars($title, ENT_QUOTES)
                            );

                        } else {
                            //ロックなし
                            $menuCode .= sprintf(
                                '<li id="item%d" class="box-item"><a href="%s">%s</a>',
                                $boxNum,
                                $basePath . '/public/pages/' . $pathRe,
                                htmlspecialchars($title, ENT_QUOTES)
                            );
                        }

                    }elseif($folderName=='admin'){//管理画面の場合

                            $menuCode .= sprintf(
                                '<li id="item%d" class="box-item"><a href="%s">%s</a>',
                                $boxNum,
                                $basePath . '/public/pages/' . $pathRe,
                                htmlspecialchars($title, ENT_QUOTES)
                            );
                            
                    }elseif(!array_key_exists($lastDir, $lockArray)){//管理者以外でDBのlock_listのデータとallのデータ配下ディレクトリ以外　メニュー表示
                        if (array_key_exists($lastDir, $lockData)) {//DBのlock_listにデータ有り

                             $menuCode .= sprintf(
                                '<li id="item%d" class="box-item"><a href="%s" class="%s">%s</a>',
                                $boxNum,
                                $basePath . '/public/pages/' . $pathRe,
                                'lock',
                                htmlspecialchars($title, ENT_QUOTES)
                            );
                            
                        }else{

                            $menuCode .= sprintf(
                                '<li id="item%d" class="box-item"><a href="%s">%s</a>',
                                $boxNum,
                                $basePath . '/public/pages/' . $pathRe,
                                htmlspecialchars($title, ENT_QUOTES)
                            );                        }
                    }
                    
                    $boxNum++; // ここで必ずインクリメント
                }

                
                // 子ディレクトリを再帰呼び出し
                $children = globMenu($f, $container, $boxNum);
                if ($children !== '') {
                    $menuCode .= '<ul class="sub-menu">'.$children.'</ul>';
                }

                $menuCode .= "</li>";
            }
        }
        
        return $menuCode;
    }
}




//フォルダ構成再生成
function globAllRe($folder)
{
    $menuArray = json_decode($_POST['list']); //メニューのリスト構成

    //pages_copyの連想配列作成
    $pgCpObj = [];
    $res = glob($folder . '/*');

    foreach ($res as $val) {
        $pgCpArray = explode('/', $val);
        $lastDir = end($pgCpArray); //配列の最後の値
        $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
        $pgCpObj[$folderNoNum] = $val;
    }


    if (!is_file($folder)) {

        foreach ($menuArray as $item) {
            $listExplode = explode('/', $item);
            $lastList = end($listExplode);

            //メニューのフォルダ名を抽出
            list($listNum, $listName) = explode(".", $lastList);

            if (array_key_exists($listName, $pgCpObj) === true) {
                //pages_copyに指定したフォルダが存在する
                try{
                    if (rename($pgCpObj[$listName], '../pages/' . $item)) {
                        //成功
                    } else {
                        throw new Exception("エラーです。。。");
                    }

                }catch(Exception $e){
                    echo $e->getMessage();
                }                    
            }
        }
    }
}



//削除フォルダをtrushにバックアップ
function trush_backup($delFolder) {
    global $dateTime;

    date_default_timezone_set('Asia/Tokyo');//日本時間にセット
    $dateTime = date('Y-m-d_H.i.s');

    mkdir('../trush/'.$dateTime);//削除日時フォルダをtrushフォルダに作成

    $delDir = str_replace('pages', 'trush/'.$dateTime, $delFolder);
    mkdir($delDir);
    copy_directory($delFolder, $dateTime);
}




// 再帰的にディレクトリを削除する関数
function remove_directory($dir) {
    $files = array_diff(scandir($dir), array('.','..'));
    foreach ($files as $file) {
        // ファイルかディレクトリによって処理を分ける
        if (is_dir("$dir/$file")) {
            // 頭に数字のないディレクトリなら再度同じ関数を呼び出す
            remove_directory("$dir/$file");
        } else {
            // ファイルなら削除
            unlink("$dir/$file");
        }
    }
    // 指定したディレクトリを削除→中身が空になって最後に実行される
    return rmdir($dir);
}



//再帰的にディレクトリをtrushにコピーする関数（中のディレクトリも一括して）　テスト
function copy_directory($ptn,$dateTime) {

    // 指定されたディレクトリ内の一覧を取得
    $res = glob($ptn.'/*');

    // 一覧をループ
    foreach ($res as $f) {
        //is_file() を使ってファイルかどうかを判定
        $fcopy = str_replace('pages','trush/'.$dateTime, $f);

        //ファイルか判定
        if (!is_file($f)) {
            if(!file_exists($fcopy)){
                mkdir($fcopy);
            }
            copy_directory($f,$dateTime);
        }else{
            //ファイルの場合、コピー
            copy($f,$fcopy);
        }
    }
}




// 再帰的にディレクトリをtrushに移動する関数 テスト
function move_trush($folder, $copyFolder)
{
    $res = glob($folder . '/*'); //「/」があるディレクトリを配列に格納
    $files = array_diff(scandir($folder), array('.','..'));

    foreach ($res as $f) {
        $dirArray = explode('/', $f); //「/」で分割して配列化
        $lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）

        //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
        if (preg_match('/^\d{3}./', $lastDir)) {

            $path1 = $f;
            $path2 = $copyFolder. $lastDir;

            //ディレクトリ($f)内に〇〇.フォルダがあるか判定
            $res1 = glob($f . '/*');

            $numBool = false;
            foreach ($res1 as $f1) {
                $dirArray1 = explode('/', $f1);
                $lastDir1 = end($dirArray1);
                if (preg_match('/^\d{3}./', $lastDir1)) { //フォルダ名に〇〇.が先頭に付いてるか判定
                    $numBool = true;
                }
            }

            if (!$numBool) {
                //フォルダ内に〇〇.フォルダがない → trushフォルダに移動
                if (file_exists($path1)) {
                    // echo $path1."\n";
                    // echo $path2."\n";
                    if (rename($path1, $path2)) {
                        // echo "OK";
                        move_trush($folder, $copyFolder);
                    } else {
                        // echo "移動エラー";
                    }
                }
            } else {
                //フォルダ内に〇〇.フォルダがある → 再帰処理
                move_trush($f, $copyFolder);
            }
        }
    }
}



//再帰的にpagesをtempにコピーする関数
function copy_pages($ptn) {
    // 指定されたディレクトリ内の一覧を取得
    $res = glob($ptn.'/*');

    // 一覧をループ
    foreach ($res as $f) {
        $fcopy = str_replace('pages','temp', $f);

        //ファイルか判定
        if (!is_file($f)) {
            if(!file_exists($fcopy)){
                mkdir($fcopy);
            }
            copy_pages($f,'temp');
        }else{
            //ファイルの場合、コピー
            copy($f,$fcopy);
        }
    }
}



//中の番号付きのフォルダを上の階層に移動して、番号を再設定。
function move_sabpages($delDir, $delFd, $num, $parent){
    $res = glob($delDir.'/*');
    $subNum = 1;

    foreach ($res as $f) {
        $dirArray = explode('/', $f); //「/」で分割して配列化
        $lastDir = end($dirArray); //配列の最後の値（フォルダ名またはファイル名）例)001.bbb、markdown.md

        //配列の最後の頭の値が数字「〇〇.」の場合
        if (preg_match('/^\d{3}./', $lastDir)) {

            $path1 = $f;
            $path2 = preg_replace('/'.$delFd.'\/\d{3}./', $num.'-'.$subNum.'.', $f);

            //上の階層に移動
            if (rename($path1, $path2)) {
                // echo "OK";
            } else {
                // echo "移動エラー";
            }
        }

        $subNum++;
    }

    //対象フォルダをtrushにバックアップ
    trush_backup($delDir);
    //対象のフォルダを削除
    remove_directory($delDir);
    //フォルダ番号再設定
    numberReset($parent);
}



//フォルダ番号再設定関数
function numberReset($parent){

    $parentAry = glob($parent.'/*');//削除するフォルダの同じ階層のフォルダらを配列化

    $num = 1;

    foreach($parentAry as $val){
        $valAry = explode('/', $val);
        $lastData = end($valAry);

        if (preg_match('/^\d{3}./', $lastData)) {
            $name = explode('.',$lastData)[1];//番号を除いた名前
            $fdNum = $num;//1から順番の数字を格納
            $fdNum = sprintf('%03d', $fdNum);//3桁に変換
            $fdName = $fdNum.'.'.$name;
        
            array_pop($valAry);//最後の配列要素を削除
            array_push($valAry, $fdName);//新しいフォルダ名を追加
            $newDir = implode('/', $valAry);//ディレクトリ作成
            rename($val, $newDir);//フォルダ名を変更（番号部分だけ）
            $num++;
        }
    }  
}




//マークダウン変換
function md2html($md)
{
    $Extra = new ParsedownExtra();
    $html = $Extra->text($md);

    return $html;
}



//pagesフォルダ内のディレクトリを配列に格納 → FolderService getFolderComp()と同じ
function fileGlobe()
{
    return globAll('../pages');
}



//-------------------//
// 　  試作中用      //
//-----------------//


//削除フォルダをtrushにバックアップ テスト
$container->set(
    "del_trush",
    function () {
        global $delFolder;
        global $dateTime;

        $delDir = str_replace('pages', 'trush/'.$dateTime, $delFolder);
        mkdir($delDir);
        copy_directory($delFolder, $dateTime);
    }
);



//並び替え フォルダ移動
$container->set(
    "dir_replace",
    function ($c) {
        dirSortTogether($c);
    }
);


//並び替え フォルダ番号修正
$container->set(
    "dirNum_replace",
    function ($c) {
        dirNumReplace($c);
    }
);


function pathReplace($dir) {
    global $firstPath;
    $path = str_replace($firstPath, '', $dir);
    return $path;
}


//フォルダ番号修正
function dirNumReplace($c){
    
    $menuArray = $c->get('menuArray');
    $folderObj = $c->get('folderObj');
    
    $menuObj = [];

    foreach ($menuArray as $val) {
        $dirArray = explode('/', $val);
        $lastDir = end($dirArray); //配列の最後の値
        $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
        $menuObj[$folderNoNum] = $lastDir;
    }

    foreach($folderObj as $key=>$dir){

        $menuDirAry = explode('/', $menuObj[$key] );
        $menuFdName = end($menuDirAry);//移動後のフォルダ名

        $dirArray1 = explode('/', $dir);
        $pagesFdName = end($dirArray1);//現状のフォルダ名

        if($pagesFdName != $menuFdName){
            $dirArray2 = array_pop($dirArray1);

            array_splice($dirArray1, count($dirArray1)+1, 1, $menuFdName);

            $dirArray2 = implode('/', $dirArray1);

            if(rename($dir, $dirArray2)){
                //成功
            }else{
                //失敗
            }   
        }            
    }   
}



//再帰処理 ディレクトリをまとめて並べ替え
function dirSortTogether($c){

    $folderObj = $c->get('folderObj');
    $sortHistory = $c->get('sortHistory');

    globAll('../pages');

    $pool = Pool::create();

    foreach($sortHistory as $key => $item){

        $pool[] = async(function ()use($folderObj, $sortHistory, $key, $item) {

            if(rename($folderObj[$item['fdName']], $item['afDir'])){
                //成功
                unset($sortHistory[$key]);
            }else{
                //失敗
                sleep(2);
                if(rename($folderObj[$item['fdName']], $item['afDir'])){
                    //成功
                }else{
                    //失敗
                    sleep(2);
                    if(rename($folderObj[$item['fdName']], $item['afDir'])){
                        //成功
                    }else{
                        //失敗
                        echo '失敗（'.$folderObj[$item['fdName']].'→'.$item['afDir'].'）';                       
                    }
                }
            }
        });

        globAll('../pages');
    }

    await($pool);
}




//配下のディレクトリ取得
function globAllDir($folder)
{
    global $folderObj2;
    global $folderArray2;
    global $res_merge2;

    if (!is_file($folder)) {
        $res = glob($folder . '/*');

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {
                $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
                $folderObj2[$folderNoNum] = $f; //「〇〇.」ディレクトリをオブジェクトに格納
                $folderArray2[] = $f; //ページフォルダのディレクトリを配列に格納

                globAllDir($f);
            }
        }
    }
}




//階層の深さで並べ替え
function order($a, $b) {
    $cntA = count(explode('/', $a));
    $cntB = count(explode('/', $b));
    
  if ($cntA===$cntB) {
    return 0;
  } else if ($cntA > $cntB) {
    return 1;
  } else if ($cntA < $cntB) {
    return -1;
  }
}


return [
    'basePath' => '/from_now_slim_01',
    'siteName' => 'from_now_slim',
    
    EditService::class => function (ContainerInterface $c) {
        return new EditService();
    },
    
    CheckIPAddressBefore::class => function (ContainerInterface $c) {
        return new CheckIPAddressBefore(
            $c->get(EditService::class),
            $c
        );
    },
];


AppFactory::setContainer($container);
