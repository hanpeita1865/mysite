Vue.createApp({
  data() {
    return {
      show: true
    };
  }
}).mount('#app');