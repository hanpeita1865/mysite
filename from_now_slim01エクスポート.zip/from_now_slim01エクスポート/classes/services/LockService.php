<?php
namespace SocymSlim\SlimMiddle\Services;

use PDO;
use Exception;

class LockService {
    private $editService;

    public function __construct(EditService $editService) {
        $this->editService = $editService;
    }


    //---------------------
    //   ページロック追加   
    //---------------------
    
    public function addLock(string $folder, string $under_dir): string {
        $db = $this->editService->db();

        $sql = $db->prepare('SELECT * FROM locklist WHERE page = :folder');
        $sql->bindValue(':folder', $folder);
        $sql->execute();
        $lockCnt = $sql->rowCount();

        if ($lockCnt) {
            return 'すでにロックされています。';
        }

        $sql = $db->prepare('INSERT INTO locklist VALUES (NULL, :folder, :under)');
        $sql->bindValue(':folder', $folder);
        $sql->bindValue(':under', $under_dir);

        if ($sql->execute()) {
            return 'ロックを追加しました。';
        } else {
            throw new Exception('ロックの追加に失敗しました。');
        }
    }


    
    //-----------------------
    //   ページロック解除   
    //-----------------------
    
    public function removeLock(string $folder): string {
        $db = $this->editService->db();

        $sql = $db->prepare('SELECT * FROM locklist WHERE page = :folder');
        $sql->bindValue(':folder', $folder);
        $sql->execute();
        $lockCnt = $sql->rowCount();

        if (!$lockCnt) {
            return 'ロックされていません。';
        }

        $sql = $db->prepare('DELETE FROM locklist WHERE page = :folder');
        $sql->bindValue(':folder', $folder);

        if ($sql->execute()) {
            return 'ロックを解除しました。';
        } else {
            throw new Exception('ロック解除に失敗しました。');
        }
    }


    
    //-------------------------------------------------//
    //   locklistテーブルから削除（フォルダ削除時など）   //
    //------------------------------------------------//
    
    public function deleteLockData(string $folder): string {
        $db = $this->editService->db();

        $sql = $db->prepare('SELECT * FROM locklist WHERE page = ?');
        $sql->execute([$folder]);
        $lockCnt = $sql->rowCount();

        if (!$lockCnt) {
            return 'ロックデータは存在しません。';
        }

        $sql = $db->prepare('DELETE FROM locklist WHERE page = ?');
        if ($sql->execute([$folder])) {
            return 'ロックデータを削除しました。';
        } else {
            throw new Exception('ロックデータの削除に失敗しました。');
        }
    }
}