<?php
require_once 'vendor/autoload.php';

// テンプレートファイルがあるディレクトリ（本サンプルではカレントディレクトリ）
//$loader = new Twig_Loader_Filesystem('.');

$loader = new \Twig\Loader\FilesystemLoader('.');

//$twig = new Twig_Environment($loader);

$twig = new \Twig\Environment($loader, [
    'cache' => 'compilation_cache',
]);

$template = $twig->loadTemplate('sample.html.twig');
$data = array(
    'title' => 'sample',
    'message'  => 'My Webpage!',
);
echo $template->render($data);
?>