const elem_box = document.getElementById('menu');
const box_items = document.querySelectorAll('.box-item');
const elem_reset = document.getElementById('reset');
let subMenu = document.querySelectorAll('.sub-menu');
let arrayStart = [];//デフォルトの並び順初期値
let menuJson = [];//メニューJson
let menuStr;//メニュー文字列
let menu_obj = {};//メニューオブジェクト
let list_elm;

//フォルダ構成をメニューに反映（初期表示）
// folder_complist_menu();


//並び順初期値格納
box_items.forEach(function (value) {
	arrayStart.push(value.getAttribute('id'));
});

box_items.forEach(elm => {
	//ボックスをダブルクリックして空のボックスを作成
	elm.addEventListener('dblclick', function (e) {

		let subLen = this.children.length;

		if (elm == e.target) {//2階層以下の複数実行防止

			//サブメニューの空ボックスを作成
			if (subLen == 5) {
				this.insertAdjacentHTML('beforeend', '<ul class="emp-ul sub-menu"></ul>\n');
				obj = this.lastChild;//サブメニューul要素

			} else {
				//サブメニュー開閉
				this.closest('.box-item').classList.toggle('s-close');
			}
		}
	})

	elm.setAttribute('draggable', 'true');

	let href = elm.querySelector('a').getAttribute('href');
	let folderName = href.split('/').slice(-2)[0];

	elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="btn-lock">ロック変更</button>');
	elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="folder-del">削除</button>');
	elm.querySelector('a').insertAdjacentHTML('afterend', '<button class="folder-rename">フォルダ名変更</button>');
	elm.querySelector('a').insertAdjacentHTML('afterend', '<span class="link-name">' + folderName + '</span>');
	elm.querySelector('a').setAttribute('title', 'ダブルクリックするとメニュー名を変更できます。');

	if (elm.children.length > 5) {
		elm.querySelector('a').insertAdjacentHTML('beforeend', '<span class="icon-slide"></span>');
	}

	sortDrop(elm);
});

//ボックス並べ替え
function sortDrop(elm) {
	elm.ondragstart = function (e) {
		e.dataTransfer.setData('text/plain', e.target.id);
	};

	let empBox = 1;

	//ドラッグオーバー
	elm.ondragover = function (e) {
		e.preventDefault();

		if (elm == e.target.parentNode || elm == e.target) {

			if (e.target.classList.contains('emp-ul')) {
				e.stopPropagation(); //イベントを停止する
				e.preventDefault(); //画面遷移を行わない
				e.target.style.border = '4px solid green';
				empBox = e.target;

			} else if (e.target.closest('li').classList.contains('box-item')) {
				let rect = e.target.closest('li').getBoundingClientRect();
				let elm_over = this

				rectOver(e, rect, elm_over);//ボーダー表示

			} else {
				let rect = e.target.getBoundingClientRect();
				let elm_over = e.target;

				rectOver(e, rect, elm_over);//ボーダー表示
			}
		}
	};

	//ドラッグリープ（ボックスから離れる）
	elm.ondragleave = function (e) {
		if (empBox != 1) {
			empBox.removeAttribute('style');
		}

		this.style.borderTop = '';
		this.style.borderBottom = '';
	}

	//ドロップ
	elm.ondrop = function (e) {
		e.preventDefault();

		if (elm == e.target.parentNode || elm == e.target) {//2階層以下の複数実行防止

			let id = e.dataTransfer.getData('text/plain');
			const elm_drag = document.getElementById(id);

			try {
				if (e.target.classList.contains('emp-ul')) {//空のボックスに挿入

					let id = e.dataTransfer.getData('text/plain');
					let dropItem = document.getElementById(id);

					e.target.removeAttribute('style');
					e.preventDefault();

					try {

						e.target.appendChild(dropItem);
						e.target.closest('.box-item').firstElementChild.insertAdjacentHTML('beforeend', '<span class="icon-slide"></span>');

						dropItem.parentNode.classList.remove('emp-ul');
						subEmpDelete();

					} catch (error) {
						console.log('エラー');
						dropItem.parentNode.classList.remove('emp-ul');
						subEmpDelete();
					}

				} else if (this.classList.contains('box-item')) { //並べ替え

					let rect = this.getBoundingClientRect();

					rectDrop(e, e.currentTarget, rect, elm_drag);//挿入位置が上側か下側かを判定
					subEmpDelete();//空になった挿入用ボックス削除
				}

				box_items.forEach(function (t) {
					t.removeAttribute('style');
				});

				document.querySelectorAll('.side-link li a').forEach(e=>{
					let folderName = e.getAttribute('href').split('/').slice(-2)[0];
				})

				// menu_create();//メニューから配列を作成
				// folder_rebuilding(menuStr);//フォルダ再生成、menu_list.phpに保存

			} catch (error) {
				console.log('エラー')
				//ボーダー削除
				box_items.forEach(function (e) {
					e.removeAttribute('style');
				});

				subMenu.forEach(function (e) {
					e.removeAttribute('style');
				})
			}
		}
	};
}


//空になったsubメニューボックス削除
function subEmpDelete() {
	subMenu = document.querySelectorAll('.sub-menu');
	//空のボックスがある。
	subMenu.forEach(function (e) {
		if (e.children.length == 0 && !e.classList.contains('emp-ul')) {
			e.remove();
		}
	});

	//サブメニューない▲アイコン削除
	document.querySelectorAll('a span.icon-slide').forEach(function (e) {
		if (e.closest('.box-item').querySelector('.sub-menu') == null) {
			e.remove();
		}
	});
}

//マウスオーバーの上下ボーダー表示
function rectOver(e, rect, elm_over) {
	if ((e.clientY - rect.top) < (elm_over.clientHeight / 2)) {
		//マウスカーソルの位置が要素の半分より上
		elm_over.style.borderTop = '2px solid blue';
		elm_over.style.borderBottom = '';
	} else {
		//マウスカーソルの位置が要素の半分より下
		elm_over.style.borderTop = '';
		elm_over.style.borderBottom = '2px solid blue';
	}
}


//ドロップ上下判定
function rectDrop(e, t, rect, elm_drag) {
	if ((e.clientY - rect.top) < (rect.height / 2)) {
		//マウスカーソルの位置が要素の半分より上
		t.parentNode.insertBefore(elm_drag, t);
	} else {
		//マウスカーソルの位置が要素の半分より下
		t.parentNode.insertBefore(elm_drag, t.nextElementSibling);
	}
}


//リンク無効化
document.querySelectorAll('a').forEach(elm => {
	elm.addEventListener('click', e => {
		e.preventDefault();
	});
});



//フォルダ新規作成
document.getElementById('create').addEventListener('click', () => {
	const newFolder = prompt('新規にフォルダ名を作成します。');

	//ダイアログ返答が「はい」なら実行
	if (newFolder != null) {

		//メニューから配列を作成
		menu_create();

		//メニューに同じメニュー名がないかチェック（存在すればtrue）
		if(!isKeyExists(menu_obj, newFolder)){
			const formData = new FormData;
			formData.append('post_newFolder', newFolder);//フォルダ名

			fetch('folder_create.php', {//フォルダ新規作成
				method: 'POST',
				body: formData,
			}, { cache: "no-store" })

				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then(data => {
					//通信成功時の処理
					if (data.match(/フォルダを新規作成しました。/)) {
						alert('フォルダを新規作成しました。')

						folder_complist_menu('folder-menu');//menu_list.phpに保存し、メニューに同期する
					}else{
						alert(data)
					}
				})
				.catch((reason) => {
					alert('失敗しましたよ～。')
				});

		}else{
			alert('同じフォルダ名があります。')
		}
	};
});


//オブジェクトのキーに存在チェック関数
function isKeyExists(obj,key){
	return key in obj;
}


//並べ替え関数
function compareFunc(a, b) {
	return a - b;
}


//ロック設定・解除
document.querySelectorAll('.btn-lock').forEach(elm => {
	elm.addEventListener('click', e => {
		if (window.confirm('閲覧ロックの設定を変更していいですか？')) {
			let folderName = e.target.parentNode.children[1].textContent;
			const formData = new FormData;
			formData.append('post_folder', folderName);

			fetch('page_lock.php', {
				method: 'POST',
				body: formData,
			}, { cache: "no-store" })
				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then(data => {
					//通信成功時の処理
					e.target.parentNode.children[0].classList.toggle('lock');
					folder_complist_menu('menu-folder')//menu_list.phpに保存
				})
				.catch((reason) => {
					alert('失敗しました～。')
				});
		};
	});
});


//フォルダ削除
document.querySelectorAll('.folder-del').forEach(elm => {
	elm.addEventListener('click', e => {
		let listName = e.target.parentNode.children[0].textContent;//メニュー名
		let listDir = e.target.parentNode.children[0].getAttribute('href');//パス
		let folderName = listDir.split('/').slice(-2)[0];//フォルダ名

		let answer = window.prompt(listName + '【' + folderName + 'フォルダ】を削除していいですか？（「all」を入力すると、配下のページも削除できます。空白は対象ページのみ削除）', listName+'（'+folderName+'フォルダ）');

		// 入力に応じて条件分岐
		if(answer === 'all'){
			e.target.closest('li').remove();
			alert('「'+listName+'」ページと配下のページを削除しました。');

		}else if(answer === listName+'（'+folderName+'フォルダ）'){
			//子要素を親要素の直後に移動して、親要素自体は削除する
			if(e.target.parentNode.children[5] != null){
				Array.from(e.target.parentNode.children[5].children).forEach(obj=>{
					e.target.parentNode.parentNode.insertBefore(obj, e.target.parentNode.nextSibling);
				});
			}

			e.target.closest('li').remove();
			alert('「'+listName+'」ページを削除しました。');

		}else{ 
			alert('キャンセルしました。');	
		}

		if(answer === 'all' || answer === listName+'（'+folderName+'フォルダ）'){
			//メニューから配列を作成
			menu_create();
			//lockデータベースから削除
			lockdata_delete(folderName)
			//フォルダ再構成、menu_list.phpに保存
			folder_rebuilding(menuStr,'menu-delete');
		}
	})
})

//メニュー名変更
document.querySelectorAll('#menu li a').forEach(elm => {
	elm.addEventListener('dblclick', function (e) {
		let menuName = this.textContent;//例）メニュー名111
		let menuId = this.closest('li').getAttribute('id');
		let folderName = this.getAttribute('href').split('/').slice(-2)[0];//フォルダ名
		let folderDir = this.getAttribute('href');//パス
		let menuReName = prompt('名前を変更して「ok」を押してください', menuName);
	
		if (menuName != menuReName && menuReName != '' && menuReName != null) {

			menu_create();//メニュー配列

			let dirName = menu_obj[folderName];//変更前のディレクトリ
	
			let formData = new FormData;
			formData.append('post_menu', menuName);//変更前メニュー名
			formData.append('post_reName', menuReName);//変更後メニュー名
			formData.append('post_dir', folderDir);//パス
			formData.append('post_dirName', dirName);//パス（番号付き）
	
			fetch('file_rename.php', {
				method: 'POST',
				body: formData,
			}, { cache: "no-store" })
				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response.text();
				})
				.then(data => {
					//通信成功時の処理
					alert(data);
					if (data.match(/変更しました/)) {
						document.getElementById(menuId).firstElementChild.textContent=menuReName;
					}
	
				})
				.catch((reason) => {
					console.log('メニュー名変更に失敗しました。')
				});
	
		} else if (menuReName == '') {
			alert('メニュー名の値が空です');
		}
	
		//e.stopPropagation();
	});
});


//全サブメニュー開閉
document.querySelectorAll('.btn-sub-close').forEach(elm => {
	elm.addEventListener('click', function () {
		document.querySelectorAll('.sub-menu').forEach(e=>{
			// e.classList.toggle('d-none');
			e.closest('.box-item').classList.toggle('s-close');
		});
	});
});

//「▼」アイコンクリックでサブメニューを開閉
document.addEventListener('click', function(e) {
	if(e.target && e.target.className=='icon-slide'){
		e.target.closest('.box-item').classList.toggle('s-close');
	}
});



// // ★メニューを元にフォルダの再生成を実行
// document.querySelector('#btn-execution').addEventListener('click', e=>{
//     menu_create();//メニューから配列を作成
//     folder_rebuilding(menuStr, 'menu-folder');//フォルダ再生成、menu_list.phpに保存
// });

//フォルダの構成をメニューに反映
document.querySelector('#btn-menu-rebuild').addEventListener('click', e=>{
    folder_complist_menu('folder-menu');//menu_list.phpに保存し、メニューに同期する
});


//フォルダ構成をメニューに反映
function folder_complist_menu(folder){

    //フォルダの構成リストを取得
    fetch('folder_complist.php',{cache: "no-store"}) 
    .then((response) => {
        if (!response.ok) {
            throw new Error();
        }
        return response;
    })
    .then(response => response.text())
    .then(data => {

        const parser = new DOMParser();
        const html = parser.parseFromString(data, "text/html");
    
        let num = 1;
        html.querySelectorAll('.box-item').forEach(e=>{
            e.setAttribute('id', 'item'+num);
            num++;
        })
    
        let htmlOuter = html.documentElement.outerHTML;
        let listHtml = htmlOuter.replace('<html><head></head><body>','').replace('</body></html>',''); 
        
        return listHtml;
    })
    .then(listHtml => {

        //「menu_list.php」への保存処理
        let fd = new FormData();
        fd.append('list', listHtml);//メニューを格納  

        fetch('folderlist_save.php', {//menu_list.phpに保存
            method: 'post', 
            body: fd 
        })
            .then(response => response.text())
            .then(data => {
                //フォルダ構成をメニューに同期する処理の時に実行
                if(folder=='folder-menu'){
                    window.location.reload(true);//キャッシュを無視してリロード 
                }
                
            });        
    })
    .catch(() => {
        //エラー
        console.log('エラー')
    }) 
}


//メニューから配列を作成
function menu_create(){
    const menu = document.getElementById('menu');
    let clone_element = menu.cloneNode(true);//メニューをコピー
    let menuArray = [];
    let menuObj = {};

    //コピーメニューからボタン削除
    clone_element.querySelectorAll('button').forEach(e=>{
        e.remove();
    })

    // //コピーメニューから.link-name要素を削除
    clone_element.querySelectorAll('.link-name').forEach(e=>{
        e.remove();
    })

    //コピー要素から属性の削除
    clone_element.querySelectorAll('li').forEach(e=>{
        e.removeAttribute('id');//id属性の削除
        e.removeAttribute('class');//class属性の削除
        e.removeAttribute('draggable');//draggable属性の削除
    })

    let listElm = '#menu > li';
    //コピー要素の頭に番号を付与
    while(clone_element.querySelectorAll(listElm).length != 0){
        let listNum = 1;

        clone_element.querySelectorAll(listElm).forEach((e,i)=>{
            let num = String(listNum).padStart(3, '0');
			//href値の最後尾のフォルダ名を取り出し番号を再設置
            let listName = num + '.' + e.children[0].getAttribute('href').split('/').slice(-2)[0];

            e.children[0].remove();//a要素を削除
			// e.children[0].remove();//link-name要素を削除
            e.insertAdjacentHTML("afterbegin",'<a>'+listName+'</a>');//リスト名を挿入

            if(listNum == e.parentNode.children.length){
                listNum = 1;
            }else{
                listNum++;
            }
        });

        listElm = listElm + '> ul > li';
    }


    const menu_list = clone_element.querySelectorAll('#menu li');

    //コピー要素のメニューフォルダ名を配列に格納
    menu_list.forEach((e)=>{
        let listParent = e.parentNode;
        let menuId = listParent.getAttribute('id');
        let menuTxt = e.children[0].textContent;//例)01.base
		let linkName = menuTxt.split('.')[1];//例)base

        while (menuId !='menu'){
            if(listParent.childNodes[0]!=''){
                menuTxt = listParent.previousElementSibling.textContent +'/'+ menuTxt;
            }

            listParent = listParent.parentNode;
            menuId = listParent.getAttribute('id');               
        }

        menuArray.push(menuTxt)//メニュー配列に追加
        menuObj[linkName] = menuTxt;//メニューオブジェクトに追加
    })

    menuJson = menuArray;//メニュー配列
    menuStr = JSON.stringify(menuJson);//文字列に変換
	menu_obj = menuObj;//メニューオブジェクト

	// console.log(menuJson)
	// console.log(menuStr);
	// console.log(menu_obj)

	//メニューのhref値の番号を再生成
	// document.querySelectorAll('.box-item').forEach(e=>{
	// 	let linkName = e.children[1].textContent;
	// 	e.children[0].setAttribute('href','../'+ menuObj[linkName] + '/')
	// });
}


//フォルダ再生成（フォルダのリスト取得と重複チェックを含む）
function folder_rebuilding(menuStr, check){
    fetch('folder_list.php',{cache: "no-store"}) //フォルダのリストを取得
    .then((response) => {
        if (!response.ok) {
            throw new Error();
        }
        return response;
    })
    .then(response => response.text())
    .then(data => {
        let ul_element = document.createElement('ul');//ul要素を生成
        ul_element.innerHTML = data;//メニューのコピー挿入

        //番号を削除
        list_elm = ul_element.childNodes;//フォルダのリスト
        let listArray = Array.from(list_elm).map(e=>{
            let name = e.textContent.replace(/^\d{3}./,'');
            return name;
        })

        check_folderCreate(list_elm, check)//フォルダのチェック及びフォルダ再生成
    })
    .catch(() => {
        //エラー
    })  
}

//削除したフォルダをゴミ箱(trush)に移動
function folder_trush(){
    fetch('trush.php',{cache: "no-store"})
    .then((response) => {
        if (!response.ok) {
            throw new Error();
        }
        return response;
    })
    .then((data) => {
    
    })
    .catch((reason) => {
        // エラー
    });
}

//フォルダのチェック及びフォルダ再生成
function check_folderCreate(list_elm, check){

    let checkBool = true;//チェック値（初期値）
    let nameArray = [];//フォルダ名を配列に格納
    let overRap = [];//重複してるフォルダを取得
	let message = [];

    //重複フォルダのチェック
    list_elm.forEach(e=>{
        let nameRep = e.textContent.replace(/^\d{3}./,''); 
        if(nameArray.includes(nameRep)){
            //同じフォルダがある
            if(!overRap.includes(nameRep)){
                overRap.push(nameRep);
            }
        }else{
            nameArray.push(nameRep);//フォルダリスト配列  ['test1111', 'test2', ...]
        }
    });

    //フォルダ名に重複があるかチェック
    if(overRap.length!=0){
        let rapText = '';
        overRap.forEach((e,i)=>{
            if(i==0){
                rapText = e;
            }else{
                rapText = rapText + '、' + e;
            }
        });
        // alert(rapText + 'フォルダが複数あります。確認してください。');
		message.push(rapText + 'フォルダが複数あります。確認してください。');
        checkBool = false;
   }

    //メニュー名とフォルダ名が全て一致してるかチェック
    //nameArray～フォルダ名リスト　menuJson～メニューのリスト名
	// console.log(nameArray)
	// console.log(menuJson)

    let menu_list = menuJson.map(e=>{
        return e.split('/').slice(-1)[0];;
    });


    //メニュー → フォルダ 存在チェック
    if(check=='menu-folder'){
		// console.log(nameArray)
		// console.log(menu_obj)
		nameArray.forEach(e=>{
			let hasKey = Object.keys(menu_obj).some(x => x == e);//「e」が「menu_obj」のキーに存在するか判定
			if(!hasKey){
				message.push('メニューの'+e+'はフォルダに存在しません。確認してください。')
				checkBool = false;
			}
		});
    }

    //フォルダ → メニュー 存在チェック
    if(check=='folder-menu'){
        nameArray.forEach(e=>{
            if(!menu_list.includes(e)){
                alert(e+'フォルダはメニューに存在しません。確認してください。');
				message.push(e+'フォルダはメニューに存在しません。確認してください。')
                checkBool = false;
            }
        });
    }


    if(checkBool){

		let firstfdNum = 0;
		let num = 0;

		const backup_elm = document.getElementById('backup-alert');

		backup_elm.classList.remove('d-none');

		//pagesフォルダのバックアップ
		fetch('pages_backup.php', {
			method: 'post', 
		})
		.then((response) => {
			if (!response.ok) {
				throw new Error();
			}
			return response;
		})
		.then(response => response.text())
		.then(data => {
			firstfdNum = Number(data);//第一階層フォルダ数
			backup_elm.classList.add('d-none');
			alert('pages_backupフォルダにバックアップを取りました。')
			// console.log(firstfdNum)
			//メニューとフォルダに問題がなければ実行
			//「pages」から「pages_copy」に同一階層で移動

			//※index.phpでfolderArray(第一階層フォルダ)は取得

			folderArray.forEach((e, index)=>{
				let fd = new FormData();
				fd.append('folder', e);

				fetch('frat_create.php', {//フォルダの再生成を実行 
					method: 'post', 
					body: fd 
				})
				.then((response) => {
					if (!response.ok) {
						throw new Error();
					}
					return response;
				})
				.then(response => response.text())
				.then(data => {
					num++
					// console.log('frat_create.php')
					// console.log('num='+num);
					// console.log('firstfdNum='+firstfdNum)
					//最後のループで実行

					if(num == (firstfdNum - 1)){
						console.log('最後のループ')
						alert('pages_copyに移動しました。')

						let fd = new FormData();
						fd.append('list', menuStr);//メニューを格納
				
						//「pages_copy」から「pages」に移動
						fetch('create.php', {//フォルダの再生成を実行 
							method: 'post', 
							body: fd 
						})
						.then(value=>{
							//「menu_list.php」に保存
							folder_complist_menu('menu-folder')
						})
						.then(()=>{
							//削除ボタンを実行した時
							if(check=='menu-delete'){
								folder_trush();//page_copyに残ったフォルダをtrushフォルダに移動  
								subEmpDelete();//空のul要素と▲アイコン削除
							}else{
								alert('並び替えを確定しました。')
							}
						})
					}
				})
				.catch(() => {
					//エラー
					console.log('エラー')
				})  			
			});

		})
		.catch(() => {
			//エラー
			console.log('エラー')
		})  	


    }else{
		console.log(message)
		let msgHtml ='';

		message.forEach(e=>{
			msgHtml = msgHtml + ' '+ e;
		})
		alert(msgHtml);
	}
}



//フォルダ名変更
document.querySelectorAll('.folder-rename').forEach((elm,i) => {

	elm.addEventListener('click', e => {
		let folderName = e.target.previousSibling.textContent;
		let menuId = e.target.parentNode.getAttribute('id');
		let folderReName = prompt('フォルダ名を変更して「ok」を押すと元には戻せません。）', folderName);

        menu_create();//メニュー配列

        if (folderReName == null || folderName == folderReName) {//キャンセルまたは名前を変えずにokを押した場合

        } else if (folderReName == '') {
            alert('フォルダ名の値が空です');

        } else if(isKeyExists(menu_obj, folderReName)){
            alert('同じフォルダ名があります。')
        } else {

            let dirName = menu_obj[folderName];//変更前のディレクトリ
            let dirReName = dirName.replace(folderName, folderReName);//変更後のディレクトリ

            if(!isKeyExists(menu_obj, folderReName)){
                const formData = new FormData;
                formData.append('post_dir', dirName);
                formData.append('post_redir', dirReName);
    
                fetch('folder_rename.php', {//フォルダ名変更
                    method: 'POST',
                    body: formData,
                }, { cache: "no-store" })
    
                .then((response) => {
                    if (!response.ok) {
                        throw new Error();
                    }
                    return response.text();
                })
                .then((data) => {

					if (data.match(/フォルダ名を変更しました。/)) {
						//locklistテーブルに登録があれば、修正した名前を変更する
						const formData1 = new FormData;
						formData1.append('post_folder', folderName);
						formData1.append('post_reName', folderReName);


						fetch('lockdata_edit.php', {
							method: 'POST',
							body: formData1,
						}, { cache: "no-store" })

						.then((response) => {
							if (!response.ok) {
								throw new Error();
							}
							return response.text();
						})
						.then(data => {
							alert('フォルダ名を変更しました。')
							folder_complist_menu('folder-menu');//menu_list.phpに保存し、メニューに同期する
						})
						.catch((reason) => {
							alert('失敗しました～。')
						});

					}else{
						alert(data)
					}
                })

                .catch((reason) => {
                    alert('失敗しましたよ～。')
                });
            }
        }
    });
});


//lockデータ削除
function lockdata_delete(folderName){
    let listFolder = folderName.split('.')[1];
    //データベースのlocklistテーブルに登録があれば削除する
    const formData = new FormData;
    formData.append('post_delFolder', listFolder);

    fetch('lockdata_del.php', {
        method: 'POST',
        body: formData,
    }, { cache: "no-store" })
        .then((response) => {
            if (!response.ok) {
                throw new Error();
            }
            return response.text();
        })
        .then(data => {
            //通信成功時の処理
            //alert('DBの閲覧不可の登録を削除しました');
        })
        .catch((reason) => {
            alert('失敗しました～。')
        });
}

// //ファイルのコピー
// document.getElementById('btn-file-copy').addEventListener('click', () => {

//     fetch('file_copy.php', {
//         method: 'POST'
//     }, { cache: "no-store" })
//         .then((response) => {
//             if (!response.ok) {
//                 throw new Error();
//             }
//             return response.text();
//         })
//         .then(data => {
// 			alert('コピーしました。')
//         })
//         .catch((reason) => {
//             alert('失敗しました～。')
//         });
// });


//テスト
// document.getElementById('btn-test').addEventListener('click', () => {
// 	console.log('クリック')
// 	// // ダイアログを表示
// 	let answer = window.prompt('削除していいですか？（「all」を入力すると、配下のページも削除できます。空白は対象ページのみ削除）');

// 	// 入力に応じて条件分岐
// 	if(answer === 'all'){
// 		alert('対象のページと配下のページを削除しました。');
// 	}else if(answer === ''){
// 		alert('対象のページのみ削除しました。');
// 	}else{ 
// 		alert('キャンセルしました。');	}
//   })

