<li id="item1" draggable="true"> <a href="<?= $base_path ?>p__base/">共有事項</a></li>
