---
title: コントローラクラスについて
media_order: 'controler_daichi.png,controller_bob.png,controller_bob_james.png'
taxonomy:
    category:
        - docs
---

コントローラクラスを導入すると、ルーティング登録のコールバック関数中に記述した処理コードを別のクラスにまとめることができます。

## コントローラクラスとは

ここまでは、全ての処理をルーティング登録のコールバック関数内に記述してきました。  
記述したコードはあくまでサンプルなので、大した量ではありません。それでも、web.phpは肥大化していきます。  
ましてや、実際のアプリとなると、処理コードの量はサンプルの比ではなく、web.phpに記述しているとメンテナンス性が著しく低下します。  
そこで、コールバック関数内に記述していた処理コードを別のクラスとして独立させ、ルーティング登録とは別に管理できる仕組みがLaravelには備わっています。  
この処理コードを記述したクラスのことを「***コントローラクラス***」と言います。


## 処理1 クラスのコントローラ

前回、ビューの解説で使用した「こんにちは! 大地太郎さん!」を表示させた処理をクラス化してみます。


##### 前回のビューでweb.phpに記述したコード
```
Route::get("/helloBladeWithData", function() {
	$data["name"] = "大地太郎";
	return view("helloWithData", $data);
});
```


##### resources/views/helloWithData.blade.php(前回のテンプレート)
```
<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>データを埋め込んだテンプレート</title>
</head>
	<body>
		<h1>こんにちは! {{$name}}さん!</h1>
	</body>
</html>
```

Laravelでは、コントローラクラスは*app/Http/Controllers*ディレクトリに作成する約束になっているので、このディレクトリ内に*HelloBladeWithDataController.php*ファイルを作成してください。


##### app/Http/Controllers/HelloBladeWithDataController.php
```
<?php
namespace App\Http\Controllers;  //（1）

use App\Http\Controllers\Controller;  //（2）

class HelloBladeWithDataController extends Controller  //（3）
{
	public function __invoke()  //（4）
	{
		$data["name"] = "大地太郎";  //（5）
		return view("helloWithData", $data);  //（5）
	}
}
```



コントローラクラスを作成する場合、先述の通り、

**app/Http/Controllers**

とディレクトリ内に作成する必要があります。それに伴い、クラスの名前空間もこのディレクトリに合わせ、

**\App\Http\Controllers**

とする必要があります。それを記述しているのが（1）です。  
また、必須ではありませんが、このコントローラクラスは、以下のクラスを継承した方が、便利なことが多いです。

**App\Http\Controllers\Controller**


こうすることで、ミドルウェアの登録メソッドである**middleware()**やバリデーションを設定する**validate()メソッド**など、便利なメソッドが使えるようになります。  
便利になるようにControllerクラスを継承する形で記述したのが（3）であり、事前にこのクラスを利用できるようにuse宣言しているのが（2）です。

さて、こうして作成したコントローラクラスに、実際に処理を記述していきます。  
それは、PHPのマジックメソッドである*__invoke()*に記述します。
それが（4）であり、実際の処理が（5）です。  
（5）は前回のコールバック関数内に記述したものと全く同じです。  
なお、__invoke()メソッドとは、PHPオブジェクトを関数のように扱えるメソッドのことです。

以上で、コントローラクラスの作成が完了しました。  
この__invoke()メソッドを利用したコントローラクラスのことを、「***シングルアクションコントローラ***」と言います。


## シングルアクションコントローラのルーティング登録

次に、作成したシングルアクションコントローラクラスをルーティング登録し、実際に表示させます。  
コントローラクラスをルーティング登録するには、下記のコードになります。

##### routes/web.php
```
Route::get("/chap4/helloBladeWithData", "HelloBladeWithDataController");
```

ルート登録メソッドの第2引数に、コールバック関数の代わりにリスト1で作成したコントローラクラスのクラス名文字列を記述するだけです。


<http://localhost/laravelapp/public/chap4/helloBladeWithData>にアクセスすると、以下のように表示されます。  
ビューで作成したのと同じものが表示されており、無事、コントローラクラスで処理が行われたのがわかります。

![](controler_daichi.png)



## 複数処理をまとめたコントローラクラス

前節までで、無事コントローラクラスが利用でき、さらに、それらのコントローラクラスを整理できるようになりました。  
ここからはさらにもう一歩進んで、コントローラクラスに処理をまとめていきます。


### __invoke()を使わないコントローラクラス

ここまでで紹介してきた__invoke()メソッドを利用したコントローラクラスは、1つのコントローラクラスに1つの処理しか記述できません。  
このことから**シングルアクションコントローラ**と命名されています。

それら複数のシングルアクションコントローラクラスを、サブディレクトリを使って整理する方法もいいのですが、クラスというのはもともと複数のメソッドを記述できます。  
なので、コントローラクラスにも複数のメソッドを記述し、サブディレクトリに複数作成していたクラス群を1つのクラスにまとめることができます。


Controllersディレクトリに、以下のChap4Controller.phpを作成してください。


##### app/Http/Controllers/Chap4Controller.php
```
<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class Chap4Controller extends Controller
{
	public function helloDaichi()  // （1）
	{
		$data["name"] = "大地太郎";  // （2）前回と同じ
		return view("helloWithData", $data);  // 〃
	}
	
	public function helloTanaka()  // （3）
	{
		$data["name"] = "田中一郎";  // （4）前回と同じ
		return view("chap3.hello", $data);  // （4）〃
	}
}
```

名前空間の付け方、継承する親クラスについては、これまで紹介してきたコントローラクラスと同じです。  
ここでのポイントは（1）と（3）です。  
**__invoke()**を使わずに、通常のメソッド名同様に、任意のメソッド名を記述できるうえ、処理ごとに複数記述できます。

### コントローラクラス内メソッドのルーティング登録

では、helloDaichi()メソッドとhelloTanaka()メソッドをそれぞれルーティング登録するにはどのように記述すればいいのでしょうか。  
これは、以下のようになります。


##### routes/web.php
```php
Route::get("/chap4/helloDaichi", "Chap4Controller@helloDaichi");  // （1）
Route::get("/chap4/helloTanaka", "Chap4Controller@helloTanaka");  // （2）
```

ルーティング登録メソッドの第2引数の記述を見てください。このような書式になっています。

<p class="tmp"><span>書式</span>ルーティング登録メソッドの第2引数</p>
```
コントローラクラス名@メソッド名
```

これが、複数メソッドが記述されたコントローラクラスのルーティング登録方法です。  
（1）では*helloDaichi()メソッド*を、（2）ではの*helloTanaka()メソッド*を登録しています。


実際に、以下のURLにそれぞれアクセスしてみます。

<http://localhost/laravelapp/public/chap4/helloDaichi>

<http://localhost/laravelapp/public/chap4/helloTanaka>


このように、__invoke()メソッドを使わないコントローラクラスでは、複数のメソッドを記述し、それらをそれぞれルーティング登録することで、
関連した複数の処理を1つのクラス内にまとめることができます。  
この方がメンテナンス性が向上するので、通常、コントローラクラスを作成する場合は、この方法を採用します。



## ルートパラメータ

ルートパラメータはコールバック関数の引数として渡されることを以前紹介しました。  
処理をコントローラクラスに記述するようになった場合、このルートパラメータはどのように記述すればいいのでしょうか。  
実は発想は同じで、コントローラクラス内のメソッドの引数として渡されます。

例えば、以下のルートパラメータを利用したルーティング登録があるとします。

##### routes/web.php
```
Route::get("/chap4/whoAreYou/{name}", "Chap4Controller@whoAreYou");
```

ここで登録したメソッドは、*whoAreYou()*です。
このメソッドでnameパラメータを受け取るには、引数に記述します。  
下記のコードをChap4Controllerクラスに追記してください。


##### app/Http/Controllers/Chap4Controller.php
```
<?php
〜省略〜
class Chap4Controller extends Controller
{
	〜省略〜
	public function whoAreYou($name)  // （1）
	{
		$data["name"] = $name;  // （2）
		return view("chap3.hello", $data);
	}
}
```

（1）でwhoAreYou()メソッドを追記していますが、引数として**$name**が記述されています。  
この$nameにURL上のパラメータが格納されます。  
（2）では渡されたURL上のパラメータをテンプレートに渡すために配列に格納しています。

　実際に、例えば以下のURLにアクセスしてみてください。このURLでは、URL末の「Bob」がルートパラメータにあたります。

<http://localhost/laravelapp/public/chap4/whoAreYou/Bob>
![](controller_bob.png)

なお、このルートパラメータは複数設定できます。例えば、下記のようなコードです。

##### routes/web.php
```
Route::get("/chap4/whoAreYouFull/{nameFirst}/{nameLast}", "Chap4Controller@whoAreYouFull");
```

ここでは、nameFirstとnameLastの2個のルートパラメータが設定されています。  
このルーティングで処理を行う**whoAreYouFull()メソッド**は、例えば以下のようになります。

##### app/Http/Controllers/Chap4Controller.php
```
<?php
〜省略〜
class Chap4Controller extends Controller
{
	〜省略〜
	public function whoAreYouFull($nameFirst, $nameLast)  // (1)
	{
		$data["name"] = $nameFirst." ".$nameLast;
		return view("chap3.hello", $data);
	}
}
```

（1）にもあるように、ルートパラメータと同じ数の引数を記述すれば利用できます。

　実際に、例えば以下のURLにアクセスしてみてください。このURLでは、URL末の「Bob」と「James」がルートパラメータにあたります。

<http://localhost/laravelapp/public/chap4/whoAreYouFull/Bob/James>
![](controller_bob_james.png)









