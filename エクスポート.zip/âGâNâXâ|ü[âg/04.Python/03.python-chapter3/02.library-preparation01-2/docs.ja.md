---
title: 02.日時を扱うモジュール
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    .t-caption {
    	font-size: 1.5rem;
        text-align: center;
        font-weight: bold;
        margin-bottom: .5rem;
    }
    .t-caption + table {margin-top: .5rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: blue;}
    .smp-box {
         margin: 2rem 0 3rem;
    }
   dl dt {
     font-weight: bold;   
    }
    .gray-box {
     	border: 1px solid gray;
        padding: 20px 30px;
        display: inline-block;
    }
    .w-400 {
      	width: 400px;
     }
    .comment {
      font-style: italic;
      color: green;
      font-size: 1rem;
    }
    h3 span {
      border-bottom: 3px solid green;   
    }
    h4 {margin-top: 3rem;}
</style>


<span class="red bold">datetimeモジュール</span> ～ 今日が何月何日か調べたいときなど、日時を扱うのに使います

<p class="tmp"><span>書式1</span>今日の日付を取得</p>

	datetime.date.today()

<p class="inpre"><span>インタプリタ</span>今日の日付を調べる</p>
<pre>
>>> import datetime
>>> datetime.date.today()
datetime.date(2019, 5, 24)<span class="comment">  # 結果</span>
</pre>

※datetimeはモジュール名、dateはクラス名、today()はメソッド名（クラスメソッド名）です。


<p class="tmp"><span>書式2</span>クラスメソッドの呼び出し</p>

	クラス名.メソッド名(引数)

※datetimeモジュールのdatetimeクラスを使うと、日時と時刻を一緒に扱えます。現在の日時を取得するには、datetimeクラスのnowメソッドを使います。


<p class="tmp"><span>書式3</span>現在の日付と時刻を取得</p>
	datetime.datetime.now()

<p class="inpre"><span>インタプリタ</span>現在の日時を調べる</p>
<pre>
>>> datetime.datetime.now()
datetime.datetime(2019, 5, 24, 10, 4, 58, 550696)<span class="comment">  # 結果</span>
</pre>


※最後の550696の単位はマイクロ秒です。<br>
　ここでは、2019年5月24日10時4分58.550696秒を表しています。


<h2 class="h-type2">日時の計算</h2>

datetimeモジュールを使うと、日時の計算もできます。

<p class="tmp"><span>書式4</span>指定した年月日のdateオブジェクトを作成</p>

	datetime.date(年,月,日)

<p class="inpre"><span>インタプリタ</span>お正月(2019.1.1)の日付を表すdateオブジェクトを作成し、変数new_year_dayに代入します</p>
<pre>
>>> new_years_day = datetime.date(2020, 1, 1)
>>> new_years_day
datetime.date(2020, 1, 1) <span class="comment">  # 結果</span>
</pre>

<p class="tmp"><span>書式5</span>日付Bから日付Aまでの日数を求める</p>

	日付A(dateオブジェクト) - 日付B(dateオブジェクト)

<p class="inpre"><span>インタプリタ</span>さきほど作成したnew_years_dayを使って、今日からお正月までの日数を求めます</p>
<pre>
>>> new_years_day - datetime.date.today() 
datetime.timedelta(days=222)<span class="comment">  # お正月まであと222日</span>
</pre>

<h2 class="h-type2">日数のオブジェクトを使う方法</h2>

「明日から14日間有効」のような日数を計算するときは、日数のオブジェクトを使います。<br>
指定した日数を表すtimedeltaオブジェクトは、次のように作成します。

<p class="tmp"><span>書式6</span>指定した日数を表すtimedeltaオブジェクトを作成</p>

	datetime.timedelta(日数)


<p class="inpre"><span>インタプリタ</span>14日間を表すtimedeltaオブジェクトを作ります</p>
<pre>
>>> datetime.timedelta(14)
datetime.timedelta(days=14) 
</pre>

<p class="tmp"><span>書式7</span>ある日付に対して、指定した日数を加算した日付を求める</p>

	日付(dateオブジェクト) + 日数(timedeltaオブジェクト)

<p class="inpre"><span>インタプリタ</span>今日から14日後の日付を求めます</p>
<pre>
>>> datetime.date.today() + datetime.timedelta(14)
datetime.date(2019, 6, 7)  //今日(2019.5.24)から14日後の日付
</pre>



<p class="tmp"><span>書式8</span>ある日付に対して、指定した日数を減算した日付を求める</p>
	日付(dateオブジェクト) - 日数(timedeltaオブジェクト) 

<p class="inpre"><span>インタプリタ</span>今日から100日前の日付を求めてください</p>
<pre>
>>> datetime.date.today() - datetime.timedelta(100)
datetime.date(2019, 2, 13)<span class="comment">  # 今日(2019.5.24)から100日前の日付</span>
</pre>

<p class="inpre"><span>インタプリタ</span>今日から-100日後の日付を求めてください</p>
<pre>
>>> datetime.date.today() + datetime.timedelta(-100)
datetime.date(2019, 2, 13)<span class="comment">  # 今日(2019.5.24)から-100日後の日付(結果は上記の例と同じ)</span>
</pre>













