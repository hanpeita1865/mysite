<?php
$post_dir = $_POST['post_dir'];
$post_redir = $_POST['post_redir'];

//半角英数字記号かを判定
if(preg_match("/^[!-~]+$/", $post_redir) ){
    //フォルダ名変更
    rename('../pages/' . $post_dir, '../pages/' . $post_redir);
    echo 'フォルダ名を変更しました。';
}else{
    echo '半角英数字記号で入力してください。';
}

?>
