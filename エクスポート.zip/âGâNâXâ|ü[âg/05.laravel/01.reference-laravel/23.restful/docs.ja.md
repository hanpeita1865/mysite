---
title: '23. リソースコントローラとRESTful'
media_order: 'restful1.png,rest_index.png,rest_id_2.png,rest_form.png,hello_rest.png'
taxonomy:
    category:
        - docs
---

* [RESTfulとは?](#p1)
* [マイグレーションの作成](#p2)
* [モデルの作成](#p3)
* [シードの作成](#p4)
* [シードの実行](#p5)
* [RESTコントローラの作成](#p6)
* [リソースコントローラについて](#p7)
* [indexおよびshowを作成する](#p8)
* [レコードの追加](#p9)
* [フォームを/hello/restに埋め込む](#p10)
* [RESTfulサービスにするために](#p11)

Webの世界では、「***REST***」と呼ばれるサービスがあります。このRESTに対応した ***（RESTful） サービス***を作成する方法について説明します。

## RESTfulとは? ##{#p1}
Webアプリケーションというのは、ここまで作成してきたように、いくつかのWebペー ジがあり、そこにアクセスをするとアプリケーションの画面が表示され、そこでさまざまな作業などを行うような仕組みになっています。画面には各種の表示やインターフェイスとなるGUI部品が表示され、それらを操作していくわけです。

ところが、Webの世界では、こうした「画面に表示される部分」を持たないものもあります。「Webサービス」と呼ばれるものなどがそれです。これらは、サーバーにアクセスして必要な情報を取得したり、情報を送って保存したりできますが、しかし一般的なWebアプリに見られるような画面表示は持っていません。

こうしたWebサービスは、利用者が自分でWebブラウザからアクセスして利用するのではなく、**他のプログラムがアクセスして利用する**ためのものと考えてよいでしょう。 こうしたWebサービスの分野でよく耳にするのが「***REST***」あるいは「***RESTful***」といった言葉です。


### REpresentational State Transfer
RESTというのは、「REpresentational State Transfer」の略で、分散型システムを構築するための考え方です。インターネットのあちこちにプログラムが分散して存在し、それらが相互にやり取りしながら動くようなシステムを考えたとき、どういう仕組みにしたらいいか、その一つの答えがRESTです。

RESTは、HTTPのメソッド(GETやPOSTなど)を使って決まったルールに従ったアドレスにアクセスすることで、必要な情報を取得したり、情報を保存したりできるようにします。HTTPですから、他のサーバーからアクセスして情報を取り出したりできるのです。

このRESTにもとづいて設計されているプログラムは「RESTful」である、と表現されま す。RESTfulなサービスは、情報の取得や送信など基本的な操作の方法が統一されているため、他のプログラムから簡単にアクセスしてサービスを利用できます。

![](restful1.png?classes=caption "図1　RESTは、HTTPのメソッドを使い、必要な情報をやり取りするための仕組みを提供する")


## マイグレーションの作成 ##{#p2}
では、実際に簡単なサンプルを作成しながらRESTfulサービス開発の手順を説明していくことにしましょう。  
ここでは、ごく簡単なデータベーステーブルを用意し、その情報を取り出したり操作したりするRESTfulサービスに近いものを作成してみます。まずは、サービスで利用するテーブルから作成していきましょう。

これは、マイグレーションファイルを作成して作っていくことにします。まずはマイグレーションファイルを作成しましょう。コマンドプロンプトまたはターミナルでプロ ジェクトのフォルダ(Flaravelapp」フォルダ)内にカレントディレクトリを移動し、以下のようにコマンドを実行します。

<p class="tmp cmd"><span>コマンド1</span>マイグレーションファイルを作成</p>
```
php artisan make:migration create_restdata_table
```
これで、「database」内の「migrations」フォルダ内に、「xxxx_create_restdata_table. php」(xxxxは任意の日時の値)というスクリプトファイルが作成されます。

### マイグレーションファイルの記述
では、作成されたマイグレーションファイルのスクリプトを記述しましょう。  
xxxx_ create_restdata_table.phpを開き、以下のように内容を記述して下さい。

<p class="tmp list"><span>リスト1</span>xxxx_ create_restdata_table.php</p>
```
<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRestdataTable extends Migration
{
   public function up()
   {
       Schema::create('restdata', 
               function (Blueprint $table) {
           $table->increments('id');
           $table->string('message');
           $table->string('url');
           $table->timestamps();
       });
   }

   public function down()
   {
       Schema::dropIfExists('restdata');
   }
}
```

マイグレーションクラスでは、**up**でテーブル生成の処理、**down**でテーブル削除の処理をするのが基本でした。  
テーブルの作成は既に何度か行いましたが、**Schema::create**というメソッドを使って行います。この第2引数に指定したクロージャ内で、$tableのメソッドを呼び出してフィールドを設定していきます。ここでは、以下のような項目を用意しました。

|フィールド項目|内容|
|:--:|--|
|id|プライマリーキーとなるフィールドです。|
|message|メッセージを保管するものです。|
|url|関連するアドレスを保管するものです。|


ごくシンプルですが、これでよいでしょう。この3つの項目に加え、$table ->timestamps(); でcreated_atとupdated_atを追加してあります。  
downメソッドは、いつもの通りSchema::droplfexistsでテーブルを削除するようにし てあります。

### マイグレーションの実行
では、マイグレーションを実行しましょう。以下のようにコマンドプロンプトまたは ターミナルから実行して下さい。

<p class="tmp cmd"><span>コマンド2</span>マイグレーションの実行</p>
```
php artisan migrate
```

## モデルの作成 ##{#p3}
ダミーとしていくつかレコードを用意しておく必要があります。が、シードを作成する前に、モデルを作っておくことにしましょう。 コマンドプロンプトまたはターミナルから以下のコマンドを実行して下さい。

<p class="tmp cmd"><span>コマンド3</span>モデルの作成</p>
```
php artisan make:model Restdata
```

これで、「Restdata.php」というファイルが「app」フォルダ内に作成されます。これが、今回のrestdataテーブルを扱うモデルとなります。

### estdata モデルの記述
では、作成されたRestdata.phpを開き、スクリプトを記述しましょう。以下のように 内容を書き換えて下さい。

<p class="tmp list"><span>リスト2</span>Restdata.php</p>
```
<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Restdata extends Model
{
   protected $table = 'restdata';
   protected $guarded = array('id');
  
   public static $rules = array(
       'message' => 'required',
       'url' => 'required'
   );

   public function getData()
   {
       return $this->id . ':' . $this->mssage 
          . '(' . $this->url . ')';
   }

}
```

ここでは、クラスの最初に「$table」というメンバ変数を用意してあります。これは、テーブル名を指定するためのものです。Eloquentでは、テーブル名はモデル名の複数形になっていますが、今回は「restdata」という単数形複数形がわかりにくい名前なので、ここで は$tableを使って"restdata'テーブルを使うように指定してあります。

※なお、dataの単数形はdatumです。あえて単数形のモデル名というならRestdatumと なるでしょう。


その他は、既に使ったものばかりです。$rulesでバリデーションのルール設定を用意し、getDataで簡単なテキストを出力するようにしておきました。

## シードの作成 ##{#p4}
では、シードを用意しましょう。まずはシーダーファイルを作ります。コマンドプロンプトまたはターミナルから以下のようにコマンドを実行しましょう。

<p class="tmp cmd"><span>コマンド3</span></p>
```
php artisan make:seeder RestdataTableSeeder
```

これで、「database」内の「seeds」フォルダ内に「RestdataTableSeeder.php」というファイルが作成されます。

### RestdataTableSeederの記述
では、作成されたシーダーファイルを記述しましょう。RestdataTableSeeder.phpを開き、以下のように記述しておきましょう。

<p class="tmp list"><span>リスト3</span>RestdataTableSeeder.php</p>
```
<?php
use Illuminate\Database\Seeder;
use App\Restdata;

class RestdataTableSeeder extends Seeder
{
   public function run()
   {
       $param = [
           'message' => 'Google Japan',
           'url' => 'https://www.google.co.jp',
       ];
       $restdata = new Restdata;
       $restdata->fill($param)->save();
       $param = [
           'message' => 'Yahoo Japan',
           'url' => 'https://www.yahoo.co.jp',
       ];
       $restdata = new Restdata;
       $restdata->fill($param)->save();
       $param = [
           'message' => 'MSN Japan',
           'url' => 'http://www.msn.com/ja-jp',
       ];
       $restdata = new Restdata;
       $restdata->fill($param)->save();
   }
}
```

ここでは、ダミーとして3つのレコードを保存するようにしてあります。今回は、DBクラスではなく、先ほど作成したRestdataモデルクラスを使ってレコードを作成しています。

まず、保存する値を連想配列にまとめておき、new Restdataでインスタンスを作成後、 fillで連想配列の値を適用します。そして、saveで保存すれば作業完了です。

### Database Seeder の登録
作成したRestdataTableSeederクラスは、DatabaseSeederに登録をしておかないといけません。では、「seeder」内にある「DatabaseSeeder.php」を開き、以下のように修正して下さい。

<p class="tmp list"><span>リスト4</span>DatabaseSeeder.php</p>
```
<?php
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
   public function run()
   {
       $this->call(RestdataTableSeeder::class);
   }
}
```

これで、シードの実行時にRestdataTableSeederのrunが呼び出され、実行されるようになります。

## シードの実行 ##{#p5}
では、シードを実行しましょう。コマンドプロンプトまたはターミナルから以下のように実行して下さい。

<p class="tmp cmd"><span>コマンド4</span></p>
```
php artisan db:seed
```

RestdataTableSeederのrunが実行され、用意しておいた3つのダミーレコードがテーブルに登録されます。これで、データベース関連の準備は完了です。

## RESTコントローラの作成 ##{#p6}
では、作成されたRestdataモデルを利用したRESTfulサービスを作成しましょう。サービスは、普通のWebアプリと同様、コントローラを作成して作ります。 コマンドプロンプトまたはターミナルから以下のようにコマンドを実行して下さい。

<p class="tmp cmd"><span>コマンド5</span></p>
```
php artisan make:controller RestappController --resource
```
これで、「Http」内の「controllers」フォルダ内に「RestappController.php」というファイルが作成されます。

今回、コントローラを作成する際に「--resource」というオプションを追記しました。 これは、「リソース」としてコントローラにメソッド類を追記しておくためのものです。

<div class="gray-box" markdown="1">
##### リソースについて
「リソース」というのは、CRUD関係の機能一式をセットにして登録し、扱えるように したものです。通常、コントローラでは1つ1つの機能をメソッドとして用意し、その ルート情報を1つずつ記述していきます。が、リソースとしてルート情報を登録すると、 CRUD関連のアクセスがすべて一括して使えるようになります。
ただし、アクセスのアドレスやアクションメソッドは最初から決められた形になりま す。また一式まとめて作成されるため、それらのメソッドは最初から全て作成しておく必要があります。
</div>

## リソースコントローラについて ##{#p7}
さて、作成されたRestappController.phpを見てみましょう。これは、デフォルトでいくつものメソッドが用意されています。全スクリプトを挙げておくと以下のようになる でしょう(コメント類は省略してあります)。

<p class="tmp list"><span>リスト5</span>RestappController.php</p>
```
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RestappController extends Controller
{
   public function index()
   {
       //
   }

   public function create()
   {
       //
   }

   public function store(Request $request)
   {
       //
   }

   public function show($id)
   {
       //
   }

   public function edit($id)
   {
       //
   }

   public function update(Request $request, $id)
   {
       //
   }

   public function destroy($id)
   {
       //
   }
}
```

### リソースのアクション
このリソースコントローラに用意されているメソッド類は、RESTの基本的な操作に合わせて生成されています。用意されているメソッドについて簡単にまとめると以下のようになるでしょう。

|	操作|	メソッド|
|:--:|:--:|
|一覧表示|	index|
|新規作成|	create、 store|
|レコード表示|	show|
|更新処理|	edit、update|
|削除如理|	destroy|

既にCRUDの基本的な処理は作成しましたから、それぞれがどのような処理を用意すればいいか、だいたい想像がつくでしょう。基本的なプログラムの作りは、普通のコントローラと変わりないのです。ただ、メソッド名が最初から指定されている、という違いがあるだけです。

### ルート情報の追記
では、リソースコントローラに用意されている、これらのアクションメソッドのルー ト情報は、どのように用意すればいいのでしょうか。これは、実はとても簡単です。  
web.phpに、以下のような文を追記して下さい。RestappControllerの7つのアクション メソッドが全て、ルート登録されます。

<p class="tmp list"><span>リスト6</span>web.php</p>
```
Route::resource('rest', 'RestappController');
```

これで、/rest 下にCRUD関係のアクセスがまとめて登録されます。  
**Route::resources**は、コントローラを作成する際、 **--resource**オプションを付けて生成された7つのアクションを一括して登録する働きをします。

|	アクション|	メソッド|
|:--:|:--:|
|/コントローラ|	index|
|/コントローラ/create|	create|
|/コントローラ|	store(POST送信)|
|/コントローラ/番号|	show(番号 = ID)|
|/コントローラ/番号/edit|	 edit(番号 = ID)|
|/コントローラ/番号|	update(番号 = ID、PUT/PATCH送信)|
|/コントローラ/番号|	delete(番号 = ID、DELETE送信)|

     
このようなアクセスを行うコントローラ(リソースコントローラ)をLaravelでは 「Resourceful(リソースフル)」である、と表現します。Resourcefulなコントローラでは、 CRUDの基本的なアクセスを一式セットで用意してくれるのです。

## indexおよびshowを作成する ##{#p8}
では、コントローラのアクションメソッドを使ってみましょう。ここでは、レコード データを取得するindexとshowメソッドを用意してみます。

<p class="tmp list"><span>リスト7</span>RestappController.php</p>
```
//use App\Restdata;　を追記

public function index()
{
   $items = Restdata::all();
   return $items->toArray();
}

public function show($id)
{
   $item = Restdata::find($id);
   return $item->toArray();
}
```

メソッドを修正したら、実際にアクセスをしてみましょう。/restにアクセスすると、登録された全レコードがJSON形式によるデータの配列として出力されます。また、/ rest/1というようにID番号をつけてアクセスすると、そのID番号のレコードがJSON形式で出力されます。

![](rest_index.png?classes=caption "図1　/restにアクセスすると、すべてのレコードをJSON形式の配列として出力する。")

![](rest_id_2.png?classes=caption "図2　/rest/2とアクセスすると、id = 2のレコードがJSON形式で表示される。")

### JSON は配列を return する
ここでは、JSONデータを生成するための特別な作業は行っていません。ただ、Restdata:tallで取得したコレクションから、toArrayというメソッドを使って配列の形で レコード情報を取り出し、それをreturnしているだけです。  
実はLaravelでは、アクションメソッドで配列をreturnすると、自動的にその配列デー タをJSON形式に変換して出力してくれるようになっているのです。JSON形式であれば、 外部のサーバーからアクセスして、取得したデータを簡単に処理することができます。

## レコードの追加 ##{#p9}
レコードの追加や更新などは、やはりフォームなどのGUIが必要となります。が、可能であれば、そうしたフォームを他のコントロールなどからでも簡単に組み込んで利用できるようにしておきたいところです。そうすることで、レコード作成もサービスとして開放することができます。

では、サンプルのフォームテンプレートを作成し、それを他のコントローラから読み 込んで利用する、ということをやってみましょう。

### create.blade.phpの作成
まずは、フォームのテンプレートを作成します。これは、「views」内に新たに「rest」と いうフォルダを作成し、その中に配置することにしましょう。フォルダを用意できたら、 「create.blade.php」という名前でファイルを作成して下さい。ソースコードは以下のように記述しておきます。

<p class="tmp list"><span>リスト8</span>create.blade.php</p>
```
<table>
<form action="/rest" method="post">
   {{ csrf_field() }}
   <tr><th>message: </th><td><input type="text" name="message"
       value="{{old('message')}}"></td></tr>
   <tr><th>url: </th><td><input type="text" name="url"
       value="{{old('url')}}"></td></tr>
   <tr><th></th><td><input type="submit" value="send"></td></tr>
</form>
</table>
```

見ればわかるように、フォームだけのテンプレートです。送信先は、/restを指定しておきます。Resourcefulでは、レコードの作成は/rest/createにGETアクセスしてフォームを表示し、/restにPOST送信して作成保存の処理が実行されるようになっています。

### create および store アクションの作成 ###
では、アクションの処理を作成しましょう。RestappController.phpを開き、**create**と**store**アクションメソッドを以下のように修正して下さい。

<p class="tmp list"><span>リスト9</span>RestappController.php</p>
```
public function create()
{
   return view('rest.create');
}

public function store(Request $request)
{
   $restdata = new Restdata;
   $form = $request->all();
   unset($form['_token']);
   $restdata->fill($form)->save();
   return redirect('/rest');
}
```

createアクションでは、先ほど作成したcreate.blade.phpのテンプレートを表示するよ うにしてあります。フォームだけですが、表示そのものは行えます。そしてPOST送信 した先のstoreアクションでは、new Restdataを行い、送信されたフォームの情報をfillで 適用してsaveで保存しています。 これらは、既にやったことですから、改めて説明するまでもないでしょう。

![](rest_form.png?classes=caption "図3　/rest/createにアクセスすると、フォームだけ表示される。")

## フォームを/hello/restに埋め込む ##{#p10}
では、用意できた/rest/createのフォームを他のWebページに埋め込んで使ってみましょう。ここでは、/hello/restというアクションを用意して、ここにフォームを埋め込 んでみます。  
まず、テンプレートを作りましょう。「views」内の「hello」フォルダの中に「rest.blade.php」という名前でファイルを作って下さい。そして以下のように記述します。

<p class="tmp list"><span>リスト10</span>rest.blade.php</p>
```
<html>
<head>
   <title>hello/Rest</title>
   <style>
   body {font-size:16pt; color:#999; margin: 5px; }
   h1 { font-size:50pt; text-align:right; color:#f6f6f6;
       margin:-20px 0px -30px 0px; letter-spacing:-4pt; }
   th {background-color:#999; color:fff; padding:5px 10px; }
   td {border: solid 1px #aaa; color:#999; padding:5px 10px; }
   .content {margin:10px; }
   </style>
</head>
<body>
   <h1>Rest</h1>

   @include('rest.create')
  
</body>
</html>
```
ここでは、ボディ部分に「@include」というディレクティブが書かれています。これは、指定したテンプレートをその部分にインポートして出力するものでした。これにより、他のところにあるテンプレートをこのWebページの中に組み込んで表示することができます。  
続いて、HelloControllerクラスにrestアクションメソッドを追記しましょう。以下のようなものです。

<p class="tmp list"><span>リスト11</span>HelloController.php</p>
```
public function rest(Request $request)
{
   return view('hello.rest');
}
```

単純に、今作成したrest.blade.phpのテンプレートを使ってWebページを表示しているだけのものです。後は、/hello/restのルート情報をweb.phpに以下のように追記するだ けです。

<p class="tmp list"><span>リスト12</span></p>
```
Route::get('hello/rest', 'HelloController@rest');
```

これで一通りできました。では、/hello/restにアクセスしてみて下さい。/rest/create で表示されるフォームがページ内に組み込まれて表示されます。そのまま項目を記入し送信すれば、レコードが保存されます。

![](hello_rest.png?classes=caption "図4　/hello/restにアクセスし、フォーム送信すると、レコードが追加される。")


ここでは新規作成の例を挙げましたが、更新や削除も同様に作成し、他のページなどから利用できるようになるでしょう。


## RESTfulサービスにするために ##{#p11}
ここで利用したLaravelの機能は、正確にはResourcefulであって、RESTfulではありません。では、RESTfulにしていくためには、どのように実装を用意すべきなのでしょうか。

RESTfulでは、CRUDはすべて同じアドレスで、アクセスに使うHTTPメソッドの違いによって処理を分けるのが一般的です。HTTPメソッドのメソッドと、実行されるCRUDの関係を整理すると、以下のようになります。

|HTTP|CRUD|
|:--|:--|
|	GET|	Read。レコードの取得。|
|	POST|	 Create。レコードの新規作成。|
|	PUT|	 Update。レコードの更新。|
|	DELETE|	 Delete。レコードの削除。|

このような形で調整していくことでRESTfulなサービスになっていきます。よく見ると、これらはLaravelのResourcefulにすべて用意されていることに気がつくはずです。 Resourcefulでは、これらの他に、CreateとUpdateのフォームとなる部分を追加しているだけであって、すべて実装すればRESTfulとして機能するようになっているのです (RESTfulなサービスでは、入力のためのフォーム部分は不要ですから)。  
先ほど説明したRerourcefullのアクションを、RESTful対応という点でもう一度整理してみましょう。

##### ■RESTfulに必要なもの #####{.tb-caption .text-left}
|アクション|メソッド|
|:--|:--|
|	/コントローラ|	index|
|	/コントローラ|	 store(POST送信) |
|	/コントローラ/番号|	 show(番号 = ID)。|
|	/コントローラ/番号|	 update(番号 = ID、PUT/PATCH送信)|
|	 /コントローラ/番号|	 delete(番号 = ID、DELETE送信)|





##### ■いらないもの #####{.tb-caption .text-left}

|アクション|メソッド|
|:--|:--|
|	/コントローラ/create|	create(新規作成のフォーム) |
|	/コントローラ/番号/edit|	edit(番号 = ID。更新のフォーム)|

いかがですか。Resourcefulを実装していけば、自然とRESTfulなサービスが完成していくことがよくわかるでしょう。

















