---
title: '12. ページ送り'
taxonomy:
    category:
        - docs
visible: true
---

ページ送り（ページネーション）とは，『一枚のページの内部で長い文章を分割し，切り替えて表示する機能』です．  
機能の実装については，無料のjQueryプラグインを使用しています  
（<a href="http://www.coolwebwindow.com/jquery-plugin/plugins/pagination/index.html" target="_blank">jQueryプラグイン無料配布 ページネーション CoolWebWindow</a>）


<iframe width="100%" height="300" src="//jsfiddle.net/ookiki/s5ayxugz/23/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずはHTMLを見てください．  
"list"クラスを持つDiv要素の中に，"pager"クラスを持つDiv要素と10個のリストがあります．  
このリストが分割し，切り替えて表示する対象となります．

次はJavaScriptを見てください．  
"list"クラスを持つDiv要素に対して，paginationプラグインを呼び出す処理を記述します．  
設定しているオプションについては，後述します．

Resultを見て，結果を確認します．  
"pager"クラスを持つDiv要素に，分割したリストを切り替えるナビゲーションが表示されます．  
ナビゲーションのボタンを押すことで，リストが切り替えて表示されます．

---

## paginationプラグインのオプション

今回設定しているオプションを下記に記述します．

|オプション|説明|
|::|:-----------|
|element|分割して繰り返す要素を指定します．今回は「li」|
|prevText|ページャーの「前」テキストの内容を指定します．今回は「＜」|
|nextText|ページャーの「後」テキストの内容を指定します．今回は「＞」|
|firstText|ページャーの「最初」テキストの内容を指定します．今回は「≪」|
|lastText|ページャーの「最後」テキストの内容を指定します．今回は「≫」|
|ellipsisText|ページャーの「省略」テキストの内容を指定します．今回は「…」|
|viewNum|1ページに表示する数を指定します．今回は「3」|
|pagerNum|ページャーのカウンター（数字）の表示数を指定します．今回は「2」|

オプションを指定しなくても初期設定でページ送り（ページネーション）は動作します．  
環境・仕様に合わせて設定をしてください．
