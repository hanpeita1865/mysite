-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1:3309
-- 生成日時: 2023-07-31 09:33:50
-- サーバのバージョン： 10.4.27-MariaDB
-- PHP のバージョン: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `from_now`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `admin_ip`
--

CREATE TABLE `admin_ip` (
  `id_admin` int(30) NOT NULL,
  `ip_address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- テーブルのデータのダンプ `admin_ip`
--

INSERT INTO `admin_ip` (`id_admin`, `ip_address`) VALUES
(3, '::1');

-- --------------------------------------------------------

--
-- テーブルの構造 `locklist`
--

CREATE TABLE `locklist` (
  `id_lock` int(30) NOT NULL,
  `page` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- テーブルのデータのダンプ `locklist`
--

INSERT INTO `locklist` (`id_lock`, `page`) VALUES
(24, 'p__markdown_exp'),
(25, 'p__test600'),
(44, 'test111'),
(46, 'markdown_exp');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `admin_ip`
--
ALTER TABLE `admin_ip`
  ADD PRIMARY KEY (`id_admin`);

--
-- テーブルのインデックス `locklist`
--
ALTER TABLE `locklist`
  ADD PRIMARY KEY (`id_lock`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `admin_ip`
--
ALTER TABLE `admin_ip`
  MODIFY `id_admin` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- テーブルの AUTO_INCREMENT `locklist`
--
ALTER TABLE `locklist`
  MODIFY `id_lock` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
