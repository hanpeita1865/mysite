*[page-title]:PHP配列


PHP においては「添字配列（キーが非負整数である配列）」と「連想配列（キーが文字列である配列）」の間に違いはなく、配列型は 1 つだけで、 同じ配列で整数のインデックスと文字列のインデックスを同時に使えます。


## 参考サイト 

* [【PHP】array_sliceの使い方。配列を範囲指定して切り取る関数](https://kinocolog.com/php_array_slice/)
* [PHPからJavaScriptへ配列を受け渡す方法を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/37729)
* [【PHP初心者向け】配列関数（array関数）を使って配列操作をスマートに書こう！](https://www.asobou.co.jp/blog/web/php-array)😀
* [【初心者用】PHPの配列の書き方を解説](https://techplay.jp/column/475)



