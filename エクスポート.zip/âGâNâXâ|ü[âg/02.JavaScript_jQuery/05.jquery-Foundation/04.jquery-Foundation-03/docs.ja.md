---
title: '04. メニュー開閉、ドロップダウン、アコーディオン'
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">メニュー開閉（トグルメニュー）</h2>

クリックすることでリストが開閉するトグルメニューのサンプルを説明していきます。  

<iframe width="100%" height="500" src="//jsfiddle.net/07yj14nz/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

HTMLでは開閉ボタンをbutton、開閉メニューをulで準備しています。  

CSSで重要なのは、あらかじめulをdisplay:noneで非表示にしている点です。  

ではJavaScriptのコードを見てみましょう。  
buttonがクリックされた時に、slideToggleメソッドでulの表示・非表示を切り替えています。  
次の処理では、クリックされた要素がbuttonかどうかを判定し、それ以外だった場合（！：否定）はslideUpでメニューを閉じます。  

---

<h2 class="h-type2">ドロップダウンメニュー</h2>

マウスオーバーでリストが開閉するドロップダウンメニューのサンプルを説明していきます。  

<iframe width="100%" height="500" src="//jsfiddle.net/9hnjq2kv/2/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLでは、第1階層#naviのMenu1～Menu4に、それぞれ入れ子にして第2階層メニューulを準備しています。  

CSSで重要なのは、あらかじめ第2階層メニュー#navi ulを非表示にしている点、メニューが展開したときに下のコンテンツが動かないよう固定表示している点です。  

ではJavaScriptのコードを見てみましょう。  
navi直下の子要素liをマウスオーバーした時に、その直下の子要素ulをslideToggle（100ミリ秒）で表示・非表示にしています。  
stopメソッドは現在実行中のアニメーションをすべて中止させるのに使用しています。  

---

<h2 class="h-type2">アコーディオンパネル</h2>

クリックすることで子リストが開閉するアコーディオンパネルのサンプルを説明していきます。  

<iframe width="100%" height="600" src="//jsfiddle.net/0jx4ktdy/1/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

まずHTMLでは、クラスaccordion直下にHTML5, CSS3, JavaScriptの3つのリストがp要素で書かれています。  
それぞれの並びで第2階層のulが書かれています。  

CSSで重要なのは、第2階層のulをdisplay:noneで非表示にしている点、クラスactiveでアイコンが変わるように用意されている点です。  

ではJavaScriptのコードを見てみましょう。  
accordion直下のli要素がクリックされた時の処理は以下のとおりです。
1. その直下のp要素にクラスactiveをオン・オフ。  
2. その直下のul要素をスライドダウン・アップ。
3. その兄弟li要素に対して、p要素のactiveを削除。
4. その兄弟li要素に対して、ul要素をスライドアップ。

クリックされた要素がアコーディオンパネル以外だった場合（！：否定）には以下の処理を行います。  
1. accordionすべてに対して、p要素のactiveを削除。
2. accordionすべてに対して、ul要素をスライドアップ。
