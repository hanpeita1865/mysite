---
title: '04. 日時の表示'
taxonomy:
    category:
        - docs
visible: true
---

<h2 class="h-type2">現在の日時の取得</h2>

まず現在の日時を取得し，表示してみましょう．

<iframe width="100%" height="200" src="//jsfiddle.net/3186tvsw/3/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

結果に日時が表示されました．しかしこのままでは使いづらいので，年月日や時刻を抽出してみましょう．

---

<h2 class="h-type2">年月日の取得</h2>

年月日の取得は，以下のコードで行います．

<iframe width="100%" height="500" src="//jsfiddle.net/3186tvsw/9/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

あらかじめ現日時を取得してから年月日を抽出していきます．  
注意点として，月を取得するとき1月は「0」と扱われるため，「1」を足す必要があります。また曜日は0～6の数値として扱われます．そのため配列を使って数値を曜日に変換しています．配列はあとで出てきますが，今回の場合は，0～6の7個の箱それぞれに日曜日から土曜日という名前を付けたイメージです．

---

<h2 class="h-type2">時刻の取得</h2>

時刻の取得は，以下のコードで行います．

<iframe width="100%" height="400" src="//jsfiddle.net/3186tvsw/11/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

年月日の抽出同様，あらかじめ現日時を取得してから時刻を抽出します．  
最後の.getTime()は特殊で，1970年1月1日午前0時からのミリ秒を取得します．これはどのようなときに使うのか，次に例を載せます．

---

<h2 class="h-type2">日数の計算</h2>

.getTime()は，主にある期間の日数を計算するときに使います．試しに現在から東京オリンピック開催日2020年7月24日までの日数を計算してみましょう．

<iframe width="100%" height="400" src="//jsfiddle.net/3186tvsw/20/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

new Date()は任意の日時を取得するときも使用します．ここでの注意点は前述の通り，月を取得するとき1月は「0」と扱われるため，7月は「6」です．  
ミリ秒は当然足し算・引き算で扱えます．表示する前に，ミリ秒を日単位などに変換するのを忘れないようにしましょう．

---

<h2 class="h-type2">おまけ - 協定世界時の取得 -</h2>

getの後にUTCを付けるだけで協定世界時が取得できます．

<iframe width="100%" height="600" src="//jsfiddle.net/3186tvsw/28/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>