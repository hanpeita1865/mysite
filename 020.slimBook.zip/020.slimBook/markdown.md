*[page-title]:Slim参考書


参考書のダウンロード資材置き場
: C:\xampp\htdocs\template_sample\★php\Slim\slimサンプルダウンロード

各章ごとに作成したファイル
: C:\xampp\htdocs\template_sample\★php\Slim\slim_study\trunk

Git（Slimの参考書サンプル用）フォルダ置き場
: C:\xampp\htdocs\socymfirstgitslim

Git（Slimの参考書サンプル用）
: https://github.com/hanpeita1865/SocymFirstGitSlim

SocymSlimVMフォルダ
: C:\Users\hirao\Workdir\SocymSlimVM6

Slim公式サイト
: https://www.slimframework.com/

PHP文法、構文の参考サイト
: https://atmarkit.itmedia.co.jp/ait/series/1432/

## 補足

ローカル環境開発用（Port: 9812）
: C:\xampp\htdocs\template_sample\★php\Slim\slim_study\trunk\SocymSlimVM6\src

XamppのPort9812のドキュメントルートの設定
: DocumentRoot "C:/xampp/htdocs/template_sample/★php/Slim/slim_study/trunk/SocymSlimVM6/src/public"

### 仮想環境用とHeroku用のデータベース切り替え

containerSetups.phpの18-24行目のDBの接続情報の変数の変更で、仮想環境とHerokuのデータベース接続を切り替えをします。
```
//仮想環境用
$dbDns = "pgsql:dbname=socymslimdb;host=192.168.33.10;port=5432";
$dbUsername = "socymslimdbusr";
$dbPassword = "hogehoge";

//Heroku用
/*$dbDns = "pgsql:dbname=d450al55uv0705;host=ec2-34-230-198-12.compute-1.amazonaws.com;port=5432";
$dbUsername = "tbgovdpvkwhjvz";
$dbPassword = "780a7c565a3c57ff919e9c806bff5f2573e9545a97e3e6f4484e49b05c0a0bbd";*/
```
				
（仮想環境用）
会員情報リスト
: <http://192.168.33.10/showMemberList>

### MySQLデータベース接続設定

![](upload/socymslimdb.png "「socymslimdb」データベース")

![](upload/members.png "「members」テーブル")

<p class="tmp list"><span>リスト</span>containerSetups.php</p>
```
$database='socymslimdb';
$dbUsername = "socymslimdbusr";
$dbPassword = "hogehoge";
$db=new PDO('mysql:host=localhost;dbname='.$database.';charset=utf8',$dbUsername, $dbPassword);
```
フォルダ:（C:\xampp\htdocs\template_sample\★php\Slim\slim_study\trunk\SocymSlimVM6\src）

会員情報登録
: http://localhost:9812/goMemberAdd

会員情報リスト
: http://localhost:9812/showMemberList



