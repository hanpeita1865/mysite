*[page-title]:Vue.js問題


<span class="bold green fz-12">問題１</span>　「Hello World」が表示されるように空欄に当てはまるコードを記入してください。
![](upload/message.png)

<div markdown="1" class="problem">
<label>①
<input type="text" value="" autocomplete="off"></input>
</label>
<label>②
<input type="text" value="" autocomplete="off"></input>
</label>
<label>③
<input type="text" value="" autocomplete="off"></input>
</label>
<label>④
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑤
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑥
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<details><summary>解答</summary>
	① {{message}}　② data()　③ return　④ Vue　⑤ createApp(appdata)　⑥ mount('#app')
</details>


<span class="bold green fz-12">問題2</span>　下記の数字が一秒ごとに1増加するよう空欄に当てはまるコードを記入してください。
![](upload/Counter.png)

<div markdown="1" class="problem">
<label>①
<input type="text" value="" autocomplete="off"></input>
</label>
<label>②
<input type="text" value="" autocomplete="off"></input>
</label>
<label>③
<input type="text" value="" autocomplete="off"></input>
</label>
<label>④
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑤
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑥
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑦
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑧
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑨
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<details><summary>解答</summary>
	① {{counter}}　② data()　③ return　④ mounted()　⑤ setInterval(() ⑥ this.counter++　⑦ Vue　⑧ createApp(Counter)　⑨ mount('#counter')
</details>


<span class="bold green fz-12">問題3</span>　title属性とname属性に値がはいるよう空欄に当てはまるコードを記入してください。
![](upload/v-bind要素.png){.photo-border}
![](upload/v-bind.png)

<div markdown="1" class="problem">
<label>①
<input type="text" value="" autocomplete="off"></input>
</label>
<label>②
<input type="text" value="" autocomplete="off"></input>
</label>
<label>③
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<details><summary>解答</summary>
	① v-bind:title　② v-bind:name　③ new Date().toLocaleString()
</details>


<span class="bold green fz-12">問題4</span>　入力欄に記入した文字が追加ボタンを押すとリストに追加されるように、空欄に当てはまるコードを記入してください。
![](upload/ほしいものリスト.png)
![](upload/v-ifディレクティブ.png)

<div markdown="1" class="problem">
<label>①
<input type="text" value="" autocomplete="off"></input>
</label>
<label>②
<input type="text" value="" autocomplete="off"></input>
</label>
<label>③
<input type="text" value="" autocomplete="off"></input>
</label>
<label>④
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑤
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑥
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑦
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑧
<input type="text" value="" autocomplete="off" size="25"></input>
</label>
</div>

<details><summary>解答</summary>
	① v-for　② item in items　③ v-model　④ v-if="addlist"　⑤ v-on:click="add" または @click="add"　⑥ methods　⑦ add()　⑧ this.items.push(this.addlist)
</details>



<span class="bold green fz-12">問題5</span>　ボタンのコンポーネントを作成するコードを空欄に記入してください。

![](upload/button-counter表示.png)
![](upload/コンポーネントbutton-counter.png)
<div markdown="1" class="problem">
<label>①
<input type="text" value="" autocomplete="off"></input>
</label>
<label>②
<input type="text" value="" autocomplete="off"></input>
</label>
<label>③
<input type="text" value="" autocomplete="off"></input>
</label>
<label>④
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑤
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑥
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<details><summary>解答</summary>
	① Vue.createApp({})　② app　③ component　④ template　⑤ app　⑥ mount
</details>




<span class="bold green fz-12">問題6</span>　fruitsのコンポーネントにデータを引き渡すことができるよう空欄にコードを記入してください。

![](upload/コンポーネントfruits表示.png){.photo-border}
![](upload/コンポーネントfruits.png)
<div markdown="1" class="problem">
<label>①
<input type="text" value="" autocomplete="off"></input>
</label>
<label>②
<input type="text" value="" autocomplete="off"></input>
</label>
<label>③
<input type="text" value="" autocomplete="off"></input>
</label>
<label>④
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑤
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑥
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<details><summary>解答</summary>
	① Vue.createApp　② appdata　③ 'fruits'　④ props: ['item']　⑤ {{item}}　⑥ mount("#app")
</details>


<span class="bold green fz-12">問題7</span>　問題6のコードにリストを繰り返しのディレクティブとinputに入力した値が追加されるよう空欄にコードを記入してください。

![](upload/Fruits_input表示.png){.photo-border}
![](upload/Fruits_input.png)
<div markdown="1" class="problem">
<label>①
<input type="text" value="" autocomplete="off"></input>
</label>
<label>②
<input type="text" value="" autocomplete="off"></input>
</label>
<label>③
<input type="text" value="" autocomplete="off"></input>
</label>
<label>④
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑤
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑥
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑦
<input type="text" value="" autocomplete="off"></input>
</label>
<label>⑧
<input type="text" value="" autocomplete="off"></input>
</label>
</div>

<details><summary>解答</summary>
	① v-for="item in items"　② :text="item"　③ v-model="additem"　④ @click="add"　⑤ methods:　⑥ add()　⑦ this.items.push(this.additem)  <br>
	⑧ props: ['text']
</details>

