update product set name='高級松の実', price=900 where id=1;
