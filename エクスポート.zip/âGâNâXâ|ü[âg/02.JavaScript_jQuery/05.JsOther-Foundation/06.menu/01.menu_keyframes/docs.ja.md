---
title: ★メニュー（keyframes仕様）
taxonomy:
    category:
        - docs
---

## 単純にクリックで表示

toggleClassメソッドを使って、サブボックスにviewクラス設置の切り替えで、表示、非表示を制御しています。
[新規タブ](../../../../sample/jquery/menu_keyframes/menu_click/index.html?target=_blank)
<iframe width="100%" height="300" src="//jsfiddle.net/hirao/psk6onjc/18/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

### フォーカス対応
ボックス内のリンクをクリックか、フォーカスをのせてエンターキーを押すと、サブボックスが表示されます。（前の例のdivにtabIndex="0"の要素では、フォーカスをのせて、エンターキーを押しても、イベントは発生しません。）
[新規タブ](../../../../sample/jquery/menu_keyframes/menu_click_ac/index.html?target=_blank)
<iframe width="100%" height="300" src="//jsfiddle.net/hirao/65raeLwy/5/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## クリックでkeyframes仕様の表示

クリックでの表示にkeyframesを使っています。

<iframe width="100%" height="300" src="//jsfiddle.net/hirao/w5zv4ngd/13/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## マウスオーバーでkeyframes仕様の表示

<iframe width="100%" height="300" src="//jsfiddle.net/hirao/qaum831v/2/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## フォーカスがのるとkeyframes仕様で表示

対象要素にフォーカスがのると、keyframesを使って、サブボックスが表示されます。

<iframe width="100%" height="300" src="//jsfiddle.net/hirao/pugzfrq3/3/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## マウスオーバーとフォーカスの両方に対応（keyframes仕様）

マウスオーバーと、フォーカスをのせるかで、サブボックスが表示されます。

<iframe width="100%" height="300" src="//jsfiddle.net/hirao/6gsyu810/2/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>



## 複数ボックス　マウスオーバーとキーボード操作対応

サブボックスに複数のリンクを設置。  
グローバルナビと同じタイプにしています。aria属性は設定していません。  
ホバーを「.box a」ではなく、親要素の「box」の方に設定するのが、ポイントです。

[新規タブ](../../../../sample/jquery/menu_keyframes/menu_keyframes_ac_child/index.html?target=_blank)（menu_keyframes_ac_child）
<iframe width="100%" height="400" src="//jsfiddle.net/hirao/gm7prfh3/9/embedded/result,html,css,js" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>





