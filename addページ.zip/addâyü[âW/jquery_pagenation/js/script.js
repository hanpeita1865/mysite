let pager = document.getElementById('pager');
console.log(pager);
let pagerLink = pager.getElementsByTagName('span');
console.log(pagerLink);
let pagerLink1 = Array.prototype.slice.call(pagerLink);
console.log(pagerLink1);

console.log(pagerLink1[1]);
