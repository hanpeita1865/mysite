*[page-title]:バリデーション


## ユーザー入力時の問題

ユーザーからの入力は誤りや悪意が含まれる可能性があるため、そのまま利用すると問題が起きます。  
入力内容が正しい形式かを確認し、必要に応じて再入力を求める仕組みを<span class="bold green marker">バリデーション</span>と呼びます。
<div markdown="1" class="flex-center">
![](upload/バリデーションの仕組み図.png)
</div>

### バリデーションとは?

バリデーションは入力情報を検証する仕組みで、Laravelではコントローラーの validate メソッドを使うのが簡単です。  
validate は Controller クラスに組み込まれた ValidateRequests トレイトの機能で、
<p class="tmp"><span>書式</span></p>
```
$this->validate($request, [
    '項目名' => '検証ルール',
    '項目名' => '検証ルール',
]);
```

のように、第1引数にリクエスト、第2引数に「項目名とルールの配列」を渡して実行します。  
これにより、各フォーム項目に対して指定したルールで自動的に検証できます。


## バリデーションを利用する

では、実際にバリデーションの機能を使ってみることにしましょう。  
まずはテンプレートにフォームを用意します。  
「hello」フォルダーのindex.blade.phpを開き、@section('content')ディレクティブを以下のように書き換えましょう。

<p class="tmp list"><span>リスト5-27</span>hello/index.blade.php</p>
```
@section('content')
  <p>{{$msg}}</p>
  <form action="/hello" method="post">
    @csrf
    <div>
      <label style="display:inline-block; width:75px;"
        for="name">name: </label>
      <input type="text" name="name">
    </div>
    <div>
      <label style="display:inline-block; width:75px;"
        for="mail">mail: </label>
      <input type="text" name="mail">
    </div>
    <div>
      <label style="display:inline-block; width:75px;"
        for="age">age: </label>
      <input type="number" name="age">
      <input type="submit" value="send">
    </div>
  </form>
@endsection
```

ここでは、name,mail,ageといった入力フィールドを用意しておきました。  
バリデーションは、さまざまなデータを入力するようなフォームのほうがより利点がわかりやすいので3つのフィールドを用意してあります。

### HelloControllerクラスの修正

では、コントローラー側にバリエーションを利用するアクションを用意しましょう。  
ここでは/helloへのGETとPOSTのアクセスを行うメソッド2つを用意します。HelloControllerクラスを以下のように書き換えてください。

<p class="tmp list"><span>リスト5-28</span>HelloController.php</p>
```
class HelloController extends Controller
{
  
  public function index(Request $request)
  {
    return view('hello.index', 
        ['msg'=>'フォームを入力：']);
  }

  public function post(Request $request)
  {
    $validate_rule = [
      'name' => 'required',
      'mail' => 'email',
      'age' => 'numeric|between:0,150',
    ];
    $request->validate($validate_rule);
    return view('hello.index', 
        ['msg'=>'正しく入力されました！']);
  }

}
```

index メソッドは msg を用意してビューを呼び出すだけで、バリデーションは post メソッドで行います。  
post はフォーム送信時の処理で、動作確認のために web.php のルート設定を確認します。  
以下のように記述してあれば問題ありません。

<p class="tmp list"><span>リスト5-29</span>web.php</p>
```
Route::get('hello', [HelloController::class,'index']);
Route::post('hello', [HelloController::class,'post']);
```

修正後に /hello にアクセスし、フォームを送信します。  
すべて正しく入力されていれば「正しく入力されました!」と表示され、問題がある場合はフォームだけが表示されます。

<div markdown="1" class="d-flex">
![](upload/バリデーションtaro送信.png){.photo-border}
<span class="arrow-right mt-5"></span>
![](upload/正しく送信されました.png){.photo-border}
</div>


## バリデーションの基本処理

post メソッドでは、まずフォームのバリデーションルールを配列でまとめます。
```
$validate_rule = [
    'name' => 'required',
    'mail' => 'email',
    'age' => 'numeric|between:0,150',
];
```

* 配列の形式は '<span class="red">項目名' => 'ルール</span>'
* ルールは複数指定でき、<span class="bold red">| </span>でつなぐ  
例：'age' => 'numeric|between:0,150' は「数値で、0〜150の範囲」という意味

これにより、各フォーム項目に対して入力内容を自動的に検証できます。


### バリデーションの実行

実際のバリデーションは $request->validate($validate_rule) で行います。

* $request オブジェクトに用意されている validate メソッドを使う
* 引数に検証ルールの配列 $validate_rule を渡すだけでチェック可能  
その後、return view でビューと必要な変数を返せば処理は完了です。

<div markdown="1" class="memo-box">
##### バリデーションの結果の反映

ここでの処理を見て、「バリデーションの結果がどのように処理に反映されているのだろう?」と疑問を持った人もいることでしょう。  
ここでは、ただvalidate メソッドを呼び出しているだけです。例えば、その結果を受け取って、それによって条件分岐で処理を行ったり、ということはありません。一体、どうやってエラーかどうでないかをチェックして処理を行っているのでしょうか。

実をいえば、これはLaravelのバリデーション機能が自動的に行っているのです。validateを実行し、問題がなければそのまま続きの処理を行っていきます。が、validate 時に問題が発生すると例外が発生し、その場でフォームページを表示するレスポンスが生成されてクライアントに返送されます。したがって、その後に用意された処理は実行されず、フォームが再
表示されるのです。
</div>


## エラーメッセージと値の保持

バリデーションが機能しても実用には、

1. エラーがある場合にメッセージを表示する
2. 再入力時に前回の値をフォームに保持する

の2点が必要です。これらはテンプレートの修正だけで対応でき、index.blade.php の @section('content') を修正します。

<p class="tmp list"><span>リスト5-30</span>hello/index.blade.php</p>
```
@section('content')
  <p>{{$msg}}</p>
  @if (count($errors) > 0)
    <div>
      <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
      </ul>
    </div>
   @endif
  <form action="/hello" method="post">
    @csrf
    <div>
      <label style="display:inline-block; width:75px;
        for="name"">name</label>
      <input style="display:inline-block" 
        type="text" name="name" value="{{old('name')}}">
    </div>
    <div>
      <label style="display:inline-block; width:75px;"
        for="mail">mail</label>
      <input style="display:inline-block"
        type="text" name="mail" value="{{old('mail')}}">
    </div>
    <div>
      <label style="display:inline-block; width:75px;"
        for="age">age</label>
      <input style="display:inline-block"
        type="number" name="age" value="{{old('age')}}">
      <button type="submit">
        send</button>
    </div>
  </form>
@endsection
```
修正後に /hello にアクセスしてフォームを送信すると、入力ミスがある場合はフォーム上にエラーメッセージが表示され、前回の入力値も保持されます。  
メッセージは英語ですが、エラー内容をすべて表示できることは確認できます。

<div markdown="1" class="d-flex">
![](upload/hogeバリデーション.png){.photo-border}
<span class="arrow-right mt-5"></span>
![](upload/hogeバリデーション結果.png){.photo-border}
</div>

### エラーメッセージ表示の仕組み

* バリデーションで発生したエラーは $errors という変数に自動で格納されます。
* $errors の要素数を count($errors) で確認し、0より大きければ表示します。
* エラーメッセージは $errors->all() で配列として取り出せるので、@foreach で順に表示します。
* コントローラー側で $errors に値を設定する必要はなく、validate を呼ぶだけで自動的に管理されます。


### 前回送信した値

フォームの前回入力値を表示するには、`<input>` の value に <span class="bold green">old('項目名')</span> を設定します。  
例えば value="{{ old('name') }}" とすると、name フィールドの前回送信値が表示されます。  
この処理はテンプレートだけで行え、コントローラー側での作業は不要です。


## フィールドごとにエラーを表示

まとめてエラーメッセージを表示するのはこれでできましたが、やはりそれぞれのフィールドごとに、そのフィールドで発生したエラーメッセージを表示したほうがよりわかりやすいでしょう。  
これもやってみましょう。  
index.blade.phpの@section('content')ディレクティブを以下のように修正してください。

<p class="tmp list"><span>リスト5-31</span>hello/index.blade.php</p>
```
@section('content')
  <p>{{$msg}}</p>
  <form action="/hello" method="post">
    @csrf
    <div>
      <label style="display:inline-block; width:75px;
        for="name"">name</label>
      <input style="display:inline-block" type="text"
        name="name" value="{{old('name')}}">
      @if ($errors->has('name'))
        <p style="font-size:10pt; margin-top:0px;">
          ERROR:{{$errors->first('name')}}</p>
      @endif
    </div>
    <div>
      <label style="display:inline-block; width:75px;"
        for="mail">mail</label>
      <input style="display:inline-block" type="text"
        name="mail" value="{{old('mail')}}">
      @error('mail')
        <p style="font-size:10pt; margin-top:0px;">
          ERROR:{{$errors->first('mail')}}</p>
      @enderror
    </div>
    <div>
      <label style="display:inline-block; width:75px;"
        for="age">age</label>
      <input style="display:inline-block" type="number"
        name="age" value="{{old('age')}}">
      @error('age')
        <p style="font-size:10pt; margin-top:0px;">
          ERROR:{{$errors->first('age')}}</p>
      @enderror
      <button type="submit">
        send</button>
    </div>
  </form>
@endsection
```
修正ができたら、/helloからフォームを送信してみましょう。問題があると、そのフィールドの下にエラーメッセージが表示されるようになります。
![](upload/フィールドの下にエラーメッセージ.png){.photo-border}

### エラーのチェック

エラーメッセージは、次のコードで有無を確認します。 
```
$errors->has('項目名')
```

次のコードでは、最初のメッセージを取得して表示できます。  
```
$errors->first('項目名')
```

さらに簡単な方法として以下を使うと、該当フィールドにエラーがある場合のみ中の内容を表示できます。 
```
@error('項目名') ... @enderror ディレクティブ
```
@error はバリデーション専用で、簡単にフィールドごとのエラー表示が可能です。


### エラーメッセージの取得

エラーが発生した場合は、$errors->first('name')という値を出力しています。  
firstというメソッドは、指定した項目の最初のエラーメッセージを取得するためのもので、以下のように呼び出します。
```
$errors->first( 項目名)
```
これで、エラーメッセージが取得されます。first('name')とすれば、name="name"の`<input>`で発生したエラーメッセージが文字列で得られる、というわけです。


### first & get

$errors->first('項目名') は最初の1つのエラーメッセージだけを取得します。  
複数のエラーがある場合は $errors->get('項目名') を使うと、配列で全てのメッセージを取得できます。  
$errors->all() は全項目のすべてのエラーメッセージをまとめて取得できます。  

これにより、エラーメッセージ取得には「all」 「first」 「get」の3つの方法があることがわかります。

<table>
	<tbody>
		<tr>
			<th>all</th>
			<td>すべてのエラーメッセージを配列で取得</td>
		</tr>
		<tr>
			<th>first</th>
			<td>指定した項目の最初のエラーメッセージを文字列で取得</td>
		</tr>
		<tr>
			<th>get</th>
			<td>指定した項目のエラーメッセージすべてを配列で取得</td>
		</tr>
	</tbody>
</table>

この3つがわかれば、かなり柔軟にエラーメッセージを取り出し処理していくことができるでしょう。


## バリデーションの検証ルール

バリデーションの基本的な使い方はこれでわかりました。後は、具体的にどのような検証ルールが用意されているか、でしょう。  
では、Laravelに用意されている主な検証ルールについてまとめましょう。


<div markdown="1" class="td-first">
検証ルール | 内容 |
-------- | --------
accept    | チェックボックスの値が true、on、yes、1 のいずれかであるかを確認し、チェックされていれば有効、されていなければ無効と判断するルールです。
active_url<br>url     | active_url は指定ドメインが実際に有効かをDNSで確認し、url は書式がURL形式かどうかだけを確認します。
after:日付<br>after_or_equal:f     | after は指定日より後、after_or_equal は指定日と同日または後かをチェックします。日付文字列や他のフィールド名を指定して利用できます。    
before:日付<br>before_or_equal:日付     | before は指定日より前、before_or_equal は指定日と同日または前かをチェックします。日付指定方法は after と同じです。    
alpha<br>alpha-dash<br>alpha-num     | alpha は英字のみ、alpha-dash は英字・ハイフン・アンダースコア、alpha-num は英字と数字のみかをチェックします。   
array     | フィールドが配列となっているかどうかをチェックします。   
between:最小値,最大値     | 数値が指定範囲内かを確認し、後に最小値と最大値をカンマ区切りで指定します。     
boolean     | 値が真偽値かどうかをチェックします。true、false、0、1といった値であればOKです。それ以外の値は不可となります。    
date    | 入力されたテキストが日時の値として扱えるものかどうかをチェックします。これは、strtotime関数でタイムスタンプに変換できればOKです。   
date_format: フォーマット    | 入力された値が指定フォーマットの定義に一致しているかどうかをチェックします。フォーマットに沿った形式ならばOKです。    
different: フィールド<br>same:フィールド     | 指定されたフィールドと同じ値かどうかをチェックします。differentは、異なる値であればOKです。sameは反対に、同じ値ならばOKです。    
digits:桁数<br>digits_between:最小桁数,最大桁数     | digits は指定桁数、digits_between は最小～最大桁数の範囲内かを数値でチェックします。
distinct     | 配列として用意されている項目で使います。配列内に同じ値がないかチェックします。もし同じ値が複数あったなら不可となります。  
exists:テーブル,カラム     | 指定データベースの特定カラムに入力値が存在するかを確認し、あればOK、なければ不可とします。     
filled    | その項目が空でない(何か入力されている)かチェックするものです。未入力の場合は不可です。     
required     | それが必須項目であることを示します。入力されていればOKです。     
image     | 指定ファイルが画像かどうかをチェックします。  
in:値1,値2,･･･<brr>not_in:値1,値2,・・・     | inは、入力された値が、in:以降に用意した値に含まれているかチェックします。含まれていればOKです。not_inは逆で、含まれていなければOKです。     
integer     | 値が整数であることをチェックします。   
numeric     | 値が数値であることをチェックします。   
ip<br>ipv4<br>ipv6     | ip はIPアドレスかをチェックし、ipv4 と ipv6 はそれぞれIPv4・IPv6かを確認します。    
json     | 値がJSON形式の文字列かどうかをチェックします。    
min:値<br>max:値     | min は指定値以上、max は指定値以下かを確認し、両方を確認する場合は between を使います。   
regix: バターン     | 指定した正規表現に一致すればOK、一致しなければ不可です。     
size:値     | 値の大きさをチェックします。文字列ならば文字数、数値の場合は整数値、配列の場合は要素の数をチェックし、指定の値と同じならばOKとします。
string     | 文字列の値かどうかをチェックします。     
unique: テーブル,カラム     | データベース利用の際に使用します。指定テーブルの特定カラムに同じ値が存在しないかをチェックします。   
bail     | 複数のバリデーションルールが2つの項目に適用されているとき、バリデーションエラーが発生したら残りのバリデーションルールの適用を中断します。     
confirmed     | その項目が「項目名_confirmation」という名前の項目と同じ値であるかチェックします。例えば、「passwd」という項目にconfirmedを設定したら、「passwd_confirmation」という項目と同じ値かどうかをチェックします。パスワードなど、同じ値を二重に入力する場合のチェックに用いられます。  
dimensions:設定内容     | イメージファイルなどを設定する場合に用いるものです。対象ファイルの内容が設定内容に合致するかどうかを示します。設定内容は、以下の項目に値を設定したものになります。   
（dimensions）<br>min_width. max_width    | 最小幅、最大幅    
（dimensions）<br>min_height. max_height     | 最小高さ、最大高さ     
（dimensions）<br>width, height     | 横幅、高さ    
（dimensions）<br>_ratio     | 縦横比<br>例えば「横幅が50以上500以下」と設定したい場合は、「min_width=50.max_width=500」という値をdimensionsに設定します。
file     | type='file"などで用いるもので、値がアップロードに成功したファイルであることを確認します。   
gt:項目<br>gte:項目<br>It:項目<br>Ite:項目     | 指定した項目と値を比較するためのものです。これらは、それぞれ「gt→>」 「gte→>=」 「It→`<`」 「lte→ `<=` 」というように比較演算子の記号に置き換えて考えるとわかりやすいでしょう。例えば、「gt:A」とすれば、項目Aより大きいかどうかをチェックします。<br>比較する2つの項目は同じタイプの入力項目である必要があります。種類が異なっていると正しく比較できないので注意してください。     
mimetypes: タイプ名<br>mimes:タイプ名    | type='file"などファイルを指定する項目で、その項目のMIMEタイプをチェックするものです。mimietypeは、'image/jpeg"といった形でタイプを指定し、mimesはjpeg"とタイプを指定します。いずれも、カンマを使って複数の値を指定できます。    
nullable     | nullが可能かどうか(必須項目ではないか)をチェックします。実際に値がnullかどうかではなく、「nullを許可しているか」を調べるものです。     
password     | Laravelのユーザー認証機能を利用している場合に使えます。これは、認証されている利用者のパスワードと一致するかどうかをチェックするものです。  
present     | この項目の値が存在することをチェックするものです。存在していれば、値はnullでも問題ありません。  
required<br>required_if:項目,値<br>required_unless:項目,値<br>required_with:項目<br>required_with_all:項目,項目,<br>required_without:項目値<br>required_without_all:<br>項目,項目, ……    | 必須項目に関する設定です。requiredは、必須項目である(値が用意されている)ことをチェックするものですが、そのバリエーションがこれだけ用意されています。     
* required     | 必須項目である    
* required_i     | 指定した他の項目が指定の値と一致するとき必須項目    
* required_unless     | 指定した他の項目が指定の値が存在しないとき必須項目  
* required_with     | 指定した他の項目の値が存在するとき必須項目    
* required_with_all     | 指定したすべての項目の値が存在するとき必須項目
* required_without     | 指定した他の項目の値が存在しないとき必須項目   
* required_without_all     | 指定したすべての項目の値が存在しないとき必須項目    
starts_with:値<br>ends_with:値     | 項目の値が、指定の値で始まるかどうか、あるいは終わるかどうかをチェックするためのものです。     
same:項目     | この項目の値が、指定の項目の値と一致するかどうかをチェックします。    


</div>

～記入途中～