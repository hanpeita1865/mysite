*[page-title]:イベント

## テキスト、画像、リンクの挿入方法

```
// クリックやエンターを押したり、入力すると実行される。
editor.model.document.on( 'change', () => {
 } );
```

```
// データの変更のみ
editor.model.document.on( 'change:data', () => {
} );
```

```
// クリックした位置に「foo」が挿入される
editor.model.document.on( 'change', () => {
	editor.model.change( writer => {
		writer.insertText( 'foo', editor.model.document.selection.getFirstPosition() );
	} );
} );
```

```
//ボタンをクリックでテキストを挿入
document.getElementById('insert').addEventListener('click', function () {
	let imgCode = 'テキスト';
	editor.model.change(writer => {
		writer.insertText(imgCode, editor.model.document.selection.getFirstPosition());
	});
}, false);
```

画像挿入
: https://ckeditor.com/docs/ckeditor5/latest/api/module_image_image_insertimagecommand-InsertImageCommand.html

```
//ボタンをクリックで画像を挿入
document.getElementById('insert').addEventListener('click', function () {
	editor.execute( 'insertImage', { source: 'http://localhost:9840/sugu_cms/sugu_webdir/1/s_0-09.png' } );
}, false);
```

```
//ボタンをクリックで複数の画像を挿入
editor.execute( 'insertImage', {
	source:  [
		'path/to/image.jpg',
		'path/to/other-image.jpg'
	]
} );
```
挿入結果 →「Flex」か「Grid」 で囲めば横並びにできそう。
```
<figure class="image">
		<img src="path/to/image.jpg">
</figure>
<figure class="image">
		<img src="path/to/image.jpg">
</figure>
```

```
editor.execute( 'insertImage', {
	source:  [
		{ src: 'path/to/image.jpg', alt: 'First alt text' },
		{ src: 'path/to/other-image.jpg', alt: 'Second alt text', customAttribute: 'My attribute value' }
	]
} );
```
挿入結果 →altが設置される。「customAttribute」はよくわからない。
```
<figure class="image">
    <img src="https://placeimg.com/640/480/any" alt="First alt text">
</figure>
<figure class="image">
    <img src="https://placeimg.com/640/480/any" alt="Second alt text">
</figure>
```

### 選択

[DocumentSelection](https://ckeditor.com/docs/ckeditor5/latest/api/module_engine_model_documentselection-DocumentSelection.html)

* <span class="green bold">getFirstPosition()</span>　～選択範囲の最初の位置を返します。 最初の位置は、選択範囲内の他のどの位置よりも前の位置です。
* <span class="green bold">getFirstRange()</span>　～選択範囲の最初の範囲のコピーを返します。 最初の範囲は、開始位置が他のすべての範囲の開始位置の前にあるものです (選択に追加された最初の範囲と混同しないでください)。
* <span class="green bold">getLastPosition() </span>～選択範囲の最後の位置を返します。 最後の位置は、選択範囲内の他の位置の後の位置です。
