## Özel Yan Bar

Üretkenliğinizi artırmak için ihtiyacınız olan her şeyi içeren özel bir Kenar Çubuğu.

| Tek Klasör                                          | Çok Köklü Çalışma Alanı                                        |
| --------------------------------------------------- | -------------------------------------------------------------- |
| ![Kenar Çubuğu](../images/printscreen-activity-bar.png) | ![Kenar Çubuğu](../images/printscreen-activity-bar-multi-root.png) |
