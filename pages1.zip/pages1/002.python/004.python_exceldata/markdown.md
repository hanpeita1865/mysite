*[page-title]:Excelからデータを抽出

参考サイト
: [意外と簡単！Pythonで複数エクセルからデータを抽出＆集計して効率化](https://code-fam.com/business_programming/excel_data_extraction/)

ファイル置き場
: C:\Users\y-hir\PythonShizai\ExcelData

## 大まかな流れ

1. フォルダからエクセルファイルだけを見つけ出して読み込む
2. エクセルから必要なデータを取得する
3. 集めたデータを集計する

![](upload/image1.png)


## 準備

### 使用するライブラリ
今回は以下のライブラリを使用します。

* glob 標準ライブラリ ･･･ フォルダから必要なファイルを取得するのに使用
* openpyxl 外部ライブラリ ･･･ エクセルファイルを操作するのに使用
* pandas 外部ライブラリ ･･･ データ集計に使用

外部ライブラリのインストール
: 使用する外部ライブラリの、pipでのインストール方法も載せておきます。<br>
インストールがまだの方は、下記コマンドでインストールをしてください。

<p class="tmp cmd"><span>コマンド</span></p>
```
pip install openpyxl
pip install pandas
```


<p class="result"><span>インストール実行結果</span></p>
![](upload/外部ライブラリーインストール結果.png "図　openpyxlと pandasのインストール結果")


## Pythonファイルの新規作成（Jupyter notebook）

使用するエクセルファイルの格納場所
: C:\Users\y-hir\PythonShizai\ExcelData

※今回は、Jupyter notebook (ジュピターノートブック) を使って実装していきます。

参考サイト
: [Jupyter Notebookの使い方](https://www.javadrive.jp/python/jupyter-notebook/)

エクセルと同じフォルダに Jupyter notebook のファイルを作ります。  
ExcelData.ipynb というファイル名にしていますが自由に付けてもらって構いません。

### Jupyter notebook 起動

Anacondaを起動し、Jupyter notebook を開きます。

[New] から Python3 の Notebook を新規作成します。
![](upload/Jupyternotebook起動新規作成.png)

### エクセルからデータを抽出する
Pythonを使ってエクセルからデータを抽出する方法を説明します。

先ほどの全体図の ② の前半部分に当たります。
![](upload/image-9-768x294.png)

#### openpyxl のインポート
エクセルファイルの読み込みにopenpyxlというライブラリを使用するため、最初にインポートします。

<p class="tmp list"><span>リスト1-1</span></p>
```
import openpyxl
```

#### Openpyxl でエクセルの ”ブック” を開く
まずプログラム上でエクセルのブックを開きます  
openpyxl でエクセルのブックを開くには openpyxl.load_workbook() を使用します。  
load_workbook() の引数には、開きたいエクセルのパスを指定します。

<p class="tmp list"><span>リスト1-2</span></p>
```
# エクセルファイルのパス
file_path = "excel/210120【発注書】事務備品.xlsx"
# ワークブックを開く
wb = openpyxl.load_workbook(file_path, data_only=True)
```

加えて今回は data_only=True という引数を指定しています。  
この引数は、今回のように関数を使用したエクセルから、関数で計算された値を取得したい場合に True を指定します。
![](upload/data_only=True.png)

#### エクセルの ”シート” を取得
開いたブックから シート を取得します。  
シートは、先ほど開いたブックオブジェクト（wb）に、ブックオブジェクト["シート名"]で取得することができます。
![](upload/発注書ブック.png)

<p class="tmp list"><span>リスト1-3</span></p>
```
# "発注書" シートを取得
sheet = wb["発注書"]
```

#### エクセルの ”セル” の値を取得
シートオブジェクトから、セル の値を取得するには下記のように書きます。  
<p class="tmp"><span>書式</span></p>
```
シートオブジェクト["セル番号"].value
```
セル番号は画像の赤丸箇所を見れば分かります。
今回のエクセルの「合計金額」の値を取得したい場合は、セル番号が “B4” なので、プログラムにすると下記のようになります。
![](upload/セル番号.png)

<p class="tmp list"><span>リスト1-4</span></p>
```
# 「合計金額」の値を取得
value = sheet["B4"].value
print(value)  # 取得した値を表示
# > 2000
```

<p class="result"><span>実行結果</span></p>
![](upload/「合計金額」の値を取得.png)

## Pandasのデータフレームに抽出したデータを追加する

エクセルから抽出したデータは、集計したり扱いやすいように Pandasのデータフレーム形式 に変換したいと思います。  
先ほどの全体図の ② の後半部分に当たります。
![](upload/Pandasのデータフレーム.png)
下図のように、[発注No、発注日、発注部署、発注者、合計金額] のデータを扱うこととします。
![](upload/鈴木A子データ.png)

### 空のデータフレームを作成する

今回は、エクセルから取得したデータを1行ずつデータフレームに追加していきたいので、まず何もデータが入っていない空のデータフレームを作成します。  
この時、各データが入るカラム名（列名）はあらかじめ設定しておきます。  
カラム名（列名）を指定しつつ空のデータフレームを作成するには下記のように書きます。

<p class="tmp list"><span>リスト</span></p>
```
df = pd.DataFrame(columns=["発注No", "発注日", "発注部署", "発注者", "合計金額"])
```
引数 columns にカラム名（列名）をリスト形式で渡すことでカラムを設定できます。  
これによって作られたデータフレームは下図のような、カラム名（列名）だけが設定されていて、中身は何も入っていないものになります。
![](upload/空のデータフレームのカラム.png)

### データフレームに追加するデータを作成
データフレームに行を追加する方法はいくつかありますが、今回は一旦辞書型データにエクセルから抽出してきた値を入れていき、一行分溜まったらデータフレームに変換して追加用行データを作り、それをメインのデータフレームへ追加するようにします。

データ追加の流れ
1. 空の辞書を用意（1行分のデータになる）
2. エクセルから一つずつ値を抽出して辞書に入れていく
3. 辞書に1行分のデータが溜まったらデータフレームに変換
4. 変換した1行分のデータフレームをメインのデータフレームに連結

#### 辞書データの作成
行追加のために作成する辞書データは下記の例のようになります。  
この時、 keyにカラム名、valueにそのカラムのデータ とします。
```
変数 = {"発注No": "2021-001",
        "発注日": "2021-01-21",
        "発注部署": "総務部",
        "発注者": "伊藤 K子",
        "合計金額": 6000}
```

下記のように書くことで、辞書にデータを追加することができます。
<p class="tmp"><span>書式</span></p>
```
辞書変数["key"] = value
```

#### 辞書データをデータフレームに変換する
辞書に1行分のデータが溜まったら、データフレームに変換します。  
辞書をデータフレームへ変換するには、pd.DataFrame() を使います。

<p class="tmp"><span>書式</span></p>
```
add_df = pd.DataFrame([辞書の変数])
```
この時、データが1行分しか無い場合は辞書をリストに入れて（ []で囲って ）渡します。


<blockquote markdown="1">
なぜ、1行分の辞書データの場合はリストに入れて渡すのかと言うと

本来、辞書データをデータフレームに変換する場合は下記のような、リストに複数の辞書が入ったものを変換するように想定されています

[ {“発注No”: “2021-001”, “発注日”: “2021-01-21”, ~ },
{“発注No”: “2021-002”, “発注日”: “2021-01-27”, ~ },
:
{“発注No”: “2022-023”, “発注日”: “2022-04-13”, ~ } ]

1行だけの場合も、このような構造のデータにするためにリストに入れるというわけです。
</blockquote>

### メインデータフレームに行データフレームを追加（連結）する
メインデータフレームに行データフレームを追加（連結）するには、pd.concat() メソッドを使用します。

pd.concat([メインデータフレーム, 追加する行の辞書型], axis=0, ignore_index=True)

* axis : 連結の向き（0=縦、1=横）
* ignore_index : インデックスの振り直しの有無（True=有、False=無）

<p class="tmp list"><span>リスト</span></p>
```
df = pd.concat([df, add_df], axis=0, ignore_index=True)
```
この時、ignore_index=True とするのを忘れないようにしてください。

<div markdown="1" class="memo-box">
ignore_index=True とすると連結後のデータフレームの index(行名)が連番に整理されます。  
これをしないとindexに重複ができたり順番がぐちゃぐちゃになり扱いにくくなったり、思わぬエラーの原因になりますので注意してください。
</div>


## フォルダ内のエクセルだけを読み込む

フォルダ内のエクセルファイルだけを読み込むのに globモジュールのglob関数を使用します。  
先ほどの全体図の ① の部分に当たります。
![](upload/image-20.png)

glob関数は指定したパターンにマッチするパスをリスト形式で返します。   
下記のように書くと、フォルダ内のエクセルファイル（拡張子が.xlsx）のファイルパスをリストで返してくれます。
```
import glob

path_str = "*.xlsx"
paths = glob.glob(path_str)
```

glob関数からの返り値を受け取った paths変数の中身を表示させてみると、下記のようにフォルダ内のエクセルファイルのパス一覧が格納されているのが分かります。

上記のコードを追記し、pathsを入力して「Run」を実行すると、エクセルファイルの一覧が表示されます。
![](upload/エクセルファイルのパス一覧.png)

<div markdown="1" class="memo-box">
glob関数に渡した “*.xlsx” の * はワイルドカード文字と言って、* の部分はどんな文字列でも良いという意味があります。
つまり、”*.xlsx” と書けば “abcd.xlsx” でも “xyz1.xlsx” でも拡張子.xlsxのファイルは全て引っかかることになります。
</div>


## プログラムを完成させる

ここまでで説明した個々の処理を組み合わせてプログラムを完成させます。

### 個々の処理を組合わせて仕上げる

処理を組み合わせて仕上げたプログラムが下記になります。

<p class="tmp list"><span>完成コード</span></p>
```
# ライブラリのインポート
import glob
import openpyxl
import pandas as pd


# 空のデータフレームを作成
df = pd.DataFrame(columns=["発注No", "発注日", "発注部署", "発注者", "合計金額"])

# ファイルパスのリスト取得
path_str = "excel/*.xlsx"
paths = glob.glob(path_str)

for file_path in paths:  # file_path変数にファイルパスが1つずつ入る
    # 空の辞書を作成
    wb_data = {}
    # ブックを開く
    wb = openpyxl.load_workbook(file_path, data_only=True)
    # 発注書シートを取得
    sheet = wb["発注書"]

    # 「発注NO」
    value = sheet["G1"].value  # G1セルの値取得
    wb_data["発注No"] = value  # 行辞書に追加
    # 「発注日」
    value = sheet["G2"].value  # G2セルの値取得
    wb_data["発注日"] = value  # 行辞書に追加
    # 「発注部署」
    value = sheet["G4"].value  # G4セルの値取得
    wb_data["発注部署"] = value  # 行辞書に追加
    # 「発注者」
    value = sheet["G5"].value  # G5セルの値取得
    wb_data["発注者"] = value  # 行辞書に追加
    # 「合計金額」
    value = sheet["B4"].value  # B4セルの値取得
    wb_data["合計金額"] = value  # 行辞書に追加
    
    # 辞書をデータフレームに変換
    add_df = pd.DataFrame([wb_data])
    # データフレームに行を追加
    df = pd.concat([df, add_df], axis=0, ignore_index=True)
    # ブックオブジェクトを閉じる
    wb.close()
	```

glob関数で取得したエクセルファイルパスのリストを for を使って一つずつ取り出して読み込み、処理しています。

dfを入力してrunを実行すると、データフレームの中身が表示されます。下記のようにちゃんとエクセルのデータが抽出できてるのが確認できます。
![](upload/データフレームの中身を表示.png "図　データフレームの中身を表示")


## 抽出したデータの集計

抽出したデータは、Pandas の機能を使って色々な集計や分析が可能です。

### 部署ごとの発注金額の集計

例として「部署ごとの発注金額合計」を <span class="green bold">groupby</span>メソッドを使って集計するコードを載せておきます
<p class="tmp list"><span>リスト</span></p>
```
department = df.groupby(by="発注部署")["合計金額"].sum()
department_df = pd.DataFrame(list(department.index), columns=["部署"])
department_df["合計金額"] = department.values
department_df
```

<p class="result"><span>結果</span></p>
![](upload/部署ごとの発注金額の集計結果.png)
※コードを追加するとき、タブスペースを頭に付けないとエラーになります。


### 月ごとの発注金額の集計

resampleメソッド参考サイト
: <https://www.yutaka-note.com/entry/pandas_resample>

こちらは「月ごとの発注金額合計」を <span class="green bold">resample</span>メソッドを使って集計するコードの例です。

<p class="tmp list"><span>リスト</span></p>
```
month_sum = df.set_index("発注日").resample("M")["発注金額"].sum()
month_df = pd.DataFrame(list(month_sum.index),columns=["発注月"])
month_df["合計金額"] = month_sum.values
month_df
```

改修
excel_data.py
```
df['発注日'] = pd.to_datetime(df['発注日']) # 日時情報が入った列をdatetime型へ変換
df.set_index('発注日', inplace=True) #indexにdatetime列を指定し、置き換え

month_sum = df.resample("M").sum()
month_df = pd.DataFrame(list(month_sum.index),columns=["発注月"])
month_df["合計金額"] = month_sum.values
month_df
```
うまくいかない・・・