<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <ul>
    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($year->nendo); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <form id="create-form" action="/year/add" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <input type="submit" value="新年度追加">
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravelapp8\resources\views/year/index.blade.php ENDPATH**/ ?>