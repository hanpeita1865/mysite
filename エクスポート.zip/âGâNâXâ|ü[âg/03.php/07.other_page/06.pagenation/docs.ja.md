---
title: ページネーション
---

よくWebページで見るページ番号、次へ、前へボタンなどがその機能です。  
一覧表示で、沢山情報がある場合に分割して表示させる機能です。  
なぜ分割させるのかといいますと、

* 表示時間を短くさせる
* 1ページの情報量を減らして見やすくさせる

などの効果があります。

### 使用するデータ

|	|	|
|:--:|:--|
|本種類	|本の名前|
|ライトノベル	|ライトノベルの本|
|歴史	|歴史の本|
|料理	|料理の本|
|啓発本	|啓発の本|
|コミック	|コミックの本|
|推理小説	|推理小説の本|
|フォトブック	|フォトブックの本|

#### 配列に格納
```
$books = array( // 表示データを配列に入れる
    array('book_kind' => 'ライトノベル', 'book_name' => 'ライトノベルの本'),
    array('book_kind' => '歴史', 'book_name' => '歴史の本'),
    array('book_kind' => '料理', 'book_name' => '料理の本'),
    array('book_kind' => '啓発本', 'book_name' => '啓発の本'),
    array('book_kind' => 'コミック', 'book_name' => 'コミックの本'),
    array('book_kind' => '推理小説', 'book_name' => '推理小説の本'),
    array('book_kind' => 'フォトブック', 'book_name' => 'フォトブックの本'),
);
```

[新規タブ1](../../../sample/php/pagenation/test.php?target=_blank)

※ 下記のpaizaでは、ページ移動はできません。動作確認は、新規タブから行ってください。
<iframe src="https://paiza.io/projects/e/E49qwcTRS1_x3plseXkc8g?theme=twilight" width="100%" height="700" scrolling="no" seamless="seamless"></iframe>



### 「前へ」「次へ」を追加

ポイントとしては次へや前へは、表示しているページによってリンクをつけるかの判定が必要になります。  
前へを押して、1ページより前に移動することはできません。

[新規タブ1](../../../sample/php/pagenation/test1.php?target=_blank)

<iframe src="https://paiza.io/projects/e/B5GO4NMBIM_KPIiC0gV1cQ?theme=twilight" width="100%" height="600" scrolling="no" seamless="seamless"></iframe>

### mysqlなどのデータベースでページング

mysql等のデータベースでsqlを発行してデータを取得する場合も考え方は同じです。

何件目からはoffsetを使用し、何件取ってくるかはlimitを使用します。


## 非同期でページング

[新規タブ](../../../sample/php/pagenation/test2/index.html?target=_blank)

<iframe width="100%" height="200" src="../../sample/php/pagenation/test2/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

##### index.html
```
<!-- 取得結果の反映 -->
<div class="result"></div>

<script>
$(function(){
    getList(1);//初期値は1ページ目に設定
    
    function getList(page){
        $.ajax({
            url: 'paging.php',
            type: 'POST',
            dataType: 'html',
			cache:    false,
            data : {
                page : page
            }
        }).done(function(data){
            /* 通信成功時 */
            $('.result').html(data); //取得したHTMLを.ajax_resultに反映
			
			//ページングのクリックイベント
			$('.pager a').on('click', function(){
				var page = Number($(this).attr('href'));
				getList(page);
				return false;
			});
			
        }).fail(function(data){
            /* 通信失敗時 */
			alert('非同期通信に失敗しました');
        });
    }
});
</script>
```

##### paging.php
```
<div>
<?php
define('MAX','3'); // 1ページの記事の表示数

$books = array( // 表示データを配列に入れる
	array('book_kind' => 'ライトノベル', 'book_name' => 'ライトノベルの本'),
	array('book_kind' => '歴史', 'book_name' => '歴史の本'),
	array('book_kind' => '料理', 'book_name' => '料理の本'),
	array('book_kind' => '啓発本', 'book_name' => '啓発の本'),
	array('book_kind' => 'コミック', 'book_name' => 'コミックの本'),
	array('book_kind' => '推理小説', 'book_name' => '推理小説の本'),
	array('book_kind' => 'フォトブック', 'book_name' => 'フォトブックの本'),
);
            
$books_num = count($books); // トータルデータ件数

$max_page = ceil($books_num / MAX); // トータルページ数※ceilは小数点を切り捨てる関数
 
if(!isset($_POST['page'])){ // $_GET['page_id'] はURLに渡された現在のページ数
    $now = 1; // 設定されてない場合は1ページ目にする
}else{
    $now = $_POST['page'];
}

$start_no = ($now - 1) * MAX; // 配列の何番目から取得すればよいか

// array_sliceは、配列の何番目($start_no)から何番目(MAX)まで切り取る関数
$disp_data = array_slice($books, $start_no, MAX, true);

foreach($disp_data as $val){ // データ表示
    echo $val['book_kind']. '　'.$val['book_name']. '<br />';
}
?>
</div>

<div class="pager">
<?php
for($i = 1; $i <= $max_page; $i++){ // 最大ページ数分リンクを作成
    if ($i == $now) { // 現在表示中のページ数の場合はリンクを貼らない
        echo $now. '　'; 
    } else {
       echo '<a href="'.$i.'">'.$i.'</a>'.'　';
    }
}
?>
</div>
```





