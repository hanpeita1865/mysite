$('.input-daterange').datepicker({
  language: 'ja',
  // format: 'yyyy/mm/dd',
  format: 'yyyy年mm月dd日',
  forceParse: false,
  keepEmptyValues: true,
})
