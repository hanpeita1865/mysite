*[page-title]:セッション


セッションは、サーバー=クライアント間の接続を維持し、個々のクライアントごとに各種のサービスや情報などを保持する技術です。セッションの基本的な使い方をマスターしましょう。

## セッションについて

本格的なアプリケーション開発では、「クライアント=サーバー間の接続を維持する仕組み」が必要となってきます。  
例えば、オンラインショップのようなものを考えたとき、商品ページを移動するたびに、カートに入れた商品がクリアされてしまったら使い物になりません。あちこちのペー ジに移動しても、カートに入れた商品が常に保存されていなければいけません。そのためには、クライアントとサーバーの接続を維持し、「今、アクセスしているクライアントはこの人だ」ということをサーバー側で把握できなければいけません。  
このようなクライアントとサーバーの接続維持のための仕組みを提供するのが「<span class="green bold marker-yellow50">セッション</span>」と呼ばれる機能です。


### セッション = クッキー ＋ データベース
セッションを使えば、クライアントとサーバーの間の接続を維持することができます。 クライアントは、それぞれに各種の情報を保持することができます。例えば、カートに商品を入れると、それぞれのクライアントごとに「カートに入れた商品」情報が保持し続けられるわけです。

もともとWebで使われている技術は、こうした連続した接続を考えていません。では、どうやってこのようなことを可能にしているのでしょうか。  
その秘密は、「クッキー」と「データベース」にあります。セッションでは、それぞれの クライアントごとに、IDとなる値をクッキーとして保管します（これを「セッションID」 といいます）。そして、クライアントごとの情報（例えば、カートに入れた商品情報）は、そのセッションIDに関連付けてデータベースに保存するのです。セッションから情報を取り出すときは、クライアントのセッションIDを使ってデータベースからデータを検索して取り出せばいい、というわけです。

![](upload/session_criant.png "図　クライアントからサーバーへセッションIDが送られると、そのIDを元にデータベースからクライ アントの情報を取り出して処理をする。")


## セッションを利用する

このようにセッションは、クッキーとデータベースを組み合わせて動かすのが基本といえます。ただし、実をいえばデータベースは必須というわけではありません。  
Laravelでは、データベースの他に、ファイルやメモリキャッシュなどを使ってセッションを保存する手段を持っています（デフォルトでは、ファイルを利用するように設定されています）。このため、データベースの設定などを行わなくとも、すぐにセッションは利用することができます。

### セッション操作の基本
セッションの操作は非常にシンプルです。「値に名前をつけて保存する」「名前を指定して値を取得する」、この2つの操作だけしかありません。

<p class="tmp"><span>書式1</span>値を保存する</p>
```
$request->session()->put( キー , 値 );
```

<p class="tmp"><span>書式2</span>値を取得する</p>
```
$変数 = $request->session()->get( キー );
```

非常に単純です。セッションは、キー（値に割り当てる名前）の文字列と保存する値がセットになっています。保存するときも取り出すときも、常にキーを使って値の読み書きを行います。



## セッション利用アクションを作る

では、セッションを利用するアクションを作ってみましょう。今回は、以前作成した HelloControllerに「session」というアクションを追加して試してみることにします。  
まず、画面表示用のテンプレートを作りましょう。「views」内の「hello」フォルダ内に、 「<span class="red">session.blade.php</span>」という名前でファイルを作成して下さい。そして以下のようにソー スコードを記述します。

<p class="tmp list"><span>リスト1-1</span>session.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Session')

@section('menubar')
   @parent
   セッションページ
@endsection

@section('content')
   <p>{{$session_data}}</p>
   <form action="/hello13/session" method="post">
   {{ csrf_field() }}
   <input type="text" name="input">
   <input type="submit" value="send">
   </form>
@endsection

@section('footer')
copyright 2023
@endsection
```

ここでは、$session_dataという変数の表示と、name="input"という入力フィールドのあるフォームを用意してあります。フォームからテキストを送信すると、それをセッションに保存し、保存された値を$session_dataに代入して表示しよう、というわけです。  
フォームの送信先は、「/hello13/session」としてあります。この「/hello13/session」にGETと POSTのアクションを用意して処理を行います。

### HelloController のアクション作成
では、コントローラにアクションを作成しましょう。「Http」内の「Controllers」フォルダにある「HelloController.php」を開き、HelloControllerクラスに以下の2つのアクションメソッドを追加して下さい。

<p class="tmp list"><span>リスト1-2</span>HelloController.php</p>
```
public function ses_get(Request $request)
{
   $sesdata = $request->session()->get('msg');
   return view('hello.session', ['session_data' => $sesdata]);
}

public function ses_put(Request $request)
{
   $msg = $request->input;
   $request->session()->put('msg', $msg);
   return redirect('hello13/session');
}
```

「<span class="red">ses_get</span>」は、「/hello13/session」にアクセスしたときの処理です。ここでは、以下のようにしてセッションから「msg」という値を取り出しています。
```
$sesdata = $request->session()->get('msg');
```
こうして取り出した値を、session_dataという名前でテンプレートに渡しています。  
もう1つの「<span class="red">ses_put</span>」は、「/hello13/session」にフォームをPOST送信したときの処理です。ここでは、<span class="red">$request->input</span>の値を取り出し、それを以下のようにしてセッションに保管し ています。
```
$request->session()->put('msg', $msg);
```
これで、<span class="red">$msg</span>の値が<span class="red">'msg'</span>という名前でセッションに保管されます。セッションの利用は、わずかこれだけのコードで実現できるのです。


### ルート情報の追記
最後に、ルート情報を追記しましょう。web.phpを開き、以下のように追記して下さい。

<p class="tmp list"><span>リスト1-3</span>web.php</p>
```
Route::get('hello13/session', [\App\Http\Controllers\HelloController::class,'ses_get']);
Route::post('hello13/session', [\App\Http\Controllers\HelloController::class,'ses_put']);
```

これで完成です。実際に、/hello13/sessionにアクセスをして、何かテキストを書いて送信してみて下さい。セッションに保存され、/hello13/sessionに何度アクセスしてもそのテキストが記憶されていて表示されるようになります。

![](upload/おはようございます。記入して送信.png "図　フォームに「おはようございます。」と記入して送信"){.photo-border}
<p class="d-flex align-items-center"><span class="arrow-down ml-5 mr-3"></span>セッションに保管され、「おはようございます。」が画面に表示されるようになる。</p>
![](upload/おはようございます。記入して送信結果.png){.photo-border}


<div class="memo-box" markdown="1">
#### Chromeでセッションが切れる!
Chromeブラウザを使っていると、セッションが頻繁に切れてしまう現象に遭遇することがあります。これは、CSRF対策の問題と同根のようで、Chrome以外のブラウザでは正常に動作します。  
もし、こうした問題が発生したら、他のWebブラウザで動作を確認してみて下さい。 それで問題なければ、Chrome固有の問題と考えてよいでしょう。  
なお、この問題は、favicon.icoが設置されていない場合に発生するようであり、以前から広く知られているものです。「chrome favicon セッション」などで検索すると多くの情報が得られるでしょう。
</div>


## データベースをセッションで使う

これで、セッションの利用ができるようになりました。しかし、ファイルに保存しておくというやり方は、やや不安です。セッションファイルは、「storage」内の「framework」フォルダ内にある「sessions」というところに保管されます。  
実際に確認してみると、ここに多数のファイルが保存されていることがわかるはずです。
![](upload/セッション保管ファイル.png)

おはようございます。のコード
```
a:4:{s:6:"_token";s:40:"PXPow33UPyc2UmPMGVb6WhePKtli9MSDoeAfjm98";s:9:"_previous";a:1:{s:3:"url";s:37:"http://localhost:8000/hello13/session";}s:6:"_flash";a:2:{s:3:"old";a:0:{}s:3:"new";a:0:{}}s:3:"msg";s:30:"おはようございます。";}
```

それぞれのセッションごとにファイルが作られるため、本格的に稼働させるようになると、アクセスによっては数千数万のファイルがここに配置されることになります。 各セッションごとに異なるファイルを読み書きするため、処理速度もそれほど速くはありません。  
こうした点を考えるなら、やはり正式稼働前にデータベースを利用する形に変更しておくべきでしょう。

### session.php について
セッションに関する設定情報は、「config」フォルダ内にある「session.php」というファイルに用意されています。このファイルを開くと、以下のように記述がされています（コメント類は省略してあります）。

<p class="tmp list"><span>リスト2-1</span>config/session.php</p>
```
<?php

use Illuminate\Support\Str;

return [
    'driver' => env('SESSION_DRIVER', 'file'),
    'lifetime' => env('SESSION_LIFETIME', 120),
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => storage_path('framework/sessions'),
    'connection' => env('SESSION_CONNECTION'),
    'table' => 'sessions',
    'store' => env('SESSION_STORE'),
    'lottery' => [2, 100],
    'cookie' => env(
        'SESSION_COOKIE',
        Str::slug(env('APP_NAME', 'laravel'), '_').'_session'
    ),
    'path' => '/',
    'domain' => env('SESSION_DOMAIN'),
    'secure' => env('SESSION_SECURE_COOKIE'),
    'http_only' => true,
    'same_site' => 'lax',
];
```

かなり多くのコメントがつけられているので、複雑そうに見えるかもしれませんが、 やっているのはこのような連想配列をreturnする、というだけのことです。これら配列にまとめられているのが、セッションに関する設定です。  



## セッションの保存先をデータベースに変更する

セッションをデータベースに変更する場合は、この<span class="red">session.php</span>の中の<span class="red">'driver'</span>の項目を 変更します。以下のように修正して下さい。

<p class="tmp list"><span>リスト2-1</span>session.php</p>
```
'driver' => env('SESSION_DRIVER', 'database'),
```
envの第2引数「file」から「database」に変更しています。  
これで、データベース利用のドライバーが使われるようになります。続いて、プロジェクトフォルダ内にある「<span class="red">.env</span>」というファイルを修正します。  
ファイルを開き、「<span class="red">SESSION_DRIVER</span>」という項目を探して下さい。この項目を以下のように修正します。  
これも「SESSION_DRIVER」の値をfileからdatabaseに変更しています。

<p class="tmp list"><span>リスト2-2</span>env</p>
```
SESSION_DRIVER=database
```
データベースを利用するように、セッションの設定が変更できました。ただしまだやることがあります。セッション用テーブルをデータベースに準備することです。


## セッション用マイグレーションの作成

セッション用のテーブルは、仕様が決まっており、それに従った形で用意しなければ いけません。これを手作業で作成するのは勧められません。  
Laravelには、artisanコマンドを使ってセッション用テーブルを作成する機能が用意されていますので、これを使いましょう。まず、専用のマイグレーションファイルを作ります。コマンドプロンプトまたはターミナルから以下のように実行して下さい。

<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan session:table

```

これで、「database」内の「migrations」フォルダに「xxxx_session_table.php」(xxxxは任意の日時)というマイグレーションファイルが作成されます。
![](upload/セッションテーブル.png "図　セッション用マイグレーションファイル")

この中に、セッション用テーブルを作成する処理が記述されています。中を見ると以下のようになっているのがわかるでしょう。

<p class="tmp list"><span>リスト3-1</span></p>
```
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sessions');
    }
};
```

セッション用テーブルは、「sessions」という名前で作成し、「id」「user_id」「ip_address」 「user_agent」「payload」「last_activity」といったフィールドが用意されています。これら の情報が、セッションを確立するために必要な情報というわけです。

### マイグレーション実行
では、マイグレーションを実行してテーブルを生成しましょう。コマンドプロンプト またはターミナルから以下のように実行して下さい。

```
php artisan migrate
```

![](upload/sessionsテーブル.png "図　sessionsテーブル")

これで、データベースを利用してセッションが動作するようになります。実際に「/ hello13/session」にアクセスして、値がセッションに保管されるか確認しましょう。

<http://localhost:8000/hello13/session>


![](upload/データベースデータ送信.png "図　セッションデータ送信"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/データベースデータ登録.png "図　セッションデータ登録"){.photo-border}

![](upload/sessionデータ登録.png "図　sessionテーブルに登録されました。"){.photo-border}


## その他

### セッションの有効期限
セッションの有効期限は、「config/session.php」でlifetimeキーで定義されています。
```
'lifetime' => env('SESSION_LIFETIME', 120),
```
単位は分でデフォルトでは120分なので、セッションの有効期限は2時間です。


### セッションファイル保存先
セッションドライバがファイルの場合の、セッションファイルの保存先を設定することができます。

filesキーで定義されており、デフォルトでは「storages/framework/sessions」ディレクトリ内に保存されます。
```
'files' => storage_path('framework/sessions'),
```


### cookieのキー名
暗号化されたセッションIDをクッキーで保存する際のcookieのキー名を設定することができます。

「config/session.php」でcookieキーで定義されています。
```
'cookie' => env(
    'SESSION_COOKIE',
    Str::slug(env('APP_NAME', 'laravel'), '_').'_session'
),
```

デフォルトではlaravel_sessionというcookieキー名で暗号化されたセッションIDが保存されます。

～まだいまいち使い方を理解できていない～

## 参考サイト

* [Laravel 10.x HTTPセッション](https://readouble.com/laravel/10.x/ja/session.html)
* [Laravelでセッション管理(保存、取得、削除など)してみる](https://migisanblog.com/laravel-session-use/)
* [【Laravel】Sessionの扱い方ざっくりまとめ](https://qiita.com/yutaka_pg/items/f0103c3171b75146c28a)
