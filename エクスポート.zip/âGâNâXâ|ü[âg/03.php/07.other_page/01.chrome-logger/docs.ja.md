---
title: PHPでコンソールに表示させる
media_order: console.png
taxonomy:
    category:
        - docs
visible: false
---

## データーをスクリプト言語に入れる

問題点
: foreach()を使ってループさせると、一回目はループするがそれ以降画像などはエラーになる。


[新規タブ](http://localhost/test/php(console.log)/index(debug).php)
##### PHP 

```
<?php
function console_log( $data ){
  echo '<script>';
  echo 'console.log('. json_encode( $data ) .')';
  echo '</script>';
}

$myvar = array(1,2,3);
console_log( $myvar ); // [1,2,3]
?>
```
##### コンソール表示

![](console.png)

### 参考

[http://lighthouse-dev.hatenablog.com/entry/2018/03/08/121727](http://lighthouse-dev.hatenablog.com/entry/2018/03/08/121727)





## Chrome Logger

問題点
: phpの最初に記述しないとコンソールが表示されない。なのでrequireで読み込んだファイルのコンソールは表示されない。・・・調査中

### 使い方

1. ChromeにChrome Loggerプラグインをインストールします。[https://chrome.google.com/webstore/detail/chrome-logger/noaneddfkdjfnfdakjjmocngnfkfehhd](https://chrome.google.com/webstore/detail/chrome-logger/noaneddfkdjfnfdakjjmocngnfkfehhd)
1. 「chromephp」をダウンロードし、コンソール表示させたいページにrequireで「ChromePhp.php」のファイルをインクルードさせます。[https://github.com/ccampbell/chromephp](https://github.com/ccampbell/chromephp)
1. デベロッパーツールを開くと次のようにコンソールに表示できるようになります。

#### PHP

```
<?php
// demo.php
include 'ChromePhp.php';
ChromePhp::log('Hello console!日本語もOK');
ChromePhp::log($_SERVER); // 配列も大丈夫
ChromePhp::info('infoログです');
ChromePhp::warn('warnログです');
ChromePhp::error('errorログです');

ChromePhp::groupCollapsed('MyGroup');
for ($i = 1; $i <= 10; $i++) {
  ChromePhp::log('log' . $i);
}
ChromePhp::groupEnd();
?>
```

### 例

PHPに記述した下記のコードが

```
ChromePhp::log('Hello console!日本語もOK');
ChromePhp::log($_SERVER); // 配列も大丈夫
ChromePhp::info('infoログです');
ChromePhp::warn('warnログです');
ChromePhp::error('errorログです');
```

デベロッパーツールで以下のようなコンソール表示がされます。

```
Hello console!日本語もOK
log.js:137 Object
log.js:137 infoログです
log.js:137 warnログです
_logData @ log.js:137
log.js:137 errorログです
```

