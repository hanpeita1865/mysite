*[page-title]:10-7. レンズ特性のゆがみを補正してみよう

## 広角補正 ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-07-1.jpg)](upload/10-07-1.jpg){.image}
</div>

## レンズ補正 ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-07-2.jpg)](upload/10-07-2.jpg){.image}
</div>