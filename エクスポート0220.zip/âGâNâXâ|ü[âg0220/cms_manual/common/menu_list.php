<li id="item1" draggable="true"> <a href="<?= $base_path ?>p__base/">共有事項</a></li>
<li id="item2" draggable="true">
<a href="<?= $base_path ?>p__list/">お知らせ作成</a>
</li>
<li id="item3" draggable="true" class="sub-open">
<a href="<?= $base_path ?>p__article/">記事ページ作成・編集方法</a>
<ul class="sub-menu"><li id="item7" draggable="true">
<a href="<?= $base_path ?>p__article_base/">基本</a>
</li><li id="item6" draggable="true">
<a href="<?= $base_path ?>p__article_toolbar/">ツールバー説明</a>
</li><li id="item5" draggable="true">
<a href="<?= $base_path ?>p__article_text/">テキスト装飾</a>
</li><li id="item8" draggable="true">
<a href="<?= $base_path ?>p__article_list/">リスト</a>
</li><li id="item9" draggable="true">
<a href="<?= $base_path ?>p__article_link/">リンク配置</a>
</li><li id="item10" draggable="true">
<a href="<?= $base_path ?>p__article_image/">画像配置</a>
</li><li id="item4" draggable="true">
<a href="<?= $base_path ?>p__article_table/">テーブル</a>
</li><li id="item11" draggable="true">
<a href="<?= $base_path ?>p__article_other/">その他</a>
</li></ul></li>
			
			
			
			
			
			