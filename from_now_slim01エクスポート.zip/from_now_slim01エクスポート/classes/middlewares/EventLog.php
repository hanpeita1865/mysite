<?php
//リスト8-13
namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Container\ContainerInterface;

class EventLog implements MiddlewareInterface
{
    private $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;

    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        // $config = $this->container->get('config');
        // $basePath = $config['basePath'];
        // $this->container->set('basePath', $basePath);
        
        $serverParams = $request->getServerParams();
        $path = $serverParams["REQUEST_URI"];
        $content = '（'.$_POST['eventName'].'）'."ログを出力しました。パスは".$path;
        $logger = $this->container->get("logger");
        $logger->info($content);
    

        $response = $handler->handle($request);
        return $response;
    }
}