*[page-title]:9-4. シェイプの塗りや線の設定


<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/9-04.jpg)](upload/9-04.jpg){.image}
</div>