---
title: '10. リンクやファイルにアイコンを設置'
taxonomy:
    category:
        - docs
---

## JSで設置

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
リンクやファイルにアイコンを自動で設置します。
[新規タブ](../../../sample/jquery/sample1(icon)/index.html?target=_blank)

<iframe width="100%" height="550" src="../../sample/jquery/sample1(icon)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

##### JS
```
//その他ファイルのパス変更とアイコン設定
$('main a').each(function() {
	var href = $(this).attr('href');//aのhrefの値
	var cls = $(this).attr('class');//aのclassの値

	//※test()メソッドは、正規表現と指定した文字列がマッチするかを調べます。 trueかfalseを返します.
	switch( true ){
		case /.pdf$/.test( href ) :
			//buttonが親要素に、またはimgタグが子要素にない時だけにアイコンを設置
			if(!$(this).children('img').length && !$(this).find('button').length){
				$(this).addClass('file_icon pdf-icon');
			}
			break ;
		case /.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/.test( href ) :
			if(!$(this).children('img').length && !$(this).find('button').length){
				$(this).addClass('file_icon excel-icon');
			}
			break ;
		case /.doc$|.docm$|.docx$|.dot$|.dotx$/.test( href ) :
			if(!$(this).children('img').length && !$(this).find('button').length){
				$(this).addClass('file_icon word-icon');
			}
			break ;
	}

	//「.no-icon」がある時は、アイコンを付けない
	if(!$(this).hasClass('no-icon')){
		switch( true ){
			case /^http:|^https:/.test(href) :
				if(!$(this).children('img').length && !$(this).find('button').length){
					$(this).addClass('file_icon newtab-icon');
				}
				break ;
			default :
				break ;					
		}

	}

	//「http」か「https」のとき、target="_blank"を設定
	switch( true ){
		case /^http:|^https:/.test(href) :
			$(this).attr('target','_blank');
			break ;
		default :
			break ;	
	}

});
```

## PHPで設置

##### PHP
フォルダ内のファイルをアイコンを付けて表示
```
foreach (glob('./upload/*') as $item) {
	$file_name = basename($item);//ファイル名だけを抜き出す
	$fileClass ='';

	  switch (1) {
		//エクセル
		case preg_match('/.xlsx$|.xls$|.xlsm$|.xlsb$|.xltx$|.xltm$|.xlt$|.xls$|.xml$|.xml$|.xlam$|.xla$|.xlw$|.xlr$/',$file_name):
		  $fileClass = 'filename file_icon excel-icon';
		  break;
		//テキスト
		case preg_match('/.txt$/',$file_name):
		  $fileClass = 'filename file_icon text-icon';
		  break;
		//ワード
		case preg_match('/.doc$|.docm$|.docx$|.dot$|.dotx$/',$file_name):
		  $fileClass = 'filename file_icon word-icon';
		  break;
		//パワーポイント
		case preg_match('/.pptx$/',$file_name):
		  $fileClass = 'filename file_icon pptx-icon';
		  break;
		//zipファイル
		case preg_match('/.zip$/',$file_name):
		  $fileClass = 'filename file_icon zip-icon';
		  break;
	  }

	echo '<li><span class="'.$fileClass.'">'.$file_name.'</span><button class="upfileDelete">削除</button></li>';
}
```

##### CSS
```

.file_icon {
	display: inline-block;
	padding-right: 23px;
	position: relative;
}

.file_icon::after {
	content: "";
	font-size: 0;
	height: 20px;
	width: 20px;
	margin-left: 4px;
	position: absolute;
}

/*PDFアイコン*/
.file_icon.pdf-icon::after {
	background: url(../images/icon-pdf.svg) no-repeat;
	background-size: auto 100%;
	content: "PDFファイル";
}

/*EXCELアイコン*/
.file_icon.excel-icon::after {
	background: url(../images/icon-excel.svg) no-repeat;
	background-size: auto 100%;
	content: 'エクセルファイル';
}

/*WORDアイコン*/
.file_icon.word-icon::after {
	background: url(../images/icon-word.svg) no-repeat;
	background-size: auto 100%;
	content: 'ワードファイル';
}

/*PowerPointアイコン*/
.file_icon.ppt-icon::after {
	background: url(../images/icon-pptx.svg) no-repeat;
	background-size: auto 100%;
	content: 'パワーポイントファイル';
}

/*ZIPアイコン*/
.file_icon.zip-icon::after {
	background: url(../images/icon-zip.svg) no-repeat;
	background-size: auto 100%;
	content: 'zipファイル';
}

/*TEXTアイコン*/
.file_icon.text-icon::after {
	background: url(../images/icon-text.svg) no-repeat;
	background-size: auto 100%;
	content: 'テキストファイル';
}

/*新規ウィンドウアイコン*/
.file_icon.newtab-icon {
	padding-right: 22px;
}

.file_icon.newtab-icon::after {
	background: url(../images/icon-newtab.svg) no-repeat;
	background-size: auto 100%;
	height: 15px;
	width: 15px;
	margin-left: 3px;
    bottom: 3px;

}
```

## CSSで設置

短所
: リンク(aタグ)にしか設置されない。

##### CSS
```
/*========================================
ファイルアイコン
=========================================*/
.file:after, .extlink:after, .mail:after {
	display: inline-block;
	background-size: contain;
	content: "";
	height: 18px;
	width: 18px;
	margin: 0 5px 0 3px;
	vertical-align: -3px;
}

a[href$=".pdf"]:after {
	background: url(../images/icon-pdf.svg) no-repeat;
}

a[href$=".doc"]:after, a[href$=".docx"]:after {
	background: url(../images/icon-word.svg) no-repeat;
}

a[href$=".xls"]:after, a[href$=".xlsx"]:after {
	background: url(../images/icon-excel.svg) no-repeat;
}

a[href$=".ppt"]:after, a[href$=".pptx"]:after {
	background: url(../images/icon-powerpoint.png) no-repeat;
}

a[href$=".zip"]:after {
	background: url(../images/icon-zip.png) no-repeat;
}

a.extlink:after {
	background: url(../images/icon-extlink.png) no-repeat left center;
	background-size: contain;
	height: 14px;
	width: 14px;
	vertical-align: -2px;
}

a.mail:after {
	background: url(../images/icon-mail.png) no-repeat left center;
	background-size: contain;
	height: 16px;
	width: 16px;
	vertical-align: -4px;
}

```

## 参照サイト

[【CSS】リンク先のURLやファイルの拡張子に合わせてアイコンを表示する方法。](https://on-ze.com/archives/1032)