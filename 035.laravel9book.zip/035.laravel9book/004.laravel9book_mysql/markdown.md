*[page-title]:MySQLの設置

参考サイト
https://chigusa-web.com/blog/laravel-sail-phpmyadmin/

## docker-compose.yml修正

すでにLaravel Sailで環境構築が済んでいる状態から始めます。

Sailの中身はDockerですので、Laravelプロジェクト直下にあるdocker-compose.ymlを修正します。  
phpMyAdminに関する情報を、servicesブロック内に追記します。

<p class="tmp list"><span>リスト</span>docker-compose.yml</p>
```
    phpmyadmin:
        image: phpmyadmin/phpmyadmin
        links:
            - mysql:mysql
        ports:
            - 8080:80
        environment:
            MYSQL_USER: '${DB_USERNAME}'
            MYSQL_PASSWORD: '${DB_PASSWORD}'
            PMA_HOST: mysql
        networks:
            - sail
```

![](upload/phpmyadmin追加コード.png)

sailを起動します。
![](upload/phpmyadmin.png)

ブラウザで <http://localhost:8080/> を表示すると、次のようにphpMyAdminが出てきます。
![](upload/phpmyadmin起動.png){.photo-bordder}

下記より  
ユーザー名　sail   
パスワード　password

![](upload/phpmyadminパスワード.png ".env")
