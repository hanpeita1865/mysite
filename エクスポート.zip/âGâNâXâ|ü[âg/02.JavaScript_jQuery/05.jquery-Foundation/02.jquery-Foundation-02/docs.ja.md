---
title: '02. jQuery メソッド'
taxonomy:
    category:
        - docs
visible: true
---

## メソッドについて

ページ内の要素（DOMオブジェクト）を操作する命令文をメソッド（method）と言います。  
DOMオブジェクトとメソッドは以下の様にドットを挟んで記述します  
（このような構文を「ドットシンタックス」と呼びます）。

```
<script>
    // オブジェクト . メソッド
    $("body").text("Hello, World!");
</script>
```

これで「誰（オブジェクト）が何をする（メソッド）」という最小限の処理が完成します。

---

## 主要メソッド一覧

jQueryの主要メソッドの一覧を記載します。  
各メソッドの詳細な説明は、次回以降に回します。

|操作                     |メソッド                                                                            |
|------------------------|-----------------------------------------------------------------------------------|
|要素選択                 |children()、parent()、find()、siblings()、prev()、prevAll()、next()、nextAll()、eq()  |
|文字列取得や書き替え       |html()、text()                                                                      |
|属性の値の取得や変更や削除  |attr()、removeAttr()、prop()                                                            |
|要素の先頭や後ろに追加      |prepend()、append()                                                                |
|cssのプロパティの取得や変更 |css()                                                                              |
|クラスの取得や変更         |hasClass、addClass、removeClass()、toggleClass()                                     |
|value値の取得            |val()                                                                               |
|要素の幅や高さを取得や設定  |width()、height()                                                                   |
|要素の位置を取得           |offset()                                                                           |
|一致した要素を順番に処理    |each                                                                               |
|要素の表示、非表示         |show()、hide()                                                                      |
|クリック、ホバー時の処理    |click()、hover()                                                                    |
|文字の属性値の置換         |replace()                                                                           |
|URLを取得                |location                                                                            |
|フェードイン、フェードアウト |fadeIn()、fadeOut()                                                                 |
|通信                     |get()、post()                                                                       |

---

コメント
