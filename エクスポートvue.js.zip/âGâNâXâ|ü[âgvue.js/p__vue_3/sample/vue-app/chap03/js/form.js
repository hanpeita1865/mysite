Vue.createApp({
  data() {
    return {
      myName: '匿名'
    };
  }
}).mount('#app');