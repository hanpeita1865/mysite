<?php require '../header.php'; ?>
<table>
<tr><th>ID</th><th>お名前</th><th>ご住所</th><th>ログイン名</th><th>パスワード</th></tr>
<?php
$pdo=new PDO('mysql:host=localhost;dbname=shop;charset=utf8', 
	'staff', 'password');
foreach ($pdo->query('select * from customer') as $row) {
	echo '<tr>';
	echo '<td>', $row['id'], '</td>';
	echo '<td>', $row['name'], '</td>';
	echo '<td>', $row['address'], '</td>';
    echo '<td>', $row['login'], '</td>';
    echo '<td>', $row['password'], '</td>';
	echo '</tr>';
	echo "\n";
}
?>
</table>
<?php require '../footer.php'; ?>