var dragImage = document.createElement('img');//img要素を作成
dragImage.src = 'image/0-01.png'; //ドラッグしてるときのイメージ画像を設定

$('#box').on('dragstart', onDragStart);//ドラッグを開始したときに、onDragStart関数を行う

function onDragStart(e) {
	//DataTrasnferオブジェクトにidを設定
	e.originalEvent.dataTransfer.setData('text', this.id);
	//DataTrasnferオブジェクトにイメージを設定
	e.originalEvent.dataTransfer.setDragImage(dragImage, 40, 40);
}
