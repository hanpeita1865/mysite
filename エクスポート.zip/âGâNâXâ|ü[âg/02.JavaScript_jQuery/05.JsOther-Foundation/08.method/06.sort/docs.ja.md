---
title: sort()による配列・文字列・オブジェクトのソート方法
taxonomy:
    category:
        - docs
---

* [sort()とは？](#p1)
* [文字列をソートする方法](#p2)
* [比較関数について](#p3)
* [配列の「sort()」について](#p4)
* [オブジェクトの「sort()」について](#p5)
* [「sort()」の破壊的メソッドについて](#p6)
* [応用](#p7)

## sort()とは？ ##{#p1}
sort()は、JavaScriptで並び替えを実現するメソッドになります。文字列順や数字の大小などによる昇順・降順で対象の値を並び替えることができるようになるので、データの操作などでよく使われます。

また、配列に格納されたバラバラの値やオブジェクトのキー（プロパティ）を対象にして並び替えることも可能なので、活用範囲はとても広いと言えます。

ただし、sort()は元の配列データを変更してしまう破壊的メソッドでもある点には注意が必要です。


## 文字列をソートする方法 ##{#p2}
文字列をソートするには、ソートしたい文字列が格納されている配列を対象に「sort()」メソッドを呼び出します。次のプログラムで確認してみましょう。

<div class="box-example">
    <h3 class="h-example">例1</h3>
    文字列を昇順に並べ替え
</div>
<iframe width="100%" height="250" src="//jsfiddle.net/089psyua/1/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

この例では、文字列が格納された配列に対して「sort()」を実行しています。実行結果を見ると、  
['hh', 'dd', 'cc', 'bb']　→  ["bb", "cc", "dd", "hh"]  
のように、アルファベット順に並び替えられています。



## 比較関数について ##{#p3}
単純な文字列の並び替えであればsort()をそのまま実行すればいいのですが、数値やオブジェクト構造などの場合だと上手くできません。

このような場合には「比較関数」と言って、2つの値を比較しながら1つずつ順番を入れ替えていく手法を取ります。次のサンプル例を見てください！
```
function compareFunc(a, b) {
    return a < b;
}
```
この例では「a」「b」という2つの引数を取り、returnで「a ＜ b」を比較した結果を返しています。これにより、「a」が「b」よりも小さいかどうかを確認することで、順番を入れ替えるというわけです。

比較条件としては「＜」以外にも、「＞, ==, -」などを使って比較することで昇順・降順などを変更することができます。



## 配列の「sort()」について ##{#p4}
配列に格納された数値データに対してのソート方法について見ていきます。　主に、昇順・降順の並び替え方法について学んでいきます。

### sort()で数値をソート（並び替え）する方法
ここでは、数値をソートする方法を解説します。数値をソートするには、引数に比較関数(compareFunction)を指定します。

引数に比較関数を指定しない場合には文字列として比較されるので注意が必要です。次のプログラムで確認してみましょう。

#### 昇順で並べ替え
<div class="box-example">
    <h3 class="h-example">例2</h3>
    数値を昇順に並べ替え
</div>
<iframe width="100%" height="250" src="//jsfiddle.net/vbpwr6fn/1/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

[5, 3, 10, 6, 55] → [3, 5, 6, 10, 55]　のように、数値が昇順に並べ替えられました。

#### 降順で並べ替え
次は、降順でソートします。降順でソートするには、引数の比較関数を降順になるように指定します。
```
return b - a;
```

次のプログラムで確認してみましょう。

<div class="box-example">
    <h3 class="h-example">例3</h3>
    数値を降順に並べ替え
</div>
<iframe width="100%" height="250" src="//jsfiddle.net/1x0o2w9t/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

[5, 3, 10, 6, 55] → [55, 10, 6, 5, 3]　このようにして降順にソートすることができました。



## オブジェクトの「sort()」について ##{#p5}
この章では、配列に格納されたオブジェクトのソート方法について見ていきます。　主に、オブジェクトのプロパティを活用した並び替え手法について学んでいきます。

### オブジェクトのキーを使ったソート（並び替え）の方法
配列に格納されたオブジェクトの構造は「連想配列」とも呼ばれたりしますが、このオブジェクトをソートするにはどうすれば良いでしょうか？　実は基本的なソート方法はこれまでとほとんど同じです。

しかし、注目すべきはオブジェクトの構造にあり、一般的に「プロパティ: 値」という形式になっています。このプロパティを利用して「sort()」メソッドで並び替えを行うのがポイントなのです。

次のような構造の配列があるとします！
```
var lists = [
  {name: 'メロン', price: 500},
  {name: 'バナナ', price: 100},
  {name: 'スイカ', price: 280},
  {name: 'イチゴ', price: 300}
];
```
これは複数のオブジェクトが格納された配列ですが、例えば「name」プロパティを使って名前を昇順で並び替えてみましょう！

<div class="box-example">
    <h3 class="h-example">例4-1</h3>
    オブジェクトの並べ替え（昇順）
</div>
<iframe width="100%" height="370" src="//jsfiddle.net/y2gwb96r/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

「a.name > b.name」のようにプロパティを比較することで、並び替えを実現しているわけです。実行結果を見ると果物の名称が昇順で並び替えられているのが分かります。

##### 実行結果
```js
[
	{name: 'メロン', price: 500},
	{name: 'バナナ', price: 100},
	{name: 'スイカ', price: 280},
	{name: 'イチゴ', price: 300}
]
　　　↓ nameをキーに昇順で並べ替え
[
	{name="イチゴ", price=300}, 
	{name="スイカ", price=280}, 
	{name="バナナ", price=100},
	{name="メロン", price=500}
]
```
また、降順で並べ替える場合は、下記のように &gt; を逆にします。
```
if (a.name < b.name) {
```
<div class="box-example">
    <h3 class="h-example">例4-2</h3>
    オブジェクトの並べ替え（降順）
</div>
<iframe width="100%" height="370" src="//jsfiddle.net/8Luny16e/2/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

次は、価格（price）で並べ替えてみましょう。

<div class="box-example">
    <h3 class="h-example">例5-1</h3>
    価格（price）の高い順に並べ替える。
</div>
<iframe width="100%" height="370" src="//jsfiddle.net/efjcnt96/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

反対に価格（price）の低い順に並べ替える。

<iframe width="100%" height="370" src="//jsfiddle.net/1bh029tz/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>



今度は別の簡単なデータを使って、日付順に並べ替えてみます。

<div class="box-example">
    <h3 class="h-example">例5-2</h3>
    日付（date）の新しい順に並べ替える。
</div>

<iframe width="100%" height="370" src="//jsfiddle.net/r76v90qc/2/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>




## 「sort()」の破壊的メソッドについて ##{#p6}
sortメソッドは元の配列を変更してしまう破壊的メソッドなので、使うときには注意してください。元の配列を残しておきたい場合には、sliceで配列のコピーを作成します。

次のプログラムで確認してみましょう。
<div class="box-example">
    <h3 class="h-example">例6</h3>
    元の配列を残しておきたい場合
</div>
<iframe width="100%" height="370" src="//jsfiddle.net/47qcs8g3/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## 応用 ##{#p7}

<div class="box-example" markdown="1">
### 例7 ### {.h-example}
オブジェクトの並べ替えで昇順、降順でそれぞれ表示
[sample(sort)1](../../../../sample/jquery/sample(sort)1/index.html?target=_blank)
</div>
<iframe width="100%" height="570" src="//jsfiddle.net/wk2exhg6/2/embedded/result,js/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<div class="box-example" markdown="1">
### 例8 ### {.h-example}
オブジェクトをname値をキーにして、ボタンでアルファベット順に並べ替え
[【sample(sort)2】](../../../../sample/jquery/sample(sort)2/index.html?target=_blank)
</div>
<iframe width="100%" height="570" src="//jsfiddle.net/aLyheckm/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


### リストからデータを作成

<div class="box-example" markdown="1">
### 例9 ### {.h-example}
[sample(sort)3](../../../../sample/jquery/sample(sort)3/index.html?target=_blank)
</div>
<iframe width="100%" height="570" src="//jsfiddle.net/f7dLhqa5/1/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>









