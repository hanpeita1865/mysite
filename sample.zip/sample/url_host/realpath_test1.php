<?php
var_dump( realpath("../") );
?>
