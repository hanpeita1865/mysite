//マークダウン読み込み
export function markedConfig() {

    let t = 0;

    //目次を配列に格納
    let head2Text = [];
    let headNum2 = 0;
    let head3Text = [];
    let headNum3 = 1;
    let headData = [];
    // let pageMokuArray = [];//カテゴリートップ用目次

    $('#text-markdown h2, #text-markdown h3').each(function () {

        if ($(this).prop("tagName") == "H2") {
            //H2見出し
            headNum2++;
            let h2Text = $(this).text(); //見出し名取得
            let chap = 'chapter' + headNum2; //見出しidに使う数字
            headNum3 = 1;
            $(this).attr('id', chap); //見出しid名
            head2Text.push(h2Text); //見出しを配列に格納
            headData.push({
                selector: "h2",
                text: h2Text,
                chapter: chap
            });

        } else {
            //H3見出し
            let h3Text = $(this).text(); //見出し名取得
            let chap = 'chapter' + headNum2 + '-' + headNum3; //見出しidに使う数字
            $(this).attr('id', chap); //見出しid名
            headData.push({
                selector: "h3",
                text: h3Text,
                chapter: chap
            });
            headNum3++;
        }
    });

    let mokujiList;
    const listMax = 20;
    let turmH2 = 20;
    let over = 0;
    let turnH2;

    Object.keys(headData).forEach(function (key) {
        if (headData[key].selector == 'h2') {
            if (key > headData.length / 2 && over == 0) {
                 over = 1;
                turnH2 = key;
            }
        }
    });


    if (head2Text.length != 0) { //h2の見出しがある場合、目次生成
        $('#text-markdown').before('<div id="mokuji"></div>');
        $('#mokuji').prepend('<h2 class="parts-guide">目次</h2>');

        //リストの数がMAXを超えたら、2列にする。
        if (headData.length > listMax) {
            $('#mokuji').append('<div class="mokuji-box"><ul id="list-mokuji1"></ul><ul id="list-mokuji2"></ul></div>');
            
            for (var i = 0; i < turnH2; i++) {
                if (headData[i].selector == 'h2') {
                    //H2目次リスト
                    $('#list-mokuji1').append('<li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li>');

                } else if (/-1$/.test(headData[i].chapter)) {
                    //H3目次リスト先頭
                    $('#list-mokuji1 > li:last-child').append('<ul><li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li></ul>');

                } else {
                    //H3目次リスト 2番目以降
                    $('#list-mokuji1 > li:last-child ul').append('<li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li>');
                }
            }

            //リスト数がturnH2から2列目のリストに挿入
            for (var i = turnH2; i < headData.length; i++) {
                if (headData[i].selector == 'h2') {
                    //H2目次リスト
                    $('#list-mokuji2').append('<li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li>');

                } else if (/-1$/.test(headData[i].chapter)) {
                    //H3目次リスト先頭
                    $('#list-mokuji2 > li:last-child').append('<ul><li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li></ul>');

                } else {
                    //H3目次リスト 2番目以降
                    $('#list-mokuji2 > li:last-child ul').append('<li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li>');
                }
            }

        } else {

            $('#mokuji').append('<ul id="list-mokuji" class="mokuji-list"></ul>');

            for (var i = 0; i < headData.length; i++) {

                if (headData[i].selector == 'h2') {
                    //H2目次リスト
                    $('#list-mokuji').append('<li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li>');

                } else if (/-1$/.test(headData[i].chapter)) {
                    //H3目次リスト先頭
                    $('#list-mokuji > li:last-child').append('<ul><li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li></ul>');

                } else {
                    //H3目次リスト 2番目以降
                    $('#list-mokuji > li:last-child ul').append('<li><a href="#' + headData[i].chapter + '">' + headData[i].text + '</a></li>');
                }
            }
        }
    }


    $('#text-markdown a').each(function () {
        //「http」か「https」のとき、target="_blank"を設定
        let href = $(this).attr('href'); //aのhrefの値
        switch (true) {
            case /^http:|^https:/.test(href):
                $(this).attr('target', '_blank');
                //外部リンクにアイコンを付ける(任意)「file_icon newtab-icon」のクラスをサイト用のに変更する
                if (!$(this).children('img').length && !$(this).find('button').length) {
                    $(this).addClass('file_icon newtab-icon');
                }

                break;
                //ファイルリンクのとき、target="_blank"を設定
            case /.xls$|.xlsx$|.pdf$|.doc$|.zip$|.txt$|.pptx$/.test(href):
                $(this).attr('target', '_blank');

                break;
        }

        if($(this).hasClass('image')){
            $(this).attr('data-group', 'gallery');
        }
    });


    //配下のページの目次挿入
    if(pageMokuArray.length && $('.auto-mokuji').length){
        $('.auto-mokuji').html('<ol></ol>');

        pageMokuArray.forEach(function(value){
            let subHtml = '';

            if(value.sub != undefined){
                //サブページがある場合
                value.sub.forEach(function(e){
                    subHtml += '<li><a href="'+e.link+'">'+e.title+'</a></li>';
                });
                subHtml = '<ul>' + subHtml + '</ul>';
            }
            //ページに目次挿入
            $('.auto-mokuji ol').append('<li><a href="'+value.link+'">'+value.title+'</a>'+subHtml+'</li>');
        })
    }
}