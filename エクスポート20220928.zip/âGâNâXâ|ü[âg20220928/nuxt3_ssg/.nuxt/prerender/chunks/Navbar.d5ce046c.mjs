import { a as _export_sfc, _ as __nuxt_component_0$1 } from './server.mjs';
import { withCtx, createTextVNode, useSSRContext } from 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/vue/index.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'file://C:/Users/hirao/Desktop/test/nuxt3-ssg/node_modules/vue/server-renderer/index.mjs';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(`<div${ssrRenderAttrs(_attrs)}><nav class="navbar navbar-expand-lg bg-light"><div class="container-fluid">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "navbar-brand",
    to: "#"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Navbar`);
      } else {
        return [
          createTextVNode("Navbar")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<div class="collapse navbar-collapse" id="navbarNavAltMarkup"><div class="navbar-nav">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "nav-link",
    activeClass: "active",
    "aria-current": "page",
    to: "/"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Home`);
      } else {
        return [
          createTextVNode("Home")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "nav-link",
    activeClass: "active",
    to: "/secondpage"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Second Page`);
      } else {
        return [
          createTextVNode("Second Page")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "nav-link",
    activeClass: "active",
    to: "/fishdata"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Fish Data`);
      } else {
        return [
          createTextVNode("Fish Data")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div></nav></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Navbar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=Navbar.d5ce046c.mjs.map
