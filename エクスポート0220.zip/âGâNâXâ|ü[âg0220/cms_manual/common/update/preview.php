<!DOCTYPE html>
<html lang="ja">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title> | プレビュー</title>
	<link rel="stylesheet" href="../../css/bootstrap.min.css">
	<link rel="stylesheet" href="../../css/highlight-origin.css">
	<!--ハイライトの背景色 白-->
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.5.1/styles/default.min.css">
	<link rel='stylesheet' href='../../css/simplebar.css'>
	<link rel="stylesheet" href="../../css/fork-awesome.min.css">
	<link rel="stylesheet" href="../../css/modaal.css">
	<link rel="stylesheet" href="../../css/style.min.css">
</head>

<body class="pages">
	<header>
		<!--案件サイトのヘッダーを記入-->
	</header>
	<main class="preview">
		<div id="content" class="container-fluid">
			<nav id="sidebar">
				<div id="header-wrapper">
					<p class="white">プレビュー</p>
				</div>
				<div id="menu-wrap">
					<ul id="menu" class="side-link">
					</ul>
				</div>
			</nav>
			<div id="body">
				<h1 id="title-p" class="heading1"><span><?= $_REQUEST['pagename-p'] ?></span></h1>
				<div id="text-markdown" class="text-markdown">
				<!-- マークダウンのコードを変換して、ここに挿入 -->
				<?php
					require_once "../php/Parsedown.php";//Parsedownを読み込み
					require_once "../php/ParsedownExtra.php";//Extraを読み込み

					//$md = file_get_contents("markdown.md");//マークダウンの内容を変数に格納
					$report = $_REQUEST['report-p'];//記事原文

                    $html = md2html($report);

					print $html;//HTML表示

					function md2html($md){
						$Extra = new ParsedownExtra();
						$html = $Extra->text($md);
						return $html;
					}
				?>

				</div>
				<!--パーツページ用のトップへ戻るボタンは、必要なければ削除する -->
				<p id="parts-pagetop">
					<a href="#top"><span class="sr-only">このページの先頭へ</span></a>
				</p>
			</div>
		</div>
	</main>
	<footer>
		<!--案件サイトのフッターを記入-->
	</footer>
	<script src="../../js/jquery.min.js"></script>
	<script src="../../js/bootstrap.bundle.min.js"></script>
	<!--<script src="../js/marked.js"></script>-->
	<script src="../../js/highlight.pack.js"></script>
	<script src='../../js/simplebar.min.js'></script>
	<script src="../../js/script.js"></script>
	<script>
		$(function () {
			//コードをハイライト
			$('pre').each(function (i, block) {
				if ($(this).children('code').length) {
					hljs.highlightBlock(block);
				}
			});

			//画像のパス変更
			$('#text-markdown img').each(function() {
				let src = $(this).attr('src');
				$(this).attr('src', '../../pages/<?= $_REQUEST["folder-p"] ?>/' + src);
				//figureWrap($(this));
			});

			$('#text-markdown a').each(function() {
				let href = $(this).attr('href');
				if( /^(?!.*(^http:|^https:)).+$/.test(href)){
					$(this).attr('href', '../../pages/<?= $_REQUEST["folder-p"] ?>/' + href);
				}
			});
			
			//ページトップボタン
			//初期は非表示
			$("#parts-pagetop").hide();

			$(window).scroll(function () {
				//140pxスクロールしたら
				if ($(this).scrollTop() > 140) {
					//フェードインで表示
					$('#parts-pagetop').fadeIn();
				} else {
					//フェードアウトで非表示
					$('#parts-pagetop').fadeOut();
				}
			});

			function figureWrap(e) {
				var clsName = e.closest('div').prop('class');

				if( /^photo/.test(clsName) && e.closest('a').length == 0) {
					if(e.parent()[0].tagName=='P') {
						e.unwrap();
					}
					e.wrap('<figure>');

				} else if(/^photo/.test(clsName) && e.closest('a').length > 0) {
					if(e.parents('a').parent()[0].tagName=='P') {
						e.parents('a').unwrap();
					}
					e.parent('a').wrap('<figure>');

				} else if(e.closest('a').length == 0) {
					if(e.parent()[0].tagName=='P') {
						e.unwrap();
					}
					e.wrap('<figure>');


				} else if(e.closest('a').length > 0) {
					if(e.parents('a').parent()[0].tagName=='P') {
						e.parents('a').unwrap();
					}
					e.wrap('<figure>');

				}
			}
		});
	</script>
</body>

</html>