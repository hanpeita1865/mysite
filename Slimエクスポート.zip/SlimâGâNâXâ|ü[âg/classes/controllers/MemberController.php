<?php
namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Container\ContainerInterface;

require '../admin/basepath.php';

class MemberController {
    // コンテナインスタンス
    private $container;

    // コンストラクタ
    public function __construct(ContainerInterface $container) {
        // 引数のコンテナインスタンスをプロパティに格納。
        $this->container = $container;
    }


    //マークダウン変換
     public function markData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        global $basePath;
        global $folderName;

        try {
            //PDOインスタンスをコンテナから取得
            $db = $this->container->get("db");

            $ipAddress = $_SERVER["REMOTE_ADDR"];//取得したIPアドレス
            $folderName = basename($_SERVER['REQUEST_URI']);//フォルダ名


            //URL中のパラメータを取得
            $folder = $args["folderName"];//フォルダ名を取得

            $assign["folder"] = $folder;//配列に格納

            if(empty($_SERVER['HTTP_REFERER'])){
                //echo '未定義';
                $motourl = '../pages/p__base/';
            }else{
                $motourl = $_SERVER['HTTP_REFERER'];//遷移元のURL
            }

            //locklistテーブルにページが存在するかチェック
            $sql_page = $db->prepare('select * from locklist where page=?');
            $sql_page->execute([$folderName]);

            $countPage=$sql_page->rowCount();//0は、誰でも閲覧可能

            //admin_ipにIPアドレスが存在するかチェック
            $sql_ip = $db->prepare('select * from admin_ip where ip_address=?');
            $sql_ip->execute([$ipAddress]);

            $countIp=$sql_ip->rowCount();//1は、ロックしたページでも閲覧可能

            //閲覧不可ページリスト
            $stmt = $db->prepare('select page from locklist');
            $stmt->execute();
            $lockArray = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $assign["lockArray"] = $lockArray;

            $assign["countIp"] = $countIp;

            //ロックしたページでかつユーザーのIPがadmin_ipテーブルにない場合、閲覧不可にする処理
            if($countPage!=0 && $countIp==0 ) {
                header('Location:'. $motourl, true, 307);
                $flag = 0;//閲覧不可
                exit;
            }

            //フォルダ構成をオブジェクトで取得
            $folderObj = $this->container->get("folderComp");

            //マークダウン変換インスタンスをコンテナから取得
            $markData = $this->container->get("mark");

            $htmlData = $markData['html'];//HTMLデータ
            $title = $markData['title'];//タイトル

            $assign["folderObj"] = $folderObj;//フォルダ構成オブジェクト
            $assign["htmlData"] = $htmlData;//記事内容
            $assign["title"] = $title;//タイトル格納
            
            $templatePath = "base.twig";
        }
        //例外処理
        catch (PDOException $ex) {

            //障害メッセージを作成
            $assign["errorMsg"] = "データベース処理に失敗しました。もう一度始めからやり直してください。";
            //表示先テンプレートをエラー画面に変更。
            $templatePath = "error.twig";

        } finally {
            //DB切断。
            $db = null;
        }
            //ディレクトリ名を格納
            $assign["pathBase"] = $basePath;
            // Twigインスタンスをコンテナから取得。
            $twig = $this->container->get("view");
            // memberAdd.htmlをもとにしたレスポンスオブジェクトを生成。
            $response = $twig->render($response, $templatePath, $assign);

        // レスポンスオブジェクトをリターン。
        return $response;
    }


    //管理画面
    public function adminData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        // Twigインスタンスをコンテナから取得。
        $twig = $this->container->get("view");

        $menuData = file_get_contents('./../templates/layouts/menu_list.twig');

        $assign["menuData"] = $menuData;//メニューリスト
        
        // templateのadmin.twigからを管理画面を生成。
        $response = $twig->render($response, "admin.twig", $assign);     

        return $response;
    }


    //編集画面
    public function editData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        global $basePath;
        global $folderName;

        $ipAddress = $_SERVER["REMOTE_ADDR"];//取得したIPアドレス
        $folderName = basename($_SERVER['REQUEST_URI']);//フォルダ名

        //PDOインスタンスをコンテナから取得
        $db = $this->container->get("db");
        $sql_ip=$db->prepare('select * from admin_ip where ip_address=?');
        $sql_ip->execute([$ipAddress]);

        $countIp=$sql_ip->rowCount();

        try{
            //例外判定
            if( $countIp==0 ){
                throw new Exception('管理者以外は編集できません');
            }else{

                $folderName = basename($_SERVER['REQUEST_URI']);//フォルダ名

                //フォルダ構成をオブジェクトで取得
                $folderObj = $this->container->get("folderComp");
                $folderDir = $folderObj[$_REQUEST['folder']];

                if(empty($_SERVER['HTTP_REFERER'])){
                    //echo '未定義';
                    $motourl = '../p__base/';//修正予定
                }else{
                    $motourl = $_SERVER['HTTP_REFERER'];//遷移元のURL
                }

                $mkData = file_get_contents($folderDir.'/markdown.md');
                // $mkData = htmlspecialchars($mkData, ENT_QUOTES);

                // Twigインスタンスをコンテナから取得。
                $twig = $this->container->get("view");

                $filelist = $this->container->get("fileIcon");

                // print_r($filelist);

                $assign["pathBase"] = $basePath;
                $assign["mkData"] = $mkData;
                $assign["edit"] = $_REQUEST['edit'];
                $assign["folder"] = $_REQUEST['folder'];
                $assign["folderPath"] = $_REQUEST['folderPath'];
                $assign["scroll"] = $_REQUEST['scroll'];
                $assign["motourl"] = $motourl;
                $assign["fileList"] = $filelist;
                $assign["folderDir"] = $folderDir;
                
                // templateのbase.twigからをHTMLを生成。
                $response = $twig->render($response, "edit.twig", $assign);

                return $response;
            }
        
        }catch(Exception $ex){
            echo $ex->getMessage();
            // header('Location:'. $motourl); //遷移元かトップに戻る
            exit;
        }

        return $response;
    }

    //テスト
    public function testData(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

		$content = "レスポンスボディに文字列を格納";
		$responseBody = $response->getBody();
		$responseBody->write($content);

        return $response;
    }

    //フォルダ新規作成
    public function folder_create(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        global $basePath;
        $newFolder = $_POST['post_newFolder'];
        $basePath = $basePath.'/public/';
        $menuCode = '';
        global $db;


        //半角英数字記号かを判定
        if(preg_match("/^[!-~]+$/", $newFolder) ){
            $pagesGlob = glob('../pages/*');
            $num = sprintf('%03d', count($pagesGlob)+1);//番号を3桁に変更　例)01
        
            mkdir('../pages/'.$num.'.'.$newFolder);
            mkdir('../pages/'.$num.'.'.$newFolder.'/upload');
            file_put_contents( '../pages/'.$num.'.'.$newFolder.'/markdown.md', '*[page-title]:メニュー名');
        
            echo 'フォルダを新規作成しました。';

            $db = $this->container->get("db");

            $menuCode = $this->container->get("menuComp");
            file_put_contents("../templates/layouts/menu_list.twig", $menuCode);

        }else{
            echo '半角英数字記号で入力してください。';
        }

        return $response;
    }


    //メニュー名変更
    public function file_rename(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        global $basePath;
        $post_menu = $_POST['post_menu'];//変更前のメニュー名
        $post_reMenu = $_POST['post_reName'];//変更後のメニュー名
        $post_dir = $_POST['post_dir'];//パス 例) {{basePath}}pages/winKey111/
        $post_dirName = $_POST['post_dirName'];//パス（番号付き）例) 02.winKey111
    
        $basePath = $basePath.'/public/';
    
        //「menu_list.twig」のメニュー名の変更処理
        $menu = file_get_contents('../templates/layouts/menu_list.twig');
    
        $post_dir_re = str_replace($basePath,'', $post_dir);
        $post_dir_esc = preg_quote( $post_dir , '/');//エスケープ処理
        $post_menu = preg_quote( $post_menu );//エスケープ処理
       
        $menuRe = preg_replace('/(.*)'.$post_dir_esc.'(.*)'.$post_menu.'(.*)/i',  '$1'.$post_dir.'$2'.$post_reMenu.'$3', $menu);
    
        file_put_contents('../templates/layouts/menu_list.twig', $menuRe);
    
        // //「markdown.md」のtitle値の変更処理
        $md = file_get_contents('../pages/'.$post_dirName.'/markdown.md'); //マークダウンの内容を変数に格納
    
        preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);//マークダウン内のタイトル名を配列に格納
    
        if(!empty($ArrayTitle[1])){
            $md = preg_replace("/^\*\[page-title\]:\s*(.+)/", '*[page-title]:'.$post_reMenu, $md);//タイトル名を変換
            file_put_contents('../pages/'.$post_dirName.'/markdown.md', $md);//マークダウンを保存
        }else{
            //マークダウン内にtitleがない場合、新規に追加
            file_put_contents('../pages/'.$post_dirName.'/markdown.md', '*[page-title]:'.$post_reMenu."\n\n".$md);
        }
    
        echo 'メニュー名を「'.$post_reMenu.'」に変更しました。';

        return $response;
    }

    
    //フォルダ名変更
    public function folder_rename(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        $post_dir = $_POST['post_dir'];
        $post_redir = $_POST['post_redir'];
        $post_name = $_POST['post_folderName'];
        $post_rename = $_POST['post_folderReName'];
        $content = '';
        
        //半角英数字記号かを判定
        if(preg_match("/^[!-~]+$/", $post_redir) ){
            //フォルダ名変更
            rename('../pages/' . $post_dir, '../pages/' . $post_redir);
            //メニューのフォルダ名変更
            $menu = file_get_contents('../templates/layouts/menu_list.twig');
        
            $menu_re = preg_replace('/'.$post_name.'\/"(.*)>/i', $post_rename.'/"$1>', $menu);
            file_put_contents('../templates/layouts/menu_list.twig', $menu_re);

            //DB locklistテーブル変更
            $db = $this->container->get("db");
        
            $sql=$db->prepare('select * from locklist where page=?');
            $sql->execute([$post_name]);
            $lockCnt=$sql->rowCount();
            
            if($lockCnt){
                $result = $sql->fetch(PDO::FETCH_ASSOC); 
                $sql=$db->prepare('update locklist set page=? where id_lock=?');
    
                if($sql->execute([$post_rename, $result['id_lock']])){
                    echo 'データを変更しました。';
                }else{
                    $content = 'テーブル修正に失敗しました。'."\n";
                }
            }         
        
            $content = $content."フォルダ名を変更しました。";

        }else{
            $content ="半角英数字記号で入力してください。";
        }

		$responseBody = $response->getBody();
		$responseBody->write($content);
        
        return $response;
    }


    //ロック設定・解除
    public function page_lock(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        
        $db = $this->container->get("db");

        $sql=$db->prepare('select * from locklist where page=?');
        $sql->execute([$_REQUEST['post_folder']]);
        
        $lockCnt=$sql->rowCount();
        
        if($lockCnt){
            //リストに有り（削除）
            $sql=$db->prepare('delete from locklist where page=?');
            if ($sql->execute([$_REQUEST['post_folder']])) {
                $content = '削除に成功しました。';
            } else {
                $content = '削除に失敗しました。';
            }
        
        }else{
            //リストになし（追加）
            $sql=$db->prepare('insert into locklist values(null, ?)');
            if ($sql->execute([$_REQUEST['post_folder']])) {
                $content = '追加に成功しました。';
            } else {
                $content = '追加に失敗しました。';
            }
        }

		$responseBody = $response->getBody();
		$responseBody->write($content);

        return $response;
    }


    //フォルダのリスト取得
    public function folder_list(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        $content = $this->container->get("folderList");

		$responseBody = $response->getBody();
		$responseBody->write($content);

        return $response;
    }


    //並べ替え確定（構成フラットから新しいフォルダ構成作成）
    public function sort_complete(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        global $basePath;
        $basePath = $basePath.'/public/';
        $menuCode = '';
        global $db;

        $this->container->get("frat_create");//pages_copyへフラットフォルダ構成の生成
        sleep(5); 
        $this->container->get("create");//pagesに再生成したフォルダ構成の作成

        //メニュー生成
        $db = $this->container->get("db");
        $menuCode = $this->container->get("menuComp");
        file_put_contents("../templates/layouts/menu_list.twig", $menuCode);

        return $response;
    }


    //lockデータ削除
    public function lockdata_del(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        $db = $this->container->get("db");
        $sql=$db->prepare('select * from locklist where page=?');
        $sql->execute([$_POST['post_delFolder']]);
        
        $lockCnt = $sql->rowCount();

        if($lockCnt){
            //リストに有り（削除）
            $sql=$db->prepare('delete from locklist where page=?');
            if ($sql->execute([$_POST['post_delFolder']])) {
                echo '削除に成功しました。';
            } else {
                echo '削除に失敗しました。';
            }      
        }

        return $response;
    }


    //削除したフォルダをゴミ箱(trush)に移動
    public function trush(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {

        $res = glob('../pages_copy' . '/*'); 
        date_default_timezone_set('Asia/Tokyo');//日本時間にセット
        $dateTime = date('Y-m-d_H.i.s');
        
        sleep(3);

        foreach ($res as $item) {
            mkdir('../trush/'.$dateTime);//削除日時フォルダ
            $itemRe = str_replace('pages_copy', 'trush'.'/'.$dateTime, $item);
        
            if (rename($item, $itemRe)) {
                //移動しました。
            }
        }

        return $response;
    }


    //フォルダ構成をメニューに反映
    public function folder_complist(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        global $basePath;
        $basePath = $basePath.'/public/';
        $menuCode = '';
        global $db;

        //メニュー生成
        $db = $this->container->get("db");
        $menuCode = $this->container->get("menuComp");
        file_put_contents("../templates/layouts/menu_list.twig", $menuCode);

        return $response;
    }

    //ホームページ テスト
    public function homepage(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        global $basePath;
        $basePath = $basePath.'/public/';

        return $response;
    }

    //編集画面を表示
    public function page_update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        global $basePath;
        $basePath = $basePath.'/public/';

        return $response;
    }

    //フォルダ削除テスト
    public function folderDelTest(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        global $basePath;
        global $deldir;
        global $delFolder;
        global $dateTime;

        $basePath = $basePath.'/public/';

        $folderObj = $this->container->get("folderDelTest");
        $delFolder = $folderObj[$_POST['folderName']];//削除するフォルダのパス

        $this->container->get("subpage_move");//テスト

        // //trushフォルダに移動
        // $deldir = glob($delFolder . '/*'); //削除するディレクトリ内のフォルダとファイル
        // date_default_timezone_set('Asia/Tokyo');//日本時間にセット
        // $dateTime = date('Y-m-d_H.i.s');

        // mkdir('../trush/'.$dateTime);//削除日時フォルダ

        // $del = $this->container->get("del_trush");





        // foreach ($res as $item) {
        //     mkdir('../trush/'.$dateTime);//削除日時フォルダ
        //     $itemRe = str_replace('pages_copy', 'trush'.'/'.$dateTime, $item);
        
        //     if (rename($item, $itemRe)) {
        //         //移動しました。
        //     }
        // }

        // $content = $_POST['folderName'];

		// $responseBody = $response->getBody();
		// $responseBody->write($content);

        return $response;
    }

    //pagesをtempにバックアップ
    public function backup(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        global $basePath;
        $basePath = $basePath.'/public/';

        $this->container->get("pages_backup");
        return $response;
    }
}