*[page-title]:セクション4（関数）


## 38.ファンクション(関数)を作って処理をまとめよう

$prefと$colorのforeachでの処理が同じようになっているので、関数を使って処理をまとめていきます。

```
<?php
// 連想配列を受け取って、リストにして出力する
function make_list($list) {
    foreach ($list as $key => $value) {
        echo '・ ', $key, '：', $value, "\n";
    }
}

$pref = [
    'hokkaido' => '北海道',
    'aomori' => '青森県',
    'iwate' => '岩手県'
];

// foreach ($pref as $pref_code => $pref_name) {
//     echo '・', $pref_code, '：', $pref_name, "\n";
// }

make_list($pref);

$color = [
    'red' => '赤',
    'blue' => '青',
    'black' => '黒'
];

// foreach ($color as $color_code => $color_name) {
//     echo '・', $color_code, '：', $color_name, "\n";
// }

make_list($color);
```


> このように処理を関数でまとめておくと、例えば文字間の記号を「：」から「-」に変更したいとき簡単にできます。  
> これからプログラムを組むときには、これは関数でまとめられるのではないかというこを考えながらやっていくといいです。


## 39.「返り値」のあるファンクションを作ろう

参考サイト
: [number_format](https://www.php.net/manual/ja/function.number-format.php)

```
<?php
// 足し算をするファンクション
function sum($num1, $num2) {
    $answer = $num1 + $num2;



    return $answer;
    echo '画面に表示しました';

}

$item_sum = sum(167, 269);
echo $item_sum;
```



## 40.パラメーターを複数指定できるようにしよう-可変パラメーター

```
<?php
// 合計を計算する
function sum($param1, ...$numbers) {
    $answer = 0;
    foreach ($numbers as $num) {
        $answer += $num;
    }

    return $answer;
}

$item_sum = sum('param1', 10, 20, 30, 40, 50, 60, 70, 80, 90, 100);
echo $item_sum;
```

> 関数の引数の頭に「...」を付けることで配列として扱うことができるようになり、指定した数だけパラメータが入ってくるようになります。

> 注意する点として、可変パラメータのあとに別の引数を追加することはできません。function sum( ...$numbers, $param1)のように書くとエラーになります。  
> 可変パラメータの前に置くのは、問題ありません。 



##  41.省略できるパラメーターを作ろう-デフォルト引数


```
<?php
// リストを作る
function make_list($list, $head = '・') {
    foreach ($list as $key => $val) {
        echo $head, $key, ': ', $val, "\n";
    }
}

$pref = [
    'hokkaido' => '北海道',
    'aomori' => '青森県',
    'iwate' => '岩手県'
];

make_list($pref);
make_list($pref, '→');
make_list($pref, '> ');
```

例えば関数に($list, $head = '・')と記述すれば、パラメータを省略することができます。省略した場合、$headには「・」が入り、パラメータを指定すればそのパラメータが$headに入ります。


## 42.変数をそのままファンクションに渡そう-リファレンス渡し

```
<?php
// $color = ['黒', '赤', '白'];
// array_shift($color);
// print_r($color);

// $price = 10000;
// $new_price = number_format($price);
// echo $price;
// echo "\n";
// echo $new_price;

// 配列の先頭に文字をつなげる
function add_head(&$target) {
    for ($i=0; $i<count($target); $i++) {
        $target[$i] = '●' . $target[$i];
    }
}

$color = ['黒', '赤', '白'];
print_r($color);
add_head($color);
print_r($color);
add_head($color);
print_r($color);
```

> number_formatは、元の値をよこさずそのまま残ります【値渡し】。  
> arrray_shiftの場合は、元の値を加工してしまいます。【リファレンス渡し（参照渡し）】

> 引数に「&」を付けるとリファレンス渡しになります。例. add_head(<span class="red">&</span>$target)    
> 配列でリファレンス渡しをすることが、稀にあります。念のため、この方式を覚えておくとよいでしょう。

## 43.変数のスコープとglobal宣言

```
<?php
$tax = 10; // 消費税

// 足し算の結果を返す。消費税を加える
function sum($a, $b) {
    global $tax;
    $ret = ($a + $b) * ($tax / 100 + 1);
    
    return $ret;
}

$num1 = 100;
$num2 = 200;

$answer = sum($num1, $num2);
echo $answer;
```

> 基本的に「{}中括弧」の中で宣言した変数は、中括弧の中だけで有効となり、中括弧の外で宣言した変数は、中括弧の外でだけ有効となります。

> 外で宣言した変数をfunction内などのスコープ外で使用したい場合は、<span class="bold red">global</span>という宣言を付けると使用できるようになります。パラメータで渡す必要がなくなります。  
> パラメータで渡す方が良いか、globalで渡す方が良いかは、変数の内容によって変わってきます。



## 44.ファンクションやパラメーターに型を指定しよう

```
<?php
declare(strict_types=1);
$tax = 10; // 消費税

// 足し算の結果を返す。消費税を加える
function sum(int $a, int $b): int {
    global $tax;
    $ret = ($a + $b) * ($tax / 100 + 1);
    
    return $ret;
}

$num1 = '100';
$num2 = 200;

$answer = sum($num1, $num2);
echo $answer;
```

> 自分が作った関数パラメータに入力する値に整数や文字列などと制限を付けいて、それを他の人がわかるようにするときに、引数にintゃstringをつけてやります。  
> 　例. unction sum(<span class="bold red">int</span> $a, <span class="bold red">int</span> $b)  
> 返り値にも型を設定できます。  
> 　例. function sum(int $a, int $b)<span class="bold red">: int</span>

> PHPでは自動型変換という機能があり、「$num1 = '100';」と記述しても整数値としてくれます。便利な反面エラーの原因になったりします。  
> それを防止するのに型を厳密にする方法として先頭に「<span class="bold red">declare(strict_types=1);</span>」を宣言します。



## 45.無名関数(クロージャー)とは

```
<?php
// function sum(int $a, int $b): int {
//     return $a + $b;
// }

// 数字を成型して表示する
function echo_price($callback) {
    echo number_format($callback(1000, 500)), '円';
}

// クロージャー・無名関数
// $get_sum = function ($a, $b) {
//     return $a + $b;
// };

$get_sum = fn($a, $b) => $a + $b;

$sum = $get_sum(10, 35);
echo $sum;
// echo_price(function ($a, $b) {
//     return $a + $b;
// });
```

> 無名関数を定義した場合、}のあとに;セミコロンを付ける必要があります。

> 他の関数のパラメーターを指定するときに、無名関数はよく使われます。直接パラメータに無名関数を書くこともできます。


## 46.外部のファイルを読み込もう-include/require

<p class="lang">4-9_include.php</p>
```
<?php
function sum($a, $b) {
    return $a + $b;
}
```

```
<?php
// require '4-9_include.php';
require_once '4-9_include.php';

// include
//include_once

echo 'こんにちは';
```

> require_onceは、一回呼び出したらもう呼び出さないという命令になります。特別な理由がない限り、require_onceを使うとよいでしょう。

> includeはそのファイルが存在するか判定したりするときに、使用したりします。




