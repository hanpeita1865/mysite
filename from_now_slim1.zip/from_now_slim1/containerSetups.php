<?php
use DI\Container;
use Slim\Factory\AppFactory;
use Slim\Views\Twig;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

$basePath = '/from_now_slim1';

$container = new Container();
$container->set("view",
    function() {
        global $basePath;
        $twig = Twig::create($_SERVER["DOCUMENT_ROOT"].$basePath."/templates");
        return $twig;
    }
);
$container->set("logger",
    function() {
        global $basePath;
        $logger = new Logger("slimmiddle");
        $fileHandler = new StreamHandler($_SERVER["DOCUMENT_ROOT"].$basePath."/logs/app.log");
        $logger->pushHandler($fileHandler);
        return $logger;
    }
);

//PDOインスタンスを生成する処理　追加箇所
$container->set("db",
    function(){
        //DB接続情報を表す変数
        $database='from_now';
        $dbUsername = "staff";
        $dbPassword = "password";

        //PDOインスタンスを生成。DB接続
        $db=new PDO('mysql:host=localhost;dbname='.$database.';charset=utf8',$dbUsername, $dbPassword);//MySQLに接続

        //PDOエラー表示モードを例外モードに設定
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //プリペアドステートメントを有効に設定
        $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        //フェッチモードをカラム名のみの結果セットに設定
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        //PDOインスタンスをリターン
        return $db;
    }
);


$folderObj = [];//ディレクトリ格納用オブジェクト

//フォルダ構成をオブジェクトで取得
$container->set("folderComp",
    function(){
        global $folderObj;
        globAll('../pages');
        // print_r($folderObj);//「〇〇.」ディレクトリオブジェクト
        return $folderObj;
    }
);


//マークダウン変換
$container->set("mark",
    function(){
        require_once("../php/Parsedown.php");
        require_once("../php/ParsedownExtra.php");

        global $basePath;
        global $folderObj;
        global $folder;
        // print_r($folderObj);

        $folderUri = basename($_SERVER['REQUEST_URI']);//例）base
        // print_r($folderUri);

        $folderPath = $folderObj[$folderUri];//例）../pages/01.base
        // print_r($folderPath);

        $Extra = new ParsedownExtra();

        //マークダウンファイル取得
        $md = file_get_contents($_SERVER["DOCUMENT_ROOT"].$basePath.'/pages/'.$folderPath.'/markdown.md');


        //ページタイトル取得
        preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);
        $title = $ArrayTitle[1];//ページタイトル
        // print_r($title);

        //HTMLに変換
        $htmlData = $Extra->text($md);

		//画像のパスを変換
		$htmlData = preg_replace('/<img(.*)src="upload\/(.*)"(.*)>/i', '<img $1 src="'.$basePath.'/pages/'.$folderPath.'/upload/$2"$3>', $htmlData);
		//ファイルリンクのパスを変換
		$htmlData = preg_replace('/<a(.*)href="upload\/(.*)"(.*)>/i', '<a $1 href="'.$basePath.'/pages/'.$folderPath.'/upload/$2"$3>', $htmlData);

        $markArray = ['html'=> $htmlData, 'title'=> $title];

        return $markArray;
    }
);


function globAll($folder) {
    global $folderObj;

    if (!is_file($folder)) {
        $res = glob($folder . '/*'); 

        foreach ($res as $key => $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の頭の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{2}./', $lastDir)) {
                $folderNoNum = preg_replace('/^\d{2}./','', $lastDir);
                $folderObj[$folderNoNum] = $f;//「〇〇.」ディレクトリをオブジェクトに格納
   
                globAll($f);
            }
        }
    }
}


AppFactory::setContainer($container);