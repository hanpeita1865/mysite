---
title: bindParam、password_verify
---

参考サイト
: [PHPでbindparamを使う方法を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/29052)
: <https://homework.hatenablog.jp/entry/2017/02/15/092946>

## bindparamとは

PHPのbindParam()関数は、プリペアドステートメントで使用するSQL文の中で、プレースホルダーに値をバインドするための関数です。  
bindParam()関数は、値の参照を受け取るという点と、execute()関数を使用した際にバインドが確定するという点で、bindValue()関数と異なります。  
プリペアドステートメントとは、SQL文をあらかじめ用意しておいて、その後はクエリ内のパラメータの値だけを変更してクエリを実行できる機能のことです。

<p class="tmp"><span>書式</span></p>
```
bindParam ($パラメータID, $バインドする変数 [, $PDOデータ型定数[, $PDOデータ型の長さ[, $ドライバーオプション]]] )
```

第一引数には、パラメータIDを使用します。これは、プレースホルダーの種類によって指定方法が異なります。  
もし、プレースホルダーが「?」を使用する、「疑問符プレースホルダー」の場合、パラメータIDには1から始まる整数値で「?」の位置を指定します。  
もし、プレースホルダーが「:id」など、名前で指定する「名前つきプレースホルダー」の場合、パラメータIDにはプレースホルダーと同じ:idなどの文字列で指定します。

第二引数には、バインドする変数を渡します。  
第三引数は、オプションで、バインドする値に対して明示的にデータ型を指定することができます。指定する場合は、「PDO::PARAM_* 定数 」を使用します。デフォルトでは、「PDO::PARAM_STR」がセットされています。  
第四引数には、オプションで、バインドする値のデータ型の長さを指定することができます。値がストアドプロシージャからの OUT パラメータであることを示す場合、 明示的に長さを設定しなければなりません。

第五引数には、オプションで、ドライバー固有のオプションを渡すことができます。 例としては、「UTF-8 でエンコードされた文字列として列を変数にバインドする」などのドライバーオプションが存在します。  
返却値は、バインドに成功した場合、bool値のTRUEが、失敗した場合には、bool値のFALSEが返却されます。


## プリペアドステートメント

PHPではprepare()関数を使用することで、プリペアドステートメントを使用できます。
```
<?php
$userName = 'mysql';
$password = 'mysql';
// PDOオブジェクトの生成（DB接続）
$pdo = new PDO('mysql:dbname=test;host=localhost', $userName, $password);

// プリペアドステートメントで SQLをあらかじめ用意しておく
$stmt = $pdo->prepare('select * from user where id = ? and name = ?');
```
prepare()関数を使用するためには、まずPDOオブジェクトを生成する必要があります。

PDOオブジェクトを生成時にDB接続情報を渡すことで、対象のDBに対してSQLを実行できるようになります。

prepare()関数の()内が、プリペアドステートメントによるSQLです。$pdo->prepare()とすることで、接続したDBに対して実行するプリペアドステートメントのSQLをセットします。

プリペアドステートメントの「?」の部分は、プレースホルダーと呼ばれるものです。

bindParam()関数を使用することで、このようなプレースホルダーに値をバインドさせることができるので、条件が動的なSQLをアプリケーションから実行できます。


## bindvalueの場合
bindValue()関数の場合は、関数に値を渡したタイミングでバインドが評価されます。
```
$stmt->bindValue(1, $id, PDO::PARAM_INT);
$stmt->bindValue(2, $name);
```

## bindparamの使い方

bindParam()関数の場合は、クエリを実行する関数execute()が実行されるまで、バインドが評価されません。  
そのため、一度bindParam()関数に変数を渡しても、execute()が実行される前に変数の値が変更されると、その変更した値がexecute()の実行時のクエリに反映されます。

<p class="tmp list"><span>リスト</span></p>
```
// 値をバインド
$id = 1;
$name = '田中太郎';
$stmt->bindParam(1, $id, PDO::PARAM_INT);
$stmt->bindParam(2, $name);

// クエリを実行（$id, $nameの中身をバインド）
$stmt->execute();

// 値の変更
$id = 2;
$name = '鈴木一郎';

// クエリを実行（$id, $nameの中身をバインド）
$stmt->execute();
```

## password_verify

<p class="tmp"><span>書式</span>password_verify書き方</p>
```
password_verify(パスワード,ハッシュ値)
```

### 解説
password_verify()のカッコ内に引数を指定することで、password_verify 関数を利用することが可能です。

引数とは、関数を利用する際に指定する値です。引数を変化させることで、柔軟に関数を操作することが可能です。

パスワードには、使用したパスワードを指定します。変数に代入したものを使用しても良いです。ハッシュ値には、password_hash() 関数で生成したハッシュ値を指定します。変数に代入したものを使用しても良いです。

パスワードとハッシュが適合する場合に TRUE、それ以外の場合に FALSE を返します。返すというのはプログラミング用語です、一般的な表現でいうと、結果を取得するというイメージです。


#### サンプルコード
password_verifyメソッドで、「rasmuslerdorf」をハッシュ化した値と、$hashに格納した値を比較しています。  
一致していれば、trueが返ります。不一致だとfalseを返します。
```
<?php
$hash = '$2y$07$BCryptRequires22Chrcte/VlQH0piJtjXl.0t1XkA8pw9dMXTpOq';

if (password_verify('rasmuslerdorf', $hash)) {
	echo '正しい！';
} else {
	echo '違う';
}
?>
```

















