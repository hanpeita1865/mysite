<footer>
		<div class="container">
			<p class="text-center">Copyright © Webst8 All Rights Reserved.</p>
		</div>
	</footer>
	
	<?php wp_footer(); ?>
</body>
</html>