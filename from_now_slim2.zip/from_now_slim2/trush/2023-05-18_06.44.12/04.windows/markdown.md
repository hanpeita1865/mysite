*[page-title]:Windows機能

## Windows起動時に指定したアプリを起動

参考サイト
: [Windowsのスタートアップとは？アプリの追加・削除の設定方法や注意点](https://hanjo.biglobe.ne.jp/it/office8/#:~:text=%EF%BC%92%EF%BC%8E%E3%82%B9%E3%82%BF%E3%83%BC%E3%83%88%E3%82%A2%E3%83%83%E3%83%97%E3%81%AE%E3%82%A2%E3%83%97%E3%83%AA%E3%82%92,%E3%82%A2%E3%83%97%E3%83%AA%E3%81%AF%E3%82%AA%E3%83%95%E3%81%AB%E3%81%97%E3%81%BE%E3%81%99%E3%80%82)
: [起動時に自動実行する処理を設定(スタートアップ)](https://webbibouroku.com/Blog/Article/windows-startup)

ショートカットを作成したら、画面左下の［スタート］ボタンから［設定］＞［スタートアップ］の順にクリックします。 ここでWindows起動時に自動で立ち上げるアプリを選択できます。 自動で立ち上げたいアプリはオンに、立ち上げる必要のないアプリはオフにします。

または、Win + R を押下して「ファイル名を指定して実行」を開きます。そこで shell:startup を入力するとエクスプローラーでスタートアップフォルダを開きます。
![](upload/win-startup-01.png)

## One Drive 停止や解除方法

<https://windowsfaq.net/windows/one-drive/to-release/>