<?php

require 'database_pass.php';

$pdo=new PDO('mysql:host=localhost;dbname='.$database.';charset=utf8',$user, $password);

$stmt = $pdo->prepare('select page from locklist');
$stmt->execute();
$lockData = $stmt->fetchAll(PDO::FETCH_COLUMN);



globAll('../pages');

function globAll($folder) {

    global $lockData;

    if (!is_file($folder)) {

        $res = glob($folder . '/*'); 

        foreach ($res as $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{2}./', $lastDir)) {

                $path = str_replace('../pages/','', $f).'/';//リストのパス

                // print_r($path);

                $pathRe = preg_replace('/^\d{2}./','',$path);
                $pathRe = preg_replace('/\/\d{2}./','/',$pathRe);

                // print_r($path);

                $md = file_get_contents($f.'/markdown.md'); //マークダウンの内容を変数に格納
                if(preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle)){
                    $title = $ArrayTitle[1];
                }

                $lastDir = preg_replace('/^\d{2}./', '',$lastDir);

                if(in_array($lastDir, $lockData)) {
                    //ロックあり
                    echo '<li id="item" class="box-item"><a href="{{basePath}}pages/'.$pathRe.'" class="lock">'.$title.'</a>';
                }else{
                    //ロックなし
                    echo '<li id="item" class="box-item"><a href="{{basePath}}pages/'.$pathRe.'">'.$title.'</a>';
                }

                //ディレクトリ($f)内にpフォルダがあるか判定
                $res1 = glob($f . '/*');
                $pBool = false;
                foreach ($res1 as $f1) {
                    $dirArray1 = explode('/', $f1);
                    $lastDir1 = end($dirArray1);
                    if (preg_match('/^\d{2}./', $lastDir1)) {
                        $pBool = true;
                    }
                }

                if($pBool){
                    echo "\r\n".'<ul class="sub-menu">'."\r\n";
                }

                globAll($f);

                if($pBool){
                    echo '</ul>'."\r\n";
                }

                echo '</li>'."\r\n";
            }
        }
    }
}
?>