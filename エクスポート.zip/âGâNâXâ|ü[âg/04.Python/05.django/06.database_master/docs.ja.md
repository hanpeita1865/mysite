---
title: データベースを更に極める
media_order: 'record_sort1.png,record_sort2.png,record_filter1.png,record_sum.png,sql_query1.png,sql_record_all1.png,sql_record_where1.png,sql_record_like1.png,sql_record_where2.png,sql_record_where3.png,sql_record_where4.png'
taxonomy:
    category:
        - docs
---

## レコードの並べ替え

レコードの並べ替えは、Managerクラスの「**{c:red}order by{/c}**」というメソッドで行えます。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">レコードの並べ替え（基本）</span></p>

	《モデル》.objects.《allやfilterなど》.order_by( 項目名 )

order_byは、allやfilterなど複数レコードを取得するメソッドの後に続けて記述します。  
引数には、並べ替えの基準となる項目の名前を指定します。  
これは、複数を指定することもできます。  
例えば、('name','mail')と引数を指定すれば、まずname順で並べ替え、同じnameのものがあった場合はそれらをmail順で並べ替えるようにできます。

### 年齢順で並べ替える

「hello」フォルダ内のviews.pyを開き、そこにあるindex関数を下のように書き換えて下さい。

<p class="mb-05"><span class="tmp list">リスト4-1</span><span class="bold">views.pyのindex関数を編集</span></p>

    def index(request):
        data = Friend.objects.all().order_by('age')    #☆
        params = {
                'title': 'Hello',
                'message':'',
                'data': data,
            }
        return render(request, 'hello/index.html', params)

ここでは、order_by('age')とメソッドを追記してあります。  
これで、レコードをage順に並べ替えるようになります。 ついでに、テンプレートも少し修正しておきましょう。  
「template」フォルダ内の「hello」フォルダ内にあるindex.htmlを開き、&lt;body&gt;タグの部分を以下のように書き換えて下さい。


<p class="mb-05"><span class="tmp list">リスト4-2</span><span class="bold">index.htmlの&lt;body&gt;タグを編集</span></p>
    
    <body>
        <h1>{{title}}</h1>
        <p>{{message|safe}}</p>
        <table>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>age</th>
                <th>mail</th>
                <th>birthday</th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item.id}}</td>
                <td>{{item.name}}</td>
                <td>{{item.age}}</td>
                <td>{{item.mail}}</td>
                <td>{{item.birthday}}</td>
            <tr>
        {% endfor %}
        </table>
    </body>


今までオブジェクトをそのまま表示していたためちょっとわかりにくかったので、レコードの全値をテーブルを表示する形に改めました。  
「hello」にアクセスしてください。レコードがageの小さいものから順に並べ替えられているのがわかります。

![](record_sort1.png?classes=caption "図　アクセスすると、ageの小さいものから順に並べ替えて表示される")


### 逆順はどうする?

order byメソッドには、逆順に並べ替える機能はありません。  
常に昇順で並べ替えます。

逆順にするには、「**並び順を逆にするメソッド**」を使います。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">逆順のの並べ替え</span></p>

《allやfilterなど》.order_by( 項目名 ).reverse()

このようにすると、指定した項目で逆順に並べ替えることが出来ます。  
最後の「**{c:red}reverse{/c}**」というメソッドが、並び順を逆にするためのものです。

先ほど修正したindex関数を少し書き換えて、逆順にしてみましょう。

<p class="mb-05"><span class="tmp list">リスト4-3</span><span class="bold">index関数を編集</span></p>

    def index(request):
        data = Friend.objects.all().order_by('age').reverse()    #☆
        params = {
                'title': 'Hello',
                'data': data,
            }
        return render(request, 'hello/index.html', params)
        
「hello」にアクセスすると、今度はageの大きいものから順に並べ替えられています。

![](record_sort2.png?classes=caption "図　アクセスすると、年齢(age)の大きいものから順に表示される")





## 指定した範囲のレコードを取り出す

レコードの数が多くなってくると、「全部表示する」とはいかなくなってきます。  
全体の中から一部のものだけを取り出して表示する必要が出てくるでしょう。  
allやfilterなどで取り出されるのは、QuerySetというクラスのインスタンスです。  
これは、その後に[] 記号を使って取り出す位置を指定することができます。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">指定した範囲の抽出</span></p>

	《QuerySet》[開始位置 : 終了位置]

![](record_filter1.png?classes=caption "図　[] を使うことで、特定の範囲のレコードを取り出すことができる。")



### 位置を指定して取り出してみる

今回は、findページを利用します。  
「hello」フォルダ内のviews.pyを開き、find関数を以下のように書き換えて下さい。

<p class="mb-05"><span class="tmp list">リスト4-4</span><span class="bold">views.pyのfind関数を編集</span></p>

    def find(request):
        if (request.method == 'POST'):
            msg = 'search result:'
            form = FindForm(request.POST)
            str = request.POST['find']
            list = str.split()
            data = Friend.objects.all()[int(list[0]):int(list[1])]    #☆
        else:
            msg = 'search words...'
            form = FindForm()
            data =Friend.objects.all()
        params = {
            'title': 'Hello',
            'message': msg,
            'form':form,
            'data':data,
        }
        return render(request, 'hello/find.html', params)
        

### find.htmlを修正しよう

ついでに、テンプレートの表示も修正しておきましょう。  
「template」フォルダ内の「hello」フォルダ内にあるfind.htmlを開き、<body>タグの部分を以下のように書き換えて下さい。

<p class="mb-05"><span class="tmp list">リスト4-5</span><span class="bold">find.htmlの&lt;body&gt;タグの部分を編集</span></p>
    
    <body>
        <h1>{{title}}</h1>
        <p>{{message|safe}}</p>
        <table>
            <form action="{% url 'find' %}" method="post">
            {% csrf_token %}
            {{form}}
            <tr><th></th><td><input type="submit" value="click"></td></tr>
            </form>
        </table>
        <hr>
        <table>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>age</th>
                <th>mail</th>
                <th>birthday</th>
            </tr>
        {% for item in data %}
            <tr>
                <td>{{item.id}}</td>
                <td>{{item.name}}</td>
                <td>{{item.age}}</td>
                <td>{{item.mail}}</td>
                <td>{{item.birthday}}</td>
            <tr>
        {% endfor %}
        </table>
    </body>


修正したら、「hello/find」にアクセスして下さい。  
そして入力フィールドに「2 5」というように、開始位置と終了位置を半角スペースで区切って記述し、送信します。  
これで、指定した範囲のレコードだけが表示されるようになります。

図　入力フィールドに「2 5」とすると、id=3～5のレコードが表示されます。テーブルの状態によって取り出されるIDなどは変わることもあるので注意。
    


### レコード検索の流れ

ここでは、ifでPOST送信されたかどうかをチェックし、送信された場合には、テキストを分割してリストにします。これは既にお馴染みの処理ですね。

    str = request.POST['find']
    list = str.split()

そして、送られた値を元にallで得た中から指定範囲のレコードだけを取り出します。

	data = Friend.objects.all()[int(list[0]:int(list[1])]

送信されたlist[0]からlist[1]までの範囲に絞り込んでいるのがわかるでしょう。　　
ただし、この[]で指定する値は整数値でなければいけません。　　
テキスト値ではエラーになります。


## レコードを集計するには?

多量の数値データなどを扱う場合、保存してある値を取り出すだけでなく、必要なレコードの値を集計処理することもよくあります。　　
こういうときは、必要なレコードをallやfilterで取り出し、そこから値を順に取り出して集計し計算する、というのが一般的でしょう。　　
が、例えば「合計」や「平均」などの一般的な集計ならば、もっと簡単な方法があります。　　
集計用の関数を使い、「**{c:red}aggregate{/c}**」というメソッドで集計を行わせるのです。これは、以下のように利用します。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">集計用の関数</span></p>
    
	変数 = 《モデル》.objects.aggregate( 変数 )

引数には、django.db.modelsに用意されている集計用の関数を記述します。 
これは、以下のようなものがあります。

|  |  |
|--|--|
|Count(項目名)|	指定した項目のレコード数を返します。|
|Sum(項目名)|	指定した項目の合計を計算します。|
|Avg(項目名)|	指定した項目の平均を計算します。|
|Min(項目名)|	指定した項目から最小値を返します。|
|Max(項目名)|	指定した項目から最大値を返します。|


これらの関数を、aggregateの引数に指定して呼び出すことで、簡単な集計を行うことができるのです。

    
### ageの集計をしてみる

今回も、indexページを修正して使うことにします。  
「hello」フォルダ内のviews.pyを開き、index関数を以下のように書き直してください。


<p class="mb-05"><span class="tmp list">リスト4-6</span><span class="bold">views.pyのindex関数を編集</span></p>
    
	from django.db.models import Count,Sum,Avg,Min,Max

    def index(request):
        data = Friend.objects.all()
        re1 = Friend.objects.aggregate(Count('age'))    #☆
        re2 = Friend.objects.aggregate(Sum('age'))    #☆
        re3 = Friend.objects.aggregate(Avg('age'))    #☆
        re4 = Friend.objects.aggregate(Min('age'))    #☆
        re5 = Friend.objects.aggregate(Max('age'))    #☆
        msg = 'count:' + str(re1['age__count']) \
                + '<br>Sum:' + str(re2['age__sum']) \
                + '<br>Average:' + str(re3['age__avg']) \
                + '<br>Min:' + str(re4['age__min']) \
                + '<br>Max:' + str(re5['age__max'])
        params = {
                'title': 'Hello',
                'message':msg,
                'data': data,
            }
        return render(request, 'hello/index.html', params)


![](record_sum.png?classes=caption "図　ageのレコード数、合計、平均、最小値、最大値といったものを表示する")



今回は、集計用の関数を利用するため、最初の
    
**{c:red}from django.db.models import Count,Sum,Avg,Min,Max{/c}**
    
という文を必ず追記しておいて下さい。  
「hello」にアクセスすると、ageの**レコード数**、**合計**、**平均**、**最小値**、**最大値**を表示します。  
こうした集計処理が非常に簡単に行えることがわかります。
ここでの集計処理を行っている部分を見てみましょう。


    re1 = Friend.objects.aggregate(Count('age'))
    re2 = Friend.objects.aggregate(Sum('age')) 
    re3 = Friend.objects.aggregate(Avg('age')) 
    re4 = Friend.objects.aggregate(Min('age')) 
    re5 = Friend.objects.aggregate(Max('age'))

aggregateメソッドの引数に、Count、Sum、Avg、Min、Maxといった関数を指定しています。  
これで値が取り出せます。  
ただし、得られるのは整数値ではありません。辞書の形になっているため、そこから値を取り出す必要があります。


    msg = 'count:' + str(re1['age__count']) \
            + '<br>Sum:' + str(re2['age__sum']) \
            + '<br>Average:' + str(re3['age__avg']) \
            + '<br>Min:' + str(re4['age__min']) \
            + '<br>Max:' + str(re5['age__max'])


<p>re1['age__count']というようにして値を取り出しています。<br>
Count('age')による値は、'age__count'という値として保管されています。<br>
得られる値は、以下のような名前になっているのです。</p>

<p class="mb-05"><span class="tmp">書式</span><span class="bold">得たい値の書き方</span></p>
    
	'項目名__関数名'

項目名と、使用した関数名を半角アンダースコア2文字でつないだ名前になります。  
なお、得られる値は整数値なので、ここではテキストに変換して利用しています。

    
## SQLを直接実行するには?

Djangoでは、filterを使ってたいていの検索は行えるようになっています。  
が、本格的なアプリ開発で、非常に複雑な検索を行う必要があるような場合、filterを組み合わせてそれを実現するのはかなり大変かも知れません。  
そういうときは、「**SQLのクエリを直接実行する**」という技が用意されています。  
SQLデータベースは、SQLのクエリ（要するにコマンド）でデータベースとやり取りしますから、Djangoの中から直接SQLクエリを実行できれば、どんなアクセスも思いのままというわけです。  
これには、Managerクラスに用意されている「**{c:red}raw{/c}**」というメソッドを使います。  
Managerというのは、モデルのobjectsに設定されているオブジェクトでしたね。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">SQLのクエリ</span></p>
    
	変数 =《モデル》.objects.raw( クエリ文 )

このように、引数にSQLクエリのテキストを指定して実行することで、それを実行した結果を受け取ることが出来ます。


![](sql_query1.png?classes=caption "図　SQLクエリを引数にしてrawメソッドを呼び出すと、そのSQLクエリがそのままSQLデータベースに送られて実行される")    



### findを修正しよう

実際にSQLクエリを実行できるサンプルを作ってみましょう。  
findページを利用することにします。  
「hello」フォルダ内のviews.pyを開き、find関数を以下のように書き換えて下さい。


<p class="mb-05"><span class="tmp list">リスト4-7</span><span class="bold">views.pyのfind関数を編集</span></p>
    
    def find(request):
        if (request.method == 'POST'):
            msg = request.POST['find']
            form = FindForm(request.POST)
            sql = 'select * from hello_friend'
            if (msg != ''):
                sql += ' where ' + msg
            data = Friend.objects.raw(sql)
            msg = sql
        else:
            msg = 'search words...'
            form = FindForm()
            data =Friend.objects.all()
        params = {
            'title': 'Hello',
            'message': msg,
            'form':form,
            'data':data,
        }
        return render(request, 'hello/find.html', params)

「hello」にアクセスして、まず何も入力せずに実行すると、全レコードが表示されます。  
これでデータベースアクセスそのものはちゃんと動いているのが確認できます。
    
![](sql_record_all1.png?classes=caption "図　何も入力せずに実行すると、全Friendレコードを表示する。")




### SQL文実行の流れ

ここでどうやってSQLクエリを実行しているのか見てみましょう。  
まず、ifを使ってPOST送信されているのかをチェックし、変数sqlにアクセスするSQLクエリ文を用意します。

	aql = 'select * from hello_friend'

この文は、全レコードを取り出す処理です。  
フォームから何かテキストが送信されてきた場合は、このSQLクエリの後に更に文を追加します。

        if (msg != ''):
            sql += ' where ' + msg

先ほどのテキストの後に、'where 〇〇'という形でテキストを追加します。  
後で説明しますが、これで検索の条件などを設定できるようにしているのです。

	data = Friend.objects.raw(sql)

最後に、完成した変数sqlを引数にしてrqwメソッドを呼び出せばそのSQLクエリが実行されるというわけです。



## SQLクエリを実行しよう

### テーブル名は「hello_friend」

ここでは、何もテキストを入力していない場合も、変数sqlに以下のようなテキストを設定していました。

	select + from hello_friend

hello_friendは、テーブルの名前です。  
ここまで、「Friendのテーブル名はfriendsだ」と説明してきました。  
adminによる管理ツールでも、friendsと表示されていましたね。  
ところが、実際にデータベースに作成されているテーブル名は、「hello_friend」だったのです。  
Djangoでは、マイグレーションを使ってテーブルの生成を行う場合、以下のような形でテーブルの名前が設定されます。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">テーブルの生成</span></p>
    
	アプリ名_モデル名

ここでは、「hello」というアプリに「Friend」モデルを作成して利用しています。  
ということは、データベースに実際に保存されているテーブルは「hello_friend」というものになるのです。


### select文が検索の基本

ここで実行しているのは、「select」文と呼ばれるもので、SQLクエリでレコードを検索する際の基本となるものです。  
これは以下のような形をしています。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">select文</span></p>
    
	select 項目名 from テーブル名

selectの後には、値を取り出す項目の指定を用意します。  
全部の項目を取り出すなら、「*」という記号を指定します。  
つまり、hello_friendテーブルのレコードを全部取り出すなら、以下になります。

	select + from hello_friend


### whereで条件を指定する

では、作成したフィールドに中に書いて実行してみましょう。  
例として、「id=1」とフィールドに書いて実行してみて下さい。  
ID番号が1番のレコードが表示されます。

![](sql_record_where1.png?classes=caption "図　「id=1」と実行すると、ID番号が1番のレコードが表示されます。")


何かのテキストを記入すると、「where」というものが追加されます。  
これは以下のように利用します。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">where</span></p>
    
	select 項目 from テーブル where 条件

whereの後に、検索の条件を指定します。  
これによって、その条件に合うレコードだけを探して取り出すことが出来ます。  
Djangoのfilterに相当するものをイメージすればいいでしょう。


### 基本的な検索条件

基本的な条件の式について簡単にまとめておきましょう。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">完全一致</span></p>
    
	項目名 = 値

指定した値と完全に一致するものだけを検索するには、イコール記号を使います。


<p class="mb-05"><span class="tmp">書式</span><span class="bold">あいまい検索</span></p>
    
	項目名 like 値

テキストの「あいまい検索」は、「**{c:red}like{/c}**」という記号を使います。  
ただしlikeを指定しただけでは検索できません。  
テキストの前後に「**{c:red}%{/c}**」という記号を付けて、「ここにはどんなテキストも入ってよし」ということを指定します。
    
例えば、「name like '%a'」とすれば、名前が「a」で終わるレコードをすべて検索します。  
ただし「a」の後にテキストがあるものは検索されません。

![](sql_record_like1.png?classes=caption "図　name like '%a'とすると、aで終わるものを検索できます。")




<p class="mb-05"><span class="tmp">書式</span><span class="bold">数字の比較</span></p>
    
    項目名 &lt; 値
    項目名 &lt;= 値
    項目名 &gt; 値
    項目名 &gt;= 値

数字の値は、&lt;&gt;=といった記号を使って値を比較することができます。
例えば、「age &lt;= 30」とすれば、ageの値が20以下のものを検索できます。

![](sql_record_where2.png?classes=caption "図　age&lt;=30で、ageの値が20以下のものを検索できます。
")


<p class="mb-05"><span class="tmp">書式</span><span class="bold">AND/OR検索</span></p>
    
    式1 and 式2
    式1 or 式2


「age &gt; 30 and age &lt; 50」とすると、ageの値が30より大きく50より小さいものだけを検索します。

![](sql_record_where3.png)
図　age &gt; 30 and age &lt; 50で、ageの値が30より大きく50より小さいものだけを検索します。


### 並べ替えと範囲指定

検索条件の他にもSQLにはさまざまなものが用意されています。  
ここでは比較的多用される「並べ替え」と「範囲の指定」に関するものを紹介しておきます。

<p class="mb-05"><span class="tmp">書式</span><span class="bold">並べ替え</span></p>
    
    where 〇〇 order by 項目名
    where 〇〇 order by 項目名 desc

並べ替えは、whereによる検索の後に「desc」をつけると、逆順に並べ替えることができます。

![](sql_record_where4.png?classes=caption "図　age &lt; 40 order by age descとすると、ageが40未満のものをageの大きいものから順に並べ替える")

<p class="mb-05"><span class="tmp">書式</span><span class="bold">範囲の指定</span></p>

	where 〇〇 limit 個数 offset 開始位置

取り出すレコードの位置と個数を設定するものです。  
「limit」は、その後に指定した数だけレコードを取り出します。  
例えば、「limit 3 offset 2」とすると、最初から2つ移動した位置（つまり3番目）から3個のレコードを取り出します。


図　「id>0 limit 3 offset 2」とすると、最初から3番目のレコードから3個を取り出します。


## SQLは非常手段

説明してなんですが、SQLクエリは、「なるべく使わない」ようにしましょう。  
理由はいくつかありますが、その最大のものは「Pythonのスクリプトの中に、Python以外のコードが含まれてしまう」という点です。  
Pythonのスクリプトは、Pythonだけで出来ていた方がメンテナンス性もよくなります。  
Pythonのスクリプトなのに、それ以外の要素が書かれているというのは非常にスクリプトの見通しを悪くします。

また、SQLクエリは、「方言」があるのです。  
すなわち、データベースによって微妙に使用が違っているんですね。  
このため、SQLクエリを直接実行するようにプログラムを作っていると、データベースを変更した途端に「動かない!」となることもあるのです。  
そもそも、「SQLのようなややこしいものを使わないで、Pythonですっきりとデータベースアクセスが行える」というのが、モデル利用の利点だったはずです。  
SQLクエリの利用は、モデルの基本的な設計思想に反するやり方といえるでしょう。  
ですから、これは「どうしても他のやり方ができないときの非常手段」と考えておきましょう。







