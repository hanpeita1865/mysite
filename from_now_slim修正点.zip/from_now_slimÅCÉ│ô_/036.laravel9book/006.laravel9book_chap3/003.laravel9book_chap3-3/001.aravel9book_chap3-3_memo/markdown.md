*[page-title]:Chpa3-3 メモ

## jsのファイルを追加する方法

下記のjsを追加する場合、resources/js/ディレクトリ内にファイルを格納します。

<p class="tmp list"><span>リスト</span>resources/js/custom.js</p>
```
document.querySelector('.three-reader').addEventListener('click', function(){
    console.log('クリックしたよー');
});
```

次に、resources/js/app.jsに追加したファイルをインポートするコードを記入します。
<p class="tmp list"><span>リスト</span>resources/js/app.js</p>
```
import './bootstrap';
import './custom';//追加

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
```

ビルドを実行します
<p class="tmp cmd"><span>コマンド</span>ビルド</p>
```
sail npm run build
```
![](upload/sail_npm_run_build.png)

そうすると、新しいapp.jsとapp.cssが出力されます。
![](upload/新しいapp.jsが出力.png){.photo-border}

出力されたapp-BO0_rWlk.jsのコードを確認すると、custom.jsのコードが入っているのが確認できます。
![](upload/console(クリックしたよ).png "app-BO0_rWlk.js"){.fig-top}

これで自分が投稿したつぶやきの3点リーダーをクリックすると、コンソールに「クリックしたよー」が表示されるようになりました。
![](upload/custom_jsクリックしたよ.png){.photo-border}