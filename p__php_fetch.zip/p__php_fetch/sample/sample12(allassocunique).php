<?php

try {

  $pdo = new PDO('sqlite:db/fetch_db.sqlite3');

  $sql = 'SELECT id, users.* FROM users';
  $sth = $pdo -> query($sql);
  $result = $sth -> fetchAll(PDO::FETCH_ASSOC|PDO::FETCH_UNIQUE);

  print_r('<pre>');
  print_r($result);
  print_r('</pre>');
  
} catch (Exception $e) {
    error_log('障害が発生しており、ご迷惑をおかけしています。');
}

?>