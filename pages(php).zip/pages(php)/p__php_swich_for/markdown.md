*[page-title]:switch文、for文

## switch文
<p class="tmp"><span>書式1</span></p>
※javascriptと書き方は同じ

```
switch ( 式 ) {
//式が値と合致したときに処理を行い、どれにも合致しなかった場合defaultの処理を行う。
case 値1 :
	処理;
	break;
case 値2 :
	処理;
	break;
default :
	処理;
	break;
}
```

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	<iframe src="https://paiza.io/projects/e/6pbgbwq3qmfG-_0zrmcQIA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例2</span>breakを付けずに OR条件での分岐</p>
	該当したcaseから、次のbreakまでは処理が実行される性質を利用し、いずれかに該当した場合といった条件分岐もできます。
<iframe src="https://paiza.io/projects/e/pTiN9H-yQyI8XIKUvWdYfg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>


## for文

<div class="exp">
	<p class="tmp"><span>例3</span></p>
	$iが0から始まり、5になるまで処理を繰り返す。
	<iframe src="https://paiza.io/projects/e/BwN2YzyA15GCOf0SWbVv4g?theme=twilight" width="100%" height="300" scrolling="no" seamless="seamless"></iframe>
</div>

### break処理

<div class="exp">
	<p class="tmp"><span>例4</span></p>
	$1が3になったら、処理を終了させます。
	<iframe src="https://paiza.io/projects/e/j9Eut6nRhmfRvhC1x6IqaQ?theme=twilight" width="100%" height="300" scrolling="no" seamless="seamless"></iframe>
</div>


### break処理のネストでの動作結果

参考サイト
: [【PHP入門】ループをbreakで終了する(foreach, for, while)](https://www.sejuku.net/blog/22128)

* break 1;または、break;→第三階層のループのみ終了
* break 2;→第二階層のループが終了
* break 3;→第一階層のループが終了

<div class="exp">
	<p class="tmp"><span>例5</span></p>
	<iframe src="https://paiza.io/projects/e/n6Q6hWLnBC34ozuC2z8zSw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>




