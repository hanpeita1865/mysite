---
title: jquery.cookie.js
media_order: 'open-panel.png,open-panel2.png,cookie1.png,cookie2.png'
taxonomy:
    category:
        - docs
visible: true
---

## jquery.cookie.jsの使い方 ##{.h-type2}

### cookieを保存 ###{.h-type3}
まずは、cookieを保存する方法です。

<p class="tmp"><span>書式</span></p>
<pre>
$.cookie( "cookieの名前" , "値" );
</pre>

これが基本形になります。さらにオプションとして、下記のように保存期間等を指定することができます。

<p class="write">オプション　<span>記入例</span></p>
<pre>
$.cookie( "sample" , "テスト" , { expires: 7 , path: "/", domain: "sample.com" , secure: true }
</pre>
この場合、このようになります。cookie名「sample」に「テスト」という値を保存することになります。で、オプションの部分はこういう感じになります。


| オプション | 機能 |
| -------- | -------- |
| {c:red}expires{/c}  | cookieの保存期限。7の場合は7日間。省略時はブラウザ終了まで有効。|
| {c:red}path{/c}     | cookieを使用するパス。サイト全体で使う場合は’/’を設定。|
| {c:red}domain{/c}   | cookieの有効ドメイン。|
| {c:red}secure{/c}   | セキュア通信時のみ送信。|



### cookieの取得 ###{.h-type3}
次に保存したcookieを取得する方法です。

<p class="tmp"><span>書式</span></p>
<pre>
$.cookie( "cookieの名前" )
</pre>
これで、保存した値が呼び出されます。

### cookieの削除 ###{.h-type3}
最後に保存したcookieを削除する方法です。

<p class="tmp"><span>書式</span></p>
<pre>
$.removeCookie( "cookieの名前" );
</pre>
これで保存したcookieが削除されます。


## jquery.cookie.jsの使用例 ##{.h-type2}

### サンプル① ###{.h-type3}

「クリックで開閉するパネルがあって、ページの更新やページを移動してもパネルの状態が維持される」というのをしてみます。

[jquery cookieを使った開閉状態を維持するパネル](http://js.crap.jp/book/chapter3/jquery-cookie-panel.html?target=_blank)

**HTML**

    <div id="header"><h1>jquery.cookie.jsを使った開閉状態を維持するパネル</h1></div>

    <div id="panel"><p>開いた状態でページ更新しても開いたままです。</p></div>
    <a href="#" id="panel-btn">panel</a>

**JS**

    $(function(){
    
        if($.cookie("open-panel")){ //cookieに「open-panel」があれば、パネルを開いておく
            $("#panel").show();
        }
        
        $("#panel-btn").click(function() {
            if($.cookie("open-panel")){ //パネルが開いた状態でボタンを押すと、パネルが閉じてcookieの「open-panel」が削除される
                $("#panel").slideUp();
                $.removeCookie("open-panel" , { path: "/" }); //cookieの「open-panel」を削除
                
            } else { //パネルが閉じた状態でボタンを押すと、パネルが開きcookieに「open-panel」が追加される
                $("#panel").slideDown();
                $.cookie("open-panel" , "open" , { expires: 7,  path: "/" }); //cookieに「open-panel」を追加
            }
            
            return false; //<a>の遷移を停止
        });
        
    });

**パネルを{c:red}開いたとき{/c}のcookieの中身**
![](open-panel.png)

**パネルを{c:blue}閉じたとき{/c}のcookieの中身**
![](open-panel2.png)

### サンプル② ###{.h-type3}

「カウントアップ」クリックで値をカウントアップし、リロードしても値が保持されます。「リセット」クリックでcookieを削除します。

[jquery.cookie.jsを使ってカウントアップ](https://webdesignday.jp/samples/p3704/chapter01/)



**初期状態のcookieの中身**
![](cookie1.png)

**カウントアップしたときのcookieの中身**
![](cookie2.png)

**HTML**

    <p>「カウントアップ」クリックでカウントアップし、ブラウザを終了しない限り値を維持します。<br>
    「リセット」クリックでcookieを削除します。</p>
    <p>カウント:<span class="js-count-num"></span></p>
    <button class="js-count-btn">カウントアップ</button><button class="js-reset-btn">リセット</button>

**JS**

    $(function(){

        var cookie = $.cookie('cookie'); //cookieにある「cookie」の値を取得
        if(cookie){
            $('.js-count-num').text(cookie); //「cookie」があれば、テキストに「cookie」の値を表示
        }else{
            $('.js-count-num').text(0); //「cookie」がなければ、テキストの値は0を表示させる
        }

        var count = $('.js-count-num').text(); //表示されてるカウント値を変数に格納
        $('.js-count-btn').on('click',function(){ //ボタンを押すと、1カウントされる処理イベント
            count++;
            $.cookie( "cookie",count); //cookieに「cookie」の値にカウントした値を保存
            $('.js-count-num').text(count); //表示テキストにカウント値を設定
        });

        $('.js-reset-btn').on('click',function(){ //リセット処理
            count = 0;
            $.removeCookie( "cookie"); //cookie内の「cookie」を削除
            $('.js-count-num').text(count); //表示カウントを0にする
        });

    });	



## 参考にしたサイト ##{.h-type2 .mt-5}

[jquery.cookie.jsの使い方と簡単なサンプルを紹介します](http://weboook.blog22.fc2.com/blog-entry-404.html)

[【jQuery】サンプル付きで確認！jquery.cookie.jsの使い方 ](https://webdesignday.jp/inspiration/technique/jquery-js/3704/)














