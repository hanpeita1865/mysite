import { Api } from '../api.js';
import { show } from '../modalManager.js';
import { getAdminData } from '../adminData.js';


export function initPageRename({ soating, completeMsg, menu_create, getMenuObj }) {

    document.querySelectorAll('#menu li a').forEach((elm) => {
        elm.addEventListener('click', async (e) => {
            
            const link = e.target.closest('a[data-editable]');

            e.preventDefault();
            
            if (!link) return;

            if (soating()) {
                show('soatWarn');
                return;
            }

            const menuName = e.target.textContent;
            const menuId = e.target.closest('li').getAttribute('id');
            const folderName = e.target.getAttribute('href').split('/').slice(-2)[0];
            const folderDir = e.target.getAttribute('href');

            const menuReName = prompt('名前を変更して「ok」を押してください', menuName);

            if (menuName === menuReName) return;

            if (menuReName === '') {
                alert('ページ名の値が空です');
                return;
            }

            if (menuReName == null) return;

            const menu_obj  = menu_create();
            const dirName = menu_obj[folderName];

            const formData = new FormData();
            formData.append('post_menu', menuName);
            formData.append('post_reName', menuReName);
            formData.append('post_dir', folderDir);
            formData.append('post_dirName', dirName);
            formData.append('eventName', 'ページ名変更');
            formData.append('post_folderName', folderName);
            
            const { adminFull } = getAdminData();

            try {
                const text = await Api.postText(adminFull + 'file_rename', formData);

                if (text.match(/変更しました/)) {
                    completeMsg(text);

                    document.getElementById(menuId)
                        .firstElementChild.textContent = menuReName;

                } else {
                    alert(text);
                }

            } catch {
                alert('ページ名変更に失敗しました。');
            }

        });
    });
}