*[page-title]:11. ミドルウェア


<span class="green bold marker-yellow50">ミドルウェア</span>は、リクエストを受け取るとコントローラ処理の前後に割り込み、独自の処理を追加する仕組みです。このミドルウェアの使い方と開発の方法を覚え、独自のミドルウェアを作成できるようになりましょう。

## ミドルウェアとは？

MVCアーキテクチャーは、モデル・ビュー・コントローラがそれぞれ切り離されています。プログラムの基本部分はコントローラですが、コントローラはそれぞれのアクションごとに処理を用意していきます。これは、個別に処理を作れるという点はよいのですが、「すべてのアクセス時に何かを処理しておく」ということになるとけっこう面倒臭いものになってしまいます。  

例えば、フォームに入力された値をチェックするような仕組みを考えてみましょう。   
フォームをPOST送信したときのアクションで、送られた値を1つずつチェックすることは可能です。が、フォームのあるページが1つでなかったら? 10ページ、あるいは 100ページもあったらどうするのでしょう。全てに1つ1つの値をチェックする処理を書いていくのは、あまり効率的なやり方とは思えませんね。  

そこでLaravelでは、コントローラとは別に、「<span class="marker-yellow50">指定のアドレスにリクエストが送られてきたら、自動的に何らの処理を行う</span>」という仕組みを用意したのです。それが「<span class="green bold marker-yellow50">ミドル ウェア</span>」です。

### ミドルウェアはアプリケーションの前にあるレイヤー
ミドルウェアとは、リクエストがコントローラのアクションに届く前（または後）に配置されるレイヤー層となるプログラムです。  
特定のアドレスにアクセスがあると、Laravelはルート情報を元に指定のコントローラ のアクションを呼び出します。ミドルウェアは、その前に割り込んで、アクションの処理が実行される前（あるいは、後）に、指定の処理を実行させることができます。  

ミドルウェアの設定は、ルート情報を記述する際に指定できます。コントローラのアクションで処理を呼び出しているわけではありません。コントローラと完全に分離しているため、コントローラで行っている処理の内容には左右されません。

![](upload/middle_ware01.png  "図　ミドルウェアは、リクエストがアクションに届く前や後に割り込んで処理を実行する。")


### ミドルウェアを作成する
では、実際にミドルウェアを作成してみましょう。ミドルウェアは、手作業でスクリプトファイルを作成すれば作れますが、例によってArtisanコマンドを使えばもっと快適 に作成することができます。  
簡単なサンプルとして「<span class="red">HelloMiddleware</span>」という名前で作ってみることにしましょう。 コマンドプロンプトまたはターミナルを起動し、コマンドを入力します。
```
php artisan make:middleware HelloMiddleware
```
ミドルウェアの作成は、「<span class="red bold">aritisan make:middlewae ミドルウェア名</span>」という形で実行します。ここでは「HelloMiddleware」という名前で作成をしました。

![](upload/artisan_middleware.png)

![](upload/HellowMiddleware作成.png){.photo-border}

### HelloMiddleware.php を確認する
ミドルウェアは、「Http」内にある「Middleware」というフォルダの中に作成されます。 このフォルダには、既に標準でいくつかのミドルウェアが入っています。ここに、作成したHelloMiddleware.phpも作成されています。

では、このHelloMiddleware.phpを開いてみましょう。すると中には以下のようなスクリプトが記述されています(※コメントは省略してあります)。

<p class="tmp list"><span>リスト1-1</span>HelloMiddleware.php</p>
```
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class HelloMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        return $next($request);
    }
}
```


## HelloMiddlewareクラス

作成されたHelloMiddlewareは、特に何かのクラスを継承しているわけでもない、比較的シンプルなクラスです。ソースコードを見ると、以下のように書かれています。  
```
namespace App\Http\Middleware;
```
「app」内の「Http」フォルダ内にある「Middleware」フォルダの中にスクリプトファイルは置かれます。namespaceを指定しておかないと正しくクラスが利用できないので注意しましょう。

### handle メソッドについて
このHelloMidlewareクラスには、1つだけメソッドが用意されています。「handle」と いうもので、以下のように定義されます。
```
public function handle(Request $request, Closure $next): Response
{
	...... 実行する処理 ......
}
```
第1引数の$requestは、リクエストの情報を管理するRequestインスタンスが渡されます。そして$nextは、Closureクラスのインスタンスです。これは無名クラスを表すため のクラスです。

ここで渡された$nextはクロージャになっており、これを呼び出して実行することでミドルウェアからアプリケーションへと送られるリクエスト（Requestインスタンス）を作成することができます。


## HelloMiddlewareを修正する

では、実際に簡単な処理を作成してみましょう。HelloMiddlewareクラスのソースコードを以下のように修正して下さい(namespace、useは省略してあります)。

<p class="tmp list"><span>リスト2-1</span></p>
```
class HelloMiddleware
{
	 public function handle(Request $request, Closure $next): Response
   {
       $data = [
           ['name'=>'taro', 'mail'=>'taro@yamada'],
           ['name'=>'hanako', 'mail'=>'hanako@flower'],
           ['name'=>'sachiko', 'mail'=>'sachico@happy'],
       ];
       $request->merge(['data'=>$data]);
       return $next($request);
   }
}


//※ミドルウェア記述後、
//「/app/Http/Kernel.php」 内の$routeMiddleware 配列内に以下の文を追記。

//'hello' => \App\Http\Middleware\HelloMiddleware::class,
```

ここでは、handleメソッド内で「merge」というメソッドを呼び出しています。これは 以下のように利用します。
<p class="tmp"><span>書式1</span></p>
```
$request->merge( 配列 );
```

このmergeは、フォームの送信などで送られる値（inputの値）に新たな値を追加するものです。これにより、dataという項目で$dataの内容が追加されます。コントローラ側では、$request->dataでこの値を取り出すことができるようになります。  
記述したら、HelloMiddlewareを登録します。「app」内の「Http」内にあるKernel.phpを 開き、$routeMiddlewareに代入している変数内に以下の文を追加して下さい。

<p class="tmp list"><span>リスト2-2</span>app/Http/Kernel.php</p>
```
'hello' =>\App\Http\Middleware\HelloMiddleware::class,
```

![](upload/Kernel.phpに追加.png "図　Kernel.phpの$middlewareAliasesに追加")
これで<span class="red">HelloMiddleware</span>が登録され、利用可能になります。


## ミドルウェアの実行

作成されたミドルウェアは、それだけではまだ利用することはできません。これを使うには、「<span class="marker-yellow50">利用するミドルウェアを呼び出す処理</span>」の追記が必要になります。これは、ルーティングの際に実行するのが一般的です。  

web.phpを開き、ルート情報にミドルウェアの呼び出し処理を追記しましょう。 Route::getで「/hello_middle」のルート情報を追加してください。

<p class="tmp list"><span>リスト3-1</span>routes/web.php</p>
```
// use App\Http\Middleware\HelloMiddleware;　を先頭の方に追記

Route::get('hello_middle', 'HelloController@index_middle')
   ->middleware(HelloMiddleware::class);
```

ミドルウェアを利用する場合は、Rouge::getの後にメソッドチェーンを使って 「middleware」メソッドを追加します。引数には、利用するミドルウェアクラスを指定します。  
このmiddlewareメソッドは、そのままメソッドチェーンとして連続して記述することができます。複数のメソッドチェーンを利用したい場合は、
```
Route::get(.....)->middleware(.....)->middleware(.....);
```
このように middlewareを連続して記述していくことができます。



## ビューとコントローラの修正

これでミドルウェアHelloMiddlewareが「/hello_middle」で動作するようになりました。では、ミドルウェアで組み込まれる変数$dataが正しく動いているか、ビューとコントローラを 修正して確認しましょう。 

まずは、コントローラの修正です。HelloControllerクラスのindexアクションメソッド を以下のように修正して下さい。

<p class="tmp list"><span>リスト4-1</span>app\Http\Controllers\HelloController.php</p>
```
public function index_midddle(Request $request)
{
   return view('hello.index3', ['data'=>$request->data]);
}
```

続いて、テンプレートの修正です。index3.blade.phpを以下のように記述しましょう。

<p class="tmp list"><span>リスト4-2</span>hello/index3.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Index')

@section('menubar')
@parent
ミドルウェアページ
@endsection

@section('content')
   <p>ここが本文のコンテンツです。</p>
   <table>
   @foreach($data as $item)
   <tr><th>{{$item['name']}}</th><td>{{$item['mail']}}</td></tr>
   @endforeach
   </table>
@endsection

@section('footer')
copyright 2023
@endsection
```
これで、ミドルウェアで追加されたデータが表示されるようになります。実際に 「/hello_middle」にアクセスして表示を確認して下さい。テーブルにデータがまとめられて表示されます。

![](upload/hello_middleにアクセス.png "図 「/hello_middle」にアクセスすると、$dataのデータがテーブルで表示される。"){.photo-border}


ここでは、コントローラのアクションメソッドでviewの引数に['data'=>$request ->data]という形で$request->dataの値を設定しておき、
![](upload/request_data.png "図　HelloController.php（コントローラー）")

テンプレート側で@foreachを使い、その内容を出力させています。  ここの「$request->data」がミドルウェアから取得したデータになります。
![](upload/middleware_data.png "図　HelloMiddleware.php（ミドルウェア）")

ここでは配列としてデータを持たせていますが、この先、データベースを本格的に利用するようになると、ミドルウェアを使って事前に必要なデータを処理したりできるため、コントローラの負担がずいぶんと軽くなります。


## リクエストとレスポンスの流れ

今回、サンプルとして作ったHelloMiddlewareは、リクエストがあったら処理を実行し、それからコントローラのアクションが呼び出されていました。が、実はミドルウェアは、 「アクション後の処理」も作成することができます。  
これには、ミドルウェアのhandleメソッドの引数として渡されるクロージャと、メソッドの返値の働きをよく理解しておかなければいけません。 handleでは、デフォルトでこのように処理が用意されていました。
```
public function handle(Request $request, Closure $next): Response
{
	return $next($request);
}
```
引数として$requestが渡され、そして一緒に渡されたクロージャの戻り値がreturnで 返されていました。この$nextで返されるのは一体、何なのでしょうか?   
実は、「<span class="red">レスポンス(Response)</span>」インスタンスなのです。

リクエストが送られてきてからクライアントにレスポンスが返されるまでの流れを整理すると、以下のようになります。

1. リクエストが送られる。 
2. ミドルウェアのhandleが呼び出される。
3. $nextを実行する。これは、複数のミドルウェアが設定されている場合は、次のミドルウェアのhandleが呼び出される。他にミドルウェアがない場合は、コントローラにあるアクションが呼び出される。
4. アクションメソッドが終わると共にページがレンダリングされ、レスポンスが生成される。この生成されたレスポンスが、$nextの戻り値として返される。
5. 返されたレスポンスが、returnとして返され、これがクライアントへ返送される。

![](upload/middle_ware04.png "図 クライアントからリクエストが送られると、ミドルウェアが受け取り、$nextでコントローラの アクションが呼び出される。その結果としてレスポンスが返され、これをreturnしたものがクライアントに戻される。")


### 前処理と後処理
この流れを理解すれば、コントローラの前に実行するミドルウェアと、後で実行する ミドルウェアの作成方法がわかってきます。

<span class="marker-yellow50">コントローラの前に実行する処理</span>は、先ほど作成しました。これは、必要な処理をすべて実行してから$nextを実行し、それをreturnします。

<p class="tmp"><span>書式2</span>前処理</p>
```
public function handle($request, Closure $next)
{
    //......処理を実行する...... //
    return $next($request);
}
```

<span class="marker-green50">コントローラの後に実行する処理</span>は、$nextを実行してレスポンスを受け取ってから、 必要な処理を実行していきます。そして処理が終わったところで、保管してあったレスポンスをreturnします。

<p class="tmp"><span>書式3</span>後処理 </p>
```
public function handle($request, Closure $next)
{
    $response = $next($request) 
   // ......処理を実行する..... //
    return $response;
}
```
このように、handleメソッドの実装の仕方を少し変えることで、コントローラの前処理・後処理を作成できます。


## レスポンスを操作する

では、先ほどコントローラの前に実行される例を挙げましたから、今度はコントローラの呼び出し後に実行されるミドルウェアのサンプルを作ってみることにしましょう。  
ここでは、新たに「Hello2Middleware.php」というミドルウェアを作ってみます。

artisanコマンドを実行します。
<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan make:middleware Hello2Middleware
```

<p class="tmp list"><span>リスト5-1</span>Hello2Middleware.php</p>
```
class Hello2Middleware
{
   public function handle($request, Closure $next)
   {
       $response = $next($request);
       $content = $response->content();

       $pattern = '/<middleware>(.*)<\/middleware>/i';
       $replace = '<a href="http://$1">$1</a>';
       $content = preg_replace($pattern, $replace, $content);

       $response->setContent($content);
       return $response;
   }
}
```

ここでは、レスポンスから、クライアントに返送されるコンテンツを取り出し、その一部を置換して返送しています。

### 処理の流れ
では、handleメソッドで行っている処理を見ていきましょう。まず最初に$nextを実行し、結果を$responseに代入します。
```
$response = $next($request);
```
これで、コントローラのアクションが実行され、その結果のレスポンスが変数 $responseに収められます。このレスポンスを使って処理を行います。 まず、レスポンスから返送されるコンテンツを取得します。
```
$content = $response->content();
```
$responseのcontentメソッドで、レスポンスに設定されているコンテンツが取得できます。これは、送り返されるHTMLソースコードのテキストが入っています。ここから、 <middleawre>というタグを正規表現で置換します。
```
$pattern = '/<middleware>(.*)<V/middleware>/i'; 
$replace = '<a href="http://$1">$1</a>'; 
$content = preg_replace($pattern, $replace, $content);
```
これは、<middleware> ○ ○</middleware>というテキストを、<a href="http://〇〇">〇〇</a>というテキストに置換する処理です。これにより、<middleware>というタグにドメイン名を書いておけば、そのドメインにアクセスするためのリンクが自動生成されるようになります。 後は、レスポンスにコンテンツを設定し、returnするだけです。
```
$response->setContent($content); 
return $response;
```
レスポンスへのコンテンツ設定は、**setContent**というメソッドを使います。これでクライアントに返送されるコンテンツが変更されました。後は、レスポンスをreturnすれば作業終了です。

### ビューとコントローラの修正
では、この新しいミドルウェアを使ってみましょう。まず、テンプレートの作成します。

<p class="tmp list"><span>リスト5-2</span> index4.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Index')

@section('menubar')
@parent
ミドルウェアページ
@endsection

@section('content')
   <p>ここが本文のコンテンツです。</p>
   <p>これは、<middleware>google.com</middleware>へのリンクです。</p>
   <p>これは、<middleware>yahoo.co.jp</middleware>へのリンクです。</p>
@endsection

@section('footer')
copyright 2023
@endsection
```
今回は、サンプルとして2つの<middleware>タグを用意しておきました。google.com とyahoo.co.jpを値に設定してあります。  
後はコントローラの修正ですね。HelloControllerクラスのindexアクションメソッドを 以下のように変更しておきます。
    
<p class="tmp list"><span>リスト5-3</span>HelloController.php</p>
```
public function index_middle2(Request $request)
{
   return view('hello.index4');
}
```

ルート情報を追加する。
先頭あたりに「use App\Http\Middleware\Hello2Middleware;」を追記して、下記を追加します。
<p class="tmp list"><span>リスト5-4</span>web.php</p>
```
Route::get('hello_middle2', [\App\Http\Controllers\HelloController::class,'index_middle2'])
   ->middleware(Hello2Middleware::class);
```

今回、コントローラ側では何も処理はしていません。値も特に設定してはおらず、ほぼデフォルトの状態でページを表示しているだけです。  
では、修正が完了したら「/hello2_middle」にアクセスしてみましょう。すると、&lt;middleware&gt;タグの部分が、&lt;a&gt;タグのリンクに変更されているのがわかります。

![](upload/hello2middlewareアクセス.png "図　/hello2_middleにアクセスすると、<middleware>タグが<a>タグのリンクに変換されている。"){.photo-border}
    
ミドルウェアを設定してない場合は、次のようになります。
![](upload/ミドルウェアなしの場合.png  "図　ミドルウェア設定なしの場合"){.photo-border}


## グローバルミドルウェア

ミドルウェアの基本的なコーディングがわかったところで、登録について改めて目を向けてみましょう。先ほどは、ルート情報を設定するところでmiddlewareメソッドを呼び出してミドルウェアを実行していました。このように、特定のアクセスにのみミドル ウェアを割り当てる場合は、1つ1つのルートに追記をしていきます。  

が、例えば「<span class="marker-yellow50">すべてのアクセスで自動的にミドルウェアが実行されるようにしたい</span>」という場合は、1つ1つのルートに追記をしていくのでは埒が明きません。 このような場合は、「<span class="green bold marker-yellow50">グローバルミドルウェア</span>」と呼ばれる機能を使います。これはすべてのリクエストで利用可能となるものです。
    
### グローバルミドルウェアの登録
ミドルウェアの登録は、「Http」フォルダ内にある「<span class="red">Kernel.php</span>」というスクリプトファイルを利用します。  
このファイルを開くと、その中に以下のような部分が見つかります。これが、グローバルミドルウェアの登録を行っているところです。
    
<p class="tmp list"><span>リスト6-1</span>app\Http\Kernel.php（デフォルト）</p>
```
protected $middleware = [
    // \App\Http\Middleware\TrustHosts::class,
    \App\Http\Middleware\TrustProxies::class,
    \Illuminate\Http\Middleware\HandleCors::class,
    \App\Http\Middleware\PreventRequestsDuringMaintenance::class,
    \Illuminate\Foundation\Http\Middleware\ValidatePostSize::class,
    \App\Http\Middleware\TrimStrings::class,
    \Illuminate\Foundation\Http\Middleware\ConvertEmptyStringsToNull::class,
];
```
    
グローバルミドルウェアは、Kernelクラスの$middlewareという変数の中に配列としてまとめられています。 では、$middlewareの配列を閉じる<span class="red"> ]</span> 記号の前を改行し、以下の文を追記して下さい。

<p class="tmp list"><span>リスト6-2</span>app\Http\Kernel.php</p>
```
\App\Http\Middleware\Hello2Middleware::class,
```
これで、HelloMiddlewareがグローバルミドルウェアとして登録されます。グローバルミドルウェアとして登録すると、個々のミドルウェアの呼び出し処理は不要になります。  
先に記述した、Route:getのmiddlewareメソッドを削除しましょう。web.phpは以下になります。

<p class="tmp list"><span>リスト6-3</span>web.php</p>
```
Route::get('hello_middle2', [\App\Http\Controllers\HelloController::class,'index_middle2']);
```

これで、middlewareの呼び出し処理はなくなりました。「/hello_middle2」にアクセスすると、ミドルウェアが呼び出されなければ、先ほどのリンクの作成機能は動作しなくなるはずです。が、middlewareメソッドは呼び出していないのに、きちんとリンクが生成されています。

![](upload/hello2middlewareアクセス.png){.photo-border}

グローバルミドルウェアに登録したことで、どこにアクセスしても常にミドルウェアが実行されるようになっているのです。  
確認ができたら、「Kernel.php」の追加したミドルウェアはコメントアウトして、「web.php」の方を復活させておいてください。



## ミドルウェアのグループ登録
    
多数のミドルウェアを使うようになると、複数のミドルウェアを一つにまとめて扱えるようにできれば管理が楽になります。  
ミドルウェアには、グループ化して登録するための仕組みも用意されています。これは、Kernel.phpの「$middlewareGroups」という変数として用意されています。この変数 には、以下のような形で値が設定されています。
    
<p class="tmp"><span>書式4</span>Kernel.php</p>
```
protected $middlewareGroups = [
   'web' => [
       ……ミドルウェアクラス……
   ],

   'api' => [
       ……ミドルウェアクラス……
   ],
];
```
$middlewareGroups内には、「<span class="red">'web'</span>」と「<span class="red">'api'</span>」 という項目があり、その中にミドルウェアのクラスがまとめられています。この「'web'」や「'api'」がグループです。  $middlewareGroups では、このようにグループ名をキーとする値を用意し、そこにミドルウェアの配列を設定しています。こうすることで、その名前のグループで使われるミドルウェアが指定できます。
    
ここでは、webとapiというグループが用意されていますが、これらはルーティング情報を設定するところでmiddlewareメソッドを使って指定することができます。
    
### グループを利用する
では、実際に簡単なグループを作って利用してみましょう。まず、グループの登録を行います。Kernel.phpの$middlewareGroupsの配列の最後尾に、以下の文を追記しておきましょう。

<p class="tmp list"><span>リスト7-1</span>Kernel.php</p>
```
'helo' => [
   \App\Http\Middleware\HelloMiddleware::class,
],
```
グループ化ですから複数のミドルウェアクラスを指定するのが一般的ですが、今回はとりあえずHelloMiddlewareクラス1つだけのグループ" helo'を用意してみました。  
続いて、web.phpを開き、「/hello_middle」のルート情報を以下のように修正します。
    
<p class="tmp list"><span>リスト7-2</span>web.php</p>
```
Route::get('hello_middle', [\App\Http\Controllers\HelloController::class,'index_middle'])
   ->middleware('helo');
```
これで、「/hello_middle」にheloグループが設定されます。「/hello_middle」にアクセスした際には、heloグループに登録してあるすべてのミドルウェアが実行されます。  

確認が終わったら、helloグループの方をコメントアウトして、単独の方を復活させておいてください。


まとめとして、
<div markdown="1" class="green-box">
1. 個々のルーティング情報への登録
2. グローバルミドルウェアの登録
3. グループの登録
</div>

この3つの登録方法がわかれば、ミドルウェアの利用はマスターできた といってよいでしょう。
