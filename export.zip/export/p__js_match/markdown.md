*[page-title]:文字列に～を含むかのチェック(match,test,indexOf,search,include)

## match() 

「match()」は正規表現のみに対応しているのが特徴となっており、返り値も「配列データ」で取得できます。  
str.match(/文字列/)で、文字列が含まれれば配列、文字列が含まれなければnullが返ることを利用する。

<p class="tmp"><span>書式</span></p>
```
対象文字列.match( 正規表現 );
```

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	「-」が文字列に含まれてるか判定しています。
	<iframe width="100%" height="200" src="//jsfiddle.net/hirao/teuw4L5z/39/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>



<div class="exp">
	<p class="tmp"><span>例2</span></p>
	文字列が郵便番号かどうか判定しています。
	<script async src="//jsfiddle.net/phf4ramx/4/embed/js,result/"></script>
</div>



変数「postcode1,postcode2,postcode3」に番号が格納されているので、これに「match()」を使って正規表現を当てはめて、正しい郵便番号なのかどうかをチェックしています。当てはまらない場合は「null」が返されます。

【補足】
: 郵便番号などを判定する場合は、test()を使用して判定することもできます。この場合は、「true」と「false」で返されます。

<div class="exp">
	<p class="tmp"><span>例3</span></p>
	<script async src="//jsfiddle.net/ka9u6hjz/1/embed/js,result/"></script>
</div>


プログラムの途中で正規表現のパターンを変更する場合や、外部から取得もしくは入力要素から受け取る場合は「***RegExp***」***コンストラクタ***を使います。  
逆に、正規表現のパターンがまったく変わらないという場合は、上記の例で使用した「***リテラル***」が好ましいです。

<div class="exp">
	<p class="tmp"><span>例4</span></p>
	 上記を「<strong>RegExp</strong>」でかくと下記のようになります。
	 <script async src="//jsfiddle.net/fqd3cm12/embed/js,result/"></script>
</div>


<p class="tmp"><span>書式1</span>「RegExp」オブジェクトの一般的な構文です。</p>
```
let reg = new RegExp( パターン, フラグ );
```
「RegExp」コンストラクタをnewすることで、JavaScriptで正規表現が扱えるRegExpオブジェクトを生成することができます。  
引数の「パターン」には一般的な正規表現を指定し、「フラグ（g,i,mなど）」を指定すればOKです！（フラグについては後述します）

参考サイト
: [【JavaScript入門】RegExp(正規表現)の使い方と活用事例！](https://www.sejuku.net/blog/24896)

## test() 

正規表現パターンに合致するかどうかをチェックし、「true / false」で返します。

<p class="tmp"><span>書式</span></p>
```
【 正規表現パターン.test( 対象の文字列または、数値 ) 】
```

【補足】
: 正規表現で扱う「特殊文字（. * + ^ | [ ] ( ) ? $ { }など）」は、パターンを作成する時にエスケープしなければいけないケースがあります。

<div class="exp">
	<p class="tmp"><span>例5-1</span></p>
	    「test()」メソッドを使って正規表現とURLが一致するかを確認しています。「www.sejuku.net」と「wwwzsejukuznet」の文字を「www.sejuku.net」と一致するかチェックしてますが、下記の両方とも「true」になります。
			<iframe width="100%" height="200" src="//jsfiddle.net/hirao/teuw4L5z/42/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


理由は簡単で、正規表現の世界で「.（ドット）」はどんな文字でも検出するというルールがあるからなのです。つまり、文字列のURLで記述した「.（ドット）」と正規表現パターンで記述した「.（ドット）」は似て非なるものというわけです！

このような状況の場合に必要となるのが「エスケープ」処理なのです。


<div class="exp">
	<p class="tmp"><span>例5-2</span></p>
	「sejuku」を変数（test）に格納してから、new RegExp()にセットして、「www.sejuku.net」に含まれるか判定しています。
	<iframe width="100%" height="200" src="//jsfiddle.net/hirao/xjy67b4u/1/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例5-3</span></p>
	    「&lt;span class="text-red"&gt;テキストです。&lt;/span&gt;」が、正規表現の「&lt;span class="(.*)"&gt;(.*)&lt;\/span&gt;」に当てはまるか判定しています。  
    ポイントは、&lt;/span&gt;の「/」の前に「\」を置いている点です。これにより、「/」が正規表現の記号ではなく、文字として認識されるれようになります。
		<script async src="//jsfiddle.net/t19qmx4a/1/embed/js,result/"></script>
</div>


<div class="exp">
	<p class="tmp"><span>例5-4</span></p>
	上記の例をreplace()で$1と$2の記号を使って、クラスにboldを追加しています。
	<script async src="//jsfiddle.net/x06aes4y/1/embed/js,result/"></script>
</div>



### バックスラッシュを使ったエスケープ方法

正規表現でエスケープ処理を行うのに必要なのは「\ (バックスラッシュ)」です

そこで、先ほど正規表現パターンに記述していた「.（ドット）」をエスケープして同じ処理を実行してみましょう！

<div class="exp">
	<p class="tmp"><span>例6</span></p>
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/teuw4L5z/44/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

結果は「false」になります。  
注目すべきは正規表現パターンの「.（ドット）」の箇所です！「\.」のように「.（ドット）」の前に「\（バックスラッシュ）」を記述することで、通常の文字「.（ドット）」を意味することになります。

そのため、「z」に置換されている文字列は正規表現パターンと異なるので実行結果は「false」となるわけです。


### 配列を検索

※ちょっとまだ使えるか調査

<script async src="//jsfiddle.net/hirao/82o1vmc9/27/embed/js,result/"></script>

## indexOf 

str.indexOf(文字列)で、文字列（searchValue）が見つかれば文字列が見つかった場所(0以上)、文字列が見つからなければ-1が返ることを利用します。検索を開始する位置（fromIndex）も任意で指定できます。


<p class="tmp"><span>書式</span></p>
```
対象文字列.indexOf(検索文字[, 開始位置])
```

<div class="exp">
	<p class="tmp"><span>例8-1</span></p>
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/n7jkw3vs/2/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


<div class="exp">
	<p class="tmp"><span>例8-2</span></p>
	配列に指定した値があるかを判定する。
	<script async src="//jsfiddle.net/jmdxa0qv/embed/js,result/"></script>
</div>



### 前方一致

解説
: indexOf()はターゲット文字列内の何文字目でパターン文字列が見つかったのか返す。
0文字目,1文字目,..と数え上げるので、最初の文字で見つかった場合は0が返ってくる。これを利用して前方一致の判定を実現できる。

```
const string  = 'isogram';
const pattern = 'is';
if(string.indexOf(pattern) === 0){
  // 前方一致のときの処理
}
```

### 前方一致のコードを短縮する

解説
: JavaScriptにおいて数値を論理値に変換したときに0はfalse、それ以外の数はすべてtrueとして扱われる。  
つまり、indexOf()は前方一致したときのみfalseと見なされる値を返す、そうでないときはtrueと見なされる値を返す性質を持っている。  
これを利用して、indexOf()の結果を否定演算子!により反転すれば短いコードで前方一致の判定ができる。

```
const string  = 'isogram';
const pattern = 'is';
if(!string.indexOf(pattern)){
  // 前方一致のときの処理
}
```

### 部分一致

解説
: indexOf()ではマッチしなかったとき-1を返す。マッチしたときは0以上の整数を返す。これを利用して部分一致の判定を実現できる。

```
const string  = 'isogram';
const pattern = 'og';
if(string.indexOf(pattern) > -1){
  // 部分一致のときの処理
}
```

### 部分一致のコードを短縮する

~は数値をビット反転する演算子であり、「indexOf()でマッチしなかったとき返ってくる数値」である**-1をビット反転した数値は0になる。

0はif文においてfalseと判定され、それ以外の数はすべてtrueとして扱われるため、  
これを利用して、indexOf()の結果を~でビット反転すれば短いコードで部分一致の判定ができる。

```
const string  = 'isogram';
const pattern = 'og';
if(~string.indexOf(pattern)){
  // 部分一致のときの処理
}
```



## search() 

search() ～ 文字の位置を検索する

<p class="tmp"><span>書式</span></p>
```
対象文字列.search( 目的のキーワードか正規表現 )
```
<div class="exp">
	<p class="tmp"><span>例9</span></p>
	<iframe width="100%" height="300" src="//jsfiddle.net/hirao/efr8h0wv//embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>




## include() 

includesは特定の要素が配列に含まれているかどうかをtrue / false で返します。  
***ただしIEでは動かないので、コードを追加する必要があります。***

```
const chars = ["a", "b", "d", "g", "h", "i", "m", "n"];
const target = "d";

const exists = chars.includes(target);
console.log(exists); // => true
```


**オブジェクトでの使用**

```
const books = [
  { title: "幼年期の終り", author: "アーサー・C・クラーク" },
  { title: "1984年", author: "ジョージ・オーウェル" },
  { title: "われはロボット", author: "アイザック・アシモフ" }
];

const target = {
  title: "1984年",
  author: "ジョージ・オーウェル"
};

const includes = books.includes(target);
console.log(`includes: ${includes}`); // includes: false
```

## some()メソッド 

some() メソッドは、配列の少なくとも一つの要素が、指定された関数で実装されたテストに合格するかどうかをテストします。これはブール値を返します。
<div class="exp">
	<p class="tmp"><span>例10</span></p>
<script async src="//jsfiddle.net/hirao/ocrxz3b4/5/embed/js,result/"></script>
</div>



## 参考サイト ##{#reference}

* [文字列の検索まとめ(indexOf/search/match/test)](https://www.sejuku.net/blog/21049)
* [JavaScript の Array.some と Array.includes の使い分け、値・参照型の動作の違い](https://qiita.com/Nossa/items/4a425e57ec4b7eedb7cb)
* [IE11で配列のincludesメソッドを使えるようにする方法](https://blog.yuhiisk.com/archive/2017/08/23/array-includes-for-ie11.html)
* [正規表現（RegExp）](http://www.tohoho-web.com/js/regexp.htm)
* [Array.prototype.some()](https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Global_Objects/Array/some)