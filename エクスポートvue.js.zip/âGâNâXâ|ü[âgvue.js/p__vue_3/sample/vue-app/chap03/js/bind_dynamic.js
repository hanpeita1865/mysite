Vue.createApp({
  data() {
    return {
      attr: 'width',
      size: 100
    };
  }
}).mount('#app');