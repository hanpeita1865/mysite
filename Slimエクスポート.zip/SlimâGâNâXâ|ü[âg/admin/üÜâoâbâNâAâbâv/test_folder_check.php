<?php
$error_mg = [];//エラーメッセージ(テスト)


globAll('../pages');

function globAll($folder) {

    global $error_mg;

    if (!is_file($folder)) {

        $res = glob($folder . '/*'); 

        foreach ($res as $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{3}./', $lastDir)) {

                $path = str_replace('../pages/','', $f).'/';//リストのパス

                $pathRe = preg_replace('/^\d{3}./','',$path);
                $pathRe = preg_replace('/\/\d{3}./','/',$pathRe);

                if(!file_exists($f.'/markdown.md')){
                    array_push($error_mg, $f.'に「markdown.md」がありません。');//テスト JSに返す方法がまだ
                }

                globAll($f);
            }
        }
    }
}

$str = implode(",", $error_mg);
$str = str_replace(',','","', $str);
$str = '["'.$str.'"]';
print_r($str);

?>