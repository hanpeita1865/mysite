*[page-title]:デザイン

## Webデザイン参考サイト

参考サイト
: [Webデザインの参考になるギャラリーサイト24選【2022年8月版】](https://liginc.co.jp/416443)

## Photoshop参考サイト
[夢見るゴリラ](https://yumegori.com/category/photoshop)

## 動きのあるサイト

参考サイト
: <https://sankoudesign.com/category/motion-effect/>

## 検索ボックス

参考サイト
: [CSS｜検索ボックスのデザインサンプル11点（2018年度）](https://cotodama.co/search-box/)
: [検索フォームの作り方オシャレなCSSデザイン6選](https://kagesai.net/search-form-design/)
: [シンプルでおしゃれなCSS検索BOXがコピペで実装できる！【デフォルト型】](https://deshinon.com/2019/03/03/simpl-searchbox-default-css/)

<div class="exp">
	<p class="tmp"><span>例1</span>アイコンで指定</p>
	検索の横にアイコンが！どれを検索したいのかパッと見てわかる
	</div>
<iframe height="300" style="width: 100%;" scrolling="no" title="DailyUI #022 - Search" src="https://codepen.io/supah/embed/XdKMJK?default-tab=result" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/supah/pen/XdKMJK">
DailyUI #022 - Search</a> by Fabio Ottaviani (<a href="https://codepen.io/supah">@supah</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>

<div class="exp">
	<p class="tmp"><span>例2</span>超シンプル</p>
	シンプルなボックスタイプのデザイン
	</div>
<iframe height="300" style="width: 100%;" scrolling="no" title="Simple Search Bar" src="https://codepen.io/AustinAuth/embed/xxmbZX?default-tab=result" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
See the Pen <a href="https://codepen.io/AustinAuth/pen/xxmbZX">
Simple Search Bar</a> by Austin (<a href="https://codepen.io/AustinAuth">@AustinAuth</a>)
on <a href="https://codepen.io">CodePen</a>.
</iframe>


<div class="exp">
	<p class="tmp"><span>例3</span>背景を透明に</p>
	背景をかっこよく透明にして、検索部分はシンプルに
	</div>
<iframe height="300" style="width: 100%;" scrolling="no" title="A cool little search box" src="https://codepen.io/jonwelsh/embed/kymgyQ?default-tab=result" frameborder="no" loading="lazy" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href="https://codepen.io/jonwelsh/pen/kymgyQ">
  A cool little search box</a> by Jon Welsh (<a href="https://codepen.io/jonwelsh">@jonwelsh</a>)
  on <a href="https://codepen.io">CodePen</a>.
</iframe>

## サイドメニューの開閉サンプル

参考サイト
: [今風に作られたコードスニペット9選](https://goworkship.com/magazine/slide-out-sidebars/)