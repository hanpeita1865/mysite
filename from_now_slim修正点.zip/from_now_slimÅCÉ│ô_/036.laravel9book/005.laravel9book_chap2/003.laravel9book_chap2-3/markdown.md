*[page-title]:Chap2-3 つぶやきを編集する処理を作成する（example-app7）

投稿する処理を作成できたので、続けて投稿を編集する機能を作成します。

<span class="bold green">Chap2-3 完成品</span>
* \\wsl.localhost\Ubuntu-24.04\root\example-app7
* つぷやき表示　<http://localhost/tweet>
* phpMyAdmin　<http://localhost:8080/index.php>　データベース名は「example_app5」にしてます。

## コントローラの作成

まずはコントローラから作成しましょう。編集する画面と編集のリクエストを受け付ける2つのコントローラが必要です。

<p class="tmp cmd"><span>コマンド</span>編集とリクエストのコントローラ作成</p>
```
sail artisan make:controller Tweet/Update/IndexController --invokable
sail artisan make:controller Tweet/Update/PutController --invokable
```

![](upload/編集する画面と編集のリクエストを受け付ける2つのコントローラが必要です.png)

ファイルが作成されました。
![](upload/IndexControllerとPutController作成.png){.photo-border}


投稿と同じようにRequestFormクラスも作成します。

<p class="tmp cmd"><span>コマンド</span></p>
```
sail artisan make:request Tweet/UpdateRequest
```

![](upload/投稿と同じようにRequestFormクラスも作成します.png)

ファイルが作成されました。
![](upload/UpdateRequestの内容はCreateRequestと同様になります。.png){.photo-border}

UpdateRequestの内容はCreateRequestと同様になります。

<p class="tmp list"><span>リスト1-1</span>UpdateRequest.php（デフォルト）</p>
```
<?php

namespace App\Http\Requests\Tweet;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            //
        ];
    }
}
```

下記のように変更します。
<p class="tmp list"><span>リスト</span>UpdateRequest.php</p>
```
<?php

namespace App\Http\Requests\Tweet;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;//trueに変更
    }

    public function rules(): array
    {
        return [
            'tweet' => 'required|max:140'//追加
        ];
    }

	//追加
    public function tweet(): string
    {
        return $this->input('tweet');
    }
}
```
コントローラが作成できたので、Routeに追加します。  
routes/web.phpに次のように追加します。

<p class="tmp list"><span>リスト1-2</span>routes/web.php</p>
```
Route::get('/tweet/update/{tweetId}', \App\Http\Controllers\Tweet\Update\IndexController::class)->name('tweet.update.index');
Route::put('/tweet/update/{tweetId}', \App\Http\Controllers\Tweet\Update\PutController::class)->name('tweet.update.put');
```

編集ページをHTTPのGETで表示し、更新処理をPUTとしています。 PUTメソッドはPOSTと同様にリソースの作成や更新を意味しますが、POSTとは 違い “べき等” であることを表します。  
編集リクエストは何度送られても同じ結果になるので、ここではPUTと定義しています。  
Route ではURIのパスパラメータにルールを設定することができます。 今回 の例であればtweetld は整数値のみを受け付ければよいので、 他の文字列などは不要です。  
その場合はメソッドチェーンでwhere() を使うことで制限させることができます。

<p class="tmp list"><span>リスト1-3</span>routes/web.php（整数値のみを受け付け設定）</p>
```
Route::get('/tweet/update/{tweetId}', \App\Http\Controllers\Tweet\Update\IndexController::class)->name('tweet.update.index')->where('tweetId', '[0-9]+');
Route::put('/tweet/update/{tweetId}', \App\Http\Controllers\Tweet\Update\PutController::class)->name('tweet.update.put')->where('tweetId', '[0-9]+');
```

こうすることで/tweet/update/abcなどのパスは404 Not Foundとなり、コントローラでも整数値のみが渡されることを前提とすることができます。  
毎回パスパラメータのルールを書くのが面倒な場合は、グローバルに tweetld = 整数値という設定を作ることも可能です。  
app/Providers/RouteServiceProviderのbootメソッドに 次のよう にルールを追加します。


<p class="tmp list"><span>リスト1-4</span>app/Providers/RouteServiceProvider.php</p>
```
public function boot()
{
    Route::pattern('tweetId', '[0-9]+');//追加
	･･･省略･･･
}
```


<p class="tmp list"><span>リスト1-5</span>app/Http/Controllers/Tweet/Update/IndexController.php</p>
```
public function __invoke(Request $request)
{
    $tweetId = (int) $request->route('tweetId');
    dd($tweetId);
}
```

Routeで{tweetId}と指定したのでRequestから$request->route('tweetId')が取得できます。

<http://localhost/tweet/update/1>にアクセスすると、1が取得できることが確認できます。

![](upload/update1。.png)

この$tweetIdを利用してデータベースからデータを取得してみます。


<p class="tmp list"><span>リスト1-6</span>app/Http/Controllers/Tweet/Update/IndexController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet\Update;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tweet; //追加
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException; //追加

class IndexController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $tweetId = (int) $request->route('tweetId');
        $tweet = Tweet::where('id', $tweetId)->first();//$tweetIdのレコードを検索　追加
        if (is_null($tweet)) {//検索結果が存在しない場合　追加
            throw new NotFoundHttpException('存在しないつぶやきです');
        }
        dd($tweet);

    }
}
```

実際に存在しないidを指定してアクセスすると404になることが確認できます。

例えば、<http://localhost/tweet/update/100>にアクセスしてみると、404が表示されます。
![](upload/update100.png)

データが存在すると、次のように表示されます。
![](upload/update2データ.png)

クエリビルダの取得でfirstOrFailを利用することで、この処理を省略することができますので、使ってみましょう。

<p class="tmp list"><span>リスト1-7</span>app/Http/Controllers/Tweet/Update/IndexController.php（firstOrFailを利用）</p>
```
public function __invoke(Request $request)
{
    $tweetId = (int) $request->route('tweetId');
    $tweet = Tweet::where('id', $tweetId)->firstOrFail();//追加
    dd($tweet);
}
```

同じように表示されるのが確認できると思います。


### 編集用の投稿画面の作成

それでは編集用の投稿画面を作って表示してみましょう。  
resources/views/tweet/update.blade.phpを作成します。

<p class="tmp list"><span>リスト1-8</span>resources/views/tweet/update.blade.php</p>
```
<!doctype html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>つぶやきアプリ</title>
</head>
<body>
<h1>つぶやきを編集する</h1>
<div>
    <a href="{{ route('tweet.index') }}">< 戻る</a>
    <p>投稿フォーム</p>
    <form action="{{ route('tweet.update.put', ['tweetId' => $tweet->id]) }}" method="post">
        @method('PUT') 
        @csrf
        <label for="tweet-content">つぶやき</label>
        <span>140文字まで</span>
        <textarea id="tweet-content" type="text" name="tweet" placeholder="つぶやきを入力">{{ $tweet->content }}</textarea>
        @error('tweet')
        <p style="color: red;">{{ $message }}</p>
        @enderror
        <button type="submit">編集</button>
    </form>
</div>
</body>
</html>
```

ではコントローラを次のように変更してviewを返します。

<p class="tmp list"><span>リスト1-9</span>app/Http/Controllers/Tweet/Update/IndexController.php</p>
```
public function __invoke(Request $request)
{
    $tweetId = (int) $request->route('tweetId');
    $tweet = Tweet::where('id', $tweetId)->firstOrFail();
    return view('tweet.update')->with('tweet', $tweet);//追加
}
```

http://localhost/tweet/update/2 にアクセスすると、次のようにテキストエリアにデータが表示されます。
![](upload/update2コントロール表示.png){.photo-border}

### 編集内容の更新処理

つづいて実際に更新する処理を追加しましょう。

<p class="tmp list"><span>リスト1-10</span>app/Http/Requests/Tweet/UpdateRequest.php</p>
```
public function id(): int
{
    return (int) $this->route('tweetId');
}
```

この処理はコントローラで実装しても変わりませんが、RequestForm側に実装することでコントローラでの処理が簡略されるためおすすめです。


<p class="tmp list"><span>リスト1-11</span>app/Http/Controllers/Tweet/Update/PutController.php</p>
```
<?php

namespace App\Http\Controllers\Tweet\Update;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Tweet\UpdateRequest;//追加
use App\Models\Tweet;//追加

class PutController extends Controller
{
	//追加 下記　Request　から　UpdateRequestにする
    public function __invoke(UpdateRequest $request)
    {
        $tweet = Tweet::where('id', $request->id())->firstOrFail();
        $tweet->content = $request->tweet();
        $tweet->save();
        return redirect()
            ->route('tweet.update.index', ['tweetId' => $tweet->id])
            ->with('feedback.success', "つぶやきを編集しました");
    }
}
```

先ほどのapp/Http/Controllers/Tweet/Update/IndexControllerと同様にまずは対象のEloquentモデルを取得します。  
そのEloquent モデルのcontent を更新してsaveメソッドから保存を実行し、元の編集ページにリダイレクトしています。  
リダイレクトする際にメソッドチェーンでwithを利用して、フラッシュセッショ ンデータを追加しています。   
フラッシュセッションデータはその名の通り一度きりしか表示されないデータとなるので、 完了の通知などに利用できます。

「update.blade.php」でフラッシュセッション データを表示できるように追加します。

<p class="tmp list"><span>リスト1-12</span>resources/views/tweet/update.blade.php</p>
```
<a href="{{ route('tweet.index') }}">< 戻る</a>
<p>投稿フォーム</p>
@if (session('feedback.success'))<!--追加-->
<p style="color: green">{{ session('feedback.success') }}</p>
@endif
```

実際に更新すると次のように表示されます。
![](upload/つぶやきを編集しました.png){.photo-border}


最後に一覧画面から編集画面へ遷移できるように動線を追加します。


<p class="tmp list"><span>リスト1-13</span>resources/views/tweet/index.blade.php</p>
```
･･･省略･･･
    <div>
    <!--追加修正-->
    @foreach($tweets as $tweet)
        <details>
            <summary>{{ $tweet->content }}</summary>
            <div>
                <a href="{{ route('tweet.update.index', ['tweetId' => $tweet->id]) }}">編集</a>
            </div>
        </details>
    @endforeach

    </div>
</body>
</html>
```

<http://localhost/tweet/>　にアクセスすると次のように表示されます。
つぶやきのテキストをクリックすると、詳細が開き編集リンクをクリックすると編集ページに遷移します。

![](upload/編集ページに遷移フォーム.png){.photo-border}

ここまでで投稿から編集までの動きを作ることができました。
Eloquentモデルを利用することで、 対象のデータを取得し、それを上書きするという動作を容易に作成することができます。



