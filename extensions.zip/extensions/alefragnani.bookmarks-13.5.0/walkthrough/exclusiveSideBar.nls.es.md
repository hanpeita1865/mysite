## Barra lateral exclusiva

Una barra lateral exclusiva con todo lo que necesitas para aumentar tu productividad.

| Una sola carpeta | Espacio de trabajo con muchas carpetas |
|---------------|------------|
| ![Barra lateral](../images/printscreen-activity-bar.png) | ![Barra lateral](../images/printscreen-activity-bar-multi-root.png) |