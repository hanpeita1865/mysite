*[page-title]:Drag & Dropで並べ替え

参考サイト
: [JavaScriptでドラッグ＆ドロップによるリストの並び替えを実装する例](https://blog.ver001.com/javascript-dragdrop-sort/)

## JavaScriptを使って並べ替える
必要最小限のコードでドラッグ＆ドロップによるリストの並び替えの実装方法です。

<div class="exp">
	<p class="tmp"><span>例1-1</span></p>
	メニューをドラッグ&ドロップすると、配置が替わります。ドラッグ中の青のボーダーは、インラインスタイルで設定しています。
	<a href="sample/sample1(js_sort)" target="_blank">新規タブ</a>
	<iframe width="100%" height="500" src="//jsfiddle.net/hirao/0pqeov93/2/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例1-2</span></p>
	例1-1を改修し、ボックスの間にスペースを取っています。indexOfを使って、リストの順番をdropStartとdropOver、dropDropでそれぞれ取得し、上か下かを判定して、ボーダーの表示位置とドロップする場所を決めています。<br>
	※ドラッグ時、インラインスタイルでborder-top、border-bottomを設置しています。
	<iframe width="100%" height="550" src="//jsfiddle.net/hirao/xq2unrdg/4/embedded/result,html.js,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例1-3</span></p>
	例1-2のドラッグ時のボーダーを疑似要素（before、after）で表示させています。
	<iframe width="100%" height="550" src="//jsfiddle.net/hirao/soxvqr08/5/embedded/result,html.js,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


## jQueryでメニューの並べ替えとサブメニューの設定を行う

<div class="exp">
	<p class="tmp"><span>例2</span></p>
	メニューの並べ替えとサブメニューの設置と並び変えを行えます。
		<a href="sample/sample2(jQuery_sort)/admin/" target="_blank">新規タブ</a>
	<iframe width="100%" height="500" src="sample/sample2(jQuery_sort)/admin/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

## 並べ替えをCookieに保存

<div class="exp">
	<p class="tmp"><span>例3</span></p>
			<a href="sample/sample3(cookie_menu)" target="_blank">新規タブ</a>
	<iframe width="100%" height="500" src="sample/sample3(cookie_menu)" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">JS</p>
```
let orderArray = [];

const elemBox = document.getElementById("menu");
const elemItem1 = document.getElementById("item1");
const elemItem2 = document.getElementById("item2");
const elemItem3 = document.getElementById("item3");
const items = document.getElementsByClassName("box-item");
const itemIdArray = ['item1','item2','item3'];

cookieSortGet();//cookieの値を取得

boxSortOrder();//メニュー作成

//ボックス並び作成
function boxSortOrder() {

    for (var i = 0; i < orderArray.length; i++) {
        switch(orderArray[i]){
            case 'item1' :
                elemBox.appendChild(elemItem1);
                break;
            
            case 'item2' :
                elemBox.appendChild(elemItem2);
                break;
    
            case 'item3' :
                elemBox.appendChild(elemItem3);
                break;
        }
    }


	elemBox.classList.add('side-show');

	document.querySelectorAll('.side-link li').forEach (elm => {
		elm.ondragstart = function (e) {
			e.dataTransfer.setData('text/plain', e.target.id);
		};

		elm.ondragover = function (e) {
			e.preventDefault();
			let rect = this.getBoundingClientRect();
			if ((e.clientY - rect.top) < (this.clientHeight / 2)) {
				//マウスカーソルの位置が要素の半分より上
				this.style.borderTop = '2px solid blue';
				this.style.borderBottom = '';
			} else {
				//マウスカーソルの位置が要素の半分より下
				this.style.borderTop = '';
				this.style.borderBottom = '2px solid blue';
			}
		};

		elm.ondragleave = function () {
			this.style.borderTop = '';
			this.style.borderBottom = '';
		};

		elm.ondrop = function (e) {
			e.preventDefault();
			let id = e.dataTransfer.getData('text/plain');
			let elm_drag = document.getElementById(id);
	
			let rect = this.getBoundingClientRect();
			if ((e.clientY - rect.top) < (this.clientHeight / 2)) {
				//マウスカーソルの位置が要素の半分より上
				this.parentNode.insertBefore(elm_drag, this);
			} else {
				//マウスカーソルの位置が要素の半分より下
				this.parentNode.insertBefore(elm_drag, this.nextSibling);
			}
			this.style.borderTop = '';
			this.style.borderBottom = '';

			cookieSortSet();//並べ替え確定
		};
	});
}


//--Cookieの設定--//
let item1Num, item2Num, item3Num;

//cookieに値を格納
function cookieSortSet(){

	let arrayMenus = Array.prototype.slice.call(items);
	let sort = itemIdArray.map(function( value ) {
		let target = document.getElementById(value);
		let index = arrayMenus.indexOf(target);

		return index;
	});

	item1Num = sort[0] + 1;
	item2Num = sort[1] + 1;
	item3Num = sort[2] + 1;

	document.cookie = 'item1=' + item1Num;
	document.cookie = 'item2=' + item2Num;
	document.cookie = 'item3=' + item3Num;

	//alert('cookieに並び順を格納しました。');
}


//cookieの値を取得
function cookieSortGet() {

	//データを1つずつに分ける
	let cookieArray = document.cookie.split(';');

	cookieArray.forEach(function (value) {

		//cookie名と値に分ける
		let content = value.split('=');

		switch (content[0].trim()) {

			case 'item1':
                orderArray[Number(content[1]-1)]='item1';
				break;

			case 'item2':
                orderArray[Number(content[1]-1)]='item2';
				break;

			case 'item3':
                orderArray[Number(content[1]-1)]='item3';
				break;
		}
	});
}


//cookieの値を削除
function cookieSortDel(){
	document.cookie = 'item1=; max-age=0';
	document.cookie = 'item2=; max-age=0';
	document.cookie = 'item3=; max-age=0';

	orderArray = ['item1','item2','item3'];
	boxSortOrder();
	alert('itemの値を削除しました。');
}
```

## 横並びのボックスを並び替える

参考サイト
: [HTML5 Drag and Drop APIの使用](https://web.dev/i18n/ja/drag-and-drop/)

<div class="exp">
	<p class="tmp"><span>例4</span></p>
			<a href="sample/sample4(sort_side)" target="_blank">新規タブ</a>
	<iframe width="100%" height="300" src="sample/sample4(sort_side)" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">JS</p>
```
document.addEventListener('DOMContentLoaded', (event) => {

	function handleDragStart(e) {
		this.style.opacity = '0.4';

		dragSrcEl = this;

		e.dataTransfer.effectAllowed = 'move';
		e.dataTransfer.setData('text/html', this.innerHTML);
	}

	function handleDragEnd(e) {
		this.style.opacity = '1';

		items.forEach(function (item) {
			item.classList.remove('over');
		});
	}

	function handleDragOver(e) {
		if (e.preventDefault) {
			e.preventDefault();
		}

		return false;
	}

	function handleDragEnter(e) {
		this.classList.add('over');
	}

	function handleDragLeave(e) {
		this.classList.remove('over');
	}

	function handleDrop(e) {
		e.stopPropagation();

		if (dragSrcEl !== this) {
			dragSrcEl.innerHTML = this.innerHTML;
			this.innerHTML = e.dataTransfer.getData('text/html');
		}

		return false;
	}

	let items = document.querySelectorAll('.container .box');
	items.forEach(function (item) {
		item.addEventListener('dragstart', handleDragStart);
		item.addEventListener('dragover', handleDragOver);
		item.addEventListener('dragenter', handleDragEnter);
		item.addEventListener('dragleave', handleDragLeave);
		item.addEventListener('dragend', handleDragEnd);
		item.addEventListener('drop', handleDrop);
	});

});
```
