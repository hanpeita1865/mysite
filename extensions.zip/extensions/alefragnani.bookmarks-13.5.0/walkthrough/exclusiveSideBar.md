## Exclusive Side Bar

An exclusive Side Bar with everything you need to increase your productivity.

| Single Folder | Multi-root Workspace |
|---------------|------------|
| ![Side Bar](../images/printscreen-activity-bar.png) | ![Side Bar](../images/printscreen-activity-bar-multi-root.png) |
