*[page-title]:10-2. スマートフィルターを使いこなそう

## スマートフィルターに変換する ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-02-1.jpg)](upload/10-02-1.jpg){.image}
</div>

## スマートフィルターの効果を変更する ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-02-2.jpg)](upload/10-02-2.jpg){.image}
</div>