*[page-title]:文字列の置換（str_replace、str_ireplace、strtr、substr_replace、preg_replace）

## 一致した全ての文字列を置換（str_replace）

検索した文字列に一致した全ての文字列を置換するにはstr_replace関数を使用します。

<p class="tmp"><span>書式</span></p>
```
str_replace( 検索文字列 , 置換後文字列 , 検索対象文字列 [, int $count ] )
```
※第四引数には文字列が一致して置換が行われた箇所の個数が格納されます。


<iframe src="https://paiza.io/projects/e/uW2x1jzmgX-oYDsWohtMvQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
「りんご,オレンジ,メロン,りんご」という文字列の中から、「りんご」という文字列を「バナナ」に変えています。

**str_replace関数は配列の値を置換することもできます。**

また、第四引数に$カウント値を指定すると、置換した個数が格納されます。

<iframe src="https://paiza.io/projects/e/-foUDeEaOdpUkpyPb-9Leg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

配列の中の値にある「りんご」を「ばなな」に置換し、置換した個数も表示しています。


### 複数文字列の置換

str_replace()で複数文字列の置換ができる。  
sourceをSourceに、destinationをDestinationに置換したい場合、以下のように一括で置換できる。

<iframe src="https://paiza.io/projects/e/AzhavvOt09_nBpcW0tkdUQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

置換が配列の順番で対応しているので、対象の数が増えた場合に変換前と変換後の対応付けがわかりづらくなる。  
その場合、連想配列で対応づけを行い、array_keys()とarray_values()でわけるとわかりやすい。

<iframe src="https://paiza.io/projects/e/3MpjrC5bdRgZel1qChCnrA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

$subjectに格納した都道府県の名前から「都、府、県」を削除

<iframe src="https://paiza.io/projects/e/0Hb1hDNvG5qtVetsUhslNw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## 大文字小文字を区別しないで置換（str_ireplace）

検索対象文字列の大文字小文字を区別しないで置換するにはstr_ireplace関数を使用します。

<p class="tmp"><span>書式</span></p>
```
str_ireplace( 検索文字列 , 置換後文字列 , 検索対象文字列 [, int $count ] )
```
※第四引数には文字列が一致して置換が行われた箇所の個数が格納されます。

<iframe src="https://paiza.io/projects/e/ut1Xa_XdB1O0GhygtkdifA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

str_replaceでは「APPLE」は置換されませんが、str_ireplaceでは大文字小文字の区別なく「APPLE」も置換されています。


## 文字の変換、部分文字列の置換（strtr）

文字の変換または、部分文字列の置換を行うにはstrtr関数を使用します。

<p class="tmp"><span>書式</span></p>
```
string strtr( 検索対象文字列 , 検索文字列 , 置換後文字列 )
```
<iframe src="https://paiza.io/projects/e/k7aPEVZjqYkdJJtC3aqOag?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


## 指定した範囲で置換する（substr_replace）

指定した範囲の一部の文字列のみを置換したい場合は、substr_replace関数を使用します。

<p class="tmp"><span>書式</span></p>
```
substr_replace( 検索対象文字列 , 置換後文字列 , 置換位置 [, 置換する範囲 ] )
```
※第三引数に置換する文字列の位置を指定し、第四引数を指定した場合は置換位置からの置換する文字数の範囲を指定します。

<div class="exp">
	<p class="tmp"><span>例1</span></p>
	<iframe src="https://paiza.io/projects/e/1Vbc80TtZHNjDs0h1UA4VQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

「ABCDE*01234*」の6文字目以降の「01234」を「#」に置換しています。

<div class="exp">
	<p class="tmp"><span>例2</span></p>
	<iframe src="https://paiza.io/projects/e/zxBdzj6_-KDj7rNyCcHKuQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
</div>

「ABCDE*012*34」の6文字目以降の3文字の「012」を「#」に置換しています。


## 正規表現で置換する（preg_replace）

指定した正規表現にマッチした文字列を置換したい場合はpreg_replace関数を使用します。  
preg_replace関数は引数に指定した正規表現パターンをもとに一致した文字列があったら置換後の文字列に置き換えます。

<p class="tmp"><span>書式</span></p>
```
preg_replace(正規表現, 置換後の文字列, 対象の文字列 [, 置換する個数 ] );
```


第一引数　：　正規表現を記載する。  
第二引数　：　置換後の文字列を指定する。区切り文字の / などは不要です。  
第三引数　：　パターンマッチの対象となる文字列を指定する。  
第四引数　：　（省略可能）１つだけ置換したい場合は１を指定。

### サンプル3-1
現在の西暦は2016年です → 現在の西暦は 2017年です  に置換
※2017の前に半角スペースができてしまう。
<div class="exp">
	<p class="tmp"><span>例3-1</span></p>
現在の西暦は2016年です → 現在の西暦は 2017年です  に置換  
※2017の前に半角スペースができてしまう。
<iframe src="https://paiza.io/projects/e/I8UQ_CfrDDYemVa9_dM91Q?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>
</div>

### サンプル3-2
a dog → a dog race に置換
<div class="exp">
	<p class="tmp"><span>例3-2</span></p>
	a dog → a dog race に置換
<iframe src="https://paiza.io/projects/e/a6TuBo8EGquJBCR_m6KqCg?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>	
</div>


<div class="exp">
	<p class="tmp"><span>例3-3</span></p>
	He110 W0r1d, enj0y 5tudying → Hello World, enjoy studying　に置換
	<iframe src="https://paiza.io/projects/e/K6M9b78pZXoR3iSs3XW8Ng?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>
</div>


### サンプル3-4
ダミーテキストです。（youtube "URL" ##float-left## @@はつかいち物語　愛の取調べ室【PR動画】@@）ダミーテキストです。ダミーテキストです。  
→
```
ダミーテキストです。<span class=" float-left embed-responsive embed-responsive-16by9">
<iframe class="embed-responsive-item" src= "URL" allowfullscreen></iframe><span class="yh-caption"> はつかいち物語　愛の取調べ室【PR動画】 </span>
</span>ダミーテキストです。ダミーテキストです。
````
に置換

<p class="tmp list"><span>リスト</span>$1,$2,$3 を使用</p>
```
（youtube (.*) ##(.*)## @@(.*)@@）/i
```

<iframe src="https://paiza.io/projects/e/-UU-WQSL19InFjn9TniSKw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


### サンプル3-5

変数が入ったテキストを置換。$1,$2,$3 を使用

<iframe src="https://paiza.io/projects/e/s8Xom9AWpKpqtzgVMdZmAA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


### サンプル3-6

タグを置換

<iframe src="https://paiza.io/projects/e/S6xtejpgRrYQuAROpJb1mg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

または、下記でもできます。  
例) button要素を削除する場合
```
$patterns = '/<button>(.*)<\/button>/';
$reg = preg_replace($patterns, '', $test);
```

### サンプル3-7

<p class="tmp"><span>書式3-1</span>scriptタグを除去</p>
```
$md = preg_replace('/<script.*?>.*?<\/script>/ims', '', $md);
```
$md～変換対象

<p class="tmp"><span>書式3-2</span>scriptタグを文字列に変換</p>
```
$md = preg_replace('/<script(.*?)>(.*?)<\/script>/ims', '&lt;script$1&gt;$2&lt;/script&gt;', $md);
```
$md～変換対象

## 正規表現の特殊文字をエスケープする（preg_quote）

参考サイト
: [[PHP] 正規表現の特殊文字をエスケープするpreg_quote()](http://kihon-no-ki.com/preg_quote-to-replace-special-characters)

preg_quote関数で正規表現の特殊記号が含まれる対象文字をエスケープしてから、正規表現を使った検索や置換をおこなうことができます。  
特殊文字の前に「\」が付きます。

<p class="tmp list"><span>リスト</span></p>
```
$str = '-._~%:/?#[]@!$&\'()*+,;=';
$str = preg_quote( $str , '/');
echo $str; //結果  \-\._~%\:\/\?#\[\]@\!\$&'\(\)\*\+,;\= 
```


## 参考にしたサイト

* [【PHP入門】文字列の置換 | str_replace・str_ireplace・strtr](https://www.sejuku.net/blog/23430)
* [【5分でまるっと理解】PHP正規表現の使い方まとめ](https://eng-entrance.com/php-regularex)
* [PHPでstr_replaceやstrtrを使って複数文字を置換する](https://qiita.com/ryoo_ss/items/8ca05de64d7c583df0dc)
* [PHP preg_replace 正規表現で特定のHTMLタグをテキストから削除する](https://over-creation-studio.jp/2379)
* [HTMLからスクリプトタグを除去する](http://php-reference.goodhead.work/pages/2493)




