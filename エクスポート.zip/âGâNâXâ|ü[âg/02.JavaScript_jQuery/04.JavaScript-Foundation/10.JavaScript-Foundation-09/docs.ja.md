---
title: '10. デバッグ方法'
taxonomy:
    category:
        - docs
visible: true
---

デバッグ（debug）とは、プログラムの欠陥（バグ）を発見および修正し、正しく動作するための作業です。  
プログラム内でメッセージを表示して、動作を確認することができます。  
メッセージを表示する方法をご紹介します。

---

## アラート表示
ダイアログという小窓で、メッセージを表示します。

<iframe width="100%" height="200" src="//jsfiddle.net/58tbek2j/5/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

---

## コンソール表示
ブラウザのコンソール画面に、メッセージを表示します。

<!--<iframe width="100%" height="200" src="//jsfiddle.net/58tbek2j/7/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>-->
<iframe width="100%" height="300" src="//jsfiddle.net/5870k9a1/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

ブラウザごとのコンソール画面の表示方法は下記になります。  

|ブラウザ                   |ツール名            |起動方法           |
|--------------------------|------------------|------------------|
|Chrome                    |デベロッパーツール   |Ctrl + Shift + I  |
|Firefox                   |開発ツール/Firebug  |Ctrl + Shift + I  |
|Internet Explorer / Edge  |開発ツール          |F12               |
---

## 注意点

デバッグ用にメッセージを表示する処理を記述しているので、リリースする際は処理を削除する必要があります。  
また、デバッグ方法は今回紹介した上記以外にもあります。  
そちらの方は次の「ステップ実行でデバッグする」でご紹介させていただきます。

