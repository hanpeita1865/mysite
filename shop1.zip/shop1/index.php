<?php
// セッションの開始
session_start();

//フラッシュメッセージ
if( isset($_SESSION['flash']) ){
	$flash_success = $_SESSION['flash']['success'];
  }

unset($_SESSION['flash']);

if (isset($flash_success)){
	foreach ((array)$flash_success as $message){
		echo '<p class="feedback">'.$message.'</p>';
	}
}
?>

<?php
//ログインしているか確認
if (!isset($_SESSION['user'])) {
	//ログイン画面に移動
	header('Location:login.php');
	exit();
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>商品一覧管理ページ</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<div class="container">
		<?php
		$pdo = new PDO('mysql:host=localhost;dbname=shop1;charset=utf8', 'staff', 'password');
		?>
		<div class="btn-box">
			<form action="insert-input.php" method="post">
				<input type="submit" value="新規登録">
			</form>
			<form action="logout-input.php" method="post">
				<p class="submit"><input type="submit" id="logout-button" value="ログアウト"></p>
			</form>
		</div>
		<table>
			<caption>商品一覧管理ページ</caption>
			<thead>
				<tr>
					<th>商品名</th>
					<th>生産地</th>
					<th>価格</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($pdo->query('select * from products') as $row): ?>
				<tr>
					<td><?= $row['name'] ?></td>
					<td><?= $row['local'] ?></td>
					<td><?= $row['price'] ?></td>
					<td>
						<form action="update-input.php" method="get">
							<input type="hidden" name="id" value="<?= $row['id'] ?>">
							<input type="submit" value="編集">
						</form>
					</td>
				</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
	<script src="js/admin.js"></script>
</body>
</html>
