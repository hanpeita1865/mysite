*[page-title]:08. Bladeの構文

Bladeでは、レイアウト内で表示を制御したり、レイアウトを継承して複数を組み合わせたりするための構文が用意されています。それらについて使い方を説明しましょう。

## 値の表示
Bladeには、さまざまな機能が用意されており、それらを実装するための構文も揃っています。この構文の書き方がわからないと、Bladeの機能を引き出すことはできません。 ここでBladeの基本的な構文の使い方について説明しておきましょう。  
まずは、値を埋め込む <span class="red bold">{{ }}</span> からです。これは、変数などを埋め込むのに既に使いました。
<p class="tmp"><span>書式1</span>値、変数、式、関数などを埋め込む</p>
```
{{ 値・変数・式・関数など }}
```

このように、<span class="red bold">{{</span> と <span class="red bold">}}</span> の間に文を書くことで、その文が返す値をその場に書き出します。 値として扱えるものであれば、関数でもメソッドでも指定することができます。  
この「<span class="red bold">{{}}</span>」の出力は、基本的にHTMLエスケープ処理されます。HTMLタグなどをテキストとして設定した場合も、すべてエスケープ処理されるため、タグはテキストとして表示され、HTMLのタグとしては機能しません。 もし、エスケープ処理されてほしくない場合は、以下のように記述します。
<p class="tmp"><span>書式2</span>エスケープ処理しない</p>
```
{!! 値・変数・式・関数など !!}
```
<span class="red bold">{!!</span> と<span class="red bold"> !!}</span> の間に値を設定します。これで、値はエスケープ処理されなくなり、HTMLタグなどはそのままタグとして機能するようになります。


## @if ディレクティブ
Bladeには、「<span class="green bold">ディレクティブ</span>」と呼ばれる機能があります。これは、言語における構文のような役割を果たします。これは、いくつかの種類が用意されています。  
まずは、<span class="red">条件分岐（if文）</span>に相当するディレクティブからです。これは以下のように利用します。

<p class="tmp"><span>書式3-1</span>条件がtrueの時に表示をする</p>
```
@if ( 条件 )
	･･･出力内容･･･
@endif
```

<p class="tmp"><span>書式3-2</span>条件によって異なる表示をする</p>
```
@if ( 条件 )
	･･･出力内容･･･
@else
	･･･出力内容･･･
@endif
```

<p class="tmp"><span>書式3-3</span>複数の条件を設定する</p>
```
@if ( 条件 )
	･･･出力内容･･･
@elseif ( 条件)
	･･･出力内容･･･
@else 
	･･･出力内容･･･
@endif
```

ディレクティブは、基本的に「<span class="red">@ディレクティブ名</span>」という形で記述します。「<span class="red">@if</span>」は、その後に条件を設定します。その条件がtrueならば、それ以降~ @endifまでの部分を表示します。
  
基本的には、PHPのif文の働きと同じです。違いは、ディレクティブの場合は何かを実行するのではなく「<span class="red">表示する</span>」という点です。  
「<span class="marker-yellow50">条件がtrueならこれを表示する、falseならこれを表示する</span>」というように、 条件に応じて表示する内容を制御するのが「<span class="green bold">@ifディレクティブ</span>」です。


### @if を利用する
では、実際に@ifディレクティブを使ってみましょう。Hello3Controller.phpを新規作成します。hello3フォルダを作成してその中のindex.blade.phpのコードを次のように修正してください。

<p class="tmp list"><span>リスト1</span>hello3/index.blade.php</p>
```
<body>
   <h1>Blade/Index</h1>
   @if ($msg != '')
   <p>こんにちは、{{$msg}}さん。</p>
   @else
   <p>何か書いて下さい。</p>
   @endif
   <form method="POST" action="/hello3If">
       {{ csrf_field() }}
       <input type="text" name="msg">
       <input type="submit">
   </form>
</body>
```

ここでは、@ifを利用し、**$msg != "がtrue**ならば（つまり、$msgに何か値があるならば）、 **$msgを使ったメッセージ**を表示しています。そして条件が**false**ならば（つまり$msgが 空ならば）、「**何か書いて下さい。**」と表示させています。  
後は、コントローラ側で$msgの値の設定を行うようにアクションメソッドを修正しておくだけです。Hello3Controller.phpのHelloControllerクラスを以下のように修正して 下さい。

<p class="tmp list"><span>リスト2</span>Hello3Controller.php</p>
```
class Hello3Controller extends Controller
{
   public function index()
   {
       return view('hello3.index', ['msg'=>'']);
   }

   public function post(Request $request)
   {
       return view('hello3.index', ['msg'=>$request->msg]);
   }
}
```

ルート情報を追記します。

<p class="tmp list"><span>リスト3</span>web.php</p>
```
Route::get('hello3if', [\App\Http\Controllers\Hello3Controller::class,'index']);
Route::post('hello3if', [\App\Http\Controllers\Hello3Controller::class,'post']);
```

修正したら、「/hello3If」にアクセスして動作を確認しましょう。アクセスすると、「何か書いて下さい」と表示されます。テキストを書いて送信すると、メッセージに変わります。何も送信されたテキストがないと**$msg**が空になり、**@else**の表示がされるようになります。

![](upload/helloIf何か書いてください.png){.photo-border}

テキストを記入して「送信」ボタンを押します。
![](upload/Laravel勉強中.png){.photo-border}

「こんにちは、〇〇〇さん。」と表示
![](upload/Laravel勉強中送信.png){.photo-border}

空白のまま「送信」ボタンを押すと、$msgが空になり、@elseの「何か書いてください」表示がされるようになります。
![](upload/Hello3If空で送信.png)

## 特殊なディレクティブ
@ifは、条件分岐の基本となるディレクティブですが、その他にも@ifと同じように分岐処理を行うディレクティブがいくつか用意されています。ここでまとめておきましょ う。いずれも@ifと同様、オプションとして@elseを追加することができます。

<p class="tmp"><span>書式4-1</span>条件が非成立の時に表示</p>
```
@unless ( 条件 )  
	･･･出力内容･･･ 
@endunless
```
@ifの逆の働きをするものです。@unlessは、*条件がfalseの場合に表示を行い、trueの 場合は表示をしません*。   
@elseを用意した場合は、条件がtrueのときに表示されるようになります。

<p class="tmp"><span>書式4-2</span>変数が空の場合に表示</p>
```
@empty ( 変数 )
	･･･出力内容･･･
@endempty
```
()に指定した変数が空の場合に表示を行うためのものです。 @elseは、<span class="red">変数が空でない（値が設定されている）場合</span>に表示されます。

<p class="tmp"><span>書式4-3</span>変数が定義済みの場合に表示</p>
```
@isset ( 変数 )
	･･･出力内容･･･
@endisset
```
@emptyと似ていますが、こちらは変数そのものが定義されているかどうかを確認するものです。<span class="red">変数が定義されている（そしてnullではない）場合</span>に表示を行います。  
@else を用意することで、変数が未定義だった場合の表示を用意できます。

### @isset で変数定義をチェックする
では、例として<span class="red bold">@isset</span>を利用したサンプルを挙げておきましょう。先ほどの@ifのソー スコードを修正し、@isset利用に変更してみます。  
index.blade.phpの&lt;body&gt;タグ部分を 以下のように修正しましょう。

<p class="tmp list"><span>リスト4</span>index.blade.php</p>
```
<body>
   <h1>Blade/Index</h1>
   @isset ($msg)
   <p>こんにちは、{{$msg}}さん。</p>
   @else
   <p>何か書いて下さい。</p>
   @endisset
   <form method="POST" action="/hello">
       {{ csrf_field() }}
       <input type="text" name="msg">
       <input type="submit">
   </form>
</body>
```

ここでは、@issetで$msgが定義されているかどうかをチェックし、されていればメッセージを表示するようにしてあります。  
これに合わせて、HelloControllerクラスも以下のように書き換えておきます。

<p class="tmp list"><span>リスト5</span>HelloController.php</p>
```
class HelloController extends Controller
{
  
   public function index()
   {
       return view('hello.index');
   }

   public function post(Request $request)
   {
       return view('hello.index', ['msg'=>$request->msg]);
   }

}
```

ここでは、indexアクションメソッドでは値をテンプレートに渡していません。渡していませんから、テンプレート側では当然、<span class="red">$msg</span>は未定義になります。  
<span class="red">@isset($msg)</span>は <span class="red">false</span>となるわけです。  
このように、「<span class="marker-yellow50">GET時には値はない</span>」「<span class="marker-yellow50">POSTされると値が渡される</span>」という処理を<span class="red">@isset </span>で分岐することができます。これによりコードがシンプルになっているのがわかるでしょう。


## 繰り返しのディレクティブ
「繰り返し関係のディレクティブも何種類かのものが用意されています。これらもまとめて整理しておきましょう。

PHPのfor構文に相当するディレクティブです。for構文と同様に、( )内に *初期化処理、 繰り返し条件、繰り返し*の後処理の3つを用意します。
<p class="tmp"><span>書式5-1</span>for構文に相当するもの</p>
```
@for ( 初期化 ; 条件 ; 後処理 ) 
	･･･繰り返す表示･･･
@endfor
```

PHPのforeach構文に相当するディレクティブです。()内には、<span class="red">配列</span>と<span class="red">変数</span>を用意します。  
これにより、配列から値を変数へと取り出す処理を繰り返していきます。
<p class="tmp"><span>書式5-2</span>foreach構文に相当するもの</p>
```
@foreach( $配列 as $変数 ) 
	･･･繰り返す表示･･･
@endforeach
```

次は、foreach構文にelseを追加した場合の処理に相当するものです。  
()の配列から 順に値を取り出して処理を繰り返していく点は@foreachと同じです。  
値をすべて取り出し終えて取り出せなくなったとき、<span class="red">@empty</span>にある処理を実行して繰り返しを終えます。
<p class="tmp"><span>書式5-3</span>foreach-else構文に相当するもの</p>
```
@forelse ( $配列 as $変数 ) 
	･･･繰り返す表示･･･
@empty 
	･･･$変数が空のときの表示･･･
@endforelse
```

PHPのwhile構文に相当するものです。引数に条件を設定し、その条件がtrueの場合に 表示を行います。  
ただし、whileでは、実行時に条件で使っている変数などの値が変化しなければ無限ループとなってしまうため、ディレクティブ内で何らかの処理を実行する必要がありま す。これには、この後で触れる**@phpディレクティブ**が必要となるでしょう。
<p class="tmp"><span>書式5-4</span>while構文に相当するもの</p>
```
@while 
	･･･繰り返す表示･･･
@endwhile
```


### 繰り返しディレクティブを利用する
では、実際に簡単なサンプルを作成して、繰り返しのディレクティブがどう機能するか確かめてみましょう。  
ここでは、<span class="red bold">@foreachディレクティブ</span>を利用してみることにします。index.blade.phpの &lt;body&gt;タグ部分を以下のように書き換えましょう。

<p class="tmp list"><span>リスト6</span>hello5/index.blade.php</p>
```
<body>
   <h1>Blade/Index</h1>
   <p>&#064;foreachディレクティブの例</p>
   <ol>
   @foreach($data as $item)
   <li>{{$item}}
   @endforeach
   </ol>
</body>
```

ここでは、@foreachディレクティブに<span class="red"> ($data as Sitem) </span>という形で繰り返しの設定を用意しています。これにより、<span class="red">$data</span> から順に値を取り出して<span class="red"> $item</span>に代入する、という 繰り返しが実行されます。コントローラ側では、$dataに配列を渡すようにしておけば いいのです。
では、Hello5Controllerクラスの修正をしましょう。indexアクションメソッドを以下のように書き換えて下さい。

<p class="tmp list"><span>リスト7</span>Hello5Controller.php</p>
```
public function index() {
    $data = ['one', 'two', 'three', 'four', 'five'];
    return view('hello5.index', ['data'=>$data]);
}
```

ルート情報を追加します。
<p class="tmp list"><span>リスト8</span>web.php</p>
```
Route::get('hello5Foreach', [\App\Http\Controllers\Hello5Controller::class,'index']);
```

<http://localhost:8000/hello5Foreach>にアクセスします。

![](upload/hello5Foreach.png){.photo-border}

「one」「two」「three」「four」「five」と5つ の項目がリスト表示されます。  
ここでは、<span class="red">$data</span> にこれらの値を配列としてまとめたものを代入しています。  
そして、viewメソッドでは、「<span class="red">data'=>$data</span>]というように <span class="red">$data</span> を<span class="red"> 'data'</span> に設定してテンプレートに渡しています。  
これで、テンプレート側では$dataでデータの配列が利用できるようになります。


## @breakと@continue

PHPの繰り返し構文では、<span class="red bold">break</span>や<span class="red bold">continue</span>といったキーワードが用意されていて、これらを使って繰り返しの中断や次のステップへの継続処理などが行えるようになっていました。 繰り返しディレクティブでも、これに相当するものが用意されています。

@break
: PHPのbreakに相当。これが出力されると、その時点で繰り返しの ディレクティブが中断されます。

@continue
: 「PHPのcontinueに相当。

では、実際に利用例を挙げておきましょう。  
index.blade.phpの&lt;body&gt;タグ部分を以下のように書き換えて下さい。

<p class="tmp list"><span>リスト9</span>hello6/index.blade.php</p>
```html
<body>
   <h1>Blade/Index</h1>
   <p>&#064;forディレクティブの例</p>
   <ol>
   @for ($i = 1;$i < 100;$i++)
   @if ($i % 2 == 1)
       @continue
   @elseif ($i <= 10)
   <li>No, {{$i}}
   @else
       @break
   @endif
   @endfor
   </ol>
</body>
```

コントローラーを作成します。

<p class="tmp list"><span>リスト10</span>Hello6Controller.php</p>
```
class Hello6Controller extends Controller {

    public function index() {
        return view('hello6.index');
    }
 }
```

ルート情報を追加します。
<p class="tmp list"><span>リスト11</span>web.php</p>
```
Route::get('hello6Break', [\App\Http\Controllers\Hello6Controller::class,'index']);
```


/hello6Breakにアクセスすると、「No,2」「No,4」「No,6」「No,8」「No,10」と項目が表示されます。  

![](upload/hello6Break.png){.photo-border}

ここでは、@for ($i = 1; $i < 100;$i++)というように、1~100の間で繰り返しを実行しています。このままでは、No,1~No,99の項目が表示されるはずです が、繰り返しの中では、まず <span class="red">@if ($i % 2 == 1) </span>をチェックしています。これで、$iが 2で割って1あまる(つまりSiが奇数である)場合は <span class="red">@continue</span> ですぐに次の繰り返しへ進むようになります。  
更にその後の <span class="red">@elseif ($i <= 10) </span>により、iが10を超えたら <span class="red">@break</span> するようにしています。これにより、<span class="red">1~10の範囲で偶数の値だけが出力されていた</span>、というわけです。


## $loopによるループ変数

繰り返しディレクティブには、「$loop」という特別な変数が用意されています。これは「ループ変数」と呼ばれるもので、繰り返しに関する情報などを得ることができます。  
この$loopはオブジェクトになっており、繰り返しに関するプロパティがいろいろと用意されています。以下に整理しておきましょう。


|	|	|
|--|--|
|**$loop->index**|現在のインデックス(ゼロから開始)|
|**$loop->iteration**|現在の繰り返し数(1から開始) |
|**$loop->remaining**|あと何回繰り返すか(残り回数)|
|**$loop->count**|繰り返しで使っている配列の要素数|
|**$loop->first**|最初の繰り返しかどうか(最初ならtrue)|
|**$loop->last**|最後の繰り返しかどうか(最後ならtrue)|
|**$loop->depth**|繰り返しのネスト数|
|**$loop->parent**|ネストしている場合、親の繰り返しのループ変数を示す|
         
これらの値を参照することで、現在の繰り返しの状態が知られます。では、これらを利用した簡単なサンプルを挙げておきましょう。  
テンプレートを以下のように記入して下さい。

<p class="tmp list"><span>リスト12</span>hello7/index.blade.php</p>
```
<body>
   <h1>Blade/Index</h1>
   <p>&#064;forディレクティブの例</p>
   @foreach ($data as $item)
   @if ($loop->first)
   <p>※データ一覧</p><ul>
   @endif
   <li>No,{{$loop->iteration}}. {{$item}}</li>
   @if ($loop->last)
   </ul><p>――ここまで</p>
   @endif
   @endforeach
</body>
```

コントローラーを作成します。

<p class="tmp list"><span>リスト13</span>Hello7Controller.php</p>
```
class Hello7Controller extends Controller {

    public function index() {
        $data = ['one', 'two', 'three', 'four', 'five'];
        return view('hello7.index', ['data'=>$data]);
    }

 }
```

ルート情報を追加します。
<p class="tmp list"><span>リスト14</span>web.php</p>
```
Route::get('hello7Loop', [\App\Http\Controllers\Hello7Controller::class,'index']);
```

<http://localhost:8000/hello7Loop>にアクセスします。

![](upload/hello7Loop.png){.photo-border}

/hello7Loop にアクセスすると、最初に「※データ一覧」、最後に「 ここまで」とメッセー ジが表示され、その間にデータのリストがナンバリングされて表示されます。  
ここでは@foreachディレクティブ内で、まず「<span class="red">@if ($loop->first)</span>」をチェックしています。 これで、最初の繰り返しの時にこの@ifディレクティブ部分が出力されます。同様に、 「<span class="red">@if ($loop->last)</span>」では最後の繰り返しの時に出力される内容が用意されます。  
項目を出力しているところでは、「<span class="red">No,{{$loop-Siteration}}</span>」 というようにして、繰り返し回数を冒頭に表示させています。  
このように、$loopを利用することで、繰り返しの状態などに応じた表示を比較的簡単に作成していくことができます。  
（なお、&lt;p&gt;タグ部分で「&#064;for」とあるのは、@forをテキストとして表示させるためです。そのまま@forと書くとBladeのキーワードとして認識されてしまうので、文字コードに変換して書いてあります。）


## @phpディレクティブについて
ディレクティブは、制御構文のような機能をテンプレートに簡単に組み込むことができますが、PHPのスクリプトそのものではありません。ifやforは利用できても、それだけで複雑な処理を組み立てられるわけではありません。PHPのスクリプトを直接実行することも必要となる場合があるでしょう。  
PHPのスクリプトは、@phpというディレクティブを使って記述することができます。 これは以下のように利用します。
```
@php
･･･PHP のスクリプト･･･
@endphp
```
このディレクティブを使えば、Bladeテンプレート内で直接スクリプトを実行し、必要な処理を行うことができます。  
では、これも利用例を見てみましょう。先に、@whileという繰り返しのディレクティブを紹介しましたが、これはスクリプトで変数などの操作を行わないとうまく使いこな せません。@phpを併用して@whileを使ってみることにしましょう。

<p class="tmp list"><span>リスト15</span>hello8/index.blade.php</p>
```
<body>
   <h1>Blade/Index</h1>
   <p>&#064;whileディレクティブの例</p>
   <ol>
   @php
   $counter = 0;
   @endphp
   @while ($counter < count($data))
   <li>{{$data[$counter]}}</li>
   @php
   $counter++;
   @endphp
   @endwhile
   </ol>
</body>
```

<p class="tmp list"><span>リスト16</span>Hello8Controller.php</p>
```
class Hello8Controller extends Controller {

    public function index() {
        $data = ['one', 'two', 'three', 'four', 'five'];
        return view('hello8.index', ['data'=>$data]);
    }
 }
 ```
 
 <p class="tmp list"><span>リスト17</span>web.php</p>
 ```
 Route::get('hello8Php', [\App\Http\Controllers\Hello8Controller::class,'index']);
 ```

<http://localhost:8000/hello8Php>にアクセスします。

![](upload/hello8Php.png){.photo-border}

ここでは、まずScounter = 0%というように変数$counterを初期化しています。そして @whileの繰り返し部分では、$counter++;で$counterを1増やしています。これで順に配列の項目を出力していき、@while ($counter < count($data))の条件がfalseになった ら($counterの値が配列の要素数になったら)繰り返しを抜けます。このように、変数の 操作を行うスクリプトを少し足すことで、@whileが使えるようになります。  

ただし、「それなら、@phpでどんどん処理を書いていけばいい」とは考えないで下さい。 テンプレートは、本来、「処理と表示を切り離す」ために用意されたものです。<span class="marker-yellow30">処理はコ ントローラ(アクション)で行い、テンプレートは表示を担当</span>する、それが基本です。  
ですから、あまり複雑なスクリプトを<span class="bold">@php</span>で記述する必要が生じたなら、「そのアプロー チ自体が間違ったやり方ではないか」ということを考えてみて下さい。 テンプレートに用意するスクリプトは必要最小限に。それが@php利用の基本です。



