<?php
namespace SocymSlim\SlimMiddle\Services;

use PDO;
use SocymSlim\SlimMiddle\Config\AppConfig;
use SocymSlim\SlimMiddle\Config\PageArea;//追加


class MenuService
{
    private array $lockData = [];
    private array $lockArray = [];
    private AppConfig $config;   
    private FolderService $folderService;
    private EditService $editService;
    
    public function __construct(AppConfig $config, FolderService $folderService, EditService $editService)
    {
        $this->config = $config;
        $this->folderService = $folderService;
        $this->editService = $editService;
    }
    
    
    
    public function getLockArray(): array
    {
        return $this->lockArray;
    }

    
    //---------------------------//
    //   DBからロック情報を取得   
    //--------------------------//

    public function loadLockData(PDO $db, array $folderObj): void
    {
        $stmt = $db->prepare('SELECT page, under_dir FROM locklist');
        $stmt->execute();
        $this->lockData = $stmt->fetchAll(PDO::FETCH_COLUMN | PDO::FETCH_GROUP);

        foreach ($this->lockData as $key => $value) {
            if (array_key_exists($key, $folderObj)) {
                if ($this->lockData[$key][0] === 'all') {
                    $folder_dir = preg_quote($folderObj[$key], '/');
                    $dir_group = preg_grep('/' . $folder_dir . '/', $folderObj);
                    $this->lockArray = array_merge($this->lockArray, $dir_group);
                }
            }
        }
    }
    
    
    
    
    //-------------------------------//
    //   検索メニュー構築
    //-------------------------------//

    public function buildSearchMenu(string $pageDir = '../pages'): array {
        return $this->getTopLevelFolders($pageDir);
    }
    
    // public function buildSearchMenu(): array {
    //     return $this->getTopLevelFolders('../pages');
    // }
    
    

    //---------------------------------------//
    //  第一階層フォルダを取得
    //--------------------------------------//
    
    public function getTopLevelFolders(string $folder): array {
        $folderFirst = [];

        if (!is_file($folder)) {
            $res = glob($folder . '/*');

            foreach ($res as $f) {
                $dirArray = explode('/', $f);
                $lastDir = end($dirArray);

                // 先頭3桁＋ドット付きフォルダのみ
                if (preg_match('/^\d{3}\./', $lastDir)) {
                    $folderNoNum = preg_replace('/^\d{3}\./', '', $lastDir);

                    if (file_exists($f . '/markdown.md')) {
                        $md = file_get_contents($f . '/markdown.md');

                        if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md)) {
                            $folderFirst[$folderNoNum] = $lastDir;
                        }
                    }
                }
            }
        }

        return $folderFirst;
    }
    



    //---------------------------//
    //   メニュー生成   
    //--------------------------//
    
    public function buildMenuCached(string $folder): string
    {
        $cacheDir = '../cache/menu/';

        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0777, true);
        }

        $userType = isset($_SESSION['auth_user']['name']) ? 'admin' : 'guest';
        
        //通常を基本形にして
        if ($folder === '../manual/pages') {
            $cacheFile = $cacheDir . "menu_manual_{$userType}.php";
        } else {
            $cacheFile = $cacheDir . "menu_{$userType}.php";
        }

        // キャッシュがあれば使う
        if (file_exists($cacheFile)) {
            return file_get_contents($cacheFile);
        }

        $menu = $this->buildMenu($folder);

        file_put_contents($cacheFile, $menu);

        return $menu;
    }




    public function buildMenu(string $folder, bool $isAdmin = false): string
    {
        $menuCode = '';

        // --- コンテナ登録済み情報を取得 ---
        $basePath = $this->config->basePath;
        
        $lockData = $this->lockData; // プロパティから取得
        $lockArray = $this->lockArray; // プロパティから取得
        
        error_log('service: ' . spl_object_id($this));//テスト


        if (!is_file($folder)) {
            $entries = glob($folder . '/*');
            
            foreach ($entries as $entry) {
                $dirArray = explode('/', $entry);
                $lastDir = end($dirArray);

                // 先頭3桁＋ドットのディレクトリ名のみ対象
                if (!preg_match('/^\d{3}\./', $lastDir)) {
                    continue;
                }

                // パス整形
                // $path = str_replace('../pages/', '', $entry) . '/';
                $path = str_replace($folder . '/', '', $entry) . '/';
                $pathRe = preg_replace('/^\d{3}\./', '', $path);
                $pathRe = preg_replace('/\/\d{3}\./', '/', $pathRe);
                
                // $pathBase = $folder === '../manual/pages'
                //     ? $basePath . '/public/manual/pages/'
                //     : $basePath . '/public/pages/';
                
                $pageArea = PageArea::fromPageDir($folder);
                $pathBase = PageArea::getUrlBase($pageArea, $basePath);
                    
                $link = $pathBase . $pathRe;
                // $link = $basePath . '/public/pages/' . $pathRe;

                // markdown.md からタイトル抽出
                $title = preg_replace('/^\d{3}\./', '', $lastDir);
                if (file_exists($entry . '/markdown.md')) {
                    $md = file_get_contents($entry . '/markdown.md');
                    if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $match)) {
                        $title = $match[1];
                    }
                }

                // --- ロック判定（排他処理なし）---
                $lockCls = '';
                $showItem = true; // 初期値：表示する
                
                $pureName = preg_replace('/^\d{3}./', '', $lastDir);

                
                               
                if ($isAdmin) {
                    // 管理者
                    if (array_key_exists($pureName, $lockData)) {
                        $lockCls = 'all-lock';
                    }

                } else {
                    // 一般ユーザー
                    if (array_key_exists($pureName, $lockArray)) {
                        $showItem = false;
                    }
                }

                // 非表示対象はスキップ
                if (!$showItem) continue;
                
                
                // --- メニューHTML生成 ---
                
                // 現在の <li> に付けるクラスを準備
                $liClasses = ['box-item'];

                if ($lockCls) {
                    $aClassLock = "class=\"$lockCls\"";
                }else{
                    $aClassLock = '';
                }
                
                // 再帰：子要素を生成（子から hasActive を受け取る）
                $childHasActive = false;
                $childrenHtml = $this->buildMenu($entry/*, $boxNum, $childHasActive*/, $isAdmin);//引数 $isAdmin追加
                
                // もし子にアクティブがあれば親側に cate-active クラスを付ける
                if ($childHasActive) {
                    // 親 li を toggle + cate-active にしたいならこちらに追加
                    $liClasses[] = 'toggle';

                } elseif ($childrenHtml !== '') {
                    // 子がいるけどアクティブでない場合でも toggle クラスは付ける
                    $liClasses[] = 'toggle';
                }
                
                $menuCode .= sprintf(
                    '<li class="box-item" data-name="%s"><a href="%s"%s title="%s">%s</a>',
                    htmlspecialchars($pureName, ENT_QUOTES),
                    htmlspecialchars($link, ENT_QUOTES),
                    $aClassLock,
                    htmlspecialchars($title, ENT_QUOTES),
                    htmlspecialchars($title, ENT_QUOTES)
                );
                    
                // 子があれば挿入
                if ($childrenHtml !== '') {
                    $menuCode .= "\n<ul class=\"sub-menu\">\n{$childrenHtml}</ul>\n";
                }

                $menuCode .= "</li>\n";                               
            }
        }

        return $menuCode;
    }
    

    //----------------------------//
    //   管理画面用メニュー構築  
    //---------------------------//

    public function buildAdminMenu( string $folder = '../pages', int &$boxNum = 1, string $role = 'admin', string $pageDir): string {

        $menuCode = '';
        $basePath = $this->config->basePath;
                
        $pageAreaDir = PageArea::fromPageDir($folder);
        $baseUrl = PageArea::getUrlBase($pageAreaDir, $basePath);
        
        $lockData = $this->lockData;
        $lockArray = $this->lockArray;

        if (!is_file($folder)) {
            $entries = glob($folder . '/*');

            foreach ($entries as $entry) {
                $dirArray = explode('/', $entry);
                $lastDir = end($dirArray);

                if (!preg_match('/^\d{3}\./', $lastDir)) {
                    continue;
                }

                // $path = str_replace($folder . '/', '', $entry) . '/';
                $path = str_replace($pageDir . '/', '', $entry) . '/';//追加
                                
                $pathRe = preg_replace('/^\d{3}\./', '', $path);
                $pathRe = preg_replace('/\/\d{3}\./', '/', $pathRe);

                $title = preg_replace('/^\d{3}\./', '', $lastDir);
                if (file_exists($entry . '/markdown.md')) {
                    $md = file_get_contents($entry . '/markdown.md');
                    if (preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $match)) {
                        $title = $match[1];
                    }
                }

                // ロック判定
                $aClassLock = '';
                $btnLock = 'btn-lock';
                $lockText = 'ロック設定';

                $pureName = preg_replace('/^\d{3}./', '', $lastDir);

                if (array_key_exists($pureName, $lockData)) {
                    $aClassLock = 'class="all-lock"';
                    $btnLock = 'unlock';
                    $lockText = 'ロック解除';
                }

                // 下書き中判定
                $draftClass = 'btn-draft';
                $draftText = '下書き設定';

                $draftList = $this->folderService->temporaryList();

                if(in_array($pureName, array_column($draftList, 'fdName'), true)){
                    $draftClass = 'btn-draft is-use';
                    $draftText = '下書き中';
                }
                
                
                // 権限フラグ
                $isAdmin = ($role === 'admin');
                
                $titleAttr = $isAdmin ? 'クリックするとページ名を変更できます。' : '';
                
                $dataAttr = $isAdmin ? 'data-editable="1"' : '';

                // ボタン生成
                $buttons = '';

                // adminのみ
                if ($isAdmin) {
                    $buttons .= '<button class="folder-rename" data-bs-toggle="modal" data-bs-target="#folderModal" data-mode="rename">フォルダ名変更</button>';
                    $buttons .= '<button class="folder-del" data-bs-toggle="modal" data-bs-target="#fdDelModal">削除</button>';
                    $buttons .= sprintf('<button class="%s">%s</button>', $btnLock, $lockText);
                }

                // 共通（editor含む）
                $buttons .= sprintf('<button class="%s">%s</button>', $draftClass, $draftText);

                $menuCode .= sprintf(
                    '<li id="item%d" class="box-item"> <a href="%s"%s %s>%s</a> <div class="btn-wrap"> <span class="link-name">%s</span> %s </div>',
                    $boxNum,
                    htmlspecialchars($baseUrl . $pathRe, ENT_QUOTES),
                    $aClassLock,
                    $dataAttr,
                    htmlspecialchars($title, ENT_QUOTES),
                    $pureName,
                    $buttons
                );

                $boxNum++;

                // 子フォルダ再帰
                $children = $this->buildAdminMenu($entry, $boxNum, $role, $pageDir);//変更 $pageDirを追加
                
                if ($children !== '') {
                    $menuCode .= "\n<ul class=\"sub-menu\">\n{$children}</ul>\n";
                }
                

                $menuCode .= "</li>\n";
            }
        }

        return $menuCode;
    }
    
    
    
    
    //--------------------------------
    // キャッシュ再生成（folder + menu）
    //--------------------------------

    public function rebuildMenuCaches(): void
    {
        $folderCacheFile = '../cache/folder.php';
        $manualFolderCacheFile = '../cache/manual_folder.php';

        // ディレクトリ保証
        if (!is_dir('../cache/menu')) {
            mkdir('../cache/menu', 0777, true);
        }

        // ===== フォルダキャッシュ生成 =====

        $folderObj = $this->folderService->getFolderComp(PageArea::getPageDir(PageArea::NORMAL));
        $manualFolderObj = $this->folderService->getFolderComp(PageArea::getPageDir(PageArea::MANUAL));

        $tmpFolderFile = $folderCacheFile . '.tmp';
        $tmpManualFolderFile = $manualFolderCacheFile . '.tmp';

        file_put_contents(
            $tmpFolderFile,
            '<?php return ' . var_export($folderObj, true) . ';',
            LOCK_EX
        );

        file_put_contents(
            $tmpManualFolderFile,
            '<?php return ' . var_export($manualFolderObj, true) . ';',
            LOCK_EX
        );


        // ===== ロック情報取得 =====

        $db = $this->editService->db();

        $this->loadLockData($db, $folderObj);


        // ===== 通常・manualページのメニューキャッシュ生成 =====

        $areas = [
            PageArea::NORMAL,
            PageArea::MANUAL
        ];

        foreach ($areas as $pageArea) {

            $folder = PageArea::getPageDir($pageArea);
            $prefix = PageArea::getMenuCachePrefix($pageArea);

            $menuData = $this->getMenuData($folder);

            // 管理者用メニュー
            $menuAdmin = $this->buildMenuFromData(
                $menuData,
                true,
                $folder
            );

            // 一般ユーザー用メニュー
            $menuGuest = $this->buildMenuFromData(
                $menuData,
                false,
                $folder
            );

            $menuCacheAdmin = '../cache/menu/' . $prefix . 'admin.php';
            $menuCacheGuest = '../cache/menu/' . $prefix . 'guest.php';

            $tmpAdminFile = $menuCacheAdmin . '.tmp';
            $tmpGuestFile = $menuCacheGuest . '.tmp';

            file_put_contents(
                $tmpAdminFile,
                $menuAdmin,
                LOCK_EX
            );

            file_put_contents(
                $tmpGuestFile,
                $menuGuest,
                LOCK_EX
            );

            rename($tmpAdminFile, $menuCacheAdmin);
            rename($tmpGuestFile, $menuCacheGuest);
        }


        // ===== フォルダキャッシュを差し替え =====

        rename($tmpFolderFile, $folderCacheFile);
        rename($tmpManualFolderFile, $manualFolderCacheFile);
    }

    
    
  
    //---------------------------
    // メニュー用フォルダ情報取得
    //---------------------------

    public function getMenuData(string $folder): array
    {
        $menuData = [];

        if (!is_dir($folder)) {
            return $menuData;
        }

        $entries = glob($folder . '/*', GLOB_ONLYDIR);

        foreach ($entries as $entry) {

            $lastDir = basename($entry);

            // 先頭3桁＋ドット以外は対象外
            if (!preg_match('/^(\d{3})\.(.+)$/', $lastDir, $match)) {
                continue;
            }

            $folderNo = $match[1];
            $pureName = $match[2];

            // markdown.mdからタイトル取得
            $title = $pureName;
            $mdPath = $entry . '/markdown.md';

            if (is_file($mdPath)) {

                $md = file_get_contents($mdPath);

                if (
                    preg_match(
                        "/^\*\[page-title\]:\s*(.+)/",
                        $md,
                        $titleMatch
                    )
                ) {
                    $title = $titleMatch[1];
                }
            }

            // 子フォルダも取得
            $children = $this->getMenuData($entry);

            $menuData[] = [
                'folderNo' => $folderNo,
                'name' => $pureName,
                'path' => $entry,
                'title' => $title,
                'children' => $children
            ];
        }

        return $menuData;
    }


        
    //---------------------------
    // メニューデータからHTML生成
    //---------------------------

    public function buildMenuFromData(
        array $menuData,
        bool $isAdmin = false,
        string $folder = '../pages'
    ): string
    {
        $menuCode = '';

        $basePath = $this->config->basePath;

        $lockData = $this->lockData;
        $lockArray = $this->lockArray;

        foreach ($menuData as $item) {

            $pureName = $item['name'];
            $title = $item['title'];

            $lockCls = '';
            $showItem = true;

            // -------------------
            // ロック判定
            // -------------------

            if ($isAdmin) {

                if (array_key_exists($pureName, $lockData)) {
                    $lockCls = 'all-lock';
                }

            } else {

                if (array_key_exists($pureName, $lockArray)) {
                    $showItem = false;
                }
            }

            // 非表示ならスキップ
            if (!$showItem) {
                continue;
            }


            // -------------------
            // 子メニュー作成
            // -------------------

            $childrenHtml = $this->buildMenuFromData(
                $item['children'],
                $isAdmin,
                $folder
            );


            // -------------------
            // リンク作成
            // -------------------
            
            $path = str_replace($folder . '/', '', $item['path']) . '/';

            $pathRe = preg_replace('/^\d{3}\./', '', $path);
            $pathRe = preg_replace('/\/\d{3}\./', '/', $pathRe);

            // $pathBase = $folder === '../manual/pages'
            //     ? $basePath . '/public/manual/pages/'
            //     : $basePath . '/public/pages/';
            
            $pageArea = PageArea::fromPageDir($folder);
            $pathBase = PageArea::getUrlBase($pageArea, $basePath);

            $link = $pathBase . $pathRe;



            // -------------------
            // HTML生成
            // -------------------

            $aClassLock = $lockCls
                ? " class=\"{$lockCls}\""
                : '';

            $menuCode .= sprintf(
                '<li class="box-item" data-name="%s"><a href="%s"%s title="%s">%s</a>',
                htmlspecialchars($pureName, ENT_QUOTES),
                htmlspecialchars($link, ENT_QUOTES),
                $aClassLock,
                htmlspecialchars($title, ENT_QUOTES),
                htmlspecialchars($title, ENT_QUOTES)
            );


            if ($childrenHtml !== '') {

                $menuCode .=
                    "\n<ul class=\"sub-menu\">\n" .
                    $childrenHtml .
                    "</ul>\n";
            }


            $menuCode .= "</li>\n";
        }

        return $menuCode;
    }
}
