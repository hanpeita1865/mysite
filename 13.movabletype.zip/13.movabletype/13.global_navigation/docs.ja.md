---
title: グローバルナビゲーション
media_order: 'jungfrau_navgation.jpg,professional.jpg'
---

テーマに使用しているグローバルナビゲーションのコードを参考までに記します。

## テーマ「Jungfrau 1.01」の場合

##### テンプレートモジュール（header）
```
<header class="global-header">
	<div class="inner group">
		<mt:SetVarBlock name="logo"><mt:Assets type="image" tag="@LOGO" limit="1"><mt:AssetUrl></mt:Assets></mt:SetVarBlock>
		<h1 class="global-header-logo"><a href="<mt:SiteURL>"><img src="<mt:If name="logo"><mt:Var name="logo"><mt:Else><mt:SiteURL>images/logo.png</mt:If>" alt="<mt:SiteName>"></a></h1>
		<nav class="global-header-navi text-smaller">
			<ul>
				<li><a href="<mt:SiteURL>news/">ニュース</a></li>
				<li><a href="<mt:SiteURL>pressrelease/">プレスリリース</a></li>
				<li><a href="<mt:SiteURL>event/">イベント・セミナー</a></li>
				<mt:Pages tag="@header">
				<li><a href="<mt:PagepermaLink>"><mt:PageTitle></a></li>
				</mt:Pages>
			</ul>
		</nav>
        <!-- ハンバーガメニュー -->
		<button class="global-header-navi-sp-btn">
			<span class="global-header-navi-sp-btn-icon"></span>
		</button>
	</div>
</header>
```

<div class="gray-box" markdown="1">
使用テンプレートタグ
: [MTSiteURL](https://www.movabletype.jp/documentation/appendices/tags/siteurl.html) ～ サイトのURLを絶対 URLで表示します。
: [MTSiteName](https://www.movabletype.jp/documentation/appendices/tags/sitename.html) ～ サイトの名前を表示します。 MTBlogName と互換があります。
: [MTPages](https://www.movabletype.jp/documentation/appendices/tags/pages.html) ～ ウェブページの一覧を表示するためのブロックタグです。
: [MTPageTitle](https://www.movabletype.jp/documentation/appendices/tags/pagetitle.html) ～ ウェブページのタイトルを表示します。
: [MTPagePermalink](https://www.movabletype.jp/documentation/appendices/tags/pagepermalink.html) ～ 現在のウェブページのアーカイブへの絶対 URL を表示します。
</div>
##### HTML出力
```
<header class="global-header">
	<div class="inner group">
		<h1 class="global-header-logo">
			<a href="http://localhost/mt_tanaka/"><img src="http://localhost/mt_tanaka/images/logo.png" alt="田中一郎サイト"></a>
		</h1>
		<nav class="global-header-navi text-smaller">
			<ul>
				<li><a href="http://localhost/mt_tanaka/news/">ニュース</a></li>
				<li><a href="http://localhost/mt_tanaka/pressrelease/">プレスリリース</a></li>
				<li><a href="http://localhost/mt_tanaka/event/">イベント・セミナー</a></li>
			</ul>
		</nav>
        <!-- ハンバーガメニュー -->
		<button class="global-header-navi-sp-btn">
		  <span class="global-header-navi-sp-btn-icon"></span>
		</button>
	</div>
</header>
```

##### 表示結果
![](jungfrau_navgation.jpg)



## テーマ「プロフェッショナル ウェブサイト 1.11」の場合

##### テンプレートモジュール（ナビゲーション）

```
<ul>
    <li class="first<mt:If name="main_index"> on</mt:If>"><a href="<$mt:Link template="メインページ"$>">Home</a></li>

<mt:WebsiteHasBlog>
    <li class="<mt:If name="blog_index"> on</mt:If>"><a href="<$mt:BlogURL$>blogs/">ブログ</a></li>
</mt:WebsiteHasBlog>

    <mt:Pages tag="@topnav">
    <mt:SetVarBlock name="this_page_id"><$mt:PageID$></mt:SetVarBlock>
    <li class="<mt:If name="nav_on" eq="$this_page_id"> on</mt:If>"><a href="<$mt:PagePermalink$>"><$mt:PageTitle$></a></li>
    </mt:Pages>

    <mt:Pages tags="@about" limit="1">
    <mt:SetVarBlock name="this_page_id"><$mt:PageID$></mt:SetVarBlock>
    <li class="<mt:If name="nav_on" eq="$this_page_id"> on</mt:If>"><a href="<$mt:PagePermalink$>"><$mt:PageTitle$></a></li>
    </mt:Pages>

    <mt:Pages tags="@contact" limit="1">
    <mt:SetVarBlock name="this_page_id"><$mt:PageID$></mt:SetVarBlock>
    <li class="last<mt:If name="nav_on" eq="$this_page_id"> on</mt:If>"><a href="<$mt:PagePermalink$>"><$mt:PageTitle$></a></li>
    </mt:Pages>
</ul>
```

##### HTML出力
```
<ul>
	<li class="first on"><a href="http://localhost/mt_suzuki/">Home</a></li>
	<li class=""><a href="http://localhost/mt_suzuki/about/about.html">About</a></li>
	<li class="last"><a href="http://localhost/mt_suzuki/contact/contact.html">連絡先</a></li>
</ul>
```

##### 表示結果
![](professional.jpg)








