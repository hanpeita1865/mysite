*[page-title]:配列が空かどうか判定 empty()

## empty()を使って配列の空判定

empty()は配列が空かを判定するものではなく、引数にセットした変数が空かどうかを判定します。  
空の場合には true を返してくれます。
<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
<iframe src="https://paiza.io/projects/e/NlHnbZuWtiNtWOb3Tq5RWw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>


**※ 配列の要素に空文字やNULLを設定した場合は、空では無い状態になります。**

<div class="exp">
	<p class="tmp"><span>例</span></p>
</div>
<iframe src="https://paiza.io/projects/e/Neb-7x_BWEgJWwZGr9X_gQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
