*[page-title]:10-11. 壁紙やモザイクなどのテクスチャや効果


## クラッキングフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-11-1.jpg)](upload/10-11-1.jpg){.image}
</div>

## ステンドグラスフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-11-2.jpg)](upload/10-11-2.jpg){.image}
</div>

## その他のフィルター ## {.sr-only}
<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-11-3.jpg)](upload/10-11-3.jpg){.image}
</div>