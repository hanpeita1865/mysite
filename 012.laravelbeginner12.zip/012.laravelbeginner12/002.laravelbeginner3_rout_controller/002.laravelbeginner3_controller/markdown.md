*[page-title]:コントローラーの利用


## コントローラーの作成

<p class="tmp cmd"><span>コマンド</span>コントローラーの作成</p>
```
php artisan make:controller 〇〇Controller
```

これで、指定した名前でコントローラーが作成されます。  
コントローラーは通常、「〇〇Controller」というように、名前の後にControllerをつけた名前が使われます。

Herdのターミナルの「Open」ボタンをクリックしてください。
![](upload/Herdからターミナル起動.png){.photo-border}

windows Power Shellが開くので、下記のコマンドを記入して実行してください。
```
php artisan make:controller HelloController
```
![](upload/HelloControllerコマンド実行.png)

HelloController.phpが作成されました。
![](upload/HelloControllerディレクトリ.png)

<p class="tmp list"><span>リスト</span>HelloController.php（デフォルト）</p>
```
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HelloController extends Controller
{
    //
}
```

### Controllers名前空間

コントローラーは、クラスとして作成されます。このクラスは、App\Http\Controllersという名前空間に配置されます。この名前空間を指定しているのが最初の文です。
```
namespace App\Http\Controllers;
```

<div markdown="1" class="memo-box">
「<span class="bold red">名前空間</span>」というのは、クラスを階層的に整理するための仕組みです。フォルダーを使って階層的にファイルを整理するのと同じようなものをイメージすれば良いでしょう。  
ここでは、<span class="bold red">App\Http\Controllers</span>という名前空間を使っていますが、これはよく見るとどこかで見覚えのある名前が並んでいるのがわかります。そう、コントローラーのファイルが置かれている場所は、「app」フォルダー内の「Http」フォルダーの中にある「Controllers」フォルダーの中です。このフォルダー構成に沿って名前空間が指定されていることがわかるでしょう。  
これは、コントローラークラスを作成する際の基本設定として覚えておきましょう。
</div>

### クラスの定義

続いて、クラスの定義がされています。ここでは、HelloControllerクラスが以下のように定義されています。
```
class HelloController extends Controller
{
	//
}
```
<pre><code class="hljs php"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">HelloController</span> <span class="hljs-title marker-yellow"><span class="hljs-keyword">extends</span> Controller</span>
</span>{
    <span class="hljs-comment">//</span>
}</code></pre>

コントローラークラスは、このように<span class="marker-yellow50">「Controller」というクラスを継承</span>して作成します。  
また名前は、すでに触れたように「〇〇Controller」というものにしておきます。これは「必ずそういう名前にしないといけない」と決まっているわけではありませんが、クラスをわかりやすく整理する上で必要な命名ルールと考えてください。


## アクションを追加

<p class="tmp list"><span>リスト2-7</span>HelloController.php</p>
```mk
class HelloController extends Controller
{
  
  public function index() {

    return <<<EOF
      <html>
        <head>
          <title>Hello/Index</title>
        <style>
          body {font-size:16pt; color:#999;}
          h1 {font-size:100pt;text-align:right;color:#eee;
          margin:-40px 0px -50px 0px;}
        </style>
        </head>
        <body>
          <h1>Index</h1>
          <p>これは、Helloコントローラーのindexアクションです。</p>
        </body>
      </html>
    EOF;
  }
}
```

<p class="tmp list"><span>リスト2-8</span>web.php</p>
```
use App\Http\Controllers\HelloController; //追記

Route::get('hello',[HelloController::class,'index']);
```

![](upload/indexアクションです.png){.photo-border}


### ルートパラメータの利用

<p class="tmp list"><span>リスト2-9</span>HelloController.php</p>
<pre><code class="language-mk hljs makefile">class HelloController extends Controller
{

  public function index(<span class="marker-yellow">$id='noname'</span>,<span class="marker-yellow"> $pass='unknown'</span>) {

    return &lt;&lt;&lt;EOF
      &lt;html&gt;
        &lt;head&gt;
          &lt;title&gt;Hello/Index&lt;/title&gt;
          &lt;style&gt;
            body {font-size:16pt; color:<span class="hljs-comment">#999; }</span>
            h1 {font-size:100pt;text-align:right;color:<span class="hljs-comment">#eee;</span>
              margin:-40px 0px -50px 0px; }
          &lt;/style&gt;
        &lt;/head&gt;
        &lt;body&gt;
          &lt;h1&gt;Index&lt;/h1&gt;
          &lt;p&gt;これは、Helloコントローラーのindexアクションです。&lt;/p&gt;
          &lt;ul&gt;
            &lt;li&gt;ID: <span class="marker-yellow">{$id}</span>&lt;/li&gt;
            &lt;li&gt;PASS: <span class="marker-yellow">{$pass}</span>&lt;/li&gt;
          &lt;/ul&gt;
        &lt;/body&gt;
      &lt;/html&gt;
    EOF;
  }
}</code></pre>

<p class="tmp list"><span>リスト2-10</span>web.php</p>
<pre><code class="hljs kotlin">Route::<span class="hljs-keyword">get</span>(<span class="hljs-string">'hello/<span class="marker-yellow">{id?}</span>/<span class="marker-yellow">{pass?}</span>'</span>, [HelloController::<span class="hljs-class"><span class="hljs-keyword">class</span>, <span class="hljs-type">'index']);</span></span></code></pre>

「～/hello/taro/yamada」にアクセス。
![](upload/taro_yamada.png){.photo-border}


### 複数のアクション利用

<p class="tmp list"><span>リスト2-11</span>HelloController.php</p>
```mk
<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

global $head, $style, $body, $end;
$head = '<html><head>';
$style = <<<EOF
<style>
body {font-size:16pt; color:#999; }
h1 { font-size:100pt; tex  t-align:right; color:#eee;
   margin:-40px 0px -50px 0px; }
</style>
EOF;
$body = '</head><body>';
$end = '</body></head>';

function tag($tag, $txt) {
  return "<{$tag}>" . $txt . "</{$tag}>";
}

class HelloController extends Controller
{
  
  public function index() {
    global $head, $style, $body, $end;
  
    $html = $head . tag('title','Hello/Index') 
      . $style . $body . tag('h1','Index')
      . tag('p','this is Index page')
      . '<a href="/hello/other">go to Other page</a>'
      . $end;
    return $html;
  }

  public function other() {
    global $head, $style, $body, $end;
  
    $html = $head . tag('title','Hello/Other') 
      . $style . $body . tag('h1','Other')
      . tag('p','this is Other page') . $end;
    return $html;
  }
}
```

<p class="tmp list"><span>リスト2-12</span>web.php</p>
```
Route::get('hello', [HelloController::class, 'index']);
Route::get('hello/other', [HelloController::class, 'other']);
```

<div markdown="1" class="d-flex">
![](upload/go_to_Other_page.png){.photo-border}
![](upload/this_is_Other_page.png){.photo-border}
</div>


<div markdown="1" class="memo-box">
##### アクションとアドレスの関係
ここでは、/helloと/hello/otherにアクションを割り当ててあります。基本的に、アドレスとコントローラー/アクションの関連は、以下のように対応させるのが一般的です。
```mk
http://アプリケーションのアドレス/コントローラー/アクション
```
HelloControllerのindexアクションならば、/hello/indexとしておくのが一般的です。ただし、Webの世界では、indexは省略してアクセスできるようにしておくのが一般的です。
</div>


## シングルアクションコントローラー

<p class="tmp"><span>書式</span>シングルアクションコントローラーの基本形</p>
```
class -- extends Controller
	{
	public function __invoke() {
		···· アクション処理 ····
	}
}
```

<p class="tmp"><span>書式</span>web.php</p>
```
Route :: get( 'アドレス’, コントローラークラスの指定);
```
このように、コントローラー名だけを指定します。アクションの指定はしません。これにより、指定のアドレスにコントローラーが割り当てられます。  
そしてそのアドレスにアクセスをすると、クラスの `__invoke`が呼び出され処理が実行される、というわけです。

<p class="tmp list"><span>リスト2-13</span>HelloController.php</p>
<pre><code class="language-mk hljs makefile">&lt;?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;

class HelloController extends Controller
{
  public function <span class="marker-yellow">__invoke()</span> {
    return &lt;&lt;&lt;EOF
      &lt;html&gt;
        &lt;head&gt;
          &lt;title&gt;Hello&lt;/title&gt;
          &lt;style&gt;
          body {font-size:16pt; color:<span class="hljs-comment">#999; }</span>
          h1 { font-size:50pt; text-align:right; color:<span class="hljs-comment">#eee;</span>
            margin:-25px 0px 0px 0px; }
          &lt;/style&gt;
        &lt;/head&gt;
        &lt;body&gt;
          &lt;h1&gt;Single Action&lt;/h1&gt;
          &lt;p&gt;これは、シングルアクションコントローラーのアクションです。&lt;/p&gt;
        &lt;/body&gt;
      &lt;/html&gt;
      EOF;
  }
}</code></pre>

<p class="tmp list"><span>リスト2-14</span>web.php</p>
<pre><code class="hljs ruby">Route::get(<span class="hljs-string">'hello'</span>, <span class="marker-yellow">HelloController</span>::<span class="hljs-class"><span class="hljs-keyword">class</span>);</span></code></pre>

![](upload/シングルアクションコントローラーのアクション.png){.photo-border}


<div markdown="1" class="memo-box">
##### `__invoke` はPHPの基本機能
シングルアクションコントローラーでは `__invoke`メソッドを実装して使っていますが、このメソッドは、Laravelの機能というわけではありません。これは、PHP のクラスに用意されている「マジックメソッド」と呼ばれるメソッドの1つです。  
マジックメソッドは、あらかじめ特別な役割を与えられているメソッドのことで、一般にアンダーバー2つで始まる名前をしています。 `__invoke`は、そのクラスのインスタンスを関数的に実行するためのもので、インスタンスに()をつけ関数として呼び出すと、インスタンス内の `__invoke`が実行されます。

したがって、コントローラーに限らず、一般的なクラスでも、「インスタンスをそのまま関数のように実行させたい」というような場合に利用されます。
</div>


## Request/Response

<p class="tmp list"><span>リスト2-15</span>HelloController.php</p>
<pre><code class="language-mk hljs makefile">&lt;?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
<span class="marker-yellow">use Illuminate\Http\Response;</span>

class HelloController extends Controller
{
  public function index(Request $request, <span class="marker-yellow">Response $response</span>) {

    $html = &lt;&lt;&lt;EOF
      &lt;html&gt;
      &lt;head&gt;
        &lt;title&gt;Hello/Index&lt;/title&gt;
        &lt;style&gt;
        body {font-size:16pt; color:<span class="hljs-comment">#999; }</span>
        h1 { font-size:120pt; text-align:right; color:<span class="hljs-comment">#f0f0f0;</span>
          margin:-50px 0px -120px 0px; }
        &lt;/style&gt;
      &lt;/head&gt;
      &lt;body&gt;
        &lt;h1&gt;Hello&lt;/h1&gt;
        &lt;h3&gt;Request&lt;/h3&gt;
        &lt;pre&gt;{$request}&lt;/pre&gt;
        &lt;h3&gt;Response&lt;/h3&gt;
        &lt;pre&gt;{$response}&lt;/pre&gt;
      &lt;/body&gt;
      &lt;/html&gt;
    EOF;
    $response-&gt;setContent($html);
    return $response;
  }
}</code></pre>

<p class="tmp list"><span>リスト2-16</span>web.php</p>
```
Route::get('hello', [HelloController::class, 'index']);
```

![](upload/response表示.png){.photo-border}

### Requestの主なメソッド
では、Request/Responseの利用例として、いくつかのメソッドを紹介しておきましょう。
まずはRequestからです。これは、アクセスしたURL に関するものがいくつか用意されているのでまとめておきましょう。

urlは、アクセスしたURL を返します。ただし、クエリー文字列(アドレスのあとに付けられる、?abc=xyzというようなテキスト)は省略されます。
```
$request->url();
```
fullUrlは、アクセスしたアドレスを完全な形で返します(クエリー文字列も含まれます)。
```
$request->fullUrl();
```
pathは、ドメイン下のパス部分だけを返します。
```
$request->path();
```


### Responseの主なメソッド
続いてResponseです。こちらは、クライアントへ返送する際のステータスコード、表示コンテンツの設定などがあります。  

アクセスに関するステータスコードを返します。これは正常にアクセスが終了していたら200になります。
```
$this->status();
```
コンテンツの取得や設定を行うものです。contentはコンテンツを取得し、setContentは引数の値にコンテンツを変更します。
```
$this->content();
$this->setContent(值);
```


これらのオブジェクトは、これから先、Laravelを使いこなすにつれ利用価値が高まっていくことでしょう。まずは、ここに挙げたメソッドを使って、オブジェクトの使い方を覚えておきましょう。