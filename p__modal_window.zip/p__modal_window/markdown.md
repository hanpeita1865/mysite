## 参考サイト

* [モーダル系JSライブラリ実践で使える間違いなしの厳選5つ](https://uhaha.net/modal5/)

### Magnific Popup

* [Magnific Popup公式サイト](https://dimsemenov.com/plugins/magnific-popup/)
* [Magnific Popup設定など](https://uhaha.net/magnific-popup/)
* [Magnific Popupデモ](https://uhaha.net/demo_js/demo_20201104_modal01/index.html#magnific_01)
* [github](https://github.com/dimsemenov/Magnific-Popup/)

### Modaal

万能モーダル系プラグインとしては Magnific Popup よりも新しく設定も簡単です。

* [Modaal公式サイト](https://humaan.com/modaal/)
* [Modaal使い方](https://uhaha.net/modaal/)
	* [デモ](https://uhaha.net/demo_js/demo_20201110_modal02/index.html)
* [github](https://github.com/humaan/Modaal)

#### まとめサンプル
<a href="sample/modaal/sample_gallery/" target="_blank">まとめデモ</a>

* Inline Content
* Fullscreen Mode（画像以外）
* AJAX
* Video 
* iframe

#### 関数

|イベント|	概要|
|--|--|
|before_open|	モーダルウィンドウが開く前に呼び出される関数を定義できる。|
|after_open|	モーダルウィンドウが開いた後、呼び出される関数を定義できる。|
|before_close|	モーダルウィンドウが閉じた後に呼び出される関数を定義できる。|
|after_close|	モーダルウィンドウが閉じた後、呼び出される関数を定義できる。|
|before_image_change|	ギャラリーで画像が変更される前に呼び出される関数を定義できる。|
|after_image_change|	ギャラリー画像が変更された後に呼び出される関数を定義できる。|
|confirm_callback|	確認ボタンやOKボタンが押された時呼び出される関数を定義できる。|
|confirm_cancel_callback|	キャンセルボタンが押された時呼び出される関数を定義できる。|
|ajax_success|	AJAXコンテンツが読み込まれたとき呼び出される関数を定義できる。|


以下のコードは、videoのモーダルを実行した時に、表示前と表示後にそれぞれアラートが出るスクリプトです。
<p class="tmp list"><span>リスト</span></p>
```
// YOUTUBE
$('.video').modaal({
	type: 'video',
	before_open: function() {
		alert('Before open');
	},
	after_open: myFunction
});

function myFunction() {
	alert('After open');
	$(video).attr('autoplay','false');
}
```