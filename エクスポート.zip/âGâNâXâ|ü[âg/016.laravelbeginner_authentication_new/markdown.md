*[page-title]:ユーザー認証（新）


参考サイト
: https://analyzegear.co.jp/blog/2176


## Breezeのインストール

「<span class="green bold marker-yellow50">Laravel Breeze</span>」はLaravel を使ったユーザー登録、ログイン、パスワードの再設定等の認証に関わる基本的な機能を手軽に提供してくれるパッケージです。

<span class="red">注意）Breezeをインストールすると、web.phpの記述が初期化されます。</span>


<p class="tmp cmd"><span>コマンド</span>Breezeインストール</p>
```
composer require laravel/breeze --dev
```

<p class="tmp cmd"><span>コマンド</span>Laravel Breezeの動作に必要なコード群を生成</p>
```
artisan breeze:install
```
どれを選択すればいい??
bladeをとりあえず選択
![](upload/Laravel_Breeze1.png)

yesを選択
![](upload/Laravel_Breeze2.png)
「0」を選択
![](upload/Laravel_Breeze3.png)


![](upload/Laravel_Breeze4.png)

breezeがインストールされてるか、下記のコマンドを実行して確認。
```
php artisan package:discover --ansi
```
![](upload/Laravel_Breeze5.png)

下記のコマンドを実行???
```
php artisan vendor:publish --tag=laravel-assets --ansi --force
```
![](upload/Laravel_Breeze6.png)


マイグレーション実行。
```
php artisan migrate
```

## 認証の動作確認

http://localhost:8000/にアクセスして、「Log in」ボタンをクリック
![](upload/login1.png)

ログイン画面が表示できた。
![](upload/login2.png)

「register」をクリックすると、登録画面が表示されます。
![](upload/login3.png){.photo-border}

下記で登録してみた。パスワード「ryouma1007」
![](upload/login4.png){.photo-border}

ログイン画面から登録したユーザー名とパスワードでログインしてみた。OK
![](upload/login5.png){.photo-border}

usersテーブルを確認すると登録されているのが確認できる。
![](upload/login6.png){.photo-border}

<p class="tmp"><span>書式</span>web.php（デフォルト）</p>
```
Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    //ここにルート情報を記述します。

});

require __DIR__.'/auth.php';
```

上記の「<span class="green">//ここにルート情報を記述します。</span>」の下に「  `Route::get('customer1', [\App\Http\Controllers\CustomerController::class,'index']);//一覧表示`」を記述して、「<http://localhost:8000/customer1>」にアクセスすると、ユーザ認証前ならログイン画面が表示される。  
ログイン後にアクセスした場合、「～/customer1」のページがすぐに表示される。
![](upload/login7.png){.photo-border}

![](upload/customer1ページ.png "図　「customer1」のページ"){.photo-border}