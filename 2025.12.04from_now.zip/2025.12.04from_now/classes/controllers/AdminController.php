<?php

namespace SocymSlim\SlimMiddle\controllers;

use PDO;
use PDOException;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    MenuService,
    LockService,
};

require '../admin/basepath.php';

class AdminController
{
    private EditService $editService;
    private FolderService $folderService;
    private MenuService $menuService;
    private LockService $lockService;
    private $container;
    
    public function __construct(EditService $editService, FolderService $folderService, MenuService $menuService, LockService $lockService, ContainerInterface $container)
    {
        $this->container = $container;
        $this->editService = $editService;
        $this->folderService = $folderService;
        $this->lockService = $lockService;
        $this->menuService = $menuService;
    }


    //管理画面表示
    public function adminData(Request $request, Response $response, array $args): Response
    {      
        //ミドルウェアより
        $foderCnt = $request->getAttribute('count');//pages内のフォルダ数
        $countIp = $request->getAttribute('countIp');//管理者かどうか 1は管理者
        
        $db = $this->editService->db();//サービス（DB接続）

        $twig = $this->editService->view();//サービス（テンプレート）

        // 管理画面メニュー
        $boxNum = 1;
        
        $folderObj = $this->folderService->getFolderComp();
              
        $menuService = $this->container->get(MenuService::class);
        $menuService->setCountIp($countIp);
        $menuService->loadLockData($db, $folderObj);//サービス（$lockData、$lockArrayの値を設定）
            
        $menuData = $this->menuService->buildAdminMenu('../pages', $boxNum);//サービス（管理画面用メニュー）
        
        $assign["menuData"] = $menuData; //メニューリスト       
        // $assign["pcopyCheck"] = $pcopyCheck; //pages_copy内にフォルダがあるか
        $assign["folderCnt"] = $foderCnt;

        $response = $twig->render($response, "admin.twig", $assign);

        return $response;
    }



    //フォルダ新規作成
    public function folder_create(Request $request, Response $response, array $args): Response
    {
        $data = $request->getParsedBody() ?? [];
        $newFolder = trim($data['post_newFolder'] ?? '');

        try {
            $this->folderService->createNewFolder($newFolder);//サービス
            $response->getBody()->write("フォルダ '{$newFolder}' を作成しました。");
        } catch (\Exception $e) {
            $response->getBody()->write('エラー: ' . $e->getMessage());
        }

        return $response;
    }


    //ページ名変更
    public function file_rename(Request $request, Response $response, array $args): Response
    {
        $parsedBody = $request->getParsedBody();
        $post_menu = $parsedBody['post_menu'] ?? '';
        $post_reMenu = $parsedBody['post_reName'] ?? '';
        $post_dirName = $parsedBody['post_dirName'] ?? '';
        $post_folderName = $parsedBody['post_folderName'] ?? '';

        try {
            $this->folderService->renameMenu($post_dirName, $post_menu, $post_reMenu, $post_folderName);//サービス
            $response->getBody()->write('メニュー名を「' . $post_reMenu . '」に変更しました。');
        } catch (\Exception $e) {
            $response->getBody()->write('エラー: ' . $e->getMessage());
        }

        return $response;
    }


    //フォルダ名変更
    public function folder_rename(Request $request, Response $response, array $args): Response
    {       
        $parsedBody = $request->getParsedBody();

        $post_dir = $parsedBody['post_dir'] ?? '';
        $post_redir = $parsedBody['post_redir'] ?? '';
        $post_name = $parsedBody['post_folderName'] ?? '';
        $post_rename = $parsedBody['post_folderReName'] ?? '';

        $responseData = [];

        try {
            $result = $this->folderService->renameFolder($post_dir, $post_redir, $post_name, $post_rename);//サービス
            $responseData = [
                'success' => true,
                'message' => $result // "フォルダ名を「xxx」に変更しました。" など
            ];
        } catch (Exception $e) {
            $responseData = [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }

        $response->getBody()->write(json_encode($responseData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        return $response->withHeader('Content-Type', 'application/json');
    }



    //ロック設定
    public function page_lock(Request $request, Response $response, array $args): Response
    {       
        $parsedBody = $request->getParsedBody();
        $folder = $parsedBody['folderName'] ?? '';
        $under_dir = $parsedBody['under_dir'] ?? '';

        try {
            $message = $this->lockService->addLock($folder, $under_dir);
            $result = ['success' => true, 'message' => $message];
            
        } catch (Exception $e) {
            $result = ['success' => false, 'message' => $e->getMessage()];
        }

        $response->getBody()->write(json_encode($result));
        return $response->withHeader('Content-Type', 'application/json');        
    }


    //ロック解除
    public function page_unlock(Request $request, Response $response, array $args): Response
    {       
        $parsedBody = $request->getParsedBody();
        $folder = $parsedBody['folderName'] ?? '';

        try {
            $message = $this->lockService->removeLock($folder);
            $result = ['success' => true, 'message' => $message];
        } catch (Exception $e) {
            $result = ['success' => false, 'message' => $e->getMessage()];
        }

        $response->getBody()->write(json_encode($result));
        return $response->withHeader('Content-Type', 'application/json');
    }



    //lockデータ削除
    public function lockdata_del(Request $request, Response $response, array $args): Response
    {
        $parsedBody = $request->getParsedBody();

        $folder = $parsedBody['post_delFolder'] ?? '';

        try {
            $message = $this->lockService->deleteLockData($folder);
            $result = ['success' => true, 'message' => $message];
        } catch (Exception $e) {
            $result = ['success' => false, 'message' => $e->getMessage()];
        }

        $response->getBody()->write(json_encode($result));
        return $response->withHeader('Content-Type', 'application/json');
    }


    
    //削除したフォルダをゴミ箱(trush)に移動
    public function trush(Request $request, Response $response, array $args): Response
    {
        $res = glob('../pages_copy' . '/*');
        date_default_timezone_set('Asia/Tokyo'); //日本時間にセット
        $dateTime = date('Y-m-d_H.i.s');
        $this->container->set('dateTime', $dateTime);

        sleep(3);

        foreach ($res as $item) {
            mkdir('../trush/' . $dateTime); //削除日時フォルダ
            $itemRe = str_replace('pages_copy', 'trush' . '/' . $dateTime, $item);

            if (rename($item, $itemRe)) {
                //移動しました。
            }
        }

        return $response;
    }



    //対象のフォルダのみ削除 folderDelOnly
    public function folderDelOnly(Request $request, Response $response, array $args): Response
    {
        // $config = $this->container->get('config');
        // $basePath = $config['basePath'];     
        // $basePath = $basePath . '/public/';

        $folderObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）
        
        $data = $request->getParsedBody() ?? [];
        $folderName = trim($data['folderName'] ?? '');
        
        $delFolder = $folderObj[$folderName]; //削除するフォルダのパス 例)../pages/042.aaa
        $this->folderService->subpageMove($delFolder, $folderName);//サービス（上の階層に移動して、番号を再設定）

        return $response;
    }


    //対象フォルダを中身ごとまとめて削除してメニュー再生成
    public function del_allfolder(Request $request, Response $response, array $args): Response
    {

        $folderObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）
        
        $data = $request->getParsedBody() ?? [];
        $folderName = trim($data['folderName'] ?? '');
        
        $delFolder = $folderObj[$folderName]; //削除するフォルダのパス 例)../pages/042.aaa
        
        // 配下フォルダの fdName 一覧を取得
        $deleteList = $this->folderService->getDeleteTargetFdNames($delFolder);

        $this->folderService->deleteAllFolder($delFolder, $deleteList);

        return $response;
    }



    //並び替え確定   
    public function sort_confirm(Request $request, Response $response): Response {
        $data = $request->getParsedBody();
        $sortHistory = json_decode($data['dirObj'] ?? '[]', true);
        
        $this->folderService->sortTogether($sortHistory);//サービス

        $response->getBody()->write(json_encode(['status' => 'success']));
        return $response->withHeader('Content-Type', 'application/json');
    }




    //フォルダ使用中かチェック
    public function folderUseCheck(Request $request, Response $response, array $args): Response
    {
        $pagesObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）
        $folderCnt1 = count($pagesObj);
        $menuArray1 = json_decode($_POST['list']);
        $menuObj = [];

        foreach ($menuArray1 as $val) {
            $dirArray = explode('/', $val);
            $lastDir = end($dirArray); //配列の最後の値
            $folderNoNum = preg_replace('/^\d{3}./', '', $lastDir);
            $menuObj[$folderNoNum] = '../pages/'.$val;
        }

        $sabunFolder = array_diff($pagesObj, $menuObj);

        $array2 = [];
        $array3 = [];
        
        foreach ($sabunFolder as $value){
            $array1 = explode('/', $value);
            $cnt = count($array1);
            
            iF($cnt==3){
                array_push($array2, $value);
            } else if($cnt==4 && !in_array($array1[2], $array2)){
                array_push($array3, $value);
            } else if($cnt >= 5){
                //第四階層以下は、第三階層にする
                $value = $array1[0].'/'.$array1[1].'/'.$array1[2].'/'.$array1[3];
                array_push($array3, $value);               
            }
        }

        $res2 = array_unique($array2);//第二階層の差分ディレクトリ
        $res3 = array_unique($array3);//第三階層の差分ディレクトリ

        //第三階層ディレクトリが第二階層階層にあれば、第三階層のディレクトリは削除
        foreach ($res2 as $value){
            foreach ($res3 as $key => $item){
                if(strpos($item, $value) !== false){
                    unset($res3[$key]);
                }
            }
        }


        $res_merge = array_merge($res2, $res3);
        $content = "true";

        //フォルダ名が変更できるかチェック
        foreach($res_merge as $sourceDir){

            try{
                if(rename ( $sourceDir , $sourceDir.'00' )){
                    rename ( $sourceDir.'00' , $sourceDir );

                }else{
                    throw new PDOException();
                }

            }catch(PDOException $e){
                // echo $e->getMessage();
                $content = "false";

                // exit('処理を強制終了します。');//処理を強制終了

            }finally{
                // echo "処理が終了しました";
            }
        }

        $responseBody = $response->getBody();
        $responseBody->write($content);

        return $response;
    }


    //pages内のディレクトリ一覧の連想配列を取得　テスト
    public function pagesDirGet(Request $request, Response $response, array $args): Response
    {
        $pagesAry = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）
        $pagesJson = json_encode($pagesAry);
        $responseBody = $response->getBody();
        $responseBody->write($pagesJson);

        return $response;
    }


    //番号修正
    public function num_replace(Request $request, Response $response, array $args): Response
    {
        $folderObj = $this->folderService->getFolderComp();//サービス（フォルダオブジェクト）      
        $data = $request->getParsedBody();
        //並べ替え予定のメニューの配列取得
        $menuArray = json_decode($data['list'] ?? '[]', true);
        sleep(2);
        //フォルダ番号修正
        $this->folderService->dirNumReplace($menuArray, $folderObj);

        return $response;
    }
}

