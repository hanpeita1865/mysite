Vue.createApp({
  data() {
    return {
      pet: 'いぬ'
    };
  }
}).mount('#app');