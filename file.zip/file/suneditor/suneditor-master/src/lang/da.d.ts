import { Lang } from './Lang';

declare const da: Lang;

export default da;