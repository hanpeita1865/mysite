*[page-title]:Drag & Drop

参考サイト
: [HTML5 Drag and Drop APIの使用](https://web.dev/i18n/ja/drag-and-drop/)
: [JavaScriptを使って要素をドラッグ＆ドロップで移動](https://q-az.net/elements-drag-and-drop/)←圭吾さんより
: [ドラッグ・ドロップしたときに処理を実行する](https://gray-code.com/javascript/execute-processing-when-drag-and-drop/)

Drag & Drop API（以降、DnDと呼びます）は、ページ内の要素をドラッグで動かし、ほかの場所に移動させたり、ブラウザ外からファイルをページにドロップしたりといった操作を可能にするHTML5のAPIです。

次のような機能を実装することができます。

* 要素の順番や位置を入れ替える
* ローカルにある画像やテキストをブラウザにドロップして読み込む

## イベントの種類 ##{.h-type2}

|イベント名 |	発生するタイミング|
| ------- | ----------------- |
|**dragstart** |ドラッグ開始時|
|**drag** |	ドラッグしている間|
|**dragend** |ドラッグ終了時|
|**dragenter** |ドラッグしている要素がドロップ領域に入ったとき|
|**dragover** |ドラッグしている要素がドロップ領域にある間|
|**dragleave** |ドラッグしている要素がドロップ領域から出たとき|
|**drop** |ドラッグしている要素がドロップ領域にドロップされたとき|

<div class="exp">
	<p class="tmp"><span>例1-1</span>drag&dropイベントをコンソールで確認</p>
	緑のボックス（#box）をクリックしてドラッグ、ドロップを行うと、コンソールにイベント名が表示されます。<br>
	<a href="sample/sample1(console)/" target="_blank">新規タブ</a>
</div>

<div class="exp">
	<p class="tmp"><span>例1-2</span>drag&dropイベントをコンソールで確認</p>
	画像をドラッグ、ドロップを行うと、コンソールにイベント名が表示されます。<br>
	<a href="sample/sample2(eventcheck)/" target="_blank">新規タブ</a>
</div>

※ドラッグとドロップの操作はセットで扱うことが多いですが、イベント「drop」は「dragover」のデフォルトの挙動が有効になっているときは発生しないため注意が必要です。  
イベント「drop」をイベントリスナーに登録するときは、「dragover」に対してpreventDefaultメソッドでデフォルトの挙動を無効にします。

<p class="lang">JS</p>
```
window.addEventListener('DOMContentLoaded', function () {

	document.addEventListener('drag', function (e) {
		console.log('drag');
	});

	document.addEventListener('dragend', function (e) {
		console.log('dragend');
	});

	document.addEventListener('dragenter', function (e) {
		console.log('dragenter');
	});

	document.addEventListener('dragexit', function (e) {
		console.log('dragexit');
	});

	document.addEventListener('dragleave', function (e) {
		console.log('dragleave');
	});

	document.addEventListener('dragover', function (e) {
		e.preventDefault();
		console.log('dragover');
	});

	document.addEventListener('dragstart', function (e) {
		console.log('dragstart');
	});

	document.addEventListener('drop', function (e) {
		e.preventDefault();
		console.log('drop');
	});
});
	```

<div class="exp">
	<p class="tmp"><span>例1-3</span>drag&dropイベント</p>
	緑のボックス（#box）をドラッグすると、ウサギのイメージ画像が表示される。青のボックスでは、表示されない。
		<a href="sample/sample5(DnD)/" target="_blank">新規タブ</a>
<iframe width="100%" height="250" src="sample/sample5(DnD)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">HTML</p>
```
<div>  
<div id="box" class="box green" draggable="true"></div>
	<div class="box blue" draggable="true"></div> 
</div>
```

<p class="lang">JS</p>
```
var dragImage = document.createElement('img');//img要素を作成
dragImage.src = 'image/0-01.png'; //ドラッグしてるときのイメージ画像を設定

$('#box').on('dragstart', onDragStart);//#boxのドラッグを開始したときに、作成したonDragStart関数を行う

function onDragStart(e) {
		//DataTrasnferオブジェクトにidを設定
		e.originalEvent.dataTransfer.setData('text', this.id);
		//DataTrasnferオブジェクトにイメージを設定
		e.originalEvent.dataTransfer.setDragImage(dragImage, 40, 40);
}
```
		
<div class="exp">
	<p class="tmp"><span>例1-4</span></p>
	<a href="https://q-az.net/elements-drag-and-drop/" target="_blank">JavaScriptを使って要素をドラッグ＆ドロップで移動</a>より参照（記事は2016と古いです）<br>
	要素をDrag&Dropを行うと、ドロップした位置に配置されます。
		<a href="sample/sample2(three_colorbox)/" target="_blank">新規タブ</a>
<iframe width="100%" height="550" src="//jsfiddle.net/hirao/or7djkbg/embedded/result,html,js,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


## DataTransferオブジェクト

**DataTransferオブジェクト**は、ドラッグしている要素のデータを保持するために使います。DataTransferオブジェクトはDnDで発生するイベント内からのみアクセスすることができます。

### DataTrasnferオブジェクトのメソッド
DataTransferオブジェクトにはデータの保持以外にも役割があります。

|メソッド名 |役割|
| --------- | --- |
|**setData** |データセットする|
|**getData** |セットされているデータを取得する|
|**setDragImage** |ドラッグ中に表示されるイメージを変更する|

**setData**は、{c:red}setData('text', 'hogehoge'){/c}のように、第一引数にタイプを指定してデータをセットします。セットしたデータは、{c:red}getData('text'){/c}とすることで取得できます。
**setDragImage**ではドラッグ中に表示されるイメージを変更することができます。セットしない場合はドラッグしている要素自体が使われます。


### DataTrasnferオブジェクトのプロパティ

プロパティはsetDataでセットされたデータに関する情報や、ドロップされたファイルの情報を持っています。

|プロパティ名 |機能 |
| ----------- | --- |
|**files** |ドロップされたファイルの情報を保持。File APIのFileList形式で格納される。|
|**types** |setDataでセットされたデータの種類が格納されている。|
|**dropEffect** |設定した値が格納される。初期値はnone |
|**effectAllowed** |設定した値が格納される。初期値はall|


<div class="exp">
	<p class="tmp"><span>例2-1</span></p>
	点線の枠の中にファイルを**Drag&Drop**すると、Consoleにそのファイルのfilesプロパティが表示されます。
	<a href="sample/sample4(DnD)/index.html" target="_blank">新規タブ</a>
	<iframe width="100%" height="400" src="sample/sample4(DnD)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">JQUERY</p>
```
$(function(){  
		var obj = $("#DnDBox");

		//ドラッグしているファイルがドロップ領域に入ったとき
		obj.on('dragenter', function (e) {
				e.stopPropagation(); //イベントを停止する
				e.preventDefault(); //画面遷移を行わない
				$(this).css('border', '4px solid #000');
		});

		//ドラッグしているファイルがドロップ領域にある間
		obj.on('dragover', function (e) {  
				e.stopPropagation();  
				e.preventDefault();  
				$(this).css('border', '4px solid #000');  
		});

		//ドラッグしているファイルがドロップ領域にドロップされたとき
		obj.on('drop', function (e) {  
				$(this).css('border', '4px dashed #000');
				e.preventDefault(); 

				var dropFile = e.originalEvent.dataTransfer.files;//filesプロパティを変数に格納
				console.log(dropFile);//格納したファイルのfilesプロパティを表示
		});
});
```

<p class="lang">JavaScript用</p>
```
const obj = document.getElementById('DnDBox');

obj.addEventListener('dragenter', function(e){
	e.stopPropagation(); //イベントを停止する
	e.preventDefault(); //画面遷移を行わない
	this.style.border='4px solid #000';
});

obj.addEventListener('dragover', function(e){
	e.stopPropagation(); //イベントを停止する
	e.preventDefault(); //画面遷移を行わない
	this.style.border='4px solid #000';
});

obj.addEventListener('drop', function(e){
	this.style.border='4px solid #000';
	e.preventDefault(); 

	console.log('ドロップ')
	
	//let dropFile = e.originalEvent.dataTransfer.files;//filesプロパティを変数に格納
	//console.log(dropFile);//格納したファイルのfilesプロパティを表示
});
```


<div class="exp">
	<p class="tmp"><span>例2-2</span></p>
	DnDしたファイルのリストを表示します。
	<a href="sample/sample6(DnD)/index.html" target="_blank">新規タブ</a>
	<iframe width="100%" height="350" src="sample/sample6(DnD)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">JS</p>
```
var waitList=[];  //追加するファイル用の配列変数

//ファイルをDnDしたときの関数
function addWaitList(files){  
		for(var i=0;i<files.length;i++){ //新しくDnDしたファイルらを一個一個チェックしてから、waitListに追加
				var sameName=-1;  
				//新しくDnDしたファイル名と既にwaitListにあるファイル名とを比較してチェック
				for(var j=0;j<waitList.length;j++){ 
						if(files.item(i).name==waitList[j].name){ //ファイル名が同じのがあった場合、
								sameName=j;  
								break; //同じ名前のファイルがあればこのファイルの処理を停止
						}  
				}	

				if(sameName<0){//初期値(sameName=-1)のとき(同じ名前がなかったとき)

						waitList.push(files.item(i));//ファイルを配列変数に追加
						//追加したファイル名をリストに表示
						$("#waitingList").append('<li><span class="filename">'+files.item(i).name +'</span><button class="fileDelete">削除</button></li>');

				}else{
						if(window.confirm(files.item(i).name +'と同じ名前のファイルがあります。上書きしますか?')){
								waitList[sameName]=files.item(i);//ファイルを上書き			   
						}
				}
		}  
}  

$(function(){  
		var obj = $("#DnDBox");

		//ドラッグしているファイルがドロップ領域に入ったとき
		obj.on('dragenter', function (e) {
				e.stopPropagation();  
				e.preventDefault();  
				$(this).css('border', '4px solid #000');
		});

		//ドラッグしているファイルがドロップ領域にある間
		obj.on('dragover', function (e) {  
				e.stopPropagation();  
				e.preventDefault();  
				$(this).css('border', '4px solid #000');  
		});

		//ドラッグしているファイルがドロップ領域にドロップされたとき
		obj.on('drop', function (e) {  
				$(this).css('border', '4px dashed #000');
				e.preventDefault(); 

				var dropFile = e.originalEvent.dataTransfer.files;
				addWaitList(e.originalEvent.dataTransfer.files);
		});

		//クリアボタンを押すと、全削除
		$('#clearWaitList').on('click',function(){
				$('#waitingList li').remove();  
				waitList=[];  
		});


		//ファイル削除を押したときの処理
		$('ul').on('click', '.fileDelete', function() {
				var delObj = $(this);
				var delName = $(this).prev('span').text();
				var fileIndex = $(this).parent('li').index();

				waitList.splice(fileIndex, 1);

				//リストのファイル表示削除
				delObj.parent('li').remove();
		}); 
});  
```


<div class="exp">
	<p class="tmp"><span>例2-3</span></p>
	DnDしたファイルをアップロードします。
		<a href="sample/sample7(DnD)/index.html" target="_blank">新規タブ</a>
	<iframe width="100%" height="400" src="sample/sample7(DnD)/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


<p class="lang">例2-2のJSにアップロード用のスクリプトを追加</p>
```
 //アップロードボタンを押したときの処理
$('#upload').on('click',function(){
    if(window.confirm('アップしていいですか？')){//確認メッセージ
        total = 0;
        // ファイルを上げに行く  
        var fd= new FormData();  
        for(var i=0;i<waitList.length;i++) {
            fd.append('file['+i+']', waitList[i]);//ファイル追加
        }


        //FormDataを格納した変数fdをupload.phpに送信
        $.ajax({  
            url: "upload.php",  
            type: "POST",  
            contentType: false,  
            processData: false,  
            cache: false,  
            data: fd,  
            success: function(data) {  
                $('#waitingList').children('li').remove();  
                waitList=[];
                alert('アップロードに成功しました');  
            },  
            error: function(data) {  
                alert('アップロードに失敗しました');  
            }  
        });  
    }
});  
```

<p class="lang">upload.php</p>
```
<?php
//フォルダがなければ作成する
if(!file_exists('upload')){
		mkdir('upload');
}

$file = array();

if (!empty($_FILES['file'])){  
		foreach ($_FILES['file'] as $string=>$naiyou){  
				foreach ($naiyou as $key=>$val){  
						$file[$key][$string] = $val;  
				}  
		}  
		foreach ($file as $key=>$val){  
				move_uploaded_file($val['tmp_name'], 'upload/'.$val['name']);  
		}  
}  
?>  
```

・・・記入途中・・・