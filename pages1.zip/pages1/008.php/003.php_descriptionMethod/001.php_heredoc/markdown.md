*[page-title]:ヒアドキュメント

## ヒアドキュメント

「ヒアドキュメント」は長い文字列を変数に代入したり、出力する場合に使います。PHPスクリプトからHTMLを出力する場合などに便利な手法です。

<p class="tmp list"><span>リスト1</span></p>
```
<?php
$str_name = "太郎";
echo <<<ABC
ヒアドキュメント<br>
です。<br>
こんにちは。$str_name だよ。
ABC;
?>
```
    
<div class="exp">
	<p class="tmp"><span>例1</span></p>
	ヒアドキュメント内での「変数」の挙動を確認するサンプルスクリプトです。
<a href="sample/sample1.php" target="_blank">新規タブ</a>
</div>


<p class="result"><span>結果</span></p>
<iframe width="100%" height="100" src="sample/sample1.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<p class="tmp"><span>書式</span>ヒアドキュメントの構文</p>
```
<<<開始ID
文字列
終端ID;
 ``` 
### IDの命名ルール

ヒアドキュメントのID名は、以下のルールに気を付けて命名しましょう。

* 開始ID、終端IDは必ず同じ名前にする
* IDはアルファベット大文字・小文字、日本語でもOKだが、アルファベット大文字が基本
* 数字を先頭にしてはいけない
* 記号は_（アンダースコア）のみ可

 

ちなみによくあるID名は以下のとおりです。

* EOD（End of Document）
* EOM（End of Message）
* EOF（End of File）

上記いずれかのID名を付けるのが一般的です。


### 注意点

* 終端IDの後には改行を入れること
* 終端IDの前後に文字列を入れてはいけない（終端IDの前後に空白やインデント、コメントなど何らかの文字列が入るとエラーになります。）
* 開始IDの後に文字列を入れてはいけない（開始IDの後に、改行以外の空白を含めた文字を入れるとエラーになります。）

<p class="tmp list"><span>リスト2</span></p>
```
<?php

// ヒアドキュメント全体を変数に格納
$str = <<<EOD
ヒアドキュメントで、<br>
テキスト出力も自由自在！！
EOD;

// 変数を出力
echo $str;
?>
```
		
<div class="exp">
	<p class="tmp"><span>例2</span></p>
	ヒアドキュメントを変数に格納すれば、いろんな箇所で使い回すこともできます。
	<a href="sample/sample2.php" target="_blank">新規タブ</a>
</div>


<p class="result"><span>結果</span></p>
<iframe width="100%" height="100" src="sample/sample2.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<p class="tmp list"><span>リスト3</span></p>
```
<?php
// 都市名を変数に格納
$city = '横浜';

$str = <<<EOD
こんにちは。<br>

ここは $city 市です！<br>

ごゆっくり{$city}を堪能ください！
EOD;

// (2行目)ここは $city 市です！ ←半角スペースを空けて変数を記述
// (3行目)ごゆっくり{$city}を堪能ください！ ←半角スペースを入れたくなければ { }（波カッコ）で変数を囲う

echo $str;
?>
```

<div class="exp">
	<p class="tmp"><span>例3</span></p>
	ヒアドキュメントは文字列だけでなく、変数を使うこともできます。
	<a href="sample/sample3.php" target="_blank">新規タブ</a>
</div>



<p class="result"><span>結果</span></p>
<iframe width="100%" height="150" src="sample/sample3.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


<p class="tmp list"><span>リスト4</span></p>
```
<?php

// HTMLを丸ごと変数に格納
$html = <<<EOD

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ドキュメント</title>
</head>
<body>
<p>ヒアドキュメントで、<br>
テキスト出力も自由自在！！</p>
</body>
</html>

EOD;

echo $html;
?>
```
<div class="exp">
	<p class="tmp"><span>例4</span></p>
	ヒアドキュメントは文字列だけでなく、HTMLタグなども出力できます。
	<a href="sample/sample4.php" target="_blank">新規タブ</a>
</div>
    
<p class="result"><span>結果</span></p>
<iframe width="100%" height="150" src="sample/sample4.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## ヒアドキュメントを使わない書き方

HTMLに埋め込んで使うことも多いPHPですが、以下のように部分部分でPHPタグを使う記述法をよく使います。

<p class="tmp list"><span>リスト</span></p>
```
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $title; ?></title>
</head>
<body>

	<?php //PHPタグをHTMLタグで挟む; ?>
	<h1><?php echo $h1; ?></h1>
	<p><?php echo $text; ?></p>
	<ul>
		<li><?php echo $list1; ?></li>
		<li><?php echo $list2; ?></li>
		<li><?php echo $list3; ?></li>
	</ul>

</body>
</html>
```
