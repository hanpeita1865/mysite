*[page-title]:9-8. Photoshopのパスをillustratorと連携しよう

