<?php

namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use SocymSlim\SlimMiddle\Config\AppConfig;
use SocymSlim\SlimMiddle\Services\FolderService;
use SocymSlim\SlimMiddle\Services\EditService;
use SocymSlim\SlimMiddle\Services\PermissionService;
use PDO;
use Slim\Routing\RouteContext;

class DraftEditMiddleware implements MiddlewareInterface {
    private AppConfig $config;
    private FolderService $folderService;
    private EditService $editService;
    private PermissionService $permissionService;

    public function __construct( AppConfig $config, FolderService $folderService, EditService $editService, PermissionService $permissionService ) {
        $this->config = $config;
        $this->folderService = $folderService;
        $this->editService = $editService;
        $this->permissionService = $permissionService;
    }

    public function process( ServerRequestInterface $request, RequestHandlerInterface $handler ): ResponseInterface {
        
        try {
            
            // throw new \Exception('テストエラー');

            $isLogin = isset($_SESSION['auth_user']);
            
            // 初期値
            $canEdit = false;
            $canView = false;
            $isAdmin = false;
            $isEditor = false;
            $userName = null;
            $isDraft = false;

            // $path = rtrim($request->getUri()->getPath(), '/');
            // $folderName = basename($path);
            // $folderNoNum = preg_replace('/^\d{3}\./', '', $folderName);
            

            //削除
            // $params = $request->getAttribute('params');
            // $folderName = basename($params);
            
            // Route取得 追加
            $route = RouteContext::fromRequest($request)->getRoute();

            $params = '';
            $folderName = '';

            if ($route) {

                // ① /pages[/{params:.*}] 用
                $params = $route->getArgument('params');

                // ② /pages/{path:.+}/Business_manager_Announced 用
                $pathArg = $route->getArgument('path');

                if (!empty($params)) {

                    $folderName = basename($params);

                } elseif (!empty($pathArg)) {

                    $folderName = basename($pathArg);
                }
            }

            // ③ fallback
            if (empty($folderName)) {

                $path = rtrim(
                    $request->getUri()->getPath(),
                    '/'
                );

                $folderName = basename($path);
            }

            
            // 非ログインは閲覧のみ許可（編集不可）
            if ($isLogin) {

                $authUser = $_SESSION['auth_user'];
                $userName = $authUser['name'];
                
                $permission = $this->permissionService->getPagePermission( $authUser, $folderName);
                
                $canEdit = $permission['canEdit'];
                $canView = $permission['canView'];
                $isAdmin = $permission['isAdmin'];
                $isEditor = $permission['isEditor'];
            }
            

            // 下書き判定
            if ($canView === true) {

                $db = $this->editService->db();

                $sql = '
                    SELECT 1
                    FROM draft_list
                    WHERE folder_name = :folder_name
                    LIMIT 1
                ';

                $stmt = $db->prepare($sql);
                $stmt->bindValue(
                    ':folder_name',
                    // $folderNoNum,
                    $folderName,
                    PDO::PARAM_STR
                );
                $stmt->execute();

                $isDraft = (bool)$stmt->fetchColumn();
            }


            $request = $request
                ->withAttribute('isLogin', $isLogin)
                ->withAttribute('canEdit', $canEdit)
                ->withAttribute('userName', $userName)
                ->withAttribute('canView', $canView)
                ->withAttribute('isAdmin', $isAdmin)
                ->withAttribute('isEditor', $isEditor)
                ->withAttribute('isDraft', $isDraft);
            
        } catch (\Throwable $e) {

            // ログだけ残す（推奨）
            error_log(
                '[DraftEditMiddleware] ' .
                $e->getMessage()
            );

            // デフォルト値を設定して通常表示継続
            $request = $request
                ->withAttribute('isLogin', false)
                ->withAttribute('canEdit', false)
                ->withAttribute('userName', null)
                // ->withAttribute('canView', true)
                ->withAttribute('canView', false)
                ->withAttribute('isAdmin', false)
                ->withAttribute('isEditor', false)
                ->withAttribute('isDraft', false);
        }            

        return $handler->handle($request);
    }
}