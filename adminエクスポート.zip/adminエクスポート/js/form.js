//画像を選択してキャプチャ
document.getElementById('my-photo').addEventListener('change', function(e){
	
	const imgTopSize = this.files[0].size; //ここでファイルサイズを取得

    if(imgTopSize>=2000000) {
        alert('ファイルサイズが大きすぎます。（'+imgTopSize+'Byte）');
        document.getElementById('my-photo').value = '';
    }else{

        document.getElementById('photo-image').innerHTML = '';//表示されてる画像を最初にクリア

        const file = e.target.files[0];//Fileオブジェクトを取得
        const reader = new FileReader(); //オブジェクトを生成

        //ファイル情報をキャプチャする
        reader.onload = (function(file){
            return function(e){
                // サムネイル用のimgタグ
                const html =  '<img class="thumb" src='+ e.target.result + '>';

                // サムネイルタグを生成
                document.getElementById('photo-image').innerHTML = html;
            };
        })(file);

        reader.readAsDataURL(file);

    }
});


document.getElementById('reset').addEventListener('click', function(e){
    document.getElementById('my-photo').value = '';
    document.getElementById('photo-image').innerHTML = '';
});