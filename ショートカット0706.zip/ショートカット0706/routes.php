<?php

use SocymSlim\SlimMiddle\controllers\SlimMiddleController;
use SocymSlim\SlimMiddle\controllers\AdminController;
use SocymSlim\SlimMiddle\controllers\RegisterController;
use SocymSlim\SlimMiddle\controllers\EditController;
use SocymSlim\SlimMiddle\controllers\SearchController;
use SocymSlim\SlimMiddle\controllers\PreviewController;
use SocymSlim\SlimMiddle\controllers\DraftController;
use SocymSlim\SlimMiddle\middlewares\EventLogMiddleware;
use SocymSlim\SlimMiddle\middlewares\FolderCountMiddleware;
use SocymSlim\SlimMiddle\controllers\AuthController;
use SocymSlim\SlimMiddle\middlewares\BaseAuthMiddleware;
use SocymSlim\SlimMiddle\middlewares\AdminRoleMiddleware;
use SocymSlim\SlimMiddle\middlewares\EditorRoleMiddleware;
use SocymSlim\SlimMiddle\middlewares\RoleCheckMiddleware;
use SocymSlim\SlimMiddle\middlewares\SessionStartMiddleware;
use SocymSlim\SlimMiddle\middlewares\LockpageCheckMiddleware;
use SocymSlim\SlimMiddle\middlewares\DraftEditMiddleware;
use SocymSlim\SlimMiddle\middlewares\DraftRoleMiddleware;
use SocymSlim\SlimMiddle\controllers\CategoryController;
use SocymSlim\SlimMiddle\controllers\ShortcutController;
use SocymSlim\SlimMiddle\middlewares\PageAccessLogMiddleware;


use SocymSlim\SlimMiddle\Config\AppConfig;

$container = $app->getContainer();
$config = $container->get(AppConfig::class);
$basePath = $config->basePath;


$app->setBasePath($basePath."/public");

$app->add(SessionStartMiddleware::class);//セッションスタート


//カテゴリー用（専用ページ） 試作追加
$app->any(
    '/pages/category1[/]',
    CategoryController::class . ':managerPage'
)
    ->add(DraftEditMiddleware::class)
    ->add(LockpageCheckMiddleware::class);

$app->any(
    '/pages/{path:.+}/category1[/]',
    CategoryController::class . ':managerPage'
)
    ->add(DraftEditMiddleware::class)
    ->add(LockpageCheckMiddleware::class);
    
//---

//ショートカットキー一覧（専用のページ）
$app->any(
    '/pages/shortcut[/]',
    ShortcutController::class . ':shortcutList'
)
    ->add(DraftEditMiddleware::class)
    ->add(LockpageCheckMiddleware::class);
    
//---


$app->get('/shortcut-api', ShortcutController::class.':shortcutApi');

$app->get('/shortcut-detail-api/{id}', ShortcutController::class.':detail');




//各ページ
$app->any('/pages[/{params:.*}]', EditController::class . ':markData')
    ->add(PageAccessLogMiddleware::class)
    ->add(DraftEditMiddleware::class)
    ->add(LockpageCheckMiddleware::class);
    
    


//---------------------
// 編集画面
//---------------------    

$app->get('/edit/{folder}', EditController::class.":editData")
->add(RoleCheckMiddleware::class)
->add(BaseAuthMiddleware::class);


$app->group('/edit', function ($group) {
    //編集保存
    $group->post("/markdown-upload", EditController::class.":markdownUpload");
    //ファイル保存
    $group->post("/file_save", EditController::class.":fileSave");
    //ファイル削除
    $group->post("/file_delete", EditController::class.":fileDelete");
        
})
->add(BaseAuthMiddleware::class);


//プレビュー
$app->post("/preview1.php", PreviewController::class.":previewData");


//---------------------
// 管理
//---------------------  
        
$app->group('/admin', function ($group) {
    //メニュー管理画面
    $group->get("", AdminController::class . ":adminData");
    //下書き設定（temporaryにコピー）
    $group->post("/draft_set", DraftController::class.":draft_set");
    
    //下書きリスト表示
    $group->get("/draft_list", DraftController::class . ":draftList");
})
->add(FolderCountMiddleware::class)
->add(EditorRoleMiddleware::class)
->add(BaseAuthMiddleware::class);


$app->group('/admin', function ($group) {
    // 画面
    $group->group('', function ($group) {
        $group->get("/account_list", AdminController::class . ":adminAccount");//アカウント一覧
        $group->get('/register', RegisterController::class.":accountCreate");//アカウント登録用フォーム
        $group->get('/account_update', RegisterController::class.":accountUpdate");//アカウント更新用フォーム
        $group->get('/limited_page', RegisterController::class.":limitedPage");//～さんの編集許可ページ一覧 追加
        $group->get("/permission_regist", RegisterController::class.":permissionRegist");//許可ページ登録用フォーム
        
    })->add(FolderCountMiddleware::class);

    // 操作系
    $group->group('', function ($group) {
        //フォルダ新規作成
        $group->post("/folder_create", AdminController::class.":folder_create");
        //ページ名変更
        $group->post("/file_rename", AdminController::class.":file_rename");
        //フォルダ名変更
        $group->post("/folder_rename", AdminController::class.":folder_rename");
        //ページ表示・非表示の設定変更
        $group->post("/page_lock", AdminController::class.":page_lock");
        //ロック解除
        $group->post("/page_unlock", AdminController::class.":page_unlock");
        //lockデータ削除（フォルダ削除時）
        $group->post("/lockdata_del", AdminController::class.":lockdata_del");
        
        //削除したフォルダをゴミ箱(trush)に移動
        $group->post("/trush", AdminController::class.":trush");
        //対象フォルダのみ削除
        $group->post("/folderDelOnly", AdminController::class.":folderDelOnly");
        //配下のフォルダも削除
        $group->post("/del_allfolder", AdminController::class.":del_allfolder");
        //並べ替え確定
        $group->post("/sort_confirm", AdminController::class.":sort_confirm");
        
        //アカウント新規登録 
        $group->post('/register', RegisterController::class.":accountCreatePost");
        //アカウント更新 
        $group->post('/account_update', RegisterController::class.":accountUpdatePost");
        //アカウント削除 
        $group->post('/account_delete', RegisterController::class.":accountDelete");
        
        //管理者登録用フォーム
        $group->post('/admin_regist', RegisterController::class.":adminRegist");
        //管理者解除用フォーム
        $group->post('/admin_remove', RegisterController::class.":adminRemove");
        
        //ページ限定編集者切替フォーム
        $group->post('/limited_regist', RegisterController::class.":limitedRegist");
        
        //ページ限定解除フォーム
        $group->post('/limited_remove', RegisterController::class.":limitedRemove");
        
        //下書きを反映
        $group->post("/draft_reflected", DraftController::class.":draftReflected");
        
        //ページ編集許可取り消し
        $group->post("/permission_remove", RegisterController::class.":permissionRemove");
        //許可ページ登録
        $group->post("/permission_confirmed", RegisterController::class.":permissionConfirmed");

        
    })
    ->add(EventLogMiddleware::class);
    
    
    $group->group('', function ($group) {
        // //下書きリスト表示
        // $group->get("/draft_list", DraftController::class . ":draftList");
        //下書き削除
        $group->post('/draft_delete', DraftController::class.":draftDelete");
    });
})
->add(AdminRoleMiddleware::class)
->add(BaseAuthMiddleware::class);



//下書きページ表示
$app->any('/temporary[/{params:.*}]', DraftController::class . ':draftMarkData')
->add(DraftEditMiddleware::class);

//下書き編集画面表示
$app->get('/draft_edit/{folder}', DraftController::class.":draftEdit")
->add(DraftRoleMiddleware::class)
->add(BaseAuthMiddleware::class);



//---------------------
// 検索関連
//---------------------  
       
//検索結果
$app->get("/search", SearchController::class.":searchResult")
    ->add(LockpageCheckMiddleware::class);
    
//検索用Db一括書き込み
$app->get("/searchdb_save", SearchController::class.":searchdbSave");

//検索用カテゴリー生成
$app->get('/api/searchMenu', EditController::class.":searchMenu");


//---------------------
// ログイン関連
//---------------------  
$app->any('/login', [AuthController::class, 'showLoginForm']);
    
$app->post('/loginProcess', [AuthController::class, 'login']);

$app->post('/logout', [AuthController::class, 'logout']);

    

//---------------------
// その他
//---------------------  

//フォルダ使用中かチェック
$app->post("/folderUseCheck", AdminController::class.":folderUseCheck");


//pages内のディレクトリを配列で取得
$app->post("/pagesDirGet", AdminController::class.":pagesDirGet");


//番号修正
$app->post("/num_replace", AdminController::class.":num_replace");


//folderObjの値をJSに引き渡し
$app->get('/api/folderObj', EditController::class.":folderObjGet");


//titlePathObjの値をJSに引き渡し
$app->get('/api/titlePathObj', EditController::class.":titlePathObjGet");


// locklist一覧をJSに引き渡し 追加
$app->get('/api/lockList', EditController::class . ':lockListGet');