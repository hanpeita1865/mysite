<?php
use Psr\Http\Message\ServerRequestInterface;//テスト
use Psr\Http\Message\ResponseInterface;//テスト

use SocymSlim\SlimMiddle\controllers\SlimMiddleController;

use SocymSlim\SlimMiddle\controllers\MemberController;
use SocymSlim\SlimMiddle\controllers\SearchController;
use SocymSlim\SlimMiddle\middlewares\UserCheck;

use SocymSlim\SlimMiddle\controllers\PreviewController;

use SocymSlim\SlimMiddle\middlewares\EventLog;//テスト

use SocymSlim\SlimMiddle\middlewares\RecordIPAddressToLog;//テスト

require 'admin/basepath.php';

$app->setBasePath($basePath."/public");


$app->any("/pages/{folderName}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/", MemberController::class.":markData");//from_now マークダウン変換


//プレビュー
$app->any("/preview1.php", PreviewController::class.":previewData");


//管理画面
$app->any("/admin", MemberController::class.":adminData");


//編集画面
$app->any("/edit", MemberController::class.":editData");


//テスト
$app->any("/writeBody", MemberController::class.":testData");


$params = ["pattern"=>2, "auth"=>1];//テスト

//フォルダ新規作成
$app->any("/folder_create", MemberController::class.":folder_create")->add(new EventLog($container));
// $app->any("/folder_create", MemberController::class.":folder_create")->add(new RecordIPAddressToLog($container));


//メニュー名変更
$app->any("/file_rename", MemberController::class.":file_rename")->add(new EventLog($container));


//フォルダ名変更
$app->any("/folder_rename", MemberController::class.":folder_rename")->add(new EventLog($container));


//locklistテーブル変更
$app->any("/lockdata_edit", MemberController::class.":lockdata_edit")->add(new EventLog($container));


//ロック設定・解除
$app->any("/page_lock", MemberController::class.":page_lock")->add(new EventLog($container));


//フォルダのリスト取得
$app->any("/folder_list", MemberController::class.":folder_list")->add(new EventLog($container));


//並べ替え確定（構成フラットから新しいフォルダ構成作成）
$app->any("/sort_complete", MemberController::class.":sort_complete")->add(new EventLog($container));


//lockデータ削除
$app->any("/lockdata_del", MemberController::class.":lockdata_del")->add(new EventLog($container));


//削除したフォルダをゴミ箱(trush)に移動
$app->any("/trush", MemberController::class.":trush")->add(new EventLog($container));


//フォルダ構成をメニューに反映
$app->any("/folder_complist", MemberController::class.":folder_complist")->add(new EventLog($container));


//ホームページ　テスト
$app->any("/home", MemberController::class.":homepage");


//フォルダ削除テスト
$app->any("/folderDelTest", MemberController::class.":folderDelTest");

//pagesバックアップ テスト
$app->any("/backup", MemberController::class.":backup");


// //ページ編集画面
// $app->any("/page_update", MemberController::class.":page_update");

// $app->any("/writeToLog",
// 	function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
// 		$logger = $this->get("logger");
// 		$logger->info("ログに書き出しました。"); 
// 		$content = "ログへの書き出し実験";
// 		$responseBody = $response->getBody();
// 		$responseBody->write($content);
// 		return $response;
// 	}
// );