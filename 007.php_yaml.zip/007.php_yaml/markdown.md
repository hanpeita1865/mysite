*[page-title]:Yamlファイルのパース

参考サイト
: [yaml_parse](https://www.php.net/manual/ja/function.yaml-parse.php)
: [phpのyamlがわからない!最短理解でyamlが得意になるには](https://www.sejuku.net/blog/68982)


## yamlとは

yamlとは構造化データの表現記法です!  
まずは実際のyamlファイルを見てみましょう。
```
users:
- nickname:さかもとさん
    age:25
```

usersという項目の下に、nickname(名前)とage(年齢)という項目がぶら下がっています。  
そしてその中身は「さかもとさん」、「25」のようにデータが入っています。  
これが構造化データです。

構造化データはプログラムなどで利用する時にとても利用しやすいです。  
構造化データ化されていない文字列として以下のような日本語が渡された場合を考えてみます。
```
ユーザーの名前はさかもとさん、年齢は25歳
```

これではプログラムはデータをどのように扱ってよいかわかりません。  
そして、yamlファイルの用途としては、例のようなデータの保存・やりとり、設定ファイルに使用したりします。


## phpでyamlを使う

実際にyamlを使用する場合としては、

* yamlファイルを作成して自分が作成しているphpのプログラムに取り入れる
* 開発中にこれを使用して欲しいと指定されたりする

のような場合があると思います。  
その時、そのままyamlファイルを読み込んでもphp側ではうまく認識されません。

では、どうすればよいのか。  
ここでは、spycを使用する方法を紹介します。

※spyc・・・phpで書かれたyamlの解析のためのプログラムです。


## spycをインストールして使用する方法

spycを以下サイトからダウンロード  
: <https://code.google.com/archive/p/spyc/downloads>

ダウンロードしたzipを解凍すると、spyc.phpや他のファイルが出来ますが、spyc.phpのみをサーバーに上げます。

### yamlファイルの準備
以下の様なyamlファイル(yamlfile.yaml)を用意します。
```
users:
    nickname:さかもとさん
    age:25
```

### phpファイルの準備
以下の内容のphpファイルを準備します。
```
<?php
require_once("spyc.php"); // ()の部分にはspyc.phpを置いたパスを入れます
class spycTest {
    function testSpyc(){
        $yaml_output= spyc_load_file("yamlfile.yaml");// ()の部分にはyamlファイルがあるパスを入れます
        var_dump($yaml_output); // 結果を出力します。
    }
}

$result = new spycTest();
$result->testSpyc();
?>
```

### phpの実行結果
準備したphpファイルを実行した結果が以下です。
```
array (size=1)
  'users' => 
    array (size=2)
      'nickname' => string 'さかもとさん' (length=18)
      'age' => int 25
```
<p class="result"><span>結果</span></p>

<a href="sample/yaml/index.php" target="_blank">新規タブ</a>

このように配列からyamlのデータを取得できます。
