<?php
use Psr\Http\Message\ServerRequestInterface;//テスト
use Psr\Http\Message\ResponseInterface;//テスト

use SocymSlim\SlimMiddle\controllers\SlimMiddleController;

use SocymSlim\SlimMiddle\controllers\MemberController;
use SocymSlim\SlimMiddle\controllers\SearchController;
use SocymSlim\SlimMiddle\middlewares\UserCheck;

use SocymSlim\SlimMiddle\controllers\PreviewController;

require 'admin/basepath.php';

// $app->setBasePath("/from_now_slim/public");
$app->setBasePath($basePath."/public");


$app->any("/pages/{folderName}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/", MemberController::class.":markData");//from_now マークダウン変換



//プレビュー
$app->any("/preview1.php", PreviewController::class.":previewData");


//管理画面用（テスト）
$app->any("/admin", MemberController::class.":adminData");
