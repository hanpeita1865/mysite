---
title: 05.ファイルの入出力
taxonomy:
    category:
        - docs
visible: true
---

今までのプログラムでは、実行結果を画面に出力していましたが、実行結果をファイルに出力することもできます。
そうすれば、プログラムの実行結果をずっと保存しておくことができます。

<h2 class="h-type2">ファイルを開く</h2>

ファイルを開くには、open関数を使います。open関数を使うために、モジュールをインポートする必要はありません。
ファイルデータを書き込むときには、下記のようにopen関数を「書き込みモード（w）」で呼び出します。


<p class="tmp"><span>書式1</span>ファイルを「書き込みモード」で開き、ファイルオブジェクトを変数に代入する</p>
	変数 = open(ファイル名, 'w')


<p class="att">※open関数は、開いたファイルを操作するためのファイルオブジェクトを返します。オブジェクトは、ファイルに対してデータを書き込んだり
ファイルを閉じたりするときに必要です。そこで上記のように、open関数が返したファイルオブジェクトを変数に代入しておきます。
また、引数に指定したファイルが存在しないときは、新規作成されます。</p>

<div class="box-example">
    <h3 class="h-example">例1</h3>
	greeting.txtというファイルを書き込みモードで開き、変数fileに代入します
</div>

<p class="file"><span>テキスト</span>greeting.txt</p>
<pre>
お久しぶりです。
お元気ですか？
</pre>

<p class="inpre"><span>インタプリタ</span></p>
    >>> file = open('greeting.txt', 'w')
    >>> 


<h2 class="h-type2">ファイルにデータを書き込む</h2>

<p  class="att">※ファイルにデータを書き込む方法のひとつは、ファイルオブジェクトのwriteメソッドを呼び出すことです。</p>

<p class="tmp"><span>書式2</span>変数にファイルオブジェクトが代入されているとき、そのファイルに文字列を書き込む</p>

	変数.write(文字列)

<div class="box-example">
    <h3 class="h-example">例2</h3>
	greeting.txtというファイルに対して、<br>
    おひさしぶりです。<br>
    お元気ですか？<br><br>
    と書き込む。改行はエスケープシーケンス（'\n'）で表します。
</div>
<p class="inpre"><span>インタプリタ</span></p>
    >>> file = open('greeting.txt', 'w')
    >>> file.write('おひさしぶりです。\nお元気ですか？\n')
    18


<p class="att">※最後に表示された「18」は、writeメソッドがファイルに書き込んだ文字数です。\nも1文字として数えます。</p>

<h2 class="h-type2">ファイルを閉じる</h2>

書き込みが完了したら、最後にclose関数でファイルを閉じて終わります。

<p class="tmp"><span>書式3</span>変数にファイルオブジェクトが代入されているとき、そのファイルを閉じる</p>

	変数.close()

<div class="box-example">
    <h3 class="h-example">例3</h3>
	さきほどメッセージを書き込んだgreeting.txtというファイルを閉じる
</div>
<p class="inpre"><span>インタプリタ</span></p>

	>>> file.close()


<h2 class="h-type2">ファイルの文字エンコーディングを指定する</h2>

ファイルの文字エンコーディングを指定するには、open関数のキーワード引数encordingを使います。

<p class="tmp"><span>書式4</span>open関数で文字エンコーディングを指定する</p>
	
    変数 = open(ファイル名, 'w', encording='文字エンコーディング')	

<div class="box-example">
    <h3 class="h-example">例5</h3>
	
</div>
<p class="inpre"><span>インタプリタ</span></p>

    >>> file = open('greeting.txt', 'w', encoding='utf_8')
    >>> file.write('おひさしぶりです。\nお元気ですか?\n')
    18
    >>> file.close()


greeting.txtを、もう一度開いてみてください。文字エンコーディングがUTF-8になってるはずです。<br>
このように、ファイルを読み書きするときには、文字エンコーディングを明示的に指定するようにしましょう。

<h2 class="h-type2">ファイル入出力とwith文</h2>

ファイルの入出力で気を付けなくてはならないのは、「読み書きを終えたファイルは閉じる必要がある」ということです。<br>
また、一度に開けるファイルの数には上限があるので、あまりたくさんのファイルを開いたままにしていると、新しくファイルを開けなくなる可能性があります。

<p class="red bold">ファイル入出力の処理とwith文を組み合わせると、closeメソッドを呼び出さなくても、使い終わったファイルを自動的に閉じることができます。</p>


<p class="tmp"><span>書式5</span>with文を使ったファイル書き込み</p>

    with open(ファイル名, 'w', encoding='文字エンコーディング') as 変数:
        ファイルへの書き込み処理


上の書式では、ファイルを「書き込みモード（w）」で開き、ファイルオブジェクトを変数に代入します。<br>
with文の内部では、この変数を使ってファイルへの書き込み処理を行います。<br>
with文が終わると、開いていたファイルは自動的に閉じられます。closeメソッドを呼び出す必要はありません。

<div class="box-example">
    <h3 class="h-example">例6</h3>
    with文を使ってopen関数を呼び出し、greeting.txtファイルを「書き込みモード」、文字エンコーディングは「UTF-8」で開きます。
    with文内部では、メッセージを書き込みます。	
</div>
<p class="inpre"><span>インタプリタ</span></p>

    >>> with open('greeting.txt', 'w', encoding='utf_8') as file:
    ...      file.write('おひさしぶりです。\nお元気ですか?\n')
    ...
    18
    >>>


ファイルを入出力をする際には、with文を組み合わせて楽をしてください。

<h2 class="h-type2">ファイルからデータを読み込む</h2>

今度はPythonプログラムからファイルを読み込んでみましょう。ここでもwith文を使って、closeメソッドを呼びださなくてもよいようにします。

<p class="tmp"><span>書式6</span>with文を使ったファイル読み込み</p>

    with open(ファイル名, 'r', encoding='文字エンコーディング') as 変数:
        ファイルからの読み込み処理


上の書式では、ファイルを「読み込みモード(r)」で開き、ファイルオブジェクトを変数に代入します。<br>
with文の内部では、この変数を使ってファイルからの読み込み処理を行います。<br>
絶対パスや相対パスでも指定することもできます。

ファイルからの読み込みにはreadメソッドを使います。

<p class="tmp"><span>書式7</span>変数にファイルオブジェクトが代入されているとき、そのファイルの内容を読み込み、文字列として返す</p>

	変数.read(   )

<div class="box-example">
    <h3 class="h-example">例7</h3>
    with文を使って、open関数を呼び出し、greeting.txtファイルを「読み込みモード」、文字エンコーディングは「UTF-8」で開きます。<br>
    with文の内部では、readメソッドを使ってファイルの内容を読み込み、変数textに代入します。<br>
    最後にwith文の外部で、変数textの内容を表示します。
</div>
<p class="inpre"><span>インタプリタ</span></p>

    >>> with open('greeting.txt', 'r', encoding='utf_8') as file:
    ...      text = file.read()
    ...
    >>> text
    'おひさしぶりです。\nお元気ですか?\n'
    >>>



<h2 class="h-type2">ファイルを1行ずつ読み込む</h2>

ファイルを読み込む際に、1行ずつ読み込めると便利な時があります。<br>
例えば、ファイルの内容に行番号を付けて表示するプログラムを作ろうと思ったら、ファイルを1行ずつ読み込みながら各行に対する処理を行えばよいです。

ファイルオブジェクトを代入した変数と、for文を組み合わせると、ファイルを行単位で読み込むことができます。

<p class="tmp"><span>書式8</span></p>

    for 変数 in ファイルオブジェクト:
        ファイルの各行に対する処理

上の書式では、ファイルオブジェクトが表すファイルを1行ずつ読み込み、変数に代入します。<br>
for文の内部では、この変数を使ってファイルの各行に対する処理を行います。


<div class="box-example">
    <h3 class="h-example">例8</h3>
	greeting.txtを1行ずつ読み込み、行番号を付けて表示します
</div>

<p class="editpre"><span>テキストエディタ</span>file1.py</p>

    with open('greeting.txt', 'r', encoding='utf_8') as file:
        count = 1
        for line in file:
            print('{0:03d} {1}'.format(count, line), end='')
            count += 1


<p class="result">実行結果</p>

    001 お久しぶりです。
    002 お元気ですか？


プログラムの中で、formatメソッドを呼び出す文字列に含まれる{0:03d}は、「10進数の数値を3桁で出力し、3桁に満たない部分は0で埋める」という動作をします。<br>
また、print関数のキーワード引数で、end=''と指定すると、出力時に改行しなくなります。<br>
ファイルから読み込んだ行に改行が含まれているため、print関数では改行をしないようにしています。

<div class="box-example">
    <h3 class="h-example">例9</h3>
    コマンドライン引数で指定したファイルを1行ずつ読み込んで、行番号を付けて表示するプログラムを作成します。<br>
    コマンドライン引数の取得には、sysモジュールの変数argvを使います。<br>
    コマンドラインで、「file2.py file2.py」と入力して実行します。	
</div>

<p class="editpre"><span>テキストエディタ</span>file2.py</p>

    import sys
    with open(sys.argv[1], 'r', encoding='utf_8') as file:
        count = 1
        for line in file:
            print('{0:03d} {1}'.format(count, line), end='')
            count += 1


<p class="result">実行結果</p>

    001 import sys
    002 with open(sys.argv[1], 'r', encoding='utf_8') as file:
    003     count = 1
    004     for line in file:
    005         print('{0:03d} {1}'.format(count, line), end='')
    006         count += 1
