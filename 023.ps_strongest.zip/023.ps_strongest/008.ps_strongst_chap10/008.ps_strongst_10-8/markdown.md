*[page-title]:10-8. さまざまなタッチで描画するフィルター


<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-08.jpg)](upload/10-08.jpg){.image}
</div>