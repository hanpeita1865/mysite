---
title: '03. Laravelを使ってみる'
media_order: 'hello.png,laravel_folder.png,welcome.png,laravel_install.jpg'
taxonomy:
    category:
        - docs
---

* [Laravel開発の手順](#p1)
* [LaravelでHello World!の表示](#p2)
* [補足](#p3)
* [Laravelアプリの公開アドレス](#p4)

Laravelを使って、実際にアプリケーションを作成してみましょう。そして内蔵のWeb サーバーで実際に動かしてみましょう。

## Laravel開発の手順 ##{#p1}
では、Laravelを使ってみましょう。Laravelでの開発は、基本的に**コマンドライン**から実行して行います。開発の流れをざっと整理すると次のようになるでしょう。

{c:blue}① プロジェクトの作成{/c} 
: Laravelでは、プログラムは「**プロジェクト**」の形で作成をします。プロジェクトというのは、アプリケーションで必要となるファイルやフォルダ一式をまとめたものです。 Webアプリケーションでは、多数のファイル類を作成していくため、それらを階層的に 整理しまとめていく必要があります。<br>
プロジェクトの作成を行うことで、アプリケーションに必要となるファイルやフォルダ類をすべて、**自動生成**することができます。手作業でこれらを用意していくのに比べると圧倒的に楽です。

{c:blue}② 必要なプログラムの作成{/c}
:プロジェクトを作り、アプリケーションの基本部分が用意できたら、その上に作成するアプリケーションの機能となる部分を作っていきます。これには、**PHPのスクリプトファイル**や**画面表示のためのテンプレート**、**その他各種の設定ファイルの編集**などが必要となるでしょう。<br>
この部分が、Laravelでの「***プログラミング***」となる部分です。これは1つのファイルを 作れば完成というわけではなく、必要に応じていくつものファイルを作っていく必要が あるでしょう。

③ サーバーで実行
: 基本的なプログラムができたら、実際にアプリケーションを実行して動作を確認していきます。Laravelには、Webサーバー機能が内蔵されており、別途HTTPサーバーなどを用意しなくともその場で実行することができます。<br>
こうして動作を確認したら、また②に戻ってプログラムの作成や修正を行い、再び③でサーバーを使って操作確認する。この操作を繰り返して開発を進めていくことになるでしょう。

④ デプロイする
: アプリケーションが完成したら、実際に公開するWebサイトにデプロイ(プログラムをアップロードし動かせる状態にすること)します。PHP対応のレンタルサーバーや、クラウドサービスなど、Laravelが使える環境はいろいろとあります。それらにファイルをアップロードして、実際にアクセスし、正常に動作することを確認できたら、開発終了です。

本書のほとんどのページを費やして説明をするのは、この手順の**②の部分**の「**{c:blue}プログラムの作成{/c}**」の作業です。 Laravelでは、***どのようなプログラムを作成していくのか***、これがもっとも重要です。  
ただし、この部分を飛ばしても、一連の作業そのものは行うことができます。プロジェクトを作り、そのままサーバーで実行すれば、作ったプロジェクトの動作を確認すると ころまで行えるのです。



### プロジェクトの作成
では、Laravelのプロジェクトを作成しましょう。これはコマンドラインから実行します。コマンドプロンプトを起動しましょう。


1. ディレクトリを移動する。
: Xamppに設置する場合は、Xamppのドキュメントルートまで移動してください。

3. laravel newを実行する。
: laravelコマンドは、「laravel new プロジェクト名」という形で実行すると、その名前でプロジェクトを作成します。「laravelapp」という名前で作成してみます。以下のようにコマンドを実行してください。

```
laravel new laravelapp
```
自分は、上記のコマンドを実行するとエラーが表示されてしまいました。

Composerのコマンドを利用しても作成できます。以下のコマンドを実行してください。(こちらの方法でうまくいきました..。)  
最新のバージョンが作成されます。

<p class="tmp cmd"><span>コマンド1</span></p>
```
composer create-project laravel/laravel laravelapp --prefer-dist
```
<!--
または、
```
composer create-project --prefer-dist laravel/laravel laravelapp
```
-->

上記を書式にすると

<p class="tmp"><span>書式1</span></p>
```
composer create-project laravel/laravel プロジェクト名 --prefer-dist
```

バージョンを指定する場合

<p class="tmp cmd"><span>コマンド2</span></p>
```
//7系
composer create-project "laravel/laravel=7.*" laravelapp

//6系
composer create-project "laravel/laravel=6.*" laravelapp

//5系
composer create-project "laravel/laravel=5.*" laravelapp
```


<p class="tmp"><span>書式2</span></p>
```
composer create-project "laravel/laravel=バージョン" プロジェクト名
```


そうすると、数分かけてインストールされ、
![](laravel_install.jpg)

最後下記が表示されれば完了です。

```
[32mPackage manifest generated successfully.[39m
> @php artisan key:generate --ansi
[32mApplication key set successfully.[39m

```



指定したルートに、下記の「laravelapp」フォルダが作成されます。

![](laravel_folder.png?classes=caption "Lalavelプロジェクト内一覧")

Xamppのhtdocsに設置して、<http://localhost/laravelapp/public/>にアクセスすると、以下の画像のようなサイトが表示されます。

![](welcome.png?classes=caption "Lalavelのトップページ画面")


## LaravelでHello World!の表示 ##{#p2}

routesディレクトリの中のweb.phpというファイルを開きます。

以下のコードがあらかじめ記述されています。(コメントは省略しています)

```
<?php
Route::get('/', function () {
	return view('welcome');
});
```

このコードの下に以下のコードを追加してください。

<p class="tmp list"><span>リスト1</span></p>
```
Route::get("/hello", function () {
	print("<h1>Hello World!</h1>");
	return null;
});
```

そして、<http://localhost/laravelapp/public/hello>にアクセスすると、下記が表示されます。

![](hello.png)




<!--
#### ① ディレクトリを移動する
プロジェクトを作成する場所にディレクトリを移動します。ここではデスクトップに 移動することにしましょう。以下のように実行して下さい。
```
cd Desktop
```

#### ② laravel newを実行する
laravelコマンドを実行します。laravelコマンドは、「laravel new プロジェクト名」という形で実行すると、その名前でプロジェクトを作成します。  
ここでは、「laravelapp」という名前で作ることにしましょう。以下のようにコマンドを実行して下さい。

<p class="tmp"><span>書式1</span>プロジェクト作成方法1</p>
```
Laravel new laravelapp
```
![](laravel_new.png)

ただ、自分はこのコマンドで実行するとエラーが表示されてしまいました。  

もし、Laravelのインストールが正常に行えていなかったり、パスが正しく設定できていないなどのために、Laravelコマンドがうまく動いてくれないような場合は、 composerを使ってLaravelプロジェクトを作成することもできます。これは以下のようになります。

<p class="tmp"><span>書式2</span>プロジェクト作成方法2</p>
```
composer create-project laravel/Laravel プロジェクト名 --prefer-dist
```
「プロジェクト名」のところに、作成するプロジェクトの名前を当てはめて実行します。今回は「laravelapp」という名前で作成していますから、以下のように実行すればよ いでしょう。
```
composer create-project laravel/laravel Laravelapp --prefer-dist
```
これで、先ほどのlaravel newコマンドと同様にプロジェクトが作成されます。  
プロジェクトを作成すると、デスクトップに「laravelapp」というフォルダが作成されます。これが、プロジェクトのフォルダです。この中に、アプリケーションに必要なファイル類が一式そろって保存されています。



[Laravelファイルリスト](../../../../sample/php/laravel/laravel_file_list.html?target=_blank)

<iframe width="100%" height="570" src="../../../sample/php/laravel/laravel_file_list.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

-->



## 補足 ##{#p3}

プロジェクトは、アプリケー ションに必要なファイル類を一通り備えています。要するに、「プロジェクト=アプリ ケーション」といっても差し支えありません。これをWebサーバーで実行すれば、そのままアプリケーションを使うことができます。

Laravelには、Webサーバー機能が内蔵されています。これを利用してアプリケーションを実行してみましょう。
デスクトップなどに設置したプロジェクトフォルダにディレクトリを移動し、作成した「laravelapp」プロジェクトの中に、以下のようにしてディレクトリを移動しましょう。

##### 例)
```
cd  C:\xampp\htdocs\laravelapp
```
プロジェクト内に移動したら、以下のコマンドを実行します。

<p class="tmp cmd"><span>コマンド3</span></p>
```
php artisan serve
```

そうすると、ウインドウに「Laravel development server started: &lt;http://127.0.0.1:8000&gt;」といった表示が現れます。これが現れたら、Webブラウザから以下のアドレスにアクセスして下さい。
<http://localhost:8000/>

※ 8000が既に使用してたら、他のポート番号が表示されるので、それを使って表示します。

これで、Laravelアプリケーションの先ほどの画像と同じLalavelのトップページが表示されます。  
動作を確認したら、コマンドプロンプトまたはターミナルでCtrlキー+「C」キーを押して下さい。これでサーバーが停止します。

<div class="gray-box" markdown="1">
#### Laravelの内蔵サーバーについて
Laravelはサーバー機能を内蔵していて簡単にサーバーでアプリケーションを実行できます。このサーバー機能は、実はPHP本体にあるものを利用しています。  
PHPでは、5.4以降にビルトインサーバー機能が用意されています。この機能を利用し てサーバー機能を提供しています。  
これは、あくまで動作確認用のものであり、本格的な運用に耐え得るほど堅牢なサーバーではありません。決して、**この機能を使ってそのままアプリケーションを公開したりしないで下さい。**
</div>


こちらのサイトにもLaravelの導入方法がわかりやすく書かれています。  
[Laravelをインストールしよう！導入手順まとめ](https://www.sejuku.net/blog/106106)


## Laravelアプリの公開アドレス ##{#p4}
XAMPPは、XAMPPのフォルダ内に「htdocs」というフォルダをもっています。これが、Webサーバーの公開ディレクトリになります。このフォルダ内にファイル類を配置すれ ば、それがそのままWebサーバーで公開されるようになります。  
例えば、「htdocs」フォルダ内に、先ほど作成した「laravelapp」フォルダをそのまま入れたとしましょう。すると、XAMPPのWebサーバーを起動してlaravelappにアクセスを する場合、以下のアドレスになります。  
<http://localhost/laravelapp/public/>

ここにWebブラウザからアクセスをすると、先に内蔵サーバーで確認したのと同じ トップページが表示されます。

Laravelアプリケーションでは、公開されるWebページは、アプリケーション内の 「*public*」というフォルダに用意されます。このため、*/laravelapp/public/*というよう に、アプリケーションのフォルダ名の後にpublicがついたアドレスを指定します。  
/ laravelapp/にアクセスしてもトップページの画面は現れないので注意して下さい。


### 指定のアドレスで公開する
しかし、トップページが/public/にある、というのは、なんともスマートさに欠けるのは確かです。実際にWebアプリケーションを公開するとき、http://○○/public/ よりも、 http://○○/ のほうがはるかにすっきりします。
Xampp内のhttpd.confとhttpd-vhosts.confを編集することでポート番号を分けることでアドレスを短縮することができます。  
以下のサイトを参考にしてください。


[XAMPPで複数のサイトのテストサーバーを作ってみました（バーチャルホスト）](https://mypcmemo.com/xampp-vertualhosts)


<div class="gray-box" markdown="1">
##### メモ
レンタルサーバーなどでは、httpd.confの変更が可能なところとできないところが あります。直接編集はできなくとも、代りの設定手段などを用意しているところも あります。また、多くのレンタルサーバーはLinuxなどで動いており、Apache HTTP Server がインストールされているディレクトリも異なります。
これらは利用するサーバーによって違いますので、実際にデプロイする際にはサー バー管理者に問い合わせて確認するようにして下さい。
</div>















