<?php
namespace call; // 名前空間を定義
function hello() {
        return 'もしもし';
}