*[page-title]:10-18. 波形、波紋、球面などでゆがめてみよう


<div markdown="1" class="sr-only">
</div>
<div markdown="1" class="photo-capture">
[![](upload/10-18.jpg)](upload/10-18.jpg){.image}
</div>