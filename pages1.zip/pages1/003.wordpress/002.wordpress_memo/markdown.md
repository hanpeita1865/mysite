*[page-title]:よく使う機能メモ

## 【WordPress】「home_url()」「site_url()」でサイトのURLを取得する

参考サイト
[【WordPress】「home_url()」「site_url()」でサイトのURLを取得する](https://mightyace.co.jp/2021/08/05/column3312/)

## wp_head()やwp_footer()からスクリプトを読み込む
参考サイト
[wp_enqueue_scriptを使ってwp_headまたはwp_footerでスクリプトを読み込む方法}(https://bambooworks.co/wp_register_script-wp_enqueue_script/)
### wp_register_script()でスクリプトを登録する
```
<?php wp_register_script( $handle, $src, $deps, $ver, $in_footer ); ?>
```
wp_register_script()はスクリプトを登録するための関数です。

上記ソースのように、読み込みたいファイルの数だけ下記のようなパラメータを利用して登録していきます。

### wp_deregister_script()で登録済みのスクリプトを除外する
```
<?php wp_deregister_script( $handle ); ?>
```
wp_deregister_script()は登録済みのスクリプトを除外するための関数です。

wp_register_script()で登録したスクリプトやWordPressに標準で読み込まれるようになっているjQueryファイルを読み込ませないようにするときなどに使用します。

### wp_enqueue_script()でスクリプトを読み込む
```
<?php wp_enqueue_script( $handle, $src, $deps, $ver, $in_footer ); ?>
```
wp_enqueue_script()は、wp_register_script()で登録したスクリプトをwp_head()またはwp_footer()で読み込むための関数です。


## VK パターンライブラリについて

参考サイト
: [VK パターンライブラリをもっと楽しむカスタマイズレシピ](https://lightning-g3.hp1.work/swiper-customize-vkpl-dental-clinic-facility/)

## パーマリンクの設定
パーマリンクとは、WordPressで作成した投稿の URLの形式のことです。 初期状態は 「http://○○○ .jp/?p= (連続した番号)」という形式で、記事の作 成順で番号が決まり、作成した投稿のURLが決まり ます。 パーマリンクは必ず変更が必要なわけではあ りませんが、<span class="red">投稿を作成した日付や投稿のタイトル を含めたURLに変更することで、訪問者に投稿の内 容が伝わりやすくなります。</span> 例えば、 パーマリンクを 「日付と投稿名」に設定しておくと、 URLが 「http:// ○○○.jp/ (年)/(月)/(日)/ (投稿のタイトル)」とな り、初期設定よりもいつ何について書かれた投稿な のかがわかりやすくなります。 ただし、 パーマリンク
に投稿名を含める場合、 投稿のタイトルが日本語だ と、日本語を含んだURLになってしまうので注意が 必要です。 URL を英語に変更し直すひと手間が投稿 の作成時に必要になるので、これを煩わしいと感じ るなら、「デフォルト」 や 「数字ベース」などを選択し ましょう。 また、 後からパーマリンクの設定を変更し てしまうと、これまでに投稿していたWebページの URLが変更されてしまい、ほかの場所でURLを紹介 していたり、リンクを張られていたりした際にアクセ スできなくなってしまいます。 パーマリンクは必ず最 初に設定しておきましょう。

![](upload/パーマリンク設定.png)

### パーマリンク変更

右サイドのURLをクリックして、ダイアログのパーマリンクの入力値を変更します。
<div markdown="1" class="d-flex">
![](upload/パーマリンク変更前.png)![](upload/パーマリンク変更後.png)
</div>

## 権限の種類について

参考サイト
: [【WordPressのユーザー権限】5種類の権限がそれぞれできること、カスタム方法を解説](https://www.conoha.jp/lets-wp/wp-role/#wp-role_administrator)

### 投稿者ユーザー登録方法

メニューの「ユーザー」-「新規追加」をクリックします。
![](upload/ユーザー新規追加メニュー.png)

ユーザー名、パスワードなどを記入して、「新規ユーザーを追加」ボタンを押します。
![](upload/ユーザー名、パスワードなどを記入.png)

権限が投稿者としてリストに追加されました。
![](upload/佐藤二郎で投稿者として登録.png)

このユーザー名でログインすると、次の投稿者用画面が表示されます。
![](upload/投稿者用管理画面.png "図　投稿者用管理画面")


## 投稿日の表示と取得

`while ( have_posts() ) : the_post();`でループした時、投稿日を表示と取得する方法です。

### 表示
下記を記述すると、echoを付けなくても年月日が表示されます。
```
the_time('Y/n/j'); //例)2023/05/31
the_time('Y年n月j日'); //例)2023年05月31日
```

```
the_date('Y/n/j'); //例)2023/05/31
the_date('Y年n月j日'); //例)2023年05月31日
```
the_date()の方は、同一の年月日があると一つ目だけ表示され、後の同一日は表示されないらしい。

### 取得

「get_」を頭につけると、値を取得できます。
```
$date = get_the_time('Y/n/j');
$date = get_the_date('Y/n/j');
```

### 年度に変換

```
$date = get_the_date('Y/n/j');//投稿日を取得 例)投稿日が2023/3/31の場合
$now = new DateTime($date);//DateTimeオブジェクトに変換
$now->modify("-3month");//3ヶ月分減算
echo $now->format("Y/m/d");//例)2022/12/31
echo $now->format("Y");//例)2022
```

## 複数の投稿ページを設定

参考サイト
: [WordPress (ワードプレス)で複数の投稿ページを設定しよう！やり方を解説！](https://cms-hikaku-navi.com/column/4081/)
: [【WordPress】複数の投稿タイプの一覧をまとめて表示する方法【固定ページを使います】](https://gokansoichiro.com/blog/postlist_paged/)

## ブロックパターン

参考サイト
: [ja.wordpress.org ](https://ja.wordpress.org/patterns/categories/featured/?curation=community)