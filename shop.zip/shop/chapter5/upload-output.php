<?php require '../header.php'; ?>
<?php
//入力画面からアップロードされたファイルかどうか調べる
if (is_uploaded_file($_FILES['file']['tmp_name'])) {
	//フォルダが存在するか調べる。「!」は否定の意味
	if (!file_exists('upload')) {
		//フォルダを作成する。
		mkdir('upload');
	}
	//保存先のファイルのパスを変数に取得。
	$file='upload/'.basename($_FILES['file']['name']);
/*	
	echo $file;//追加
	$file_tmp='upload/'.$_FILES['file']['tmp_name'];//一時的保存ファイル
	echo $file_tmp;//追加
*/	
	
	//一時的なファイルを保存先のフォルダに保存する。
	if (move_uploaded_file($_FILES['file']['tmp_name'], $file)) {
		echo $file, 'のアップロードに成功しました。';
		echo '<p><img src="', $file, '"></p>';
	} else {
		echo 'アップロードに失敗しました。';
	}
} else {
	echo 'ファイルを選択してください。';
}
?>
<?php require '../footer.php'; ?>
