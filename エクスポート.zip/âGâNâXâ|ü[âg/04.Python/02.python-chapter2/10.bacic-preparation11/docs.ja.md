---
title: 10.オブジェクト指向プログラミング
taxonomy:
    category:
        - docs
visible: true
---

オブジェクト指向とは、プログラミングを効率的に行うための考え方の一つです。関連が深いデータと操作をまとめて、「オブジェクト」という部品にすることによって、プログラミングの構造を整理します。<br>
オブジェクト指向プログラミングの基本となるのは、「<span class="bold red">クラス</span>」と「<span class="bold red">インスタンス</span>」という概念です。クラスは、データと操作をまとめた構造の定義です。Pythonでは、データはデータ属性、操作はメソッドで表現します。<br>
クラスで定義した構造を、実際にメモリ上に生成したものがインスタンスです。インスタンスのことをオブジェクトと呼ぶこともあります。

<p class="indent-01">※Pythonはオブジェクト指向プログラミングのための文法を用意していますが、複雑な文法は避けて、できるだけシンプルな形で提供しています。
    Pythonを使ったプログラミングにおいては、オブジェクト指向に頼る度合いはそれほど大きくなく、むしろ各種のデータ構造（<span class="bold blue">リスト</span>、<span class="bold blue">タプル</span>、<span class="bold blue">集合</span>、<span class="bold blue">辞書</span>など）を適切に使いこなすことの方が、効率よくプログラミングを進めるために重要です。</p>
    
<p class="tmp"><span>書式1</span>クラスの定義</p>

	class クラス名:

<p class="list-title">スタイルガイドで推奨されているクラスの命名規則</p>

+ 半角の英文字（小文字および大文字）を使用する
+ クラス名の2文字目以降には、半角の数字を使用することもある
+ 英単語の区切りは、各単語の先頭を英大文字にすることで示す　

<p class="tmp"><span>書式2</span>メソッドの定義 ～ クラスの内側はインデントをして記述します。</p>

    class クラス名:
        def メソッド名(self, 引数, …):
            処理


<p class="indent-01">※メソッドは関数と同様にdefキーワードで定義します。クラスの内側にメソッドを定義します。メソッドの最初の引数は、selfという名前に
することが推奨されています。この変数selfには、メソッドの操作対象となるインスタンスが入ります。</p>

<h3 class="h-type3">なぜクラスには関数ではなく、メソッドを使うのか?</h3>

<p class="pre-title">例) </p>
<pre>
<span class="bold">関数の場合</span>    　<span class="bold blue">buy</span>(customer,'carrot')
<span class="bold">メソッドの場合</span>　customer<span class="bold blue">.buy</span>('carrot')
</pre>

buy関数の場合、例えば「店が仕入れする処理」に「buy」という名前を使ってると、「顧客が買い物をする処理」には「buy」以外の名前を
使わないといけません。

<p class="pre-title">buyメソッドを使用した場合</p>

    customer.buy('carrot')　# 顧客が買い物をする処理
    shop.buy('radish')　　　# 店が仕入れする処理


というように呼び出しに用いるオブジェクトによって、区別することができます。
このように、関数ではなくメソッドを使うのは、名前の衝突を避けるためです。

おまけ<br>
pass文を使うと、空のクラスを定義することができます。

<p class="tmp"><span>書式3</span>空のクラスの定義</p>

    class クラス名:
        pass


<p class="editpre"><span>テキストエディタ</span>例) プレイヤーを表すPlayerクラスを定義します。</p>

    class Player:　　　　　　　　　　　　# Playerクラスの定義
        def display(self):　　　　　　　 # displayメソッドの定義
            print('Name :', self.name)　　　   # 名前の表示
            print('Level:', self.level)　　　  # レベルの表示

<h3 class="h-type3">インスタンスの生成</h3>

インスタンスの生成とは ～ クラスで定義したデータ属性を保存するためのメモリを確保し、データ属性の地を書き込むことです。

インスタンスは次のように生成します。クラスのインスタンスを生成し、変数に代入します。

<p class="tmp"><span>書式4</span>インスタンスの生成</p>

	変数 = クラス名()


インスタンスに属するデータのことを、データ属性と呼びます。<br>
データ属性を保存するための領域は、各インスタンス用のメモリ領域内に確保されます。<br>
データ属性を参照するには、次のように書きます。

<p class="tmp"><span>書式5</span>データ属性の参照</p>

	変数.データ属性名


<p class="tmp"><span>書式6</span>データ属性の変更</p>

	変数.データ属性名 = 値


<p class="tmp"><span>書式7</span>メソッドの呼び出し</p>

	変数.メソッド名(引数, …)


<div class="box-example">
    <h3 class="h-example">例1</h3>
	Playerクラスのインスタンスを生成し、データ属性を設定    
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:　　　　　　　　　　　　# Playerクラスの定義
        def display(self):　　　　　　　 # displayメソッドの定義
        print('Name :', self.name)　　　 # 名前の表示
        print('Level:', self.level)　　　# レベルの表示

    p1 = Player()　　　　　# インスタンスの生成
    p1.name = 'Daikon'　　 # 名前を設定
    p1.level = 1　　　　　 # レベルを設定
    p1.display()　　　　　 # 名前とレベルの表示

    p2 = Player()
    p2.name = 'Ninjin'
    p2.level = 2
    p2.display()


<p class="result">実行結果</p>

    Name : Daikon
    Level: 1
    Name : Ninjin
    Level: 2


※Pythonでは、インスタンスのデータ属性を、クラスの内側でも外側でも定義することができます。

<dl>
    <dt>__init_メソッド</dt>
    <dd>このメソッドを定義すると、インスタンスを生成する際に、同時にデータ属性を設定することができます。</dd>
</dl>

<p class="tmp"><span>書式8</span>__init__メソッドの定義</p>

	class クラス名
        def __init__(self, 引数, …):
            self.データ属性名 =　値


<p class="tmp"><span>書式9</span>__init__メソッドを使ったインスタンスの生成</p>

	変数 = クラス名(引数, …)


<div class="box-example">
    <h3 class="h-example">例2</h3>
	__init__メソッドを定義したPlayerクラスを使って、インスタンスを生成
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        def __init__(self, name, level):　　　　# __init__メソッドの定義
            self.name = name　　　　　　　　　　
            self.level = level

        def display(self):　　　　　　　　　　 # displayメソッドは前回と同じ
            print('Name :', self.name)
            print('Level :', self.level)

    p1 = Player('Daikon', 1)                   # インスタンスの生成とデータ属性の設定
    p1.display()　　　　　　　　　　　　　　　 # 名前とレベルの表示</span>

    p2 = Player('Ninjin', 2)                   # インスタンスの生成とデータ属性の設定
    p2.display()　　　　　　　　　　　　　　　 # 名前とレベルの表示</span>



<p class="result">実行結果</p>

    Name : Daikon
    Level: 1
    Name : Ninjin
    Level: 2



<div class="box-example">
    <h3 class="h-example">例3</h3>
	クラスには、複数のデータ属性やメソッドを持たせることができます。
</div>
<p class="editpre"><span>テキストエディタ</span>メソッドの追加</p>

    class Player:
        def __init__(self, name, level):
            self.name = name
            self.level = level

        def display(self):
            print('Name :', self.name)
            print('Level:', self.level)

        def level_up(self, number):
            self.level += number


    p1 = Player('Daikon', 1)       # name='Daikon', level=1
    p1.level_up(2)　　　　　　　　 # number=2 → level=1+2=3
    p1.display()                   # nameとlevel結果表示


<p class="result">実行結果</p>

    Name : Daikon
    Level: 3



<h2 class="h-type2">マングリング</h2>

一般にメソッドはクラスの外部からでも呼び出せますが、ときにはクラスの内部だけで使うメソッドを定義したいことがあります。
そのメソッドを定義することによって、クラス内部の処理が実装しやすくなるけれども、外部に公開するほどの機能はない、というような場合です。

<dl>
    <dt>マングリングとは</dt>
    <dd>２個のアンダーバー「__」から始まるメソッド名は、自動的に「_クラス名__メソッド名」という名前に変換されます。
これをマングリングといいます。<br>
この機能は、内部だけで使うメソッドを間違って外部から呼んでしまう危険性を減少させます。<br>
__init__も2個のアンダーバーから始まりますが、このように末尾に2個以上のアンダーバーが付くメソッドは、マンドリングされません。</dd>
</dl>

<div class="box-example">
    <h3 class="h-example">例4</h3>
	レベルアップをレベル10までに制限する
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        def __init__(self, name, level):
            self.name = name
            self.level = level

        def display(self):
            print('Name :', self.name)
            print('Level:', self.level)

        def level_up(self, number):
            self.level += number
            self.__check_level()

        def __check_level(self):
            if self.level > 10:　　　# レベルが10を超えると、自動的に10に補正されます
                self.level = 10


    p1 = Player('Daikon', 1)
    p1.level_up(10)
    p1.display()



<p class="result">実行結果</p>

    Name : Daikon
    Level: 10



<p>例えば上記の__check_levelメソッドは、Player_check_levelという名前のメソッドに変換されます。<br>
変換後のPlayer_check_levelというメソッド名を使えば、クラスの外部からでも呼び出すことはできますが、__check_levelという元の名前では
呼び出せないので、うっかり呼び出すことは少なくなります。</p>




<h2 class="h-type2">クラス属性と定数</h2>

<dl>
    <dt>定数</dt>
    <dd>変更しない値のことです。Pythonには定数を定義するための文法はありませんが、以下のような命名規則を使って変数を定義することでプログラマが誤って変更してしまうことを防いでいます。</dd>
</dl>


+ 半角の英大文字を使用する。
+ 変数名の2文字目以降には、半角の数字を使用することもある。
+ 英単語の区切りはアンダーバーで示す。

※複数のインスタンスで共通に使う変数や定数を定義する場合には、クラス属性にするのがいいです。

<p class="tmp"><span>書式10</span>クラス属性の定義</p>

	変数 = クラス名(引数, …)
    class クラス名
        クラス属性名 = 値


<p class="tmp"><span>書式11</span>クラス属性の参照</p>

	クラス名.クラス属性名


<p class="tmp"><span>書式12</span>クラス属性の変更</p>

	クラス名.クラス属性名 = 値


<p class="tmp"><span>書式13</span>クラスの内側からクラス属性を参照</p>

    self.クラス属性名


<p class="tmp"><span>書式14</span>クラスの外側から、クラス属性参照を行うには次のようにも書けます</p>

    self.クラス属性名
	変数名.クラス属性名



<div class="box-example">
    <h3 class="h-example">例5</h3>
	Playerクラスにおいて、レベルの上限値をクラス属性LEVEL_LIMITで表現してみます
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        LEVEL_LIMIT = 10

        def __init__(self, name, level):
            self.name = name
            self.level = level

        def display(self):
            print('Name :', self.name)
            print('Level:', self.level)

        def level_up(self, number):
            self.level += number
            self.__check_level()

        def __check_level(self):
            if self.level > Player.LEVEL_LIMIT:
                self.level = Player.LEVEL_LIMIT


    p1 = Player('Daikon', 1)
    p1.level_up(10)
    p1.display()



<p class="result">実行結果</p>

    Name : Daikon
    Level: 10



<h2 class="h-type2">継承</h2>

既存のクラスを拡張して、新しいクラスを定義することができます。このとき新しいクラスは、既存のクラスが持つすべての機能（データ属性およびメソッド）を引き継ぎます。この性質のことを「<span class="red bold">継承</span>」といいます。<br>
また、このときの既存のクラスを「<span class="red bold">基底クラス</span>」、新しいクラスを「<span class="red bold">派生クラス</span>」といいます。

<p class="tmp"><span>書式15</span>派生クラスの定義</p>

    class 派生クラス名(基底クラス名)
        メソッドや変数の定義    



<div class="box-example">
    <h3 class="h-example">例6</h3>
	Playerクラスを基底クラスにして、FighterクラスとWizardクラスを定義してみます。
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:
        LEVEL_LIMIT = 10

        def __init__(self, name, level):
            self.name = name
            self.level = level

        def display(self):
            print('Name :', self.name)
            print('Level:', self.level)

        def level_up(self, number):
            self.level += number
            self.__check_level()

        def __check_level(self):
            if self.level > Player.LEVEL_LIMIT:
                self.level = Player.LEVEL_LIMIT


    class Fighter(Player):　　　　　　　　　　　　　# Fighterクラスの定義
        def __init__(self, name, level, sword):     # __init__メソッドの定義（オーバーライド）
            Player.__init__(self, name, level)　　　# Playerクラスの__init__メソッドを呼び出す
            self.sword = sword　　　　　　　　　　　# データ属性swordの設定</span>

        def display(self):　　　　　　　　　　　　　# displayメソッドの定義（オーバーライド）
            Player.display(self)　　　　　　　　　　# Playerクラスのdisplayメソッドを呼び出す
            print('Sword:', self.sword)　　　　　　 # データ属性swordの表示</span>

        def slash(self):　　　　　　　　　　　　　　# Fighterクラスに特有のslashメソッド
            print('Slashing!')


    class Wizard(Player):　　　　　　　　　　　　　# Wizardクラスの定義
        def __init__(self, name, level, wand):     # __init__メソッドの定義（オーバーライド）
            Player.__init__(self, name, level)　　 # Playerクラスの__init__メソッドを呼び出す
            self.wand = wand　　　　　　　　　　　 # データ属性wandの設定

        def display(self):　　　　　　　　　　　　# displayメソッドの定義（オーバーライド）
            Player.display(self)　　　　　　　　　# Playerクラスのdisplayメソッドを呼び出す
            print('Wand :', self.wand)　　　　　　# データ属性wandの表示

        def magic(self):　　　　　　　　　　　　　# Wizardクラスに特有のmagicメソッド
            print('Casting a magic!')


    f = Fighter('Daikon', 1, 'iron')              # Fighterインスタンスの生成
    f.display()　　　　　　　　　　　　　　　　　 # displayメソッドの呼び出し
    f.slash()                               　　　# slashメソッドの呼び出し

    w = Wizard('Ninjin', 2, 'wood')              # Wizardインスタンスの生成
    w.display()　　　　　　　　　　　　　　　　　# displayメソッドの呼び出し
    w.magic()                               　　 # magicメソッドの呼び出し



<p class="result">実行結果</p>

    Name : Daikon
    Level: 1
    Sword: iron　　　　　# Fighterクラスのdisplayメソッドによる表示
    Slashing!            # Fighterクラスのslashメソッドによる表示 
    Name : Ninjin
    Level: 2
    Wand : wood　　　　　# Wizardクラスのdisplayメソッドによる表示
    Casting a magic!     # Wizardクラスのmagicメソッドによる表示



<dl>
    <dt>オーバーライド</dt>
    <dd>基底クラスにあるメソッドを派生クラスで再定義すること。<br>
オブジェクト指向プログラミングにおいてオーバーライド (override) とは、スーパークラスで定義されたメソッドをサブクラスで定義し直し、動作を上書き（変更）することである。 </dd>
</dl>
 
<p class="tmp"><span>書式16</span>基底クラスのメソッド呼び出し</p>

	基底クラス.メソッド名(self, 引数, …)


またはsuper関数を使って、下記のように書くこともできます。

<p class="tmp"><span>書式17</span>基底クラスのメソッド呼び出し</p>

	super().メソッド名(self, 引数, …)




<dl>
    <dt>多重継承</dt>
    <dd>複数の基底クラスから機能を継承することをいいます。利用することで、複数のクラスの機能を合わせ持ったクラスを作ることができます。（1つの基底クラスから機能を継承することを、単一継承と呼びます。）</dd>
</dl>

<p class="tmp"><span>書式18</span>複数の基底クラスを持つ派生クラスの定義</p>

class 派生クラス名(基底クラス名, 基底クラス名, …):


<div class="box-example">
    <h3 class="h-example">例7</h3>

</div>
<p class="editpre"><span>テキストエディタ</span></p>

    class Player:　　　　　　　　　　　# Playerクラスの定義
        LEVEL_LIMIT = 10

        def __init__(self, name, level):  # Wizardクラスのmagicメソッドによる表示
            self.name = name
            self.level = level

        def display(self):
            print('Name :', self.name)
            print('Level:', self.level)

        def level_up(self, number):
            self.level += number
            self.__check_level()

        def __check_level(self):
            if self.level > Player.LEVEL_LIMIT:
                self.level = Player.LEVEL_LIMIT


    class Fighter(Player):　　　　　　　　　　　　# Fighterクラスの定義
        def __init__(self, name, level, sword):
            Player.__init__(self, name, level)
            self.sword = sword

        def display(self):
            Player.display()
            print('Sword:', self.sword)

        def slash(self):
            print('Slashing!')


    class Wizard(Player):　　　　　　　　　　　　# Wizardクラスの定義
        def __init__(self, name, level, wand):
            Player.__init__(self, name, level)
            self.wand = wand

        def display(self):
            Player.display(self)
            print('Wand :', self.wand)

        def magic(self):
            print('Casting a magic!')


    class MagicKnight(Fighter, Wizard):　　　　　　　　# MagicKnightクラスの定義
        def __init__(self, name, level, sword, wand):　# __init__メソッドの定義

            Player.__init__(self, name, level)　　　　 # Playeクラスの__init__メソッドを呼び出す
            self.sword = sword　　　　　　　　　　　　 # データ属性swordの初期化
            self.wand = wand  　　　　　　　　　　　　 # データ属性wandの初期化

        def display(self):　　　　　　　　　　　　　　 # displayメソッドの定義（オーバーライド）
            Player.display(self)　　　　　　　　　　　 # Playeクラスのdisplayメソッドを呼び出す
            print('Sword:', self.sword)　　　　　　　　# データ属性swordの表示
            print('Wand :', self.wand) 　　　　　　　　# データ属性wandの表示


    mk = MagicKnight('Gobou', 3, 'silver', 'glass')
    mk.display()
    mk.slash()  　　　　　　　　　　　　　　　　　　　 # Fighterクラスから継承したslashメソッドの呼び出し
    mk.magic()  　　　　　　　　　　　　　　　　　　　 # Wizardクラスから継承したmagicメソッドの呼び出し

<p class="result">実行結果</p>

    Name : Gobou
    Level: 3
    Sword: silver
    Wand : glass
    Slashing!             # Fighterクラスから継承したslashメソッドによる表示
    Casting a magic!　　　# Wizardクラスから継承したmagicメソッドによる表示


<h2 class="h-type2">例外処理</h2>

例外はプログラムの実行中に起こるエラーです。例外が発生すると、プログラムはエラーメッセージを表示して終了します。ただし、<span class="red bold">例外処理</span>を記述しておけば、エラー発生後もプログラムの実行を継続することができます。

<h3 class="h-type3">例外処理の書き方</h3>

<p class="tmp"><span>書式19</span>try文とexcept節</p>

	try:
        処理A
    except 例外名
        処理B


※except節は複数並べることができます。どの例外名とも一致しない場合には、エラーメッセージを表示してプログラムは終了します。

<p class="tmp"><span>書式20</span>複数のexcept節</p>

    except 例外名:
        処理
    except 例外名:
        処理

※次のように書くと、1つのexcept節で複数種類の例外を処理することができます。

<p class="tmp"><span>書式21</span>複数の例外を処理するexcept節</p>

except (例外名, 例外名, …):


<div class="box-example">
    <h3 class="h-example">例8</h3>
	リストに格納されたデータの合計値を求めるのに、文字列は処理せずに数値の合計だけを求める
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    number = ['1', '2', 'three', '4']
    sum = 0
    for n in number:　　　# リストから値を取り出す
        sum += int(n)　　 # 値を数値に変換して合計する
    print(sum)

<p class="result">実行結果</p>

    Traceback (most recent call last):
      File "try1.py", line 4, in <module>
        sum += int(n)
    ValueError: invalid literal for int() with base 10: 'three'

※ValueErrorという例外が発生しました。プログラムの4行目で、int関数を使って'three'という文字列を数値に変換しようとしたことが原因です。


try文を使って次のようにプログラムを修正します。

<div class="box-example">
    <h3 class="h-example">例9</h3>
	ValueErrorが発生したときには、pass文を使ってスルーさせます
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    number = ['1', '2', 'three', '4']
    sum = 0
    for n in number:
        try:
            sum += int(n)
        except ValueError:        //ValueErrorが起きたときの処理
            pass　　　　　　　　　//何もしない
    print(sum)

<p class="result">実行結果</p>

	7

<p class="tmp"><span>書式22</span>else節とfinally節</p>

    try:
        処理A
    except 例外名:
        処理B
    else:
        処理C
    finally:
        処理D

解説) 最初にtry節の処理Aを実行します。処理Aの実行中に例外が発生した場合、エラーメッセージを発信して処理Aの実行を中断します。<br>
　　　もし発生した例外がexcpt節の例外名に一致していたら、処理Bを実行します。<br>
      例外が発生しなかったら、処理Cを実行します。<br>
　　　例外が発生してもしなくても、最後に処理Dを実行します。　

<div class="box-example">
    <h3 class="h-example">例10</h3>
	
</div>
<p class="editpre"><span>テキストエディタ</span></p>

    try:
        print('try')
        int(123)          # 文字列'123'を数値に変換する
    except ValueError:
        print('except')
    else:
        print('else')
    finally:
        print('finally')

<p class="tmp"><span>書式23</span>else節とfinally節</p>

    try
    else
    finally

<p class="indent-01">※文字列'123'を数値に変換しても、例外は発生しません。そのため、try→else→fanallyの順で実行します。
int(123)をint('abc')に書き換えると、try→except→fanallyの順で実行します。</p>


※ValueErrorは、演算子や関数に対して与えられた値の型は適切だが、値の内容が不適切なときに発生する例外です。












