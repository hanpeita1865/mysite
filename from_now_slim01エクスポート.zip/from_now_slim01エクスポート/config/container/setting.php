<?php
return function ($container) {
    $container->set('config', function () {
        return [
            'app_env' => $_ENV['APP_ENV'] ?? 'production',
            'displayErrorDetails' => $_ENV['APP_DEBUG'] === 'true',
            'basePath' => $_ENV['BASE_PATH'],
            'siteName' => $_ENV['SITE_NAME'],
            'db' => [
                'host' => $_ENV['DB_HOST'] ?? 'localhost',
                'port' => $_ENV['DB_PORT'] ?? '3306',
                'dbname' => $_ENV['DB_NAME'] ?? '',
                'user' => $_ENV['DB_USER'] ?? '',
                'pass' => $_ENV['DB_PASS'] ?? '',
            ],
        ];
    });
};