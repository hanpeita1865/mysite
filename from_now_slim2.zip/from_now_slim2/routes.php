<?php
use Psr\Http\Message\ServerRequestInterface;//テスト
use Psr\Http\Message\ResponseInterface;//テスト

use SocymSlim\SlimMiddle\controllers\SlimMiddleController;

use SocymSlim\SlimMiddle\controllers\MemberController;
use SocymSlim\SlimMiddle\middlewares\UserCheck;

$app->setBasePath("/from_now_slim2/public");


//管理画面
$app->any("/pages/{folderName}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/", MemberController::class.":markData");//from_now マークダウン変換
$app->any("/pages/{folderName}/{folderName1}/{folderName2}/{folderName3}/{folderName4}/{folderName5}/", MemberController::class.":markData");//from_now マークダウン変換
