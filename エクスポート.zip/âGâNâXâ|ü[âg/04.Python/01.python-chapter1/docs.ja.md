---
title: インストールと実行方法
media_order: 'cmd_01.png,cmd_02.png,cmd_03.png,cmd_04.png,cmd_05.png,cmd_06.png,dir_01.png,dir_02.png,dir_03.png,dir_04.png,pycode1.png,pycode2.png,inst_01.png,inst_02.png,inst_03.png,Releases.png,windows.png,x86-64-executable.png,Python3.8.0.png'
taxonomy:
    category:
        - docs
visible: true
---

<!--
<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: blue;}
    .smp-box {
         margin: 2rem 0 3rem;
    }

    .dcn {
     font-weight: bold;   
    }
    .gray-box {
     	border: 1px solid gray;
        padding: 20px 30px;
        display: inline-block;
    }
    .w-400 {
      	width: 400px;
     }

    h3 span {
      border-bottom: 3px solid green;   
    }
    h4 {margin-top: 3rem;}

</style>
-->

Pythonを実行するには、お使いのパソコンにPythonの実行環境をインストールする必要があります。<br>
ここでは、「Python 3」を使って説明していきますので、バージョン番号が「3」からはじまる最新バージョンをインストールしてください。


<h2 class="h-type2">WindowsにPythonをインストールする</h2>

<dl>
    <dt>Python公式サイト</dt>
    <dd><a href="https://www.python.org/" alt="">https://www.python.org/</a></dd>
</dl>


<h3 class="h-type3">Python 3（64bit版）を入手する</h3>

1. 上記の公式サイトを開き、メニューの「Downloads」の「Windows」をクリックしてください。

![](windows.png)

2. 下記のページが開いたら、少し下の方までスクロールしてください。
![](Releases.png)

3. そうすると、「Windows x86-64 executable installer」（この時点ではPython 3.8.0が最新）というリンクがありますので、それをクリックしてダウンロードしてください。
![](x86-64-executable.png)

<h3 class="h-type3">Python 3をインストールする</h3>

ダウンロードした実行ファイル（python.3….exe）をダブルクリックして、次の手順を実行します。

1. 「Add Python 3.x to PATH」にチェックを入れて、「Install Now」をクリックします。

<!--![](inst_02.png "")-->
![](Python3.8.0.png)


2. インストールが完了すると、下記の画面が表示されるので、「Close」をクリックします。

![](inst_03.png "") 

<h2 class="h-type2">インタプリタを起動して実行</h2>

コマンドプロンプトを開き、pythonと入力しエンターキーを押す。

![](cmd_01.png "") 

→Pythonのインタブリタが起動し、画面上に「>>>」が表示される。

![](cmd_02.png "") 

「1+2」と入力して、ENTERキーをを押すと、実行結果として「3」が表示される。

![](cmd_04.png "") 

Pythonインタプリタを終了するには、CTRLキー + Zキーを押し、画面に「^Z」と表示されたら、ENTERキーを押す。

![](cmd_06.png "") 

<h2 class="h-type2">ファイルに保存し実行する方法</h2>

例）<br>
<span class="bold">C:&yen;xampp&yen;htdocs&yen;テンプレートサンプル&yen;★Python&yen;練習&yen;チャプター2&yen;<span class="red">test.py</span></span> のファイルを実行します。

<p class="mb-05">（<span class="bold red">test.py</span>のコード）</p>
<pre>
print('1')  <span class="comment"># 「1」と表示します。</span>
print('2')  <span class="comment"># 「2」と表示します。</span>
</pre>

※「#」を書くと、そこから行末までがコメントになります。

1.　ファイルを置いているディレクトリを入力  

	cd ディレクトリ
    
![](dir_01.png "") 

2.　ENTERキーを押してディレクトリ変更
![](dir_02.png "") 

3.　ファイル名を入力して、ENTERキーを押し実行
![](dir_03.png "") 

4.　test.py 実行結果
![](dir_04.png "") 

<h2 class="h-type2">スタイルガイド「PEP8」に準拠して書く</h2>

PEP8は「読みやすいPythonプログラム」を書くために考えられたガイドです。Pythonの標準ライブラリなどで採用されています。なお、スタイルガイドの利用は強制ではありません。<br>
作成したプログラムがPEP8に準拠しているかをチェックするには「<span class="bold red">pycodestyle</span>」というツールを使用します。<br>


pycodestyleをインストールするには、コマンドプロンプトに以下のコマンドを入力します。
<pre>
pip install pycodestyle
</pre>

コマンドの実行後に「Successfully installed pycodestyle ～」と表示れたら、インストールは成功です。<br>
MacOSの場合は、「pip」の代わりに「pip3」と入力してください。


書いたプログラムがPEP8に準拠しているか否かをチェックするには、以下のコマンドを実行します。

<p class="tmp"><span>書式</span>pycodestyleの使い方</p>
<pre>
pycodestyle ファイル名
</pre>

<p class="mb-05 bold">例)</p>
<pre>
print('1')#「1」と表示します。
print('2')#「2」と表示します。
</pre>

このようにコードを書いてスタイルガイドをチェックすると、下記のように修正点が表示されます。
![](pycode1.png "") 


<p class="mb-05 bold">スタイルガイドに準拠した書き方</p>
<pre>
print('1')  # 「1」と表示します。
print('2')  # 「2」と表示します。
</pre>
・プログラムと同じ行にあるコメントは、「#」の前に半角スペース2つ入れ、後ろにも1ついれる。<br>
・最後の行は、改行する。

コードを修正してもう一度チェックにかけると、下記のように修正点が消えています。
![](pycode2.png "") 

※pycodestyleは必須ではありません。しっかりと文法を理解して、思い通りプログラムが書けるようになってからコーティングスタイルを学ぶのもお勧めです。






