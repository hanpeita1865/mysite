*[page-title]:正規表現

## よく使用する記号

### 特別な意味を表す文字パターン

* 「.」何らかの1文字
* 「\w」大文字小文字を含む英数字とアンダースコア
* 「\d」0〜9の数字
* 「\s」タブ、改行、スペース


### 繰り返しを表すパターン

* 「*」0文字以上の繰り返し
* 「+」1文字以上の繰り返し
* 「?」1文字が「ある」か「ない」か
* 「{}」繰り返す回数を指定


### 文字の位置を表すパターン

* 「^」行の先頭
* 「$」行の末尾

<div class="exp">
	<p class="tmp"><span>例</span></p>
	「"flex-box"」の先頭の「"」を削除のパターンと末尾の「"」を削除のパターンとをそれぞれ置換で行っています。
</div>
<script async src="//jsfiddle.net/cfpq8uhn/2/embed/js,result/"></script>


### 任意の文字列を表すパターン


* 「[ ]」一連の文字セットを表す
* 「( )」文字パターンをグループ化する

<div class="exp">
	<p class="tmp"><span>例</span></p>
「**{c:red}/<[ap]>/{/c}**」と書くと、「<a>」「<p>」のどちらかにマッチするパターンになります。

「**{c:red}/<(a|p|div)>/{/c}**」と書くと、「<a>」「<p>」「<div>」のどれかにマッチするパターンになります。
</div>



正規表現を試せるWebサービス
: [https://regex101.com/](https://regex101.com/)


## エスケープ処理を行う

正規表現でエスケープ処理を行うのに必要なのは「\ (バックスラッシュ)」になります。

<div class="exp">
	<p class="tmp"><span>例</span></p>
正規表現の世界で「.（ドット）」はどんな文字でも検出するというルールがあります。
その「.」をエスケープして、通常の文字「.（ドット）」を意味するようにします。

「/www<span class="red bold">\</span>.nikkansports<span class="red bold">\</span>.com/」
</div>


## 正規表現に変数を使用する

```
hoge.test(/abc/);
```
とするけどabcの部分は変数ではなくてStringとして認識されてしまうので

```
var abc = "efg";
hoge.test(/abc/);
```
としてもefgを検索してくれない。  
そこで、変数を入れたい場合は正規表現オブジェクトを使います。

### 正規表現オブジェクト

<p class="tmp"><span>書式1</span>RegExp</p>
```
regexp = new RegExp(patern[, flags])
```

<iframe width="100%" height="200" src="//jsfiddle.net/gbh7a4dx/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

細かい検索条件も設定可能です。

<iframe width="100%" height="200" src="//jsfiddle.net/0gm2spyx/3/embedded/js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>



new RegExp() の代わりに、次のように生成することもできます。

<p class="tmp"><span>書式2</span></p>
```
regexp = /pattern/flags
```

<script async src="//jsfiddle.net/7uwczqk1/embed/js,result/"></script>

変数を使用して検索と置換

<script async src="//jsfiddle.net/Lxd32eyo/1/embed/js,result/"></script>


### 正規表現のマッチング表現

※ **[**指定パターン**]**　対象となる文字のパターンを指定する

|正規表現|意味|
|:--:|--|
|x|	xという文字。|
|xyz|	x, y, z がこの順番で出現する場合にマッチ。|
|[xyz]|	x、y、zのいずれか1文字。|
|[x-z]|	x～zまでのいずれか1文字。|
|[^xyz]|	x、y、zのいずれでもない任意の1文字|

## 複数の文字列のいずれかにマッチ（OR）

メタ文字のひとつである縦棒(|)は複数の文字列のいずれか一つに一致する文字列にマッチします。文字列の候補を縦棒(|)で区切って記述します。

<p class="tmp"><span>書式</span></p>
```
文字列|文字列|...
```

<script async src="//jsfiddle.net/hus9j82d/embed/js,result/"></script>

## HTMLタグを除去する

正規表現を使ったHTMLタグ除去にreplace()関数を利用します。  
replace()関数は元の変数にある値を書き換えず、返り値として結果を返します。

<p class="tmp"><span>書式</span></p>
```
text.replace(/(<([^>]+)>)/gi, '');
```

textに代入したHTMLを含む文字列からHTMLタグのみを除去します。

<script async src="//jsfiddle.net/bzcwd8t0/1/embed/js,result/"></script>

HTMLタグの入れ子構造、複数行でも機能します。

<script async src="//jsfiddle.net/wogmt9fc/embed/js,result/"></script>

## HTMLタグで分割して、配列にする

<p class="tmp"><span>書式</span></p>
```
string.split(/(<[^>]*>)/)
```

<script async src="//jsfiddle.net/nyot1uL2/embed/js,result/"></script>


## フラグ

RegExp() の第2引数や /.../ の後ろに記述する i、g、m などのフラグは下記のような意味を持ちます。i と g の両方を指定する時は ig と指定します。


|フラグ	|フラグ名	|意味|
|--|--|--|
|g	|global	|2番目、3番目... にマッチする部分も検索する|
|i	|ignoreCase	|大文字・小文字を区別しない|
|m	|multiline	|複数行に対して検索する|

g フラグを指定すると最初にマッチした部分に加え、2番目、3番目...にマッチした部分も配列として返します。


<script async src="//jsfiddle.net/hirao/bs9a05z3/2/embed/js,result/"></script>

g フラグによるマッチングは、lastIndex 番目以降の文字に対して行われます。下記の様に、ループ処理することも可能です。

<script async src="//jsfiddle.net/hirao/kfhrs5md/2/embed/js,result/"></script>

i フラグを指定すると大文字小文字を区別しなくなります。

```
"abc".match(/ABC/)     // マッチしない
"abc".match(/ABC/i)    // マッチする;
```

m を指定すると、行頭（^）や行末（$）のマッチングが文字列の先頭・末尾だけではなく、各行の行頭・行末にもマッチするようになります。

```
"123\n456\n789".match(/^456/)        // マッチしない
"123\n456\n789".match(/^456/m)       // マッチする
```

y を指定すると、lastIndex の位置からから先頭マッチングします。

<script async src="//jsfiddle.net/hirao/6h0m51e9/1/embed/js,result/"></script>


## 特定のパターン以外の文字列の正規表現

### 指定した文字を含まない  
`[]`を使って書くことができます。

```
例）
[正規表現]
[^ABCDEF]

[マッチする例]
G
HIJ
```

### 指定した文字列を含まない1行を検索する
```
^(?!.*文字列).+$
```
上記の文字列の箇所に指定した文字（文字列）を含まない1行を検索出来ます。

```
例）
^(?!.*ABC).+$
「ABC」という文字列を含まない行を検索します。
```

### 指定した複数の文字列を含まない1行を検索する
```
^(?!.*(文字列|文字列)).+$
```
文字列を|（パイプ）で繋げることで、複数の文字列を除外することが出来ます。
```
例）
^(?!.*(ABC|XYZ)).+$
「ABC」または、「XYZ」という文字列を含まない行を検索します。
```

### 指定した文字列から開始しない1行を検索する
```
^(?!文字列).+$
```
文字列の部分から開始しない行を検索することが出来ます。

```
例）
^(?!ABC).+$
「ABC」という文字列から始まらない行を検索します。
```

### 指定した文字列で終わらない1行を検索する
```
^(?!.*文字列$).+$
```
文字列で終了しない行を検索することが出来ます。
```
例）
^(?!.*ABC$).+$
「ABC」で終了しない行を検索します。
```

### ～は含むが、～は含まない1行を検索する
```
^(?!.*文字列1).*(?=文字列2).*$
```
文字列2は含むが、文字列1は含まない1行を検索することが出来ます。
```
例）
^(?!.*ABC).*(?=XYZ).*$
「XYZ」という文字列を含み、ABCという文字列は含まない行を検索します。
```

## 桁数を範囲指定して数字を検索する

参考サイト
: [桁数を範囲指定して数字を検索する](https://hodade.com/seiki/page.php?s_suuji3)

<p class="tmp"><span>書式</span></p>
```
\d{最小桁数, 最大桁数}
```

<div class="exp" markdown="1">
<p class="tmp"><span>例</span> id="item1～3桁の数字"の文字を検索</p>
```
id="item\d{1,3}"
```
</div>



## 参考サイト

* [正規表現（RegExp）](http://www.tohoho-web.com/js/regexp.htm)
* [JavaScript | 文字列から正規表現でHTMLタグを除去する方法](https://1-notes.com/javascript-strip-html-tags/)
* [【JavaScript】splitでhtmlタグを開始タグ、中身、終了タグで分割したい](https://teratail.com/questions/229587)
* [ WWWクリエイターズ › 開発ブログ › 正規表現 › 正規表現：AND（かつ）の表現方法 正規表現：AND（かつ）の表現方法](https://www-creators.com/archives/5332)
* [正規表現のAND（かつ）条件の書き方はOR（または）条件より複雑！？](https://minory.org/regexp-and.html)
* [正規表現を使って「〜以外」をマッチさせてみる](https://style.potepan.com/articles/9251.html)
* [ WWWクリエイターズ › 開発ブログ › 正規表現 › 正規表現：文字列を「含まない」否定の表現まとめ](https://www-creators.com/archives/1827)
* [正規表現：文字列を「含まない」否定の表現まとめ](https://www-creators.com/archives/1827)
* [【正規表現】記号のみや半角英数記号のみ（初心者向け解説）](https://tabibitojin.com/regular-expression-symbols-alphanumeric/)
* [ファイル名やディレクトリ名に指定できない文字のチェック](https://qiita.com/s_ryota/items/3b2c7b598cc650a089f9)
