//マークダウンと標準の記事の切り替え
$(function () {
	btn_simplemde_def();//デフォルトは標準入力
	btn_simplemde_mark();//マークダウン入力
});


//===========================//
//      標準入力             //
//==========================//

function btn_simplemde_def() {

	var simplemde = new SimpleMDE({
		element: document.getElementById("report"),
		forceSync: true,
		spellChecker: false,
		renderingConfig: {
			singleLineBreaks: false,
			codeSyntaxHighlighting: true,
		},
		toolbar: [
			'fullscreen',
			{
				name: 'font-bold',
				className: 'fa fa-bold-def',
				title: '太字',
			},
			{
				name: 'font-red',
				className: 'fa fa-font fa-red-def',
				title: '赤文字',
			},
			{
				name: 'font-blue',
				className: 'fa fa-font fa-blue-def',
				title: '青文字',
			},
			{
				name: 'font-green',
				className: 'fa fa-font fa-green-def',
				title: '緑文字',
			},
			{
				name: 'font-darkred',
				className: 'fa fa-font fa-darkred-def',
				title: '茶色文字',
			},
			'|',
			{
				name: 'fz',
				className: 'fa fa-fz',
				title: '文字サイズ調整(1.1～2.0rem)',
			},
			'|',
			{
				name: 'link-tag',
				className: 'fa fa-link-def',
				title: 'リンクタグ',
			},
			{
				name: 'span',
				className: 'fa fa-span',
				title: 'spanタグ',
			},
			{
				name: 'br',
				className: 'fa fa-br',
				title: '改行タグ',
			},
			{
				name: 'mgt',
				className: 'fa fa-mgt',
				title: 'マージントップ(1～8rem)',
			},
			'|',
			{
				name: 'list-ul',
				className: 'fa fa-list-ul fa-list-disc',
				title: 'リスト(ul)',
			},
			/*{
				name: 'list-ul-none',
				className: 'fa fa-list-ul fa-list-none',
				title: 'リスト(ul)',
			},*/
			{
				name: 'list-ol',
				className: 'fa fa-list-ol-def',
				title: 'リスト(ol)',
			},
			'|',
			{
				name: 'youtube',
				className: 'fa btn-youtube fa-youtube-def youtube-left',
				title: '動画左寄せ（テキスト回り込みなし）クラス無し',
			},
			'|',
			{
				name: 'youtube',
				className: 'fa btn-youtube fa-youtube-def youtube-center',
				title: '動画中央配置 クラス(mx-auto)',
			},
			'|',
			{
				name: 'youtube',
				className: 'fa btn-youtube fa-youtube-def youtube-float',
				title: 'テキスト右回り込み クラス(float-left)',
			},
			'|',
			{
				name: 'youtube',
				className: 'fa btn-youtube fa-youtube-def youtube-right',
				title: 'テキスト左回り込み クラス(float-right)',
			},
			'|',
		]
	});



	//拡大
	$(".fa-arrows-alt").click(function () {
		console.log('拡大');
		$('a.fa.fa-preview').toggleClass('d-inline-block');
	});

	$('.fa-preview').on('click', function () {
		console.log('実行');
		$('#btn-markpreview').trigger('click');
	});


	//マークダウンテキストエリアに![](img数字)の文字を挿入
	$(".btn-markimg").click(function () {
		var valText = $(this).val();
		var line = simplemde.codemirror.getCursor().line;
		var ch = simplemde.codemirror.getCursor().ch;

		//文字列の挿入
		var text = '![](' + valText + ')';
		simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });

		$(this).hide();
	});

	// //マークダウンにファイルリンクを挿入
	// $('ul').on('click', '.fileInsert', function () {
	// 	//$('.fileInsert').on('click', function(){
	// 	var valText = $(this).siblings('.filename').text();
	// 	var line = simplemde.codemirror.getCursor().line;
	// 	var ch = simplemde.codemirror.getCursor().ch;

	// 	//文字列の挿入
	// 	var text = '<a href="' + valText + '" target="_blank">' + valText + '</a>';
	// 	simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });
	// 	alert('「' + valText + '」 ファイルリンクを記入しました');
	// 	return false;

	// });

	//太字
	$('.fa-bold-def').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/bold/)) {
				var text = selected.replace(regexp, '<span class="$1 bold">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにboldが既にあります。');
			}
		} else {
			var text = '<span class="bold">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});


	//文字の色　赤に変更
	$('.fa-font.fa-red-def').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/text-red/)) {
				var text = selected.replace(regexp, '<span class="$1 text-red">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにtext-redが既にあります。');
			}
		} else {
			var text = '<span class="text-red">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//文字の色　青に変更
	$('.fa-font.fa-blue-def').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/text-blue/)) {
				var text = selected.replace(regexp, '<span class="$1 text-blue">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにtext-blueが既にあります。');
			}
		} else {
			var text = '<span class="text-blue">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//文字の色　緑に変更
	$('.fa-font.fa-green-def').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/text-green/)) {
				var text = selected.replace(regexp, '<span class="$1 text-green">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにtext-greenが既にあります。');
			}
		} else {
			var text = '<span class="text-green">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//文字の色　茶色に変更
	$('.fa-font.fa-darkred-def').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/text-darkred/)) {
				var text = selected.replace(regexp, '<span class="$1 text-darkred">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにtext-darkredが既にあります。');
			}
		} else {
			var text = '<span class="text-darkred">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//文字サイズ
	$('.fa-fz').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/fz-/)) {
				var text = selected.replace(regexp, '<span class="$1 fz-12">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにfz-が既にあります。');
			}
		} else {
			var text = '<span class="fz-12">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});


	//リンク
	$('.fa-link-def').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		//文字列の置き換え
		var text = '<a href="" target="_blank">' + selected + '</a>';
		simplemde.codemirror.replaceSelection(text);
	});

	//リスト（ul）
	$('.fa-list-disc').on('click', function () {
		var text = '</p>\n<ul>\n\t<li></li>\n\t<li></li>\n\t<li></li>\n</ul>\n<p>';
		simplemde.codemirror.replaceSelection(text);
	});

	//リスト（ol）
	$('.fa-list-ol-def').on('click', function () {
		var text = '</p>\n<ol>\n\t<li></li>\n\t<li></li>\n\t<li></li>\n</ol>\n<p>';
		simplemde.codemirror.replaceSelection(text);
	});


	//スパンタグ
	$('.fa-span').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		//文字列の置き換え
		var text = '<span class="">' + selected + '</span>';
		simplemde.codemirror.replaceSelection(text);
	});

	//改行
	$('.fa-br').on('click', function () {
		var text = '<br>';
		simplemde.codemirror.replaceSelection(text);
	});

	//マージントップ
	$('.fa-mgt').on('click', function () {
		var text = '</p>\n<p class="mgt-1">';
		simplemde.codemirror.replaceSelection(text);
	});

	//divを設置
	$('.fa-div').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		//文字列の置き換え
		var text = '<div class="" markdown="1">\n' + selected + '\n</div>';
		simplemde.codemirror.replaceSelection(text);
	});

	//モーダルを設置
	$('.fa-modal').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		//文字列の置き換え
		var text = '[![](img～){.wd350}](img～){.modal-win}';
		//var text = '[![](img～)](img～){.modal-win .wd300}';

		simplemde.codemirror.replaceSelection(text);
	});


	//テキストエリアの記事を削除
	$('.fa-clear').on('click', function () {
		if (window.confirm('テキストエリアの記事を全部削除しますが、よろしいですか？')) {
			simplemde.value("");
			return true;
		} else {
			return false;
		}
	});

	//テキストエリアに（img数字）の文字を挿入
	$(".btn-img").click(function () {
		var valText = $(this).val();
		simplemde.codemirror.replaceSelection(valText);
	})

	//YouTube動画を埋め込み
	$('.fa-youtube-def').on('click', function () {

		var btnVal = $(this).attr('class');
		var pos = '';

		switch (true) {
			case $(this).hasClass('youtube-center'):
				pos = 'mx-auto';
				break;

			case $(this).hasClass('youtube-float'):
				pos = 'float-left';
				break;

			case $(this).hasClass('youtube-left'):
				pos = '';
				break;

			case $(this).hasClass('youtube-right'):
				pos = 'float-right';
				break;
		}

		tubeInput_def(pos);
	});


	function tubeInput_def(pos) {

		// 入力ダイアログを表示 
		tubeUrl = window.prompt("YOUTUBEのURLを入力してください。（https://www.youtube.com/から始まるURL）", "");

		var regexp = new RegExp(/www\.youtube\.com/);
		var result = regexp.test(tubeUrl);

		if (result) {
			//文字列の挿入
			var tubeUrl = tubeUrl.replace('watch?v=', 'embed/');

			tubeUrl = '（youtube "' + tubeUrl + '" ##' + pos + '## @@@@）';

			simplemde.codemirror.replaceSelection(tubeUrl);
		}
	}
}


//===========================//
//     マークダウン入力       //
//==========================//

function btn_simplemde_mark() {

	var simplemde = new SimpleMDE({
		element: document.getElementById("report-markdown"),
		forceSync: true,
		spellChecker: false,
		renderingConfig: {
			singleLineBreaks: false,
			codeSyntaxHighlighting: true,
		},
		toolbar: [
			'|',
			'bold',
			'italic',
			'heading',
			'|',
			'quote',
			'unordered-list',
			'ordered-list',
			'|',
			'link',
			'image',
			'table',
			'code',
			'|',
			'fullscreen',
			'|',
			{
				name: 'font-red',
				className: 'fa fa-font fa-red',
				title: '赤文字',
			},
			{
				name: 'font-blue',
				className: 'fa fa-font fa-blue',
				title: '青文字',
			},
			{
				name: 'font-green',
				className: 'fa fa-font fa-green',
				title: '緑文字',
			},
			'|',
			{
				name: 'div',
				className: 'fa fa-div',
				title: 'div設置',
			},
			'|',
			{
				name: 'modal',
				className: 'fa fa-modal',
				title: 'モーダルウィンドウ設置',
			},
			'|',
			{
				name: 'youtube',
				className: 'fa fa-youtube',
				title: 'YouTube動画の埋め込み',
			},
			'|',
			{
				name: 'clear',
				className: 'fa fa-clear',
				title: 'テキストエリアの記事を削除',
			},
			'|',
			{
				name: 'プレビュー',
				className: 'fa fa-preview',
				title: '記事をプレビューします',
			}
		]
	});



	//拡大
	$(".fa-arrows-alt").click(function () {
		$('a.fa.fa-preview').toggleClass('d-inline-block');
	});

	$('.fa-preview').on('click', function () {
		$('#btn-markpreview').trigger('click');
	});


	//マークダウンテキストエリアに![](img数字)の文字を挿入
	$(".btn-markimg").click(function () {
		var valText = $(this).val();
		var line = simplemde.codemirror.getCursor().line;
		var ch = simplemde.codemirror.getCursor().ch;

		//文字列の挿入
		var text = '![](' + valText + ')';
		simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });

		$(this).hide();
	});

	//マークダウンにファイルリンクや画像コードを挿入
	$('ul#waitingList').on('click', '.fileInsert', function () {
		let valText = $(this).siblings('.filename').text();
		let line = simplemde.codemirror.getCursor().line;
		let ch = simplemde.codemirror.getCursor().ch;

		if ($(this).parent('li').hasClass('photo-list')) {
			//画像の挿入
			var text = '![]' + '(upload/' + valText + ')';
			simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });
			alert('「' + valText + '」画像のコードを記入しました');
		} else {
			//文字列の挿入
			var text = '[' + valText + '](upload/' + valText + ')';
			simplemde.codemirror.replaceRange(text, { line: line, ch: ch }, { line: line, ch: ch });
			alert('「' + valText + '」 ファイルリンクを記入しました');
		}
		return false;
	});

	//文字の色　赤に変更
	$('.fa-font.fa-red').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/text-red/)) {
				var text = selected.replace(regexp, '<span class="$1 text-red">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにtext-redが既にあります。');
			}
		} else {
			var text = '<span class="text-red">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//文字の色　青に変更
	$('.fa-font.fa-blue').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/text-blue/)) {
				var text = selected.replace(regexp, '<span class="$1 text-blue">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにtext-blueが既にあります。');
			}
		} else {
			var text = '<span class="text-blue">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//文字の色　緑に変更
	$('.fa-font.fa-green').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/text-green/)) {
				var text = selected.replace(regexp, '<span class="$1 text-green">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにtext-greenが既にあります。');
			}
		} else {
			var text = '<span class="text-green">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//文字の色　茶色に変更
	$('.fa-font.fa-darkred').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/text-darkred/)) {
				var text = selected.replace(regexp, '<span class="$1 text-darkred">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにtext-darkredが既にあります。');
			}
		} else {
			var text = '<span class="text-darkred">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//太字
	$('.fa-bold-def').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		console.log(selected);
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/bold/)) {
				var text = selected.replace(regexp, '<span class="$1 bold">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにboldが既にあります。');
			}
		} else {
			var text = '<span class="bold">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});


	//文字サイズ
	$('.fa-fz').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		var regexp = new RegExp(/<span class="(.*)">(.*)<\/span>/);

		if (regexp.test(selected)) {//<span class=""></span>が選択にある場合
			var clsText = selected.replace(regexp, '$1');

			if (!clsText.match(/fz-/)) {
				var text = selected.replace(regexp, '<span class="$1 fz-12">$2</span>');
				simplemde.codemirror.replaceSelection(text);
			} else {
				alert('クラスにfz-が既にあります。');
			}
		} else {
			var text = '<span class="fz-12">' + selected + '</span>';
			simplemde.codemirror.replaceSelection(text);
		}
	});

	//YouTube動画を埋め込み（マークダウン用）
	$('.fa-youtube').on('click', function () {
		tubeInput();
	});

	function tubeInput() {
		// 入力ダイアログを表示 
		tubeUrl = window.prompt("You TubeのURLを入力してください。", "");

		var regexp = new RegExp(/www\.youtube\.com/);
		var result = regexp.test(tubeUrl);

		if (result) {
			//文字列の挿入

			var tubeUrl = tubeUrl.replace('watch?v=', 'embed/');

			var text = '<div class="embed-responsive embed-responsive-16by9">\n' +
				'<iframe class="embed-responsive-item" src="' + tubeUrl + '" allowfullscreen></iframe>\n' +
				'</div>';

			simplemde.codemirror.replaceSelection(text);
		}
	}

	//divを設置
	$('.fa-div').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		//文字列の置き換え
		var text = '<div class="" markdown="1">\n' + selected + '\n</div>';
		simplemde.codemirror.replaceSelection(text);
	});

	//モーダルを設置
	$('.fa-modal').on('click', function () {
		//選択した文字列の取得
		var selected = simplemde.codemirror.getSelection();
		//文字列の置き換え
		var text = '[![](img～){.wd350}](img～){.modal-win}';
		//var text = '[![](img～)](img～){.modal-win .wd300}';

		simplemde.codemirror.replaceSelection(text);
	});


	//テキストエリアの記事を削除
	$('.fa-clear').on('click', function () {
		if (window.confirm('テキストエリアの記事を全部削除しますが、よろしいですか？')) {
			simplemde.value("");
			return true;
		} else {
			return false;
		}
	});
}

