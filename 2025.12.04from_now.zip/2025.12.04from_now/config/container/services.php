<?php
use Psr\Container\ContainerInterface;
use SocymSlim\SlimMiddle\Services\{
    EditService,
    FolderService,
    DirReplaceService,
    MenuService,
    MarkdownService,
    LockService,
};


return function ($container) {

    $container->set(PDO::class, function ($c) {
        $config = $c->get('config')['db'];

        $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};port={$config['port']};charset=utf8mb4";

        return new PDO($dsn, $config['user'], $config['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    });       
    
    
    // EditService
    $container->set(EditService::class, function (ContainerInterface $c) {
        return new EditService($c);
    });


    // FolderService
    $container->set(FolderService::class, function ($c) {
        return new FolderService(
            $c->get(EditService::class),
            $c //コンテナの値も渡す
        );
    });
        
    //DirReplaceService
    $container->set(DirReplaceService::class, function (ContainerInterface $c) {
        return new DirReplaceService(
            $c->get(FolderService::class)
        );
    });
    
    //MenuService
    $container->set(MenuService::class, function (ContainerInterface $c) {
        return new MenuService($c);
    });
    
    //MarkdownService 
    // $container->set(MarkdownService::class, function (ContainerInterface $c) {
    //     // return new MarkdownService($c);
    //     return new MarkdownService(
    //         $c->get(EditService::class),
    //         $c //コンテナの値も渡す
    //     );
    // });
    
    $container->set(MarkdownService::class, function (ContainerInterface $c) {
        return new MarkdownService(
            $c,                        // ContainerInterface $container
            $c->get(EditService::class) // EditService $editService
        );
    });
 
    
    //LockService
    $container->set(LockService::class, function ($c) {
        return new LockService($c->get(EditService::class));
    });
};
