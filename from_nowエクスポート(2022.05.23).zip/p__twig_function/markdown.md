<a href="sample/twig/" target="_blank">baseファイル</a>

## block、extends

参考サイト
: [公式サイトblock](https://twig.symfony.com/doc/3.x/functions/block.html)
: [Twigテンプレートの実践的な構成と作り方](https://php-archive.net/php/twig-advanced/)

<span class="green bold">block</span>は継承に使用され、同時にプレースホルダーと置換として機能します。  
ブロック名は、英数字とアンダースコアで構成する必要があります。 最初の文字を数字にすることはできず、ダッシュは使用できません。

<span class="purple bold">extends</span>タグを使用すると、テンプレートを別のテンプレートから拡張できます。

PHPと同様に、Twigは多重継承をサポートしていません。 したがって、レンダリングごとに呼び出されるextendsタグは1つだけです。 ただし、Twigは水平方向の再利用をサポートしています。

<p class="tmp list"><span>リスト1</span>index1_block.php</p>
```
<?php
require_once("vendor/autoload.php");

$loader = new \Twig\Loader\FilesystemLoader("templates");

$twig = new \Twig\Environment($loader);

echo $twig->render('block.twig');
```

<p class="tmp list"><span>リスト2</span>templates/block.twig</p>
extendsで「base.twig」を読み込み、block titleとblock contentにbase.twigに継承する値を設定する。
```
{% extends 'layouts/base.twig' %}
 
{% block title %}Twig Block{% endblock %}

{% block header %}
<img src="images/logo.png">
{% endblock %}

{% block content %}
<h1>Hello, World!</h1>
{% endblock %}

{% block footer %}
<p>copyright nttdata daichi</p>
{% endblock %}
```

<p class="tmp list"><span>リスト3</span>templates/layouts/base.twig</p>
block.twigから継承された値が、block title、block content、block footerがあるタグに挿入されます。
```
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>{% block title %}{% endblock %}</title>
	</head>
	<body>
		<div id="header">
			{% block header %}{% endblock %}
		</div>
		{% block content %}{% endblock %}
		<div id="footer">
			{% block footer %}{% endblock %}
		</div>
	</body>
</html>
```

下記のURLに接続すると、次のように表示されます。

<a href="sample/twig/index1_block.php" target="_blank">～/sample/twig/index1_block.php</a>

![](upload/index1_block表示結果.png)

<p class="tmp">出力結果（HTML）</p>
```
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Twig Block</title>
	</head>
	<body>
		<div id="header">
			<img src="images/logo.png">
		</div>
		<h1>Hello, World!</h1>
		<div id="footer">
			<p>copyright nttdata daichi</p>
		</div>
	</body>
</html>
```

## include

<p class="tmp list"><span>リスト</span>index3_include.php</p>
```
<?php
require_once("vendor/autoload.php");

$loader = new \Twig\Loader\FilesystemLoader("templates");

$twig = new \Twig\Environment($loader);

echo $twig->render('include.twig');
```

<p class="tmp list"><span>リスト</span>include.twig</p>
```
{% include 'layouts/header.html' %}
```

<p class="tmp list"><span>リスト</span>header.html</p>
```
<p>ヘッダーです。</p>
```

<a href="sample/twig/index3_include.php" target="_blank">sample/twig/index3_include.php</a>


<p class="tmp list"><span>リスト</span>index3-1_include.php</p>
```
<?php
require_once("vendor/autoload.php");

$loader = new \Twig\Loader\FilesystemLoader("templates");

$twig = new \Twig\Environment($loader);

echo $twig->render('include1.twig');
```

<p class="tmp list"><span>リスト</span>include.twig1</p>
```
{% extends 'layouts/base1.twig' %}

{% block title %}include1{% endblock %}

{% block header %}
{% include 'layouts/header.twig' %}
{% endblock %}
```

<p class="tmp list"><span>リスト</span>base1.twig</p>
```
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>{% block title %}{% endblock %}</title>
	</head>
	<body>
		<div id="header">
			{% block header %}
			{% endblock %}
		</div>
	</body>
</html>
```

<p class="tmp list"><span>リスト</span>header.twig</p>
```
<p>ヘッダーです。</p>
{% include 'layouts/header_inner.html' %}
```

<p class="tmp list"><span>リスト</span>header_inner.html</p>
```
<p>ヘッダーです。</p>
{% include 'layouts/header_inner.html' %}
```

<a href="sample/twig/index3-1_include.php" target="_blank">sample/twig/index3-1_include.php</a>

<p class="tmp">出力結果（HTML）</p>
```
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<title>include1</title>
	</head>
	<body>
		<div id="header">
			<p>ヘッダーです。</p>
			<p>ヘッダーインナーです。</p>
		</div>
	</body>
</html>
```