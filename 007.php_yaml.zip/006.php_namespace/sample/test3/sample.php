<?php
require_once 'greeting.php';
use Asia\Japan\Kanto\Tokyo as Tokyo;

require_once 'calling.php';
use Asia\Japan\Hokkaido\Hokkaido\Sapporo as Hokkaido;

echo Tokyo\hello(); // 出力結果：こんにちは
echo Hokkaido\hello(); // 出力結果：もしもし