Vue.createApp({
  data() {
    return {
      message: ''
    };
  },
  methods: {
    onchange() {
      //アップロードファイルを準備
      const fl = this.$refs.upfile.files[0];
      const data = new FormData();
      data.append('upfile', fl, fl.name);
      //サーバーにデータを送信
      fetch('upload.php', { 
        method: 'POST',
        body: data,
      })
      //成功時に結果を表示
      .then(response => response.text())
      .then(text => {
        this.message = text;
      })
      //失敗時にはエラーメッセージをダイアログで表示
      .catch(error => {
        window.alert(`Error: ${error.message}`);
      });
    }
  }
}).mount('#app');