---
title: 06.JSONを利用したデータ交換
taxonomy:
    category:
        - docs
visible: true
---

もともとはJavaScriptというプログラム言語に由来するデータ形式ですが、Pythonを含めて、多くのプログラミング言語がJSONに対応しています。<br>
ここではJSONとモジュールの使い方を学んで、プログラム間のデータ交換を行ってみましょう。

<h2 class="h-type2">JSONの機能</h2>

JSONには次のような機能があります。

<h3 class="h-type3">配列</h3>

JSONの配列は、Pythonのリストに似たデータ構造てす。順序された値の集まりを表します。<br>
JSONの配列は、角括弧で囲みます。

<p class="tmp"><span>書式1</span></p>

	[値A, 値B, 値C,…]


<h3 class="h-type3">オブジェクト</h3>

JSONのオブジェクトは、Pythonの辞書に似たデータ構造です。名前の付いた値の集まりを表します。<br>
JSONのオブジェクトは、中括弧で囲みます。

<p class="tmp"><span>書式2</span></p>

	{名前A:値A, 名前B:値B, 名前C:値C,…}


次のように改行で区切って、わかりやすく書くこともできます。


    {
        名前A: 値A, 
        名前B: 値B, 
        名前C: 値C,
        …
    }


JSONとPythonのデータ構造は、機能も記法もよく似ています。<br>
そして、jsonモジュールを使えば、Pythonのデータ構造をJSONに変換してファイルに書き込んだり、ファイルから読み込んだJSONをPythonのデータ構造に変換したり、といった処理がとても簡単に行えます。

<h3 class="h-type3">Pythonのデータ構造をJSONに変換</h3>

JSONを出力するにはdump関数を使います。

<p class="tmp"><span>書式3</span>Pythonのデータ構造をJSONに変換して出力する</p>

	json.dump(変数, ファイルオブジェクト)


上の書式では、変数に格納されたPythonのデータ構造をJSONに変換し、ファイルオブジェクトが表すファイルに出力します。

<div class="box-example">
    <h3 class="h-example">例1</h3>
	jsonモジュールのdump関数を使って、変数menuに代入されたメニューの内容を、menu.txtというファイルに出力します。
</div>

<p class="editpre"><span>テキストエディタ</span>json1.py</p>

    import = json
    menu = [
        {'name': 'ハンバーガー', 'price': 100, 'calorie': 260},
        {'name': 'チーズバーガー', 'price': 130, 'calorie': 310},
        {'name': 'フライドポテト', 'price': 150, 'calorie': 420}
    ]
    with open('menu.txt', 'w') as file:
        json.dump(menu, file)


<p class="file"><span>テキスト</span>menu.txt</p>

    [
        {"name": "\u30cf\u30f3\u30d0\u30fc\u30ac\u30fc", "price": 100, "calorie": 260},
        {"name": "\u30c1\u30fc\u30ba\u30d0\u30fc\u30ac\u30fc", "price": 130, "calorie": 310}, 
        {"name": "\u30d5\u30e9\u30a4\u30c9\u30dd\u30c6\u30c8", "price": 150, "calorie": 420}
    ]


出力されたmenu.txtは、データが詰まっていて読みづらいので、改行やインデントを入れて読みやすくします。

dump関数を呼び出す際にはキーボード引数indentを設定すると、改行やインデントで整形してJSONを出力できます。


<p class="tmp"><span>書式4</span>改行とインデントで整形してJSONを出力</p>

	json.dump(変数, ファイルオブジェクト, indent=インデント幅)


<div class="box-example">
    <h3 class="h-example">例2</h3>
	下記のコードで、さきほどのmenu.txtを再度出力してみます。
</div>

<p class="file"><span>テキスト</span>json1.py</p>
<pre>
…【中略】…
with open('menu.txt', 'w') as file:
    json.dump(menu, file, indent=4)
</pre>


<p class="editpre"><span>テキストエディタ</span>menu.txt</p>

    [
        {
            "name": "\u30cf\u30f3\u30d0\u30fc\u30ac\u30fc",
            "price": 100,
            "calorie": 260
        },
        {
            "name": "\u30c1\u30fc\u30ba\u30d0\u30fc\u30ac\u30fc",
            "price": 130,
            "calorie": 310
        },
        {
            "name": "\u30d5\u30e9\u30a4\u30c9\u30dd\u30c6\u30c8",
            "price": 150,
            "calorie": 420
        }
    ]


これで、かなり読みやすくなりました。nameの値に並んでいる「\u〇〇〇〇」という記述は、Unicodeエスケープシーケンスと呼ばれる記法です。<br>
〇〇〇〇の部分には、文字コードを表す4桁の16進数が入ります。



<h3 class="h-type3">ファイルから読み込んだJSONをPythonのデータ構造に変換</h3>

<p class="tmp"><span>書式5</span>ファイルから読み込んだJSONをPythonのデータ構造に変換して返す</p>

	json.load(ファイルオブジェクト)




<div class="box-example">
    <h3 class="h-example">例3</h3>
	jsonモジュールのload関数を使って、JSON形式でデータを持つmenu.txtからメニューの内容を読み込み、変数menuに代入します。
	そして、変数menuを画面に表示します。
</div>
<p class="editpre"><span>テキストエディタ</span>json2.py</p>

    import json
    with open('menu.txt', 'r') as file:
        menu = json.load(file)
    print(menu)



json2.pyを実行
<p class="result">実行結果</p>

    [
        {'name': 'ハンバーガー', 'price': 100, 'calorie': 260},
        {'name': 'チーズバーガー', 'price': 130, 'calorie': 310},
        {'name': 'フライドポテト', 'price': 150, 'calorie': 420}
    ]



※見やすいように改行しています。

ここまで見てきた通り、JSONを使うと、とても簡単にデータが保存できます。<br>
ちょっとした住所録や注文の一覧表なども作れるでしょう。<br>
業務用のプログラムではデータベースを使うことが多いですが、ちょっとしたデータならばJSONとファイルで手軽に管理することができます。


















