*[page-title]:Slim機能メモ

## パラメータを取得

FORMからPOSTで送信した値は、$_REQUEST[]で取得できます。

例）検索ボックスから送信した値を取得
```
<form action="../../search/" method="post" id="search">
	<div class="keyword">
		<input type="text" name="word" placeholder="全ページ検索">
		<input class="btn-search" type="submit" value="検索">
	</div>
</form>
```

<p class="lang">routes.php</p>
```
//検索ボックス(テスト)
$app->any("/search/", 
    function(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface {
        $word = $_REQUEST['word'];//検索ワードを取り出す
        $content = $word."の検索を実行します。";
        $responseBody = $response->getBody();
        $responseBody->write($content);
        return $response;
    }
);
```

![](upload/検索ボックス.png)

## Slimアップデート

<p class="tmp cmd"><span>コマンド</span>アップデートできるファイルのバージョン表示</p>
```
composer outdated
```
<p class="result"><span>結果</span></p>
![](upload/現状composer_outdated.png)

<p class="tmp cmd"><span>コマンド</span>現在インストールされているパッケージを最新のものに更新。</p>
```
composer update
```

アップデート後　composer.lock
![](upload/アップデート後composer.lock.png)
