---
title: tablesorter設定補足
taxonomy:
    category:
        - docs
tablesorter:
    active: true
    include_widgets: true
    table_nums: '1,2,3,4,5,6,7,8'
    themes: 'green,blue,dark'
    args:
        1:
            theme: blue
            widgets:
                - zebra
                - filter
        2:
            theme: green
            widgets:
                - zebra
                - filter
        3:
            theme: green
            widgets:
                - zebra
                - filter
            headers:
                -
                    sorter: false
                -
                    sorter: false
        4:
            theme: green
            widgets:
                - zebra
                - filter
            sortList:
                -
                    - 4
                    - 0
        5:
            theme: green
            widgets:
                - zebra
                - filter
            sortList:
                -
                    - 2
                    - 1
                -
                    - 4
                    - 0
        6:
            theme: green
            headers:
                -
                    sorter: false
                    parser: false
                -
                    filter: false
            sortList:
                -
                    - 0
                    - 0
                -
                    - 1
                    - 0
                -
                    - 2
                    - 0
            widgets:
                - zebra
                - filter
        7:
            theme: green
            widgets:
                - zebra
                - filter
        8:
            theme: green
            widgets:
                - zebra
            headers:
                -
                    sorter: false
                -
                    sorter: false
                -
                    sorter: false
                -
                    sorter: false
---

テーマ一覧
: [https://mottie.github.io/tablesorter/docs/themes.html](https://mottie.github.io/tablesorter/docs/themes.html)

## テーマ（blue）<span class="font-weight-normal h5">ソート、フィルター機能付き</span>

<div class="box-example" markdown="1">
### 例1 ### {.h-example}

    theme: blue
    widgets:
        - zebra
        - filter

| 社員番号| 名前 | ふりがな| 入社年月日| 年齢 | 性別 |
| -------- | -------- | -------- | -------- | -------- |
| 136 | 山田太郎 | やまだたろう |	2001/06/01 | 28 | 男 |
| 138 | 小池百合子 | こいけゆりこ | 2005/08/01| 32 | 女 |
|140 | 鈴木一郎 | すずきいちろう |	1999/04/01 | 44 | 男 |
| 144 |	松井秀喜 | まついひでき |	2017/04/01 | 43 | 男 |
| 153 |	小田和正 |	おだかずまさ | 2014/09/01 | 27 | 男 |
| 176 |	藤田菜々子 |	ふじたななこ | 1997/04/01 | 45 | 女 |
| 192 |	黒田博樹 | くろだひろき |	2012/07/01 | 37 | 男 |

</div>

## テーマ（green）<span class="font-weight-normal h5">ソート、フィルター機能付き</span>

<div class="box-example" markdown="1">
### 例2 ### {.h-example}

    theme: green
    widgets:
	    - zebra
	    - filter

| 社員番号| 名前 | ふりがな| 入社年月日| 年齢 | 性別 |
| -------- | -------- | -------- | -------- | -------- |
| 136 | 山田太郎 | やまだたろう |	2001/06/01 | 28 | 男 |
| 138 | 小池百合子 | こいけゆりこ | 2005/08/01| 32 | 女 |
|140 | 鈴木一郎 | すずきいちろう |	1999/04/01 | 44 | 男 |
| 144 |	松井秀喜 | まついひでき |	2017/04/01 | 43 | 男 |
| 153 |	小田和正 |	おだかずまさ | 2014/09/01 | 27 | 男 |
| 176 |	藤田菜々子 |	ふじたななこ | 1997/04/01 | 45 | 女 |
| 192 |	黒田博樹 | くろだひろき |	2012/07/01 | 37 | 男 |

</div>

## 指定した列のソート機能を外す

一列目、二列目のソート機能を解除する

<div class="box-example" markdown="1">
### 例3 ### {.h-example}

    headers:
	    -
		    sorter: false
	    -
		    sorter: false
        

| 社員番号| 名前 | ふりがな| 入社年月日| 年齢 | 性別 |
| -------- | -------- | -------- | -------- | -------- |
| 136 | 山田太郎 | やまだたろう |	2001/06/01 | 28 | 男 |
| 138 | 小池百合子 | こいけゆりこ | 2005/08/01| 32 | 女 |
|140 | 鈴木一郎 | すずきいちろう |	1999/04/01 | 44 | 男 |
| 144 |	松井秀喜 | まついひでき |	2017/04/01 | 43 | 男 |
| 153 |	小田和正 |	おだかずまさ | 2014/09/01 | 27 | 男 |
| 176 |	藤田菜々子 |	ふじたななこ | 1997/04/01 | 45 | 女 |
| 192 |	黒田博樹 | くろだひろき |	2012/07/01 | 37 | 男 |

</div>

## 最初からソートした状態で表示

sortListオプションは、最初からソートしておく列（第1引数）と、昇順・降順（第2引数）を指定します。第2引数が0だと昇順、1だと降順になります。


<div class="box-example" markdown="1">
### 例4 ### {.h-example}
下記は、左から5列目（年齢）を昇順でソートしてある状態です。

    sortList:
	    -
		    - 4
		    - 0



| 社員番号| 名前 | ふりがな| 入社年月日| 年齢 | 性別 |
| -------- | -------- | -------- | -------- | -------- |
| 136 | 山田太郎 | やまだたろう |	2001/06/01 | 28 | 男 |
| 138 | 小池百合子 | こいけゆりこ | 2005/08/01| 32 | 女 |
|140 | 鈴木一郎 | すずきいちろう |	1999/04/01 | 44 | 男 |
| 144 |	松井秀喜 | まついひでき |	2017/04/01 | 43 | 男 |
| 153 |	小田和正 |	おだかずまさ | 2014/09/01 | 27 | 男 |
| 176 |	藤田菜々子 |	ふじたななこ | 1997/04/01 | 45 | 女 |
| 192 |	黒田博樹 | くろだひろき |	2012/07/01 | 37 | 男 |

</div>



<div class="box-example" markdown="1">
### 例5 ### {.h-example}
下記の場合、左から3番目の列（ふりがな）は降順、左から5番目の列（年齢）は昇順でソートされた状態でページが読み込まれます

    sortList: [[2, 1],[4, 0]]

| 社員番号| 名前 | ふりがな| 入社年月日| 年齢 | 性別 |
| -------- | -------- | -------- | -------- | -------- |
| 136 | 山田太郎 | やまだたろう |	2001/06/01 | 28 | 男 |
| 138 | 小池百合子 | こいけゆりこ | 2005/08/01| 32 | 女 |
|140 | 鈴木一郎 | すずきいちろう |	1999/04/01 | 44 | 男 |
| 144 |	松井秀喜 | まついひでき |	2017/04/01 | 43 | 男 |
| 153 |	小田和正 |	おだかずまさ | 2014/09/01 | 27 | 男 |
| 176 |	藤田菜々子 |	ふじたななこ | 1997/04/01 | 45 | 女 |
| 192 |	黒田博樹 | くろだひろき |	2012/07/01 | 37 | 男 |

</div>

## フィルターをオフにする

<div class="box-example" markdown="1">
### 例6 ### {.h-example}
下記の場合、左から1番目の列（社員番号）は並べ替えとフィルターをオフにしており、左から2番目の列（名前）はフィルターだけをオフにしています。  
「parser: false」と「filter: false」のどちらでも、フィルターオフになります。

	headers:
		-
			sorter: false
			parser: false
		-
			filter: false



| 社員番号| 名前 | ふりがな| 入社年月日| 年齢 | 性別 |
| -------- | -------- | -------- | -------- | -------- |
| 136 | 山田太郎 | やまだたろう |	2001/06/01 | 28 | 男 |
| 138 | 小池百合子 | こいけゆりこ | 2005/08/01| 32 | 女 |
|140 | 鈴木一郎 | すずきいちろう |	1999/04/01 | 44 | 男 |
| 144 |	松井秀喜 | まついひでき |	2017/04/01 | 43 | 男 |
| 153 |	小田和正 |	おだかずまさ | 2014/09/01 | 27 | 男 |
| 176 |	藤田菜々子 |	ふじたななこ | 1997/04/01 | 45 | 女 |
| 192 |	黒田博樹 | くろだひろき |	2012/07/01 | 37 | 男 |

</div>

## セレクトボックスを設定する

&lt;th&gt;に「filter-select」と「filter-exact」の2つのクラスを設置すると、その列はセレクトボックスになります。  
「data-placeholder="テキスト"」を設置すると、入力欄に初期表示する内容を指定することができます。  
※マークダウンでの設定方法は、今のところ調査中です。

<div class="box-example" markdown="1">
### 例7 ### {.h-example}
下記では、左から3番目の列（gender）にセレクトボックスを設定しています。

```html
<th class="filter-select filter-exact" data-placeholder="Pick a gender">Sex</th>
```


<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Major</th>
			<th class="filter-select filter-exact" data-placeholder="Pick a gender">gender</th>
			<th>English</th>
			<th>Japanese</th>
			<th>Calculus</th>
			<th>Geometry</th></tr>
	</thead>
	<tfoot>
		<tr>
			<th>Name</th>
			<th>Major</th>
			<th>gender</th>
			<th>English</th>
			<th>Japanese</th>
			<th>Calculus</th>
			<th>Geometry</th>
		</tr>
	</tfoot>
	<tbody>
		<tr><td>Student01</td><td>Languages</td><td>male</td><td>80</td><td>70</td><td>75</td><td>80</td></tr>
		<tr><td>Student02</td><td>Mathematics</td><td>male</td><td>90</td><td>88</td><td>100</td><td>90</td></tr>
		<tr><td>Student03</td><td>Languages</td><td>female</td><td>85</td><td>95</td><td>80</td><td>85</td></tr>
		<tr><td>Student04</td><td>Languages</td><td>male</td><td>60</td><td>55</td><td>100</td><td>100</td></tr>
		<tr><td>Student05</td><td>Languages</td><td>female</td><td>68</td><td>80</td><td>95</td><td>80</td></tr>
		<tr><td>Student06</td><td>Mathematics</td><td>male</td><td>100</td><td>99</td><td>100</td><td>90</td></tr>
		<tr><td>Student07</td><td>Mathematics</td><td>male</td><td>85</td><td>68</td><td>90</td><td>90</td></tr>
		<tr><td>Student08</td><td>Languages</td><td>male</td><td>100</td><td>90</td><td>90</td><td>85</td></tr>
		<tr><td>Student09</td><td>Mathematics</td><td>male</td><td>80</td><td>50</td><td>65</td><td>75</td></tr>
		<tr><td>Student10</td><td>Languages</td><td>male</td><td>85</td><td>100</td><td>100</td><td>90</td></tr>
		<tr><td>Student11</td><td>Languages</td><td>male</td><td>86</td><td>85</td><td>100</td><td>100</td></tr>
		<tr><td>Student12</td><td>Mathematics</td><td>female</td><td>100</td><td>75</td><td>70</td><td>85</td></tr>
		<tr><td>Student13</td><td>Languages</td><td>female</td><td>100</td><td>80</td><td>100</td><td>90</td></tr>
		<tr><td>Student14</td><td>Languages</td><td>female</td><td>50</td><td>45</td><td>55</td><td>90</td></tr>
		<tr><td>Student15</td><td>Languages</td><td>male</td><td>95</td><td>35</td><td>100</td><td>90</td></tr>
  	</tbody>
</table>

</div>


## テスト


<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Major</th>
			<th>gender</th>
			<th>English</th>
        </tr>
	</thead>
	<tbody>
		<tr>
            <td><a href="#" class="permalink">cssAsc</a></td>
            <td>Languages</td>
            <td>male</td>
            <td>80
                		<div class="collapsible"><br>
			Changed to empty string (<code>""</code>) in v2.11, as the <code>"tablesorter-headerAsc"</code> class will always be added to a header cell with an ascending sort; this option now contains any additional class names to add.

			<p>Example from the blue theme:</p>
			<pre class="prettyprint lang-css"><span class="pun">.</span><span class="pln">tablesorter</span><span class="pun">-</span><span class="pln">blue </span><span class="pun">.</span><span class="pln">tablesorter</span><span class="pun">-</span><span class="pln">headerAsc </span><span class="pun">{</span><br><span class="pln">  background</span><span class="pun">-</span><span class="pln">color</span><span class="pun">:</span><span class="pln"> </span><span class="com">#9fbfdf;</span><br><span class="pln">  background</span><span class="pun">-</span><span class="pln">image</span><span class="pun">:</span><span class="pln"> url</span><span class="pun">(</span><span class="pln">black</span><span class="pun">-</span><span class="pln">asc</span><span class="pun">.</span><span class="pln">gif</span><span class="pun">);</span><br><span class="pun">}</span></pre>
		Default changed v2.5 to <code>"tablesorter-headerAsc"</code>. Default changed v2.1.7 to <code>"tablesorter-headerSortUp"</code>. Original default: <code>"headerSortUp"</code></div>
            </td>
        </tr>
		<tr>
            <td>Student02</td>
            <td>Mathematics</td>
            <td>male</td>
            <td>90</td>
        </tr>
  	</tbody>
</table>

