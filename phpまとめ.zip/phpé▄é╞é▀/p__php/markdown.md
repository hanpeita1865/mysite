*[page-title]:PHP

## PHP関連で参考になるサイト

* [WEPICKS!](https://wepicks.net/category/phpsample/)
	* [PHPの文法](https://wepicks.net/category/phpreference-structure/)
	* [PHPサンプル](https://wepicks.net/category/phpsample/)
	* [PHPテクニック](https://wepicks.net/category/phpreference-tech/)
	* [PHP関数リファレンス](https://wepicks.net/category/phpfunction/)
	* [PHPセキュリティー](https://wepicks.net/category/phpsecurity/)



## URLにクエリパラメーターを付けてブラウザにキャッシュされずにページを更新する方法

参考サイト
: [もう悩まない。URLにクエリパラメーターを付けてブラウザにキャッシュされずにページを更新する方法](https://ryu-webstudy.com/2021/07/18/%E3%82%82%E3%81%86%E6%82%A9%E3%81%BE%E3%81%AA%E3%81%84%E3%80%82url%E3%81%AB%E3%82%AF%E3%82%A8%E3%83%AA%E3%83%91%E3%83%A9%E3%83%A1%E3%83%BC%E3%82%BF%E3%83%BC%E3%82%92%E4%BB%98%E3%81%91%E3%81%A6/)
















### 実際にクエリパラメータを付けてみる

```
<link rel="stylesheet" href="css/style.css">
```

style.cssというCSSファイルを読み込んでいると仮定します。  
このstyle.cssを読み込んでいるlinkタグのhref属性にクエリパラメータを付けてみます。

```
// ファイルの更新年月日
<link rel="stylesheet" href="css/style.css?20210718">

// ファイルのバージョン
<link rel="stylesheet" href="css/style.css?ver=1.01">
```

「?20210718」や「?ver=1.01」の部分がクエリパラメータになります。
ファイル名に付けるクエリパラメータはファイルの更新年月日かバージョンを付けるのが一般的です。

絶対パスでも相対パスでも同じ方法で大丈夫です。

scriptタグでも同様にhref属性に指定したファイル名の末尾に「？〇〇」のクエリパラメータを付ける事によってキャッシュ対策が可能です。

### ファイルのクエリパラメータを自動で更新する方法

linkタグのhref属性に「？〇〇」のクエリパラメータを付けてブラウザのキャッシュ対策が出来ることは分かりましたが、ファイルの更新のたびにクエリパラメータも更新するのは面倒くさいです。

出来ればファイルを更新したらクエリパラメータも自動で更新したいところです。

PHPのfilemtime()関数を使うことで、クエリパラメータの自動更新を実現出来ます。
filemtime()は引数に指定したファイル名の更新日時をUNIXタイムスタンプの形式で取得します。

UNIXタイムスタンプとは世界の標準となる時間、協定世界時(UTC)として定められた1970年1月1日0時0分0秒から経過した秒数の事です。(別名UNIX時間とも呼ばれています。)

実際にfilemtime()を使ってUNIXタイムスタンプを見てみましょう。

<p class="tmp list"><span>リスト</span></p>
```
<?php 
echo filemtime( 'css/style.css' ); 
?>
```

上記コードを実行すると桁数が多い数字が画面に表示されているのが確認出来ます。  
この表示されている数字こそがUNIXタイムスタンプで、1970年1月1日0時0分0秒から経過した秒数です。

次にこのfilemtime()を使ってURLにクエリパラメータを付けてみます。

<p class="tmp list"><span>リスト</span></p>
```
<link rel="stylesheet" href="css/style.css?<?php echo filemtime( 'css/style.css' ); ?>">
```

先ほど直接日付を書いていたところにfilemtime()を書いて引数にファイル名を指定します。
filemtime()はファイルの更新日時を取得しますので、ファイルが更新された場合は更新された日時を自動で取得します。

こうする事でクエリパラメータの自動更新を実現することが出来ます。

またお好みにはなりますが、filemtime()で返ってくる数字が長い、時間や秒数が必要ない、そもそもUNIXタイムスタンプだと何の数字か分かりづらいと感じる方はPHPのdate()関数を使うことでfilemtime()で取得したUNIXタイムスタンプの表示を制御することが出来ます。

date()関数は引数に表示形式とUNIXタイムスタンプを指定することで時間を自分が表示したい形にカスタマイズ出来ます。
<p class="tmp list"><span>リスト</span></p>
```
<link rel="stylesheet" href="css/style.css?<?php echo date('Ymd', filemtime( 'css/style.css' )); ?>">
```
date()関数の引数に年月日を表す「Ymd」とfilemtime()を指定することで「20210719」というような見慣れた数字にUNIXタイムスタンプの表示をカスタマイズ出来ます。

### 都道府県サイトでお試し

試しに、都道府県サイトでおこなってみます。

<p class="tmp list"><span>リスト</span>head.php</p>
```
～省略～
<title><?= $title ?>｜だいち都道府県おすすめ情報サイト</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" type="text/css" href="./css/ress.css">
<link rel="stylesheet" type="text/css" href="./css/bootstrap-grid.css">
<link rel="stylesheet" type="text/css" href="./css/responsive.gs.12col.css">
<link rel="stylesheet" type="text/css" href="./css/style.css">
<link rel="stylesheet" type="text/css" href="./css/color.css">
～省略～
```
上記のstyle.cssに、パラメータを設置してみます。
```
<link rel="stylesheet" type="text/css" href="./css/style.css?<?php echo filemtime( 'css/style.css' ); ?>">
```
これで、style.cssのコードを更新して保存すると、以下のようにパラメータが付きます。
<p class="tmp list"><span>リスト</span></p>
```
～省略～
<title>広島｜だいち都道府県おすすめ情報サイト</title>
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" type="text/css" href="./css/ress.css">
<link rel="stylesheet" type="text/css" href="./css/bootstrap-grid.css">
<link rel="stylesheet" type="text/css" href="./css/responsive.gs.12col.css">
<link rel="stylesheet" type="text/css" href="./css/style.css?1646954803">
～省略～
```

また、次のようにdate関数をつかってみると、
```
<link rel="stylesheet" type="text/css" href="./css/style.css?<?php echo date('Ymd', filemtime( 'css/style.css' )); ?>">
```
パラメータは、このようになります。
```
<link rel="stylesheet" type="text/css" href="./css/style.css?20220311">
```

時間も付け足す場合は、以下のように「His」を追加すると
```
<link rel="stylesheet" type="text/css" href="./css/style.css?<?php echo date('Ymd_His', filemtime( 'css/style.css' )); ?>">
```
このように、なります。
```
<link rel="stylesheet" type="text/css" href="./css/style.css?20220311_002736">
```