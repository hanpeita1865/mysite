---
title: YouTube
media_order: 'toolbar_youtube.png,popup_youtube.png'
taxonomy:
    category:
        - docs
---

<style>
    .shadow {
        border: 1px solid #e7e7e7;
        border-radius: 0px;
        box-shadow: 0px 3px 10px 2px rgba(0,0,0,0.2);
        padding: 1.5em;
    }
    .youtube-small {
    	max-width: 600px;
       	margin: 0 auto;
    }
</style>

<i class="fa fa-check-square text-primary"></i>（テンプレート設定済み）

YouTubeの埋め込みを簡単に表示設定することができるプラグインです。

1. ツールバーのYouTubeアイコンをクリックします。
![](toolbar_youtube.png)

2. 入力画面が出るので、表示したいYouTubeのURLを貼り付けて、OKボタンを押します。
![](popup_youtube.png?classes=shadow)

3. 最後に編集画面右上の保存ボタンを押せば完了で、以下のように表示されます。

<div markdown="block" class="youtube-small">
[plugin:youtube](https://www.youtube.com/watch?v=4Nc27g3pol8)
    &#x1f4fd;おすすめの映画です。　個人的に今年NO`.1の映画 &#x1f600;
</div>



### サイズ調整

画面のサイズを設定したいときは、下記のようなクラスをcustom.cssに追加して、「markdown="block"」属性とクラスをdivに入れて囲んでやります。


**CSS**
<pre>
.youtube-small {
    max-width: 600px;
    margin: 0 auto;
}
</pre>

**HTML**
<pre>
&lt;div markdown="block" class="youtube-small"&gt;
<span class="comment">youtubeマークダウン</span>
&lt;/div&gt;
</pre>












