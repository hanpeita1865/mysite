*[page-title]:データベースを準備する


## モデルとデータベース

モデル（Model）はデータベース処理を担当する部分で、Laravelではデータベース操作のために2つの主要な機能が用意されています。

* <span class="green">DBクラス(クエリービルダー)</span>
: 最もシンプルなデータベース利用方法は「DBクラス」を使うことです。<br>
DBクラスを使うと、SQLクエリを直接実行するような形でデータベースにアクセスできます。<br>
さらに「**クエリービルダー**」を使うと、メソッドを使ってPHPらしい書き方でデータベース操作が可能になります。

* <span class="green">Eloquent(ORM)</span>
: LaravelにはEloquentというORM（Object-Relational Mapping）が搭載されています。<br>
ORMは、データベースのデータとプログラムのオブジェクトをつなぎ、オブジェクトとして操作できる仕組みです。<br>
Eloquentを使うと、DBクラスよりもPHPらしい書き方でデータベースを扱えます。

通常はDBクラスかEloquentのどちらかを使い、本書ではまずDBクラスを学び、次にEloquentを学びます。


## SQLite データベースについて

LaravelはMySQL、PostgreSQL、SQLite、SQL Serverに対応しており、設定で使うデータベースを選ぶだけで利用可能です。  
どのデータベースでもLaravel内では同じように扱えるため、操作方法に大きな違いはありません。  
導入が簡単なSQLiteは、データベースサーバーを起動せず、ファイルに直接アクセスして読み書きできる軽量なデータベースです。  
PHPはSQLiteファイルにすぐアクセスでき、Laravelの新規プロジェクトでもデフォルトでSQLiteが使えるように設定済みです。


## Adminerを利用する

とはいえ、SQLデータベースは、SQL というクエリー言語(データベースに問い合わせる専用言語)を使ってデータベース操作を行うため、こうした作業に慣れていないと扱いが非常に難しく感じるでしょう。  

そんな人のために、Herdには「Adminer」というツールが用意されています。Adminerは、SQLデータベースを操作するためのシンプルなツールです。これは、Herdから起動して使うことができます。  

Herdで、サイトの管理ウィンドウを呼び出し、使用するサイトを選択してください。すると、サイトに関する細かな項目が現れます。この中にある「Adminer」というものの「Open」ボタンをクリックすると、Adminerが開かれ、このアプリに用意されているSQLiteのデータベースファイルを編集できるようになります。

![](upload/Herd_Adminer.png){.photo-border}

![](upload/Herd_SQLite3.png "図　HerdからAdminerを開く"){.photo-border}


### Adminerの画面

このAdminerは、Webベースのツールです。「Open」ボタンを押すと、WebブラウザでAdminerの画面が開かれます。  
デフォルトでは「Login」という画面が現れているでしょう。ここでは、以下のような項目があります。

<table>
	<tbody>
		<tr>
			<th>System</th>
			<td>使用するSQLデータベースを選択します。</td>
		</tr>
		<tr>
			<th>Database</th>
			<td>使用するデータベースの指定です。</td>
		</tr>
	</tbody>
</table>

これらは、いずれもデフォルトで設定済みになっているため、変更する必要はありません。   
SQLite以外のデータベースを扱うような場合にのみ設定を変更すると考えてください。   
このまま「Login」ボタンを押せば、データベースにログインし、作業を開始します。

![](upload/Adminer_Databeseログイン.png "図　ログインするとデータベースのテーブルが一覧表示される"){.photo-border}

ログインすると、アプリケーション用のデータベースファイルが開かれます。  
左側にテーブル一覧、右側に各テーブルの内容が表示されます。  
デフォルトで多くのテーブルが作成されており、ユーザー認証やセッション管理などに使われています。削除しないよう注意してください。  
自分のアプリ用のテーブルは、この既存のテーブルに追加して作成していきます。


## テーブルを作成する

では、データベースに「テーブル」を作成しましょう。  
テーブルというのは、データの内容を定義し、それにしたがって用意されたデータ(レコードといいます)を保管し管理するものです。一般に「データベースにデータを保存したり検索したりする」という作業は、このテーブルを操作することです。

データベースには、必要に応じていくつでもテーブルを用意することができます。ここでは、以下のようなシンプルなテーブルを作ってみましょう。
<p class="tb-caption"><span>表</span>peopleテーブル</p>
<table>
	<tbody>
		<tr>
			<th>id</th>
			<td>保管するデータ(レコード)に割り当てる番号。</td>
		</tr>
		<tr>
			<th>name</th>
			<td>名前を保管する項目。</td>
		</tr>
		<tr>
			<th>mail</th>
			<td>メールアドレスを保管する項目。</td>
		</tr>
		<tr>
			<th>age</th>
			<td>年齢を保管するための項目。</td>
		</tr>
	</tbody>
</table>

ごく簡単な、個人情報を保管するテーブルですね。テーブルにはこのように、保管するデータの項目を必要なだけ用意します。これらの項目は「フィールド」(または、カラム)と呼ばれます。

それぞれのフィールドには、名前と、値の種類、その他必要に応じて設定などの情報が用意されます。では、実際にテーブルを作成しましょう。

### peopleテーブルを作る

では、新しいテーブルを作成します。  
左側のテーブルのリストが表示されているところに「Create table」というリンクが見えますね? これをクリックしてください。新しいテーブルを作成するためのフォームが現れます。

まずは、フォームの一番上にある「Table name」というところに「people」と記入しておきましょう。そしてフィールドを作成していきます。
![](upload/Create_tableをクリックするとフォームが現れる.png){.photo-border}

### Iidフィールドの作成

フォームには、最初のフィールドを入力する欄が用意されています。「Column name」のフィールドに「id」と記入してください。そして、以下のように項目を設定します。

<table>
	<tbody>
		<tr>
			<th>Type</th>
			<td>値のタイプを指定します。デフォルトの「Integer」のままにしておきます。</td>
		</tr>
		<tr>
			<th>Length</th>
			<td>データ長を指定します。これは空のままでいいでしょう。</td>
		</tr>
		<tr>
			<th>Options</th>
			<td>特に設定はありません。</td>
		</tr>
		<tr>
			<th>NULL</th>
			<td>未入力を許可するか指定します。OFFのままにしておきます。</td>
		</tr>
		<tr>
			<th>Al</th>
			<td>「Auto Increment」の略です。ONにしておきます。</td>
		</tr>
	</tbody>
</table>

テーブル作成時は「Type」と「AI」に注意が必要です。Typeでデータ型を設定し、idは必ずAuto Increment（AI）をONにして自動採番にします。値を入力すると新しいフィールド欄が追加され、順に入力してテーブルを作成できます。
![](upload/people_id入力.png)

### その他のフィールドの設定

では、どんどんフィールドを作っていきましょう。以下のように残りのフィールドを設定していってください。

#### nameフィールド
<table>
	<tbody>
		<tr>
			<th>Column name</th>
			<td>name</td>
		</tr>
		<tr>
			<th>Type</th>
			<td>text</td>
		</tr>
		<tr>
			<th>その他</th>
			<td>デフォルトのまま</td>
		</tr>
	</tbody>
</table>

#### mailフィールド

<table>
	<tbody>
		<tr>
			<th>Column name</th>
			<td>mail</td>
		</tr>
		<tr>
			<th>Type</th>
			<td>text</td>
		</tr>
		<tr>
			<th>その他</th>
			<td>NULLをONにする</td>
		</tr>
	</tbody>
</table>


#### ageフィールド

<table>
	<tbody>
		<tr>
			<th>Column name</th>
			<td>age</td>
		</tr>
		<tr>
			<th>Type</th>
			<td>integer</td>
		</tr>
		<tr>
			<th>その他</th>
			<td>NULLをONにする</td>
		</tr>
	</tbody>
</table>

![](upload/peopleテーブルカラム作成.png){.photo-border}

### テーブルを保存する

一通りフィールドが用意できたら、「Save」ボタンをクリックしてください。テーブルが作成され、テーブルの内容が表示されます。ここで、用意したフィールドの名前とタイプが間違っていないか確認しましょう。

![](upload/peopleテーブル完成.png){.photo-border}


## ダミーのレコードを追加する

テーブルを作ったら、練習用にダミーデータを入れましょう。  
画面上部の「New item」リンクから新しいレコードを追加できます。 
![](upload/NewItemリンクをクリック.png){.photo-border}

id は入力不要（自動で番号がつく）。  
name・mail・age を入力し、「Save and insert next」で保存しつつ次の入力画面に進めます。  
![](upload/taroさんデータ記入.png)
「Save」は保存して終了。  
mail や age の欄で「NULL」が残った場合は手動で空白に直しましょう。

### レコードを確認する

適当にレコードを作成したら、テーブルの内容を確認しましょう。左側に表示されているテーブルの一覧リストから「people」をクリックしてください。
![](upload/メニューからpeopleテーブル選択.png){.photo-border}
これでpeopleテーブルの概要表示に移動します。
![](upload/peopleダミーデータ記入完了.png){.photo-border}


## DB利用のための手続き

データベースとテーブルを準備できたら、次はLaravelから利用できるようにします。  
Laravelでは「config/database.php」にデータベース設定ファイルがあり、これを編集してSQLiteを使えるようにします。

<p class="tmp list"><span>リスト6-1</span>config/database.php（デフォルト）</p>
```
<?php
use Illuminate\Support\Str;

return [

  'default' => env('DB_CONNECTION', 'sqlite'),

  'connections' => [

    'sqlite' => [
      'driver' => 'sqlite',
      'url' => env('DB_URL'),
      'database' => env('DB_DATABASE', 
          database_path('database.sqlite')),
      'prefix' => '',
      'foreign_key_constraints' => 
          env('DB_FOREIGN_KEYS', true),
      'busy_timeout' => null,
      'journal_mode' => null,
      'synchronous' => null,
    ],

    'mysql' => [
      'driver' => 'mysql',
      'url' => env('DB_URL'),
      'host' => env('DB_HOST', '127.0.0.1'),
      'port' => env('DB_PORT', '3306'),
      'database' => env('DB_DATABASE', 'laravel'),
      'username' => env('DB_USERNAME', 'root'),
      'password' => env('DB_PASSWORD', ''),
      ……略……
    ],

    'mariadb' => [
      'driver' => 'mariadb',
      'url' => env('DB_URL'),
      'host' => env('DB_HOST', '127.0.0.1'),
      'port' => env('DB_PORT', '3306'),
      'database' => env('DB_DATABASE', 'laravel'),
      'username' => env('DB_USERNAME', 'root'),
      'password' => env('DB_PASSWORD', ''),
      ……略……
    ],

    'pgsql' => [
      'driver' => 'pgsql',
      'url' => env('DB_URL'),
      'host' => env('DB_HOST', '127.0.0.1'),
      'port' => env('DB_PORT', '5432'),
      'database' => env('DB_DATABASE', 'laravel'),
      'username' => env('DB_USERNAME', 'root'),
      'password' => env('DB_PASSWORD', ''),
      ……略……
    ],

    'sqlsrv' => [
      'driver' => 'sqlsrv',
      'url' => env('DB_URL'),
      'host' => env('DB_HOST', 'localhost'),
      'port' => env('DB_PORT', '1433'),
      'database' => env('DB_DATABASE', 'laravel'),
      'username' => env('DB_USERNAME', 'root'),
      'password' => env('DB_PASSWORD', ''),
      ……略……
    ],

  ],

  'redis' => [
    ……略……
  ],
];
```
ここでは、配列の中にデータベース関連の設定がまとめられています。よく見ると、それぞれのデータベースごとに設定が用意されていることがわかるでしょう。

Laravelの「config/database.php」では、connections配列にSQLiteやMySQLなどの設定がまとまっています。  
どのデータベースを使うかは、defaultに書かれた <span class="red">env('DB_CONNECTION', 'sqlite')</span> で決まります。

env は .env ファイルから環境変数を読み込む関数で、ここでは DB_CONNECTION の値を参照します。  
もし .env に指定がなければ 'sqlite' が使われるため、初期状態ではSQLiteがデフォルトに設定されています。


### SQLiteの設定

Laravelの database.php にある SQLiteの設定内容 は以下の通りです。

* driver: 'sqlite'（SQLite用ドライバー）
* url: env('DB_URL')（URL形式の接続。SQLiteではほとんど使わない）
* database: env('DB_DATABASE', database_path('database.sqlite'))<br>
→ .env の DB_DATABASE を使うか、指定がなければ database/ フォルダー内の database.sqlite を使用
* prefix: ''（テーブル名の頭につける文字列。通常は空でOK）
* foreign_key_constraints: env('DB_FOREIGN_KEYS', true)（外部キーを使うか。デフォルトで有効）
* busy_timeout: null（ビジー時の待ち時間。未設定なら待たない）
* journal_mode: null（変更履歴の管理方式。デフォルトはDELETEモード）
* synchronous: null（書き込みの安全性設定。デフォルトはFULLで完全保存）

👉 基本的に デフォルトのままで問題なく使える。変更が必要なのは高度な設定をしたいときだけです。


## MySQL/PostgreSQLの設定

##### <span class="marker-yellow50">基本項目（必ず設定する必要があるもの）</span>

* driver: 使用するDBの種類（mysql または pgsql）
* host: DBサーバーの場所（IPやドメイン）
* port: 接続ポート番号
* MySQL → 3306（デフォルト）
* PostgreSQL → 5432（デフォルト）
* database: 利用するデータベース名
* username: 接続に使うユーザー名
* password: 接続に使うパスワード（必須！）

##### <span class="marker-yellow50">追加項目（必要に応じて設定）</span>

* unix_socket（MySQLのみ）: ソケットファイルの指定（通常は空でOK）
* charset: 文字コード
* MySQL → utf8mb4
* PostgreSQL → utf8
* collation（MySQLのみ）: utf8mb4_unicode_ci を指定
* prefix: テーブル名の接頭辞（通常は空）
* strict（MySQLのみ）: 厳格モード（trueでON）
* engine（MySQLのみ）: ストレージエンジンの指定（通常はnull）

これらの多くはデフォルトのままで問題ありません。最低限必要となるのは、<span class="red">host</span>, <span class="red">database</span>, <span class="red">username</span>, <span class="red">password</span>の4つでしょう。これらは、それぞれの環境に合わせて設


## .envの環境変数について

これでデータベースの設定は完了しましたが、実はもう1つ設定しておかなければいけないものがあります。それは、Laravelの「<span class="bold red">環境変数</span>」です。

Laravelでは、「<span class="bold green">.env</span>」というファイルに環境変数がまとめられています。これは、Laravelの基本的な動作環境に関する変数です。ここには、データベースに関する設定情報が以下のように記述されています。

<p class="tmp list"><span>リスト6-2</span>.env</p>
```
DB_CONNECTION=sqlite
# DB_HOST=127.0.0.1
# DB_PORT=3306
# DB_DATABASE=laravel
# DB_USERNAME=root
# DB_PASSWORD=
```

DB_CONNECTIONが、使用するデータベース名になります。それ以降のものは、すべてコメントアウトされています(SQLiteでは使わないため)。  
SQLiteの場合、これらの値を直接編集することはありません。しかし他のデータベースに切り替えるような場合、先ほどのdatabase.phpと共に、この.envにあるデータベース関係の環境変数も修正する必要がある、ということは知っておきましょう。

