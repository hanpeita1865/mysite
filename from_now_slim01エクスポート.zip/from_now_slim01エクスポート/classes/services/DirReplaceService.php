<?php
namespace SocymSlim\SlimMiddle\Services;


class DirReplaceService
{
    private FolderService $folderService;

    public function __construct(FolderService $folderService)
    {
        $this->folderService = $folderService;
    }

    public function replace(array $sortHistory, array $menuArray, array $folderObj): void
    {
        //並べ替え
        $this->folderService->sortTogether($sortHistory);
    }
}