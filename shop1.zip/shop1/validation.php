<?php
    function validation($request, $imgpath) 
    {
        $errors = [];
        $nameAry = [];

        //入力チェック
        if(empty($_POST['name'])){
            $errors[] = '商品名の入力は必須です。';
        }

        if(empty($_POST['local'])){
            $errors[] = '生産地の入力は必須です。';
        }

        if(empty($_POST['price'])){
            $errors[] = '価格の入力は必須です。';
        }elseif(!preg_match('/[0-9]+/', $_POST['price'])){
            $errors[] = '価格は数値で入力してください。';
        }

        //画像ファイルチェック
        if(preg_match('/\*|"|:|\?|<|>|\//', $imgpath)){
            $errors[] = '画像ファイル名に不適合の文字が含まれています。';
        }
        
        if(preg_match('/^\./', $imgpath)){
            $errors[] = '画像ファイル名に「.」の文字が先頭にあります。';
        }
        
        if(strpos($imgpath,' ') !== false || strpos($imgpath,'　') !== false){
            $errors[] = '画像ファイル名に空白があります。';
        }

        foreach (glob('images/*.*') as $file) {
            $nameAry[] = basename($file);//ファイル名だけを配列に格納
        }

        if(in_array($imgpath, $nameAry)){
            $errors[] = '同じ画像ファイル名が存在します';
        }

        if(empty($imgpath)){
            $errors[] = '画像が未選択です。';
        }

        return $errors; //$errorsを返す
    }

    //同じファイル名があるかチェック
    // function fileName($name){
    //     $nameAry  = [];

    //     foreach (glob('images/*.*') as $file) {
    //         $nameAry[] = basename($file);//ファイル名だけを配列に格納
    //     }

    //     if(in_array($name, $nameAry)){
    //         $exist = 'true';
    //         $errors[] = '同じ画像ファイル名が存在します';
    //     }else{
    //         $exist = 'false';
    //     }

    //     return in_array($name, $nameAry);
    // }
?>

