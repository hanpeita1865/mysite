*[page-title]:Drag & Dropで並べ替え

参考サイト
: [JavaScriptでドラッグ＆ドロップによるリストの並び替えを実装する例](https://blog.ver001.com/javascript-dragdrop-sort/)

## JavaScriptを使って並べ替える
必要最小限のコードでドラッグ＆ドロップによるリストの並び替えの実装方法です。

<div class="exp">
	<p class="tmp"><span>例1-1</span></p>
	メニューをドラッグ&ドロップすると、配置が替わります。ドラッグ中の青のボーダーは、インラインスタイルで設定しています。
	<a href="sample/sample1(js_sort)" target="_blank">新規タブ</a>
	<iframe width="100%" height="500" src="//jsfiddle.net/hirao/0pqeov93/2/embedded/result,js,html/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例1-2</span></p>
	例1-1を改修し、ボックスの間にスペースを取っています。indexOfを使って、リストの順番をdropStartとdropOver、dropDropでそれぞれ取得し、上か下かを判定して、ボーダーの表示位置とドロップする場所を決めています。<br>
	※ドラッグ時、インラインスタイルでborder-top、border-bottomを設置しています。
	<iframe width="100%" height="550" src="//jsfiddle.net/hirao/xq2unrdg/4/embedded/result,html.js,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<div class="exp">
	<p class="tmp"><span>例1-3</span></p>
	例1-2のドラッグ時のボーダーを疑似要素（before、after）で表示させています。
	<iframe width="100%" height="550" src="//jsfiddle.net/hirao/soxvqr08/5/embedded/result,html.js,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>


## jQueryでメニューの並べ替えとサブメニューの設定を行う

<div class="exp">
	<p class="tmp"><span>例2</span></p>
	メニューの並べ替えとサブメニューの設置と並び変えを行えます。
		<a href="sample/sample2(jQuery_sort)/admin/" target="_blank">新規タブ</a>
	<iframe width="100%" height="500" src="sample/sample2(jQuery_sort)/admin/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

## 並べ替えをCookieに保存

<div class="exp">
	<p class="tmp"><span>例3</span></p>
			<a href="sample/sample3(cookie_menu)" target="_blank">新規タブ</a>
	<iframe width="100%" height="500" src="sample/sample3(cookie_menu)" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

## 横並びのボックスを並び替える

参考サイト
: [HTML5 Drag and Drop APIの使用](https://web.dev/i18n/ja/drag-and-drop/)

<div class="exp">
	<p class="tmp"><span>例4</span></p>
			<a href="sample/sample4(sort_side)" target="_blank">新規タブ</a>
	<iframe width="100%" height="300" src="sample/sample4(sort_side)" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

<p class="lang">JS</p>
```
document.addEventListener('DOMContentLoaded', (event) => {

	function handleDragStart(e) {
		this.style.opacity = '0.4';

		dragSrcEl = this;

		e.dataTransfer.effectAllowed = 'move';
		e.dataTransfer.setData('text/html', this.innerHTML);
	}

	function handleDragEnd(e) {
		this.style.opacity = '1';

		items.forEach(function (item) {
			item.classList.remove('over');
		});
	}

	function handleDragOver(e) {
		if (e.preventDefault) {
			e.preventDefault();
		}

		return false;
	}

	function handleDragEnter(e) {
		this.classList.add('over');
	}

	function handleDragLeave(e) {
		this.classList.remove('over');
	}

	function handleDrop(e) {
		e.stopPropagation();

		if (dragSrcEl !== this) {
			dragSrcEl.innerHTML = this.innerHTML;
			this.innerHTML = e.dataTransfer.getData('text/html');
		}

		return false;
	}

	let items = document.querySelectorAll('.container .box');
	items.forEach(function (item) {
		item.addEventListener('dragstart', handleDragStart);
		item.addEventListener('dragover', handleDragOver);
		item.addEventListener('dragenter', handleDragEnter);
		item.addEventListener('dragleave', handleDragLeave);
		item.addEventListener('dragend', handleDragEnd);
		item.addEventListener('drop', handleDrop);
	});

});
```
