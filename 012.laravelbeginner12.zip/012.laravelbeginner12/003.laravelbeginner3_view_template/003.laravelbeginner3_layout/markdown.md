*[page-title]:レイアウトの作成


## Bladeのレイアウト定義と継承

<div markdown="1" class="d-flex">
<div markdown="1" class="">
多くのページを持つサイトでは、共通のデザインを使うためにレイアウトの継承が有効です。  
Bladeの継承は、基本レイアウトを別テンプレートで引き継ぐ仕組みになります。  

子テンプレートは、継承元にない必要な部分だけを定義すればよいです。  
セクションは、レイアウト内で埋め込むための区画で、子テンプレートで内容を埋めます。  
継承とセクションを使えば、統一感のあるページを効率よく構築できます。
</div>
![](upload/テンプレート継承.png "図　ベースとなるレイアウトを継承し、用意されたセクションに表示内容をはめ込んでいけば、同じレイアウトでページをどんどん作っていける")
</div>

### @yield &@section

セクションの利用のために、Bladeには2つのディレクティブが用意されています。  
<span class="bold green">@yield</span>と<span class="bold green">@section</span>です。この2つを使いこなすことが、レイアウト作成のポイントといって良いでしょう。

#### @sectionについて

@sectionは、Bladeテンプレートで表示区画を定義するためのディレクティブです。  
同じ名前の@yieldと組み合わせて使い、内容を指定の位置に表示できます。  
また、継承先のテンプレートで@sectionを使って内容を上書きすることも可能です。

<p class="tmp"><span>書式</span>@section</p>
```
@section( 名前)
	…… 表示内容 ……
@endsection
```

#### @yieldについて

@yieldは、指定した名前のセクションの内容を表示位置に埋め込むためのディレクティブです。  
配置場所を示すだけなので、@endのような記述は不要です。

<p class="tmp"><span>書式</span>@yield</p>
```mk
@yield(名前)
```

## ベースレイアウトを作成する

ベースレイアウトを作成するために、resources/views内にlayoutsフォルダを作り、そこにhelloapp.blade.phpというファイルを作成します。  
このファイルが共通レイアウトとして使われます。
![](upload/helloappblade作成.png)

<p class="tmp list"><span>リスト3-22</span>resources/views/layouts/helloapp.blade.php</p>
<pre><code class="hljs xml"><span class="hljs-tag">&lt;<span class="hljs-name">html</span>&gt;</span>
<span class="hljs-tag">&lt;<span class="hljs-name">head</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">title</span>&gt;</span><span class="marker-yellow">@yield('title')</span><span class="hljs-tag">&lt;/<span class="hljs-name">title</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">style</span>&gt;</span><span class="css">
  <span class="hljs-selector-tag">body</span> {<span class="hljs-attribute">font-size</span>:<span class="hljs-number">16pt</span>; <span class="hljs-attribute">color</span>:<span class="hljs-number">#777</span>; }
  <span class="hljs-selector-tag">h1</span> {<span class="hljs-attribute">font-size</span>:<span class="hljs-number">40pt</span>;<span class="hljs-attribute">text-align</span>:right;<span class="hljs-attribute">color</span>:<span class="hljs-number">#d0d0f0</span>;
    <span class="hljs-attribute">margin</span>:-<span class="hljs-number">20px</span> <span class="hljs-number">0px</span> <span class="hljs-number">0px</span> <span class="hljs-number">0px</span>;}
  <span class="hljs-selector-tag">ul</span> {<span class="hljs-attribute">font-size</span>:<span class="hljs-number">12pt</span>;}
  <span class="hljs-selector-tag">hr</span> {<span class="hljs-attribute">margin</span>:<span class="hljs-number">25px</span> <span class="hljs-number">100px</span>;<span class="hljs-attribute">border-top</span>:<span class="hljs-number">1px</span> dashed <span class="hljs-number">#ddd</span>;}
  <span class="hljs-selector-class">.menutitle</span> {<span class="hljs-attribute">font-size</span>:<span class="hljs-number">14pt</span>;<span class="hljs-attribute">font-weight</span>:bold;<span class="hljs-attribute">margin</span>:<span class="hljs-number">0px</span>;}
  <span class="hljs-selector-class">.content</span> {<span class="hljs-attribute">margin</span>:<span class="hljs-number">10px</span>; }
  <span class="hljs-selector-class">.footer</span> {<span class="hljs-attribute">text-align</span>:right;<span class="hljs-attribute">font-size</span>:<span class="hljs-number">10pt</span>;<span class="hljs-attribute">margin</span>:<span class="hljs-number">10px</span>;
    <span class="hljs-attribute">border-bottom</span>:solid <span class="hljs-number">1px</span> <span class="hljs-number">#ccc</span>;<span class="hljs-attribute">color</span>:<span class="hljs-number">#ccc</span>;}
  </span><span class="hljs-tag">&lt;/<span class="hljs-name">style</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">head</span>&gt;</span>
<span class="hljs-tag">&lt;<span class="hljs-name">body</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">h1</span>&gt;</span><span class="marker-yellow">@yield('title')</span><span class="hljs-tag">&lt;/<span class="hljs-name">h1</span>&gt;</span>
  <span class="marker-yellow">@section('menubar')</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">ul</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">p</span> <span class="hljs-attr">class</span>=<span class="hljs-string">"menutitle"</span>&gt;</span>※メニュー<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="marker-yellow">@show</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">ul</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">hr</span> <span class="hljs-attr">size</span>=<span class="hljs-string">"1"</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">div</span> <span class="hljs-attr">class</span>=<span class="hljs-string">"content"</span>&gt;</span>
    <span class="marker-yellow">@yield('content')</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">div</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">div</span> <span class="hljs-attr">class</span>=<span class="hljs-string">"footer"</span>&gt;</span>
    <span class="marker-yellow">@yield('footer')</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">div</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">body</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">html</span>&gt;</span></code></pre>

レイアウトでは、@yield('title')や@yield('content')などのディレクティブを使って各セクションの表示位置を指定します。  
メニュー表示には@section('menubar') @showのように、内容の定義と同時に即表示できる@showを使うこともあります。  

継承側のテンプレートで対応する@sectionを定義すれば、各@yieldに内容が挿入されます。


## 継承レイアウトの作成

<p class="tmp list"><span>リスト3-23</span>index.blade.php</p>
```
@extends('layouts.helloapp')

@section('title', 'Index')

@section('menubar')
  @parent
  インデックスページ
@endsection

@section('content')
  <p>ここが本文のコンテンツです。</p>
  <p>必要なだけ記述できます。</p>
@endsection

@section('footer')
copyright 2025 tuyano.
@endsection
```
![](upload/本文のコンテンツですコード.png){.photo-border}

今回は、先ほどのhelloapp.blade.phpとはうって変わって、HTMLらしい記述がほとんどないものになってしまいました。

<span class="bold marker-yellow50">@extends('layouts.helloapp')</span>で親レイアウトを継承し、@sectionで各表示内容を定義します。  
@section('title', 'Index')のように簡潔に書く方法と、@section ～ @endsectionで囲む方法があります。  

@parentを使えば、親のセクション内容も引き継げます。  

親テンプレートの@yieldに、子の@sectionがはめ込まれて表示され、共通レイアウトを保ちながら個別の内容を柔軟に記述できます。

![](upload/必要なだけ記述できます.png "図　/helloにアクセスして表示されるページ。helloapp.blade.phpのレイアウトにindex.blade.phpの内容がはめ込まれている"){.photo-border}

<!--
### サブビューについて

サブビューとは、フッターやサイドバーなどの定形コンテンツを別テンプレートとして用意し、親テンプレートに埋め込む仕組みです。
<p class="tmp"><span>書式</span></p>
```mk
@include(テンプレート名)
```
で読み込み、必要に応じて第2引数に連想配列（[ '変数名' => 値 ]）の形で変数も渡せます。シンプルな構造で、渡された変数はサブビュー内でも使用可能です。

では、「views」内の「hello」フォルダーの中に、「message.blade.php」というファイルを作成してください。
-->

### サブビューについて

サブビューとは、別のテンプレートを読み込んで表示する仕組みで、フッターやサイドバーなど定型コンテンツに使われます。  
特別なテンプレートではなく通常のテンプレートを@includeで埋め込みます。変数はコントローラーから渡されたものがそのまま使え、@include('テンプレート名', [変数])の形式で値を渡すこともできます。

<p class="tmp"><span>書式</span>インクルード</p>
```mk
@include( テンプレート名,[ …… 値の指定 …… ])
```

サブビューの作成手順は以下の通りです。  

まず、「views/hello」フォルダーにmessage.blade.phpを作成し、{{$msg_title}}や{{$msg_content}}などの変数を使ってメッセージ表示用のテンプレートを記述します。   
その後、index.blade.phpの@section('content')内で@include('hello.message')を使ってこのサブビューを読み込みます。これにより、指定した変数の内容が表示されます。

<p class="tmp list"><span>リスト3-24</span>views/hello/message.blade.php</p>
```
<style>
.message {border:double 4px #ccc;margin:10px;
  padding:10px;background-color:#fafafa;}
.msg_title {margin:10px 20px;text-color:#999;
  font-size:16pt;font-weight:bold;}
.msg_content {margin:10px 20px;text-color:#aaa;
  font-size:12pt;}
</style>
<div class="message">
  <p class="msg_title">{{$msg_title}}</p>
  <p class="msg_content">{{$msg_content}}</p>
</div>
```
<!--
message.blade.phpは、{{$msg_title}}や{{$msg_content}}などの変数を表示するシンプルなHTMLテンプレートです。  
これをサブビューとして利用するには、hello/index.blade.phpの@section('content')内で@includeを使って読み込みます。これにより、message.blade.phpの内容が埋め込まれて表示されます。
-->

@section('content')部分を以下のように修正してください。
<p class="tmp list"><span>リスト3-25</span>hello/index.blade.php</p>
```
・・・
@section('content')
  <p>ここが本文のコンテンツです。</p>
  <p>必要なだけ記述できます。</p>

  @include('hello.message', ['msg_title'=>'OK', 
    'msg_content'=>'サブビューです。'])

@endsection
・・・
```
/helloにアクセスして表示されるページ。  
helloapp.blade.phpのレイアウトにindex.blade.phpの内容がはめ込まれています。

![](upload/サブビューです表示.png){.photo-border}

@include('hello.message', ['msg_title'=>'OK', 'msg_content'=>'サブビューです。'])のように記述することで、message.blade.phpをサブビューとして読み込み、必要な変数（msg_titleとmsg_content）を配列で渡して表示できます。  

テンプレート名はviewsフォルダー内の相対パスで指定し、渡した値はそのままサブビュー内で利用されます。


## @eachによるコレクションビュー

繰り返し表示のレイアウトを切り離す際に便利なのが@eachディレクティブです。  
これは、指定したテンプレートに配列やコレクションの要素を1つずつ渡して表示する仕組みです。構文は以下の通りです

<p class="tmp"><span>書式</span>＠each</p>
```mk
@each(テンプレート名, 配列, 変数名)
```
テンプレート内では、変数を使って要素ごとの表示が行えます。リストやテーブルの繰り返し表示に適しています。

@eachを使って繰り返し表示する方法として、まずhelloフォルダの中にitem.blade.phpを作成し、各項目を次のように記述します。

<p class="tmp list"><span>リスト3-26</span>item.blade.php</p>
```
<li>{{$item['name']}} [{{$item['mail']}}]</li>
```
これは、nameとmailを持つ配列の1要素を表示するテンプレートです。

次に、index.blade.php内で以下のように@eachを使って繰り返し表示します。

@section('content')の修正です。
<p class="tmp list"><span>リスト3-28</span>index.blade.php</p>
```
@section('content')
  <p>ここが本文のコンテンツです。</p>
  
  @each('hello.item', $data, 'item')

@endsection
```

ここでは、$dataという配列の各要素がitemに渡され、item.blade.phpを使って表示されます。  
そのため、コントローラー側で$dataを用意しビューに渡す必要があります。

では、HelloController.phpのindexアクションメソッドを修正しましょう。
<p class="tmp list"><span>リスト3-28</span>HelloController.php</p>
```
public function index()
{
  $data = [
    ['name'=>'山田たろう', 'mail'=>'taro@yamada'],
    ['name'=>'田中はなこ', 'mail'=>'hanako@flower'],
    ['name'=>'鈴木さちこ', 'mail'=>'sachico@happy']
  ];
  return view('hello.index', ['data'=>$data]);
}
```

「/hello」にアクセスしてみてください。
![](upload/each名前表示.png){.photo-border}

@eachディレクティブは、['name'=>〇〇, 'mail'=>〇〇]形式の配列を繰り返し処理し、テンプレートに値を渡して表示する便利な仕組みです。テンプレート名を変えるだけで表示内容を柔軟に変更でき、データ表示が多いアプリに特に有効です。

※表示部品をさらに高度に扱うには「コンポーネント」という仕組みがありますが、これは5章で説明されます。