---
title: (移動済)制御構造の代替構文
taxonomy:
    category:
        - docs
---

**if** 、**for** 、**foreach** と **while** といった制御構造について簡略化した形式で記述することができます。  
これも、覚えておくとコードが読みやすくなってよいです。

例えば下記は **foreach** を使用した場合の例です:

```html
<ul>
<?php foreach ($todo as $item): ?>
        <li><?=$item?></li>
<?php endforeach; ?>
</ul>
```
波括弧がないことに注意してください。そのかわりに、波括弧は **endforeach** に置き換えられています。上に列挙した制御構造にはそれぞれ、 同様の閉じ構文があります。
**endif** 、 **endfor** 、 **endforeach** 、および **endwhile**

また、各構造のうしろにはセミコロンを使用するのではなく、かわりに***コロン***があることに注意してください (ただし最後のものを除く) 。これは重要です！

<p class="tmp"><span>書式1</span>foreach</p>
```
<?php foreach (配列 as 変数): ?>
        ～HTML文 <?=変数?> ～
<?php endforeach; ?>
```

## if文

<p class="tmp"><span>書式2</span>if文</p>
```
<?php if (条件式): ?>
　一致した時
<?php else: ?>
　一致しない時
<?php endif; ?>

```

<iframe src="https://paiza.io/projects/e/H7dDlZtwZmpDEtx6nS3fCw?theme=twilight" width="100%" height="300" scrolling="no" seamless="seamless"></iframe>

##### (例)　if～elseif～else～
```
<?php if ($username === 'sally'): ?>
	<h3>こんにちはサリー</h3>
<?php elseif ($username === 'joe'): ?>
	<h3>こんにちはジョー</h3>
<?php else: ?>
	<h3>こんにちは知らない人</h3>
<?php endif; ?>
```

### 否定

<p class="tmp"><span>書式3</span></p>

```
等しくない：$値1 != $値2
（$値1 が $値2 に等しくない場合にTRUEを返します。）
または、
等しくない：$値1 <> $値2
（$値1 が $値2 に等しくない場合にTRUEを返します。）
```

<iframe src="https://paiza.io/projects/e/eik_EqqzTZItHUceFcZCag?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## for文

<iframe src="https://paiza.io/projects/e/EIRDByX0Z-AbkaGD01x-8Q?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式4</span></p>
```
<?php for ($i = 0; $i < 10; $i++): ?>
     ～HTML文1～
<?php endfor; ?>
```

## switch文

<iframe src="https://paiza.io/projects/e/88sa8ASogH7L_jGwzJiwfw?theme=twilight" width="100%" height="400" scrolling="no" seamless="seamless"></iframe>

<p class="tmp"><span>書式5</span></p>
```
<?php switch (変数): ?>
<?php case 値1: ?>
      ～HTML文1～
    <?php break; ?>
<?php case 値2: ?>
      ～HTML文2～
    <?php break; ?>
<?php case 値3: ?>
      ～HTML文3～
    <?php break; ?>
<?php endswitch; ?>
```

## while文

```
<?php while ($condition): ?>
    <p>Do something in HTML</p>
<?php endwhile; ?>
```