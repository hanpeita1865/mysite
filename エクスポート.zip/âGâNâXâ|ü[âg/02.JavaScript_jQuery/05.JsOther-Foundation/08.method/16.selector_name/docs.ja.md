---
title: 要素名を取得
taxonomy:
    category:
        - docs
---

<iframe width="100%" height="300" src="//jsfiddle.net/kf8vdyeu/embedded/js,html,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>


## 参考サイト

[jQueryで要素名を取得する](https://qiita.com/_shimizu/items/50ccf226ee8bd2e02054)