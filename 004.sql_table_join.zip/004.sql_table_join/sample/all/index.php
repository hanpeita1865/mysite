<!DOCTYPE html>
<head>
    <style>
        table {
            width: 300px;
            border: 1px solid #555;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th,td {
            border: 1px solid #555;
        }
        td {
            text-align: right;
        }
    </style>
</head>
<table>
<caption>fruitテーブル</caption>
<tr><th>id</th><th>name</th></tr>
<?php
$pdo=new PDO('mysql:host=localhost;dbname=join_test;charset=utf8', 'root', '');

foreach ($pdo->query('select * from fruits') as $row) {
    echo '<tr>';
    echo '<td>'.$row['id'].'</td>';
    echo '<td>'.$row['name'].'</td>';
    echo '</tr>';
}
?>
</table>

<table>
<caption>priceテーブル</caption>
<tr><th>fruit_id</th><th>price</th></tr>
<?php
foreach ($pdo->query('select * from price') as $row) {
    echo '<tr>';
    echo '<td>'.$row['fruit_id'].'</td>';
    echo '<td>'.$row['price'].'</td>';
    echo '</tr>';
}
?>
</table>


<table>
<caption>fruitとpriceのテーブルを結合</caption>
<tr><th>id</th><th>name</th><th>price</th></tr>

<?php
foreach ($pdo->query('SELECT * FROM fruits LEFT OUTER JOIN price ON fruits.id=price.fruit_id') as $row) {
    echo '<tr>';
    echo '<td>'.$row['id'].'</td>';
    echo '<td>'.$row['name'].'</td>';
    echo '<td>'.$row['price'].'</td>';
    echo '</tr>';
}
?>
</table>




















