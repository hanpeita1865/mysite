Vue.createApp({})
  .use(ElementPlus, {
    locale: ElementPlusLocaleJa
  })
  .mount('#app');
