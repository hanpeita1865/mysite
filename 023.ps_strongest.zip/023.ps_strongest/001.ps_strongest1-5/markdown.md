*[page-title]:ツールパネルについて


<div markdown="1" class="d-flex">
<div markdown="1" class="d-flex flex-column">
[![](upload/ツールパネル構成について.png)](upload/ツールパネル構成について.png){.image}

[![](upload/ツールや機能を検索する.png)](upload/ツールや機能を検索する.png){.image}

[![](upload/ツールパネルを2列で表示.png)](upload/ツールパネルを2列で表示.png){.image}
</div>

[![](upload/ツールパネル.jpg)](upload/ツールパネル.jpg){.image}
</div>