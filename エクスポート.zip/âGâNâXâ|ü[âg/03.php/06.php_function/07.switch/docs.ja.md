---
title: (移動済)switch文、for文
visible: true
---

## switch文
<p class="tmp"><span>書式1</span></p>
※javascriptと書き方は同じ

```
switch ( 式 ) {
//式が値と合致したときに処理を行い、どれにも合致しなかった場合defaultの処理を行う。
case 値1 :
	処理;
	break;
case 値2 :
	処理;
	break;
default :
	処理;
	break;
}
```

#### 例1
<!--
<iframe src="https://paiza.io/projects/e/tMsyTdFgGN4nA27J1pYCzg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>
-->
<iframe src="https://paiza.io/projects/e/6pbgbwq3qmfG-_0zrmcQIA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

#### 例2　breakを付けずに OR条件での分岐

該当したcaseから、次のbreakまでは処理が実行される性質を利用し、いずれかに該当した場合といった条件分岐もできます。
<iframe src="https://paiza.io/projects/e/pTiN9H-yQyI8XIKUvWdYfg?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

## for文
$iが0から始まり、5になるまで処理を繰り返す。
<iframe src="https://paiza.io/projects/e/BwN2YzyA15GCOf0SWbVv4g?theme=twilight" width="100%" height="300" scrolling="no" seamless="seamless"></iframe>

### break処理
$1が3になったら、処理を終了させます。
<iframe src="https://paiza.io/projects/e/j9Eut6nRhmfRvhC1x6IqaQ?theme=twilight" width="100%" height="300" scrolling="no" seamless="seamless"></iframe>






