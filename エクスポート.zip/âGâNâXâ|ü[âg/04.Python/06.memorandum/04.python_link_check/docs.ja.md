---
title: リンク切れチェック
taxonomy:
    category:
        - docs
---

requests
: HTTP通信を行うためのライブラリです。  
http://requests-docs-ja.readthedocs.io/en/latest/

コマンドプロンプトを起動して、下記を実行してBeautifulSoupをインストールします。
```
pip install requests
```
BeautifulSoup
: HTMLやXMLファイルからデータを取り出すためのライブラリです。  
<https://www.crummy.com/software/BeautifulSoup/bs4/doc/>

コマンドプロンプトを起動して、下記を実行してBeautifulSoupをインストールします。
```
$ pip install beautifulsoup4
```
<p class="tmp list"><span>ソース</span></p>
```
import requests
from bs4 import BeautifulSoup
 
# アクセスするURL
resp = requests.get("https://www.google.co.jp/")
 
# BeauttifulSoupを使用してHTML整形
soup = BeautifulSoup(resp.text, 'html.parser')
 
# aタグからURLを取得し、HTTPリクエストを送る
for link in soup.find_all('a'):
 
    # URLを取得し、HTTPリクエスト
    url = link.get('href')
    if url is None:
        continue
    elif url == '#':
        continue
    resp = requests.get(url)
 
    # 結果をCSVに出力する
    f = open('test.csv','a')
    f.write(str(resp.status_code) + ',' + url + '\n')
    f.close()
```
    
実行すると、リンクのリストが書かれたtest.csvが出力されていればOKです。
    
 ## 参考サイト
 * [5分でできる！Python3を利用した自動リンクチェッカーの開発](https://engineers.weddingpark.co.jp/python/)
    
    
    