*[page-title]:メニュー生成

<div class="exp">
	<p class="tmp"><span>例1-1</span></p>
	下記のように指定したディレクトリ内のフォルダ（p_～）のメニューを生成するコードです。
	<a href="http://localhost:7001/test/php/file_exists1/index.php" trget="_blank">新規タブ（file_exists1）</a>
</div>

<div markdown="1" class="d-flex justify-content-around align-items-center max-wpx700 mx-auto">
![](upload/menu_list.png "図　フォルダ構成")
<p class="fz-15">➡</p>
![](upload/pages_dir2表示結果.png "図　メニュー生成")
</div>

```
<?php

globAll('p_test');

function globAll($folder) {
    if (!is_file($folder)) {

        $res = glob($folder . '/*'); //Array ( [0] => p_test/p_test1 [1] => p_test/p_test2 ) 
        // print_r($res);

        foreach ($res as $key => $f) {
            // echo $f; //p_test/p_test1 , p_test/p_test2
            $dirArray = explode('/', $f);
            // print_r($dirArray);//Array ( [0] => p_test [1] => p_test1 ) , Array ( [0] => p_test [1] => p_test2 )
            $lastDir = end($dirArray); //配列の最後の値
            // echo $lastDir; //p_test1 , p_test2

            //配列の最後の値が「p__」の場合、リストで表示
            if (preg_match('/^p_/', $lastDir)) {
                echo '<li>'.$lastDir;

                //ディレクトリ($f)内にpフォルダがあるか判定 テスト
                $res1 = glob($f . '/*');
                $pBool = false;
                foreach ($res1 as $key1 => $f1) {
                    $dirArray1 = explode('/', $f1);
                    $lastDir1 = end($dirArray1);
                    if (preg_match('/^p_/', $lastDir1)) {
                        $pBool = true;
                    }
                }
                // echo $pBool;
                if($pBool){
                    // echo 'ありますよ!!';
                    echo '<ul>';
                }
                //判定ここまで

                globAll($f);

                if($pBool){
                    // echo 'ありますよ!!';
                    echo '</ul>';
                }

                echo '</li>';
            }
        }
    }
}
```


<div class="exp">
	<p class="tmp"><span>例1-2</span></p>
	フォルダ名が「〇〇.～」のフォルダ構成のメニュー生成を行います。
	<a href="http://localhost:7001/test/php/file_exists1-1/index.php" trget="_blank">新規タブ（file_exists1-1）</a>
</div>

<div markdown="1" class="d-flex justify-content-around align-items-center max-wpx700 mx-auto">
![](upload/exist1-1フォルダ構成.png  "図　フォルダ構成")
<p class="fz-15">➡</p>
![](upload/exist1-1フォルダ構成生成.png "図　メニュー生成")
</div>


<div class="exp">
	<p class="tmp"><span>例2</span></p>
	フォルダ名が数字「〇〇.」の場合に、リストで表示するようにしています。
	<a href="http://localhost:7001/test/php/file_exists2/index.php" trget="_blank">新規タブ（file_exists2）</a>
</div>

<div markdown="1" class="d-flex justify-content-around align-items-center max-wpx700 mx-auto">
![](upload/pages_dir2.png "図　フォルダ構成")
<p>➡</p>
![](upload/pages_dir2表示結果.png "図　表示結果")
</div>

```
<?php

globAll('pages');

function globAll($folder) {
    if (!is_file($folder)) {

        $res = glob($folder . '/*'); 

        foreach ($res as $f) {
            $dirArray = explode('/', $f);
            $lastDir = end($dirArray); //配列の最後の値

            //配列の最後の値が数字「〇〇.」の場合、リストで表示
            if (preg_match('/^\d{2}./', $lastDir)) {

                $md = file_get_contents($f.'/markdown.md'); //マークダウンの内容を変数に格納
                preg_match("/^\*\[page-title\]:\s*(.+)/", $md, $ArrayTitle);

                $lastDir = preg_replace('/^\d{2}./', '',$lastDir);

                echo '<li>'.$lastDir;

                //ディレクトリ($f)内にpフォルダがあるか判定 テスト
                $res1 = glob($f . '/*');
                $pBool = false;
                foreach ($res1 as $f1) {
                    $dirArray1 = explode('/', $f1);
                    $lastDir1 = end($dirArray1);
                    if (preg_match('/^\d{2}./', $lastDir1)) {
                        $pBool = true;
                    }
                }

                if($pBool){
                    // echo 'ありますよ!!';
                    echo '<ul>';
                }

                globAll($f);

                if($pBool){
                    // echo 'ありますよ!!';
                    echo '</ul>';
                }

                echo '</li>';
            }
        }
    }
}
?>
```

<div class="exp">
	<p class="tmp"><span>例3</span></p>
	複数階層まであるディレクリーのフォルダを同一階層にします。<br>
	pages内のフォルダをpages_copyに移動する際に、同一階層になるようになっています。
	<a href="http://localhost:7001/test/php/file_exists3/index.php" trget="_blank">新規タブ（file_exists3）</a>
</div>

<div markdown="1" class="d-flex justify-content-around align-items-center max-wpx700 mx-auto">
![](upload/pages_dir2.png "図　pagesフォルダ構成")
<p class="fz-15">➡</p>
![](upload/exist3_pages_copy.png "図　pages_copyフォルダ構成")
</div>

<span class="red">※「psges」「pages_copy」フォルダの設置している階層が違う場合は、「../pages」「../pages_copy」のように変える。</span>

次の3か所のコードを変更
```
globAll('pages');
・・・
path2 = 'pages_copy/'.$lastDir;
・・・
globAll('pages');
```

<div class="exp">
	<p class="tmp"><span>例4</span></p>
	〇〇.フォルダ名の〇〇.の数字を順番通りに書き換える。
</div>

<div markdown="1" class="d-flex justify-content-around align-items-center max-wpx700 mx-auto">
![](upload/exist1-1フォルダ構成.png  "図　フォルダ構成")
<p class="fz-15">➡</p>
![](upload/exist1-1フォルダ構成生成.png "図　メニュー生成")
</div>

<div class="exp">
	<p class="tmp"><span>例5</span></p>
	フォルダを再生成します。
	<a href="http://localhost:7001/test/php/file_exists5/index.html">新規タブ</a>
</div>

<div markdown="1" class="d-flex justify-content-around align-items-center max-wpx700 mx-auto">
![](upload/exist5メニュー1.png "図　メニュー")
<p class="fz-15">➡</p>
![](upload/exist5フォルダ再生成.png "図　フォルダ再生成")
</div>


