*[page-title]:セクション1（開発環境）


## 9.クオーテーション記号の違い

参考サイト
: [echo公式ドキュメント](https://www.php.net/manual/ja/function.echo.php)
: [エスケープシーケンスの種類と使い方](https://www.javadrive.jp/php/string/index4.html)


改行`\n`を使用する場合、文字列を「<span class="red bold">"</span>（ダブルクォーテーション）」で囲みます。「<span class="green bold">'</span>（シングルクォーテーション）」だと改行されません。

ただし、普段echoで文字列などを囲むときには、「<span class="green bold">'</span>（シングルクォーテーション）」を使う方が事故が起きにくくなります。


## 10.複数行のテキストを表示しよう-ヒアドキュメント、Nowdoc

参考サイト
: [文字列](https://www.php.net/manual/ja/language.types.string.php)

### ヒアドキュメント

PHPのヒアドキュメント構文（<<<）では、開始IDを指定し、その後に文字列を書き、同じ終端IDで文字列を終了します。終端IDはインデント可能で、行頭のインデントが自動で取り除かれます（PHP 7.3.0以降）。終端IDは<span class="red">英数字とアンダースコアを含み、数字以外で始める必要があります</span>。

ヒアドキュメントを使用して文章を表示してみます。

<pre><code class="hljs php"><span class="hljs-meta">&lt;?php</span>
<span class="marker-yellow"><span class="hljs-keyword">echo</span> &lt;&lt;&lt; EOT</span>
吾輩は猫である。
名前はまだ無い。
どこで生れたかとんと見当がつかぬ。
何でも薄暗いじめじめした所でニャーニャー泣いていた事だけは記憶している。
<span class="marker-yellow">EOT;</span></code></pre>

※EOTの箇所は、ABCなど何でもいいです。同じキーワードの間にある文字が表示されます。  
ここで使っている「EOT」は、END OF TEXTの略でよく使用されています。また、大文字を使うのが一般的です。


<p class="result"><span>表示結果</span></p>
![](upload/sample03ヒアドキュメント.png)

ヒアドキュメントは二重引用符なしで記述しますが、動作は二重引用符の文字列と同じです。変数は展開され、エスケープシーケンスも使用できます。ただし、複雑な変数展開には注意が必要です。


### Nowdoc

Nowdocはヒアドキュメントに似ていますが、<span class="red">シングルクォート扱い</span>となり、変数展開やエスケープ処理が行われません。そのため、PHPコードや大量のテキストの埋め込みに便利です。

書き方は <<<'EOT' のように識別子をシングルクォートで囲み、識別子のルールはヒアドキュメントと同じです。

```
echo "\n ■ Nowdoc\n";

echo <<< 'EOT'
吾輩は猫である。\n
名前はまだ無い。
EOT;

echo "\n";
echo '\n';
```

<p class="result"><span>表示結果</span></p>
![](upload/sample3Nowdoc表示結果.png)


## 11.コメントをプログラムコードに挿入しよう

コメントを書くには、頭に「//」か「#」を付けます。一般的には、「//」を使います。  
複数行のコメントを書くときは、/*～*/で書くとよいです

```
<?php
// 画面にメッセージを出す
# １行でコメントを残せます
echo "コメントを学習しています";

// 複数行の
// コメントです

/*
複数行の
コメントです
*/
echo "２つめのプログラムです";
```

## 12.算術演算子(代数演算子)

参考サイト
: [算術演算子](https://www.php.net/manual/ja/language.operators.arithmetic.php)
: [演算子の優先順位 ](https://www.php.net/manual/ja/language.operators.precedence.php)

### 演算子の優先順位 

PHPでは、演算子の優先順位によって式の評価順が決まります。例えば 1 + 5 * 3 は、* の方が優先順位が高いため 1 + (5 * 3) と評価されて16になります。優先順位を変更したい場合は括弧を使います。

同じ優先順位の演算子が並ぶ場合、評価順は「結合性」に従い、左結合なら左から、右結合なら右から評価されます（例：- は左結合、= は右結合）。優先順位が同じで結合しない演算子は併用できません。

単項演算子には結合性は関係ありません。括弧を使って明示的にグループ分けすることで、可読性が向上し、誤解を防げます。

```
<?php
echo 1+2+3*4;
```
<p class="lang">結果</p>
```
15
```

```
<?php
echo (1+2+3)*4;
```
<p class="lang">結果</p>
```
24
```

## 13.変数とは

PHP の変数はドル記号の後に変数名が続く形式で表されます。 変数名は大文字小文字を区別します。

変数名は、文字 (A-Z, a-z, 128から255 までのバイト) で始まり、 任意の数の文字、 数字、アンダースコアが続きます。正規表現を使うと、これは次の ように表現することができます。

`^[a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*$`

日本語でも使えますが、できれば英語がいいです。

使える変数
```
$x;
$number_123;
$_123;
$番号;
```

<span class="red">使えない変数</span>
```
$123 = 10; // ×
$number-123 = 10; // ×
$_SERVER = 10; // ×
```

## 14.クオーテーション記号での処理の違い

変数をダブルクォーテーションで囲むと、変数の値が表示されます。
```
$price = 100;
echo "$price";
```
上記を実行すると、100が表示されます。

ダブルクォーテーションの中に変数を入れると、そのまま値を表示してくれるので便利です。
<p class="lang">例）</p>
```
$price = 100;
echo '50 + 50 は、', $price, ' です';
```
<p class="result"><span>表示結果</span></p>
```
50 + 50 は、100 です
```

英数字を変数の直後に続けたいときは、次のように「{}」で囲むと動作します。
```
$number = 10;
echo "{$number}th anniversary"; // 10th anniversary
```
<p class="result"><span>表示結果</span></p>
```
10th anniversary
```
ただし、シングルクオーテーションを使う方がわかりやすいです。

## 15. 定数とは

参考サイト
: [定数](https://www.php.net/manual/ja/language.constants.php)
: [define](https://www.php.net/manual/ja/function.define.php)
: [【完全ガイド】PHPのdefineとは？基本から応用まで使いこなす7つのテクニック](https://dexall.co.jp/articles/?p=3477)
: [PHPの定数完全ガイド：constとdefineの違いから実践的な活用法まで【2025年最新】](https://dexall.co.jp/articles/?p=3685)

定数を定義するには、constやdefine()をあります。constの方が新しいのでこちらを使うとよいです。defineは将来的に廃止される可能性があります。
```
<?php
const TAX = 10;
//define(TAX, 10);

echo "消費税は、", TAX, "%です";
```
※定数では、ダブルクォーテーション内で「{}」を使うことはできません。表示するときは、上記のように記述します。


## 16.ファンクション(関数)とパラメーター

参考サイト
: [number_format](https://www.php.net/manual/ja/function.number-format.php)
: [string関数](https://www.php.net/manual/ja/ref.strings.php)

```php
$sum = 10005000 + 150;
$sum = number_format($sum);
//$sum = number_format(1234.126, 2); //小数点第2まで四捨五入して表示
// $sum = number_format(1234.126, 2, ';', ':');
echo $sum, '円です';
```

number_format()を使うと、数字に「,」が付きます。

## 17.キーボードからの入力を受け取ろう
参考サイト
: [fgets](https://www.php.net/manual/ja/function.fgets.php)
: [入出力ストリーム](https://www.php.net/manual/ja/features.commandline.io-streams.php)
: [trim](https://www.php.net/manual/ja/function.trim.php)

```
<?php
echo '数字を入力してください';
$number = trim(fgets(STDIN));
echo $number, 'ですね？';
```
10を記入すると、10ですね？と表示されます。
```
数字を入力してください10
10ですね？
```

STDINとは
: stdin へのオープン済みのストリーム。 これにより、以下のようにオープンする必要がなくなります。（ユーザーからの入力値を受け付けます）

```
<?php
$stdin = fopen('php://stdin', 'r');
?>
```

stdin から1行読み込みたい場合、以下のようにします。
```
<?php
$line = trim(fgets(STDIN)); // STDIN から 1 行読み込む
fscanf(STDIN, "%d\n", $number); // STDIN から数値を読み込む
?>
```

trim — 文字列の先頭および末尾にあるホワイトスペースを取り除く

 trim()は以下の文字を削除します。
```
" ": ASCII の SP 文字 0x20 、通常のスペース。
"\t": ASCII の HT 文字 0x09 、タブ。
"\n": ASCII の LF 文字 0x0A 、改行（ラインフィード）。
"\r": ASCII の CR 文字 0x0D 、キャリッジリターン。
"\0": ASCII の NUL 文字 0x00 、NULバイト。
"\v": ASCII VT 文字 0x0B 、垂直タブ。
```

> コードをコピーペーストしていると覚えないので、できるだけ手打ちで入力するようにしましょう。

## 18.[実践]簡易計算機を作ろう

```
<?php
echo '足される数 >';
$number1 = trim(fgets(STDIN));

echo '足す数 >';
$number2 = trim(fgets(STDIN));

echo "$number1 + $number2 =", $number1 + $number2;
```

実行すると、足される数と足す数を聞いてきます。
![](upload/足される数と足す数.png)