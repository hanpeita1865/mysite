// This sample still does not showcase all CKEditor 5 features (!)
// Visit https://ckeditor.com/docs/ckeditor5/latest/features/index.html to browse all the features.
CKEDITOR.ClassicEditor.create(document.getElementById("body"), {
    // plugins: [ HtmlEmbed],
    // https://ckeditor.com/docs/ckeditor5/latest/features/toolbar/toolbar.html#extended-toolbar-configuration-format
    toolbar: {
        items: [
            //'exportPDF','exportWord', '|',
            'undo', 'redo', '|',
            'heading', '|',
            'bold', /*'italic',*/ 'strikethrough', 'underline', /*'code',*/ 'subscript', 'superscript', /*'removeFormat',*/ '|',
            'fontSize', /*'fontFamily',*/ 'fontColor', 'fontBackgroundColor', 'highlight', '|',
            'alignment', '|',
            'bulletedList', 'numberedList', /*'todoList',*/ '|',
            'outdent', 'indent', '|',
            'findAndReplace', 'selectAll', '|',
            // '-',
            'sourceEditing', '|',
            'link', 'insertImage', 'blockQuote', 'insertTable', 'mediaEmbed',/* 'codeBlock',*/ 'htmlEmbed', '|',
            'specialCharacters', 'horizontalLine', /*'pageBreak',*/ '|',
            //'textPartLanguage', '|',
        ],
        shouldNotGroupWhenFull: true
    },

    // Changing the language of the interface requires loading the language file using the <script> tag.
    // language: 'es',
    list: {
        properties: {
            styles: true,
            startIndex: true,
            reversed: true
        }
    },
    // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
    heading: {
        options: [
            { model: 'paragraph', title: '見出し', class: 'ck-heading_paragraph' },
            { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
            { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
            { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
            { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' },
            { model: 'heading5', view: 'h5', title: 'Heading 5', class: 'ck-heading_heading5' },
            { model: 'heading6', view: 'h6', title: 'Heading 6', class: 'ck-heading_heading6' }
        ]
    },
    // https://ckeditor.com/docs/ckeditor5/latest/features/editor-placeholder.html#using-the-editor-configuration
    placeholder: 'ここに記入してください。',
    // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-family-feature
    // fontFamily: {
    //     options: [
    //         'default',
    //         'Arial, Helvetica, sans-serif',
    //         'Courier New, Courier, monospace',
    //         'Georgia, serif',
    //         'Lucida Sans Unicode, Lucida Grande, sans-serif',
    //         'Tahoma, Geneva, sans-serif',
    //         'Times New Roman, Times, serif',
    //         'Trebuchet MS, Helvetica, sans-serif',
    //         'Verdana, Geneva, sans-serif'
    //     ],
    //     supportAllValues: true
    // },
    // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-size-feature
    fontSize: {
        options: [10, 12, 14, 'default', 18, 20, 22],
        supportAllValues: true
    },
    // Be careful with the setting below. It instructs CKEditor to accept ALL HTML markup.
    // https://ckeditor.com/docs/ckeditor5/latest/features/general-html-support.html#enabling-all-html-features
    htmlSupport: {
        allow: [
            {
                name: /.*/,
                attributes: true,
                classes: true,
                styles: true
            }
        ]
    },
    // Be careful with enabling previews
    // https://ckeditor.com/docs/ckeditor5/latest/features/html-embed.html#content-previews
    htmlEmbed: {
            showPreviews: true,
            sanitizeHtml: ( inputHtml ) => {
            // Strip unsafe elements and attributes, e.g.:
            // the `<script>` elements and `on*` attributes.
            const outputHtml = sanitize( inputHtml );

            return {
                html: outputHtml,
                // true or false depending on whether the sanitizer stripped anything.
                hasChanged: true
            };
        }
    },
    // https://ckeditor.com/docs/ckeditor5/latest/features/link.html#custom-link-attributes-decorators
    // link: {
    // 	decorators: {
    // 		addTargetToExternalLinks: true,
    // 		defaultProtocol: 'https://',
    // 		toggleDownloadable: {
    // 			mode: 'manual',
    // 			label: 'Downloadable',
    // 			attributes: {
    // 				download: 'file'
    // 			}
    // 		}
    // 	}
    // },

    // link: {
    // 	// Automatically add target="_blank" and rel="noopener noreferrer" to all external links.
    // 	addTargetToExternalLinks: true,

    // 	// Let the users control the "download" attribute of each link.
    // 	decorators: [
    // 		{
    // 			mode: 'manual',
    // 			label: 'Downloadable',
    // 			attributes: {
    // 				download: 'download'
    // 			}
    // 		},
    // 	]
    // },

    link: {
        addTargetToExternalLinks: true,

        decorators: {
            detectDownloadable: {
                mode: 'automatic',
                callback: url => url.endsWith( '.txt' ),
                attributes: {
                    download: 'file.txt'
                }
            }
        }
    },

    // https://ckeditor.com/docs/ckeditor5/latest/features/mentions.html#configuration
    mention: {
        feeds: [
            {
                marker: '@',
                feed: [
                    '@apple', '@bears', '@brownie', '@cake', '@cake', '@candy', '@canes', '@chocolate', '@cookie', '@cotton', '@cream',
                    '@cupcake', '@danish', '@donut', '@dragée', '@fruitcake', '@gingerbread', '@gummi', '@ice', '@jelly-o',
                    '@liquorice', '@macaroon', '@marzipan', '@oat', '@pie', '@plum', '@pudding', '@sesame', '@snaps', '@soufflé',
                    '@sugar', '@sweet', '@topping', '@wafer'
                ],
                minimumCharacters: 1
            }
        ]
    },

    // The "super-build" contains more premium features that require additional configuration, disable them below.
    // Do not turn them on unless you read the documentation and know how to configure them and setup the editor.
    removePlugins: [
        // These two are commercial, but you can try them out without registering to a trial.
        // 'ExportPdf',
        // 'ExportWord',
        'CKBox',
        'CKFinder',
        'EasyImage',
        // This sample uses the Base64UploadAdapter to handle image uploads as it requires no configuration.
        // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/base64-upload-adapter.html
        // Storing images as Base64 is usually a very bad idea.
        // Replace it on production website with other solutions:
        // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/image-upload.html
        // 'Base64UploadAdapter',
        'RealTimeCollaborativeComments',
        'RealTimeCollaborativeTrackChanges',
        'RealTimeCollaborativeRevisionHistory',
        'PresenceList',
        'Comments',
        'TrackChanges',
        'TrackChangesData',
        'RevisionHistory',
        'Pagination',
        'WProofreader',
        // Careful, with the Mathtype plugin CKEditor will not load when loading this sample
        // from a local file system (file://) - load this site via HTTP server if you enable MathType
        'MathType'
    ]
})
    .then(newEditor => {
        editor = newEditor;
        let editorData = editor.getData();
        editorData = editorData.replace('<p>{{{</p>', '').replace('<p>}}}</p>', '').replace('<p>{{{}}}</p>', '');
        editorData = editorData.trim();
        editor.setData(editorData);

        // クリックやエンターを押したり、入力すると実行される。
        // editor.model.document.on( 'change', () => {
        // } );

        // データの変更のみ
        // editor.model.document.on( 'change:data', () => {
        // } );

        // クリックした位置に「foo」が挿入される
        // editor.model.document.on( 'change', () => {
        // 	editor.model.change( writer => {
        // 		writer.insertText( 'foo', editor.model.document.selection.getFirstPosition() );
        // 	} );
        // } );

        // クリックした位置に「foo」が挿入される
        // editor.model.document.on( 'change', () => {
        // 	editor.model.change( writer => {
        // 		writer.insertText( 'foo', editor.model.document.selection.getFirstPosition() );
        // 	} );
        // } );

        //ボタンをクリックでテキストを挿入
        // document.getElementById('insert').addEventListener('click', function () {
        // 	let imgCode = 'テキスト';
        // 	editor.model.change(writer => {
        // 		writer.insertText(imgCode, editor.model.document.selection.getFirstPosition());
        // 	});
        // }, false);

        //ボタンをクリックでリンクを挿入→うまくいかなかった
        // document.getElementById('insert').addEventListener('click', function () {
        // 	let imgCode = 'http://localhost:9840/sugu_cms/sugu_webdir/1/sample.txt';
        // 	editor.model.change(writer => {
        // 		writer.insertText(imgCode, editor.model.document.selection.getFirstPosition());
        // 		//writer.setAttribute( imgCode, href, linkRange );
        // 	});
        // }, false);

        //ボタンをクリックで画像を挿入
        // document.getElementById('insert').addEventListener('click', function () {
        // 	editor.execute( 'insertImage', { source: 'http://localhost:9840/sugu_cms/sugu_webdir/1/s_0-09.png' } );
        // }, false);

        //記事に画像を挿入
        document.querySelectorAll('.insert-image').forEach(function(elm){
            elm.addEventListener('click', function(e){
                let href = e.target.closest('.sugu-control-group').querySelector('.current_image').getAttribute('href');
                editor.execute( 'insertImage', { source: href } );
            });
        });

        const regexp = new RegExp(/.jpg$|.jpeg$|.jpe$|.jfif$|.png$|.gif$|.svgx$|webp$/i);

        //記事に画像・ファイルを挿入（添付用コントロール）
        document.querySelectorAll('.insert-file').forEach(function(elm){

            let id = elm.getAttribute('data-id');
            let href = document.getElementById(id).getAttribute('href');
            let fileTextid = id.replace('current_file_', 'current_file_text,');
            let fileLinkId = id.replace('current_file_', 'current_file_link,');
            //current_file_2
            //current_file_link,2

            //画像以外か判定
            if(regexp.test(href)){
                //画像の場合、「挿入ボタン」を表示、ファイルリンクを非表示
                elm.classList.add('d-block');
                document.getElementById(fileTextid).classList.add('d-none');
                document.getElementById(fileTextid).previousElementSibling.classList.add('d-none');

            }else{
                //ファイルリンクの場合、リンクを絶対パスで表示
                let arr = absolutePath(href).split("/").slice(-1)[0] //スラッシュで分割して配列をつくる
                let repHref = absolutePath(href).replace(arr, document.getElementById(fileTextid).value)
                document.getElementById(fileLinkId).value = repHref;
            }

            //相対パスを絶対パスに変換
            function absolutePath(path) {
                let baseUrl = location.href;
                let url = new URL(path, baseUrl);
                return url.href;
            }


            elm.addEventListener('click', function(e){

                id = e.target.getAttribute('data-id');
                href = document.getElementById(id).getAttribute('href');

                if(regexp.test(href)){
                    //画像
                    editor.execute( 'insertImage', { source: href } );
                }else{
                    //添付ファイル
                    // const path = href.split("/");
                    // const text = path.slice(-1)[0];
                    // const link = '<a href="'+ path + '" target"_blank">' + text + '</a>';

                    // link1 = 'http://localhost:9840/sugu_cms/sugu_webdir/1/sample.txt';

                    // editor.model.change(writer => {
                    // 	writer.insertText(link1 , editor.model.document.selection.getFirstPosition())
                    // });
                }
            });
        });		
    })
    .catch(error => {
    });