*[page-title]:FullCalendar

関連ファイル
: C:\Users\hirao\Desktop\test\calendar

公式サイト
: https://fullcalendar.io/

FullCalendarオプション
: FullCalendarをカスタマイズするには、下記の公式ドキュメントを参照してください。
: https://fullcalendar.io/docs
: 数多くのオプションが用意されています。

サンプル（基本）
: <http://localhost:7000/test/calendar/sample/>

コードペン
: https://codepen.io/hashikaru/pen/jOrByXN

## 祝日設定
 
参考サイト
: [FullCalendarでカレンダー実装](https://www.w2solution.co.jp/tech/2021/02/21/fullcalendar%E4%BD%BF%E3%81%84%E6%96%B9/)
: [Holidays JP API](https://holidays-jp.github.io/)

### ◆祝日表示
日本の祝日はよく変動します。  
コード内に祝日データを書いてメンテナンスするより、Googleカレンダの祝日情報APIを利用したほうが便利だと思います。  
Holidays JP APIはGoogleカレンダー情報をAPIとして提供しています。  
直近3年分の祝日しか取れませんが、一般の開発では十分使えます。  

Holidays JP APIはJson形式もしくはCSV形式で返します。  
下記のURLでAPIを紹介しています。  
https://holidays-jp.github.io/

参考コード
![](upload/image-31-768x962.png)
<p class="tmp list"><span>リスト</span>祝日表示</p>
```
document.addEventListener("DOMContentLoaded", function () {
    $.get("https://holidays-jp.github.io/api/v1/date.json", function (holidaysData) { 
        //初期処理
        var calendarEl = document.getElementById('calendar'); 
        var calendar = new FullCalendar.Calendar(calendarEl,
        {
			// ほかのオプションを省略
			// イベント予定設定
			events: getEventDates(holidaysData),
			// イベント(予定)毎の初期化処理
			eventcontent: function (arg) {
				$('.fc-daygrid-day[data-date=' + arg.event.extendedProps.holiday + ']').addClass("holiday");
			};
		});

	//キャンバスにレンダリング 
	calendar.render();
	});
});

//イベント（予定）取得
function getEventDates(holidaysData){
    var eventDates = [];

    //祝日
	var holidays = Object.keys (holidaysData); 
	for (var i = 0; i < holidays.length; i++) {
    	var holiday =
		{
			// 指定日付セル内の表示内容 
			title: holidaysData[holidays[i]], 
			//日付指定
			start: holidays[i], 
			//クラス名
			className: "holiday", 
			holiday: holidays[i],
		};
		eventDates.push(holiday);
	}
}
```

![](upload/image-32-768x607.png)









