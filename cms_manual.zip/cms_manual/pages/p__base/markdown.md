*[page-title]: 共有事項

## シンクラが起動しないときの対応（雷があったとき）

シンクラの起動ボタンを15秒長押しします。そうすると、放電されるので、再度起動ボタンを押すと、立ち上がります。

## font-familyの不具合調査と対応

### 色々なサイトのfont-familyを調査

[エディターでid,class,styleを一括削除する方法](https://beacats.com/how-to-bulk-delete-attribute/)
: "Hiragino Kaku Gothic ProN","Hiragino Sans",Meiryo,sans-serif

radico
: "ヒラギノ角ゴ Pro W3", "Hiragino Kaku Gothic Pro", "メイリオ", Meiryo, Osaka, "ＭＳ Ｐゴシック", "MS P Gothic", sans-serif

[Webフォント｜Noto Sans JPをウェブサイトに設定する全手順](https://rico-notes.com/programming/html/web%E3%83%95%E3%82%A9%E3%83%B3%E3%83%88%EF%BD%9Cnoto-sans-jp%E3%82%92%E3%82%A6%E3%82%A7%E3%83%96%E3%82%B5%E3%82%A4%E3%83%88%E3%81%AB%E8%A8%AD%E5%AE%9A%E3%81%99%E3%82%8B%E5%85%A8%E6%89%8B%E9%A0%86/)
: "Helvetica Neue",Arial,"Hiragino Kaku Gothic ProN","Hiragino Sans",Meiryo,sans-serif
: 公式サイト<https://fonts.google.com/noto/specimen/Noto+Sans+JP>