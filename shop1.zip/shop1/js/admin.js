if(document.querySelector('.feedback') !== null){
    const FADE_OUT = document.querySelector('.feedback').animate([
            {opacity: 1},// from
            {opacity: 0}// to
        ],
        {//option
            delay: 7000,
            duration: 2000
        }
    )
    //animation終了後の処理
    FADE_OUT.addEventListener('finish', function() {
        document.querySelector('.feedback').remove();
    });
}