---
title: ☆ファイル、フォルダの操作
taxonomy:
    category:
        - docs
visible: true
media_order: uoload_folder_small.png
---

* [ファイルが存在するか確認する（file_exists）](#p1)
* [ファイルの全体を読み込む（file_get_contents）](#p2)
* [ファイルに書き込む（file_put_contents）](#p3)
* [JSON形式に変換（json_encode）](#p4)
* [PHPで扱える形式に変換（json_decode）](#p5)
* [アップロードしたファイルの移動（move_uploaded_file）](#p6)
* [ファイルをコピーしたり移動させる（copy, rename）](#p7)
* [フォルダ内のファイル名を取得](#p8)
* [ファイルアップロードのチェックやサイズを調べる方法](#p9)
* [アップロードされたファイルか確認する（is_uploaded_file）](#p10)
* [ファイルまたはURLをオープンしてくれる関数（fopen）](#p11)


## file_exists<span class="font-weight-normal ml-3 h4">(ファイルが存在するか確認する)</span> ##{#p1}


<p class="tmp"><span>書式</span>指定したファイルが存在する場合にはtrue、存在しない場合にはfalseを返します。</p>

	file_exists($file)

	※$fileはファイル名を格納した変数です。
    

<div class="box-example" markdown="1">
### 例1 ### {.h-example}
ファイル（foo.txt）が存在するかどうか調べます。  
以下のPHPのコードを実行すると、指定の場所にfoo.txtがあれば「foo.txtが存在します。」と表示され、無ければ「foo.txtは存在しません。」と表示されます。
<!--[新規タブ](../../../sample/php/file_/sample1(exists)/index.php?target=_blank)
<iframe width="100%" height="100" src="../../sample/php/file_/sample1(exists)/index.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>-->
</div>
##### PHP

    <?php
        $filename = 'foo.txt';

        if (file_exists($filename)) {
            echo "$filename が存在します";
        } else {
            echo "$filename は存在しません";
        }
    ?>


## file_get_contents<span class="font-weight-normal ml-3 h4">(ファイルの全体を読み込む)</span> ##{#p2}

<p class="tmp"><span>書式</span>ファイルの全体を読み込み、内容を文字列として返します。</p>

	file_get_contents(ファイル名)

<div class="box-example" markdown="1">
### 例2 ### {.h-example}
ファイル（foo.txt）を読み込み、内容をvar_dumpで表示します。

[新規タブ](../../../sample/php/file_/sample2(contents)/file_get.php?target=_blank)

<iframe width="100%" height="100" src="../../sample/php/file_/sample2(contents)/file_get.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>
##### PHPコード
```
<?php
    $file = file_get_contents('foo.txt');
    var_dump($file);
?>
```
<p class="tmp"><span>書式</span>「読み込み開始位置」から「読み込み終了位置」を指定します</p>
```
file_get_contents( ファイル, false, NULL, 読み込み開始位置, 読み込み終了位置 )
```
<div class="box-example" markdown="1">
### 例2-1 ### {.h-example}
```
<?php
$abc = file_get_contents('abc.txt', false, NULL, 3, 10);
var_dump( $abc );
?>
```
</div>

### 参考サイト

* [PHP マニュアル ](https://www.php.net/manual/ja/function.file-get-contents.php)
* [PHP入門　ファイル・URLの内容を全て読み込む - file_get_contents()](https://webkaru.net/php/function-file-get-contents/)

## file_put_contents<span class="font-weight-normal ml-3 h4">(ファイルに書き込む)</span> ##{#p3}

file_put_contents() 関数は、fopen()、fwrite()、 fclose() を続けて実行するのと同じです。  
指定したファイルが存在しない場合はファイルを作成します。 存在する場合はそのファイルを上書きします。

<p class="tmp"><span>書式</span>データを指定したファイルに書き込みます。</p>
```
file_put_contents( ファイル名, 書き込むデータ )
```

<div class="box-example" markdown="1">
### 例3 ### {.h-example}
接続すると、foo.txtのファイルに$stringの文字列が書き込まれます。
[新規タブ](../../../sample/php/file_/sample2(contents)/file_put.php?target=_blank)
</div>

##### PHPコード
```
<?php
    $file = "foo.txt";//書き込むファイル名
    $string = "Hello1, PHP";//書き込む文字列
    file_put_contents($file, $string);
?>
```

**FILE_APPEND** フラグが設定されている場合は追記になります。  
また、オプションの指定で書き込み処理中に、ファイルに対する排他ロックを行うことができます。

以下が構文です。
<p class="tmp"><span>書式</span>フラッグを使用（追記やロック）</p>
```
file_put_contents( $filename , $data [, $flags ] )
```

##### パラメータ

* filename（string）：データを書き込むファイルへのパス。  
* data（mixed）：書き込むデータ。文字列, 配列 もしくは ストリーム リソースのいずれかを指定可能です。  
* flags（int）：flags の値は、以下のフラグを組み合わせたものとなります 組み合わせる際には、論理 OR (|) 演算子で連結します。  
	* FILE_USE_INCLUDE_PATH ：filename をインクルードディレクトリから探します。  
	* FILE_APPEND ：filename がすでに存在する場合に、 データをファイルに上書きするするのではなく追記します。  
	* LOCK_EX ：書き込み処理中に、ファイルに対する排他ロックを確保します。

##### 戻り値
この関数はファイルに書き込まれたバイト数を返します。 但し、失敗した場合には FALSE を返します。  
この関数は論理値 FALSE を返す可能性がありますが、FALSE として評価される値を返す可能性もあるので、この関数の返り値を調べるには ===演算子を使用する必要があります。



以下は、既存の内容を取得して、新しい内容を追加して書き込む例です。
```
<?php
    $file = 'fruits.txt';
    // ファイルをオープンして既存のコンテンツを取得します
    $contents = file_get_contents($file);
    // 新しい内容をファイルに追加します
    $contents .= "Apple\n";
    // 結果をファイルに書き出します
    file_put_contents($file, $contents);
?>
```

以下は、オプションのフラグで、追記（FILE_APPEND）と排他ロック（LOCK_EX）を指定して書き込む例です。

    <?php
    $file = 'fruits.txt';
    $fruit = "Strawberry\n";
    //ファイルに書き込み
    file_put_contents($file, $fruit, FILE_APPEND | LOCK_EX);
    echo file_get_contents($file);
    ?>





## json_encode<span class="font-weight-normal ml-3 h4">(JSON形式に変換)</span>##{#p4}

<p class="tmp"><span>書式</span>指定した値をJSON形式に変換します。</p>

	json_encode(文字列)
    
返り値
: json_encode関数は、戻り値にJSONエンコードされた値を返し、処理が失敗した場合はFALSEを返します。

注意点
: 変換する全ての文字列データは、文字コードUTR-8にエンコードされていなければいけません。


<div class="box-example" markdown="1">
### 例3 ### {.h-example}
json_encodeを使うと「キー：値, キー：値」のようにキー:値のペアがカンマ(,)で区切られているJSON形式に変換します。  
※JSONは「キーと値」のペアとして構成されています。

[新規タブ](../../../sample/php/file_/sample3(json_encode)/index.php?target=_blank)

<iframe width="100%" height="100" src="../../sample/php/file_/sample3(json_encode)/index.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

</div>

##### PHP
    <?php
        //配列を作成
        $fruits_array = ['apple'=>'fruits1',
                         'orange'=>'fruits2',
                         'melon'=>'fruits3',
                         'pineapple'=>'fruits4'
                        ];

        //配列をJSON形式に変換
        $jsonstr =  json_encode($fruits_array);

        echo $jsonstr;
    ?>

### 日本語をjson_encodeする


<div class="box-example" markdown="1">
### 例4 ### {.h-example}

日本語が含まれる配列をjson_encodeでエンコードすると、下記のように日本語が文字コードで表示されてしまいます。

[新規タブ](../../../sample/php/file_/sample4(json_encode)/index.php?target=_blank)

<iframe width="100%" height="100" src="../../sample/php/file_/sample4(json_encode)/index.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

</div>

##### PHP

    <?php
        //配列を作成
    $fruits_array = ['apple'=>'りんご',
                     'orange'=>'オレンジ',
                     'melon'=>'メロン',
                     'pineapple'=>'パイナップル'
                    ];

        //配列をJSON形式に変換
        $jsonstr =  json_encode($fruits_array);

        echo $jsonstr;
    ?>


そのため、日本語をjson_encodeするには、第二引数に**JSON_UNESCAPED_UNICODE**を指定します。  
JSON_UNESCAPED_UNICODEを指定すると、マルチバイト文字をそのままの形式で扱います。

<div class="box-example" markdown="1">
### 例5 ### {.h-example}

日本語が含まれる配列を第二引数にJSON_UNESCAPED_UNICODEを指定し、json_encodeでエンコードします。下記のように今度は日本語で表示されるようになりました。

[新規タブ](../../../sample/php/file_/sample5(json_encode)/index.php?target=_blank)

<iframe width="100%" height="100" src="../../sample/php/file_/sample5(json_encode)/index.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

</div>

##### PHP

    <?php
        //配列を作成
        $fruits_array = ['apple'=>'りんご',
                         'orange'=>'オレンジ',
                         'melon'=>'メロン',
                         'pineapple'=>'パイナップル'
                        ];

        //配列をJSON形式に変換
        $jsonstr =  json_encode($fruits_array, JSON_UNESCAPED_UNICODE);

        echo $jsonstr;
    ?>


## json_decode<span class="font-weight-normal ml-3 h4">(PHPで扱える形式に変換)</span> ##{#p5}

JSON形式にエンコードされた文字列を受け取って、デコードするにはjson_decode関数を使用します。  
デコードとは、簡単に説明するとエンコードされたデータを元に戻すことを言います。

<p class="tmp"><span>書式</span>JSON形式などをPHPで扱える形式に変換します。</p>

	json_decode(文字列)



<div class="box-example" markdown="1">
### 例6 ### {.h-example}

一旦エンコードしてJSON形式にした配列をまた元に戻します。

[新規タブ](../../../sample/php/file_/sample6(json_encode)/index.php?target=_blank)

<iframe width="100%" height="100" src="../../sample/php/file_/sample6(json_encode)/index.php" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

</div>

##### PHP

    <?php
        //配列を作成
        $fruits_array = ['apple'=>'fruits1',
                         'orange'=>'fruits2',
                         'melon'=>'fruits3',
                         'pineapple'=>'fruits4'
                        ];

        //配列をJSON形式に変換
        $jsonstr =  json_encode($fruits_array);
        print_r($jsonstr);

        echo '<br>';

        //JSON形式を元に戻す
        $fruits = json_decode($jsonstr, true);
        print_r($fruits);

    ?>
    
file_get_contents関数で取得した文字列を、json_decode関数に渡します。

	json_decode(file_get_contents($file))

※JSONファイルの読み込みは、存在確認、文字列の取得、文字列の変換の順番で行います。


## アップロードしたファイルの移動（move_uploaded_file） ##{#p6}

### move_uploaded_fileとは
クライアントからのリクエストでアップロードされたファイルの保存場所を変更する際に使用するのが***move_uploaded_file***関数です。
アップロードされたファイルはまず、/tmpなどの一時フォルダに保存されます。

そのままでは、一定の時間が経つと一時フォルダの中身は削除されるので、アップロードされたファイルを今後使用する場合は
勝手に削除される可能性がない専用のディレクトリに保存する必要がありるため、その際にmove_uploaded_file関数を利用します。

<p class="tmp"><span>書式</span></p>
```
move_uploaded_file ( アップロードしたファイル名 , ファイルの移動先 )
```

<div class="box-example" markdown="1">
### 例7 ### {.h-example}

ファイルを選択し、formでfilesフォルダに「memo.txt」ファイルとして保存します。

[新規タブ](../../../sample/php/file_upload/?target=_blank)

<iframe width="100%" height="100" src="../../sample/php/file_upload/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

</div>

##### index.html
```
<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>アップロード</title>
</head>
<body>
	<!--formのenctypeに"multipart/form-data"を設定する-->
	<form action="upload.php" method="post" enctype="multipart/form-data">
		<!--input typeは"file"を設定する-->
		<input type="file" name="upload">
		<input type="submit" value="アップロード">
	</form>
</body>
</html>
```

##### upload.php
```
<?php
// ファイルの保存先
$uploadfile = 'files/memo.txt';
// アップロードされたファイルに、パスとファイル名を設定して保存
move_uploaded_file($_FILES['upload']['tmp_name'], $uploadfile);
// 完了メッセージを表示
echo 'アップロード完了！';
```

※ajaxで送信する場合は、[04. FormData()、Ajax送信【例6】](../../../javascript_jquery/jsother-foundation/jsother-foundation-04#ex6)に参考例を記載しています。

## ファイルをコピーしたり移動させる(copy, rename) ##{#p7}

ファイルのコピーは**copy()**を、移動は**rename()**を使います。

### copy関数
ファイルをコピーします。

<p class="tmp"><span>書式</span></p>
```
copy ( コピー元のファイルパス名 , コピー先のファイルパス名 );
```

<p class="tmp list"><span>リスト</span></p>
````
// ファイルをvarディレクトリにコピーする
copy('file.txt', 'var/file.txt');
```
<p class="tmp list"><span>リスト</span>ファイルコピーが成功したらメッセージを表示</p>
```
// varディレクトリにコピーする
if (copy('file.txt', 'var/file.txt')) {
 
  // コピーが成功した場合に表示される
  echo 'コピーしました。';
 
} else {
 
  // コピーが失敗した場合に表示される
  echo 'コピーできません！';
 
}
```

### rename関数

ファイルをリネームします。

<p class="tmp"><span>書式</span></p>
```
rename ( 元のファイルパス名 , リネーム後のファイルパス名 );
```
**rename()**はファイル名を変更する関数ですが、リネーム後のファイルパス名に移動したいディレクトリを指定することで、実際にそのディレクトリにファイルが生成されるため、結果的に移動したことになります。

元のファイル名は変更されて消えるため、元あった場所からファイルが消えることになります。

<p class="tmp list"><span>リスト</span></p>
```
// ファイルをvarディレクトリに移動する
rename('file.txt', 'var/file.txt');
```

<p class="tmp list"><span>リスト</span>ファイル移動が成功したらメッセージを表示</p>
```
// varディレクトリに移動する
if (rename('file.txt', 'var/file.txt')) {
  // 移動が成功したら表示される
  echo '移動しました。';
} else {
  // 移動に失敗したら表示される
  echo '移動できない！';
}
```

## フォルダ内のファイル名を取得 ##{#p8}

<div class="box-example" markdown="1">
### 例8 ### {.h-example}

指定したフォルダ内のファイル名やフォルダ名を表示します。

[新規タブ](../../../sample/php/file_/sample7(file_list)/?target=_blank)

![](uoload_folder_small.png)

<iframe width="100%" height="500" src="../../sample/php/file_/sample7(file_list)/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

##### HTML
```
<h3>フォルダ直下内のファイル名をすべて表示</h3>
 <?php
    foreach (glob('upload/*.*') as $file) {
        $file_name = basename($file);//ファイル名だけを抜き出す
        echo '<li><span class="filename">'.$file_name.'</span></li>';
    }
?>

<h3>拡張子を指定</h3>
<?php
	foreach(glob('upload/{*.docx,*.pdf}',GLOB_BRACE) as $file){
        $file_name = basename($file);//ファイル名だけを抜き出す
        echo '<li><span class="filename">'.$file_name.'</span></li>';
	}
?>



<h3>フォルダ内にあるフォルダ名だけを表示</h3>
<?php
	$dir = 'upload/';

	$folder = glob('upload/*', GLOB_ONLYDIR);

	foreach ($folder as $dir) {
		echo '<li><span class="filename">'.$dir.'</span></li>';
	}
?>

<h3>指定したディレクトリ配下のファイル名をすべて表示</h3>
<p></p>
<?php
	function globAll($folder) {
		// 指定されたディレクトリ内の一覧を取得
		$files = glob($folder.'/*');

		// フォルダ内ループ
		foreach ($files as $file) {
			// ファイルかどうか判定
			if (is_file($file)) {
				// ファイルならそのまま出力
				echo $file . "<br />";

			} else {//フォルダの場合、再度glob関数で中身を取得
				globAll($file);
			}
		}
	}

	// 最初にディレクトリを指定する
	globAll('upload');
    ```

## ファイルアップロードのチェックやサイズを調べる方法 ##{#p9}

PHPでアップロードファイルの情報を見る場合に扱うことになる変数や、覚えておくと便利な関数を紹介していきます。スーパーグローバル変数である***$_FILES***を使用し、ここに連想配列の形で様々な情報が格納されていきますので、その扱い方を覚えておくと色んな場面で役に立つでしょう。

PHPでは特別な変数等を使用していくことでアップロードしたファイルに関して色んな情報が取得できるようになっていますので、その基本的な使い方を知っておくと良いでしょう。

### $_FILESとは
アップロードしたファイル情報を取得するために使用する変数が「***＄_FILES***」です。これはPHPで定義済み変数とされている変数であり、つまりプログラムを組む人がわざわざ定義をしなくても初めから使えるようになっている変数になります。また$_FILESを別の言い方で「スーパーグローバル変数」とも呼びます。 $_FILES['name']といった具合に変数名に続けてファイル情報の種類を指定して使用します。

### $_FILESで取得できる情報

$_FILESでは主に「*ファイル名*」、「*ファイルタイプ*」、「*一時ファイル名*」、「*エラーコード*」、「*ファイルサイズ*」が取得できます。

* ファイル名
: アップロードしたファイルの情報は$_FILESへ連想配列の形で格納されていき、 HTMLのinputタグで指定したnameを「uploadfile」とすれば、ファイル名は$_FILES['uploadfile']['name']の中に格納されることになります。

* ファイルタイプ
: ファイル名が格納されているのと同様、ファイルのMIMEタイプも$_FILESの中に格納されています。MIMEタイプとはドキュメントの種類を表すもので、拡張子とは似て非なるものです。例えばテキストを含むものとして「text/html」など、画像を表すものとしては「image/jpeg」などがあり、これらの情報は$_FILES['uploadfile']['type']の中に情報が入っています。 ただしこの値は必ずしも正しいとは言えず、偽装されている可能性もあり注意が必要です。そこで、アップロードされたファイルのバイナリデータからできるだけ正しい値を読み取るという手法もあります。そしてそのためにはFileinfoという関数が効果的です。このファイルの種類識別の際にはこの関数も検討してみると良いでしょう。

* 一時ファイル名
: $_FILES['uploadfile']['tmp_name']では、サーバー上で一時的に保存されるテンポラリファイル名が格納されています。

* ファイルサイズ
: ファイルサイズの情報は$_FILES['uploadfile']['size']の中に格納されます。ただし格納された値はバイト単位になっていることには注意が必要です。


### PHPでファイルアップロードの確認を行うプログラム例

```
if (is_uploaded_file($_FILES['uploadfile']['tmp_name'])) {
   echo "ファイル ". $_FILES['uploadfile']['name'] ." のアップロードに成功しました。\n";
   echo "その中身を表示します\n";
   readfile($_FILES['uploadfile']['tmp_name']);
} else {
   echo "失敗しました";
   echo "ファイル名 '". $_FILES['uploadfile']['tmp_name'] . "'.";
}
```


## アップロードされたファイルか確認する（is_uploaded_file）##{#p10}

is_uploaded_file関数を使うと、フォームなどでアップロードされたファイルがPOST通信で送信されてきたものかを確認することができます。

<p class="tmp"><span>書式</span></p>
```
is_uploaded_file( $_FILES['file1']['tmp_name'] );
```
POST通信でアップされている場合はtrue、それ以外の方法でアップされている場合はfalseを返します。  
この結果から、想定していない方法でファイルがアップロードされていないかを確認できます。

フォームなどを通じてアップロードされる場合、ファイルは仮名で仮フォルダに保存されるため、スーパーグローバル変数$_FILESと組み合わせて使用することが多いです。



<p class="tmp list"><span>リスト</span>if文の条件式と組み合わせてis_uploaded_file関数を使用しています。</p>
```
// ファイルがアップロードされたか確認
if( !empty($_FILES['file1']['tmp_name']) ) {

	// POST通信でアップロードされたか確認
	if( is_uploaded_file($_FILES['file1']['tmp_name']) ) {
		echo 'ファイルはPOST通信でアップロードされました。';
	} else {
		echo 'ファイルはPOST通信以外の方法でアップロードされました。';
	}
}
```

1つ目のif文ではempty関数で仮ファイルの存在を確認し、そもそもファイルがアップロードされたかを確認し、続く2つ目のif文でis_uploaded_file関数を使ってPOST通信でアップロードされたかを確認しています。

今回はメッセージ出力のみですが、アップロードされたファイルに問題がなければ、ファイルをmove_uploaded_file関数を使って仮フォルダから本フォルダに移動する処理などを記載します。

is_uploaded_file関数はアップロードされた通信方式のみを調べることができるため、ファイル形式やサイズ（容量）などを別途確認する必要があります。


### ファイルのMIMEタイプを正確に調べる

ファイルにはJPEGやPNGなどの画像ファイル、HTMLやXMLなどのテキストファイル、動画ファイル、音源ファイルなど様々な種類があります。  
どんな種類のファイルかを正確に知りたいときは、ファイルのMIMEタイプを調べます。

MIMEタイプを調べるもっとも手軽な方法は、***mime_content_type***関数を使うことです。

<p class="tmp list"><span>リスト</span></p>
```
mime_content_type("images/test.jpg");
```

返り値として「image/jpeg」や「text/plain」など、ファイルのMIMEタイプを文字列で返します。  
具体的な用途は、ファイルアップロード機能を実装した時に「$_FILES」に入っているファイルのMIMEタイプを確認するケースです。


mime_content_type関数を使う以外にも、次の2通りの方法があります。
取得できる内容は同じですが、ファイルの種類を調べる以外の処理に応じて使う方法を選択してください。


### finfoクラスを使う

finfoクラスのインスタンスを生成し、メソッドを通じてMIMEタイプを取得する方法です。

<p class="tmp list"><span>リスト</span></p>
```
// ファイルサイズを調べたいファイルへのパス
$path = '/images/pic.jpg';

// finfoクラスを使う
$finfo = new finfo();
echo $finfo->file( $path, FILEINFO_MIME_TYPE);
```

##### 出力例
```
image/jpeg
```

まず「new finfo();」の部分でfinfoクラスのインスタンスを作成し、その後にfileメソッドでMIMEタイプを取得します。

fileメソッドの第一パラメータはファイルのパス、第二パラメータは「取得する情報の定数」です。
今回はMIMEタイプを取得するために「FILEINFO_MIME_TYPE」を指定していますが、MIMEエンコーディングを取得する「FILEINFO_MIME_ENCODING」、ファイルにあった拡張子を返す「FILEINFO_EXTENSION」などが定義されています。
定義された定数について詳しくは、php.netの「[定義済み定数](https://www.php.net/manual/ja/fileinfo.constants.php)」をご覧ください。

### fileinfoリソースを使う
fileinfoリソースを生成してファイルのMIMEタイプを取得する方法です。

<p class="tmp list"><span>リスト</span></p>
```
// ファイルサイズを調べたいファイルへのパス
$path = '/images/pic.jpg';

$file = finfo_open();
echo finfo_file($file, $path, FILEINFO_MIME_TYPE);
finfo_close($file);
```
最初に、finfo_open関数でfileinfoリソースを取得して$fileへ格納します。  
クラスのインスタンスを作成する手順と非常によく似ています。

続いて、finfo_file関数に先ほど取得したfileinfoリソース、ファイルへのパス、定数の順に指定します。  
最後の定数は先ほどのfinfoクラスで使用したものと同一です。  
そのため、ここの定数を変更すれば取得できる情報が同様に変わります。

最後にfinfo_close関数でfileinfoリソースを閉じて終了です。  
ファイルの種類を調べるだけにしてはやや手順が多いため、他の情報も取得したいときに使用する方法になります。

## ファイルまたはURLをオープンしてくれる関数（fopen） ##{#p11}

<https://www.sejuku.net/blog/24369>

～時間ある時に記入～

## 参考サイト

* [【PHP入門】ディレクトリを削除する方法を解説！(rmdir)](https://www.sejuku.net/blog/78776)






