<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>フォルダ再生成</title>
    <a href="index.html">戻る</a>
</head>
<body>
<ul>
<?php

require 'frat_create.php';//pages_copyフォルダへ同一階層にして移動

globAll('../pages_copy');

function globAll($folder) {

    $menuArray = json_decode($_POST['list']);//メニューのリスト構成

    if (!is_file($folder)) {

        $res = glob($folder . '/*'); 

        foreach ($menuArray as $item){
            $listExplode = explode('/', $item);
            $lastList = end($listExplode);
            list($listNum, $listName) = explode(".", $lastList);

            foreach ($res as $key => $f) {
                $dirArray = explode('/', $f);
                $lastDir = end($dirArray); //配列の最後の値

                list($dirNum, $dirName) = explode(".", $lastDir);

                if($dirName == $listName){
                    break;
                }
            }

            //移動
            if (rename($f, '../pages/'.$item)) {
                //echo "OK";
            } else {
                //echo "エラー";
            }
        }
    }
}
?>
</ul>
</body>
</html>