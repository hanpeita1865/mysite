---
title: ☆querySelector、querySelectorAllメソッド
taxonomy:
    category:
        - docs
---

## 参考サイト

* [JavaScriptのquerySelectorAllメソッドの使い方を現役エンジニアが解説【初心者向け】](https://techacademy.jp/magazine/26842)
* [【JavaScript入門】querySelector()によるHTML要素の取得方法まとめ！](https://www.sejuku.net/blog/70581)