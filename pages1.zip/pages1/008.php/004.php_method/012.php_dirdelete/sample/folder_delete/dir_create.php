<?php
// ディレクトリ、ファイルを作成
mkdir('test1');
mkdir('test1/test2');
touch('test1/test2/test3');