---
title: ファクトリの利用
taxonomy:
    category:
        - docs
---

* [テーブル作成](#p1)
* [ファクトリを作成する](#p2)
* [ファクトリを使ってテストする](#p3)
* [ステートを設定する](#p4)
* [ステートを利用する](#p5)
* [コールバックの設定](#p6)

## テーブル作成 {#p1}

事前にマイグレーションでpeopleテーブルを作成しておきます。  
コマンドプロンプトのディレクトを変更して、下記をを実行します。

```
php artisan make:migration create_people_table
```

\database\migrationsフォルダに**xxxx_xx_xx_xxxxxx_create_people_table.php**が作成されます。

テーブルを作成するデータベースを指定します。

<p class="tmp list"><span>リスト</span>config/database</p>
```
'mysql' => [
	'driver' => 'mysql',
	'url' => env('DATABASE_URL'),
	'host' => env('DB_HOST', '127.0.0.1'),
	'port' => env('DB_PORT', '3306'),
	'database' => env('DB_DATABASE', 'データベース名'),
	・・・・・
```

<p class="tmp list"><span>リスト</span>env</p>
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=データベース名
DB_USERNAME=staff
DB_PASSWORD=password
```

次に下記を実行します。
```
php artisan migrate:refresh --database=testing
```
データベースにpeopleテーブルが作成されます。  
ではここから、peopleテーブルにサンプルのデータを挿入する操作説明をしていきます。

## ファクトリを作成する {#p2}

モデルを使ってダミーレコードを作成する場合、あらかじめ用意したデータを使って レコードを生成するのがもっとも単純なやり方です。シーディングはそれに最適なものです。  
が、これでは、決まりきった値をチェックすることになります。もっとランダムにレコードを生成してテストする必要がある場合、Laravelでは「**ファクトリ**」を作成して利用することができます。

ファクトリは、さまざまなデータを生成するクラスです。これを用意することで、テキストや数字などをランダムに生成し、それをもとにモデルを作成し、テーブルに追加できるようになります。これにより、毎回ランダムな内容のレコードを作成してテストを行えるようになります。  
ファクトリは**artisanコマンド**を使って作成できます。ではコマンドプロンプトまたは ターミナルから実行して下さい。
```
php artisan make:factory PersonFactory
```
これで、**database/factoriesフォルダ**に**PersonFactory.php**ファイルが作成されます。これを開くと、次のようなスクリプトが記述されています。

<p class="tmp list"><span>リスト1</span></p>
```
<?php


/* @var $factory \Illuminate\Database\Eloquent\Factory */


use App\Model;
use Faker\Generator as Faker;


$factory->define(Model::class, function (Faker $faker) {
    return [
        //
    ];
});
```

Factoryクラスの**define**というメソッドを実行する文が書かれています。これは、ファクトリを設定するメソッドです。第1引数にモデルクラスを指定し、第2引数にはそれに設定するクロージャを指定します。  
このクロージャでは、「**Faker**」というクラスのインスタンスが渡されます。Fakerは、 ダミーのデータを生成するクラスです。Fakerにあるメソッドを使ってダミーのデータを生成し、returnします。これにより、ダミーデータのモデルを生成できるようになります。

### Factory を定義する
では、Personインスタンスを生成するためのファクトリを用意しましょう。 PersonFactory.phpを次のように修正して下さい。

<p class="tmp list"><span>リスト2</span></p>
```
<?php
use App\Person;
use Faker\Generator as Faker;


$factory->define(Person::class, function (Faker $faker) {
    return [
        'name' => $faker->name,
        'mail' => $faker->email,
        'age' => $faker->numberBetween(1,100),
    ];
});
```

これで、ランダムなデータを使ってPersonインスタンスを生成するファクトリが設定できました。

### Faker のメソッドについて
defineのクロージャでは、Personインスタンスに設定する値を連想配列として用意し、それをreturnしています。各項目の値は、引数で渡されるFakerインスタンスからメソッドを呼び出して用意しています。このFakerに用意されているメソッドを活用するのが、ファクトリのポイントになります。  
Fakerクラスには、値を生成するさまざまなメソッドが用意されています。膨大な数のメソッドが用意されているので、比較的よく使われるものに絞って簡単にまとめておきましょう。


|メソッド名|機能|
|--|--|
|boolean()|真偽値の値をランダムに返します。|
|randomNumber()|整数値をランダムに返します。|
|random Float()|実数値(float)をランダムに返します。|
|***numberBetween(最小値 . 最大値)***|引数で指定された範囲内からランダムに整数を返します。|
|randomHtml(階層 . 最大工レメント数)|ランダムにHTMLコードを生成します。第1引数はタグの最大階層数で、第2引数は階層内に生成されるエレメントの最大数です。|
|shuffle(配列)|引数の配列をランダムに入れ替えて返します。|
|randomLetter()| ランダムな文字(アルファベット)を返します。|
|word ()|ランダムな単語(英単語)を返します。|
|text(文字数)|引数に指定した最大文字数のテキストを生成して返します。|
|sentence()|センテンス(一文)をランダムに生成して返します。|
| paragraph() |一段落のテキストをランダムに生成して返します。|
|emoji()|絵文字をランダムに返します。|
|***name()***|名前をランダムに返します。|
|firstName()|ファーストネームをランダムに返します。|
|firstNameMale()|男性のファーストネームをランダムに返します。|
|firstNameFemale|女性のファーストネームをランダムに返します。|
|lastName()|ラストネームをランダムに返します。 |
|country()|国名をランダムに返します。|
|state()|ステート(州)をランダムに返します。|
|city()|街の名前をランダムに返します。|
|address()|住所をランダムに返します。|
|postcode()| 郵便番号をランダムに返します。|
| latitude()| 緯度の値(実数値)をランダムに返します。|
|longitude()|軽度の値(実数値)をランダムに返します。|
|phoneNumber()|電話番号をランダムに返します。|
|date() |日付(年月日)のテキストをランダムに返します。|
|time()|時刻(時分秒)のテキストをランダムに返します。|
|dateTime() |日時のテキストをランダムに返します。|
|***email()***|メールアドレスのテキストをランダムに返します。|
|userName() |ユーザー名のテキストをランダムに返します。|
|password |パスワードのテキスをランダムに返します。|
|domainName() |インターネットのドメインのテキストをランダムに返します。|
|url()|URLのテキストをランダムに返します。|
|hexcolor()|色を表す16進数の値をランダムに返します。|
|rgbcolor()|RGBの各値をランダムに返します。|
|colorName() |色名をランダムに返します。 |
|locale()|ロケールを表す値(jaなど)をランダムに返します。|

        
## ファクトリを使ってテストする {#p3}
では、作成したファクトリを利用してテストを行うサンプルを挙げておきます。 ExampleTest@testBasicTestメソッドを次のように修正して下さい。

<p class="tmp list"><span>リスト3</span></p>
```
public function testBasicTest()
{
    for($i = 0;$i < 100;$i++)
    {
        factory(Person::class)->create();
    }
    $count = Person::get()->count();
    $person = Person::find(rand(1, $count));
    $data = $person->toArray();
    print_r($data);


    $this->assertDatabaseHas('people', $data);


    $person->delete();
    $this->assertDatabaseMissing('people', $data);
 
}
```

★図挿入

コマンドプロンプトまたはターミナルから**phpunitコマンド**を実行すると、100個の Personインスタンスを生成して保存し、そこからダンダムに1つを選んでテストを行い ます。ここでは、forを使い、次の文を繰り返し実行しています。
```
factory(Person::class)->create();
```
factory関数は、引数に指定したモデルクラスのインスタンスを生成します。このとき、ファクトリとして登録された機能を使ってモデルの値が設定されます。先に作成したファクトリを使って、ランダムな値が設定されたPersonインスタンスが、これで作成されるわけです。そして、createを呼び出してモデルを保存すれば、ダミーデータがデー タベーステーブルに保存されます。

## ステートを設定する {#p4}
ファクトリは、ランダムな値を使ってモデルを生成します。ただし、なんでもランダムに作ればそれでいい、というわけにもいきません。モデルの中には、設定する値に何 らかの条件や制約が必要となるものも存在するでしょう。こうした場合、設定する値を制御する仕組みが欲しくなります。  
ファクトリには「***ステート***」と呼ばれる機能があります。これは、$factoryの「***state***」 ソッドを使って設定します。stateの使い方は次のようになります。

<p class="tmp"><span>書式1</span></p>
```
単純な形 $factory->stater モデルクラス , 名前 , 連想配列 );
```

■複雑な形 
```
$factory->state(モデルクラス , 名前, function($faker)
{
	return 連想配列 ;
});
```
ステートは、モデルに設定される値を連想配列として返します。第3引数に直接、配列を用意してもいいし、クロージャを用意してその中で配列を作成し、returnしてもいいでしょう。クロージャを使う場合、引数にFakerが渡されるので、これを使って新たなダミーデータを取得し、利用することもできます。  
returnする連想配列は、モデルに用意されるすべての値を揃える必要はありません。 値を再設定したい項目だけ用意すればいいのです。そうすることで、ステートを呼び出 したとき、指定の項目だけ値が更新されるようになります。 こうして作成したステートは、モデルから「state」メソッドを呼び出して利用します。

■ステートの実行
```
《モデル>->state( 名前 )
```
モデルクラスのインスタンスからstateメソッドを呼び出すことで、ステートを実行します。戻り値は、値を改変したモデルのインスタンスが渡されるので、そのままcreate なりを呼び出して保存すればいいでしょう。  
stateの引数には、実行するステートの名前を指定します。ステートは、1つのモデル に複数用意することが可能です。名前を使って、どのステートを呼び出すかを決めます。 またメソッドチェーンで複数のステートを呼び出すことも可能です。

## ステートを利用する {#p5}
では、実際にステートを作成してみましょう。ステートは、ファクトリのスクリプトファイルに記述します。 /database/factories/PersonFactory.phpを開き、次のスクリプトを追記して下さい。

<p class="tmp list"><span>リスト4</span></p>
```
$factory->state(Person::class, 'upper', function($faker)
{
    return [
        'name' => strtoupper($faker->name()),
    ];
});
$factory->state(Person::class, 'lower', function($faker)
{
    return [
        'name' => strtolower($faker->name()),
    ];
});
```

前章で、Personモデルクラスのnameにアクセサとミューテータを用意し、名前はすべて大文字にして保存するようにしてありました。そこで、nameをすべて大文字にするステートと、すべて小文字にするステートを用意しました。これらを使ってモデル のnameを操作しながらテストを行おう、というわけです。

### ステートを使ってテストする
では、実際にステートを利用したテストを行ってみましょう。 ExampleTest@testBasicTestメソッドを次のように修正します。

<p class="tmp list"><span>リスト5</span></p>
```
public function testBasicTest()
{
    $list = [];
    for($i = 0;$i < 10;$i++)
    {
        $p1 = factory(Person::class)->create();
        $p2 = factory(Person::class)->states('upper')->create();
        $p3 = factory(Person::class)->states('lower')->create();
        $p4 = factory(Person::class)->states('upper')
                ->states('lower')->create();
        $list = array_merge($list, [$p1->id, $p2->id, 
                $p3->id, $p4->id]);
    }
    
    for($i = 0;$i < 10;$i++)
    {
        shuffle($list);
        $item = array_shift($list);
        $person = Person::find($item);
        $data = $person->toArray();
        print_r($data);
        
        $this->assertDatabaseHas('people', $data);


        $person->delete();
        $this->assertDatabaseMissing('people', $data);
    }
}
```

★図挿入

ここでは全部で40個のPersonを作成し、そこから10個を取り出して削除しながらテストを行っています。取り出したPersonはすべて内容を出力しています。nameの値がすべて大文字になっているのを確認しましょう。 ここではforの繰り返しごとに、次の4つのPersonを作成して保存しています。

<p class="tmp"><span>書式</span>通常のPerson </p>
```
$p1 = factory(Person::class)->create();
```

<p class="tmp"><span>書式</span>state('upper')でnameを大文字に変換したPerson </p>
```
$p2 = factory(Person::class)->states('upper')->create();
```

<p class="tmp"><span>書式</span>state("lower')でnameを小文字に変換したPerson</p>
```
$p3 = factory(Person::class)->states('lower')->create();
```
<p class="tmp"><span>書式</span>state(upper')とstate('lower)を連続で呼び出す </p>
```
$p4 = factory(Person::class)->states('upper')->states('lower')
	->create();
```

<p class="tmp"><span>書式</span>作成したPersonのidを$listに追加する</p>
```
$list = array_merge($list, [$p1->id, $p2->id, $p3->id, $p4->id]);
```

**$list**は、作成したPersonのidが保管されている配列です。Personを取り出して削除する処理を繰り返していくので、idの配列を用意し、そこからidを取り出しながら処理を していきます。  
こうして4つのPerson作成を10回繰り返し、計40個を保存したら、2つ目のforで、 Personをランダムに取り出してテストを行います。


<p class="tmp"><span>書式</span>ランダムに1つ取り出す </p>
```
shuffle($list); $item = array_shift($list); $person = Person:: find($item);
```
**shuffle**で$listをランダムにかき混ぜています。そして**array_shift**で最初の値を取り出し、**Person::find**でそのidのPersonインスタンスを取得します。

<p class="tmp"><span>書式</span>Personの内容を出力</p>
```
$data = $person->toArray(); print_r($data);
```
**toArray**でPersonの内容を配列で取り出し、print_rして出力します。これで、取り出したPersonの内容がどんなものかわかります。


<p class="tmp"><span>書式</span>$dataが存在するかテスト</p>
```
$this->assertDatabaseHas('people', $data);
```
assertDatabaseHasを使い、$dataのデータがpeopleテーブルに存在するかテストします。先ほどPerson::findで取り出したものですから、存在するはずです。存在していれ ばテストは通過です。

<p class="tmp"><span>書式</span>Personを削除しテスト</p>
```
$person->delete(); $this->assertDatabaseMissing('people', $data);
```
deleteでPersonを削除し、assertDatabaseMissingで$dataがテーブルに存在しないことをテストします。deleteで削除されていれば、このテストは通過します。


## コールバックの設定 {#p6}
ファクトリでモデルを作成したり保存したりするとき、その操作の「後処理」のようなものを行いたいこともあります。このような処理のために、ファクトリにはコールバッ クを設定するメソッドが用意されています。

<p class="tmp"><span>書式</span>モデル作成後の処理</p>
```
$factory->afterMaking モデルクラス , クロージャ );
```
<p class="tmp"><span>書式</span>モデル保存後の処理</p>
```
$factory->afterCreating( モデルクラス , クロージャ );
```

<p class="tmp"><span>書式</span>モデル作成後のステート実行後の処理</p>
```
$factory->afterMakingState( モデルクラス , クロージャ );
```


<p class="tmp"><span>書式</span>モデル保存後のステート実行後の処理処理</p>
```
$factory->afterCreatingState(モデルクラス , クロージャ );
```

<p class="tmp"><span>書式</span>クロージャ関数の定義</p>
```
function (モデルインスタンス , $faker)
{
......コールバック処理......
}
```

コールバックは、モデル作成時とステート実行時にそれぞれ用意されています。 いずれもmaking後とcreating後に呼び出されるようになっています。  
引数は第1引数にモデルクラスを指定し、第2引数にクロージャを用意します。このク ロージャが、コールバックとして実行される処理になります。  
クロージャでは、モデルのインスタンスとFakerインスタンスが引数として渡されます。これらを使って、必要な後処理を記述します。基本的なメソッドの書き方はどれも同じですから、4つあってもすぐに使いこなせるようになるでしょう。

### コールバックを用意する
では、実際に簡単なコールバック処理を用意し、動作を確かめてみます。 ExampleTest@testBasicTestはそのままで構いません。 /database/factories/PersonFactory.phpに次の文を追記して下さい。

<p class="tmp list"><span>リスト6</span></p>
```
$factory->afterMaking(Person::class, 
        function ($person, $faker)
{
    $person->name .= ' [making]';
    $person->save();
});


$factory->afterCreating(Person::class, 
        function ($person, $faker)
{
    $person->name .= ' [creating]';
    $person->save();
});


$factory->afterMakingState(Person::class, 'upper',
        function ($person, $faker)
{
    $person->name .= ' [making state]';
    $person->save();
});


$factory->afterCreatingState(Person::class, 'lower', 
        function ($person, $faker)
{
    $person->name .= ' [creating state]';
    $person->save();
});
```

★図挿入

<p>ここでは、4つのコールバックメソッド全てに簡単な処理を用意してあります。それぞれのコールバックの種類で、nameの名前の末尾に[making]といったテキストを付け 足すようにしてあります。こうしたテキストが付いていれば、それらはコールバックによって処理されたことがわかります。<br>
テストを実行すると、例えばこんな感じに、Personを取得した内容が表示されること がわかるでしょう。</p>
```
Array
{
[id] => 20 
[name] => JESSIKA KSHLERIN (MAKING) [CREATING]
	[CREATING STATE]
	[mail] => franecki.serena@hotmail.com 
    [age] => 10 
    [created_at] => 2019-05-23 07:05:34 
    [updated_at] => 2019-05-23 07:05:35
}
```

<p>ここでは、「MAKING] [CREATING] [CREATING STATE] という3つのテキストがnameに 追加されています。それぞれafterMaking、afterCreating、afterCreatingStateが実行 されていることがわかります。そして、いずれもテキストはすべて大文字に変わっています。</p>















