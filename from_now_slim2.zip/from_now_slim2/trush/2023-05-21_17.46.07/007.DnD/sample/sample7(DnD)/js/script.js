var waitList=[];  //追加するファイル用の配列変数

//ファイルをDnDしたときの関数
function addWaitList(files){  
    for(var i=0;i<files.length;i++){ //新しくDnDしたファイルらを一個一個チェックしてから、waitListに追加
        var sameName=-1;  
        for(var j=0;j<waitList.length;j++){ //新しくDnDしたファイル名と既にwaitListにあるファイル名とを比較してチェック
            if(files.item(i).name==waitList[j].name){ //ファイル名が同じのがあった場合、
                sameName=j;  
                break; //同じ名前のファイルがあればこのファイルの処理を停止
            }  
        }	
		
        if(sameName<0){//初期値(sameName=-1)のとき(同じ名前がなかったとき)
			
            waitList.push(files.item(i));//ファイルを配列変数に追加
			
			//追加したファイル名をリストに表示
			$("#waitingList").append('<li><span class="filename">'+files.item(i).name +'</span><button class="fileDelete">削除</button></li>');
			
        }else{
			if(window.confirm(files.item(i).name +'と同じ名前のファイルがあります。上書きしますか?')){
            	waitList[sameName]=files.item(i);//ファイルを上書き			   
			}
        }
    }  
}  
  
$(function(){  
    var obj = $("#DnDBox");
	
	//ドラッグしているファイルがドロップ領域に入ったとき
    obj.on('dragenter', function (e) {
        e.stopPropagation();  
        e.preventDefault();  
        $(this).css('border', '4px solid #000');
    });
	
	//ドラッグしているファイルがドロップ領域にある間
    obj.on('dragover', function (e) {  
        e.stopPropagation();  
        e.preventDefault();  
        $(this).css('border', '4px solid #000');  
    });
	
	//ドラッグしているファイルがドロップ領域にドロップされたとき
    obj.on('drop', function (e) {  
        $(this).css('border', '4px dashed #000');
		e.preventDefault(); 
		
		var dropFile = e.originalEvent.dataTransfer.files;

        addWaitList(e.originalEvent.dataTransfer.files);
    });
	
	//クリアボタンを押すと、全削除
    $('#clearWaitList').on('click',function(){
        $('#waitingList li').remove();  
        waitList=[];  
    });
	
	
    //ファイル削除を押したときの処理
	$('ul').on('click', '.fileDelete', function() {
		var delObj = $(this);
		var delName = $(this).prev('span').text();
		var fileIndex = $(this).parent('li').index();
		
		waitList.splice(fileIndex, 1);

		//リストのファイル表示削除
		delObj.parent('li').remove();
    }); 

	
	
    //アップロードボタンを押したときの処理
    $('#upload').on('click',function(){
		if(window.confirm('アップしていいですか？')){//確認メッセージ
			total = 0;
			// ファイルを上げに行く  
			var fd= new FormData();  
			for(var i=0;i<waitList.length;i++) {
				fd.append('file['+i+']', waitList[i]);//ファイル追加
			}


			//FormDataを格納した変数fdをupload.phpに送信
			$.ajax({  
				url: "upload.php",  
				type: "POST",  
				contentType: false,  
				processData: false,  
				cache: false,  
				data: fd,  
				success: function(data) {  
					$('#waitingList').children('li').remove();  
					waitList=[];
					alert('アップロードに成功しました');  
				},  
				error: function(data) {  
				   alert('アップロードに失敗しました');  
				}  
			});  
		}
    });  
});  