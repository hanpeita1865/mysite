*[page-title]:WebSocket


参考サイト
* [5分で動かせるwebsocketのサンプル3つ](https://qiita.com/okumurakengo/items/a8ccea065f5659d1a1de)

## サンプル1

下記のコマンドを実行してください。ここでは「server」ディレクトリを作成しています。

<p class="tmp cmd"><span>コマンド</span></p>
```
mkdir server
cd server
npm init -y
npm i ws --save
touch index.js //これは手動でindex.jsファイルを作成でもいい
```

<p class="tmp list"><span>リスト</span>index.js</p>
```
var server = require('ws').Server;
var s = new server({port:5001});

s.on('connection',function(ws){

    ws.on('message',function(message){
        console.log("Received: "+message);

        s.clients.forEach(function(client){
            client.send(message+' : '+new Date());
        });
    });

    ws.on('close',function(){
        console.log('I lost a client');
    });

});
```

<p class="tmp cmd"><span>コマンド</span></p>
```
node index.js
```

どこでもいいので、index.htmlを作成し、ブラウザで開く
<p class="tmp list"><span>リスト</span></p>
```
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <input type="button" id="sample" value="送信">

    <script>
        var sock = new WebSocket('ws://127.0.0.1:5001');

        // 接続
        sock.addEventListener('open',function(e){
            console.log('Socket 接続成功');
        });

        // サーバーからデータを受け取る
        sock.addEventListener('message',function(e){
            console.log(e.data);
        });

        document.addEventListener('DOMContentLoaded',function(e){
            // サーバーにデータを送る
            document.getElementById('sample').addEventListener('click',function(e){
                sock.send('hello');
            });
        });
    </script>
</body>
</html>
```

<p class="result"><span>実行結果</span></p>
![](upload/websocket実行.gif){.photo-border}

ファイル格納場所
```
C:\xampp\htdocs\server
```
