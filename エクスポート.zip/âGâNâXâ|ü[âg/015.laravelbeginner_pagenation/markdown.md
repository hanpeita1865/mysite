*[page-title]:ペジネーション


ペジネーションは、データベースに保管されているレコードを、一定数ごとに取り出し表示していく技術です。その基本的な使い方を覚えましょう。

## ペジネーションとは?

データベースで多量のデータを扱うようになると、考えなければならないのが「デー タの表示の仕方」です。これまでのように、allで全レコードを取得して表示する、といったやり方はできません。全レコードの中から、表示する部分だけを取り出して処理する必要が生じます。

このように、レコードを一定数ずつ取り出して表示していくための仕組みが「ペジネーション」です。ペジネーションは、レコード全体をページ分けして表示するための機能を提供します。1ページ当たりいくつのレコードを表示するかを指定し、その数ごとにレコードを取り出して表示していきます。

また、ページ分けをしての表示は、前後のページに移動する機能も用意しなければいけません。でなければ、必要なレコードにたどり着けなくなってしまいますから。つまりペジネーションは、「ページ分けしてレコードを取得する機能」と「指定のページに表示を移動するための機能」の2つの機能によって実現されるもの、といえるでしょう。

![](upload/pagenation_record.png "図　ペジネーションは、レコード全体から指定のページに表示するものだけを取り出す機能。リンク などを使い、簡単に前後のページに移動できるようになっている。")

DBクラスとsimplePaginateでは、実際にペジネーションを使ってレコードを表示させてみましょう。ここでは、先に作成したHello9Controllerを作成し、indexアクションメソッドに下記を追加します。  

<p class="tmp list"><span>リスト</span>Hello9Controller.php</p>
```
<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Customer;

class Hello9Controller extends Controller {

    public function index(Request $request)
    {
       $items = DB::table('customers')->simplePaginate(5);
       return view('hello14.index', ['items' => $items]);
    }

 }
```

ここでは、5項目ずつレコードを取り出して表示するようにしてあります。レコード の取得部分を見るとこうなっています。
```
$items = DB::table('customers')->simplePaginate(5);
```

テーブルは、DB::table('customers')というように指定してあります。そしてその中の 「simplePaginate」というメソッドを呼び出しています。これは以下のように利用します。

```
$変数 = DB::table(テーブル名)->simplePaginater 表示数 );
```

DB::tableでテーブルを指定し、その戻り値のインスタンスからsimplePaginateメソッドを呼び出します。これは引数に、1ページ当たりの表示レコード数を指定します。これで、1ページ分のレコードだけが取り出されます。

「ページ当たりのレコード数はわかった、ではページ数はどうやって設定するんだ?」 と思った人。ページ数の設定は必要ありません。このsimlePaginateの戻り値には、前後のページに移動するリンクの情報も含まれており、移動はそれらを使って作成されたリンクで行うようになっているのです。



## ページの表示を作成する

では、テンプレートを作成しましょう。「views」内の「hello」フォルダにあるindex. blade.phpを開き、以下のように記述して下さい。

<p class="tmp list"><span>リスト</span>hello14/index.blade.php</p>
```
@extends('layouts.helloapp')
<style>
   .pagination {
      font-size: 10pt;
   }

   .pagination li {
      display: inline-block
   }
</style>
@section('title', 'Index')

@section('menubar')
@parent
ペジネーションページ
@endsection

@section('content')
<table>
   <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Address</th>
   </tr>
   @foreach ($items as $item)
   <tr>
      <td>{{$item->id}}</td>
      <td>{{$item->name}}</td>
      <td>{{$item->address}}</td>
   </tr>
   @endforeach
</table>
{{ $items->links() }}
@endsection

@section('footer')
copyright 2023
@endsection
```

ルート情報に追記します。
<p class="tmp list"><span>リスト</span>web.php</p>
```
Route::get('hello14', [\App\Http\Controllers\Hello14Controller::class,'index']);
```

これで作成は完了です。/hello14にアクセスをしてみて下さい。レコードデータが5項目だけ表示されます。その下には、「<<Previous」「Next>>」といったリンクが表示されます。 このリンクをクリックすることで前後のページに移動することができます。

![](upload/hello14にアクセス.png "図 「/hello14」にアクセス"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/hello14_2ページ目を表示.png "図　2ページ目を表示"){.photo-border}


### ページ移動の仕組み
ここでは、コントローラ側から受け取った$itemsから順に値を取り出して、テーブルを表示しています。そしてその下では、以下のような文が用意されています。
```
{{$items->links() }}
```
$itemsは、simplePaginateで取得したインスタンスです。ここから順に値を取り出してレコードの内容を出力しています。が、実はそれがすべてではありません。 $itemsには、 前後の移動のためのリンクを生成する機能も含まれています。それが、「links」というメ ソッドです。linksで得られた値を出力することで、以下のようなタグが生成されるのです。
```
<ul class="pagination">
	<li class="disabled"><span>&laquo; Previous</span></li> 
    <li><a href="http://localhost:8000/hello?page=2" rel="next">Next &raquo;</a></li> 
</ul>
```
次のページに移動するリンクを見てみると、href="http://localhost:8000/ hello?page=2"というように設定されています。/hello に ?page=番号 とパラメータを付けることで、表示するページを設定することができるのです。  
ということは、特定のページに移動する場合は、pageに番号を指定してアクセスすれ ばいいことがわかります。例えば、/hello?page=10とすれば、10ページ目を表示させることができます。



## DBクラスとモデル

ここでは、DBクラスを利用してページ移動をしました。これは、以下のように呼び出せばよかったんですね。
<p class="tmp"><span>書式</span></p>
```
DB::table(テーブル名 )->simplePaginateページ番号 );
```
では、モデルを利用している場合はどうすればよいのでしょうか。実は、モデルもまったく同様にペジネーションを利用できます。例えば、ここではCustomerモデルクラスを使っていますが、
```
$items = Customer::simplePaginate(5);
```
このように実行すれば、まったく同様にページ単位でレコードを取得することができます。もちろん、linksメソッドで移動のリンクを生成することもできます。

### 並び順を設定する
このsimplePaginateは、基本的にはレコードを取得するgetなどの代わりとして利用するものと考えるとよいでしょう。ですから、データベースを扱う各種のメソッド(where やorderByなど)のメソッドももちろん併用することができます。

例えば、「idの古い順に並べ替えて表示する」という場合はどうすればいいでしょう か。

<p class="lang">DBクラス利用の場合 </p>
```
$items = DB::table('customers')->orderBy('id', 'desc')->simplePaginate(5);
```

<p class="lang">モデル利用の場合 </p>
```
$items = Customer::orderBy('id', 'desc')->simplePaginate(5);
```
![](upload/hello14にアクセス_ID降順.png "図 「/hello14」にアクセス（降順）"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/hello14にアクセス_ID降順2ページ目.png "図　2ページ目"){.photo-border}
<span class="arrow-down ml-5"></span>
![](upload/hello14にアクセス_ID降順3ページ目.png "図　3ページ目"){.photo-border}

このように、orderByを呼び出した後でsimplePaginateを呼び出せば、並び順を変更した状態でページ分け表示することができます。  
注意したいのは、メソッドの呼び出し順です。simplePaginateは、常に一番最後に呼び出すようにします。間違えて、simplePaginate->orderByとやってしまうとエラーになります。



## ソート順を変更する
では、更に一歩進んで、「一覧リストの項目部分をクリックしたら、ソート順が変更される」という仕組みを考えてみましょう。例えば、「Name」のところをクリックしたら name順に、「Address」をクリックしたらaddress順にレコードが並び替わる、というものです。

もちろん、前後の移動のリンクをクリックすれば、指定した並び順でページ移動をします。  
これには、何らかの形でソートするフィールド名を伝えるようにしなければいけません。一番簡単なのは、クエリー文字列を使った方法でしょう。既にペジネーションでは 表示するページ番号をpage=1というようにして伝えています。これにsort=nameといった項目を追加して処理すればできそうです。

### index アクションの修正
では、やってみましょう。まずコントローラ側の修正です。Hello9Controllerクラスの indexメソッドを以下のように作成して下さい。

<p class="tmp list"><span>リスト</span>Hello9Controller.php</p>
```
public function index_sort(Request $request)
{
   $sort = $request->sort;
   $items = Customer::orderBy($sort, 'asc')->simplePaginate(5);
   $param = ['items' => $items, 'sort' => $sort];
   return view('hello15.index', $param);
}
```

(コメント部分は、DBクラスを利用した場合の書き方)

ここでは、$request->sortの値を変数に取り出し、それをorderByの引数に指定しています。こうすることで、クエリー文字列としてsort=○○と渡されたフィールド名でレコードを並べ替えることができます。

### テンプレートの修正
続いて、テンプレートの修正です。「hello」内のindex.blade.phpを以下のように書き換えて下さい。

<p class="tmp list"><span>リスト</span>hello15/index.blade.php</p>
```
@extends('layouts.helloapp')
<style>
   .pagination {
      font-size: 10pt;
   }

   .pagination li {
      display: inline-block
   }

   tr th a:link {
      color: white;
   }

   tr th a:visited {
      color: white;
   }

   tr th a:hover {
      color: white;
   }

   tr th a:active {
      color: white;
   }
</style>
@section('title', 'Index')

@section('menubar')
@parent
インデックスページ
@endsection

@section('content')
<table>
   <tr>
      <th><a href="/hello15?sort=id">ID</a></th>
      <th><a href="/hello15?sort=name">Name</a></th>
      <th><a href="/hello15?sort=address">Address</a></th>
   </tr>
   @foreach ($items as $item)
   <tr>
      <td>{{$item->id}}</td>
      <td>{{$item->name}}</td>
      <td>{{$item->address}}</td>
   </tr>
   @endforeach
</table>
{{ $items->appends(['sort' => $sort])->links() }}
@endsection

@section('footer')
copyright 2023
@endsection
```

ルート情報に追記します。
<p class="tmp list"><span>リスト</span>web.php</p>
```
Route::get('hello15', [\App\Http\Controllers\Hello9Controller::class,'index_sort']);
```

修正したら、/hello15?sort=nameにアクセスしてみて下さい。レコードのデータがテー ブルにまとめて表示されますが、そのヘッダー部分にある「ID」「Name」「Address」といった ラベルをクリックすると、その項目でレコードを並べ替えます。また、下にある前後の ページ移動リンクも、設定した並べ替えの順番に従って実行されます。
![](upload/hello15_sort_name.png "図 「Name」で並べ替え"){.photo-border}
<span class="arrow-down ml-5"></span>  
「Address」の見出しをクリック
![](upload/hello15_sort_address.png "図 「Address」で並べ替え"){.photo-border}
<span class="arrow-down ml-5"></span>  
「ID」の見出しをクリック
![](upload/hello15_sort_id.png "図 「ID」で並べ替え"){.photo-border}


### ソート用リンクの仕組み
ここでは、クリックしてレコードの並び順を変更するために、以下のような形でリンクを用意しています。
```
<a href="/hello15?sort=name">name</a>
```
これは、name/順に並べ替えるリンクです。クエリー文字列に<span class="red">sort=name</span>と指定してあります。Hello9Controllerのindexアクション側では、$request->sortの値を取り出して orderByしていましたから、これでname/順にソートしてレコードを取り出すことができます。

### links にパラメータを追加する
前後に移動するリンクを生成するlinksメソッドのところでは、以下のような書き方に変わっています。
```
{{ $items->appends(['sort' => $sort])->links() } }
```
ここで利用している「<span class="red">appends</span>」というメソッドは、生成するリンクにパラメータを追加します。ここでは、<span class="red">['sort' => $sort]</span>と引数に指定していますが、これにより、<span class="red">sort= </span>○○といったパラメータが追加された形でリンク先が設定されるようになります。

つまり、&lt;a&gt;タグのhrefに設定されるアドレスは、「/hello15?sort=&page=○○」といっ た形になるわけです。これにより、<span class="marker-yellow50">表示するページ番号とソートするフィールド名をクエリー文字列でサーバーに送ることができます</span>。
    
## paginateメソッドの利用
simplePaginateは、前後の移動を行う単純なリンクを持っていますが、ページ数が多い場合は、ページ番号のリンクも表示される「<span class="red">paginate</span>」メソッドを利用することができます。  
Hello9Controllerのindexアクションメソッドを修正してみましょう。

<p class="tmp list"><span>リスト</span>Hello9Controller.php</p>
```
public function index_paginate(Request $request)
{
   $sort = $request->sort;
   $items = Customer::orderBy($sort, 'asc')->paginate(5);
   $param = ['items' => $items, 'sort' => $sort];
   return view('hello.index', $param);
}
```

hello15/index.blade.phpを元にhello16/index.blade.phpのテンプレートを作成します。
<p class="tmp list"><span>リスト</span>hello16/index.blade.php</p>
```
@section('content')
<table>
   <tr>
      <th><a href="/hello16?sort=id">ID</a></th>
      <th><a href="/hello16?sort=name">Name</a></th>
      <th><a href="/hello16?sort=address">Address</a></th>
   </tr>
   @foreach ($items as $item)
   <tr>
      <td>{{$item->id}}</td>
      <td>{{$item->name}}</td>
      <td>{{$item->address}}</td>
   </tr>
   @endforeach
</table>
{{ $items->appends(['sort' => $sort])->links() }}
@endsection
```

ルート情報に追記します。
<p class="tmp list"><span>リスト</span>web.php</p>
```
Route::get('hello16', [\App\Http\Controllers\Hello9Controller::class,'index_paginate']);
```
 

修正したら、「/hello16?sort=name」にアクセスしてみて下さい。今度は、前後の移動の記号の間にペー ジ番号が表示されるようになります。ページ数が多くなると、このほうが使いやすいですね。  
ここでは、simplePaginateメソッドを、ただpaginateに書き換えただけです。テンプレー ト側は一切変更はしていません。メソッドを替えるだけで、リンクまで表示が変わってしまうのです。


※うまく表示できない。
    
		
## リンクのテンプレートを用意する
では、このページ移動のリンクをカスタマイズしたい場合はどうすればいいのでしょうか。実は、リンクを生成するlinksメソッドは、使用するテンプレートを指定することができます。linksの引数にテンプレート名を指定することで、そのテンプレートを利用してページ移動のリンクを生成させることができるのです。  
とはいっても、具体的にどのようにテンプレートを用意すればいいのかわからないでしょう。そこで、Laravelにデフォルトで用意されているテンプレートをファイルとして 追加し、利用できるようにしましょう。 コマンドプロンプトまたはターミナルから、以下のようにコマンドを実行して下さい。
    
<p class="tmp cmd"><span>コマンド</span></p>
```
php artisan vendor:publish --tag=laravel-pagination
```
    
これで、「views」内に「vendor」というフォルダが作成され、更にその中に「pagination」 というフォルダが用意されます。
![](upload/viewkvendorに.png){.photo-border}

このフォルダ内に、Laravelが利用するペジネーション用のテンプレートファイルが保存されます。  
標準では4種類のファイルが用意されています。「simple ~」で始まるものは simplePaginate用、simpleがついていないのがpaginate用です。それぞれ、defaultと bootstrap-4というものが用意されています。
    
これらのファイルをベースにして中身をカスタマイズし、linksで指定して実行すれば、カスタマイズされた表示を作成できます。
    
### simple-default.blade.phpの中身
では例として、もっとも単純なsimple-default.blade.phpテンプレートの中身がどうなっているか見てみましょう。

<p class="tmp list"><span>リスト</span>vendor/pagenation/simple-default.blade.php</p>
```
@if ($paginator->hasPages())
    <nav>
        <ul class="pagination">
            {{-- Previous Page Link --}}
            @if ($paginator->onFirstPage())
                <li class="disabled" aria-disabled="true"><span>@lang('pagination.previous')</span></li>
            @else
                <li><a href="{{ $paginator->previousPageUrl() }}" rel="prev">@lang('pagination.previous')</a></li>
            @endif

            {{-- Next Page Link --}}
            @if ($paginator->hasMorePages())
                <li><a href="{{ $paginator->nextPageUrl() }}" rel="next">@lang('pagination.next')</a></li>
            @else
                <li class="disabled" aria-disabled="true"><span>@lang('pagination.next')</span></li>
            @endif
        </ul>
    </nav>
@endif
```

$paginatorという変数にあるメソッドを多用しているのがわかります。この $paginatorは、paginateやsimplePaginateで返されたインスタンスです。変数名は違いますが（サンプルでは$items）、テンプレートに渡される際には$paginatorとして渡されるようになっています。変数名を$paginatorに変更する必要はありません。
    
では、ここで使われているペジネーション独自のメソッドや値について整理しておきましょう。

複数のページがあるかどうかをチェックします。あればtrue、なければfalseです。
```
$paginator->hasPages()
```
最初のページを表示しているかどうかをチェックします。最初のページならtrue、そ うでなければfalseです。
```
$paginator->onFirstPage()
```

国際化対応のリソースからpagination.previousという名前の値を取り出しています。
```
@lang('pagination.previous')
```

現在のページより先にページがあればtrue、なければfalseを返します。
```
$paginator->hasMorePages()
```

前のページのURLを返します。
```
$paginator->previousPageUrl()
```
    
国際化対応のリソースからpagination.nextという名前の値を取り出しています。
```
@lang('pagination.next')
```

    
#### その他に用意されているメソッド

現在開いているページ番号を返します。
```
$paginator->currentPage());
```

ページに表示されているレコード数を返します。
```
$paginator->count();
```

次のページのURLを返します。
```
$paginator->nextPageUrl()
```

引数に指定したページ番号のURLを返します。
```
$paginator->url( 番号 )
```

これらを利用してテンプレートを作成していくことになります。 この他、simpleのついていないテンプレートファイルでは、「$elements」という変数も用意されています。これは、ページ番号の表示に使われるデータの配列で、配列の各 項目にはページ番号とリンクのURLが保管されています。default.blade.phpでは、この $elementsを使ってページ番号の表示を行う処理が用意されています。

## app.cssスタイルシートについて
ここまで、スタイルシートについては特に考えることなく進めてきましたが、ページ移動のリンクのデザインを考えるようになると、標準で用意されるスタイルシートにつ いても触れておかなければいけないでしょう。
    
Laravelでは、標準で「/css/app.css」というスタイルシートが用意されています。これを利用することで、ある程度デザインされた表示を作ることができます。
ページのデザインを担当しているhelloapp.blade.phpの&lt;head&gt;部分に、以下のようにタグを追記してみて下さい。

<p class="tmp list"><span>リスト</span>layouts/helloapp.blade.php</p>
```
<link rel="stylesheet" type="text/css" href="/css/app.css">
```
そして/hello?sort=nameにアクセスをすると、ページ移動のリンクがきれいにデザインされて表示されます。


app.cssは、「Bootstrap」というページデザインのためのライブラリのスタイルシートを内包しており、このBootstrapを利用したデザインがしやすいようになっています。

※「app.css」の中身は空になっている。これだと読み込んでも意味なし。???




