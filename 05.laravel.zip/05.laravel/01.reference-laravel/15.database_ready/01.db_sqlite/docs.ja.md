---
title: SQLiteを使用する場合
taxonomy:
    category:
        - docs
---

## SQLiteデータベースを準備する
データベースと一口にいってもさまざまなものがあります。Laravelでは、標準で **MySQL、PostgeSQL、SQLite、SQL Server**に対応しています。後述しますが、これらは 既に設定ファイルまで用意されており、「どのデータベースを使うか」を指定するだけで、 そのデータベースを利用できるようになります。どのデータベースを使っても、Laravel 内ではまったく同じ扱いができるようになっているのです。  
したがって、どのデータベースを使おうと基本的には違いはありません。ここでは、 一番導入がしやすいものとして、「SQLite」を利用することにしましょう。

###  SQLite の特徴
SQLiteは、プログラム1つで簡単にデータベースを利用できる、非常にシンプルなデー タベースです。  
一般的なSQLデータベースの多くは、「クライアント・サーバー型」で、データベースサーバーとしてプログラムを起動し、それにクライアントとしてアクセスするようになっています。これは、まずSQLデータベースサーバーを設定して起動する必要 があり、どうしても大掛かりなものになってしまいがちです。

これに対してSQLiteは、データベースサーバーだけでなく、「ファイル型」の利用も可能です。つまり、SQLiteのデータベースファイルを保存し、そこに直接アクセスしてデータの読み書きを行うのです。これだとサーバーなどを起動する必要がありません。更に、PHPにはSQLiteファイルにアクセスする機能があるので、SQLite本体すら必要ないのです。何の準備もせず、すぐにデータベースの利用を開始することができます。

### SQLite を用意する。
とはいえ、データベースを利用する場合には、PHPのプログラムだけでなく、直接デー タベースにアクセスしてデータベースの操作を行う必要が生じます。SQLiteのインス トールは面倒なものではありませんので、Windowsユーザーはインストールだけ行って おくとよいでしょう。 SQLiteは、以下のアドレスで公開されています。

<http://www.sqlite.org/download.html>

![](sqlite02.png?classes=caption "図 SQLiteのダウンロードページ。ここから、Precompiled Binariesをダウンロードする。")

ここでは、SQLiteのソースコードからドキュメント、バイナリファイルまで一通りを 配布しています。プログラムは、「***Precompiled Binaries for Windows***」というところにアップロードされています。ここから、使っているOS用のバイナリファイルをダウンロードして下さい。64 bit Windowsを使っているなら、「***sqlite-dill-win64-x64-xxx.zip***」(xxxはバー ジョン番号)をダウンロードして下さい。

ダウンロードしたzipファイルを展開すると、「sqlite3.dll」というファイルがあります。 これが、SQLiteの本体です。これを、環境変数pathに設定されている場所に保存します。 どこかわからない場合は、「Windows」フォルダ内の「system32」フォルダの中に入れて下さい。これでSQLiteが使えるようになります。


## DB Browser for SQLiter
SQLiteは、コマンドを使ってデータベースを操作することができます。既にSOLに慣れている人ならばこれで十分でしょうが、これから開発を学んでいこうという人にとっ て、「すべてコマンドで」というのは少々つらいでしょう。そこで、SQLiteを利用するためのツールも用意しておきましょう。
ここでは、「**DB Browser for SQLite**」(以後、DB Browserと略)というソフトウェアを紹介しておきます。これはSQLiteのデータベースファイルを開いて直接データベースを編集できるツールです。以下のアドレスよりダウンロードできます。

<http://sqlitebrowser.org/>

![](db_browser02.png?classes=caption "DB Browser for SQLiteのサイト。ここからインストーラをダウンロードする。")

右側に見えるダウンロードボタンの中から利用したいプラットフォームを選んでクリックして下さい。インストーラのファイルがダウンロードできます。

インストールして、起動すると以下の画面が表示されます。

![](db_browser.png)

このウインドウは、左側に操作する項目のリストが表示され、そこから項目を選ぶと その詳細が右側に表示されるようになっています。基本的な作業の手順がわかれば、データベースの操作は比較的簡単に行えるようになるでしょう。

## データベースファイルを作る
データベースを利用するには、まずデータベースファイルを作成します。ウインドウ の左上に「New Database」というボタンがあるので、これをクリックして下さい。そして、 プロジェクトのフォルダ(ここでは「laravelapp」フォルダ)内にある「database」フォルダ 内に、「database.sqlite」というファイル名でデータベースファイルを作成しましょう。

![](db_browser1.png)


## テーブルを作成する
データベースファイルを作成すると、新しいウインドウが現れます。「Edit table definition」というウインドウです。これはデータベースの「テーブル」を作成するためのものです。  
テーブルというのは、データの内容を定義し、それに従って用意されたデータ(レコー ドといいます)を保管し、管理するものです。一般に「データベースにデータを保存したり検索したりする」という作業は、このテーブルを操作することです。  
データベースには、必要に応じていくつでもデーブルを用意することができます。ここでは、以下のようなシンプルなテーブルを作ってみましょう。

####「people」テーブル 

|カラム名	|内容	|
|--|--|
|id	|保管するデータ(レコード)に割り当てる番号。	|
|name	|名前を保管する項目。	|
|mail	|メールアドレスを保管する項目。	|
|age	|年齢を保管するための項目。	|


ごく簡単な、個人情報を保管するテーブルです。テーブルにはこのように、保管するデータの項目を必要なだけ用意します。これらの項目は「フィールド」(またはカラム)と 呼ばれます。  
それぞれのフィールドには、名前と、値の種類、その他必要に応じて設定などの情報 が用意されます。では、実際にテーブルを作成しましょう。

### people テーブルを作る
では、開いているウインドウで、新しいテーブルを作成します。一番上の「Table」と 表示されているところに、テーブル名「people」を入力しましょう。

![](db_browser3.png)
一通りフィールドが用意できたら、「OK」ボタンでウインドウを閉じましょう。これで テーブルが作成できました。  
ただし、まだファイルに保存はされていません。ウインドウを閉じたら、ウインドウ 上部にある「Write Changes」ボタンをクリックして下さい。これで変更内容がファイル に保存されます。これを忘れると変更内容が保存されないので注意しましょう。 これで、ようやくデータベースにテーブルを作成できました!

![](db_browser4.png)



## SQL利用の場合
既にSQLでデータベースを利用している場合は、直接、SQLiteプログラムを実行して、 SQLのクエリを発行してテーブルを作ることもできます。この手順も説明しておきましょう。 (なお、既にDB Browserでテーブルを作成済みの場合は、この説明は読み飛ばして下さい)
まず、コマンドプロンプトで「laravelapp」フォルダの「database」フォルダにカレント ディレクトリを移動して下さい。

そして以下のコマンドを実行します。これで、sqlite3プログラムでdatabase.sqliteファ イルを開きます。
```
sqlite3 database.sqlite
```

続けて、SQLのクエリ文をタイプしてテーブルを作成します。今回は以下のように実 行すればよいでしょう。

<p class="tmp list"><span>リスト1</span></p>
```
CREATE TABLE `people` (
	`id`	INTEGER PRIMARY KEY AUTOINCREMENT,
	`name`	TEXT NOT NULL,
	`mail`	TEXT,
	`age`	INTEGER
);
```
![](sqlite_command.png)
これでテーブルが作成できます。後は、「.exit」とタイプして、SQLiteを終了すれば作 業完了です。  
SQLがわかっていれば簡単にデータベースを操作できます。

## ダミーのレコードを追加する
テーブルの用意ができたら、ダミーのレコードをいくつか追加しておきましょう。まずは、DB Browserを使ったやり方です。  
DB Browserのウインドウで、「New Database」などのボタンがあるすぐ下に、いくつ かのタブが並んでいます。ここから「Browse Data」というタブをクリックして切り替え て下さい。

![](browse_data1.png)

ここは、テーブルのレコードを表示するためのものです。タブのすぐ下にある「Table:」 ポップアップメニューから「people」を選択して下さい。そして、右側の「New Record」ボ タンを押すと、下のリストに新しいレコードが追加されます。

![](browse_data2.png)

追加されたレコードの各項目(フィールド)をクリックし、値を入力していきましょう。 IDは自動的に値が割り当てられていますから、それ以外の項目をクリックして値を記入 して下さい。

![](browse_data3.png)
これを繰り返して、いくつかレコードを作成しておきましょう。内容などは適当で構いません。

![](browse_data4.png)
レコードを追加したら、「Write Changes」ボタンをクリックして変更を保存します。 これでレコードが用意できました。

### sqlite3 コマンドを使う
続いて、SOLiteのコマンドでレコードを追加する手順を説明しましょう。先程と同様に、「sqlite3 database.sqlite」コマンドでSQLiteを起動して下さい。そして、以下のよう にSQLのクエリ文を実行しましょう。

<p class="tmp list"><span>リスト2</span></p>
```
INSERT INTO `people` VALUES (1,'taro','taro@yamada.jp',35);
INSERT INTO `people` VALUES (2,'hanako','hanako@flower.com',24);
INSERT INTO `people` VALUES (3,'sachiko','sachi@happy.org',47);
```

![](database_insert_into.png)

これで、3つのダミーレコードが追加されます。追加したら、「.exit」コマンドでSQLite を終了します。


## DB利用のための手続き
これでデータベースとテーブルが用意できました。では、いよいよLaravelからデータ ベースを利用することにしましょう。  
Laravelでは、データベースの利用に関する設定ファイルが用意されています。それらを修正してSQLiteが使えるようにしましょう。  
Laravelで使用するデータベースの情報は、「config」フォルダにある「database.php」と いうファイルに用意されています。このファイルには、以下のようなスクリプトが記述 されています(一部省略)。

<p class="tmp list"><span>リスト3</span>config/database.php</p>
初期値は、mysqlに設定されています。
```
<?php

return [

   'default' => env('DB_CONNECTION', 'mysql'),

   'connections' => [

       'sqlite' => [
           'driver' => 'sqlite',
           'database' => env('DB_DATABASE', 
                 database_path('database.sqlite')),
           'prefix' => '',
       ],

       'mysql' => [
           'driver' => 'mysql',
           'host' => env('DB_HOST', '127.0.0.1'),
           'port' => env('DB_PORT', '3306'),
           'database' => env('DB_DATABASE', 'forge'),
           'username' => env('DB_USERNAME', 'forge'),
           'password' => env('DB_PASSWORD', ''),
           'unix_socket' => env('DB_SOCKET', ''),
           'charset' => 'utf8mb4',
           'collation' => 'utf8mb4_unicode_ci',
           'prefix' => '',
           'strict' => true,
           'engine' => null,
       ],

       'pgsql' => [
           'driver' => 'pgsql',
           'host' => env('DB_HOST', '127.0.0.1'),
           'port' => env('DB_PORT', '5432'),
           'database' => env('DB_DATABASE', 'forge'),
           'username' => env('DB_USERNAME', 'forge'),
           'password' => env('DB_PASSWORD', ''),
           'charset' => 'utf8',
           'prefix' => '',
           'schema' => 'public',
           'sslmode' => 'prefer',
       ],

       'sqlsrv' => [
           'driver' => 'sqlsrv',
           'host' => env('DB_HOST', 'localhost'),
           'port' => env('DB_PORT', '1433'),
           'database' => env('DB_DATABASE', 'forge'),
           'username' => env('DB_USERNAME', 'forge'),
           'password' => env('DB_PASSWORD', ''),
           'charset' => 'utf8',
           'prefix' => '',
       ],

   ],

   ……以下略……

];
```

ここでは、配列の中にデータベース関連の設定がまとめられています。  
よく見ると、それぞれのデータベースごとに設定が用意されていることがわかるでしょう。これをもう少し整理すると以下のようになるでしょう。

### データベースの設定

```
<?php
return [
    'default' => env('DB_CONNECTION', 設定名 ),
    'connections' => [
        'sqlite' => [ ......SQLiteの設定...... ],
        'mysql' => [...MySQLの設定...... ],
        'pgsql' => [ ......PostgreSQLの設定... ],
        'sqlsrv' => [ ......SQL Serverの設定..... ],
    ],
    ......以下略......
];
```

'connections'という配列の中に、各データベースの設定がまとめられています。そし て、'default"というキーワードにenvという関数が用意されています。これは、Laravel の環境変数を設定する関数で、ここでは'DB CONNECTION'というキーワードの値を 変更しています。この値が、実際に使用されるデータベース設定となります。
デフォルトでは、'mysql"がDB_CONNECTIONに設定されています。これで、MySQL がデフォルトのデータベースに設定されることになるのです。  
では、この値をSQLiteに変更しましょう。'default'の文を以下のように書き換えて下 さい。
```
'default' => env('DB_CONNECTION', 'sqlite'),
```
これで、SQLiteがデータベースに設定されました。このDB_CONNECTIONの名前を変更するだけで、使うデータベースを替えられます。これを書き換えれば、いつでも MySQLやPostgreSQLに切り替えることができるのです。

## SQLiteの設定
では、このdatabase.phpに用意されている設定内容について説明しておきましょう。 まずは、SQLiteの設定についてです。 'sqlite'という配列にまとめられている値は以下のようになります。
```
'driver' => 'sqlite',
```
ドライバー名です。 'sqlite'としておきます。ドライバーはLaravelに組み込み済みです。
```
'database' => env('DB_DATABASE', database_path('database.sqlite')),
```
使用するデータベース名です。これはenv関数で、DB_DATABASEという環境変数に値 を設定しておきます。ここでは'database.sqlite'というファイル名を指定しています。  
このDB_DATABSEに用意するデータベースファイル名は、database_pathという関数を 使って設定しています。これは、Laravelの「database」フォルダ内のパスを返すものです。 これにより、このフォルダの中にあるデータベースファイルが設定されるようになります。
```
'prefix' => "
```
プレフィクスです。データベースの名前の前に付ける文字列の指定です。ここでは特に必要ないので空の文字列にしてあります。  
先ほど、「database」フォルダの中に「database.sqlite」というファイル名でデータ ベースファイルを用意しましたので、ここでの設定は何も変更する必要はありません。  データベースファイル名が異なるような場合は、DB_DATABASEの値を書き換えるとよいでしょう。

