<?php

namespace SocymSlim\SlimMiddle\middlewares;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Server\MiddlewareInterface;
use SocymSlim\SlimMiddle\Config\PageArea;
use SocymSlim\SlimMiddle\Config\AppConfig;

class PageAreaMiddleware implements MiddlewareInterface
{
    private AppConfig $config;

    public function __construct(AppConfig $config)
    {
        $this->config = $config;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $path = $request->getUri()->getPath();
        $path = substr($path, strlen($this->config->basePath));

        if (strpos($path, '/public/manual/') === 0) {
            $pageArea = PageArea::MANUAL;
        } else {
            $pageArea = PageArea::NORMAL;
        }

        $request = $request->withAttribute('pageArea', $pageArea);

        return $handler->handle($request);
    }
}