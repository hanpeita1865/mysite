*[page-title]:インストール方法

参考サイト
: [（YOUTUBE）WordPressをローカル環境で！ワードプレスのインストール方法も！](https://www.youtube.com/watch?v=U-_U9uz35ss)
: [【Windows】XAMPPとWordPressのインストール](https://chigusa-web.com/blog/windows%E3%81%ABxampp%E3%81%A8wordpress%E3%81%AE%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB/)

## ワードプレスをXamppに設置

ダウンロードサイト
: <https://ja.wordpress.org/download/>

ダウンロードボタンをクリックし、資材ををダウンロードします。
![](upload/ダウンロードボタン.png){.photo-border}

htdocsに解凍したフォルダを設置します。
![](upload/フォルダ設置.png){.photo-border}

データベース名　「wordpress」 ではエラーになるので、「wp1」など で作成。  
ユーザー名「staff」、パスワード「password」
<p class="lang">sql文</p>
```
create database wp1 default character set utf8 collate utf8_general_ci;
grant all on wp1.* to 'staff'@'localhost' identified by 'password';
use wp1;
```

<http://localhost:7001/wordpress/wp-admin/setup-config.php>に接続し、「さあ始めましょう」ボタンを押します。
![](upload/さあ始めましょう.png)

詳細を記入して、「送信」ボタンをクリックします。
![](upload/詳細を記入.png){.photo-border}

「インストール実行」ボタンをクリックします。
![](upload/インストール実行.png)

必要事項を入力して、「WordPressをインストール」をクリック
![](upload/WordPressをインストール.png)

成功!!
![](upload/成功しました.png)

ログインします。
![](upload/ログインする.png)

接続完了したら、ダッシュボードが開きます。
![](upload/ダッシュボード.png)