insert into product values(null, 'バターピーナッツ', 200);
