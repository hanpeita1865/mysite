---
title: （移動済）配列をカウントする(count)
taxonomy:
    category:
        - docs
---

## countとは

countは配列の要素の数を数え、それを数値として返す関数です。  
配列の要素の数や変数に含まれる要素の数などを取得したい場合に便利なので、ぜひ書き方を覚えておきましょう。

<p class="tmp"><span>書式1</span></p>
```
count(要素を数える配列,モード)
```
※( )内に要素の数を数えたい配列を入れます。

また、再帰的に要素を数える場合は「モード」の部分にCOUNT_RECURSIVEと入力します。このパラメータは使用しない場合は省略が可能です。

<div class="box-example">
    <h3 class="h-example">例1</h3>
</div>

<iframe src="https://paiza.io/projects/e/RB90eoR-k9oGScES06faiA?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

ここでは3つの数値が格納されている配列$arrを作成し、次にcountで処理した値を変数$cntに格納します。最後に$cntの値をechoによって出力します。

画面では上記のように表示されます。配列$arrには数値の「10,20,30」の3つの要素が入っているため$cntの値は”3″となり、それが表示されます。

<div class="box-example">
    <h3 class="h-example">例2</h3>
</div>

<iframe src="https://paiza.io/projects/e/Mc2tkjQ-VBePylaCIzTshw?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

$arr3には「$arr1・$arr2」という2つの要素が入っているため、上記では2と表示されます。

<div class="box-example">
    <h3 class="h-example">例2</h3>
    <p>次に、同様の配列を任意のパラメータである<strong>COUNT_RECURSIVE</strong>を使い再帰的にカウントした場合の例です。</p>
</div>

<iframe src="https://paiza.io/projects/e/Kert8dO011Mg5vGxV-jaPQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>

上記ではこのように表示されます。$arr3内の配列を含むすべての要素($arr1・$arr2とその各要素)がカウントされ、”8″と表示されます。

<div class="box-example">
    <h3 class="h-example">例3</h3>
    <p>例えば以下のような場合でも、$arr2をcountした場合は通常では”3″となりますが、COUNT_RECURSIVEを使用すると”6″が値として返されることになります。</p>
</div>

<iframe src="https://paiza.io/projects/e/OAdqOa_vk8-gPZOsGtJnFQ?theme=twilight" width="100%" height="500" scrolling="no" seamless="seamless"></iframe>









