// Gulpを初期化する
const { src, dest, series } = require('gulp');
const sassGlob = require('gulp-sass-glob');

// Gulpプラグインの読み込み
//const sass = require('gulp-sass');
const sass = require('gulp-sass')(require('sass'));
const sourcemaps = require('gulp-sourcemaps');

// Sassのコンパイル処理
const sass_compile = function () {
    return src('css/sass/style.scss')
        .pipe(sourcemaps.init())
        .pipe(sassGlob())
        .pipe(sass({ outputStyle: 'expanded' }))
        .pipe(sourcemaps.write('./'))
        .pipe(dest('css'))
}

// タスクを実行する
exports.default = series(sass_compile);