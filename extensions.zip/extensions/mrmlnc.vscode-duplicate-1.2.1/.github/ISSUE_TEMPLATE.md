### Environment

  * VSCode Version: ...
  * OS Version: ...

### Actual behavior

...

### Expected behavior

...

### Steps to reproduce

...

### Settings

```js
// Paste your configuration here.
```
