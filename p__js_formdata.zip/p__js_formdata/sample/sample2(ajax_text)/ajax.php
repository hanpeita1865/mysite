<?php
	$id = $_REQUEST['id'];
	$name = $_REQUEST['name'];

    //受け取ったデータを配列に格納
	$return_array = [$id, $name];

    //「$return_array」をjson_encodeして出力
    echo json_encode($return_array);
?>
