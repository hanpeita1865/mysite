---
title: Slider_Pro
taxonomy:
    category:
        - docs
---

## example2

[新規タブ](../../../../sample/jquery/slider-pro-master/examples/example2.html?target=_blank)

<iframe width="100%" height="450" src="../../../sample/jquery/slider-pro-master/examples/example2.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
</div>

#### HTML
```
<div id="example2" class="slider-pro">
    <div class="sp-slides">
        <div class="sp-slide">
            <a href="http://bqworks.com/slider-pro/images2/image1_large.jpg">
                <img class="sp-image" src="../src/css/images/blank.gif" 
                    data-src="http://bqworks.com/slider-pro/images2/image1_medium.jpg" 
                    data-retina="http://bqworks.com/slider-pro/images2/image1_large.jpg"/>
            </a>
            <p class="sp-caption">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>

        <div class="sp-slide">
            <a href="http://bqworks.com/slider-pro/images2/image2_large.jpg">
                <img class="sp-image" src="../src/css/images/blank.gif" 
                    data-src="http://bqworks.com/slider-pro/images2/image2_medium.jpg" 
                    data-retina="http://bqworks.com/slider-pro/images2/image2_large.jpg"/>
            </a>
            <p class="sp-caption">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
				・
                ・
    </div>
</div>
```

#### JS
```
$( document ).ready(function( $ ) {
    $( '#example2' ).sliderPro({
        width: 300,
        height: 300,
        arrows: true,
        visibleSize: '100%',
        forceSize: 'fullWidth',
        autoSlideSize: true
    });

    // instantiate fancybox when a link is clicked
    $( ".slider-pro" ).each(function(){
        var slider = $( this );

        slider.find( ".sp-image" ).parent( "a" ).on( "click", function( event ) {
            event.preventDefault();

            if ( slider.hasClass( "sp-swiping" ) === false ) {
                var sliderInstance = slider.data( "sliderPro" ),
                    isAutoplay = sliderInstance.settings.autoplay;

                $.fancybox.open( slider.find( ".sp-image" ).parent( "a" ), {
                    index: $( this ).parents( ".sp-slide" ).index(),
                    afterShow: function() {
                        if ( isAutoplay === true ) {
                            sliderInstance.settings.autoplay = false;
                            sliderInstance.stopAutoplay();
                        }
                    },
                    afterClose: function() {
                        if ( isAutoplay === true ) {
                            sliderInstance.settings.autoplay = true;
                            sliderInstance.startAutoplay();
                        }
                    }

                });
            }
        });
    });
});
```
