---
title: '06. 属性の値の取得や変更や削除<br>（attr、prop、val）'
media_order: 'google_logo.png,script.js,style.css,nttdata_logo.png,viewer.png,index.html'
taxonomy:
    category:
        - docs
visible: true
---

<style>
    h2,h3 {margin-top: 4rem;}
    #FirebugUI {top: 100px;}
    pre {margin-top: 0.5rem;}
    section {margin-bottom: 4rem;}
    .mb-05 {margin-bottom:0.5rem;}
    .att {text-indent: -1rem; padding-left: 1rem; display: block; color: #000;}
    table {margin: 2rem 0;}
    table th {text-align: center;}
    table td {text-align: center;}
    table caption {font-size: 1.2rem;}     
    .flexbox-between {display:flex; justify-content: space-between;}
    .bold {font-weight: bold;}
    .red {color: red;}
    .blue {color: blue;}
    .smp-box {
         margin: 2rem 0 3rem;
    }
    .smp {
        display: inline-block;
        margin-top: 2rem;
        margin-bottom: 0;
        background: #bc495b;
        color: #fff;
        font-size: .75rem;
        font-weight: bold;
        letter-spacing: .3rem;
        padding: .2rem .5rem;
    }
    span.tmp {
        background: #026ca2;
        color: #fff;
        font-size: .87rem;
        letter-spacing: .3rem;
        padding: .2rem 0.3rem .2rem .7rem;
        white-space: nowrap;
    }
    .dcn {
     font-weight: bold;   
    }
    .gray-box {
     	border: 1px solid gray;
        padding: 20px 30px;
        display: inline-block;
    }
    .w-400 {
      	width: 400px;
     }
    .comment {
      font-style: italic;
      color: green;
      font-size: 1rem;
    }
    h3 span {
      border-bottom: 3px solid green;   
    }
    h4 {margin-top: 3rem;}

</style>

<h2 class="h-type2">属性値の取得・変更・設定（attr）</h2>

任意の要素にある属性の値を取得・変更・設定ができます。
    

<p class="tmp"><span>書式1</span>属性値を取得する</p>

<pre>
	$('セレクタ').attr('属性'); 
</pre>

<div class="box-example">
    <h3 class="h-example">例1</h3>
    NTTデータのリンクの&lt;a&gt;要素にあるhref属性値とtarget属性値を取得し、コンソールで表示しています。
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/5ahzLm41/embedded/html,js,result" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>



<p class="mb-05"><span class="tmp">書式2</span>　<span class="bold">属性値を変更する</span></p>
<pre>
	$('セレクタ').attr('属性','値'); 
</pre>

<div class="box-example">
    <h3 class="h-example">例2</h3>
    &lt;a&gt;要素の<span class="red">href</span>属性値と、&lt;img&gt;要素の<span class="red">src</span>属性値と<span class="red">alt</span>属性値をボタンをクリックすることで切り替えています。
</div>

<script async src="//jsfiddle.net/a205rhms/1/embed/result,html,js/"></script>
</p>

ボタンをクリックすることによって、ボタンに「change」というクラスが設定されたり、削除されたりという処理を**toggleClass()**で行っています。<br><br>
<span class="red">ボタンに「change」クラスが有れば ⇒ Google画像</span><br>
<span class="blue">ボタンに「change」クラスが無ければ ⇒ NTTデータ画像</span><br><br>
というよう切り替わるように、**hasClass()**でクラス「change」の有無を判定して**attr()**で3つの属性値（href、src、alt）を代えています。

<h2 class="h-type2">属性の削除（removeAttr）</h2>
   
 <p class="mb-05"><span class="tmp">書式3</span>　<span class="bold">指定した属性を削除します。</span></p>
 <pre>
	$('セレクタ').removeAttr('属性'); 
</pre>

<div class="box-example">
    <h3 class="h-example">例3</h3>
    &lt;a&gt;要素のhref属性をボタンを押すことによって削除しています。
</div>

<script async src="//jsfiddle.net/0rvnesjk/embed/result,html,js/"></script>

属性を複数削除したいときは、下記のように**スペース区切り**で属性名を複数指定することで出来ます。 

<pre>
$('セレクタ').removeAttr('属性1 属性2 属性3'); 
</pre>


<h3><span>画像ビューアーサンプル</span></h3>
<p>サムネールをクリックすると、拡大画像の表示が切り替わります。<br>
サムネールのクリックで、対応する画像のURLを取得し、拡大画像の表示を切り替える仕組みです。</p>

<iframe width="100%" height="600" src="//jsfiddle.net/ph4g0js8/embedded/result,html,js,css" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

初期状態では一つ目の拡大画像img01.jpgが表示され、その画像のサムネールのa要素には「active」クラスを設定しています。<br>
サムネールはli要素でリストにしてあり、それぞれa要素のhref属性に、拡大する画像のパスを設定しています。<br>
したがって、thumb01.jpgをクリックした場合、画像ファイルimg01.jpgが直接表示されるようになっています。

<pre>
	$("a").click(function(){
    
		<span class="comment">// 拡大画像のsrc属性に、選択したa要素のhref属性を入れる</span>
		$("figure img").attr("src", <span class="blue bold">$(this).attr("href")</span>);	
		
		$('a').removeClass('active');<span class="comment"> //サムネール画像からactiveクラスを削除</span>
		$(this).addClass('active');<span class="comment"> //クリックしたサムネール画像にactiveクラスを設定</span>

		return false;<span class="comment"> //画面遷移停止</span>
	});
</pre>

![](viewer.png "") 

※説明図のimgのsrc属性値は相対パスにしています。



<h2 class="h-type2">属性値の取得・変更・設定（prop）</h2>

HTML属性を取得するattr()ではチェックなどの動的な動作に対応していなかったり、フォーム周りで上手く取得できないことも多かったため、フォームのプロパティを取得したり設定するために、だいぶ前ですがjQuery 1.6より**prop()**が追加されました。

チェックボックスの<span class="red">checked</span>やボタンの<span class="red">disabled</span>やセレクトボックスの<span class="red">selected</span>などのプロパティは**prop()**で操作したりします。

####attrとpropの違い
取得する値が違う

+ attrは、**属性における値** を取得
+ propは、**プロパティの値** を取得

idやname、inputのtypeなどといった属性は、DOMのAttributeにもPropertyにも同じ値で存在しているので、attr()でもprop()でも取得した値は同じになります。


+ DOM ～ WEBページとJavaScriptなどのプログラミング言語とを繋ぐ役割を持っています。<br>
+ **attribute** ～ 「HTMLに書いてあるもの」をDOM経由でやり取りするという形になっていて、jQueryでは、**attr()**を使って操作します。<br>
+ **property** ～ HTMLを解釈し構築したDOM要素のプロパティのことで、JavaScriptのオブジェクトに直接プロパティとして生えているのですぐ書き換えられます。jQueryからは、**prop()**で操作することができます。　


<div class="box-example">
    <h3 class="h-example">例4</h3>
    送信ボタンを押すと、inputタグの中のid属性の値とtype属性の値をattr()とprop()で取得して、コンソールに表示させています。
</div>




    
次の例では、attr()とprop()を使ってcheckboxの値を取得してみます。

<div class="box-example">
    <h3 class="h-example">例5</h3>
    チェックボックスにチェックを入れたときと外したときのprop()とattr()で取得したchecked属性の値を、コンソールで表示させて比較してみます。
</div>

<iframe width="100%" height="300" src="//jsfiddle.net/r6bvmzf9/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
    
チェックボックスにチェックを入れるとprop()で取得した値は「true」、attr()で取得した値は「undefined」になります。<br>
チェックをはずしたときの値は、prop()では「false」、attr()では変わらず「undefined」になります。

<div class="gray-box">
    <strong>attr()</strong> は純粋に、<strong>属性における値</strong> を取得します。<br>
checkedという属性がない ⇒ undefined<br>
<br>
一方、<strong>prop()</strong> は、<strong>属性プロパティの真偽</strong> を取得しています。<br>
checkされている　⇒　checked属性の「プロパティ」はtrue　⇒　true を取得<br>
checkされていない　⇒　checked属性の「プロパティ」はfalse　⇒　false を取得
</div>

※初期設定でinputに「checked="checked"」を記入しておくと、attr()ではチェックを入れたときも外したときも「checked」という値を取得します。


次に、disabledの場合を見てみます。

<div class="box-example">
    <h3 class="h-example">例6</h3>
    ボタンに設定したdisabledの有無を表示します。
</div>

<iframe width="100%" height="340" src="//jsfiddle.net/3ma8x0cb/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

<dl>
    <dt>ボタンにdisabledがない（ボタンが有効）の場合</dt>
    <dd class="mb-05">prop() ⇒ false、attr() ⇒ undifined</dd>
    <dt>disabledがある（ボタンが無効）の場合</dt>
    <dd>prop() ⇒ true、attr() ⇒ disabled<br>
        となります。</dd>
</dl>

####checkboxで処理を分ける

<div class="box-example">
    <h3 class="h-example">例7</h3>
    if文を使ってcheckboxのchecked属性が「true」と「false」によって処理を分けています。
</div>

<script async src="//jsfiddle.net/hirao/0hn84qgL/embed/result,html,js/"></script>

チェックが入った時と外した時に<strong>change()イベント</strong>が発動し、<br>
<pre class="mb-05 w-400">var <span class="bold red">prop</span> = $('#test').prop('checked');</pre>
でチェックの真偽値を格納した変数 <span class="bold red">prop</span> を<br>
<br>
if文を使って、下記のようにチェックが入ったときと外れたときで処理を分けています。
<pre>
    if (<span class="bold red">prop</span>) {　<span class="comment">//チェックが入った時の処理</span>
    
      $('#result').text('チェックしました。'); 
      
    } else {　<span class="comment">//チェックが外れた時の処理</span>
     
      $('#result').text(''); // テキストをリセット
      
    }
</pre>


<div class="box-example">
    <h3 class="h-example">例8</h3>
    「<span class="blue bold">href</span>」や「<span class="red bold">src</span>」から属性値を取得する場合、attr()では<span class="bold">相対パス</span>、prop()では<span class="bold">絶対パス</span>が取得されます。（余談）
</div>

<iframe width="100%" height="450" src="method-02/index.html" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>

####prop()についてまとめると

input関連で属性値の真偽（boolean型の値）については、prop()を使います。それ以外のHTML要素の属性値を取得する場合は、主にattr()を使うことが多いです。


<h2 class="h-type2">value値を取得・設定（val）</h2>

テキストボックス、ラジオボタン、セレクトボックスなどのvalue値の取得、設定を行います。

<p class="mb-05"><span class="tmp">書式4</span></p>
<pre>
	$('セレクタ').val(); 　　　　値を取得
    
    $('セレクタ').val('設定値'); 　値を設定
</pre>

<div class="box-example">
    <h3 class="h-example">例9</h3>
    チェックされたradioボタンのvalue値をval()を使って取得し、表示させています。
</div>

方法1
<script async src="//jsfiddle.net/hirao/zx05grwu/embed/result,html,js/"></script>

方法2
<script async src="//jsfiddle.net/hirao/whmexs1z/embed/result,html,js/"></script>

 

    

###おまけ

また、prop()以外でもval()やis()を使ってもcheckboxなどの真偽の値を取得することができます。

<div class="box-example">
    <h3 class="h-example">例9</h3>
    チェックを入れるとval()とis()で取得した真偽がコンソールにが表示されます。
</div>

<iframe width="100%" height="270" src="//jsfiddle.net/dq94ufar/5/embedded/html,js,result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>
この真偽を使って例7と同じように処理を分岐させることができます。<br>
ただ、<span class="bold">prop()を使うのが一般的です。</span>
