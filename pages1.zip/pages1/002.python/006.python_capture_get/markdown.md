*[page-title]:キャプチャを取得

## 準備

サイトのキャプチャを取得するには、「Chrome Driver」をブラウザのバージョンに合わせる必要があります。  
下記の「Chrome Driver download」ページからダウンロードして、上書き保存する方法もありますが、いちいち手間ですし、そもそも最新のバージョンのドライバーにダウンロードページが更新されるのがかなり遅めです。

そこで、ブラウザのバージョンを確認して自動でChrome Driverを更新するPythonのファイルを作成します。

参考サイト
: [webdriver_managerで自動的にSeleniumとChromeバージョンを一致させる](https://scr.marketing-wizard.biz/dev/webdriver-manager-selenium-chrome)

1. いつも通りAnacondaを立ち上げ、mytestの仮想環境を開きます。
2. Power Shell Promptを起動します。
3. 「selenium」「webdriver」「ChromeDriverManager」を「pip install ～」コマンドでインストールします。mytestでは既にインストール済みですので省略していいです。
4. 次のコードを実行すると、ChromeDriverのバージョンをチェックし、バージョンに差異がある場合には自動て最新版をインストールしてくれます。
```
# selenium 4
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
```
5. 実行後、フォルダを確認すると以下のように更新日時が更新されてるのがわかります。
![](upload/ChromeDriver更新後フォルダし.png)


## キャプチャを取得

指定したサイトのキャプチャを取得するコードです。

<p class="tmp list"><span>リスト</span>capture_get.py</p>
```
from selenium import webdriver

#キャプチャを撮るサイトのURL
urls = ["http://tendocity-museum.jp/"
        ]

#既定のChromeDriver格納場所
driver = webdriver.Chrome()

for url in urls:
    driver.get(url)

    page_width = driver.execute_script('return document.body.scrollWidth')
    page_height = driver.execute_script('return document.body.scrollHeight')
    driver.set_window_size(page_width, page_height)

    #「https://」と「http://」を取り、「/」を「_」に置換。
    url_name = url.lstrip("https://" "http://" ).replace("/","_").replace("?", "_")
    #画像の名前に「image_」を頭につけて、指定したフォルダに格納
    driver.save_screenshot(r"site_capture\image_" + str(url_name) + ".png")
```

実行すると、フォルダにサイト（<http://tendocity-museum.jp/>）のキャプチャが格納されています。
![](upload/指定したサイトのキャプチャを取得.png)

「urls」には、複数のサイトURLを格納できます。