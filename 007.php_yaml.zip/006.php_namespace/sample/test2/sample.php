<?php
require_once 'greeting.php'; 
require_once 'calling.php'; 
echo greet\hello(); // 出力結果：こんにちは
echo call\hello(); // 出力結果：もしもし
